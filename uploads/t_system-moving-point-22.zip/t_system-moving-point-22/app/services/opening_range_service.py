from app.logger import get_logger

from app.utils.datetime_helper import (
    ist_now,
)

from app.services.mongo_service import (
    opening_range_collection,
)

from app.services.payload_normalizer import (
    normalize_opening_range_payload,
)

from app.services.telegram_service import send_telegram_message

from app.services.opening_tele_msg_service import (
    build_opening_range_message,
)

logger = get_logger()

# ==========================================================
# PROCESS OPENING RANGE
# ==========================================================


def process_opening_range(
    trace_id: str,
    payload: dict,
):

    try:

        logger.info(
            f"Processing Opening Range "
            f"trace_id={trace_id} "
            f"symbol={payload.get('SYMBOL')}"
        )

        normalized = normalize_opening_range_payload(payload)

        doc = {
            "trace_id": trace_id,
            # ==================================================
            # BASIC FIELDS
            # ==================================================
            "type": normalized.get("type"),
            "ticker": normalized.get("ticker"),
            "symbol": normalized.get("symbol"),
            # ==================================================
            # OPENING RANGE VALUES
            # ==================================================
            "high": normalized.get("high"),
            "low": normalized.get("low"),
            "avg": normalized.get("avg"),
            "sub_resistance": normalized.get("sub_resistance"),
            "sub_support": normalized.get("sub_support"),
            "resistance2": normalized.get("resistance2"),
            "support2": normalized.get("support2"),
            "resistance3": normalized.get("resistance3"),
            "support3": normalized.get("support3"),
            # ==================================================
            # STRIKE REFERENCES
            # ==================================================
            "resistance3_ce_strike": normalized.get("resistance3_ce_strike"),
            "resistance3_pe_strike": normalized.get("resistance3_pe_strike"),
            "support3_ce_strike": normalized.get("support3_ce_strike"),
            "support3_pe_strike": normalized.get("support3_pe_strike"),
            # ==================================================
            # STRATEGY BUY LEVELS
            # ==================================================
            "buy_ce": normalized.get("buy_ce"),
            "buy_pe": normalized.get("buy_pe"),
            # ==================================================
            # FULL PAYLOAD STORAGE
            # ==================================================
            "opening_range": payload,
            "raw_payload": normalized.get("raw_payload", {}),
            # ==================================================
            # AUDIT
            # ==================================================
            "created_at": ist_now(),
        }

        result = opening_range_collection.insert_one(doc)

        # ==================================================
        # TELEGRAM NOTIFICATION
        # ==================================================

        try:

            logger.info(
                f"Preparing Opening Range Telegram "
                f"trace_id={trace_id} "
                f"symbol={doc['symbol']}"
            )

            telegram_message = build_opening_range_message(doc)

            send_telegram_message(telegram_message)

            logger.info(
                f"Opening Range Telegram sent "
                f"trace_id={trace_id} "
                f"symbol={doc['symbol']}"
            )

        except Exception:

            logger.exception(
                f"Opening Range Telegram failed "
                f"trace_id={trace_id} "
                f"symbol={doc['symbol']}"
            )

        logger.info(
            f"Opening Range saved "
            f"trace_id={trace_id} "
            f"symbol={payload.get('SYMBOL')} "
            f"mongo_id={result.inserted_id}"
        )

        return result.inserted_id

    except Exception:

        logger.exception(
            f"Opening Range processing failed "
            f"trace_id={trace_id} "
            f"symbol={payload.get('SYMBOL')}"
        )

        raise
