from app.config import TRADINGVIEW_SYMBOL_PREFIX

from app.utils.datetime_helper import (
    ist_now,
)


def build_opening_range_message(doc: dict) -> str:
    """
    Builds compact Telegram message for Opening Range.
    """

    prefix = TRADINGVIEW_SYMBOL_PREFIX.rstrip(":")

    r3_ce = f"{prefix}C{doc['resistance3_ce_strike']}"
    r3_pe = f"{prefix}P{doc['resistance3_pe_strike']}"
    s3_ce = f"{prefix}C{doc['support3_ce_strike']}"
    s3_pe = f"{prefix}P{doc['support3_pe_strike']}"

    pine_script = f"""r3CeSymbol = input.symbol("{r3_ce}", "R3 CE TradingView Symbol")
r3PeSymbol = input.symbol("{r3_pe}", "R3 PE TradingView Symbol")
s3CeSymbol = input.symbol("{s3_ce}", "S3 CE TradingView Symbol")
s3PeSymbol = input.symbol("{s3_pe}", "S3 PE TradingView Symbol")"""

    current_time = ist_now().strftime("%d-%m-%Y %I:%M:%S %p IST")

    message = f"""
<b>📈 OPENING RANGE</b>

<b>📅</b> {current_time}

<b>Symbol</b> : {doc["symbol"]}
<b>Ticker</b> : {doc["ticker"]}

<b>High</b> : {doc["high"]}
<b>Low</b> : {doc["low"]}
<b>Avg</b> : {doc["avg"]}

<b>R2</b> : {doc["resistance2"]}   |   <b>S2</b> : {doc["support2"]}
<b>R3</b> : {doc["resistance3"]}   |   <b>S3</b> : {doc["support3"]}

<b>Buy CE</b> : {doc["buy_ce"]}
<b>Buy PE</b> : {doc["buy_pe"]}

━━━━━━━━━━━━━━━━━━━━

<b>📋 Pine Input (Copy Below)</b>

<pre>{pine_script}</pre>

━━━━━━━━━━━━━━━━━━━━

<b>Trace ID</b>

<code>{doc["trace_id"]}</code>
"""

    return message.strip()
