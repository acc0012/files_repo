import threading
from app.logger import get_logger
from app.utils.datetime_helper import ist_now

from app.services.mongo_service import (
    index_signal_collection,
    option_signal_collection,
)
from app.services.upstox_service import get_option_instrument
from app.services.payload_normalizer import normalize_signal_payload
from app.services.telegram_service import send_telegram_message
from app.services.telegram_message_service import build_signal_message
from app.upstox_app.upstox_services.get_inst_data import (
    get_strike_ladder,
)
from app.upstox_app.upstox_services.ltp_service import (
    get_bulk_ltp,
)

# ==========================================================
# ✅ FIXED: UPPERCASE CONFIG SWITCHES IMPORT
# ==========================================================
from app.config import TELEGRAM_SERVICE_ENABLED, SEND_TELEGRAM_VALID_ONLY

logger = get_logger()


# ==========================================================
# PROCESS SIGNAL
# ==========================================================


def process_signal(trace_id: str, payload: dict):

    try:
        source = payload.get("ALERT_SOURCE")
        if source not in ["INDEX", "OPTION"]:
            raise ValueError(f"Unknown ALERT_SOURCE: {source}")

        normalized = normalize_signal_payload(payload)

        logger.info(
            f"Processing Signal "
            f"trace_id={trace_id} "
            f"source={source} "
            f"type={payload.get('TYPE')} "
            f"symbol={payload.get('SYMBOL')}"
        )

        signal_type = payload.get("TYPE")
        cross_direction = payload.get("CROSS_DIRECTION")
        buy_only_signal = payload.get("BUY_ONLY_SIGNAL")

        live_ce_strike = payload.get("LIVE_CE_STRIKE")
        live_pe_strike = payload.get("LIVE_PE_STRIKE")

        # ==================================================
        # ✅ FIX: Handle Strike Processing Safely
        # ==================================================
        suggested_strike_raw = (
            payload.get("SUGGESTED_STRIKE") or payload.get("suggested_strike") or {}
        )

        strike_50 = None
        strike_100 = None
        recommended_strike = ""

        if isinstance(suggested_strike_raw, dict) and suggested_strike_raw:
            strike_50 = suggested_strike_raw.get(
                "STRIKE_50"
            ) or suggested_strike_raw.get("suggested_strike_50")
            strike_100 = suggested_strike_raw.get(
                "STRIKE_100"
            ) or suggested_strike_raw.get("suggested_strike_100")
            recommended_strike = strike_50 or strike_100 or ""
        else:
            recommended_strike = (
                suggested_strike_raw if isinstance(suggested_strike_raw, str) else ""
            )

        if not recommended_strike:
            recommended_strike = payload.get("recommended_strike") or ""

        # ==================================================
        # ✅ PARSE & RESOLVE RECOMMENDED UPSTOX OPTION
        # ==================================================
        recommended_option_strike = None
        recommended_option_type = None

        recommended_option = None
        strike_ladder = {}
        upstox_meta = {}

        if recommended_strike:

            strike_text = recommended_strike.strip().upper()

            if strike_text.endswith("CE"):
                recommended_option_type = "CE"
                recommended_option_strike = int(strike_text[:-2])

            elif strike_text.endswith("PE"):
                recommended_option_type = "PE"
                recommended_option_strike = int(strike_text[:-2])

            else:
                logger.warning(
                    f"Invalid recommended strike format "
                    f"trace_id={trace_id} "
                    f"recommended_strike={recommended_strike}"
                )

        # process after parsing
        if recommended_option_strike and recommended_option_type:

            logger.info(
                f"Recommended Strike Parsed "
                f"trace_id={trace_id} "
                f"strike={recommended_option_strike} "
                f"type={recommended_option_type}"
            )

            recommended_option = get_option_instrument(
                strike_price=recommended_option_strike,
                option_type=recommended_option_type,
            )

            strike_ladder_result = get_strike_ladder(
                strike_price=recommended_option_strike,
                option_type=recommended_option_type,
            )

            if strike_ladder_result.get("success"):

                strike_ladder = strike_ladder_result

                # ==================================================
                # FETCH LATEST LTP FOR LADDER STRIKES
                # ==================================================

                exchange_tokens = []

                for item in strike_ladder.get("data", []):

                    token = item.get("exchange_token")

                    if token:

                        exchange_tokens.append(token)

                if exchange_tokens:

                    ltp_response = get_bulk_ltp(exchange_tokens)

                    if ltp_response.get("success"):

                        ltp_data = ltp_response.get("data", {})

                        for item in strike_ladder.get("data", []):

                            token = str(item.get("exchange_token"))

                            item["ltp"] = ltp_data.get(token, {}).get("last_price")

                            # Attach recommended option LTP

                        logger.info(
                            f"LTP fetched successfully "
                            f"trace_id={trace_id} "
                            f"tokens={exchange_tokens}"
                        )

                    else:

                        logger.warning(f"LTP fetch failed " f"trace_id={trace_id}")

                logger.info(
                    f"Strike ladder created "
                    f"trace_id={trace_id} "
                    f"count={strike_ladder.get('count')} "
                    f"strikes={strike_ladder.get('strikes')}"
                )

            else:

                logger.warning(f"Strike ladder creation failed " f"trace_id={trace_id}")

            if recommended_option:

                logger.info(
                    f"Recommended option resolved "
                    f"trace_id={trace_id} "
                    f"instrument_key={recommended_option.get('instrument_key')} "
                    f"trading_symbol={recommended_option.get('trading_symbol')}"
                )

                upstox_meta = {
                    "name": recommended_option.get("name"),
                    "segment": recommended_option.get("segment"),
                    "exchange": recommended_option.get("exchange"),
                    "security_id": recommended_option.get("exchange_token"),
                    "exchange_token": recommended_option.get("exchange_token"),
                    "instrument_key": recommended_option.get("instrument_key"),
                    "trading_symbol": recommended_option.get("trading_symbol"),
                    "expiry": recommended_option.get("expiry"),
                    "weekly": recommended_option.get("weekly"),
                    "instrument_type": recommended_option.get("instrument_type"),
                    "strike_price": recommended_option.get("strike_price"),
                    "lot_size": recommended_option.get("lot_size"),
                    "tick_size": recommended_option.get("tick_size"),
                    "freeze_quantity": recommended_option.get("freeze_quantity"),
                }

                if strike_ladder.get("data"):
                    upstox_meta["ltp"] = strike_ladder["data"][0].get("ltp")
            else:

                logger.warning(
                    f"Recommended option NOT FOUND "
                    f"trace_id={trace_id} "
                    f"strike={recommended_option_strike} "
                    f"type={recommended_option_type}"
                )

        logger.info(
            f"Recommended Option "
            f"trace_id={trace_id} "
            f"strike={recommended_option_strike} "
            f"type={recommended_option_type} "
            f"security_id={upstox_meta.get('security_id')} "
            f"trading_symbol={upstox_meta.get('trading_symbol')}"
        )

        signal_direction = ""
        signal_title = ""
        signal_message = ""

        # ==================================================
        # ✅ SIGNAL LOGIC (REPAIRING BLANK STRINGS)
        # ==================================================
        if signal_type == "BUY_CE":
            signal_direction = "BUY"
            signal_title = "MARKET RISING"

            if not recommended_strike:
                recommended_strike = f"{live_ce_strike} CE"

            if strike_50 or strike_100:
                signal_message = (
                    "Market is showing bullish momentum. "
                    f"ATM: {strike_50 or '-'} | Safe: {strike_100 or '-'}"
                )
            else:
                signal_message = f"Market is showing bullish momentum. Take CALL Option {recommended_strike}"

        elif signal_type == "SELL_CE":
            signal_direction = "SELL"
            signal_title = "EXIT CALL POSITION"

            if not recommended_strike:
                recommended_strike = f"{live_ce_strike} CE"

            if strike_50 or strike_100:
                signal_message = (
                    "Bullish momentum is weakening. "
                    f"ATM: {strike_50 or '-'} | Safe: {strike_100 or '-'}"
                )
            else:
                signal_message = f"Bullish momentum is weakening. Exit CALL Option {recommended_strike}"

        elif signal_type == "BUY_PE":
            signal_direction = "BUY"
            signal_title = "MARKET FALLING"

            if not recommended_strike:
                recommended_strike = f"{live_pe_strike} PE"

            if strike_50 or strike_100:
                signal_message = (
                    "Market is showing bearish momentum. "
                    f"ATM: {strike_50 or '-'} | Safe: {strike_100 or '-'}"
                )
            else:
                signal_message = f"Market is showing bearish momentum. Take PUT Option {recommended_strike}"

        elif signal_type == "SELL_PE":
            signal_direction = "SELL"
            signal_title = "EXIT PUT POSITION"

            if not recommended_strike:
                recommended_strike = f"{live_pe_strike} PE"

            if strike_50 or strike_100:
                signal_message = (
                    "Bearish momentum is weakening. "
                    f"ATM: {strike_50 or '-'} | Safe: {strike_100 or '-'}"
                )
            else:
                signal_message = f"Bearish momentum is weakening. Exit PUT Option {recommended_strike}"

        # ==================================================
        # ✅ DOCUMENT MAPPING
        # ==================================================
        or_data = normalized.get("opening_range", {})
        opt_or_data = normalized.get("option_opening_range", {})
        extracted_level_status = normalized.get("level_status", {})

        doc = {
            "trace_id": trace_id,
            "alert_source": source,
            "alert_category": payload.get("ALERT_CATEGORY"),
            "type": signal_type,
            "ticker": payload.get("TICKER"),
            "symbol": payload.get("SYMBOL"),
            "date": payload.get("DATE"),
            "time": payload.get("TIME"),
            "timeframe": payload.get("TF"),
            "cross_direction": cross_direction,
            "buy_only_signal": buy_only_signal,
            "signal_direction": signal_direction,
            "signal_title": signal_title,
            "signal_message": signal_message,
            "recommended_strike": recommended_strike,
            "suggested_strike_50": strike_50,
            "suggested_strike_100": strike_100,
            "strike_meta": suggested_strike_raw,
            "ema_cross_history": normalized.get("ema_cross_history"),
            "price": normalized.get("price"),
            "ema9": normalized.get("ema9"),
            "ema21": normalized.get("ema21"),
            "diff": normalized.get("diff"),
            "live_main_ltp": normalized.get("live_main_ltp"),
            "live_ce_strike": live_ce_strike,
            "live_pe_strike": live_pe_strike,
            "high": or_data.get("HIGH") or opt_or_data.get("HIGH"),
            "low": or_data.get("LOW") or opt_or_data.get("LOW"),
            "avg": or_data.get("AVG") or opt_or_data.get("AVG"),
            "level_status": extracted_level_status,
            "ema_level_info": normalized.get("ema_level_info", {}),
            "opening_range": normalized.get("opening_range", {}),
            "option_opening_range": normalized.get("option_opening_range", {}),
            "suggested_strike": normalized.get("suggested_strike", {}),
            "raw_payload": normalized.get("raw_payload", {}),
            "strike_ladder": strike_ladder,
            "recommended_option": upstox_meta,
            "created_at": ist_now(),
        }

        # ==================================================
        # ✅ UPPERCASE CONDITIONAL TELEGRAM VALIDATION
        # ==================================================
        r3_touched = extracted_level_status.get("R3_TOUCHED") == "YES"
        s3_touched = extracted_level_status.get("S3_TOUCHED") == "YES"
        is_level_touched = r3_touched or s3_touched

        should_send_telegram = False

        if TELEGRAM_SERVICE_ENABLED:
            if SEND_TELEGRAM_VALID_ONLY:
                if is_level_touched:
                    should_send_telegram = True
                else:
                    logger.info(
                        f"Telegram alert skipped: SEND_TELEGRAM_VALID_ONLY is True but neither R3 nor S3 touched. "
                        f"trace_id={trace_id}"
                    )
            else:
                should_send_telegram = True

        telegram_message = None
        if should_send_telegram:
            telegram_message = build_signal_message(
                payload=payload,
                signal_title=signal_title,
                signal_direction=signal_direction,
                signal_message=signal_message,
                recommended_strike=recommended_strike,
                upstox_meta=upstox_meta,  # 👈 Passing the resolved Upstox data here
            )

        # ==================================================
        # ✅ CLEANED: SAVE & DISPATCH TO CHANNELS (DRY)
        # ==================================================
        collection = (
            index_signal_collection if source == "INDEX" else option_signal_collection
        )
        result = collection.insert_one(doc)
        logger.info(
            f"{source.capitalize()} signal saved trace_id={trace_id} mongo_id={result.inserted_id}"
        )

        if should_send_telegram and telegram_message:
            threading.Thread(
                target=send_telegram_message,
                args=(telegram_message,),
                daemon=True,
            ).start()
            logger.info(f"Telegram alert triggered trace_id={trace_id}")

        return result.inserted_id

    except Exception:
        logger.exception(f"Signal processing failed trace_id={trace_id}")
        raise
