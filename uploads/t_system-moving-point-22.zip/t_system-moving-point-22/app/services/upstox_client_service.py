import upstox_client

from app.utils.datetime_helper import (
    ist_now,
)
from app.logger import get_logger

from app.services.upstox_service import (
    get_active_token,
)

logger = get_logger()

# ==========================================================
# GLOBAL CONTEXT
# ==========================================================

UPSTOX_CONTEXT = {
    "initialized": False,
    "access_token": None,
    "configuration": None,
    "api_client": None,
    "initialized_at": None,
}

# ==========================================================
# INITIALIZE CLIENT
# ==========================================================


def initialize_upstox_client():

    try:

        logger.info("=" * 80)
        logger.info("UPSTOX CLIENT INITIALIZATION STARTED")
        logger.info("=" * 80)

        token_doc = get_active_token()

        if not token_doc:

            logger.warning("No active Upstox token found in MongoDB")

            reset_upstox_client()

            return False

        access_token = token_doc.get("access_token")

        if not access_token:

            logger.warning("Active token found but access_token is empty")

            reset_upstox_client()

            return False

        configuration = upstox_client.Configuration()

        configuration.access_token = access_token

        api_client = upstox_client.ApiClient(configuration)

        UPSTOX_CONTEXT["initialized"] = True

        UPSTOX_CONTEXT["access_token"] = access_token

        UPSTOX_CONTEXT["configuration"] = configuration

        UPSTOX_CONTEXT["api_client"] = api_client

        UPSTOX_CONTEXT["initialized_at"] = ist_now()

        logger.info("Upstox client initialized successfully")

        return True

    except Exception:

        logger.exception("Failed initializing Upstox client")

        reset_upstox_client()

        return False


# ==========================================================
# RELOAD CLIENT
# ==========================================================


def reload_upstox_client():

    try:

        logger.info("Reloading Upstox client")

        return initialize_upstox_client()

    except Exception:

        logger.exception("Failed reloading Upstox client")

        return False


# ==========================================================
# GET API CLIENT
# ==========================================================


def get_api_client():

    try:

        ensure_client_initialized()

        return UPSTOX_CONTEXT["api_client"]

    except Exception:

        logger.exception("Failed retrieving Upstox ApiClient")

        raise


# ==========================================================
# GET CONFIGURATION
# ==========================================================


def get_configuration():

    try:

        if not UPSTOX_CONTEXT["initialized"]:

            raise RuntimeError("Upstox client not initialized")

        return UPSTOX_CONTEXT["configuration"]

    except Exception:

        logger.exception("Failed retrieving Upstox configuration")

        raise


# ==========================================================
# GET ACCESS TOKEN
# ==========================================================


def get_access_token():

    try:

        if not UPSTOX_CONTEXT["initialized"]:

            raise RuntimeError("Upstox client not initialized")

        return UPSTOX_CONTEXT["access_token"]

    except Exception:

        logger.exception("Failed retrieving Upstox access token")

        raise


# ==========================================================
# IS INITIALIZED
# ==========================================================


def is_initialized():

    try:

        return UPSTOX_CONTEXT["initialized"]

    except Exception:

        logger.exception("Failed checking client status")

        return False


# ==========================================================
# GET FULL CONTEXT
# ==========================================================


def get_context():

    try:

        return dict(UPSTOX_CONTEXT)

    except Exception:

        logger.exception("Failed retrieving client context")

        return {}


# ==========================================================
# CLIENT STATUS
# ==========================================================


def get_upstox_client_status():

    try:

        return {
            "initialized": UPSTOX_CONTEXT["initialized"],
            "token_loaded": bool(UPSTOX_CONTEXT["access_token"]),
            "initialized_at": UPSTOX_CONTEXT["initialized_at"],
        }

    except Exception:

        logger.exception("Failed retrieving Upstox client status")

        return {
            "initialized": False,
            "token_loaded": False,
            "initialized_at": None,
        }


# ==========================================================
# COMMON API HELPERS
# ==========================================================


def get_user_api():

    try:

        return upstox_client.UserApi(get_api_client())

    except Exception:

        logger.exception("Failed creating UserApi")

        raise


def get_order_api():

    try:

        ensure_client_initialized()

        return upstox_client.OrderApi(UPSTOX_CONTEXT["api_client"])

    except Exception:

        logger.exception("Failed creating OrderApi")

        raise


def get_market_quote_api():

    try:

        return upstox_client.MarketQuoteApi(get_api_client())

    except Exception:

        logger.exception("Failed creating MarketQuoteApi")

        raise


def get_history_api():

    try:

        return upstox_client.HistoryApi(get_api_client())

    except Exception:

        logger.exception("Failed creating HistoryApi")

        raise


# ==========================================================
# RESET CLIENT
# ==========================================================


def reset_upstox_client():

    try:

        logger.warning("Resetting Upstox client context")

        UPSTOX_CONTEXT["initialized"] = False

        UPSTOX_CONTEXT["access_token"] = None

        UPSTOX_CONTEXT["configuration"] = None

        UPSTOX_CONTEXT["api_client"] = None

        UPSTOX_CONTEXT["initialized_at"] = None

        logger.info("Upstox client context reset completed")

    except Exception:

        logger.exception("Failed resetting Upstox client context")

        raise


# ==========================================================
# ENSURE CLIENT INITIALIZED
# ==========================================================


def ensure_client_initialized():

    try:

        if UPSTOX_CONTEXT["initialized"]:

            return True

        logger.warning("Upstox client not initialized. Attempting reload.")

        success = reload_upstox_client()

        if not success:

            raise RuntimeError("Unable to initialize Upstox client.")

        return True

    except Exception:

        logger.exception("Failed ensuring Upstox client initialization")

        raise


# ==========================================================
# ORDER API V3
# ==========================================================


def get_order_api_v3():

    try:

        ensure_client_initialized()

        return upstox_client.OrderApiV3(UPSTOX_CONTEXT["api_client"])

    except Exception:

        logger.exception("Failed creating OrderApiV3")

        raise

# ==========================================================
# PORTFOLIO API
# ==========================================================


def get_portfolio_api():
    """
    Creates and returns a validated PortfolioApi instance.
    Ensures active tokens are hot-reloaded dynamically from MongoDB.
    """
    try:
        ensure_client_initialized()
        return upstox_client.PortfolioApi(UPSTOX_CONTEXT["api_client"])
    except Exception:
        logger.exception("Failed creating PortfolioApi")
        raise
        
