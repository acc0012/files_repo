# In-memory array holding your loaded contracts for sub-millisecond strategy lookup
INSTRUMENTS_CACHE = {}
