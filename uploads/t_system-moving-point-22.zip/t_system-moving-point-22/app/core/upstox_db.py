from pymongo import MongoClient
from app.config import (
    UPSTOX_OPTION_DB,
    UPSTOX_INST_COLLECTION,
    UPSTOX_ORDERS_COLLECTION,
)

from app.logger import get_logger

logger = get_logger()

class UpstoxMongoDB:
    """
    Dedicated MongoDB connection manager for Upstox databases.

    This connection is completely independent from:
        MONGO_URL
        MONGO_DB

    Used only for:
        - Instrument Cache
        - Order Storage
    """

    _client = None
    _db = None

    @classmethod
    def get_db(cls):
        """
        Returns Upstox Mongo database instance.
        Creates connection only once.
        """
        try:
            if cls._db is None:

                if not UPSTOX_OPTION_DB:
                    raise ValueError(
                        "UPSTOX_OPTION_DB is missing in environment variables"
                    )

                logger.info(
                    "Initializing Upstox MongoDB connection..."
                )

                cls._client = MongoClient(
                    UPSTOX_OPTION_DB,
                    serverSelectionTimeoutMS=5000,
                    connectTimeoutMS=5000,
                )

                # Force connection validation
                cls._client.admin.command("ping")

                cls._db = cls._client.get_default_database()

                logger.info(
                    "Successfully connected to Upstox MongoDB"
                )

            return cls._db

        except Exception as ex:
            logger.exception(
                f"Failed to connect Upstox MongoDB : {str(ex)}"
            )
            raise

    @classmethod
    def get_instrument_collection(cls):
        """
        Return instrument cache collection.
        """

        try:

            if not UPSTOX_INST_COLLECTION:
                raise ValueError(
                    "UPSTOX_INST_COLLECTION env variable is missing"
                )

            collection = cls.get_db()[UPSTOX_INST_COLLECTION]

            logger.debug(
                f"Using instrument collection : {UPSTOX_INST_COLLECTION}"
            )

            return collection

        except Exception as ex:
            logger.exception(
                f"Unable to get instrument collection : {str(ex)}"
            )
            raise

    @classmethod
    def get_orders_collection(cls):
        """
        Return orders collection.
        """

        try:

            if not UPSTOX_ORDERS_COLLECTION:
                raise ValueError(
                    "UPSTOX_ORDERS_COLLECTION env variable is missing"
                )

            collection = cls.get_db()[UPSTOX_ORDERS_COLLECTION]

            logger.debug(
                f"Using orders collection : {UPSTOX_ORDERS_COLLECTION}"
            )

            return collection

        except Exception as ex:
            logger.exception(
                f"Unable to get orders collection : {str(ex)}"
            )
            raise

    @classmethod
    def close_connection(cls):
        """
        Close Mongo connection gracefully.
        """

        try:

            if cls._client:

                logger.info(
                    "Closing Upstox MongoDB connection..."
                )

                cls._client.close()

                cls._client = None
                cls._db = None

                logger.info(
                    "Upstox MongoDB connection closed"
                )

        except Exception as ex:
            logger.exception(
                f"Error while closing MongoDB connection : {str(ex)}"
            )