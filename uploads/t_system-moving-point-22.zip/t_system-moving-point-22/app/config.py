import os

from dotenv import load_dotenv

load_dotenv()

# ==========================================================
# TELEGRAM
# ==========================================================

TELEGRAM_SERVICE_ENABLED = bool(
    os.getenv("TELEGRAM_SERVICE_ENABLED", "false").lower() == "true"
)

SEND_TELEGRAM_VALID_ONLY =bool (
    os.getenv("SEND_TELEGRAM_VALID_ONLY", "false").lower() == "true"
)
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")

TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")
# ==========================================================
# APPLICATION
# ==========================================================

APP_NAME = os.getenv("APP_NAME", "T_SYSTEM_ALERT_ENGINE")

LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")

# ==========================================================
# MARKET FEED
# ==========================================================

BASE_MARKET_URL = os.getenv("BASE_MARKET_URL")

MARKET_SECURITY_ID = os.getenv("MARKET_SECURITY_ID", "13")

# Convert https -> wss
MARKET_FEED_URL = (
    BASE_MARKET_URL.replace("https://", "wss://").replace("http://", "ws://")
    + f"/ws/market/{MARKET_SECURITY_ID}/"
)

MARKET_FEED_HEALTH_INTERVAL_MINUTES = int(
    os.getenv("MARKET_FEED_HEALTH_INTERVAL_MINUTES", "5")
)

TRADINGVIEW_SYMBOL_PREFIX = "NSE:NIFTY260630"

# ==========================================================
# MONGODB
# ==========================================================

MONGO_URL = os.getenv("MONGO_URL")

MONGO_DB = os.getenv("MONGO_DB")

# ==========================================================
# EXTRA INSTRUMENT CACHE DATABASE SETTINGS
# ==========================================================
UPSTOX_OPTION_DB = os.getenv("UPSTOX_OPTION_DB")
UPSTOX_INST_COLLECTION = os.getenv("UPSTOX_INST_COLLECTION")
UPSTOX_ORDERS_COLLECTION = os.getenv("UPSTOX_ORDERS_COLLECTION")
UPSTOX_ORDERS_TELE_TOKEN = os.getenv("TELEGRAM_ORDER_TOKEN")


# Example entries inside your .env file
UPSTOX_TOKEN_DB=os.getenv("UPSTOX_OPTION_DB")
UPSTOX_TOKEN_COLLECTION=os.getenv("UPSTOX_TOKEN_COLLECTION","UPSTOX_TOKEN_COLLECTION")

WEBHOOK_COLLECTION = os.getenv("WEBHOOK_COLLECTION")

OPENING_RANGE_COLLECTION = os.getenv("OPENING_RANGE_COLLECTION")

INDEX_SIGNAL_COLLECTION = os.getenv("INDEX_SIGNAL_COLLECTION")

OPTION_SIGNAL_COLLECTION = os.getenv("OPTION_SIGNAL_COLLECTION")

UPSTOX_TOKEN_COLLECTION = os.getenv("UPSTOX_TOKEN_COLLECTION", "upstox_tokens")

# ==========================================================
# UPSTOX
# ==========================================================

# Bootstrap token from ENV.
# After first successful validation,
# application will primarily use token
# stored in MongoDB.

UPSTOX_ACCESS_TOKEN = os.getenv("UPSTOX_ACCESS_TOKEN")

UPSTOX_API_SECRET = os.getenv("UPSTOX_API_SECRET")

UPSTOX_API_KEY = os.getenv("UPSTOX_API_KEY")

# ==========================================================
# UPSTOX API URLS
# ==========================================================

UPSTOX_FUNDS_API = "https://api.upstox.com/v2/user/get-funds-and-margin"

# ==========================================================
# TOKEN SETTINGS
# ==========================================================

UPSTOX_TOKEN_STATUS_ACTIVE = "ACTIVE"

UPSTOX_TOKEN_STATUS_EXPIRED = "EXPIRED"

UPSTOX_TOKEN_STATUS_INACTIVE = "INACTIVE"

UPSTOX_TOKEN_STATUS_MISSING = "MISSING"

MONITOR_INTERVAL_MINUTES = 30
