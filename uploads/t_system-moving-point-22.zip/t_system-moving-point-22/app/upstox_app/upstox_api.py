from fastapi import APIRouter, HTTPException, Query, status
from pydantic import BaseModel, Field
from typing import Optional

# Import all independent trading service workflows
from app.upstox_app.upstox_services.order_service import (
    place_regular_order,
    place_sl_market_order,
    place_immediate_nse_option_market_order,
)
from app.upstox_app.upstox_services.gtt_service import (
    place_single_leg_gtt,
    place_multiple_leg_gtt,
    place_trailing_stoploss_gtt,
)
from app.upstox_app.upstox_services.exit_service import (
    exit_all_positions,
    exit_all_fno_positions,
    exit_all_equity_positions,
    exit_positions_by_tag,
)
from app.upstox_app.upstox_services.portfolio_service import (
    get_live_positions,
    get_account_holdings,
)

from app.upstox_app.upstox_services.get_inst_data import (
    get_instrument_by_strike,
    get_instrument_by_token,
)

# Import the global memory state variable directly out of your service folder
# Change this line:
# from app.cache import INSTRUMENTS_CACHE

# To this:
from app.services.upstox_service import INSTRUMENTS_CACHE
from app.logger import get_logger

logger = get_logger()

# Instantiate dedicated router block for server mounting
router = APIRouter(prefix="/api/upstox", tags=["Upstox Trading Services"])

# ==========================================================
# PYDANTIC REQUEST SCHEMAS (DATA VALIDATION)
# ==========================================================


class RegularOrderSchema(BaseModel):
    instrument_token: str = Field(
        ..., description="Upstox instrument key (e.g., NSE_EQ|INE528G01035)"
    )
    transaction_type: str = Field("BUY", description="BUY or SELL")
    quantity: int = Field(..., gt=0, description="Order execution volume shares/units")
    product: str = Field("I", description="I (Intraday MIS) or D (Delivery NRML)")
    order_type: str = Field("MARKET", description="MARKET, LIMIT, SL, SL-M")
    price: float = Field(0.0, description="Order execution limit base price")
    trigger_price: float = Field(0.0, description="Trigger condition activation price")
    tag: str = Field("ALGO", description="Algorithmic custom identifier tracking flag")


class SlMarketOrderSchema(BaseModel):
    instrument_token: str = Field(...)
    transaction_type: str = Field(...)
    quantity: int = Field(..., gt=0)
    trigger_price: float = Field(
        ...,
        gt=0.0,
        description="The price target where SL-M converts to a live Market order",
    )
    product: str = Field("I")
    tag: str = Field("ALGO")


class ImmediateOptionOrderSchema(BaseModel):
    instrument_token: str
    transaction_type: str = "BUY"
    quantity: int = 65
    product: str = "I"
    tag: str = "OPTION_ALGO"


class SingleLegGttSchema(BaseModel):
    instrument_token: str = Field(...)
    transaction_type: str = Field(...)
    quantity: int = Field(..., gt=0)
    product: str = Field(...)
    trigger_price: float = Field(..., gt=0.0)
    trigger_type: str = Field("ABOVE", description="ABOVE or BELOW entry rules")


class MultiLegGttSchema(BaseModel):
    instrument_token: str = Field(...)
    transaction_type: str = Field(...)
    quantity: int = Field(..., gt=0)
    product: str = Field(...)
    entry_price: float = Field(..., gt=0.0)
    target_price: float = Field(..., gt=0.0)
    stoploss_price: float = Field(..., gt=0.0)
    entry_trigger_type: str = Field("ABOVE")


class TrailingGttSchema(BaseModel):
    instrument_token: str = Field(...)
    transaction_type: str = Field(...)
    quantity: int = Field(..., gt=0)
    product: str = Field(...)
    entry_price: float = Field(..., gt=0.0)
    target_price: float = Field(..., gt=0.0)
    stoploss_price: float = Field(..., gt=0.0)
    trailing_gap: float = Field(
        ..., gt=0.0, description="Dynamic tracking gap points offset value"
    )
    entry_trigger_type: str = Field("ABOVE")


# ==========================================================
# 1. PRIMARY ORDERS INTERFACES
# ==========================================================


@router.post("/order/regular", status_code=status.HTTP_201_CREATED)
def api_place_regular_order(payload: RegularOrderSchema):
    """Places standard orders (Market, Limit, SL, etc.) into the exchange context."""
    result = place_regular_order(
        instrument_token=payload.instrument_token,
        transaction_type=payload.transaction_type,
        quantity=payload.quantity,
        product=payload.product,
        order_type=payload.order_type,
        price=payload.price,
        trigger_price=payload.trigger_price,
        tag=payload.tag,
    )
    if not result.get("success"):
        raise HTTPException(status_code=400, detail=result)
    return result


@router.post("/order/sl-m", status_code=status.HTTP_201_CREATED)
def api_place_sl_market_order(payload: SlMarketOrderSchema):
    """Places defensive Stop Loss-Market (SL-M) barrier protection legs."""
    result = place_sl_market_order(
        instrument_token=payload.instrument_token,
        transaction_type=payload.transaction_type,
        quantity=payload.quantity,
        trigger_price=payload.trigger_price,
        product=payload.product,
        tag=payload.tag,
    )
    if not result.get("success"):
        raise HTTPException(status_code=400, detail=result)
    return result


@router.post("/order/immediate-option", status_code=status.HTTP_201_CREATED)
def api_place_immediate_option_order(payload: ImmediateOptionOrderSchema):
    """Fires instantaneous market entry routes customized exclusively for NSE options structures."""
    result = place_immediate_nse_option_market_order(
        instrument_token=payload.instrument_token,
        transaction_type=payload.transaction_type,
        quantity=payload.quantity,
        product=payload.product,
        tag=payload.tag,
    )
    if not result.get("success"):
        raise HTTPException(status_code=400, detail=result)
    return result


# ==========================================================
# 2. GOOD-TILL-TRIGGERED (GTT) BUCKET INTERFACES
# ==========================================================


@router.post("/gtt/single", status_code=status.HTTP_201_CREATED)
def api_place_single_gtt(payload: SingleLegGttSchema):
    """Configures a long-term conditional Single-Leg GTT trigger milestone."""
    result = place_single_leg_gtt(
        instrument_token=payload.instrument_token,
        transaction_type=payload.transaction_type,
        quantity=payload.quantity,
        product=payload.product,
        trigger_price=payload.trigger_price,
        trigger_type=payload.trigger_type,
    )
    if not result.get("success"):
        raise HTTPException(status_code=400, detail=result)
    return result


@router.post("/gtt/multiple", status_code=status.HTTP_201_CREATED)
def api_place_multiple_gtt(payload: MultiLegGttSchema):
    """Sets a composite multi-bracket GTT grid pairing basic Entry with rigid Target and SL checks."""
    result = place_multiple_leg_gtt(
        instrument_token=payload.instrument_token,
        transaction_type=payload.transaction_type,
        quantity=payload.quantity,
        product=payload.product,
        entry_price=payload.entry_price,
        target_price=payload.target_price,
        stoploss_price=payload.stoploss_price,
        entry_trigger_type=payload.entry_trigger_type,
    )
    if not result.get("success"):
        raise HTTPException(status_code=400, detail=result)
    return result


@router.post("/gtt/trailing", status_code=status.HTTP_201_CREATED)
def api_place_trailing_gtt(payload: TrailingGttSchema):
    """Initializes a reactive dynamic Trailing Stop Loss multi-stage bracket GTT order framework."""
    result = place_trailing_stoploss_gtt(
        instrument_token=payload.instrument_token,
        transaction_type=payload.transaction_type,
        quantity=payload.quantity,
        product=payload.product,
        entry_price=payload.entry_price,
        target_price=payload.target_price,
        stoploss_price=payload.stoploss_price,
        trailing_gap=payload.trailing_gap,
        entry_trigger_type=payload.entry_trigger_type,
    )
    if not result.get("success"):
        raise HTTPException(status_code=400, detail=result)
    return result


# ==========================================================
# 3. PANIC EMERGENCY BREAK / POSITION EXIT INTERFACES
# ==========================================================


@router.post("/exit/global", status_code=status.HTTP_200_OK)
def api_exit_global(
    segment: Optional[str] = Query(
        None, description="Filter segments: NSE_EQ, NSE_FO, MCX"
    ),
    tag: Optional[str] = Query(
        None, description="Target specific operational tag sets only"
    ),
):
    """Fires emergency global market closure sequences across open matrix groups."""
    result = exit_all_positions(segment=segment, tag=tag)
    if not result.get("success"):
        raise HTTPException(status_code=500, detail=result)
    return result


@router.post("/exit/fno", status_code=status.HTTP_200_OK)
def api_exit_fno():
    """Flushes all high-exposure active derivatives and options allocations (NSE_FO)."""
    result = exit_all_fno_positions()
    if not result.get("success"):
        raise HTTPException(status_code=500, detail=result)
    return result


@router.post("/exit/equity", status_code=status.HTTP_200_OK)
def api_exit_equity():
    """Liquidates active cash intraday and delivery equity holdings (NSE_EQ)."""
    result = exit_all_equity_positions()
    if not result.get("success"):
        raise HTTPException(status_code=500, detail=result)
    return result


@router.post("/exit/by-tag/{tag}", status_code=status.HTTP_200_OK)
def api_exit_by_tag(tag: str):
    """Isolates and terminates open positions matching an explicit strategy track identifier."""
    result = exit_positions_by_tag(tag=tag)
    if not result.get("success"):
        raise HTTPException(status_code=500, detail=result)
    return result


# ==========================================================
# 4. ACCOUNT PORTFOLIO MONITORING INTERFACES
# ==========================================================


@router.get("/portfolio/positions", status_code=status.HTTP_200_OK)
def api_get_live_positions(api_version: str = "2.0"):
    """Queries running intraday transaction status matrices and net profit metrics."""
    result = get_live_positions(api_version=api_version)
    if not result.get("success"):
        raise HTTPException(status_code=500, detail=result)
    return result


@router.get("/portfolio/holdings", status_code=status.HTTP_200_OK)
def api_get_account_holdings(api_version: str = "2.0"):
    """Pulls current structural long-term ledger asset valuations."""
    result = get_account_holdings(api_version=api_version)
    if not result.get("success"):
        raise HTTPException(status_code=500, detail=result)
    return result


@router.get("/instruments/status", tags=["System Monitoring Utilities"])
def get_instruments_cache_status():
    """
    Returns runtime state statistics regarding the preloaded
    option instruments cache.
    """

    total_cached = len(INSTRUMENTS_CACHE)

    if total_cached == 0:
        return {
            "status": "EMPTY / UNINITIALIZED",
            "total_strikes": 0,
            "message": "Warning: Memory storage cache is empty. Verify startup workflow.",
        }

    # Get the first available strike
    sample_strike = next(iter(INSTRUMENTS_CACHE))

    # Get strike data
    sample_contract = INSTRUMENTS_CACHE[sample_strike]

    # Prefer CE if available, otherwise PE
    sample_item = sample_contract.get("ce") or sample_contract.get("pe") or {}

    return {
        "status": "ACTIVE_HEALTHY",
        "total_strikes": total_cached,
        "sample_strike": sample_strike,
        "sample_contract_key": sample_item.get("instrument_key", "N/A"),
        "sample_contract_symbol": sample_item.get("trading_symbol", "N/A"),
        "expiry_target": sample_item.get("expiry", "N/A"),
    }


@router.get("/instruments")
def get_loaded_instruments():

    return {
        "type": str(type(INSTRUMENTS_CACHE)),
        "success": True,
        "count": len(INSTRUMENTS_CACHE),
        "data": INSTRUMENTS_CACHE,
    }


@router.get("/instrument")
def api_get_instrument(
    strike: int,
    option_type: str,
):
    """
    Example

    /api/upstox/instrument?strike=23400&option_type=CE
    """

    option_type = option_type.upper()

    if option_type not in ["CE", "PE"]:

        raise HTTPException(
            status_code=400,
            detail="option_type must be CE or PE",
        )

    result = get_instrument_by_strike(
        strike=strike,
        option_type=option_type,
    )

    if not result.get("success"):

        raise HTTPException(
            status_code=404,
            detail=result.get("message"),
        )

    return result


@router.get("/instrument/token/{instrument_token:path}")
def api_get_instrument_by_token(
    instrument_token: str,
):
    """
    Example

    /api/upstox/instrument/token/NSE_FO|79809
    """

    result = get_instrument_by_token(
        instrument_token=instrument_token,
    )

    if not result.get("success"):

        raise HTTPException(
            status_code=404,
            detail=result.get("message"),
        )

    return result
