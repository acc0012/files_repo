from app.logger import get_logger
import app.upstox_app.upstox_marketfeed.marketfeed_state as state
logger=get_logger()

def on_open(*args,**kwargs):
    state.IS_CONNECTED=True
    logger.info("UPSTOX MARKETFEED CONNECTED")

def on_close(*args,**kwargs):
    state.IS_CONNECTED=False
    logger.warning("UPSTOX MARKETFEED DISCONNECTED")

def on_error(error):
    logger.exception(f"Marketfeed error: {error}")

def on_message(message):
    logger.info(message)
