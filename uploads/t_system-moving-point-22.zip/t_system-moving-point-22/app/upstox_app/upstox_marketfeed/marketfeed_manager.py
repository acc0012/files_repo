from app.logger import get_logger
from app.upstox_app.upstox_marketfeed.marketfeed_client import get_marketfeed_client
from app.upstox_app.upstox_marketfeed.marketfeed_handlers import on_open,on_close,on_error,on_message
logger=get_logger()

def initialize_marketfeed():
    try:
        s=get_marketfeed_client()
        s.on("open",on_open)
        s.on("close",on_close)
        s.on("error",on_error)
        s.on("message",on_message)
        s.connect()
        logger.info("Marketfeed initialized")
    except Exception:
        logger.exception("Marketfeed initialization failed")
        raise
