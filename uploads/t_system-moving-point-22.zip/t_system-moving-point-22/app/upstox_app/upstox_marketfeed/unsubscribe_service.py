from app.logger import get_logger
from app.upstox_app.upstox_marketfeed.marketfeed_client import get_marketfeed_client
import app.upstox_app.upstox_marketfeed.marketfeed_state as state
logger=get_logger()

def unsubscribe(instrument_keys):
    try:
        get_marketfeed_client().unsubscribe(instrument_keys)
        for k in instrument_keys: state.SUBSCRIPTIONS.pop(k,None)
        logger.info(f"Unsubscribed {instrument_keys}")
        return True
    except Exception:
        logger.exception("Unsubscribe failed")
        return False
