import upstox_client
from app.logger import get_logger
from app.services.upstox_service import get_current_access_token
import app.upstox_app.upstox_marketfeed.marketfeed_state as state
logger=get_logger()

def get_marketfeed_client():
    try:
        if state.STREAMER:
            return state.STREAMER
        token=get_current_access_token()
        if not token:
            raise Exception("No Active Upstox Token")
        cfg=upstox_client.Configuration()
        cfg.access_token=token
        state.STREAMER=upstox_client.MarketDataStreamerV3(upstox_client.ApiClient(cfg))
        logger.info("Marketfeed client initialized")
        return state.STREAMER
    except Exception:
        logger.exception("Failed creating marketfeed client")
        raise
