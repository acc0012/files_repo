from app.logger import get_logger
from app.upstox_app.upstox_marketfeed.marketfeed_client import get_marketfeed_client
import app.upstox_app.upstox_marketfeed.marketfeed_state as state
logger=get_logger()

def change_mode(instrument_keys,mode):
    try:
        get_marketfeed_client().change_mode(instrument_keys,mode)
        for k in instrument_keys: state.SUBSCRIPTIONS[k]=mode
        logger.info(f"Changed mode {instrument_keys} -> {mode}")
        return True
    except Exception:
        logger.exception("Change mode failed")
        return False
