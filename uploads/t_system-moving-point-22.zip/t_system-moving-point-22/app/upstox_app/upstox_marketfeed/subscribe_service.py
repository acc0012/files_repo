from app.logger import get_logger
from app.upstox_app.upstox_marketfeed.marketfeed_client import get_marketfeed_client
import app.upstox_app.upstox_marketfeed.marketfeed_state as state
logger=get_logger()

def subscribe(instrument_keys,mode="ltpc"):
    try:
        get_marketfeed_client().subscribe(instrument_keys,mode)
        for k in instrument_keys: state.SUBSCRIPTIONS[k]=mode
        logger.info(f"Subscribed {instrument_keys} mode={mode}")
        return True
    except Exception:
        logger.exception("Subscribe failed")
        return False
