import upstox_client
from upstox_client.rest import ApiException

from app.logger import get_logger

# Import the centralized API client builder from your services directory
from app.services.upstox_client_service import (
    get_order_api,
)
from app.upstox_app.upstox_services.order_audit_service import save_order_audit

from app.services.telegram_service import (
    send_telegram_message,
)

logger = get_logger()

# ==========================================================
# PRIVATE HELPER FUNCTIONS
# ==========================================================


def _send_order_alert(
    status: str,
    instrument_token: str,
    transaction_type: str,
    quantity: int,
    details: str = "",
) -> None:
    """
    Helper function to cleanly forward order status alerts to Telegram.
    Wrapped in a generic try/except block to ensure tracking errors
    never corrupt or stall execution sequences.
    """
    emoji = "🟢" if "SUCCESS" in status else "🔴" if "FAILED" in status else "🚨"

    html_message = f"""
{emoji} <b>UPSTOX ORDER {status}</b>

<b>Instrument</b>
<code>{instrument_token}</code>

<b>Action</b>
{transaction_type} | {quantity} Qty
"""
    if details:
        html_message += f"\n{details}"

    try:
        send_telegram_message(html_message.strip())
    except Exception:
        # Safe! Your trade still goes through even if Telegram fails or rate limits.
        logger.exception("Telegram notification failed for regular order")


# ==========================================================
# HIGH-LEVEL CONVENIENCE: IMMEDIATE NSE OPTION MARKET ORDER
# ==========================================================


def place_immediate_nse_option_market_order(
    instrument_token: str,
    transaction_type: str = "BUY",
    quantity: int = 65,
    product: str = "I",
    tag: str = "OPTION_ALGO",
):
    """
    Executes an immediate Market Order specifically for an NSE Options instrument.

    Parameters
    ----------
    instrument_token : str
        The full Upstox instrument key (e.g., "NSE_FO|44556").
    transaction_type : str
        "BUY" or "SELL".
    quantity : int
        The total options lot quantity to trade (must be a multiple of lot size).
    product : str, optional
        "I" for Intraday (MIS) [Default], "D" for Delivery (NRML).
    tag : str, optional
        Custom tag tracking identifier for algorithmic matching context.
    """
    logger.info("=" * 80)
    logger.info("IMMEDIATE NSE OPTION MARKET ORDER TRIGGERS")
    logger.info("=" * 80)

    # Enforces explicit validation check rules for execution
    if not instrument_token or "NSE_" not in instrument_token:
        logger.warning(
            f"Instrument token {instrument_token} might not be a valid NSE contract framework."
        )

    # Re-route straight into place_regular_order with fixed market parameters
    return place_regular_order(
        instrument_token=instrument_token,
        transaction_type=transaction_type,
        quantity=quantity,
        product=product,
        order_type="MARKET",
        price=0.0,
        trigger_price=0.0,
        validity="DAY",
        disclosed_quantity=0,
        is_amo=False,
        tag=tag,
        api_version="2.0",
    )


# ==========================================================
# MARKET / LIMIT ORDER PLACEMENT
# ==========================================================


def place_regular_order(
    instrument_token: str,
    transaction_type: str = "BUY",
    quantity: int = 65,
    product: str = "I",
    order_type: str = "MARKET",
    price: float = 0.0,
    trigger_price: float = 0.0,
    validity: str = "DAY",
    disclosed_quantity: int = 0,
    is_amo: bool = False,
    tag: str = "ALGO",
    api_version: str = "2.0",
):
    """
    Places a standard regular order (Market, Limit, etc.) via Upstox API v2.
    Dynamically routes authentication via the shared MongoDB token context.
    """
    try:
        logger.info("=" * 80)
        logger.info("UPSTOX REGULAR ORDER REQUEST")
        logger.info("=" * 80)
        logger.info(f"Instrument      : {instrument_token}")
        logger.info(f"Transaction     : {transaction_type}")
        logger.info(f"Order Type      : {order_type}")
        logger.info(f"Product         : {product}")
        logger.info(f"Quantity        : {quantity}")
        logger.info(f"Price           : {price}")
        logger.info("=" * 80)

        # Automatically fetches/validates active session and returns OrderApi instance
        api = get_order_api()

        body = upstox_client.PlaceOrderRequest(
            quantity=quantity,
            product=product,
            validity=validity,
            price=price,
            tag=tag,
            instrument_token=instrument_token,
            order_type=order_type,
            transaction_type=transaction_type,
            disclosed_quantity=disclosed_quantity,
            trigger_price=trigger_price,
            is_amo=is_amo,
        )

        response = api.place_order(body=body, api_version=api_version)

        save_order_audit(
            event_type="PLACE_ORDER",
            request_payload={
                "instrument_token": instrument_token,
                "transaction_type": transaction_type,
                "quantity": quantity,
                "product": product,
                "order_type": order_type,
                "price": price,
                "trigger_price": trigger_price,
                "tag": tag,
            },
            response_payload=(
                response.to_dict() if hasattr(response, "to_dict") else str(response)
            ),
            status="SUCCESS",
        )

        logger.info("=" * 80)
        logger.info("UPSTOX REGULAR ORDER SUCCESS")
        logger.info("=" * 80)
        logger.info(response)
        logger.info("=" * 80)

        details_str = (
            f"<b>Product</b>: {product}\n"
            f"<b>Type</b>: {order_type}\n"
            f"<b>Response</b>: <pre>{response}</pre>"
        )

        # Triggers notification block safely using internal abstraction helper
        _send_order_alert(
            "SUCCESS", instrument_token, transaction_type, quantity, details_str
        )

        return {
            "success": True,
            "message": "Order processed successfully",
            "data": response,
        }

    except ApiException as ex:
        logger.error("=" * 80)
        logger.error("UPSTOX REGULAR ORDER API FAILURE")
        logger.error("=" * 80)
        logger.error(str(ex))
        logger.error("=" * 80)

        _send_order_alert(
            "FAILED",
            instrument_token,
            transaction_type,
            quantity,
            f"<b>API Reason</b>\n<pre>{str(ex)}</pre>",
        )
        save_order_audit(
            event_type="PLACE_ORDER",
            request_payload={
                "instrument_token": instrument_token,
                "transaction_type": transaction_type,
                "quantity": quantity,
            },
            status="FAILED",
            error=str(ex),
        )

        return {
            "success": False,
            "message": "Upstox API refused order request",
            "error": str(ex),
        }

    except Exception as ex:
        logger.exception("Unexpected structural failure processing order placement")

        _send_order_alert(
            "EXCEPTION",
            instrument_token,
            transaction_type,
            quantity,
            f"<b>App Exception</b>\n<pre>{str(ex)}</pre>",
        )

        return {
            "success": False,
            "message": "Unexpected wrapper runtime exception encountered",
            "error": str(ex),
        }


# ==========================================================
# STOP LOSS MARKET (SL-M) ORDER PLACEMENT
# ==========================================================


def place_sl_market_order(
    instrument_token: str,
    transaction_type: str,
    quantity: int,
    trigger_price: float,
    product: str = "I",
    validity: str = "DAY",
    disclosed_quantity: int = 0,
    is_amo: bool = False,
    tag: str = "ALGO",
    api_version: str = "2.0",
):
    """
    Places a Stop Loss-Market (SL-M) protection order.
    The order gets triggered when the market hits the specified trigger_price.
    """
    try:
        logger.info("=" * 80)
        logger.info("UPSTOX SL-M ORDER REQUEST")
        logger.info("=" * 80)
        logger.info(f"Instrument      : {instrument_token}")
        logger.info(f"Transaction     : {transaction_type}")
        logger.info("Order Type      : SL-M")
        logger.info(f"Trigger Price   : {trigger_price}")
        logger.info(f"Quantity        : {quantity}")
        logger.info("=" * 80)

        api = get_order_api()

        # Build payload specifically for SL-M (price is 0.0, trigger_price is active)
        body = upstox_client.PlaceOrderRequest(
            quantity=quantity,
            product=product,
            validity=validity,
            price=0.0,
            tag=tag,
            instrument_token=instrument_token,
            order_type="SL-M",
            transaction_type=transaction_type,
            disclosed_quantity=disclosed_quantity,
            trigger_price=trigger_price,
            is_amo=is_amo,
        )

        response = api.place_order(body=body, api_version=api_version)

        logger.info("=" * 80)
        logger.info("UPSTOX SL-M ORDER SUCCESS")
        logger.info("=" * 80)
        logger.info(response)
        logger.info("=" * 80)

        details_str = (
            f"<b>Product</b>: {product}\n"
            f"<b>Type</b>: SL-M\n"
            f"<b>Trigger Price</b>: {trigger_price}\n"
            f"<b>Response</b>: <pre>{response}</pre>"
        )

        _send_order_alert(
            "SUCCESS", instrument_token, transaction_type, quantity, details_str
        )

        return {
            "success": True,
            "message": "SL-M order processed successfully",
            "data": response,
        }

    except ApiException as ex:
        logger.error("=" * 80)
        logger.error("UPSTOX SL-M ORDER API FAILURE")
        logger.error("=" * 80)
        logger.error(str(ex))
        logger.error("=" * 80)

        _send_order_alert(
            "FAILED",
            instrument_token,
            transaction_type,
            quantity,
            f"<b>API Reason</b>\n<pre>{str(ex)}</pre>",
        )

        return {
            "success": False,
            "message": "Upstox API refused SL-M order request",
            "error": str(ex),
        }

    except Exception as ex:
        logger.exception(
            "Unexpected structural failure processing SL-M order placement"
        )

        _send_order_alert(
            "EXCEPTION",
            instrument_token,
            transaction_type,
            quantity,
            f"<b>App Exception</b>\n<pre>{str(ex)}</pre>",
        )

        return {
            "success": False,
            "message": "Unexpected wrapper runtime exception encountered for SL-M",
            "error": str(ex),
        }
