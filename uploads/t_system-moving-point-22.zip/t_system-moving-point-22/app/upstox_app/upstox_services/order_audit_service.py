from datetime import datetime

from app.core.upstox_db import UpstoxMongoDB
from app.logger import get_logger


logger = get_logger()


def save_order_audit(
    event_type: str,
    request_payload: dict,
    response_payload: dict = None,
    status: str = "SUCCESS",
    error: str = None,
):
    """
    Save order request/response into Upstox Orders Collection
    """

    try:

        collection = UpstoxMongoDB.get_orders_collection()

        order_id = None

        try:
            order_id = response_payload.get("_data", {}).get("_order_id")
        except Exception:
            pass

        document = {
            "event_type": event_type,
            "status": status,
            "order_id": order_id,
            "request": request_payload,
            "response": response_payload,
            "error": error,
            "created_at": datetime.utcnow(),
        }

        result = collection.insert_one(document)

        logger.info(f"Order audit saved : {result.inserted_id}")

        return str(result.inserted_id)

    except Exception:
        logger.exception("Failed saving order audit")
