from upstox_client.rest import ApiException

from app.logger import get_logger

# Clean absolute import pointing to your central upstox client helper
from app.services.upstox_client_service import (
    get_order_api,
)

from app.services.telegram_service import (
    send_telegram_message,
)
from app.upstox_app.upstox_services.order_audit_service import save_order_audit

logger = get_logger()

# ==========================================================
# EXIT ALL POSITIONS
# ==========================================================


# ==========================================================
# EXIT ALL POSITIONS
# ==========================================================


def exit_all_positions(
    segment: str | None = None,
    tag: str | None = None,
):
    """
    Exit all open positions.

    Parameters
    ----------
    segment : str | None
        Example:
            NSE_EQ
            NSE_FO
            MCX

    tag : str | None
        Exit only positions created with a tag.
    """

    request_payload = {
        "segment": segment,
        "tag": tag,
    }

    try:

        logger.info("=" * 80)
        logger.info("UPSTOX EXIT POSITIONS REQUEST")
        logger.info("=" * 80)
        logger.info(f"Segment : {segment}")
        logger.info(f"Tag     : {tag}")
        logger.info("=" * 80)

        api = get_order_api()

        params = {}

        if segment:
            params["segment"] = segment

        if tag:
            params["tag"] = tag

        response = api.exit_positions(**params)

        # ==================================================
        # SAVE SUCCESS AUDIT
        # ==================================================

        try:

            response_payload = (
                response.to_dict() if hasattr(response, "to_dict") else str(response)
            )

            save_order_audit(
                event_type="EXIT_POSITION",
                request_payload=request_payload,
                response_payload=response_payload,
                status="SUCCESS",
            )

        except Exception:
            logger.exception("Failed saving exit position audit record")

        logger.info("=" * 80)
        logger.info("UPSTOX EXIT POSITIONS SUCCESS")
        logger.info("=" * 80)
        logger.info(response)
        logger.info("=" * 80)

        try:

            send_telegram_message(f"""
🟢 <b>UPSTOX EXIT POSITIONS</b>

<b>Status</b>
SUCCESS

<b>Segment</b>
{segment or "ALL"}

<b>Tag</b>
{tag or "-"}

<b>Response</b>

<pre>{response}</pre>
""".strip())

        except Exception:

            logger.exception("Telegram notification failed")

        return {
            "success": True,
            "message": "Positions exited successfully",
            "data": response,
        }

    except ApiException as ex:

        logger.error("=" * 80)
        logger.error("UPSTOX EXIT POSITIONS FAILED")
        logger.error("=" * 80)
        logger.error(str(ex))
        logger.error("=" * 80)

        # ==================================================
        # SAVE FAILURE AUDIT
        # ==================================================

        try:

            save_order_audit(
                event_type="EXIT_POSITION",
                request_payload=request_payload,
                status="FAILED",
                error=str(ex),
            )

        except Exception:
            logger.exception("Failed saving failed exit position audit")

        try:

            send_telegram_message(f"""
🔴 <b>UPSTOX EXIT POSITIONS FAILED</b>

<b>Segment</b>
{segment or "ALL"}

<b>Tag</b>
{tag or "-"}

<b>Error</b>

<pre>{str(ex)}</pre>
""".strip())

        except Exception:

            logger.exception("Telegram notification failed")

        return {
            "success": False,
            "message": "Failed exiting positions",
            "error": str(ex),
        }

    except Exception as ex:

        logger.exception("Unexpected error while exiting positions")

        # ==================================================
        # SAVE EXCEPTION AUDIT
        # ==================================================

        try:

            save_order_audit(
                event_type="EXIT_POSITION",
                request_payload=request_payload,
                status="EXCEPTION",
                error=str(ex),
            )

        except Exception:
            logger.exception("Failed saving exception exit position audit")

        try:

            send_telegram_message(f"""
🚨 <b>UPSTOX EXIT POSITIONS EXCEPTION</b>

<b>Segment</b>
{segment or "ALL"}

<b>Tag</b>
{tag or "-"}

<b>Exception</b>

<pre>{str(ex)}</pre>
""".strip())

        except Exception:

            logger.exception("Telegram notification failed")

        return {
            "success": False,
            "message": "Unexpected error while exiting positions",
            "error": str(ex),
        }


# ==========================================================
# EXIT ALL POSITIONS - NSE_FO
# ==========================================================


def exit_all_fno_positions():

    return exit_all_positions(
        segment="NSE_FO",
    )


# ==========================================================
# EXIT ALL POSITIONS - NSE_EQ
# ==========================================================


def exit_all_equity_positions():

    return exit_all_positions(
        segment="NSE_EQ",
    )


# ==========================================================
# EXIT POSITIONS BY TAG
# ==========================================================


def exit_positions_by_tag(
    tag: str,
):

    return exit_all_positions(
        tag=tag,
    )
