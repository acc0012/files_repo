import upstox_client
from upstox_client.rest import ApiException

from app.logger import get_logger

# Correctly importing the API factory function from your services directory
from app.services.upstox_client_service import (
    get_order_api_v3,
)

from app.services.telegram_service import (
    send_telegram_message,
)

logger = get_logger()

# ==========================================================
# PRIVATE HELPER FUNCTIONS
# ==========================================================


def _send_alert(
    status: str, instrument_token: str, transaction_type: str, details: str = ""
) -> None:
    """Helper function to avoid repetitive telegram notification code blocks."""
    emoji = "🟢" if "SUCCESS" in status else "🔴" if "FAILED" in status else "🚨"

    html_message = f"""
{emoji} <b>UPSTOX GTT ORDER {status}</b>

<b>Instrument</b>
<code>{instrument_token}</code>

<b>Transaction</b>
{transaction_type}
"""
    if details:
        html_message += f"\n{details}"

    try:
        send_telegram_message(html_message.strip())
    except Exception:
        logger.exception("Telegram notification failed")


# ==========================================================
# CORE BASE GTT FUNCTION
# ==========================================================


def place_gtt_order(
    instrument_token: str,
    transaction_type: str,
    quantity: int,
    product: str,
    rules: list,
    order_type: str = "SINGLE",
):

    try:

        logger.info("=" * 80)
        logger.info("UPSTOX GTT ORDER REQUEST")
        logger.info("=" * 80)
        logger.info(f"Instrument      : {instrument_token}")
        logger.info(f"Transaction     : {transaction_type}")
        logger.info(f"Order Type      : {order_type}")
        logger.info(f"Product         : {product}")
        logger.info(f"Quantity        : {quantity}")
        logger.info(f"Rules Count     : {len(rules)}")
        logger.info("=" * 80)

        # Automatically fetches/validates active session and returns OrderApiV3 instance
        api = get_order_api_v3()

        body = upstox_client.GttPlaceOrderRequest(
            type=order_type,
            instrument_token=instrument_token,
            product=product,
            quantity=quantity,
            rules=rules,
            transaction_type=transaction_type,
        )

        response = api.place_gtt_order(body=body)

        logger.info("=" * 80)
        logger.info("UPSTOX GTT ORDER SUCCESS")
        logger.info("=" * 80)
        logger.info(response)
        logger.info("=" * 80)

        details_str = (
            f"<b>Type</b>\n{order_type}"
            f"\n\n<b>Product</b>\n{product}"
            f"\n\n<b>Quantity</b>\n{quantity}"
        )

        _send_alert(
            "SUCCESS",
            instrument_token,
            transaction_type,
            details_str,
        )

        return {
            "success": True,
            "message": "GTT order placed successfully",
            "data": response,
        }

    except ApiException as ex:

        logger.error("=" * 80)
        logger.error("UPSTOX GTT ORDER FAILED")
        logger.error("=" * 80)
        logger.error(str(ex))
        logger.error("=" * 80)

        _send_alert(
            "FAILED",
            instrument_token,
            transaction_type,
            f"<b>Reason</b>\n<pre>{str(ex)}</pre>",
        )

        return {
            "success": False,
            "message": "Failed placing GTT order",
            "error": str(ex),
        }

    except Exception as ex:

        logger.exception("Unexpected error while placing GTT order")

        _send_alert(
            "EXCEPTION",
            instrument_token,
            transaction_type,
            f"<b>Exception</b>\n<pre>{str(ex)}</pre>",
        )

        return {
            "success": False,
            "message": "Unexpected error while placing GTT order",
            "error": str(ex),
        }


# ==========================================================
# EXTENDED CONVENIENCE FUNCTIONS
# ==========================================================


def place_single_leg_gtt(
    instrument_token: str,
    transaction_type: str,
    quantity: int,
    product: str,
    trigger_price: float,
    trigger_type: str = "ABOVE",
):
    """
    Places a simple single leg GTT entry order.
    trigger_type can be 'ABOVE' or 'BELOW'
    """
    entry_rule = upstox_client.GttRule(
        strategy="ENTRY", trigger_type=trigger_type, trigger_price=trigger_price
    )

    return place_gtt_order(
        instrument_token=instrument_token,
        transaction_type=transaction_type,
        quantity=quantity,
        product=product,
        rules=[entry_rule],
        order_type="SINGLE",
    )


def place_multiple_leg_gtt(
    instrument_token: str,
    transaction_type: str,
    quantity: int,
    product: str,
    entry_price: float,
    target_price: float,
    stoploss_price: float,
    entry_trigger_type: str = "ABOVE",
):
    """
    Places a multi-leg GTT order containing Entry, Target, and Stop-loss configurations.
    """
    entry_rule = upstox_client.GttRule(
        strategy="ENTRY", trigger_type=entry_trigger_type, trigger_price=entry_price
    )
    target_rule = upstox_client.GttRule(
        strategy="TARGET", trigger_type="IMMEDIATE", trigger_price=target_price
    )
    stoploss_rule = upstox_client.GttRule(
        strategy="STOPLOSS", trigger_type="IMMEDIATE", trigger_price=stoploss_price
    )

    rules = [entry_rule, target_rule, stoploss_rule]

    return place_gtt_order(
        instrument_token=instrument_token,
        transaction_type=transaction_type,
        quantity=quantity,
        product=product,
        rules=rules,
        order_type="MULTIPLE",
    )


def place_trailing_stoploss_gtt(
    instrument_token: str,
    transaction_type: str,
    quantity: int,
    product: str,
    entry_price: float,
    target_price: float,
    stoploss_price: float,
    trailing_gap: float,
    entry_trigger_type: str = "ABOVE",
):
    """
    Places a multi-leg GTT order equipped with a Trailing Stop Loss mechanic.
    """
    entry_rule = upstox_client.GttRule(
        strategy="ENTRY", trigger_type=entry_trigger_type, trigger_price=entry_price
    )
    target_rule = upstox_client.GttRule(
        strategy="TARGET", trigger_type="IMMEDIATE", trigger_price=target_price
    )

    # Passing trailing_gap parameter directly inside the GttRule object setup
    stoploss_rule = upstox_client.GttRule(
        strategy="STOPLOSS",
        trigger_type="IMMEDIATE",
        trigger_price=stoploss_price,
        trailing_gap=trailing_gap,
    )

    rules = [entry_rule, target_rule, stoploss_rule]

    return place_gtt_order(
        instrument_token=instrument_token,
        transaction_type=transaction_type,
        quantity=quantity,
        product=product,
        rules=rules,
        order_type="MULTIPLE",
    )
