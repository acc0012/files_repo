import upstox_client
from upstox_client.rest import ApiException

from app.logger import get_logger

# Import the centralized API client builder
from app.services.upstox_client_service import (
    get_portfolio_api,
)

from app.services.telegram_service import (
    send_telegram_message,
)

logger = get_logger()

# ==========================================================
# PRIVATE HELPER FUNCTIONS
# ==========================================================


def _send_portfolio_alert(status: str, report_type: str, details: str = "") -> None:
    """
    Helper function to cleanly forward portfolio updates to Telegram.
    Wrapped in a try/except block to keep core calculations running smoothly.
    """
    emoji = "🟢" if "SUCCESS" in status else "🔴" if "FAILED" in status else "🚨"

    html_message = f"""
{emoji} <b>UPSTOX PORTFOLIO {status}</b>

<b>Report Type</b>
<code>{report_type}</code>
"""
    if details:
        html_message += f"\n{details}"

    try:
        send_telegram_message(html_message.strip())
    except Exception:
        # Safe! Your processing flow continues even if Telegram drops or rate limits
        logger.exception("Telegram notification failed for portfolio service")


# ==========================================================
# GET OPEN POSITIONS
# ==========================================================


def get_live_positions(api_version: str = "2.0"):
    """
    Fetches the user's current positions for the trading day.
    """
    try:
        logger.info("=" * 80)
        logger.info("UPSTOX GET POSITIONS REQUEST")
        logger.info("=" * 80)

        # Dynamically pulls fresh session context without hardcoded credentials
        api = get_portfolio_api()

        response = api.get_positions(api_version=api_version)

        logger.info("=" * 80)
        logger.info("UPSTOX GET POSITIONS SUCCESS")
        logger.info("=" * 80)
        logger.info(response)
        logger.info("=" * 80)

        # Parse data safely out to text
        details_str = f"<b>Response</b>: <pre>{response}</pre>"
        _send_portfolio_alert("SUCCESS", "GET POSITIONS", details_str)

        return {
            "success": True,
            "message": "Positions fetched successfully",
            "data": response,
        }

    except ApiException as ex:
        logger.error("=" * 80)
        logger.error("UPSTOX GET POSITIONS API FAILURE")
        logger.error("=" * 80)
        logger.error(str(ex))
        logger.error("=" * 80)

        _send_portfolio_alert(
            "FAILED", "GET POSITIONS", f"<b>API Reason</b>\n<pre>{str(ex)}</pre>"
        )

        return {
            "success": False,
            "message": "Upstox API refused positions request",
            "error": str(ex),
        }

    except Exception as ex:
        logger.exception("Unexpected error while fetching portfolio positions")

        _send_portfolio_alert(
            "EXCEPTION", "GET POSITIONS", f"<b>App Exception</b>\n<pre>{str(ex)}</pre>"
        )

        return {
            "success": False,
            "message": "Unexpected error encountered in positions retrieval",
            "error": str(ex),
        }


# ==========================================================
# GET LONG TERM HOLDINGS
# ==========================================================


def get_account_holdings(api_version: str = "2.0"):
    """
    Fetches the user's long-term equity holdings.
    """
    try:
        logger.info("=" * 80)
        logger.info("UPSTOX GET HOLDINGS REQUEST")
        logger.info("=" * 80)

        api = get_portfolio_api()

        response = api.get_holdings(api_version=api_version)

        logger.info("=" * 80)
        logger.info("UPSTOX GET HOLDINGS SUCCESS")
        logger.info("=" * 80)
        logger.info(response)
        logger.info("=" * 80)

        details_str = f"<b>Response</b>: <pre>{response}</pre>"
        _send_portfolio_alert("SUCCESS", "GET HOLDINGS", details_str)

        return {
            "success": True,
            "message": "Holdings fetched successfully",
            "data": response,
        }

    except ApiException as ex:
        logger.error("=" * 80)
        logger.error("UPSTOX GET HOLDINGS API FAILURE")
        logger.error("=" * 80)
        logger.error(str(ex))
        logger.error("=" * 80)

        _send_portfolio_alert(
            "FAILED", "GET HOLDINGS", f"<b>API Reason</b>\n<pre>{str(ex)}</pre>"
        )

        return {
            "success": False,
            "message": "Upstox API refused holdings request",
            "error": str(ex),
        }

    except Exception as ex:
        logger.exception("Unexpected error while fetching portfolio holdings")

        _send_portfolio_alert(
            "EXCEPTION", "GET HOLDINGS", f"<b>App Exception</b>\n<pre>{str(ex)}</pre>"
        )

        return {
            "success": False,
            "message": "Unexpected error encountered in holdings retrieval",
            "error": str(ex),
        }
