from app.services.upstox_service import INSTRUMENTS_CACHE

from app.logger import get_logger

logger = get_logger()


# ==========================================================
# GET INSTRUMENT USING STRIKE + OPTION TYPE
# ==========================================================


def get_instrument_by_strike(
    strike: int,
    option_type: str,
):
    """
    Example

    strike = 23400
    option_type = CE

    Returns the CE contract for strike 23400
    """

    try:

        strike_key = str(strike)

        option_type = option_type.lower()

        contract = INSTRUMENTS_CACHE.get(strike_key)

        if not contract:

            return {
                "success": False,
                "message": f"Strike {strike} not found",
            }

        instrument = contract.get(option_type)

        if not instrument:

            return {
                "success": False,
                "message": f"{option_type.upper()} contract not found",
            }

        return {
            "success": True,
            "strike": strike,
            "option_type": option_type.upper(),
            "data": instrument,
        }

    except Exception as ex:

        logger.exception("Failed fetching instrument by strike")

        return {
            "success": False,
            "message": str(ex),
        }


# ==========================================================
# GET INSTRUMENT USING INSTRUMENT TOKEN
# ==========================================================


def get_instrument_by_token(
    instrument_token: str,
):
    """
    Example

    NSE_FO|79809
    """

    try:

        for strike, contract in INSTRUMENTS_CACHE.items():

            ce = contract.get("ce")

            if ce and ce.get("instrument_key") == instrument_token:
                return {
                    "success": True,
                    "strike": strike,
                    "option_type": "CE",
                    "data": ce,
                }

            pe = contract.get("pe")

            if pe and pe.get("instrument_key") == instrument_token:
                return {
                    "success": True,
                    "strike": strike,
                    "option_type": "PE",
                    "data": pe,
                }

        return {
            "success": False,
            "message": f"Instrument token not found : {instrument_token}",
        }

    except Exception as ex:

        logger.exception("Failed fetching instrument by token")

        return {
            "success": False,
            "message": str(ex),
        }


# ==========================================================
# GET STRIKE LADDER
# ==========================================================


def get_strike_ladder(
    strike_price: int,
    option_type: str,
):
    """
    CE:
        current
        +50
        +100

    PE:
        current
        -50
        -100
    """

    try:

        option_type = option_type.upper()

        strikes = [strike_price]

        if option_type == "CE":

            strikes.extend(
                [
                    strike_price + 50,
                    strike_price + 100,
                ]
            )

        else:

            strikes.extend(
                [
                    strike_price - 50,
                    strike_price - 100,
                ]
            )

        ladder = []

        for strike in strikes:

            instrument = get_instrument_by_strike(
                strike=strike,
                option_type=option_type,
            )

            if instrument.get("success"):

                ladder.append(instrument["data"])

        return {
            "success": True,
            "option_type": option_type,
            "strikes": strikes,
            "count": len(ladder),
            "data": ladder,
        }

    except Exception as ex:

        logger.exception("Failed building strike ladder")

        return {
            "success": False,
            "message": str(ex),
        }
