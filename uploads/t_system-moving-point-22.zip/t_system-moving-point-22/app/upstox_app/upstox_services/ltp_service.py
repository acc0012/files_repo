import requests

from app.config import BASE_MARKET_URL
from app.logger import get_logger

logger = get_logger()

LTP_API_URL = f"{BASE_MARKET_URL}/dhan/ltp/"


def get_ltp(exchange_token: str):
    """
    Fetch LTP from market service.

    Example:

    exchange_token = 71472
    """

    try:

        payload = {"NSE_FNO": [int(exchange_token)]}

        response = requests.post(
            LTP_API_URL,
            json=payload,
            timeout=10,
        )

        response.raise_for_status()

        data = response.json()

        last_price = (
            data.get("data", {})
            .get("data", {})
            .get("NSE_FNO", {})
            .get(str(exchange_token), {})
            .get("last_price")
        )

        return {
            "success": True,
            "ltp": last_price,
            "response": data,
        }

    except Exception as ex:

        logger.exception(f"Failed fetching LTP : {exchange_token}")

        return {
            "success": False,
            "ltp": None,
            "error": str(ex),
        }


def get_bulk_ltp(exchange_tokens: list):

    try:

        payload = {"NSE_FNO": [int(token) for token in exchange_tokens]}

        response = requests.post(
            LTP_API_URL,
            json=payload,
            timeout=10,
        )

        response.raise_for_status()

        data = response.json()

        results = data.get("data", {}).get("data", {}).get("NSE_FNO", {})

        return {
            "success": True,
            "data": results,
        }

    except Exception as ex:

        logger.exception("Failed fetching bulk LTP")

        return {
            "success": False,
            "data": {},
            "error": str(ex),
        }
