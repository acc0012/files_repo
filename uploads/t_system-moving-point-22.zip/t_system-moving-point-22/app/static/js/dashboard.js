// ======================================================
// GLOBAL
// ======================================================

let refreshInterval = null;
let marketFeedSocket = null;
let initialFeedLogged = false;
let globalGroupedAlerts = {}; // Keeps track of currently loaded option groups

// ======================================================
// CONTRACT TICKER PARSER
// ======================================================
function parseStrikeTicker(ticker) {
  if (!ticker) return "Unknown Contract";

  // Remove segment prefix like "NSE:" if present
  const cleanTicker = ticker.replace(/^NSE:/, "").trim();

  // Regex: 1. Index Name (letters), 2. Year (2 digits), 3. Month (2 digits), 4. Day (2 digits), 5. Type (C/P), 6. Strike (digits)
  const match = cleanTicker.match(
    /^([A-Z]+)(\d{2})(\d{2})(\d{2})([CP])(\d+)$/i,
  );

  if (!match) {
    return ticker; // Fallback to original string if format is irregular
  }

  const [_, indexName, year, month, day, type, strikeValue] = match;

  // Optional: Convert month digits to a readable shorthand names
  const months = [
    "JAN",
    "FEB",
    "MAR",
    "APR",
    "MAY",
    "JUN",
    "JUL",
    "AUG",
    "SEP",
    "OCT",
    "NOV",
    "DEC",
  ];
  const monthStr = months[parseInt(month, 10) - 1] || month;

  const optionType = type.toUpperCase() === "C" ? "CALL (CE)" : "PUT (PE)";

  // Returns a cleanly formatted string for your table header
  return `${indexName} | Expiry: ${day}-${monthStr}-20${year} | ${optionType} | Strike: ${strikeValue}`;
}

function getSelectedDate() {
  return document.getElementById("selectedDate").value;
}

function isTodaySelected() {
  const today = new Date().toISOString().split("T")[0];

  return getSelectedDate() === today;
}

// ======================================================
// DIAGNOSTIC METADATA OVERLAY MODAL HANDLER
// ======================================================

function showMetaPayload(title, encodedPayload) {
  try {
    const rawPayload = decodeURIComponent(encodedPayload);

    let parsedObj;

    try {
      parsedObj = JSON.parse(rawPayload);
    } catch {
      parsedObj = rawPayload;
    }

    document.getElementById("metaModalTitle").innerText = title;

    document.getElementById("metaModalPayload").innerText =
      typeof parsedObj === "object"
        ? JSON.stringify(parsedObj, null, 2)
        : parsedObj;

    const elementsModal = new bootstrap.Modal(
      document.getElementById("metaInfoModal"),
    );

    elementsModal.show();
  } catch (e) {
    console.error("Meta Modal Error", e);
  }
}

// ======================================================
// LOAD DASHBOARD
// ======================================================

async function loadDashboard() {
  await loadSummary();

  await loadOpeningRange();

  await loadIndexAlerts();

  await loadOptionAlerts();

  await loadUpstoxStatus();

  await loadMonitorStatus();

  document.getElementById("lastRefreshTime").innerText =
    new Date().toLocaleTimeString();
}

// ======================================================
// UPSTOX STATUS
// ======================================================

async function loadUpstoxStatus() {
  try {
    const response = await fetch("/api/upstox/status");

    const result = await response.json();

    if (!result.success) {
      return;
    }

    const data = result.data;

    const availableMargin = document.getElementById("availableMargin");

    const statusElement = document.getElementById("upstoxTokenStatus");

    if (availableMargin) {
      availableMargin.innerText = `₹ ${formatAmount(data.balance || 0)}`;
    }

    if (statusElement) {
      statusElement.innerText = data.token_valid ? "ACTIVE" : "EXPIRED";

      statusElement.className = data.token_valid
        ? "text-success fw-bold"
        : "text-danger fw-bold";
    }
  } catch (error) {
    console.error("Upstox Status Load Error", error);
  }
}

// ======================================================
// MONITOR STATUS
// ======================================================

async function loadMonitorStatus() {
  try {
    const response = await fetch("/api/upstox/monitor-status");

    const result = await response.json();

    if (!result.success) {
      return;
    }

    const data = result.data;

    const statusElement = document.getElementById("monitorStatus");

    const lastRunElement = document.getElementById("monitorLastRun");

    const lastSuccessElement = document.getElementById("monitorLastSuccess");

    const nextRunElement = document.getElementById("monitorNextRun");

    const intervalElement = document.getElementById("monitorInterval");

    if (statusElement) {
      statusElement.innerText = data.running ? "RUNNING" : "STOPPED";

      statusElement.className = data.running
        ? "fw-bold text-success"
        : "fw-bold text-danger";
    }

    if (lastRunElement) {
      lastRunElement.innerText = formatDateTime(data.last_run_at);
    }

    if (lastSuccessElement) {
      lastSuccessElement.innerText = formatDateTime(data.last_success_at);
    }

    if (nextRunElement) {
      nextRunElement.innerText = formatDateTime(data.next_run_at);
    }

    if (intervalElement) {
      intervalElement.innerText = `${data.interval_minutes} Minutes`;
    }
  } catch (error) {
    console.error("Monitor Status Load Error", error);
  }
}

// ======================================================
// SUMMARY
// ======================================================

async function loadSummary() {
  try {
    const date = getSelectedDate();

    const response = await fetch(`/api/dashboard/summary?date=${date}`);

    const result = await response.json();

    if (!result.success) {
      return;
    }

    const data = result.data;

    document.getElementById("openingRangeCount").innerText =
      data.opening_range_count;

    document.getElementById("indexSignalCount").innerText =
      data.index_signal_count;

    document.getElementById("optionSignalCount").innerText =
      data.option_signal_count;

    document.getElementById("totalAlertCount").innerText = data.total_alerts;
  } catch (error) {
    console.error("Summary Load Error", error);
  }
}

// ======================================================
// OPENING RANGE
// ======================================================

async function loadOpeningRange() {
  try {
    const date = getSelectedDate();

    const response = await fetch(`/api/dashboard/opening-range?date=${date}`);

    const result = await response.json();

    const tbody = document.getElementById("openingRangeTableBody");

    tbody.innerHTML = "";

    if (!result.success || result.data.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="18" class="text-center text-muted py-3">
            No Opening Range Alerts Found
          </td>
        </tr>
      `;
      return;
    }

    result.data.forEach((row, index) => {
      const or = row.opening_range || row;

      const encodedRaw = encodeURIComponent(
        JSON.stringify(row.raw_payload || {}),
      );

      tbody.innerHTML += `
        <tr class="text-nowrap">

          <td>${index + 1}</td>

          <td class="fw-bold text-dark">
            ${row.symbol ?? row.SYMBOL ?? ""}
          </td>

          <td>${or.HIGH ?? or.high ?? "-"}</td>

          <td>${or.LOW ?? or.low ?? "-"}</td>

          <td class="bg-light fw-semibold">
            ${or.AVG ?? or.avg ?? "-"}
          </td>

          <td>
            ${or.SUB_RESISTANCE ?? or.sub_resistance ?? "-"}
          </td>

          <td>
            ${or.SUB_SUPPORT ?? or.sub_support ?? "-"}
          </td>

          <td>
            ${or.RESISTANCE2 ?? or.resistance2 ?? "-"}
          </td>

          <td>
            ${or.SUPPORT2 ?? or.support2 ?? "-"}
          </td>

          <td class="text-primary fw-semibold">
            ${or.RESISTANCE3 ?? or.resistance3 ?? "-"}
          </td>

          <td class="text-danger fw-semibold">
            ${or.SUPPORT3 ?? or.support3 ?? "-"}
          </td>

          <td>
            <span class="badge bg-light text-dark border font-monospace-sm">
              ${or.RESISTANCE3_CE_STRIKE ?? or.resistance3_ce_strike ?? "-"}
            </span>
          </td>

          <td>
            <span class="badge bg-light text-dark border font-monospace-sm">
              ${or.RESISTANCE3_PE_STRIKE ?? or.resistance3_pe_strike ?? "-"}
            </span>
          </td>

          <td>
            <span class="badge bg-light text-dark border font-monospace-sm">
              ${or.SUPPORT3_CE_STRIKE ?? or.support3_ce_strike ?? "-"}
            </span>
          </td>

          <td>
            <span class="badge bg-light text-dark border font-monospace-sm">
              ${or.SUPPORT3_PE_STRIKE ?? or.support3_pe_strike ?? "-"}
            </span>
          </td>

          <td>
            <button
              class="btn btn-sm btn-outline-primary"
              onclick="showMetaPayload(
                'Opening Range Raw Alert',
                '${encodedRaw}'
              )"
            >
              View
            </button>
          </td>

          <td class="text-muted font-monospace-sm">
            ${formatDateTime(row.created_at)}
          </td>

        </tr>
      `;
    });
  } catch (error) {
    console.error("Opening Range Load Error", error);
  }
}

// ======================================================
// INDEX ALERTS
// ======================================================

async function loadIndexAlerts() {
  try {
    const date = getSelectedDate();

    const response = await fetch(`/api/dashboard/index-alerts?date=${date}`);

    const result = await response.json();

    const tbody = document.getElementById("indexAlertsTableBody");

    tbody.innerHTML = "";

    if (!result.success || result.data.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="26" class="text-center text-muted py-3">
            No Index Alerts Found
          </td>
        </tr>
      `;
      return;
    }

    result.data.forEach((row, index) => {
      const or = row.opening_range || {};

      const emaInfo = row.ema_level_info || {};

      const levelStatus = row.level_status || {};

      const encodedMeta = encodeURIComponent(
        JSON.stringify(row.ema_level_info || {}),
      );

      const encodedRaw = encodeURIComponent(
        JSON.stringify(row.raw_payload || {}),
      );

      tbody.innerHTML += `
        <tr class="text-nowrap">

          <td>${index + 1}</td>

          <td class="fw-bold text-dark">
            ${row.symbol ?? ""}
          </td>

          <td class="font-monospace-sm">
            ${row.time ?? ""}
          </td>

          <td>
            ${getAlertTypeBadge(row)}
          </td>

          <td class="signal-message">
            ${getSignalMessage(row)}
          </td>

          <td>
            <small
              class="text-uppercase fw-bold text-secondary text-xs border rounded p-1 bg-light"
            >
              ${row.alert_category ?? ""}
            </small>
          </td>

          <td class="fw-bold text-primary">
            ${row.price ?? ""}
          </td>

          <td class="fw-bold text-dark">
            ${row.live_main_ltp ?? "-"}
          </td>

          <td>
            <span
              class="badge bg-light text-dark border font-monospace-sm"
            >
              ${row.live_ce_strike ?? "-"}
            </span>
          </td>

          <td>
            <span
              class="badge bg-light text-dark border font-monospace-sm"
            >
              ${row.live_pe_strike ?? "-"}
            </span>
          </td>

          <td>${row.ema9 ?? ""}</td>

          <td>${row.ema21 ?? ""}</td>

          <td class="fw-bold">
            ${row.diff ?? ""}
          </td>

          <td>${or.HIGH ?? or.high ?? "-"}</td>

          <td>${or.LOW ?? or.low ?? "-"}</td>

          <td>${or.AVG ?? or.avg ?? "-"}</td>

          <td>
            ${or.RESISTANCE3 ?? or.resistance3 ?? "-"}
          </td>

          <td>
            ${or.SUPPORT3 ?? or.support3 ?? "-"}
          </td>

          <td>
            ${emaInfo.NEAREST_OR_LEVEL || "-"}
          </td>

          <td>
            ${emaInfo.NEAREST_DISTANCE || "-"}
          </td>

          <td>
            ${levelStatus.R3_TOUCHED || "-"}
          </td>

          <td>
            ${levelStatus.R3_TOUCH_TIME || "-"}
          </td>

          <td>
            ${levelStatus.S3_TOUCHED || "-"}
          </td>

          <td>
            ${levelStatus.S3_TOUCH_TIME || "-"}
          </td>

          <td>
            <button
              class="btn btn-sm btn-outline-dark font-monospace-sm"
              onclick="showMetaPayload(
                '${row.symbol ?? "INDEX"} EMA Metadata',
                '${encodedMeta}'
              )"
            >
              Open Info (${Object.keys(row.ema_level_info || {}).length})
            </button>
          </td>

          <td>
            <button
              class="btn btn-sm btn-outline-primary"
              onclick="showMetaPayload(
                '${row.symbol ?? "INDEX"} Raw Alert',
                '${encodedRaw}'
              )"
            >
              Raw Alert
            </button>
          </td>

        </tr>
      `;
    });
  } catch (error) {
    console.error("Index Alerts Load Error", error);
  }
}

function showEmaHistory(encodedHistory) {
  try {
    const history = decodeURIComponent(encodedHistory);

    // Split by either pipe "|" OR arrow "→" safely
    const rows = history
      .split(/\||→/)
      .map((item) => item.trim())
      .filter(Boolean);

    document.getElementById("metaModalTitle").innerText = "EMA Cross History";

    // Build the grid wrapper
    let gridHtml = '<div class="row g-2">'; // Kept a tight gutter spacing

    gridHtml += rows
      .map((item) => {
        // Clean up the item match to handle flexible spaces/formatting
        const match = item.match(
          /(\d{2}:\d{2}:\d{2}):(BULL|BEAR):([0-9.]+):([0-9.]+)/i,
        );

        if (!match) {
          return `
            <div class="col-6 col-sm-4 col-md-3 col-lg-2.5">
              <div class="card h-100 border-0 bg-light">
                <div class="card-body p-2 text-center font-monospace-sm text-muted small">
                  ${item}
                </div>
              </div>
            </div>
          `;
        }

        const [, time, signal, ema9, ema21] = match;
        const isBull = signal.toUpperCase() === "BULL";

        // Card frame styling variables
        const themeClass = isBull ? "border-success bg-success-subtle-light" : "border-danger bg-danger-subtle-light";
        const badgeClass = isBull ? "bg-success" : "bg-danger";

        // Background color blocks for indicators
        const ema9Bg = "background-color: rgba(25, 135, 84, 0.12); color: #146c43;"; // Stable Green Tint
        const ema21Bg = "background-color: rgba(108, 117, 125, 0.12); color: #495057;"; // Neutral Grey Tint

        return `
          <div class="col-6 col-sm-4 col-md-3" style="flex: 0 0 auto; width: 20%; min-width: 145px;">
            <div class="card h-100 shadow-sm border-start border-4 ${themeClass}" style="border: 1px solid rgba(0,0,0,0.06); border-left-width: 4px !important;">
              <div class="card-body p-2 d-flex flex-column justify-content-between">
                
                <div class="d-flex justify-content-between align-items-center mb-2">
                  <strong class="text-dark font-monospace" style="font-size: 0.75rem;">${time}</strong>
                  <span class="badge ${badgeClass} text-white font-monospace fw-bold" style="font-size: 0.65rem; padding: 2px 4px;">
                    ${signal.toUpperCase()}
                  </span>
                </div>
                
                <div class="d-flex gap-1 font-monospace text-center">
                  
                  <div class="flex-grow-1 rounded p-1" style="${ema9Bg}">
                    <div style="font-size: 0.55rem; font-weight: 700; opacity: 0.85;">EMA 9</div>
                    <div class="fw-bold" style="font-size: 0.75rem; mt-0.5">${ema9}</div>
                  </div>
                  
                  <div class="flex-grow-1 rounded p-1" style="${ema21Bg}">
                    <div style="font-size: 0.55rem; font-weight: 700; opacity: 0.85;">EMA 21</div>
                    <div class="fw-bold" style="font-size: 0.75rem; mt-0.5">${ema21}</div>
                  </div>
                  
                </div>

              </div>
            </div>
          </div>
        `;
      })
      .join("");

    gridHtml += '</div>';

    document.getElementById("metaModalPayload").innerHTML = gridHtml;

    const modal = new bootstrap.Modal(document.getElementById("metaInfoModal"));
    modal.show();
  } catch (error) {
    console.error("EMA History Modal Error", error);
  }
}

// ======================================================
// OPTION ALERTS
// ======================================================
async function loadOptionAlerts() {
  try {
    const date = getSelectedDate();
    const response = await fetch(`/api/dashboard/option-alerts?date=${date}`);
    const result = await response.json();

    const container = document.getElementById("optionAlertsContainer");
    container.innerHTML = "";

    if (!result.success || result.data.length === 0) {
      container.innerHTML = `
        <div class="text-center text-muted py-3">
          No Option Alerts Found
        </div>
      `;
      return;
    }

    // 1. Group alerts by Ticker
    const groupedAlerts = {};
    result.data.forEach((row, index) => {
      const ticker = row.ticker ?? "Other Strikes";
      if (!groupedAlerts[ticker]) {
        groupedAlerts[ticker] = [];
      }
      groupedAlerts[ticker].push(row);
    });

    // Custom Token Parser for NSE Option Contract Formats
    const parseTickerHeader = (tickerStr) => {
      if (!tickerStr || tickerStr === "Other Strikes") return tickerStr;

      // Remove trading platform prefixes like "NSE:" safely
      const cleanStr = tickerStr.replace(/^NSE:/i, "").trim();

      // Matcher handling standard monthly formats (e.g., NIFTY260630C23850)
      // Groups: 1:Index, 2:Year(2-deg), 3:Month(2-deg), 4:Day(2-deg), 5:Type(C/P), 6:Strike
      const monthlyRegex = /^([A-Z]+)(\d{2})(\d{2})(\d{2})([CP])(\d+)$/i;

      // Matcher handling quick weekly contract formatting schemas if present
      // Groups: 1:Index, 2:Year(2-deg), 3:Month Token(Shorthand/Char), 4:Day(2-deg), 5:Type(C/P), 6:Strike
      const weeklyRegex = /^([A-Z]+)(\d{2})([A-Z0-9]{2,3})(\d{2})([CP])(\d+)$/i;

      let match = cleanStr.match(monthlyRegex);

      if (match) {
        const [_, indexName, year, month, day, type, strikeValue] = match;
        const optionType = type.toUpperCase() === "C" ? "CE" : "PE";

        const monthNames = [
          "JAN",
          "FEB",
          "MAR",
          "APR",
          "MAY",
          "JUN",
          "JUL",
          "AUG",
          "SEP",
          "OCT",
          "NOV",
          "DEC",
        ];
        const formattedMonth = monthNames[parseInt(month, 10) - 1] || month;

        return `${indexName} 20${year} ${formattedMonth} ${day} [${optionType}] Strike: ${strikeValue}`;
      }

      // Fallback matching logic for explicit weekly custom string tags
      match = cleanStr.match(weeklyRegex);
      if (match) {
        const [_, indexName, year, monthToken, day, type, strikeValue] = match;
        const optionType = type.toUpperCase() === "C" ? "CE" : "PE";
        return `${indexName} 20${year} ${monthToken.toUpperCase()} ${day} [${optionType}] Strike: ${strikeValue}`;
      }

      return tickerStr; // Returns baseline value safely if custom formats don't align
    };

    // 2. Generate separate component tables for each contract group
    Object.keys(groupedAlerts).forEach((ticker) => {
      const alerts = groupedAlerts[ticker];
      const parsedTitle = parseTickerHeader(ticker);

      let tableHtml = `
        <div class="strike-table-wrapper shadow-sm mb-4">
          <div class="strike-table-header d-flex justify-content-between align-items-center p-3 rounded-top bg-light border-bottom">
            <h5 class="strike-title-text fw-bold text-dark mb-0">
              🎯 <span class="text-primary font-monospace">${parsedTitle}</span> 
              ${ticker !== parsedTitle ? `<small class="text-muted font-monospace-sm ms-2">(${ticker})</small>` : ""}
            </h5>
            <span class="badge bg-dark rounded-pill px-3 py-2">${alerts.length} Alerts</span>
          </div>
          <div class="table-responsive">
            <table class="table table-bordered table-hover align-middle mb-0">
              <thead>
                <tr class="table-dark text-nowrap">
                  <th>#</th>
<th>Time</th>
                  <th>Category</th>
                  <th>Type</th>
                  <th>Recommendation</th>
                  <th>Price</th>
                  <th>Live Main LTP</th>
                  <th>Live CE Strike</th>
                  <th>Live PE Strike</th>
                  <th>EMA9</th>
                  <th>EMA21</th>
                  <th>Diff</th>
                  <th>High</th>
                  <th>Low</th>
                  <th>Avg</th>
                  <th>R3 Level</th>
                  <th>S3 Level</th>
                  <th>EMA Info Meta</th>
                  <th>EMA Cross History</th>
<th>Raw Alert</th>
                </tr>
              </thead>
              <tbody>
      `;

      // Render structural table content loops
      alerts.forEach((row, index) => {
        const encodedRaw = encodeURIComponent(
          JSON.stringify(row.raw_payload || {}),
        );

        const crossHistory = Array.isArray(row.ema_cross_history)
          ? row.ema_cross_history.join(" → ")
          : row.ema_cross_history || "-";

        const encodedMeta = encodeURIComponent(
          JSON.stringify(row.ema_level_info || {}),
        );
        const or = row.option_opening_range || row.opening_range || {};

        tableHtml += `
          <tr class="text-nowrap">
          <td>${index + 1}</td>
            <td class="font-monospace-sm">${row.time ?? ""}</td>
            <td>${getCategoryBadge(row.alert_category)}</td>
            <td>${getAlertTypeBadge(row)}</td>
            <td class="signal-message fw-semibold">${getSignalMessage(row)}</td>
            <td class="fw-bold text-primary">${row.price ?? ""}</td>
            <td class="fw-bold text-dark">${row.live_main_ltp ?? "-"}</td>
            <td><span class="badge bg-light text-dark border font-monospace-sm">${row.live_ce_strike ?? "-"}</span></td>
            <td><span class="badge bg-light text-dark border font-monospace-sm">${row.live_pe_strike ?? "-"}</span></td>
            <td>${row.ema9 ?? ""}</td>
            <td>${row.ema21 ?? ""}</td>
            <td class="fw-bold">${row.diff ?? ""}</td>
            <td>${row.high ?? or.HIGH ?? or.high ?? "-"}</td>
            <td>${row.low ?? or.LOW ?? or.low ?? "-"}</td>
            <td>${row.avg ?? or.AVG ?? or.avg ?? "-"}</td>
            <td class="fw-semibold text-success">${row.resistance3 ?? or.RESISTANCE3 ?? or.resistance3 ?? "-"}</td>
            <td class="fw-semibold text-danger">${row.support3 ?? or.SUPPORT3 ?? or.support3 ?? "-"}</td>
            <td>
              <button class="btn btn-sm btn-outline-dark font-monospace-sm" onclick="showMetaPayload('${row.alert_category || "OPTION"} Info Matrix', '${encodedMeta}')">
                Open Info (${Object.keys(row.ema_level_info || {}).length})
              </button>
            </td>
            <td>
  <button
    class="btn btn-sm btn-outline-info"
    onclick="showEmaHistory(
      '${encodeURIComponent(crossHistory)}'
    )"
  >
    View History
  </button>
</td>
<td>
  <button
    class="btn btn-sm btn-outline-primary"
    onclick="showMetaPayload(
      '${row.ticker || "OPTION"} Raw Alert',
      '${encodedRaw}'
    )"
  >
    Raw Alert
  </button>
</td>
          </tr>
        `;
      });

      tableHtml += `
              </tbody>
            </table>
          </div>
        </div>
      `;

      container.innerHTML += tableHtml;
    });
  } catch (error) {
    console.error("Option Alerts Load Error", error);
  }
}

// ======================================================
// ALERT TYPE BADGES
// ======================================================

function getAlertTypeBadge(row) {
  let direction = row.signal_direction;
  console.log(row)
  if (!direction) {
    switch (row.type) {
      case "BUY_CE":
      case "BUY_PE":
        direction = "BUY";
        break;

      case "SELL_CE":
      case "SELL_PE":
        direction = "SELL";
        break;

      default:
        direction = "";
    }
  }

  const title =
    row.signal_title ||
    {
      BUY_CE: "MARKET RISING",
      SELL_CE: "EXIT CALL POSITION",
      BUY_PE: "MARKET FALLING",
      SELL_PE: "EXIT PUT POSITION",
    }[row.type] ||
    row.type;

  let strike = "";

  // ✅ NEW DATA (correct format)
  if (row.suggested_strike_50 || row.suggested_strike_100) {
    strike = `ATM: ${row.suggested_strike_50 || "-"} | SAFE: ${row.suggested_strike_100 || "-"}`;
  }

  // ✅ OLD DATA (object handling fix)
  else if (
    typeof row.recommended_strike === "object" &&
    row.recommended_strike !== null
  ) {
    strike = `ATM: ${row.recommended_strike.STRIKE_50 || "-"} | SAFE: ${row.recommended_strike.STRIKE_100 || "-"}`;
  }

  // ✅ FALLBACK
  else {
    strike =
      row.recommended_strike ||
      (row.type === "BUY_CE" || row.type === "SELL_CE"
        ? `${row.live_ce_strike ?? ""} CE`
        : `${row.live_pe_strike ?? ""} PE`);
  }

  const cssClass = direction === "BUY" ? "buy-signal" : "sell-signal";

  return `
    <div class="alert-type ${cssClass}">
      <div>${title}</div>
      <small>${strike}</small>
    </div>
  `;
}

function getSignalMessage(row) {
  if (row.signal_message) {
    let msg = row.signal_message;

    // Fix legacy strike object text safely
    if (msg.includes("STRIKE_50")) {
      try {
        const match = msg.match(/\{.*\}/);
        if (match) {
          const obj = JSON.parse(match[0]);
          msg = msg.replace(
            match[0],
            `ATM: ${obj.STRIKE_50 || "-"} | Safe: ${obj.STRIKE_100 || "-"}`
          );
        }
      } catch (error) {
        console.warn("Failed parsing strike recommendation payload", error);
      }
    }

    // FIX: If the message contains blank ATM/Safe markers but a valid recommended_strike exists
    if ((msg.includes("ATM: -") || msg.includes("Safe: -")) && row.recommended_strike) {
      // Extract everything before "ATM:" to keep the original momentum description
      const baseMessage = msg.split("ATM:")[0].trim();
      msg = `${baseMessage}<br><span class="fw-bold text-dark">Suggested Strike: ${row.recommended_strike}</span>`;
    }

    return msg.replaceAll(" | ", "<br>");
  }

  // Baseline Fallbacks
  switch (row.type) {
    case "BUY_CE":
      return `Market is showing bullish momentum. Take CALL Option ${row.live_ce_strike ?? ""} CE`;
    case "SELL_CE":
      return `Bullish momentum is weakening. Exit CALL Option ${row.live_ce_strike ?? ""} CE`;
    case "BUY_PE":
      return `Market is showing bearish momentum. Take PUT Option ${row.live_pe_strike ?? ""} PE`;
    case "SELL_PE":
      return `Bearish momentum is weakening. Exit PUT Option ${row.live_pe_strike ?? ""} PE`;
    default:
      return "-";
  }
}

// ======================================================
// CATEGORY BADGES
// ======================================================

function getCategoryBadge(category) {
  if (!category) {
    return "";
  }

  let cssClass = "";

  switch (category) {
    case "R3_CE_OPTION":
      cssClass = "r3-ce";
      break;

    case "R3_PE_OPTION":
      cssClass = "r3-pe";
      break;

    case "S3_CE_OPTION":
      cssClass = "s3-ce";
      break;

    case "S3_PE_OPTION":
      cssClass = "s3-pe";
      break;

    default:
      cssClass = "bg-secondary text-white";
  }

  return `
    <span class="category-badge ${cssClass}">
      ${category}
    </span>
  `;
}

// ======================================================
// DATETIME FORMATTER
// ======================================================

function formatDateTime(dateValue) {
  if (!dateValue) {
    return "";
  }

  try {
    const dt = new Date(dateValue);

    return dt.toLocaleString();
  } catch {
    return dateValue;
  }
}

// ======================================================
// CURRENCY FORMAT
// ======================================================

function formatAmount(value) {
  try {
    return Number(value || 0).toLocaleString("en-IN", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  } catch {
    return value;
  }
}

// ======================================================
// AUTO REFRESH
// ======================================================

function startAutoRefresh() {
  if (refreshInterval) {
    clearInterval(refreshInterval);
  }

  refreshInterval = setInterval(async () => {
    if (!isTodaySelected()) {
      return;
    }

    // console.log("Dashboard Auto Refresh : ", new Date().toLocaleTimeString());

    await loadDashboard();
  }, 5000);
}

// ======================================================
// MARKET FEED WEBSOCKET
// ======================================================

function connectMarketFeedSocket() {
  try {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";

    const wsUrl = `${protocol}//${window.location.host}/ws/feed`;

    // console.log("Connecting Market Feed Socket :", wsUrl);

    marketFeedSocket = new WebSocket(wsUrl);

    marketFeedSocket.onopen = () => {
      console.log("Market Feed Socket Connected");

      const statusEl = document.getElementById("feedStatus");

      if (statusEl) {
        statusEl.innerText = "CONNECTED";

        statusEl.className = "badge bg-success";
      }
    };

    marketFeedSocket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);

        if (data.type === "heartbeat") {
          return;
        }

        if (!initialFeedLogged) {
          console.log("Initial Market Feed Payload:", data);

          initialFeedLogged = true;
        }

        updateMarketFeedUI(data);
      } catch (e) {
        console.error("Feed Parse Error", e);
      }
    };

    marketFeedSocket.onclose = () => {
      console.warn("Market Feed Socket Disconnected");

      const statusEl = document.getElementById("feedStatus");

      if (statusEl) {
        statusEl.innerText = "DISCONNECTED";

        statusEl.className = "badge bg-danger";
      }

      setTimeout(connectMarketFeedSocket, 5000);
    };

    marketFeedSocket.onerror = (error) => {
      console.error("Market Feed Socket Error", error);
    };
  } catch (error) {
    console.error("Failed Connecting Feed Socket", error);
  }
}

// ======================================================
// LIVE MARKET FEED UPDATE
// ======================================================

function updateMarketFeedUI(data) {
  // console.log("LIVE FEED :", data);

  const statusEl = document.getElementById("feedStatus");

  const securityIdEl = document.getElementById("feedSecurityId");

  const ltpEl = document.getElementById("feedLtp");

  const highEl = document.getElementById("feedHigh");

  const lowEl = document.getElementById("feedLow");

  const volumeEl = document.getElementById("feedVolume");

  if (statusEl) {
    statusEl.innerText = "CONNECTED";
    statusEl.className = "badge bg-success";
  }

  if (securityIdEl) {
    securityIdEl.innerText = data.security_id ?? "-";
  }

  if (ltpEl) {
    ltpEl.innerText = data.LTP ?? "-";
  }

  if (highEl) {
    highEl.innerText = data.high ?? "-";
  }

  if (lowEl) {
    lowEl.innerText = data.low ?? "-";
  }

  if (volumeEl) {
    volumeEl.innerText = data.volume ?? "-";
  }
}

document.addEventListener("DOMContentLoaded", async function () {
  let today = new Date().toISOString().split("T")[0];

  document.getElementById("selectedDate").value = today;

  connectMarketFeedSocket();

  await loadDashboard();

  startAutoRefresh();

  document
    .getElementById("selectedDate")
    .addEventListener("change", async function () {
      await loadDashboard();
    });
});
