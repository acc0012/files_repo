import requests
import json


def test_ltp_api():

    url = "https://marketfeed101.up.railway.app/dhan/ltp/"

    payload = {
        "NSE_FNO": [
            71472,
            71473
        ]
    }

    try:

        response = requests.post(
            url,
            json=payload,
            timeout=30,
        )

        print(f"Status Code: {response.status_code}")
        print("\nResponse:")

        data = response.json()

        print(
            json.dumps(
                data,
                indent=4
            )
        )

        return data

    except Exception as ex:

        print(f"Error: {ex}")


if __name__ == "__main__":
    test_ltp_api()