import time
import threading

from datetime import datetime
from zoneinfo import ZoneInfo

import upstox_client

from config.settings import Settings
from core.logger import get_logger
from services.preload_service import PreloadService
from services.candle_builder import CandleBuilder
from services.crossover_engine import CrossoverEngine

logger = get_logger(__name__)


class UpstoxStreamService:

    def __init__(self, access_token: str):

        self.access_token = access_token
        self.streamer = None
        self.running = False
        self.stats_thread = None

    def create_streamer(self):
        """
        Create Upstox streamer.
        """

        try:

            configuration = upstox_client.Configuration()
            configuration.access_token = self.access_token

            self.streamer = upstox_client.MarketDataStreamerV3(
                upstox_client.ApiClient(configuration)
            )

            logger.info("Upstox streamer initialized.")

        except Exception as ex:

            logger.exception(f"Streamer initialization failed: {ex}")
            raise

    def subscribe_all_instruments(self):
        """
        Subscribe all strike instruments.
        """

        try:

            instrument_keys = PreloadService.get_instrument_keys()

            if not instrument_keys:

                logger.warning("No instrument keys available.")
                return

            logger.info(f"Subscribing " f"{len(instrument_keys)} " f"instruments.")

            self.streamer.subscribe(instrument_keys, Settings.UPSTOX_FEED_MODE)

            logger.info(
                f"Successfully subscribed " f"{len(instrument_keys)} " f"instruments."
            )

        except Exception as ex:

            logger.exception(f"Subscription failed: {ex}")

    def on_open(self):
        """
        Websocket connected.
        """

        try:

            logger.info("WebSocket connected.")

            self.subscribe_all_instruments()

        except Exception as ex:

            logger.exception(f"Open handler failed: {ex}")

    def on_message(self, message):
        """
        Incoming market data.
        """

        try:

            feeds = message.get("feeds", {})

            if not feeds:
                return

            for instrument_key, feed in feeds.items():

                try:

                    ltpc = None

                    if "ltpc" in feed:

                        ltpc = feed.get("ltpc")

                    elif "fullFeed" in feed and "marketFF" in feed["fullFeed"]:

                        ltpc = feed["fullFeed"].get("marketFF", {}).get("ltpc")

                    if not ltpc:
                        continue

                    price = float(ltpc.get("ltp", 0))

                    timestamp_ms = ltpc.get("ltt")

                    if not timestamp_ms:
                        continue

                    timestamp = self.convert_timestamp(timestamp_ms)

                    volume = int(ltpc.get("ltq", 0))

                    completed_candle = CandleBuilder.process_tick(
                        instrument_key=instrument_key,
                        price=price,
                        volume=volume,
                        timestamp=timestamp,
                    )

                    if completed_candle:

                        CrossoverEngine.process_completed_candle(
                            instrument_key=instrument_key, candle=completed_candle
                        )

                except Exception as ex:

                    logger.exception(
                        f"Tick processing failed " f"{instrument_key}: {ex}"
                    )

        except Exception as ex:

            logger.exception(f"Message processing failed: {ex}")

    def on_error(self, error):

        logger.error(f"WebSocket error: {error}")

    def on_close(self):

        logger.warning("WebSocket disconnected.")

    def register_events(self):
        """
        Attach websocket events.
        """

        try:

            self.streamer.on("open", self.on_open)

            self.streamer.on("message", self.on_message)

            self.streamer.on("error", self.on_error)

            self.streamer.on("close", self.on_close)

        except Exception as ex:

            logger.exception(f"Event registration failed: {ex}")
            raise

    @staticmethod
    def convert_timestamp(timestamp_ms: int) -> str:
        """
        Convert epoch ms to ISO timestamp.
        """

        try:

            dt = datetime.fromtimestamp(
                timestamp_ms / 1000, tz=ZoneInfo(Settings.TIMEZONE)
            )

            return dt.isoformat()

        except Exception as ex:

            logger.exception(f"Timestamp conversion failed: {ex}")
            raise

    def connect(self):
        """
        Connect websocket.
        """

        try:

            self.create_streamer()

            self.register_events()

            logger.info("Connecting to Upstox...")

            self.streamer.connect()

        except Exception as ex:

            logger.exception(f"Connection failed: {ex}")
            raise

    def auto_reconnect(self):
        """
        Auto reconnect.
        """

        retries = 0

        while self.running:

            try:

                self.connect()

                logger.info("Connected successfully.")

                return

            except Exception as ex:

                retries += 1

                logger.error(
                    f"Reconnect failed " f"| Attempt={retries} " f"| Error={ex}"
                )

                time.sleep(Settings.RECONNECT_DELAY)

    def start_background_stats(self):
        """
        Runtime stats logger.
        """

        def worker():

            while self.running:

                try:

                    CrossoverEngine.print_runtime_stats()

                except Exception as ex:

                    logger.exception(f"Stats worker failed: {ex}")

                time.sleep(Settings.STATS_INTERVAL_SECONDS)

        self.stats_thread = threading.Thread(target=worker, daemon=True)

        self.stats_thread.start()

    def stop(self):
        """
        Market close cleanup.
        """

        try:

            logger.info("Stopping Upstox stream...")

            self.running = False

            if not self.streamer:
                return

            try:

                instrument_keys = PreloadService.get_instrument_keys()

                if instrument_keys:

                    self.streamer.unsubscribe(instrument_keys)

                    logger.info(
                        f"Unsubscribed " f"{len(instrument_keys)} " f"instruments."
                    )

            except Exception as ex:

                logger.exception(f"Unsubscribe failed: {ex}")

            try:

                if hasattr(self.streamer, "disconnect"):
                    self.streamer.disconnect()

                    logger.info("WebSocket disconnected.")

            except Exception as ex:

                logger.exception(f"Disconnect failed: {ex}")

        except Exception as ex:

            logger.exception(f"Stop service failed: {ex}")

    def start(self):
        """
        Start service.
        """

        try:

            logger.info("=" * 80)
            logger.info("UPSTOX STREAM SERVICE STARTING")
            logger.info("=" * 80)

            self.running = True

            self.start_background_stats()

            self.auto_reconnect()

        except Exception as ex:

            logger.exception(f"Stream startup failed: {ex}")
            raise
