from datetime import datetime

from config.settings import Settings
from core.logger import get_logger
from db.repositories import UpstoxRepository
from indicators.ema import EMAIndicator
from models.strike_state import StrikeState

logger = get_logger(__name__)


class PreloadService:
    """
    Loads all strike documents and builds
    runtime EMA state before market open.
    """

    RUNTIME_STATE = {}

    @classmethod
    def load_access_token(cls):
        """
        Load latest Upstox access token.
        """

        try:

            token = UpstoxRepository.get_access_token()

            logger.info("Access token loaded successfully.")

            return token

        except Exception as ex:

            logger.exception(f"Failed loading access token: {ex}")
            raise

    @classmethod
    def get_today(cls):
        """
        Current trading date.
        """

        return datetime.now().strftime("%Y-%m-%d")

    @classmethod
    def reset(cls):
        """
        Clear runtime cache.
        Called every market close.
        """

        try:

            count = len(cls.RUNTIME_STATE)

            cls.RUNTIME_STATE.clear()

            logger.info(f"Runtime cache cleared. " f"Removed {count} instruments.")

        except Exception as ex:

            logger.exception(f"Failed clearing runtime cache: {ex}")

    @classmethod
    def _load_ema_state(cls, strike_doc: dict):
        """
        Load latest EMA state.

        Priority:

        1. Daily stored EMA
        2. Recalculate from candles
        """

        try:

            daily = strike_doc.get("daily", {})

            if daily:

                latest_date = sorted(daily.keys())[-1]

                latest_daily = daily.get(latest_date, {})

                ema_short = latest_daily.get("ema_short")

                ema_long = latest_daily.get("ema_long")

                last_price = latest_daily.get("last_price")

                if (
                    ema_short is not None
                    and ema_long is not None
                    and last_price is not None
                ):

                    relation = "ABOVE" if ema_short > ema_long else "BELOW"

                    logger.debug(
                        f"Using stored EMA " f"| {strike_doc.get('instrument_key')}"
                    )

                    return {
                        "ema_short": float(ema_short),
                        "ema_long": float(ema_long),
                        "last_close": float(last_price),
                        "relation": relation,
                    }

            candles = strike_doc.get("candles", [])

            return EMAIndicator.get_latest_state(
                candles=candles,
                short_period=Settings.EMA_SHORT_PERIOD,
                long_period=Settings.EMA_LONG_PERIOD,
            )

        except Exception as ex:

            logger.exception(f"Failed loading EMA state: {ex}")
            raise

    @classmethod
    def initialize_runtime_state(cls):
        """
        Load all strike documents and
        build runtime cache.
        """

        try:

            cls.reset()

            strikes = UpstoxRepository.get_all_strikes()

            total_loaded = 0
            total_skipped = 0

            today = cls.get_today()

            logger.info(f"Initializing runtime state " f"for {len(strikes)} strikes.")

            for strike_doc in strikes:

                try:

                    instrument_key = strike_doc.get("instrument_key")

                    if not instrument_key:

                        total_skipped += 1

                        logger.warning("Instrument key missing.")

                        continue

                    candles = strike_doc.get("candles", [])

                    if not candles:

                        total_skipped += 1

                        logger.warning(
                            f"Skipping "
                            f"{instrument_key} "
                            f"because candles "
                            f"are empty."
                        )

                        continue

                    UpstoxRepository.ensure_daily_document(instrument_key, today)

                    ema_state = cls._load_ema_state(strike_doc)

                    strike_state = StrikeState.from_preload(strike_doc, ema_state)

                    cls.RUNTIME_STATE[instrument_key] = strike_state

                    total_loaded += 1

                except Exception as strike_ex:

                    total_skipped += 1

                    logger.exception(
                        f"Failed loading "
                        f"{strike_doc.get('instrument_key')} "
                        f": {strike_ex}"
                    )

            logger.info(
                f"Runtime initialized "
                f"| Loaded={total_loaded}"
                f" | Skipped={total_skipped}"
            )

            return cls.RUNTIME_STATE

        except Exception as ex:

            logger.exception(f"Runtime initialization failed: {ex}")
            raise

    @classmethod
    def get_runtime_state(cls):
        """
        Return complete runtime cache.
        """

        return cls.RUNTIME_STATE

    @classmethod
    def get_runtime_by_key(cls, instrument_key: str):
        """
        Return one instrument runtime state.
        """

        return cls.RUNTIME_STATE.get(instrument_key)

    @classmethod
    def update_runtime_state(cls, instrument_key: str, updates: dict):
        """
        Update StrikeState object.
        """

        try:

            state = cls.RUNTIME_STATE.get(instrument_key)

            if not state:

                logger.warning(f"Runtime state missing " f"for {instrument_key}")

                return

            if "ema_short" in updates:

                state.update_ema(
                    ema_short=updates.get("ema_short", state.ema_short),
                    ema_long=updates.get("ema_long", state.ema_long),
                    last_close=updates.get("last_close", state.last_close),
                    relation=updates.get("relation", state.relation),
                )

        except Exception as ex:

            logger.exception(f"Runtime update failed " f"{instrument_key}: {ex}")

    @classmethod
    def get_instrument_keys(cls):
        """
        Used for Upstox subscriptions.
        """

        try:

            keys = list(cls.RUNTIME_STATE.keys())

            return keys

        except Exception as ex:

            logger.exception(f"Failed loading instrument keys: {ex}")
            raise

    @classmethod
    def get_subscription_batches(cls, batch_size=None):
        """
        Split instruments into batches.
        """

        try:

            if batch_size is None:

                batch_size = Settings.SUBSCRIBE_BATCH_SIZE

            keys = cls.get_instrument_keys()

            return [keys[i : i + batch_size] for i in range(0, len(keys), batch_size)]

        except Exception as ex:

            logger.exception(f"Failed creating batches: {ex}")
            raise

    @classmethod
    def get_total_instruments(cls):

        return len(cls.RUNTIME_STATE)

    @classmethod
    def print_startup_summary(cls):
        """
        Startup summary.
        """

        try:

            total = cls.get_total_instruments()

            logger.info("=" * 70)
            logger.info(Settings.APP_NAME)
            logger.info(f"EMA SHORT : " f"{Settings.EMA_SHORT_PERIOD}")
            logger.info(f"EMA LONG : " f"{Settings.EMA_LONG_PERIOD}")
            logger.info(f"INSTRUMENTS : " f"{total}")
            logger.info("=" * 70)

        except Exception as ex:

            logger.exception(f"Failed startup summary: {ex}")
