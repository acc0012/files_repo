import time

from datetime import datetime, time as dt_time
from zoneinfo import ZoneInfo

from core.logger import get_logger

from db.mongo_app import MongoApp

from services.preload_service import PreloadService

from services.candle_builder import CandleBuilder

from services.crossover_engine import CrossoverEngine

from services.upstox_stream import UpstoxStreamService

logger = get_logger(__name__)


class MarketScheduler:

    def __init__(self):

        self.stream_service = None

        self.ist = ZoneInfo("Asia/Kolkata")

        self.preloaded_today = False

        self.market_started = False

        self.market_closed_today = False

        self.current_trading_date = None

        self.access_token = None

    def get_today(self):

        return datetime.now(self.ist).date().isoformat()

    def get_current_time(self):

        return datetime.now(self.ist).time()

    def is_preload_time(self):

        now = self.get_current_time()

        return now >= dt_time(9, 0)

    def is_market_open_time(self):

        now = self.get_current_time()

        return now >= dt_time(9, 15)

    def is_market_closed_time(self):

        now = self.get_current_time()

        return now >= dt_time(15, 30)

    def reset_for_new_day(self):
        """
        Reset scheduler state
        for a new trading day.
        """

        try:

            today = self.get_today()

            if self.current_trading_date == today:
                return

            logger.info(f"New trading day detected: {today}")

            self.current_trading_date = today

            self.preloaded_today = False

            self.market_started = False

            self.market_closed_today = False

        except Exception as ex:

            logger.exception(f"Reset day failed: {ex}")

    def perform_preload(self):
        """
        Daily preload.
        """

        try:

            logger.info("=" * 70)
            logger.info("STARTING DAILY PRELOAD")
            logger.info("=" * 70)

            PreloadService.RUNTIME_STATE.clear()

            self.access_token = PreloadService.load_access_token()

            runtime_state = PreloadService.initialize_runtime_state()

            total = len(runtime_state)

            logger.info(f"Daily preload complete" f" | Instruments={total}")

            PreloadService.print_startup_summary()

            self.preloaded_today = True

        except Exception as ex:

            logger.exception(f"Daily preload failed: {ex}")

    def start_market(self):
        """
        Start live streaming.
        """

        try:

            if self.market_started:
                return

            logger.info("=" * 70)
            logger.info("MARKET OPEN - STARTING FEED")
            logger.info("=" * 70)

            self.stream_service = UpstoxStreamService(self.access_token)

            self.stream_service.start()

            self.market_started = True

            logger.info("Market feed started.")

        except Exception as ex:

            logger.exception(f"Market start failed: {ex}")

    def flush_pending_candles(self):
        """
        Flush all active candles.
        """

        try:

            active_candles = dict(CandleBuilder.ACTIVE_CANDLES)

            logger.info(f"Flushing " f"{len(active_candles)} " f"active candles")

            for instrument_key in list(active_candles.keys()):

                try:

                    candle = CandleBuilder.force_close_candle(instrument_key)

                    if candle:

                        CrossoverEngine.process_completed_candle(instrument_key, candle)

                except Exception as ex:

                    logger.exception(f"Flush failed " f"{instrument_key}: {ex}")

        except Exception as ex:

            logger.exception(f"Flush active candles failed: {ex}")

    def stop_market(self):
        """
        Market close cleanup.
        """

        try:

            if self.market_closed_today:
                return

            logger.info("=" * 70)
            logger.info("MARKET CLOSED")
            logger.info("=" * 70)

            self.flush_pending_candles()

            if self.stream_service:

                try:

                    self.stream_service.stop()

                except Exception as ex:

                    logger.exception(f"Socket stop failed: {ex}")

            runtime_count = len(PreloadService.RUNTIME_STATE)

            active_count = len(CandleBuilder.ACTIVE_CANDLES)

            logger.info(f"Runtime Instruments=" f"{runtime_count}")

            logger.info(f"Active Candles=" f"{active_count}")

            PreloadService.RUNTIME_STATE.clear()

            CandleBuilder.clear()

            self.market_closed_today = True

            self.market_started = False

            logger.info("Market cleanup completed.")

        except Exception as ex:

            logger.exception(f"Market stop failed: {ex}")

    def scheduler_cycle(self):
        """
        One scheduler cycle.
        """

        try:

            self.reset_for_new_day()

            today = self.get_today()

            # -------------------------
            # Daily preload
            # -------------------------

            if (
                not self.preloaded_today
                and self.is_preload_time()
                and not self.is_market_closed_time()
            ):

                logger.info(f"Running preload " f"for {today}")

                self.perform_preload()

            # -------------------------
            # Start market feed
            # -------------------------

            if (
                self.preloaded_today
                and not self.market_started
                and self.is_market_open_time()
                and not self.is_market_closed_time()
            ):

                self.start_market()

            # -------------------------
            # Market close
            # -------------------------

            if self.market_started and self.is_market_closed_time():

                self.stop_market()

        except Exception as ex:

            logger.exception(f"Scheduler cycle failed: {ex}")

    def start(self):
        """
        Main scheduler loop.
        """

        logger.info("=" * 80)
        logger.info("MARKET SCHEDULER STARTED")
        logger.info("=" * 80)

        MongoApp.connect()

        while True:

            try:

                self.scheduler_cycle()

            except Exception as ex:

                logger.exception(f"Scheduler error: {ex}")

            time.sleep(15)
