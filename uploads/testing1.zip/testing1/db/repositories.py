from datetime import datetime

from db.mongo_app import MongoApp
from core.logger import get_logger

logger = get_logger(__name__)


class UpstoxRepository:

    @staticmethod
    def get_access_token() -> str:
        """
        Fetch Upstox access token.
        """

        try:

            token_doc = MongoApp.get_token_collection().find_one(
                {"_id": "upstox_access_token"}
            )

            if not token_doc:
                raise Exception("Upstox access token document not found.")

            access_token = token_doc.get("access_token")

            if not access_token:
                raise Exception("Access token is empty.")

            logger.info("Successfully loaded access token.")

            return access_token

        except Exception as ex:

            logger.exception(f"Failed to fetch access token: {ex}")

            raise

    @staticmethod
    def get_all_strikes():
        """
        Load all strike documents.
        """

        try:

            strikes = list(MongoApp.get_strikes_collection().find({}))

            logger.info(f"Loaded {len(strikes)} strike documents.")

            return strikes

        except Exception as ex:

            logger.exception(f"Failed to load strikes: {ex}")

            raise

    @staticmethod
    def get_all_instruments():
        """
        Load only instrument keys.
        """

        try:

            data = list(
                MongoApp.get_strikes_collection().find(
                    {}, {"_id": 0, "instrument_key": 1}
                )
            )

            instrument_keys = [
                row["instrument_key"] for row in data if row.get("instrument_key")
            ]

            logger.info(f"Loaded {len(instrument_keys)} instrument keys.")

            return instrument_keys

        except Exception as ex:

            logger.exception(f"Failed to load instrument keys: {ex}")

            raise

    @staticmethod
    def get_strike_by_instrument_key(instrument_key: str):
        """
        Fetch one strike document.
        """

        try:

            doc = MongoApp.get_strikes_collection().find_one(
                {"instrument_key": instrument_key}
            )

            return doc

        except Exception as ex:

            logger.exception(f"Failed to fetch strike " f"{instrument_key}: {ex}")

            raise

    @staticmethod
    def append_candle(instrument_key: str, candle: dict, trading_date: str):
        """
        Append candle into:
        candles
        daily.<date>.today_candles
        """

        try:

            result = MongoApp.get_strikes_collection().update_one(
                {"instrument_key": instrument_key},
                {
                    "$push": {
                        "candles": candle,
                        f"daily.{trading_date}.today_candles": candle,
                    }
                },
            )

            logger.info(
                f"Candle saved | "
                f"{instrument_key} | "
                f"modified={result.modified_count}"
            )

        except Exception as ex:

            logger.exception(f"Failed to save candle " f"{instrument_key}: {ex}")

    @staticmethod
    def save_crossover(instrument_key: str, trading_date: str, crossover: dict):
        """
        Save bullish/bearish crossover.
        """

        try:

            result = MongoApp.get_strikes_collection().update_one(
                {"instrument_key": instrument_key},
                {"$push": {f"daily.{trading_date}.crosses_today": crossover}},
            )

            logger.info(
                f"Crossover saved | "
                f"{instrument_key} | "
                f"{crossover.get('signal')}"
            )

            return result

        except Exception as ex:

            logger.exception(f"Failed saving crossover " f"{instrument_key}: {ex}")

    @staticmethod
    def update_live_ema_status(
        instrument_key: str,
        trading_date: str,
        signal_status: str,
        ema_short: float,
        ema_long: float,
        last_price: float,
        candle_timestamp: str,
    ):
        """
        Update current EMA values and status.
        """

        try:

            result = MongoApp.get_strikes_collection().update_one(
                {"instrument_key": instrument_key},
                {
                    "$set": {
                        f"daily.{trading_date}.signal_status": signal_status,
                        f"daily.{trading_date}.ema_short": ema_short,
                        f"daily.{trading_date}.ema_long": ema_long,
                        f"daily.{trading_date}.last_price": last_price,
                        f"daily.{trading_date}.candle_timestamp": candle_timestamp,
                    }
                },
            )

            logger.debug(f"EMA status updated | " f"{instrument_key}")

            return result

        except Exception as ex:

            logger.exception(f"Failed updating EMA status " f"{instrument_key}: {ex}")

    @staticmethod
    def update_last_updated(instrument_key: str):
        """
        Update document last_updated.
        """

        try:

            (
                MongoApp.get_strikes_collection().update_one(
                    {"instrument_key": instrument_key},
                    {"$set": {"last_updated": datetime.utcnow()}},
                )
            )

        except Exception as ex:

            logger.exception(f"Failed updating last_updated " f"{instrument_key}: {ex}")

    @staticmethod
    def ensure_daily_document(instrument_key: str, trading_date: str):
        """
        Ensure daily.<date> exists.
        """

        try:

            strike = MongoApp.get_strikes_collection().find_one(
                {"instrument_key": instrument_key}
            )

            daily_data = strike.get("daily", {}).get(trading_date)

            if daily_data:
                return

            (
                MongoApp.get_strikes_collection().update_one(
                    {"instrument_key": instrument_key},
                    {
                        "$set": {
                            f"daily.{trading_date}": {
                                "signal": None,
                                "signal_status": "NO_CROSSOVER",
                                "crosses_today": [],
                                "today_candles": [],
                                "ema_short": None,
                                "ema_long": None,
                                "last_price": None,
                                "candle_timestamp": None,
                            }
                        }
                    },
                )
            )

            logger.info(
                f"Created daily bucket " f"{trading_date} | " f"{instrument_key}"
            )

        except Exception as ex:

            logger.exception(f"Failed creating daily bucket " f"{instrument_key}: {ex}")
