from datetime import datetime, timezone

from fastapi import APIRouter, Query

from core import config
from services.option_service import options_cache
from ws_feed.broadcaster import broadcaster

try:
    from services.opening_range_service import (
        get_support_confirmation_status,
        get_effective_selected_instrument_status,
        get_manual_selected_instrument_state,
        get_automatic_selected_or_instrument_state,
        get_effective_isolated_instrument_state,
        get_effective_isolated_instrument_source,
    )
except Exception:
    get_support_confirmation_status = None
    get_effective_selected_instrument_status = None
    get_manual_selected_instrument_state = None
    get_automatic_selected_or_instrument_state = None
    get_effective_isolated_instrument_state = None
    get_effective_isolated_instrument_source = None

router = APIRouter()


# ============================================================
# Live EMA Mode Helper
# ============================================================


def get_live_ema_calculation_mode_text() -> str:
    """
    Returns configured live EMA calculation mode.

    LIVE_EMA_CALCULATION_MODE = False
        completed candle close based EMA calculation.

    LIVE_EMA_CALCULATION_MODE = True
        live tick/LTP based EMA calculation.
    """

    return (
        "tick_ltp"
        if bool(getattr(config, "LIVE_EMA_CALCULATION_MODE", False))
        else "candle_close"
    )


def get_live_ema_calculation_mode_payload() -> dict:
    """
    Returns live EMA mode payload for debug/API responses.
    """

    flag = bool(getattr(config, "LIVE_EMA_CALCULATION_MODE", False))
    mode = get_live_ema_calculation_mode_text()

    return {
        "flag": flag,
        "mode": mode,
        "description": (
            "live tick/LTP based EMA calculation"
            if flag
            else "completed candle close based EMA calculation"
        ),
    }


def get_support_confirmation_rule_payload() -> dict:
    """
    Returns Opening Range support confirmation rule payload.
    """

    return {
        "enabled": bool(
            getattr(config, "OPENING_RANGE_SUPPORT_CONFIRMATION_ENABLED", True)
        ),
        "mode": "support_confirmation_flow",
        "description": (
            "R3 and R2 are resistance triggers only when support confirmation is enabled. "
            "R3 waits for opposite-side S3 support confirmation. R2 waits for "
            "opposite-side S2 support confirmation. After S2 touches, the system waits "
            "for S3 upgrade. If S3 touches inside the wait window, S3 is isolated. "
            "If S3 does not touch inside the wait window, S2 is isolated after timeout."
        ),
        "rules": {
            "r3": {
                "trigger_level": "R3",
                "direct_isolation": False,
                "required_confirmation": "opposite_side_S3",
                "final_isolation_level": "S3",
                "enabled": bool(
                    getattr(config, "OPENING_RANGE_R3_REQUIRES_S3_CONFIRMATION", True)
                ),
            },
            "r2": {
                "trigger_level": "R2",
                "direct_isolation": False,
                "required_confirmation": "opposite_side_S2",
                "provisional_level": "S2",
                "upgrade_level": "S3",
                "wait_minutes": int(
                    getattr(config, "OPENING_RANGE_S2_TO_S3_WAIT_MINUTES", 15)
                ),
                "final_if_s3_within_window": "S3",
                "final_if_no_s3_within_window": "S2",
                "enabled": bool(
                    getattr(config, "OPENING_RANGE_R2_REQUIRES_S2_CONFIRMATION", True)
                ),
            },
        },
        "eod": {
            "hour": int(
                getattr(config, "OPENING_RANGE_SUPPORT_CONFIRMATION_EOD_HOUR", 15)
            ),
            "minute": int(
                getattr(config, "OPENING_RANGE_SUPPORT_CONFIRMATION_EOD_MINUTE", 30)
            ),
            "message_enabled": bool(
                getattr(
                    config,
                    "OPENING_RANGE_SUPPORT_CONFIRMATION_EOD_MESSAGE_ENABLED",
                    True,
                )
            ),
        },
        "timeout_check": {
            "interval_minutes": int(
                getattr(
                    config,
                    "OPENING_RANGE_SUPPORT_CONFIRMATION_TIMEOUT_CHECK_INTERVAL_MINUTES",
                    1,
                )
            ),
            "scheduler_required": True,
        },
    }


def get_manual_selection_rule_payload() -> dict:
    """
    Returns manual / hard selected instrument rule payload.
    """

    return {
        "enabled": bool(
            getattr(config, "TELEGRAM_MANUAL_INSTRUMENT_SELECTION_ENABLED", True)
        ),
        "manual_selection_overrides_auto": bool(
            getattr(config, "MANUAL_INSTRUMENT_SELECTION_OVERRIDES_AUTO", True)
        ),
        "reset_daily": bool(
            getattr(config, "MANUAL_INSTRUMENT_SELECTION_RESET_DAILY", True)
        ),
        "mode": "manual_or_hard_selected_instrument",
        "description": (
            "Manual selection allows one instrument to be selected for isolated EMA "
            "Telegram alerts. Hard select force-locks one instrument. When manual "
            "override is active, automatic Opening Range support-confirmation isolation "
            "does not replace the effective selected instrument."
        ),
        "modes": {
            "manual_select": {
                "description": (
                    "Manual selected instrument becomes effective when "
                    "MANUAL_INSTRUMENT_SELECTION_OVERRIDES_AUTO=True."
                ),
                "can_be_replaced_by_new_manual_select": True,
            },
            "hard_select": {
                "description": (
                    "Hard selected instrument is treated as the strongest manual override."
                ),
                "can_be_replaced_by_new_hard_select": True,
            },
            "clear": {
                "description": (
                    "Clears manual / hard selection. If an automatic isolated instrument "
                    "exists, the system falls back to it. Otherwise no effective isolated "
                    "instrument remains selected."
                ),
            },
        },
    }


def get_current_support_confirmation_status_payload() -> dict:
    """
    Returns current support confirmation status if opening_range_service is importable.
    """

    if not get_support_confirmation_status:
        return {
            "status": "unavailable",
            "message": "get_support_confirmation_status could not be imported.",
        }

    try:
        return get_support_confirmation_status()
    except Exception as ex:
        return {
            "status": "error",
            "error": f"{type(ex).__name__}: {ex}",
        }


def get_current_manual_selection_status_payload() -> dict:
    """
    Returns current manual / hard selected instrument status if opening_range_service is importable.
    """

    if not get_effective_selected_instrument_status:
        return {
            "status": "unavailable",
            "message": "manual selection helpers could not be imported.",
        }

    try:
        return {
            "status": "success",
            "manual_selection": get_effective_selected_instrument_status(),
            "manual_selected_instrument": (
                get_manual_selected_instrument_state()
                if get_manual_selected_instrument_state
                else None
            ),
            "automatic_isolated_instrument": (
                get_automatic_selected_or_instrument_state()
                if get_automatic_selected_or_instrument_state
                else None
            ),
            "effective_isolated_instrument": (
                get_effective_isolated_instrument_state()
                if get_effective_isolated_instrument_state
                else None
            ),
            "effective_isolated_instrument_source": (
                get_effective_isolated_instrument_source()
                if get_effective_isolated_instrument_source
                else "unknown"
            ),
        }
    except Exception as ex:
        return {
            "status": "error",
            "error": f"{type(ex).__name__}: {ex}",
        }


def get_ema_order_side_rule_payload() -> dict:
    """
    Returns EMA order side rule payload.

    Current requirement:
        bullish_cross -> same side as isolated instrument
        bearish_cross -> opposite side of isolated instrument
    """

    return {
        "mode": "dynamic_isolated_instrument_side",
        "description": (
            "EMA alert suggested order instruments are selected from current NIFTY "
            "spot based strikes. The option side is dynamic: bullish_cross uses the "
            "same side as the isolated instrument, while bearish_cross uses the "
            "opposite side of the isolated instrument."
        ),
        "rules": {
            "bullish_cross": "same_side_as_isolated_instrument",
            "bearish_cross": "opposite_side_of_isolated_instrument",
        },
        "examples": [
            {
                "isolated_instrument_type": "CE",
                "cross_type": "bullish_cross",
                "suggested_order_side": "CE",
            },
            {
                "isolated_instrument_type": "CE",
                "cross_type": "bearish_cross",
                "suggested_order_side": "PE",
            },
            {
                "isolated_instrument_type": "PE",
                "cross_type": "bullish_cross",
                "suggested_order_side": "PE",
            },
            {
                "isolated_instrument_type": "PE",
                "cross_type": "bearish_cross",
                "suggested_order_side": "CE",
            },
        ],
        "fallback": {
            "bullish_option_type": getattr(
                config,
                "EMA_ALERT_BULLISH_OPTION_TYPE",
                "CE",
            ),
            "bearish_option_type": getattr(
                config,
                "EMA_ALERT_BEARISH_OPTION_TYPE",
                "PE",
            ),
            "used_only_when_isolated_instrument_type_missing": True,
        },
    }


# ============================================================
# Test Broadcast Routes
# ============================================================


@router.get("/test-broadcast")
async def test_broadcast():
    """
    Local debug endpoint.

    Use this to verify /ws and /all-feeds without depending on Upstox live ticks.
    """

    sample_tick = {
        "fullFeed": {
            "marketFF": {
                "ltpc": {
                    "ltp": 24500,
                    "cp": 24450,
                    "ltt": 0,
                    "ltq": 50,
                },
                "marketOHLC": {
                    "ohlc": [
                        {
                            "interval": "1d",
                            "open": 24400,
                            "high": 24550,
                            "low": 24350,
                            "vol": 100000,
                        }
                    ]
                },
                "atp": 24480,
                "vtt": 100000,
                "oi": 0,
            }
        }
    }

    contract_info = {
        "instrument_key": "NSE_INDEX|Nifty 50",
        "instrument_type": "INDEX",
        "strike_price": None,
        "expiry": None,
        "trading_symbol": "NIFTY 50",
        "underlying_type": "INDEX",
        "underlying_symbol": "NIFTY 50",
    }

    await broadcaster.broadcast_tick(
        instrument_key="NSE_INDEX|Nifty 50",
        tick_raw=sample_tick,
        contract_info=contract_info,
    )

    return {
        "status": "sent",
        "message": "Test broadcast sent to connected /ws and /all-feeds clients.",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "live_ema_calculation": get_live_ema_calculation_mode_payload(),
        "support_confirmation_rule": get_support_confirmation_rule_payload(),
        "support_confirmation_status": get_current_support_confirmation_status_payload(),
        "manual_selection_rule": get_manual_selection_rule_payload(),
        "manual_selection_status": get_current_manual_selection_status_payload(),
    }


@router.get("/test-broadcast-option")
async def test_broadcast_option():
    """
    Local debug endpoint for /option clients.

    Connect first to:
        ws://127.0.0.1:8000/option?strike=24500&striketype=ce

    Then call:
        http://127.0.0.1:8000/test-broadcast-option
    """

    sample_tick = {
        "fullFeed": {
            "marketFF": {
                "ltpc": {
                    "ltp": 120.5,
                    "cp": 115.0,
                    "ltt": 0,
                    "ltq": 75,
                },
                "marketOHLC": {
                    "ohlc": [
                        {
                            "interval": "1d",
                            "open": 110.0,
                            "high": 130.0,
                            "low": 100.0,
                            "vol": 250000,
                        }
                    ]
                },
                "atp": 118.5,
                "vtt": 250000,
                "oi": 500000,
                "iv": 12.5,
                "optionGreeks": {
                    "delta": 0.52,
                    "theta": -8.2,
                    "gamma": 0.001,
                    "vega": 10.4,
                    "rho": 1.25,
                },
                "marketLevel": {
                    "bidAskQuote": [
                        {
                            "bidQ": 100,
                            "bidP": 120.0,
                            "askQ": 150,
                            "askP": 121.0,
                        }
                    ]
                },
            }
        }
    }

    contract_info = {
        "instrument_key": "TEST_NSE_FO|24500CE",
        "instrument_type": "CE",
        "strike_price": 24500.0,
        "expiry": options_cache.get("nearest_expiry"),
        "trading_symbol": "NIFTY 24500 CE TEST",
        "underlying_type": "INDEX",
        "underlying_symbol": "NIFTY",
    }

    await broadcaster.broadcast_tick(
        instrument_key="TEST_NSE_FO|24500CE",
        tick_raw=sample_tick,
        contract_info=contract_info,
    )

    return {
        "status": "sent",
        "message": "Test option broadcast sent to connected /option clients for 24500 CE.",
        "target": "24500.0_CE_0",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "live_ema_calculation": get_live_ema_calculation_mode_payload(),
        "support_confirmation_rule": get_support_confirmation_rule_payload(),
        "support_confirmation_status": get_current_support_confirmation_status_payload(),
        "manual_selection_rule": get_manual_selection_rule_payload(),
        "manual_selection_status": get_current_manual_selection_status_payload(),
    }


@router.get("/test-broadcast-ema")
async def test_broadcast_ema(
    strike: float = Query(
        default=24500.0,
        description="Option strike price for test EMA event.",
    ),
    striketype: str = Query(
        default="ce",
        description="Option type: ce or pe.",
    ),
    cross_type: str = Query(
        default="bullish_cross",
        description="EMA cross type: bullish_cross or bearish_cross.",
    ),
):
    """
    Local debug endpoint for EMA crossover WebSocket clients.

    Connect first to:
        ws://127.0.0.1:8000/ws/ema-crossover

    Or instrument-specific:
        ws://127.0.0.1:8000/ws/ema-crossover/instrument?instrument_key=TEST_NSE_FO|24500CE

    Or option:
        ws://127.0.0.1:8000/option?strike=24500&striketype=ce

    Then call:
        http://127.0.0.1:8000/test-broadcast-ema
    """

    option_type = str(striketype or "ce").upper()

    if option_type not in ["CE", "PE"]:
        option_type = "CE"

    if cross_type not in ["bullish_cross", "bearish_cross"]:
        cross_type = "bullish_cross"

    instrument_key = f"TEST_NSE_FO|{int(float(strike))}{option_type}"

    mode_payload = get_live_ema_calculation_mode_payload()
    ema_mode = mode_payload.get("mode")

    contract_info = {
        "instrument_key": instrument_key,
        "instrument_type": option_type,
        "strike_price": float(strike),
        "expiry": options_cache.get("nearest_expiry"),
        "trading_symbol": f"NIFTY {int(float(strike))} {option_type} TEST",
        "underlying_type": "INDEX",
        "underlying_symbol": "NIFTY",
    }

    now_ts = datetime.now(timezone.utc).isoformat()

    base_event = {
        "type": "live_ema_cross",
        "instrument_key": instrument_key,
        "timestamp": now_ts,
        "timestamp_ms": None,
        "cross_type": cross_type,
        "close": 120.5,
        "ema_fast_period": getattr(config, "LIVE_EMA_FAST_PERIOD", 9),
        "ema_slow_period": getattr(config, "LIVE_EMA_SLOW_PERIOD", 21),
        "ema_fast": 121.25,
        "ema_slow": 120.95,
        "previous_ema_fast": 120.80,
        "previous_ema_slow": 120.90,
        "previous_signal": "bearish" if cross_type == "bullish_cross" else "bullish",
        "current_signal": "bullish" if cross_type == "bullish_cross" else "bearish",
        "created_at": now_ts,
        "contract_info": contract_info,
        "info": contract_info,
        "telegram_alert_scope": "isolated_support_or_manual_instrument_only",
        "broadcast_scope": "all_instruments",
        "ema_order_side_rule": get_ema_order_side_rule_payload(),
        "support_confirmation_rule": get_support_confirmation_rule_payload(),
        "support_confirmation_status": get_current_support_confirmation_status_payload(),
        "manual_selection_rule": get_manual_selection_rule_payload(),
        "manual_selection_status": get_current_manual_selection_status_payload(),
    }

    if ema_mode == "tick_ltp":
        ema_event = {
            **base_event,
            "interval_minutes": 0,
            "ltp": 120.5,
            "source": "debug_live_tick",
            "ema_calculation_mode": "tick_ltp",
            "tick": {
                "timestamp": now_ts,
                "timestamp_ms": None,
                "ltp": 120.5,
                "ltq": 75,
                "ltt": 0,
            },
            "candle": None,
        }
    else:
        ema_event = {
            **base_event,
            "interval_minutes": getattr(config, "LIVE_EMA_INTERVAL_MINUTES", 1),
            "source": "debug_candle_close",
            "ema_calculation_mode": "candle_close",
            "candle": {
                "timestamp": now_ts,
                "timestamp_ms": None,
                "open": 118.0,
                "high": 123.0,
                "low": 117.5,
                "close": 120.5,
                "volume": 250000,
            },
            "tick": None,
        }

    await broadcaster.broadcast_ema_cross(ema_event)

    return {
        "status": "sent",
        "message": (
            "Test EMA crossover broadcast sent to connected EMA, all-feeds, "
            "and matching option clients."
        ),
        "target_instrument_key": instrument_key,
        "target_option": f"{float(strike)}_{option_type}",
        "cross_type": cross_type,
        "timestamp": now_ts,
        "live_ema_calculation": mode_payload,
        "ema_order_side_rule": get_ema_order_side_rule_payload(),
        "support_confirmation_rule": get_support_confirmation_rule_payload(),
        "support_confirmation_status": get_current_support_confirmation_status_payload(),
        "manual_selection_rule": get_manual_selection_rule_payload(),
        "manual_selection_status": get_current_manual_selection_status_payload(),
        "event": ema_event,
    }


@router.get("/test-broadcast-opening-range")
async def test_broadcast_opening_range(
    strike: float = Query(
        default=24500.0,
        description="Option strike price for test Opening Range event.",
    ),
    striketype: str = Query(
        default="ce",
        description="Option type: ce or pe.",
    ),
    level: str = Query(
        default="R3",
        description="Opening Range level: R2, R3, S2, or S3.",
    ),
):
    """
    Local debug endpoint for Opening Range WebSocket clients.

    Connect first to:
        ws://127.0.0.1:8000/ws/opening-range

    Or instrument-specific:
        ws://127.0.0.1:8000/ws/opening-range/instrument?instrument_key=TEST_NSE_FO|24500CE

    Or option:
        ws://127.0.0.1:8000/option?strike=24500&striketype=ce

    Then call:
        http://127.0.0.1:8000/test-broadcast-opening-range
    """

    option_type = str(striketype or "ce").upper()

    if option_type not in ["CE", "PE"]:
        option_type = "CE"

    level_upper = str(level or "R3").upper()

    if level_upper not in ["R2", "R3", "S2", "S3"]:
        level_upper = "R3"

    instrument_key = f"TEST_NSE_FO|{int(float(strike))}{option_type}"

    now_ts = datetime.now(timezone.utc).isoformat()

    contract_info = {
        "instrument_key": instrument_key,
        "instrument_type": option_type,
        "strike_price": float(strike),
        "expiry": options_cache.get("nearest_expiry"),
        "trading_symbol": f"NIFTY {int(float(strike))} {option_type} TEST",
        "underlying_type": "INDEX",
        "underlying_symbol": "NIFTY",
    }

    is_resistance = level_upper.startswith("R")

    opening_range_event = {
        "type": "opening_range_touch",
        "instrument_key": instrument_key,
        "level": level_upper,
        "level_value": 130.0 if is_resistance else 110.0,
        "trigger_price": 131.25 if is_resistance else 108.75,
        "trigger_field": "high" if is_resistance else "low",
        "touch_time": now_ts,
        "source": "debug_api",
        "date": datetime.now(timezone.utc).date().isoformat(),
        "main_index_ltp": 24520.0,
        "distance_from_index": abs(float(strike) - 24520.0),
        "alert_key": f"{instrument_key}_{level_upper}",
        "contract_info": contract_info,
        "info": contract_info,
        "candle": {
            "timestamp": now_ts,
            "open": 118.0,
            "high": 131.25,
            "low": 108.75,
            "close": 129.5 if is_resistance else 109.5,
            "volume": 250000,
            "oi": 0,
        },
        "broadcast_scope": "all_instruments",
        "support_confirmation_rule": get_support_confirmation_rule_payload(),
        "support_confirmation_status": get_current_support_confirmation_status_payload(),
        "manual_selection_rule": get_manual_selection_rule_payload(),
        "manual_selection_status": get_current_manual_selection_status_payload(),
        "created_at": now_ts,
    }

    await broadcaster.broadcast_opening_range(opening_range_event)

    return {
        "status": "sent",
        "message": (
            "Test Opening Range broadcast sent to connected Opening Range, "
            "all-feeds, and matching option clients. This debug endpoint only "
            "broadcasts a synthetic event. It does not mutate actual Opening Range "
            "support-confirmation or manual-selection state."
        ),
        "target_instrument_key": instrument_key,
        "target_option": f"{float(strike)}_{option_type}",
        "level": level_upper,
        "timestamp": now_ts,
        "live_ema_calculation": get_live_ema_calculation_mode_payload(),
        "support_confirmation_rule": get_support_confirmation_rule_payload(),
        "support_confirmation_status": get_current_support_confirmation_status_payload(),
        "manual_selection_rule": get_manual_selection_rule_payload(),
        "manual_selection_status": get_current_manual_selection_status_payload(),
        "event": opening_range_event,
    }


# ============================================================
# Cache / Support Confirmation / Manual Selection Debug Routes
# ============================================================


@router.get("/debug/cache")
async def debug_cache():
    """Returns current in-memory cache details for local debugging."""

    cache_data = options_cache.get("data", [])

    return {
        "nearest_expiry": options_cache.get("nearest_expiry"),
        "total_contracts": options_cache.get("total_contracts"),
        "subscribed_keys_count": len(options_cache.get("subscribed_keys", [])),
        "sample_subscribed_keys": options_cache.get("subscribed_keys", [])[:5],
        "sample_contract": cache_data[0] if cache_data else None,
        "live_ema_calculation": get_live_ema_calculation_mode_payload(),
        "ema_order_side_rule": get_ema_order_side_rule_payload(),
        "support_confirmation_rule": get_support_confirmation_rule_payload(),
        "support_confirmation_status": get_current_support_confirmation_status_payload(),
        "manual_selection_rule": get_manual_selection_rule_payload(),
        "manual_selection_status": get_current_manual_selection_status_payload(),
    }


@router.get("/debug/support-confirmation")
async def debug_support_confirmation():
    """
    Returns current Opening Range support-confirmation debug payload.
    """

    return {
        "status": "success",
        "support_confirmation_rule": get_support_confirmation_rule_payload(),
        "support_confirmation_status": get_current_support_confirmation_status_payload(),
        "live_ema_calculation": get_live_ema_calculation_mode_payload(),
        "ema_order_side_rule": get_ema_order_side_rule_payload(),
        "manual_selection_rule": get_manual_selection_rule_payload(),
        "manual_selection_status": get_current_manual_selection_status_payload(),
    }


@router.get("/debug/manual-selection")
async def debug_manual_selection():
    """
    Returns current manual / hard selected instrument debug payload.
    """

    return {
        "status": "success",
        "manual_selection_rule": get_manual_selection_rule_payload(),
        "manual_selection_status": get_current_manual_selection_status_payload(),
        "support_confirmation_rule": get_support_confirmation_rule_payload(),
        "support_confirmation_status": get_current_support_confirmation_status_payload(),
        "live_ema_calculation": get_live_ema_calculation_mode_payload(),
        "ema_order_side_rule": get_ema_order_side_rule_payload(),
    }


@router.get("/debug/find-option")
async def debug_find_option(
    strike: float = Query(..., description="Strike Price, e.g., 24500"),
    striketype: str = Query(..., description="Option type: ce or pe"),
):
    """
    Debug endpoint to verify whether a specific option exists in options_cache.

    Example:
        http://127.0.0.1:8000/debug/find-option?strike=24500&striketype=ce
    """

    itype = str(striketype).upper()
    cache_data = options_cache.get("data", [])

    matches = []

    for item in cache_data:
        item_strike = item.get("strike_price")
        item_type = item.get("instrument_type")

        try:
            if float(item_strike) == float(strike) and str(item_type).upper() == itype:
                matches.append(item)
        except Exception:
            continue

    return {
        "search": {
            "strike": strike,
            "striketype": itype,
        },
        "matches_count": len(matches),
        "matches": matches,
        "live_ema_calculation": get_live_ema_calculation_mode_payload(),
        "ema_order_side_rule": get_ema_order_side_rule_payload(),
        "support_confirmation_rule": get_support_confirmation_rule_payload(),
        "support_confirmation_status": get_current_support_confirmation_status_payload(),
        "manual_selection_rule": get_manual_selection_rule_payload(),
        "manual_selection_status": get_current_manual_selection_status_payload(),
    }
