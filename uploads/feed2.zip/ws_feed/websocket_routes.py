import asyncio
from datetime import datetime, timezone

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Query

from core import config
from core.logger import get_logger
from services.option_service import options_cache
from ws_feed.broadcaster import broadcaster

try:
    from services.opening_range_service import (
        get_support_confirmation_status,
        get_effective_selected_instrument_status,
        get_manual_selected_instrument_state,
        get_automatic_selected_or_instrument_state,
        get_effective_isolated_instrument_state,
        get_effective_isolated_instrument_source,
    )
except Exception:
    get_support_confirmation_status = None
    get_effective_selected_instrument_status = None
    get_manual_selected_instrument_state = None
    get_automatic_selected_or_instrument_state = None
    get_effective_isolated_instrument_state = None
    get_effective_isolated_instrument_source = None


logger = get_logger(__file__)

router = APIRouter()


# ============================================================
# Helper: Live EMA Calculation Mode
# ============================================================


def get_live_ema_calculation_mode_text() -> str:
    """
    Returns configured live EMA calculation mode.

    LIVE_EMA_CALCULATION_MODE = False
        completed candle close based EMA calculation.

    LIVE_EMA_CALCULATION_MODE = True
        live tick/LTP based EMA calculation.
    """

    return (
        "tick_ltp"
        if bool(getattr(config, "LIVE_EMA_CALCULATION_MODE", False))
        else "candle_close"
    )


def get_live_ema_calculation_mode_payload() -> dict:
    """Returns live EMA calculation mode payload for websocket connection messages."""

    flag = bool(getattr(config, "LIVE_EMA_CALCULATION_MODE", False))
    mode = get_live_ema_calculation_mode_text()

    return {
        "flag": flag,
        "mode": mode,
        "description": (
            "live tick/LTP based EMA calculation"
            if flag
            else "completed candle close based EMA calculation"
        ),
    }


# ============================================================
# Helper: Opening Range / Manual Selection Status Payloads
# ============================================================


def get_support_confirmation_rule_payload() -> dict:
    """
    Returns Opening Range support confirmation rule payload.
    """

    return {
        "enabled": bool(
            getattr(config, "OPENING_RANGE_SUPPORT_CONFIRMATION_ENABLED", True)
        ),
        "mode": "support_confirmation_flow",
        "description": (
            "R3 and R2 are resistance triggers only when support confirmation is enabled. "
            "R3 waits for opposite-side S3 support confirmation. R2 waits for "
            "opposite-side S2 support confirmation. After S2 touches, the system waits "
            "for S3 upgrade. If S3 touches inside the wait window, S3 is isolated. "
            "If S3 does not touch inside the wait window, S2 is isolated after timeout."
        ),
        "rules": {
            "r3": {
                "trigger_level": "R3",
                "direct_isolation": False,
                "required_confirmation": "opposite_side_S3",
                "final_isolation_level": "S3",
                "enabled": bool(
                    getattr(config, "OPENING_RANGE_R3_REQUIRES_S3_CONFIRMATION", True)
                ),
            },
            "r2": {
                "trigger_level": "R2",
                "direct_isolation": False,
                "required_confirmation": "opposite_side_S2",
                "provisional_level": "S2",
                "upgrade_level": "S3",
                "wait_minutes": int(
                    getattr(config, "OPENING_RANGE_S2_TO_S3_WAIT_MINUTES", 15)
                ),
                "final_if_s3_within_window": "S3",
                "final_if_no_s3_within_window": "S2",
                "enabled": bool(
                    getattr(config, "OPENING_RANGE_R2_REQUIRES_S2_CONFIRMATION", True)
                ),
            },
        },
        "eod": {
            "hour": int(
                getattr(config, "OPENING_RANGE_SUPPORT_CONFIRMATION_EOD_HOUR", 15)
            ),
            "minute": int(
                getattr(config, "OPENING_RANGE_SUPPORT_CONFIRMATION_EOD_MINUTE", 30)
            ),
            "message_enabled": bool(
                getattr(
                    config,
                    "OPENING_RANGE_SUPPORT_CONFIRMATION_EOD_MESSAGE_ENABLED",
                    True,
                )
            ),
        },
        "timeout_check": {
            "interval_minutes": int(
                getattr(
                    config,
                    "OPENING_RANGE_SUPPORT_CONFIRMATION_TIMEOUT_CHECK_INTERVAL_MINUTES",
                    1,
                )
            ),
            "scheduler_required": True,
        },
    }


def get_manual_selection_rule_payload() -> dict:
    """
    Returns manual / hard selected instrument rule payload.
    """

    return {
        "enabled": bool(
            getattr(config, "TELEGRAM_MANUAL_INSTRUMENT_SELECTION_ENABLED", True)
        ),
        "manual_selection_overrides_auto": bool(
            getattr(config, "MANUAL_INSTRUMENT_SELECTION_OVERRIDES_AUTO", True)
        ),
        "reset_daily": bool(
            getattr(config, "MANUAL_INSTRUMENT_SELECTION_RESET_DAILY", True)
        ),
        "mode": "manual_or_hard_selected_instrument",
        "description": (
            "Manual selection allows one instrument to be selected for isolated EMA "
            "Telegram alerts. Hard select force-locks one instrument. When manual "
            "override is active, automatic Opening Range support-confirmation isolation "
            "does not replace the effective selected instrument."
        ),
        "modes": {
            "manual_select": {
                "description": (
                    "Manual selected instrument becomes effective when "
                    "MANUAL_INSTRUMENT_SELECTION_OVERRIDES_AUTO=True."
                ),
                "can_be_replaced_by_new_manual_select": True,
            },
            "hard_select": {
                "description": (
                    "Hard selected instrument is treated as the strongest manual override."
                ),
                "can_be_replaced_by_new_hard_select": True,
            },
            "clear": {
                "description": (
                    "Clears manual / hard selection. If an automatic isolated instrument "
                    "exists, the system falls back to it. Otherwise no effective isolated "
                    "instrument remains selected."
                ),
            },
        },
    }


def get_current_support_confirmation_status_payload() -> dict:
    """
    Returns current support confirmation status if opening_range_service is importable.
    """

    if not get_support_confirmation_status:
        return {
            "status": "unavailable",
            "message": "get_support_confirmation_status could not be imported.",
        }

    try:
        return get_support_confirmation_status()

    except Exception as ex:
        return {
            "status": "error",
            "error": f"{type(ex).__name__}: {ex}",
        }


def get_current_manual_selection_status_payload() -> dict:
    """
    Returns current manual / hard selected instrument status if opening_range_service is importable.
    """

    if not get_effective_selected_instrument_status:
        return {
            "status": "unavailable",
            "message": "manual selection helpers could not be imported.",
        }

    try:
        return {
            "status": "success",
            "manual_selection": get_effective_selected_instrument_status(),
            "manual_selected_instrument": (
                get_manual_selected_instrument_state()
                if get_manual_selected_instrument_state
                else None
            ),
            "automatic_isolated_instrument": (
                get_automatic_selected_or_instrument_state()
                if get_automatic_selected_or_instrument_state
                else None
            ),
            "effective_isolated_instrument": (
                get_effective_isolated_instrument_state()
                if get_effective_isolated_instrument_state
                else None
            ),
            "effective_isolated_instrument_source": (
                get_effective_isolated_instrument_source()
                if get_effective_isolated_instrument_source
                else "unknown"
            ),
        }

    except Exception as ex:
        return {
            "status": "error",
            "error": f"{type(ex).__name__}: {ex}",
        }


# ============================================================
# Helper: Resolve Instrument Key
# ============================================================


def resolve_instrument_key(
    instrument_key: str | None = None,
    strike: float | None = None,
    striketype: str | None = None,
) -> str | None:
    """
    Resolves instrument key.

    Supports:
    1. Direct instrument_key
       Example:
           NSE_INDEX|Nifty 50
           NSE_FO|41012

    2. strike + striketype
       Example:
           strike=24500, striketype=ce
    """

    if instrument_key:
        return instrument_key

    if strike is None or not striketype:
        return None

    option_type = str(striketype).upper()

    if option_type not in ["CE", "PE"]:
        return None

    cache_data = options_cache.get("data", [])

    for item in cache_data:
        try:
            item_strike = item.get("strike_price")
            item_type = str(item.get("instrument_type", "")).upper()

            if float(item_strike) == float(strike) and item_type == option_type:
                return item.get("instrument_key")

        except Exception:
            continue

    return None


def resolve_ema_instrument_key(
    instrument_key: str | None = None,
    strike: float | None = None,
    striketype: str | None = None,
) -> str | None:
    """Resolves EMA crossover instrument key."""

    return resolve_instrument_key(
        instrument_key=instrument_key,
        strike=strike,
        striketype=striketype,
    )


def resolve_opening_range_instrument_key(
    instrument_key: str | None = None,
    strike: float | None = None,
    striketype: str | None = None,
) -> str | None:
    """Resolves Opening Range instrument key."""

    return resolve_instrument_key(
        instrument_key=instrument_key,
        strike=strike,
        striketype=striketype,
    )


# ============================================================
# Common WebSocket Payload Helpers
# ============================================================


def build_common_connection_context() -> dict:
    """
    Shared context sent during websocket connects / pings.
    """

    return {
        "live_ema_calculation": get_live_ema_calculation_mode_payload(),
        "support_confirmation_rule": get_support_confirmation_rule_payload(),
        "support_confirmation_status": get_current_support_confirmation_status_payload(),
        "manual_selection_rule": get_manual_selection_rule_payload(),
        "manual_selection_status": get_current_manual_selection_status_payload(),
        "ema_opening_range_enrichment": getattr(
            config,
            "EMA_CROSS_INCLUDE_OPENING_RANGE_LEVELS",
            True,
        ),
        "telegram_ema_alerts": "effective_isolated_or_manual_instrument_only",
    }


# ============================================================
# All Feeds WebSocket
# ============================================================


@router.websocket("/ws")
@router.websocket("/all-feeds")
async def websocket_all_feeds(websocket: WebSocket):
    """
    WebSocket endpoint returning live market feeds for all loaded contracts.

    This can receive:
    - live tick events
    - live EMA crossover events
    - Opening Range touch events

    Current flow:
    - EMA calculation runs for all initialized instruments.
    - EMA calculation mode is controlled by LIVE_EMA_CALCULATION_MODE.
    - EMA WebSocket events are broadcast for all instruments.
    - Telegram EMA alerts are restricted to the effective isolated instrument.
    - Effective isolated instrument may be automatic support-confirmation selection,
      manual selection, or hard selection.
    """

    logger.info(f"Incoming websocket request for /all-feeds from {websocket.client}")

    try:
        await websocket.accept()
        logger.info("WebSocket accepted for /all-feeds")

        if hasattr(broadcaster, "connect_all_feeds"):
            await broadcaster.connect_all_feeds(websocket)
        else:
            await broadcaster.connect(websocket)

        await websocket.send_json(
            {
                "type": "connected",
                "endpoint": "/all-feeds",
                "message": (
                    "Connected to all feeds websocket. Waiting for live ticks, "
                    "EMA crossover events, and Opening Range events."
                ),
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "subscribed_instruments": len(options_cache.get("subscribed_keys", [])),
                "ema_broadcast_scope": "all_instruments",
                "opening_range_isolated_instrument_flow": getattr(
                    config,
                    "OPENING_RANGE_ISOLATED_INSTRUMENT_ENABLED",
                    True,
                ),
                **build_common_connection_context(),
            }
        )

        while True:
            try:
                client_message = await asyncio.wait_for(
                    websocket.receive_text(),
                    timeout=30,
                )

                if client_message:
                    await websocket.send_json(
                        {
                            "type": "client_message_received",
                            "endpoint": "/all-feeds",
                            "message": client_message,
                            "timestamp": datetime.now(timezone.utc).isoformat(),
                            **build_common_connection_context(),
                        }
                    )

            except asyncio.TimeoutError:
                await websocket.send_json(
                    {
                        "type": "ping",
                        "endpoint": "/all-feeds",
                        "message": (
                            "WebSocket alive. Waiting for live ticks, EMA crossover "
                            "events, and Opening Range events."
                        ),
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                        **build_common_connection_context(),
                    }
                )

    except WebSocketDisconnect:
        logger.info("Client disconnected from /all-feeds websocket")

    except Exception as ex:
        logger.error(f"/all-feeds websocket error: {type(ex).__name__}: {ex}")

    finally:
        if hasattr(broadcaster, "disconnect_all_feeds"):
            broadcaster.disconnect_all_feeds(websocket)
        else:
            broadcaster.disconnect(websocket)


# ============================================================
# Option WebSocket
# ============================================================


@router.websocket("/option")
async def websocket_option(
    websocket: WebSocket,
    strike: float = Query(..., description="Strike Price, e.g., 24500"),
    striketype: str = Query(..., description="Option type: ce or pe"),
):
    """
    WebSocket endpoint filtering live feeds by strike price and CE/PE.

    This endpoint can receive:
    - matching live option ticks
    - matching EMA crossover events
    - matching Opening Range events

    Telegram EMA alerts are not sent from this WebSocket route.
    Telegram EMA alerts are sent only for the effective isolated instrument.
    """

    itype = str(striketype).upper()

    logger.info(
        f"Incoming websocket request for /option from {websocket.client}. "
        f"strike={strike}, striketype={itype}"
    )

    if itype not in ["CE", "PE"]:
        try:
            await websocket.accept()
            await websocket.send_json(
                {
                    "type": "error",
                    "endpoint": "/option",
                    "message": "Invalid striketype. Value must be 'ce' or 'pe'.",
                    "received": striketype,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    **build_common_connection_context(),
                }
            )
            await websocket.close(code=1008, reason="striketype must be 'ce' or 'pe'")

        except Exception as ex:
            logger.error(
                f"Error while closing invalid /option websocket: "
                f"{type(ex).__name__}: {ex}"
            )

        return

    try:
        await websocket.accept()
        logger.info(f"WebSocket accepted for /option {strike}_{itype}")

        if hasattr(broadcaster, "connect_option"):
            await broadcaster.connect_option(
                websocket,
                strike_price=strike,
                instrument_type=itype,
            )
        else:
            await broadcaster.connect(websocket)

        logger.info(f"Option client registered for {strike}_{itype}")

        await websocket.send_json(
            {
                "type": "connected",
                "endpoint": "/option",
                "strike": strike,
                "striketype": itype,
                "message": (
                    "Connected to option websocket. Waiting for matching option ticks, "
                    "EMA crossover events, and Opening Range events."
                ),
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "ema_broadcast_scope": "matching_option_and_all_feeds",
                **build_common_connection_context(),
            }
        )

        while True:
            try:
                client_message = await asyncio.wait_for(
                    websocket.receive_text(),
                    timeout=30,
                )

                if client_message:
                    await websocket.send_json(
                        {
                            "type": "client_message_received",
                            "endpoint": "/option",
                            "strike": strike,
                            "striketype": itype,
                            "message": client_message,
                            "timestamp": datetime.now(timezone.utc).isoformat(),
                            **build_common_connection_context(),
                        }
                    )

            except asyncio.TimeoutError:
                await websocket.send_json(
                    {
                        "type": "ping",
                        "endpoint": "/option",
                        "strike": strike,
                        "striketype": itype,
                        "message": (
                            "WebSocket alive. Waiting for matching option ticks, "
                            "EMA crossover events, and Opening Range events."
                        ),
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                        **build_common_connection_context(),
                    }
                )

    except WebSocketDisconnect:
        logger.info(f"Client disconnected from /option websocket: {strike}_{itype}")

    except Exception as ex:
        logger.error(
            f"/option websocket error for {strike}_{itype}: "
            f"{type(ex).__name__}: {ex}"
        )

    finally:
        if hasattr(broadcaster, "disconnect_option"):
            broadcaster.disconnect_option(websocket, strike, itype)
        else:
            broadcaster.disconnect(websocket)


# ============================================================
# Global EMA Crossover WebSocket
# ============================================================


@router.websocket("/ws/ema-crossover")
async def websocket_ema_crossover(websocket: WebSocket):
    """
    Dedicated WebSocket endpoint streaming real-time EMA crossover events.

    Current flow:
    - Receives EMA crossover events for all initialized instruments.
    - Events are not filtered by isolated instrument.
    - Telegram EMA alerts are restricted to the effective isolated instrument.
    """

    logger.info(
        f"Incoming websocket request for /ws/ema-crossover from {websocket.client}"
    )

    try:
        await websocket.accept()
        logger.info("WebSocket accepted for /ws/ema-crossover")

        if hasattr(broadcaster, "connect_ema_crossover"):
            await broadcaster.connect_ema_crossover(websocket)
        else:
            await broadcaster.connect(websocket)

        await websocket.send_json(
            {
                "type": "connected",
                "endpoint": "/ws/ema-crossover",
                "message": (
                    "Connected to EMA Crossover feed. Waiting for EMA crossover "
                    "signals enriched with Opening Range levels when available."
                ),
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "scope": "all_instruments",
                "isolated_instrument_filtering": "not_applied_to_websocket",
                "opening_range_isolated_instrument_flow": getattr(
                    config,
                    "OPENING_RANGE_ISOLATED_INSTRUMENT_ENABLED",
                    True,
                ),
                **build_common_connection_context(),
            }
        )

        while True:
            try:
                client_message = await asyncio.wait_for(
                    websocket.receive_text(),
                    timeout=30,
                )

                if client_message:
                    await websocket.send_json(
                        {
                            "type": "client_message_received",
                            "endpoint": "/ws/ema-crossover",
                            "message": client_message,
                            "timestamp": datetime.now(timezone.utc).isoformat(),
                            **build_common_connection_context(),
                        }
                    )

            except asyncio.TimeoutError:
                await websocket.send_json(
                    {
                        "type": "ping",
                        "endpoint": "/ws/ema-crossover",
                        "message": (
                            "WebSocket alive. Waiting for EMA crossover signals "
                            "with Opening Range context."
                        ),
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                        **build_common_connection_context(),
                    }
                )

    except WebSocketDisconnect:
        logger.info("Client disconnected from /ws/ema-crossover websocket")

    except Exception as ex:
        logger.error(f"/ws/ema-crossover websocket error: {type(ex).__name__}: {ex}")

    finally:
        if hasattr(broadcaster, "disconnect_ema_crossover"):
            broadcaster.disconnect_ema_crossover(websocket)
        else:
            broadcaster.disconnect(websocket)


# ============================================================
# Instrument-Specific EMA Crossover WebSocket
# ============================================================


@router.websocket("/ws/ema-crossover/instrument")
async def websocket_ema_crossover_instrument(
    websocket: WebSocket,
    instrument_key: str = Query(
        default=None,
        description="Instrument key, e.g. NSE_INDEX|Nifty 50 or NSE_FO|41012",
    ),
    strike: float = Query(
        default=None,
        description="Option strike price, e.g. 24500. Optional if instrument_key is provided.",
    ),
    striketype: str = Query(
        default=None,
        description="Option type: ce or pe. Optional if instrument_key is provided.",
    ),
):
    """
    Dedicated WebSocket endpoint for one instrument's live EMA crossover events.

    Supports:
        /ws/ema-crossover/instrument?instrument_key=NSE_INDEX%7CNifty%2050
        /ws/ema-crossover/instrument?instrument_key=NSE_FO%7C41012
        /ws/ema-crossover/instrument?strike=24500&striketype=ce
        /ws/ema-crossover/instrument?strike=24500&striketype=pe
    """

    resolved_instrument_key = resolve_ema_instrument_key(
        instrument_key=instrument_key,
        strike=strike,
        striketype=striketype,
    )

    logger.info(
        f"Incoming websocket request for /ws/ema-crossover/instrument from "
        f"{websocket.client}. "
        f"instrument_key={instrument_key}, "
        f"strike={strike}, "
        f"striketype={striketype}, "
        f"resolved_instrument_key={resolved_instrument_key}"
    )

    if not resolved_instrument_key:
        try:
            await websocket.accept()

            await websocket.send_json(
                {
                    "type": "error",
                    "endpoint": "/ws/ema-crossover/instrument",
                    "message": (
                        "Unable to resolve instrument. Provide either instrument_key "
                        "or valid strike + striketype."
                    ),
                    "input": {
                        "instrument_key": instrument_key,
                        "strike": strike,
                        "striketype": striketype,
                    },
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    **build_common_connection_context(),
                }
            )

            await websocket.close(
                code=1008,
                reason="Unable to resolve EMA crossover instrument",
            )

        except Exception as ex:
            logger.error(
                f"Error while closing unresolved EMA instrument websocket: "
                f"{type(ex).__name__}: {ex}"
            )

        return

    try:
        await websocket.accept()

        logger.info(
            f"WebSocket accepted for /ws/ema-crossover/instrument. "
            f"resolved_instrument_key={resolved_instrument_key}"
        )

        if hasattr(broadcaster, "connect_ema_instrument"):
            await broadcaster.connect_ema_instrument(
                websocket=websocket,
                instrument_key=resolved_instrument_key,
            )
        else:
            await broadcaster.connect(websocket)

        await websocket.send_json(
            {
                "type": "connected",
                "endpoint": "/ws/ema-crossover/instrument",
                "message": (
                    "Connected to instrument-specific EMA crossover feed. "
                    "Waiting for EMA crossover signals enriched with Opening Range "
                    "levels when available."
                ),
                "instrument_key": resolved_instrument_key,
                "input": {
                    "instrument_key": instrument_key,
                    "strike": strike,
                    "striketype": striketype,
                },
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "scope": "single_instrument",
                "isolated_instrument_filtering": "not_applied_to_websocket",
                "telegram_ema_alerts": "only_if_this_instrument_is_effective_selected",
                **build_common_connection_context(),
            }
        )

        while True:
            try:
                client_message = await asyncio.wait_for(
                    websocket.receive_text(),
                    timeout=30,
                )

                if client_message:
                    await websocket.send_json(
                        {
                            "type": "client_message_received",
                            "endpoint": "/ws/ema-crossover/instrument",
                            "instrument_key": resolved_instrument_key,
                            "message": client_message,
                            "timestamp": datetime.now(timezone.utc).isoformat(),
                            **build_common_connection_context(),
                        }
                    )

            except asyncio.TimeoutError:
                await websocket.send_json(
                    {
                        "type": "ping",
                        "endpoint": "/ws/ema-crossover/instrument",
                        "instrument_key": resolved_instrument_key,
                        "message": (
                            "WebSocket alive. Waiting for instrument-specific "
                            "EMA crossover signals with Opening Range context."
                        ),
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                        **build_common_connection_context(),
                    }
                )

    except WebSocketDisconnect:
        logger.info(
            f"Client disconnected from /ws/ema-crossover/instrument websocket. "
            f"instrument_key={resolved_instrument_key}"
        )

    except Exception as ex:
        logger.error(
            f"/ws/ema-crossover/instrument websocket error for "
            f"{resolved_instrument_key}: {type(ex).__name__}: {ex}"
        )

    finally:
        if hasattr(broadcaster, "disconnect_ema_instrument"):
            broadcaster.disconnect_ema_instrument(
                websocket=websocket,
                instrument_key=resolved_instrument_key,
            )
        else:
            broadcaster.disconnect(websocket)


# ============================================================
# Global Opening Range WebSocket
# ============================================================


@router.websocket("/ws/opening-range")
async def websocket_opening_range(websocket: WebSocket):
    """
    Dedicated WebSocket endpoint streaming Opening Range events.

    Current flow:
    - Receives Opening Range events for all instruments.
    - Touch events can be used for automatic isolated instrument selection.
    - Manual / hard selected instrument may override automatic isolation.
    """

    logger.info(
        f"Incoming websocket request for /ws/opening-range from {websocket.client}"
    )

    try:
        await websocket.accept()
        logger.info("WebSocket accepted for /ws/opening-range")

        if hasattr(broadcaster, "connect_opening_range"):
            await broadcaster.connect_opening_range(websocket)
        else:
            await broadcaster.connect(websocket)

        await websocket.send_json(
            {
                "type": "connected",
                "endpoint": "/ws/opening-range",
                "message": (
                    "Connected to Opening Range feed. Waiting for Opening Range "
                    "events for all instruments."
                ),
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "scope": "all_instruments",
                "isolated_instrument_flow": getattr(
                    config,
                    "OPENING_RANGE_ISOLATED_INSTRUMENT_ENABLED",
                    True,
                ),
                "touch_levels_for_isolation": getattr(
                    config,
                    "OPENING_RANGE_ISOLATION_TOUCH_LEVELS",
                    ["R2", "R3", "S2", "S3"],
                ),
                "priority_levels": getattr(
                    config,
                    "OPENING_RANGE_ISOLATION_PRIORITY_LEVELS",
                    ["S3", "S2", "R3", "R2"],
                ),
                **build_common_connection_context(),
            }
        )

        while True:
            try:
                client_message = await asyncio.wait_for(
                    websocket.receive_text(),
                    timeout=30,
                )

                if client_message:
                    await websocket.send_json(
                        {
                            "type": "client_message_received",
                            "endpoint": "/ws/opening-range",
                            "message": client_message,
                            "timestamp": datetime.now(timezone.utc).isoformat(),
                            **build_common_connection_context(),
                        }
                    )

            except asyncio.TimeoutError:
                await websocket.send_json(
                    {
                        "type": "ping",
                        "endpoint": "/ws/opening-range",
                        "message": "WebSocket alive. Waiting for Opening Range events.",
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                        **build_common_connection_context(),
                    }
                )

    except WebSocketDisconnect:
        logger.info("Client disconnected from /ws/opening-range websocket")

    except Exception as ex:
        logger.error(f"/ws/opening-range websocket error: {type(ex).__name__}: {ex}")

    finally:
        if hasattr(broadcaster, "disconnect_opening_range"):
            broadcaster.disconnect_opening_range(websocket)
        else:
            broadcaster.disconnect(websocket)


# ============================================================
# Instrument-Specific Opening Range WebSocket
# ============================================================


@router.websocket("/ws/opening-range/instrument")
async def websocket_opening_range_instrument(
    websocket: WebSocket,
    instrument_key: str = Query(
        default=None,
        description="Instrument key, e.g. NSE_INDEX|Nifty 50 or NSE_FO|41012",
    ),
    strike: float = Query(
        default=None,
        description="Option strike price, e.g. 24500. Optional if instrument_key is provided.",
    ),
    striketype: str = Query(
        default=None,
        description="Option type: ce or pe. Optional if instrument_key is provided.",
    ),
):
    """
    Dedicated WebSocket endpoint for one instrument's Opening Range events.

    Supports:
        /ws/opening-range/instrument?instrument_key=NSE_INDEX%7CNifty%2050
        /ws/opening-range/instrument?instrument_key=NSE_FO%7C41012
        /ws/opening-range/instrument?strike=24500&striketype=ce
        /ws/opening-range/instrument?strike=24500&striketype=pe
    """

    resolved_instrument_key = resolve_opening_range_instrument_key(
        instrument_key=instrument_key,
        strike=strike,
        striketype=striketype,
    )

    logger.info(
        f"Incoming websocket request for /ws/opening-range/instrument from "
        f"{websocket.client}. "
        f"instrument_key={instrument_key}, "
        f"strike={strike}, "
        f"striketype={striketype}, "
        f"resolved_instrument_key={resolved_instrument_key}"
    )

    if not resolved_instrument_key:
        try:
            await websocket.accept()

            await websocket.send_json(
                {
                    "type": "error",
                    "endpoint": "/ws/opening-range/instrument",
                    "message": (
                        "Unable to resolve instrument. Provide either instrument_key "
                        "or valid strike + striketype."
                    ),
                    "input": {
                        "instrument_key": instrument_key,
                        "strike": strike,
                        "striketype": striketype,
                    },
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    **build_common_connection_context(),
                }
            )

            await websocket.close(
                code=1008,
                reason="Unable to resolve Opening Range instrument",
            )

        except Exception as ex:
            logger.error(
                f"Error while closing unresolved Opening Range instrument websocket: "
                f"{type(ex).__name__}: {ex}"
            )

        return

    try:
        await websocket.accept()

        logger.info(
            f"WebSocket accepted for /ws/opening-range/instrument. "
            f"resolved_instrument_key={resolved_instrument_key}"
        )

        if hasattr(broadcaster, "connect_opening_range_instrument"):
            await broadcaster.connect_opening_range_instrument(
                websocket=websocket,
                instrument_key=resolved_instrument_key,
            )
        else:
            await broadcaster.connect(websocket)

        await websocket.send_json(
            {
                "type": "connected",
                "endpoint": "/ws/opening-range/instrument",
                "message": (
                    "Connected to instrument-specific Opening Range feed. "
                    "Waiting for Opening Range events."
                ),
                "instrument_key": resolved_instrument_key,
                "input": {
                    "instrument_key": instrument_key,
                    "strike": strike,
                    "striketype": striketype,
                },
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "scope": "single_instrument",
                "isolated_instrument_flow": getattr(
                    config,
                    "OPENING_RANGE_ISOLATED_INSTRUMENT_ENABLED",
                    True,
                ),
                "telegram_ema_alerts": "only_if_this_instrument_is_effective_selected",
                **build_common_connection_context(),
            }
        )

        while True:
            try:
                client_message = await asyncio.wait_for(
                    websocket.receive_text(),
                    timeout=30,
                )

                if client_message:
                    await websocket.send_json(
                        {
                            "type": "client_message_received",
                            "endpoint": "/ws/opening-range/instrument",
                            "instrument_key": resolved_instrument_key,
                            "message": client_message,
                            "timestamp": datetime.now(timezone.utc).isoformat(),
                            **build_common_connection_context(),
                        }
                    )

            except asyncio.TimeoutError:
                await websocket.send_json(
                    {
                        "type": "ping",
                        "endpoint": "/ws/opening-range/instrument",
                        "instrument_key": resolved_instrument_key,
                        "message": (
                            "WebSocket alive. Waiting for instrument-specific "
                            "Opening Range events."
                        ),
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                        **build_common_connection_context(),
                    }
                )

    except WebSocketDisconnect:
        logger.info(
            f"Client disconnected from /ws/opening-range/instrument websocket. "
            f"instrument_key={resolved_instrument_key}"
        )

    except Exception as ex:
        logger.error(
            f"/ws/opening-range/instrument websocket error for "
            f"{resolved_instrument_key}: {type(ex).__name__}: {ex}"
        )

    finally:
        if hasattr(broadcaster, "disconnect_opening_range_instrument"):
            broadcaster.disconnect_opening_range_instrument(
                websocket=websocket,
                instrument_key=resolved_instrument_key,
            )
        else:
            broadcaster.disconnect(websocket)
