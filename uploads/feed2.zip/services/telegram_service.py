import html
from datetime import datetime
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

import requests

from core import config
from core.logger import get_logger

logger = get_logger(__file__)


class TelegramService:
    """
    Telegram notification service.

    Used for sending project lifecycle, scheduler, token, instrument,
    subscription, refresh, Opening Range job status, support confirmation,
    isolated instrument selection, isolated EMA crossover alerts, shutdown,
    and error notifications.

    Current behavior:
    - Normal main-flow Telegram notifications remain unchanged.
    - Sends Telegram notification when an Opening Range resistance trigger is found.
    - Sends Telegram notification when S2 becomes provisional support candidate.
    - Sends Telegram notification when final support instrument is isolated.
    - Sends optional EOD warning when no final support confirmation is selected.
    - Sends EMA Telegram alerts only for the isolated instrument.
    - Other instruments can continue live EMA processing and WebSocket broadcast,
      but should not trigger Telegram EMA alerts.

    Support confirmation behavior:
    - R3 touch is resistance trigger only.
    - After R3 touch, wait for opposite-side S3 support confirmation.
    - R2 touch is resistance trigger only.
    - After R2 touch, wait for opposite-side S2 support confirmation.
    - After S2 touch, wait configured minutes for S3 upgrade.
    - If S3 touches inside the wait window, isolate S3.
    - If S3 does not touch inside the wait window, isolate S2.

    Live EMA calculation mode:
    - LIVE_EMA_CALCULATION_MODE=False means completed candle close based EMA.
    - LIVE_EMA_CALCULATION_MODE=True means live tick/LTP based EMA.

    Order-side display behavior:
    - Opening Range service and Option service decide suggested order side.
    - Telegram service only displays isolated side, suggested side, and instruments.
    """

    def __init__(self):
        self.bot_token = config.TELEGRAM_BOT_TOKEN
        self.chat_id = config.TELEGRAM_CHAT_ID
        self.enabled = config.TELEGRAM_ENABLED

        self.timeout_seconds = int(getattr(config, "TELEGRAM_TIMEOUT_SECONDS", 10))

        self.market_timezone = self._load_market_timezone()
        self.market_time_format = getattr(
            config,
            "MARKET_TIME_FORMAT",
            "%Y-%m-%d %H:%M:%S %Z",
        )

        self.api_url = (
            f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
            if self.bot_token
            else None
        )

    def _load_market_timezone(self):
        """Loads market timezone from config, defaulting to Asia/Kolkata."""

        timezone_name = getattr(config, "MARKET_TIMEZONE", "Asia/Kolkata")

        try:
            return ZoneInfo(timezone_name)

        except ZoneInfoNotFoundError:
            logger.error(
                f"Invalid MARKET_TIMEZONE configured: {timezone_name}. "
                "Falling back to Asia/Kolkata."
            )
            return ZoneInfo("Asia/Kolkata")

    def _now_market_time(self) -> str:
        """Returns current market time as formatted string."""

        return datetime.now(self.market_timezone).strftime(self.market_time_format)

    def is_configured(self) -> bool:
        """Returns True if Telegram service has required configuration."""

        return bool(self.enabled and self.bot_token and self.chat_id and self.api_url)

    def _escape(self, value) -> str:
        """Escapes text for Telegram HTML parse mode."""

        return html.escape(str(value), quote=False)

    def _normalize_option_type(self, value) -> str:
        """Normalizes option type for Telegram display."""

        text = str(value or "N/A").strip().upper()

        if text == "CALL":
            return "CE"

        if text == "PUT":
            return "PE"

        if text in ["CE", "PE"]:
            return text

        return text or "N/A"

    def _get_live_ema_calculation_mode(self) -> str:
        """
        Returns configured live EMA calculation mode.

        LIVE_EMA_CALCULATION_MODE=False:
            candle_close

        LIVE_EMA_CALCULATION_MODE=True:
            tick_ltp
        """

        tick_based_mode = bool(getattr(config, "LIVE_EMA_CALCULATION_MODE", False))

        return "tick_ltp" if tick_based_mode else "candle_close"

    def _get_live_ema_calculation_mode_description(
        self,
        mode: str | None = None,
    ) -> str:
        """Returns readable description for EMA calculation mode."""

        mode = mode or self._get_live_ema_calculation_mode()

        if mode == "tick_ltp":
            return "Live tick/LTP based EMA cross detection"

        return "Completed candle close based EMA cross detection"

    def _send_raw_message(self, message: str) -> bool:
        """
        Sends raw HTML message to Telegram.

        Returns:
            True if message was sent successfully, False otherwise.
        """

        if not self.is_configured():
            logger.warning(
                "Telegram notification skipped. "
                "Service is disabled or bot token/chat id is missing."
            )
            return False

        payload = {
            "chat_id": self.chat_id,
            "text": message,
            "parse_mode": "HTML",
            "disable_web_page_preview": True,
        }

        try:
            response = requests.post(
                self.api_url,
                json=payload,
                timeout=self.timeout_seconds,
            )

            if response.status_code != 200:
                logger.error(
                    f"Telegram send failed. "
                    f"status_code={response.status_code}, response={response.text}"
                )
                return False

            logger.info("Telegram notification sent successfully.")
            return True

        except Exception as ex:
            logger.error(f"Telegram send exception: {type(ex).__name__}: {ex}")
            return False

    def send_message(
        self,
        title: str,
        message: str,
        level: str = "INFO",
    ) -> bool:
        """
        Sends a formatted Telegram notification.

        Args:
            title: Notification title.
            message: Notification body.
            level: INFO, SUCCESS, WARNING, ERROR, STARTUP, REFRESH,
                   SUBSCRIPTION, TOKEN, INSTRUMENTS, EMA, OPENING_RANGE.
        """

        level_upper = str(level or "INFO").upper()

        emoji_map = {
            "INFO": "ℹ️",
            "SUCCESS": "✅",
            "WARNING": "⚠️",
            "ERROR": "❌",
            "STARTUP": "🚀",
            "REFRESH": "🔄",
            "SUBSCRIPTION": "📡",
            "TOKEN": "🔐",
            "INSTRUMENTS": "📊",
            "SHUTDOWN": "🛑",
            "EMA": "📈",
            "OPENING_RANGE": "🎯",
            "MANUAL_SELECTION": "📌",
        }
        emoji = emoji_map.get(level_upper, "ℹ️")

        safe_title = self._escape(title)
        safe_message = self._escape(message)
        market_time = self._escape(self._now_market_time())

        formatted_message = (
            f"{emoji} <b>{safe_title}</b>\n\n"
            f"{safe_message}\n\n"
            f"<b>Level:</b> {self._escape(level_upper)}\n"
            f"<b>Time:</b> {market_time}"
        )

        return self._send_raw_message(formatted_message)

    # ========================================================
    # Application Lifecycle Messages
    # ========================================================

    def send_startup_message(self, status: str, details: str = "") -> bool:
        """Sends application startup notification."""

        message = f"Application startup status: {status}"

        if details:
            message += f"\n\n{details}"

        return self.send_message(
            title="Option Feed Engine Startup",
            message=message,
            level="STARTUP",
        )

    def send_shutdown_message(self, details: str = "") -> bool:
        """Sends application shutdown notification."""

        message = "Application shutdown sequence executed."

        if details:
            message += f"\n\n{details}"

        return self.send_message(
            title="Option Feed Engine Shutdown",
            message=message,
            level="SHUTDOWN",
        )

    # ========================================================
    # Token / Instrument / Subscription Messages
    # ========================================================

    def send_token_refresh_message(
        self,
        success: bool,
        updated_at=None,
        error: str = "",
    ) -> bool:
        """Sends token refresh notification."""

        if success:
            message = "Access token document refreshed successfully from MongoDB."

            if updated_at:
                message += f"\nToken Updated At: {updated_at}"

            return self.send_message(
                title="Token Refresh Successful",
                message=message,
                level="TOKEN",
            )

        message = "Access token refresh failed."

        if error:
            message += f"\nError: {error}"

        return self.send_message(
            title="Token Refresh Failed",
            message=message,
            level="ERROR",
        )

    def send_instruments_fetched_message(
        self,
        success: bool,
        nearest_expiry=None,
        total_contracts=0,
        subscribed_keys_count=0,
        strike_from=None,
        strike_to=None,
        error: str = "",
    ) -> bool:
        """Sends option instruments fetch notification."""

        if success:
            message = (
                "Option instruments fetched and cache updated successfully.\n\n"
                f"Nearest Expiry: {nearest_expiry}\n"
                f"Total Contracts: {total_contracts}\n"
                f"Subscribed Keys: {subscribed_keys_count}\n"
                f"Strike Range: {strike_from} to {strike_to}"
            )

            return self.send_message(
                title="Instruments Fetch Successful",
                message=message,
                level="INSTRUMENTS",
            )

        message = "Option instruments fetch failed."

        if error:
            message += f"\nError: {error}"

        return self.send_message(
            title="Instruments Fetch Failed",
            message=message,
            level="ERROR",
        )

    def send_subscription_message(
        self,
        success: bool,
        subscribed_keys_count=0,
        feed_mode=None,
        error: str = "",
    ) -> bool:
        """Sends Upstox subscription or streamer restart notification."""

        if success:
            message = (
                "Upstox streamer subscription is active.\n\n"
                f"Subscribed Instruments: {subscribed_keys_count}\n"
                f"Feed Mode: {feed_mode}"
            )

            return self.send_message(
                title="Feed Subscription Successful",
                message=message,
                level="SUBSCRIPTION",
            )

        message = "Upstox feed subscription failed."

        if error:
            message += f"\nError: {error}"

        return self.send_message(
            title="Feed Subscription Failed",
            message=message,
            level="ERROR",
        )

    # ========================================================
    # Refresh Messages
    # ========================================================

    def send_daily_refresh_message(
        self,
        success: bool,
        subscribed_keys_count=0,
        nearest_expiry=None,
        error: str = "",
    ) -> bool:
        """Sends daily hard refresh notification."""

        if success:
            message = (
                "Daily market hard refresh completed successfully.\n\n"
                f"Nearest Expiry: {nearest_expiry}\n"
                f"Subscribed Instruments: {subscribed_keys_count}"
            )

            return self.send_message(
                title="Daily Market Hard Refresh Successful",
                message=message,
                level="REFRESH",
            )

        message = "Daily market hard refresh failed."

        if error:
            message += f"\nError: {error}"

        return self.send_message(
            title="Daily Market Hard Refresh Failed",
            message=message,
            level="ERROR",
        )

    # ========================================================
    # Opening Range Support Confirmation Messages
    # ========================================================

    def send_support_confirmation_watch_message(
        self,
        trigger_event: dict,
        expected_level: str,
    ) -> bool:
        """
        Sends a support-confirmation watch notification.

        Used when R3 or R2 resistance trigger is detected.
        R2/R3 does not directly isolate when support confirmation is enabled.
        """

        trigger_event = trigger_event or {}
        contract_info = trigger_event.get("contract_info") or {}

        strike = contract_info.get("strike_price", "N/A")
        option_type = self._normalize_option_type(contract_info.get("instrument_type"))
        trigger_level = str(trigger_event.get("level", "N/A")).upper()
        trigger_price = trigger_event.get("trigger_price", "N/A")
        trigger_time = trigger_event.get("touch_time", "N/A")
        instrument_key = trigger_event.get("instrument_key", "N/A")

        message = (
            f"{strike} {option_type} touched {trigger_level}.\n\n"
            f"Trigger Price: {trigger_price}\n"
            f"Touch Time: {trigger_time}\n"
            f"Instrument Key: {instrument_key}\n\n"
            "This is a resistance trigger only.\n"
            f"Waiting for opposite-side {expected_level} support confirmation.\n\n"
            "No isolated EMA Telegram alerts will be sent until final support "
            "confirmation is completed."
        )

        return self.send_message(
            title="Opening Range Resistance Trigger",
            message=message,
            level="OPENING_RANGE",
        )

    def send_s2_provisional_support_message(
        self,
        event: dict,
        wait_until: str,
    ) -> bool:
        """
        Sends notification when S2 becomes provisional support candidate.
        """

        event = event or {}
        contract_info = event.get("contract_info") or {}

        strike = contract_info.get("strike_price", "N/A")
        option_type = self._normalize_option_type(contract_info.get("instrument_type"))
        trigger_price = event.get("trigger_price", "N/A")
        touch_time = event.get("touch_time", "N/A")
        instrument_key = event.get("instrument_key", "N/A")

        wait_minutes = getattr(config, "OPENING_RANGE_S2_TO_S3_WAIT_MINUTES", 15)

        message = (
            f"{strike} {option_type} touched S2.\n\n"
            "S2 is selected as provisional support candidate.\n"
            f"Touch Price: {trigger_price}\n"
            f"Touch Time: {touch_time}\n"
            f"Instrument Key: {instrument_key}\n\n"
            f"Waiting {wait_minutes} minutes for S3 upgrade.\n"
            f"S3 Wait Until: {wait_until}\n\n"
            "If S3 does not touch within this window, this S2 instrument will be isolated."
        )

        return self.send_message(
            title="Opening Range S2 Provisional Candidate",
            message=message,
            level="OPENING_RANGE",
        )

    def send_no_support_confirmation_eod_message(
        self,
        support_state: dict | None = None,
    ) -> bool:
        """
        Sends EOD no-confirmation Telegram message.

        Used when R2/R3 resistance trigger happened but no final S2/S3
        support instrument was isolated before configured EOD time.
        """

        support_state = support_state or {}
        trigger = support_state.get("resistance_trigger_event") or {}
        contract_info = trigger.get("contract_info") or {}

        strike = contract_info.get("strike_price", "N/A")
        option_type = self._normalize_option_type(contract_info.get("instrument_type"))
        level = trigger.get("level", "N/A")
        phase = support_state.get("phase", "N/A")
        state_message = support_state.get("message", "N/A")

        message = (
            "No final support confirmation instrument was selected today.\n\n"
            f"Resistance Trigger: {strike} {option_type} {level}\n"
            f"Current Phase: {phase}\n"
            f"Message: {state_message}\n\n"
            "No isolated EMA Telegram alerts were enabled for the day."
        )

        return self.send_message(
            title="Opening Range No Support Confirmation",
            message=message,
            level="WARNING",
        )

    # ========================================================
    # Opening Range Isolated Instrument Messages
    # ========================================================

    def send_selected_or_instrument_message(
        self,
        instrument_key: str,
        symbol: str,
        level: str,
        level_value,
        trigger_field: str,
        trigger_price,
        touch_time,
        source: str,
        nifty_ltp=None,
        strike_price=None,
        instrument_type=None,
        reference_average=None,
        average_window=None,
        selection_reason=None,
        support_confirmation: dict | None = None,
    ) -> bool:
        """
        Sends Telegram notification when Opening Range support instrument is isolated.

        New selection behavior:
        - R3 waits for opposite-side S3 confirmation.
        - R2 waits for opposite-side S2 confirmation.
        - S2 becomes provisional and waits for S3 upgrade.
        - Final isolated instrument normally comes from S3 or S2.
        """

        if not bool(
            getattr(config, "OPENING_RANGE_ISOLATED_INSTRUMENT_NOTIFY_ENABLED", True)
        ):
            logger.info(
                "Isolated instrument Telegram notification skipped because "
                "OPENING_RANGE_ISOLATED_INSTRUMENT_NOTIFY_ENABLED=False."
            )
            return False

        strike_text = strike_price if strike_price is not None else "N/A"
        type_text = self._normalize_option_type(instrument_type)

        window_text = "not_available"

        if isinstance(average_window, dict):
            window_text = (
                f"{average_window.get('final_lower')} to "
                f"{average_window.get('final_upper')}"
            )

        support_confirmation = support_confirmation or {}
        support_phase = support_confirmation.get("phase", "N/A")
        support_message = support_confirmation.get("message", "N/A")

        ema_mode = self._get_live_ema_calculation_mode()
        ema_mode_description = self._get_live_ema_calculation_mode_description(ema_mode)

        message = (
            "Opening Range support instrument isolated for EMA Telegram alerts.\n\n"
            f"Instrument: {strike_text} {type_text}\n"
            f"Symbol: {symbol}\n"
            f"Instrument Key: {instrument_key}\n"
            f"Selected Level: {level}\n"
            f"Level Value: {level_value}\n"
            f"Trigger {trigger_field}: {trigger_price}\n"
            f"Touch Time: {touch_time}\n"
            f"Touch Source: {source}\n"
            f"Selection Reason: {selection_reason or 'support_confirmation_final_isolation'}\n"
            f"Support Confirmation Phase: {support_phase}\n"
            f"Support Confirmation Message: {support_message}\n"
            f"Reference Average: {reference_average}\n"
            f"Average Window: {window_text}\n"
            f"NIFTY LTP: {nifty_ltp if nifty_ltp is not None else 'not_available'}\n"
            f"EMA Calculation Mode: {ema_mode}\n"
            f"EMA Mode Description: {ema_mode_description}\n\n"
            "From now, Telegram EMA alerts will be sent only for this isolated instrument."
        )

        return self.send_message(
            title="Opening Range Support Instrument Isolated",
            message=message,
            level="OPENING_RANGE",
        )

    def send_selected_or_ema_cross_message(
        self,
        selected_state: dict,
        ema_event: dict,
        nifty_ltp=None,
        suggested_order_instruments: list | None = None,
    ) -> bool:
        """
        Sends EMA crossover Telegram alert for isolated instrument only.

        This service does not decide CE/PE order side.
        Order side is decided before this method is called.

        Expected order-side rule from opening_range_service/option_service:
            bullish_cross:
                Same side as isolated instrument.

            bearish_cross:
                Opposite side of isolated instrument.

        Examples:
            Isolated CE + bullish_cross -> suggested CE instruments.
            Isolated CE + bearish_cross -> suggested PE instruments.
            Isolated PE + bullish_cross -> suggested PE instruments.
            Isolated PE + bearish_cross -> suggested CE instruments.

        Suggested strikes are selected around current NIFTY spot/LTP.
        """

        if not bool(getattr(config, "EMA_ISOLATED_INSTRUMENT_TELEGRAM_ENABLED", True)):
            logger.info(
                "Isolated EMA Telegram notification skipped because "
                "EMA_ISOLATED_INSTRUMENT_TELEGRAM_ENABLED=False."
            )
            return False

        selected_state = selected_state or {}
        ema_event = ema_event or {}
        suggested_order_instruments = suggested_order_instruments or []

        contract_info = (
            selected_state.get("contract_info")
            or ema_event.get("contract_info")
            or ema_event.get("info")
            or {}
        )

        strike = contract_info.get("strike_price", "N/A")
        isolated_instrument_type = self._normalize_option_type(
            contract_info.get("instrument_type", "N/A")
        )

        selected_level = selected_state.get("selected_level", "N/A")

        instrument_key = ema_event.get("instrument_key") or selected_state.get(
            "instrument_key"
        )

        cross_type = ema_event.get("cross_type", "N/A")
        current_signal = ema_event.get("current_signal", "N/A")
        close_price = ema_event.get("close")
        event_timestamp = ema_event.get("timestamp")

        ema_fast = ema_event.get("ema_fast")
        ema_slow = ema_event.get("ema_slow")
        previous_ema_fast = ema_event.get("previous_ema_fast")
        previous_ema_slow = ema_event.get("previous_ema_slow")

        ema_fast_period = ema_event.get(
            "ema_fast_period",
            getattr(config, "LIVE_EMA_FAST_PERIOD", 9),
        )
        ema_slow_period = ema_event.get(
            "ema_slow_period",
            getattr(config, "LIVE_EMA_SLOW_PERIOD", 21),
        )

        ema_mode = ema_event.get(
            "ema_calculation_mode",
            self._get_live_ema_calculation_mode(),
        )

        ema_mode_description = self._get_live_ema_calculation_mode_description(ema_mode)
        source = ema_event.get("source", "live_feed")

        if ema_mode == "tick_ltp":
            price_label = "Live Tick LTP"
            time_label = "Tick Time"
        else:
            price_label = "EMA Candle Close"
            time_label = "EMA Candle Time"

        nifty_text = nifty_ltp if nifty_ltp is not None else "NIFTY_LTP_NOT_AVAILABLE"

        suggested_order_option_type = None

        for item in suggested_order_instruments:
            if not isinstance(item, dict):
                continue

            candidate_type = self._normalize_option_type(item.get("instrument_type"))

            if candidate_type in ["CE", "PE"]:
                suggested_order_option_type = candidate_type
                break

        suggested_order_type_text = (
            suggested_order_option_type
            if suggested_order_option_type
            else "not_available"
        )

        cross_text = str(cross_type or "").strip().lower()

        if "bullish" in cross_text:
            order_side_rule = (
                "Bullish cross uses the same side as the isolated instrument."
            )
        elif "bearish" in cross_text:
            order_side_rule = (
                "Bearish cross uses the opposite side of the isolated instrument."
            )
        else:
            order_side_rule = (
                "Order side could not be resolved because EMA cross type is unknown."
            )

        header = (
            f"{strike} {isolated_instrument_type} - "
            f"crosses {selected_level} - "
            f"At {nifty_text}"
        )

        order_details_text = self._format_suggested_order_instruments(
            suggested_order_instruments
        )

        message = (
            f"{header}\n\n"
            "EMA Cross Details:\n"
            f"Cross Type: {cross_type}\n"
            f"Signal: {current_signal}\n"
            f"Isolated Instrument Type: {isolated_instrument_type}\n"
            f"Suggested Order Side: {suggested_order_type_text}\n"
            f"Order Side Rule: {order_side_rule}\n"
            f"EMA Calculation Mode: {ema_mode}\n"
            f"EMA Mode Description: {ema_mode_description}\n"
            f"Source: {source}\n"
            f"{price_label}: {close_price}\n"
            f"{time_label}: {event_timestamp}\n"
            f"EMA Fast Period: {ema_fast_period}\n"
            f"EMA Slow Period: {ema_slow_period}\n"
            f"EMA Fast: {ema_fast}\n"
            f"EMA Slow: {ema_slow}\n"
            f"Previous EMA Fast: {previous_ema_fast}\n"
            f"Previous EMA Slow: {previous_ema_slow}\n"
            f"Instrument Key: {instrument_key}\n\n"
            f"{order_details_text}"
        )

        logger.info(
            f"Sending isolated EMA Telegram message. "
            f"instrument_key={instrument_key}, "
            f"cross_type={cross_type}, "
            f"isolated_instrument_type={isolated_instrument_type}, "
            f"suggested_order_option_type={suggested_order_option_type}, "
            f"suggested_instruments_count={len(suggested_order_instruments)}"
        )

        return self.send_message(
            title="Isolated Instrument EMA Alert",
            message=message,
            level="EMA",
        )

    def send_isolated_instrument_message(
        self,
        isolated_state: dict,
    ) -> bool:
        """
        Convenience wrapper for isolated instrument notification.

        This allows opening_range_service.py to pass the full isolated state
        instead of individual fields.
        """

        isolated_state = isolated_state or {}
        contract_info = isolated_state.get("contract_info") or {}

        symbol = (
            contract_info.get("trading_symbol")
            or contract_info.get("instrument_key")
            or isolated_state.get("instrument_key")
            or "N/A"
        )

        return self.send_selected_or_instrument_message(
            instrument_key=isolated_state.get("instrument_key"),
            symbol=symbol,
            level=isolated_state.get("selected_level"),
            level_value=isolated_state.get("level_value"),
            trigger_field=isolated_state.get("trigger_field"),
            trigger_price=isolated_state.get("trigger_price"),
            touch_time=isolated_state.get("touch_time"),
            source=isolated_state.get("touch_source"),
            nifty_ltp=isolated_state.get("latest_main_index_ltp"),
            strike_price=contract_info.get("strike_price"),
            instrument_type=contract_info.get("instrument_type"),
            reference_average=isolated_state.get("reference_average"),
            average_window=isolated_state.get("average_window"),
            selection_reason=isolated_state.get("selection_reason"),
        )

    def send_isolated_ema_cross_message(
        self,
        isolated_state: dict,
        ema_event: dict,
        nifty_ltp=None,
        suggested_order_instruments: list | None = None,
    ) -> bool:
        """
        Convenience wrapper for isolated instrument EMA alert.
        """

        return self.send_selected_or_ema_cross_message(
            selected_state=isolated_state,
            ema_event=ema_event,
            nifty_ltp=nifty_ltp,
            suggested_order_instruments=suggested_order_instruments,
        )

   
    # ========================================================
    # Manual / Hard Selected Instrument Messages
    # ========================================================

    def send_manual_selected_instrument_message(
        self,
        selected_state: dict,
    ) -> bool:
        """
        Sends Telegram notification when an instrument is manually selected
        or hard-selected from Telegram.

        This is only a notification helper.
        Actual manual-selection state should be managed by opening_range_service.py.
        """

        selected_state = selected_state or {}
        contract_info = selected_state.get("contract_info") or {}

        instrument_key = selected_state.get("instrument_key", "N/A")
        selection_mode = selected_state.get("selection_mode", "manual_select")
        selection_reason = selected_state.get(
            "selection_reason", "telegram_manual_selection"
        )
        selected_at = selected_state.get("selected_at", "N/A")

        strike = contract_info.get("strike_price", "N/A")
        option_type = self._normalize_option_type(contract_info.get("instrument_type"))
        trading_symbol = (
            contract_info.get("trading_symbol")
            or contract_info.get("instrument_key")
            or instrument_key
            or "N/A"
        )

        latest_ltp = (selected_state.get("latest_live_data") or {}).get("ltp")
        latest_main_index_ltp = selected_state.get("latest_main_index_ltp")

        if selection_mode == "hard_select":
            title = "Hard Selected Instrument Activated"
            mode_text = "HARD SELECT"
            description = (
                "This instrument is now force-locked for isolated EMA Telegram alerts."
            )
        else:
            title = "Manual Selected Instrument Activated"
            mode_text = "MANUAL SELECT"
            description = "This instrument is now manually selected for isolated EMA Telegram alerts."

        message = (
            f"{description}\n\n"
            f"Selection Mode: {mode_text}\n"
            f"Selection Reason: {selection_reason}\n"
            f"Selected At: {selected_at}\n\n"
            f"Instrument: {strike} {option_type}\n"
            f"Symbol: {trading_symbol}\n"
            f"Instrument Key: {instrument_key}\n"
            f"Latest Instrument LTP: {latest_ltp if latest_ltp is not None else 'not_available'}\n"
            f"NIFTY LTP: {latest_main_index_ltp if latest_main_index_ltp is not None else 'not_available'}\n\n"
            "From now, EMA Telegram alerts will be sent only for this selected instrument."
        )

        return self.send_message(
            title=title,
            message=message,
            level="MANUAL_SELECTION",
        )

    def send_manual_selection_cleared_message(
        self,
        effective_state: dict | None = None,
        effective_source: str | None = None,
    ) -> bool:
        """
        Sends Telegram notification when manual or hard selection is cleared.

        If an automatic Opening Range isolated instrument exists, the system can
        fall back to that instrument after manual selection is cleared.
        """

        effective_state = effective_state or {}
        effective_source = effective_source or "none"

        selected = bool(effective_state.get("selected"))
        instrument_key = effective_state.get("instrument_key", "N/A")
        contract_info = effective_state.get("contract_info") or {}

        strike = contract_info.get("strike_price", "N/A")
        option_type = self._normalize_option_type(contract_info.get("instrument_type"))
        trading_symbol = (
            contract_info.get("trading_symbol")
            or contract_info.get("instrument_key")
            or instrument_key
            or "N/A"
        )

        if selected:
            message = (
                "Manual / hard selected instrument has been cleared.\n\n"
                "System has fallen back to the currently effective automatic isolated instrument.\n\n"
                f"Effective Source: {effective_source}\n"
                f"Instrument: {strike} {option_type}\n"
                f"Symbol: {trading_symbol}\n"
                f"Instrument Key: {instrument_key}\n\n"
                "EMA Telegram alerts will now follow the effective isolated instrument."
            )
        else:
            message = (
                "Manual / hard selected instrument has been cleared.\n\n"
                "No automatic isolated instrument is currently active.\n\n"
                f"Effective Source: {effective_source}\n\n"
                "EMA Telegram alerts will remain disabled until a new effective instrument is selected."
            )

        return self.send_message(
            title="Manual Instrument Selection Cleared",
            message=message,
            level="MANUAL_SELECTION",
        )

    def send_manual_selection_failed_message(
        self,
        instrument_key: str | None = None,
        reason: str = "",
    ) -> bool:
        """
        Sends Telegram notification when manual or hard selection fails.
        """

        message = "Manual instrument selection failed."

        if instrument_key:
            message += f"\nInstrument Key: {instrument_key}"

        if reason:
            message += f"\nReason: {reason}"

        return self.send_message(
            title="Manual Instrument Selection Failed",
            message=message,
            level="WARNING",
        )

    def _format_suggested_order_instruments(
        self,
        suggested_order_instruments: list,
    ) -> str:
        """
        Formats nearest CE/PE instruments for EMA alert.

        Example:
            Nearest Instrument Details:
            - 24300PE - 120rs
            - 24350PE - 135rs
            - 24400PE - 150rs
        """

        if not suggested_order_instruments:
            return "Nearest Instrument Details: not_available"

        lines = ["Nearest Instrument Details:"]

        for item in suggested_order_instruments:
            if not isinstance(item, dict):
                continue

            strike = item.get("strike_price", "N/A")
            instrument_type = self._normalize_option_type(item.get("instrument_type"))
            live_ltp = item.get("live_ltp")

            if live_ltp is None:
                price_text = "ltp_not_available"
            else:
                price_text = f"{live_ltp}rs"

            lines.append(f"- {strike}{instrument_type} - {price_text}")

        if len(lines) == 1:
            return "Nearest Instrument Details: not_available"

        return "\n".join(lines)

    # ========================================================
    # Exception Messages
    # ========================================================

    def send_exception_message(
        self,
        title: str,
        exception: Exception,
        context: str = "",
    ) -> bool:
        """Sends exception notification."""

        message = (
            f"Exception Type: {type(exception).__name__}\n"
            f"Exception Message: {exception}"
        )

        if context:
            message = f"Context: {context}\n\n{message}"

        return self.send_message(
            title=title,
            message=message,
            level="ERROR",
        )


telegram_service = TelegramService()
