import json
import time
from collections import deque
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, time as dt_time
from pathlib import Path
from threading import Lock
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

import upstox_client
from upstox_client.rest import ApiException

from core import config
from core.logger import get_logger
from services.option_service import (
    options_cache,
    get_contract_info_by_instrument_key,
    get_nearest_order_instruments_for_ema_cross,
)
from services.telegram_service import telegram_service

logger = get_logger(__file__)

# ============================================================
# Thread-Safe Runtime Cache
# ============================================================

_opening_range_cache_lock = Lock()

opening_range_cache = {
    "last_run_at": None,
    "date": None,
    "status": "not_started",
    "message": "Opening range calculation has not run yet.",
    "source": "intraday_api",
    "interval": None,
    "opening_range_candle_count": 0,
    "market_open_time": None,
    "fetch_time": None,
    "total_instruments": 0,
    "success_count": 0,
    "failed_count": 0,
    "empty_count": 0,
    "insufficient_data_count": 0,
    "output_file_path": None,
    "latest_main_index_ltp": None,
    "latest_main_index_ltp_source": None,
    "latest_main_index_ltp_updated_at": None,
    "touch_events_count": 0,
    "pending_touch_events_count": 0,
    "alert_sent_keys_count": 0,
    "isolated_instrument": None,
    "isolated_instrument_selected": False,
    "isolated_instrument_selected_at": None,
    "isolated_instrument_selection_reason": None,
    "isolated_ema_alerts_count": 0,
    "manual_selected_instrument": None,
    "automatic_isolated_instrument": None,
    "effective_isolated_instrument_source": "none",
    "manual_override_active": False,
    "support_confirmation": None,
    "data": {},
    "touch_events": [],
    "errors": {},
}

_touch_lock = Lock()
_pending_touch_events = deque()
_touch_events = deque(
    maxlen=int(getattr(config, "OPENING_RANGE_MAX_EVENTS_IN_MEMORY", 5000))
)
_alert_sent_keys = set()

_latest_main_index_ltp = None
_latest_main_index_ltp_source = None
_latest_main_index_ltp_updated_at = None
_last_touch_alert_sent_at = None
_latest_ltp_by_instrument = {}
_latest_ltp_updated_at_by_instrument = {}

# ============================================================
# Isolated Instrument State
# ============================================================

_selected_or_lock = Lock()
_selected_or_state_date = None

_SELECTED_OR_DEFAULT_STATE = {
    "selected": False,
    "instrument_key": None,
    "selected_level": None,
    "level_value": None,
    "trigger_price": None,
    "trigger_field": None,
    "touch_time": None,
    "touch_source": None,
    "selected_at": None,
    "selection_priority": None,
    "selection_reason": None,
    "reference_average": None,
    "average_window": None,
    "contract_info": None,
    "range": None,
    "levels": None,
    "latest_live_data": None,
    "latest_main_index_ltp": None,
    "ema_alerts_count": 0,
    "last_ema_alert": None,
    "disabled": False,
    "message": "No isolated Opening Range instrument selected yet.",
}

_selected_or_instrument_state = dict(_SELECTED_OR_DEFAULT_STATE)
_selected_or_ema_alerts = deque(
    maxlen=int(getattr(config, "OPENING_RANGE_MAX_EVENTS_IN_MEMORY", 5000))
)
_selected_or_ema_alert_minute_keys = set()
_selected_or_ema_alert_minute_date = None

# ============================================================
# Telegram Manual / Hard Selected Instrument State
# ============================================================

_manual_selected_or_lock = Lock()
_manual_selected_or_state_date = None

_MANUAL_SELECTED_OR_DEFAULT_STATE = {
    "selected": False,
    "manual_override": False,
    "selection_mode": None,
    "instrument_key": None,
    "contract_info": None,
    "selected_at": None,
    "selection_reason": None,
    "historical_ema_initialized": False,
    "live_ema_initialized": False,
    "subscription_active": False,
    "streamer_restart_required": False,
    "today_latest_crossover": None,
    "last_available_crossover": None,
    "message": "No Telegram manual instrument selected.",
}

_manual_selected_or_instrument_state = dict(_MANUAL_SELECTED_OR_DEFAULT_STATE)

# ============================================================
# Config Defaults
# ============================================================

DEFAULT_OPENING_RANGE_ENABLED = bool(getattr(config, "OPENING_RANGE_ENABLED", True))
DEFAULT_OPENING_RANGE_INTERVAL = getattr(config, "OPENING_RANGE_INTERVAL", "1minute")
DEFAULT_OPENING_RANGE_CANDLE_COUNT = int(
    getattr(config, "OPENING_RANGE_CANDLE_COUNT", 1)
)
DEFAULT_MARKET_OPEN_HOUR = int(getattr(config, "OPENING_RANGE_MARKET_OPEN_HOUR", 9))
DEFAULT_MARKET_OPEN_MINUTE = int(
    getattr(config, "OPENING_RANGE_MARKET_OPEN_MINUTE", 15)
)
DEFAULT_FETCH_HOUR = int(getattr(config, "OPENING_RANGE_FETCH_HOUR", 9))
DEFAULT_FETCH_MINUTE = int(getattr(config, "OPENING_RANGE_FETCH_MINUTE", 18))
DEFAULT_INTRADAY_UNIT = getattr(config, "OPENING_RANGE_INTRADAY_UNIT", "minutes")
DEFAULT_INTRADAY_INTERVAL = getattr(config, "OPENING_RANGE_INTRADAY_INTERVAL", "1")
DEFAULT_MAX_WORKERS = int(getattr(config, "OPENING_RANGE_MAX_WORKERS", 5))
DEFAULT_SLEEP_SECONDS = float(
    getattr(config, "OPENING_RANGE_REQUEST_SLEEP_SECONDS", 0.15)
)
DEFAULT_SAVE_FILE = bool(getattr(config, "OPENING_RANGE_SAVE_FILE", True))
DEFAULT_OUTPUT_FILE = getattr(
    config, "OPENING_RANGE_OUTPUT_FILE", "data/opening_range_results.json"
)
DEFAULT_BACKFILL_SCAN_ENABLED = bool(
    getattr(config, "OPENING_RANGE_BACKFILL_TOUCH_SCAN_ENABLED", True)
)
DEFAULT_TOUCH_ALERT_ENABLED = bool(
    getattr(config, "OPENING_RANGE_TOUCH_ALERT_ENABLED", True)
)
DEFAULT_BACKFILL_TOUCH_ALERT_ENABLED = bool(
    getattr(config, "OPENING_RANGE_BACKFILL_TOUCH_ALERT_ENABLED", True)
)
DEFAULT_LIVE_TOUCH_ALERT_ENABLED = bool(
    getattr(config, "OPENING_RANGE_LIVE_TOUCH_ALERT_ENABLED", True)
)
DEFAULT_TOUCH_ALERT_MAX_INSTRUMENTS = int(
    getattr(config, "OPENING_RANGE_TOUCH_ALERT_MAX_INSTRUMENTS", 5)
)
DEFAULT_TOUCH_ALERT_BATCH_SECONDS = int(
    getattr(config, "OPENING_RANGE_TOUCH_ALERT_BATCH_SECONDS", 10)
)
DEFAULT_TOUCH_ALERT_ONCE_PER_LEVEL = bool(
    getattr(config, "OPENING_RANGE_TOUCH_ALERT_ONCE_PER_LEVEL", True)
)
DEFAULT_TOUCH_ALERT_OPTIONS_ONLY = bool(
    getattr(config, "OPENING_RANGE_TOUCH_ALERT_OPTIONS_ONLY", True)
)
DEFAULT_SORT_BY_NEAREST_INDEX = bool(
    getattr(config, "OPENING_RANGE_TOUCH_ALERT_SORT_BY_NEAREST_INDEX", True)
)
DEFAULT_MAIN_INDEX_KEY = getattr(
    config,
    "OPENING_RANGE_TOUCH_ALERT_MAIN_INDEX_KEY",
    getattr(config, "MAIN_NIFTY_SECURITY", "NSE_INDEX|Nifty 50"),
)
DEFAULT_TOUCH_CHECK_MODE = getattr(config, "OPENING_RANGE_TOUCH_CHECK_MODE", "high_low")
DEFAULT_TOUCH_EVENTS_OUTPUT_FILE = getattr(
    config,
    "OPENING_RANGE_TOUCH_EVENTS_OUTPUT_FILE",
    "data/opening_range_touch_events.json",
)
DEFAULT_TOUCH_EVENTS_SAVE_TEST_FILE = bool(
    getattr(config, "OPENING_RANGE_TOUCH_EVENTS_SAVE_TEST_FILE", True)
)
DEFAULT_LEGACY_TOUCH_TELEGRAM_ENABLED = bool(
    getattr(config, "OPENING_RANGE_LEGACY_TOUCH_TELEGRAM_ENABLED", False)
)
DEFAULT_EMA_CROSS_INCLUDE_OPENING_RANGE_LEVELS = bool(
    getattr(config, "EMA_CROSS_INCLUDE_OPENING_RANGE_LEVELS", True)
)
DEFAULT_ISOLATION_ENABLED = bool(
    getattr(config, "OPENING_RANGE_ISOLATED_INSTRUMENT_ENABLED", True)
)
DEFAULT_ISOLATION_WINDOW_POINTS = float(
    getattr(config, "OPENING_RANGE_ISOLATION_AVERAGE_WINDOW_POINTS", 500.0)
)
DEFAULT_ISOLATION_TOUCH_LEVELS = [
    str(item).upper()
    for item in getattr(
        config, "OPENING_RANGE_ISOLATION_TOUCH_LEVELS", ["R2", "R3", "S2", "S3"]
    )
]
DEFAULT_ISOLATION_PRIORITY_LEVELS = [
    str(item).upper()
    for item in getattr(
        config, "OPENING_RANGE_ISOLATION_PRIORITY_LEVELS", ["S3", "S2", "R3", "R2"]
    )
]
DEFAULT_ISOLATION_LOCK_FOR_DAY = bool(
    getattr(config, "OPENING_RANGE_ISOLATION_LOCK_FOR_DAY", True)
)
DEFAULT_ISOLATION_ALLOW_PRIORITY_UPGRADE = bool(
    getattr(config, "OPENING_RANGE_ISOLATION_ALLOW_PRIORITY_UPGRADE", True)
)
DEFAULT_ISOLATED_NOTIFY_ENABLED = bool(
    getattr(config, "OPENING_RANGE_ISOLATED_INSTRUMENT_NOTIFY_ENABLED", True)
)
DEFAULT_ISOLATION_ALLOW_BACKFILL_TOUCH = bool(
    getattr(config, "OPENING_RANGE_ISOLATION_ALLOW_BACKFILL_TOUCH", True)
)
DEFAULT_ISOLATION_ALLOW_LIVE_TOUCH = bool(
    getattr(config, "OPENING_RANGE_ISOLATION_ALLOW_LIVE_TOUCH", True)
)
DEFAULT_ISOLATION_OPTIONS_ONLY = bool(
    getattr(config, "OPENING_RANGE_ISOLATION_OPTIONS_ONLY", True)
)
DEFAULT_EMA_ISOLATED_TELEGRAM_ENABLED = bool(
    getattr(config, "EMA_ISOLATED_INSTRUMENT_TELEGRAM_ENABLED", True)
)
DEFAULT_LIVE_EMA_CALCULATION_MODE = bool(
    getattr(config, "LIVE_EMA_CALCULATION_MODE", False)
)

DEFAULT_MANUAL_SELECTION_ENABLED = bool(
    getattr(config, "TELEGRAM_MANUAL_INSTRUMENT_SELECTION_ENABLED", True)
)

DEFAULT_MANUAL_SELECTION_OVERRIDES_AUTO = bool(
    getattr(config, "MANUAL_INSTRUMENT_SELECTION_OVERRIDES_AUTO", True)
)

DEFAULT_MANUAL_SELECTION_RESET_DAILY = bool(
    getattr(config, "MANUAL_INSTRUMENT_SELECTION_RESET_DAILY", True)
)

DEFAULT_MANUAL_SELECTED_LEVEL_NAME = "MANUAL_SUPPORT"

DEFAULT_MANUAL_SELECT_SELECTION_REASON = "telegram_manual_selection"

DEFAULT_HARD_SELECT_SELECTION_REASON = "telegram_hard_select_selection"
# ============================================================
# Support Confirmation / New Isolation Flow Defaults
# ============================================================

DEFAULT_SUPPORT_CONFIRMATION_ENABLED = bool(
    getattr(config, "OPENING_RANGE_SUPPORT_CONFIRMATION_ENABLED", True)
)
DEFAULT_R3_REQUIRES_S3_CONFIRMATION = bool(
    getattr(config, "OPENING_RANGE_R3_REQUIRES_S3_CONFIRMATION", True)
)
DEFAULT_R2_REQUIRES_S2_CONFIRMATION = bool(
    getattr(config, "OPENING_RANGE_R2_REQUIRES_S2_CONFIRMATION", True)
)
DEFAULT_S2_TO_S3_WAIT_MINUTES = int(
    getattr(config, "OPENING_RANGE_S2_TO_S3_WAIT_MINUTES", 15)
)
DEFAULT_SUPPORT_CONFIRMATION_EOD_HOUR = int(
    getattr(config, "OPENING_RANGE_SUPPORT_CONFIRMATION_EOD_HOUR", 15)
)
DEFAULT_SUPPORT_CONFIRMATION_EOD_MINUTE = int(
    getattr(config, "OPENING_RANGE_SUPPORT_CONFIRMATION_EOD_MINUTE", 30)
)
DEFAULT_SUPPORT_CONFIRMATION_EOD_MESSAGE_ENABLED = bool(
    getattr(config, "OPENING_RANGE_SUPPORT_CONFIRMATION_EOD_MESSAGE_ENABLED", True)
)

# ============================================================
# Support Confirmation State
# ============================================================

_support_confirmation_lock = Lock()
_SUPPORT_CONFIRMATION_DEFAULT_STATE = {
    "enabled": DEFAULT_SUPPORT_CONFIRMATION_ENABLED,
    "date": None,
    "phase": "idle",
    "message": "No support confirmation flow started yet.",
    "resistance_trigger_event": None,
    "resistance_trigger_level": None,
    "resistance_trigger_instrument_key": None,
    "resistance_trigger_option_type": None,
    "expected_support_option_type": None,
    "resistance_trigger_at": None,
    "provisional_s2_event": None,
    "provisional_s2_selected_at": None,
    "s3_wait_started_at": None,
    "s3_wait_until": None,
    "s3_wait_minutes": DEFAULT_S2_TO_S3_WAIT_MINUTES,
    "final_support_event": None,
    "final_support_level": None,
    "final_isolated_at": None,
    "final_isolation_reason": None,
    "resistance_watch_message_sent": False,
    "s2_provisional_message_sent": False,
    "final_isolation_message_sent": False,
    "eod_no_confirmation_message_sent": False,
}
_support_confirmation_state = dict(_SUPPORT_CONFIRMATION_DEFAULT_STATE)

# ============================================================
# Basic Helpers
# ============================================================


def is_opening_range_enabled() -> bool:
    return bool(getattr(config, "OPENING_RANGE_ENABLED", True))


def get_market_timezone():
    timezone_name = getattr(config, "MARKET_TIMEZONE", "Asia/Kolkata")
    try:
        return ZoneInfo(timezone_name)
    except ZoneInfoNotFoundError:
        logger.error(
            f"Invalid MARKET_TIMEZONE configured: {timezone_name}. Falling back to Asia/Kolkata."
        )
        return ZoneInfo("Asia/Kolkata")


def get_now_market_time() -> datetime:
    return datetime.now(get_market_timezone())


def get_live_ema_calculation_mode_text() -> str:
    return "tick_ltp" if DEFAULT_LIVE_EMA_CALCULATION_MODE else "candle_close"


def safe_float(value, default: float = 0.0) -> float:
    try:
        if value is None:
            return default
        return float(value)
    except Exception:
        return default


def safe_int(value, default: int = 0) -> int:
    try:
        if value is None:
            return default
        return int(value)
    except Exception:
        return default


def response_to_dict(api_response: Any) -> dict:
    if api_response is None:
        return {}
    if hasattr(api_response, "to_dict"):
        return api_response.to_dict()
    if isinstance(api_response, dict):
        return api_response
    try:
        return dict(api_response)
    except Exception:
        return {}


def extract_candles_from_response(api_response: Any) -> list:
    response_dict = response_to_dict(api_response)
    data = response_dict.get("data", {})
    if isinstance(data, dict):
        candles = data.get("candles", [])
        return candles if isinstance(candles, list) else []
    return []


def parse_candle_timestamp(timestamp_value) -> datetime | None:
    if timestamp_value is None:
        return None
    market_tz = get_market_timezone()
    try:
        if isinstance(timestamp_value, (int, float)):
            return datetime.fromtimestamp(int(timestamp_value) / 1000, tz=market_tz)
        text = str(timestamp_value).strip()
        if not text:
            return None
        if text.isdigit():
            return datetime.fromtimestamp(int(text) / 1000, tz=market_tz)
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=market_tz)
        else:
            parsed = parsed.astimezone(market_tz)
        return parsed
    except Exception:
        return None


def parse_market_datetime(value) -> datetime | None:
    return parse_candle_timestamp(value)


def normalize_candle(candle: list) -> dict | None:
    if not isinstance(candle, list) or len(candle) < 5:
        return None
    candle_dt = parse_candle_timestamp(candle[0])
    if not candle_dt:
        return None
    return {
        "timestamp": candle_dt.isoformat(),
        "datetime": candle_dt,
        "open": safe_float(candle[1]),
        "high": safe_float(candle[2]),
        "low": safe_float(candle[3]),
        "close": safe_float(candle[4]),
        "volume": safe_int(candle[5]) if len(candle) > 5 else 0,
        "oi": safe_int(candle[6]) if len(candle) > 6 else 0,
    }


def normalize_candles(candles: list) -> list:
    normalized = []
    for candle in candles:
        item = normalize_candle(candle)
        if item:
            normalized.append(item)
    seen = set()
    unique = []
    for item in normalized:
        ts = item.get("timestamp")
        if ts not in seen:
            seen.add(ts)
            unique.append(item)
    try:
        return sorted(unique, key=lambda x: x.get("datetime"))
    except Exception:
        return unique


def serialize_candle(candle: dict) -> dict:
    return {
        "timestamp": candle.get("timestamp"),
        "open": candle.get("open"),
        "high": candle.get("high"),
        "low": candle.get("low"),
        "close": candle.get("close"),
        "volume": candle.get("volume"),
        "oi": candle.get("oi"),
    }


def get_subscribed_instrument_keys() -> list:
    subscribed_keys = options_cache.get("subscribed_keys", [])
    if not subscribed_keys:
        return []
    return list(dict.fromkeys(subscribed_keys))


def get_contract_info_by_key(instrument_key: str) -> dict:
    main_key = getattr(config, "MAIN_NIFTY_SECURITY", "NSE_INDEX|Nifty 50")
    if instrument_key == main_key:
        return {
            "instrument_key": instrument_key,
            "instrument_type": "INDEX",
            "strike_price": None,
            "expiry": None,
            "trading_symbol": "NIFTY 50",
            "underlying_type": "INDEX",
            "underlying_symbol": "NIFTY 50",
        }
    resolved = get_contract_info_by_instrument_key(instrument_key)
    if resolved:
        return resolved
    for item in options_cache.get("data", []):
        if item.get("instrument_key") == instrument_key:
            return item
    return {"instrument_key": instrument_key}


def is_option_contract(contract_info: dict | None) -> bool:
    if not contract_info:
        return False
    return str(contract_info.get("instrument_type", "")).upper() in ["CE", "PE"]


def normalize_option_type(value) -> str | None:
    text = str(value or "").strip().upper()
    if text in ["CE", "CALL"]:
        return "CE"
    if text in ["PE", "PUT"]:
        return "PE"
    return None


def get_opposite_option_type(value) -> str | None:
    option_type = normalize_option_type(value)
    if option_type == "CE":
        return "PE"
    if option_type == "PE":
        return "CE"
    return None


def update_latest_ltp_for_instrument(
    instrument_key: str, ltp, updated_at: str | None = None
):
    if not instrument_key:
        return
    value = safe_float(ltp)
    if value <= 0:
        return
    updated_at = updated_at or get_now_market_time().isoformat()
    with _touch_lock:
        _latest_ltp_by_instrument[instrument_key] = value
        _latest_ltp_updated_at_by_instrument[instrument_key] = updated_at


def get_latest_ltp_for_instrument(instrument_key: str) -> float | None:
    if not instrument_key:
        return None
    with _touch_lock:
        return _latest_ltp_by_instrument.get(instrument_key)


def update_latest_main_index_ltp(
    ltp, source: str = "unknown", updated_at: str | None = None
):
    global _latest_main_index_ltp, _latest_main_index_ltp_source, _latest_main_index_ltp_updated_at
    value = safe_float(ltp, default=0.0)
    if value <= 0:
        return
    updated_at = updated_at or get_now_market_time().isoformat()
    with _touch_lock:
        _latest_main_index_ltp = value
        _latest_main_index_ltp_source = source
        _latest_main_index_ltp_updated_at = updated_at
    with _opening_range_cache_lock:
        opening_range_cache["latest_main_index_ltp"] = value
        opening_range_cache["latest_main_index_ltp_source"] = source
        opening_range_cache["latest_main_index_ltp_updated_at"] = updated_at


def get_latest_main_index_ltp() -> float | None:
    with _touch_lock:
        return _latest_main_index_ltp


def set_manual_selected_instrument(
    instrument_key: str,
    contract_info: dict | None = None,
    selection_mode: str = "manual_select",
    selection_reason: str = DEFAULT_MANUAL_SELECT_SELECTION_REASON,
):
    """
    Manual / hard-select instrument from Telegram.
    """

    if not instrument_key:
        return False

    contract_info = contract_info or get_contract_info_by_key(instrument_key)

    state = {
        "selected": True,
        "manual_override": True,
        "selection_mode": selection_mode,
        "instrument_key": instrument_key,
        "selected_level": DEFAULT_MANUAL_SELECTED_LEVEL_NAME,
        "level_value": None,
        "trigger_price": None,
        "trigger_field": None,
        "touch_time": None,
        "touch_source": "telegram_manual_selection",
        "contract_info": contract_info,
        "selected_at": get_now_market_time().isoformat(),
        "selection_priority": -1 if selection_mode == "hard_select" else 0,
        "selection_reason": selection_reason,
        "reference_average": get_reference_opening_range_average(),
        "average_window": None,
        "range": None,
        "levels": None,
        "latest_live_data": {"ltp": get_latest_ltp_for_instrument(instrument_key)},
        "latest_main_index_ltp": get_latest_main_index_ltp(),
        "live_ema_calculation_mode_flag": DEFAULT_LIVE_EMA_CALCULATION_MODE,
        "live_ema_calculation_mode": get_live_ema_calculation_mode_text(),
        "ema_alerts_count": 0,
        "last_ema_alert": None,
        "historical_ema_initialized": False,
        "live_ema_initialized": False,
        "subscription_active": False,
        "streamer_restart_required": False,
        "today_latest_crossover": None,
        "last_available_crossover": None,
        "disabled": False,
        "message": f"{selection_mode} instrument selected.",
    }

    with _manual_selected_or_lock:
        _manual_selected_or_instrument_state.clear()
        _manual_selected_or_instrument_state.update(state)

    effective_source = get_effective_isolated_instrument_source()

    with _opening_range_cache_lock:
        opening_range_cache["manual_selected_instrument"] = dict(state)

        opening_range_cache["manual_override_active"] = True

        opening_range_cache["isolated_instrument"] = dict(state)

        opening_range_cache["isolated_instrument_selected"] = True

        opening_range_cache["isolated_instrument_selected_at"] = state.get(
            "selected_at"
        )

        opening_range_cache["isolated_instrument_selection_reason"] = state.get(
            "selection_reason"
        )

        opening_range_cache["effective_isolated_instrument_source"] = effective_source

    return True


def clear_manual_selected_instrument():

    with _manual_selected_or_lock:
        _manual_selected_or_instrument_state.clear()
        _manual_selected_or_instrument_state.update(
            dict(_MANUAL_SELECTED_OR_DEFAULT_STATE)
        )

    effective_state = get_effective_isolated_instrument_state()
    effective_source = get_effective_isolated_instrument_source()

    with _opening_range_cache_lock:
        opening_range_cache["manual_selected_instrument"] = None

        opening_range_cache["manual_override_active"] = False

        opening_range_cache["isolated_instrument"] = dict(effective_state)

        opening_range_cache["isolated_instrument_selected"] = bool(
            effective_state.get("selected")
        )

        opening_range_cache["isolated_instrument_selected_at"] = effective_state.get(
            "selected_at"
        )

        opening_range_cache["isolated_instrument_selection_reason"] = (
            effective_state.get("selection_reason")
        )

        opening_range_cache["effective_isolated_instrument_source"] = effective_source

    return True


def select_instrument_manually(
    instrument_key: str,
    contract_info: dict | None = None,
):
    """
    Telegram manual selection.

    Manual selection can be replaced later
    by another manual selection.
    """

    return set_manual_selected_instrument(
        instrument_key=instrument_key,
        contract_info=contract_info,
        selection_mode="manual_select",
        selection_reason=DEFAULT_MANUAL_SELECT_SELECTION_REASON,
    )


def hard_select_instrument_manually(
    instrument_key: str,
    contract_info: dict | None = None,
):
    """
    Telegram hard select.

    Highest priority override.
    Used when user wants one instrument
    locked for EMA alerts.
    """

    return set_manual_selected_instrument(
        instrument_key=instrument_key,
        contract_info=contract_info,
        selection_mode="hard_select",
        selection_reason=DEFAULT_HARD_SELECT_SELECTION_REASON,
    )


def get_effective_selected_instrument_status():

    return {
        "manual_selected_instrument": get_manual_selected_instrument_state(),
        "automatic_isolated_instrument": get_automatic_selected_or_instrument_state(),
        "effective_isolated_instrument": get_effective_isolated_instrument_state(),
        "effective_source": get_effective_isolated_instrument_source(),
        "manual_override_active": is_manual_selected_instrument_active(),
    }


# ============================================================
# Daily State Reset Helpers
# ============================================================
def reset_manual_selected_state_for_today_if_needed():
    global _manual_selected_or_state_date

    if not DEFAULT_MANUAL_SELECTION_RESET_DAILY:
        return

    today = get_now_market_time().date().isoformat()

    with _manual_selected_or_lock:

        if _manual_selected_or_state_date == today:
            return

        _manual_selected_or_instrument_state.clear()
        _manual_selected_or_instrument_state.update(
            dict(_MANUAL_SELECTED_OR_DEFAULT_STATE)
        )

        _manual_selected_or_state_date = today

    effective_state = get_effective_isolated_instrument_state()
    effective_source = get_effective_isolated_instrument_source()

    with _opening_range_cache_lock:
        opening_range_cache["manual_selected_instrument"] = None

        opening_range_cache["manual_override_active"] = False

        opening_range_cache["isolated_instrument"] = dict(effective_state)

        opening_range_cache["isolated_instrument_selected"] = bool(
            effective_state.get("selected")
        )

        opening_range_cache["isolated_instrument_selected_at"] = effective_state.get(
            "selected_at"
        )

        opening_range_cache["isolated_instrument_selection_reason"] = (
            effective_state.get("selection_reason")
        )

        opening_range_cache["effective_isolated_instrument_source"] = effective_source


def reset_selected_or_state_for_today_if_needed():
    global _selected_or_state_date, _selected_or_ema_alert_minute_date
    today = get_now_market_time().date().isoformat()
    with _selected_or_lock:
        if _selected_or_state_date == today:
            return
        _selected_or_instrument_state.clear()
        _selected_or_instrument_state.update(dict(_SELECTED_OR_DEFAULT_STATE))
        _selected_or_ema_alerts.clear()
        _selected_or_ema_alert_minute_keys.clear()
        _selected_or_ema_alert_minute_date = today
        _selected_or_state_date = today
    with _opening_range_cache_lock:
        opening_range_cache["isolated_instrument"] = dict(_SELECTED_OR_DEFAULT_STATE)
        opening_range_cache["isolated_instrument_selected"] = False
        opening_range_cache["isolated_instrument_selected_at"] = None
        opening_range_cache["isolated_instrument_selection_reason"] = None
        opening_range_cache["isolated_ema_alerts_count"] = 0


def get_support_confirmation_state() -> dict:
    with _support_confirmation_lock:
        return dict(_support_confirmation_state)


def reset_support_confirmation_state_for_today_if_needed():
    today = get_now_market_time().date().isoformat()
    reset_selected_or_state_for_today_if_needed()
    reset_manual_selected_state_for_today_if_needed()

    with _support_confirmation_lock:
        if _support_confirmation_state.get("date") == today:
            return
        _support_confirmation_state.clear()
        _support_confirmation_state.update(dict(_SUPPORT_CONFIRMATION_DEFAULT_STATE))
        _support_confirmation_state["date"] = today
    with _opening_range_cache_lock:
        opening_range_cache["support_confirmation"] = get_support_confirmation_state()


# ============================================================
# Opening Range Candle Selection / Formula
# ============================================================


def get_market_open_datetime(target_date=None) -> datetime:
    market_tz = get_market_timezone()
    now_market = get_now_market_time()
    if target_date is None:
        target_date = now_market.date()
    return datetime.combine(
        target_date,
        dt_time(hour=DEFAULT_MARKET_OPEN_HOUR, minute=DEFAULT_MARKET_OPEN_MINUTE),
        tzinfo=market_tz,
    )


def get_opening_range_end_datetime(
    candle_count: int = DEFAULT_OPENING_RANGE_CANDLE_COUNT, target_date=None
) -> datetime:
    candle_count = max(1, int(candle_count or 1))
    market_open_dt = get_market_open_datetime(target_date=target_date)
    return market_open_dt + timedelta(minutes=candle_count)


def select_opening_range_candles(
    candles: list, candle_count: int = DEFAULT_OPENING_RANGE_CANDLE_COUNT
) -> list:
    if not candles:
        return []
    candle_count = max(1, int(candle_count or 1))
    market_open_dt = get_market_open_datetime()
    selected = []
    for candle in candles:
        candle_dt = candle.get("datetime")
        if not candle_dt:
            continue
        if candle_dt >= market_open_dt:
            selected.append(candle)
        if len(selected) >= candle_count:
            break
    return selected


def select_post_opening_range_candles(
    candles: list, candle_count: int = DEFAULT_OPENING_RANGE_CANDLE_COUNT
) -> list:
    if not candles:
        return []
    or_end_dt = get_opening_range_end_datetime(candle_count=candle_count)
    return [
        candle
        for candle in candles
        if candle.get("datetime") and candle.get("datetime") >= or_end_dt
    ]


def calculate_opening_range_levels(selected_candles: list) -> dict:
    if not selected_candles:
        return {
            "status": "empty",
            "message": "No opening range candles selected.",
            "range": None,
            "levels": None,
        }
    range_open = safe_float(selected_candles[0].get("open"))
    range_close = safe_float(selected_candles[-1].get("close"))
    range_high = max(safe_float(item.get("high")) for item in selected_candles)
    range_low = min(safe_float(item.get("low")) for item in selected_candles)
    range_avg = (range_high + range_low) / 2
    high_avg_diff = abs(range_high - range_avg)
    low_avg_diff = abs(range_avg - range_low)
    sub_resistance = range_avg + (high_avg_diff / 2)
    sub_support = range_avg - (low_avg_diff / 2)
    resistance2 = range_high + high_avg_diff
    support2 = range_low - low_avg_diff
    resistance3 = resistance2 + high_avg_diff
    support3 = support2 - low_avg_diff
    r3_threshold = (resistance2 + resistance3) / 2
    s3_threshold = (support2 + support3) / 2
    return {
        "status": "success",
        "message": "Opening range levels calculated successfully.",
        "range": {
            "open": round(range_open, 4),
            "high": round(range_high, 4),
            "low": round(range_low, 4),
            "close": round(range_close, 4),
            "average": round(range_avg, 4),
            "selected_candles_count": len(selected_candles),
            "first_candle_time": selected_candles[0].get("timestamp"),
            "last_candle_time": selected_candles[-1].get("timestamp"),
        },
        "levels": {
            "r1": round(sub_resistance, 4),
            "s1": round(sub_support, 4),
            "r2": round(resistance2, 4),
            "s2": round(support2, 4),
            "r3": round(resistance3, 4),
            "s3": round(support3, 4),
            "sub_resistance": round(sub_resistance, 4),
            "sub_support": round(sub_support, 4),
            "resistance2": round(resistance2, 4),
            "support2": round(support2, 4),
            "resistance3": round(resistance3, 4),
            "support3": round(support3, 4),
            "r3_threshold": round(r3_threshold, 4),
            "s3_threshold": round(s3_threshold, 4),
        },
    }


# ============================================================
# Touch Event Helpers
# ============================================================


def build_alert_key(instrument_key: str, level: str) -> str:
    return f"{instrument_key}_{str(level).upper()}"


def calculate_distance_from_index(strike_price, index_ltp) -> float | None:
    try:
        if strike_price is None or index_ltp is None:
            return None
        return round(abs(float(strike_price) - float(index_ltp)), 4)
    except Exception:
        return None


def get_default_touch_status() -> dict:
    return {
        "r2_touched": False,
        "s2_touched": False,
        "r3_touched": False,
        "s3_touched": False,
        "r2_touch_time": None,
        "s2_touch_time": None,
        "r3_touch_time": None,
        "s3_touch_time": None,
        "r2_alert_sent": False,
        "s2_alert_sent": False,
        "r3_alert_sent": False,
        "s3_alert_sent": False,
        "first_touch_level": None,
        "first_touch_source": None,
        "first_touch_time": None,
        "events": [],
    }


def create_touch_event(
    instrument_key: str,
    level: str,
    level_value: float,
    trigger_price: float,
    trigger_field: str,
    touch_time: str,
    source: str,
    contract_info: dict,
    candle: dict | None = None,
) -> dict:
    index_ltp = get_latest_main_index_ltp()
    strike_price = contract_info.get("strike_price") if contract_info else None
    distance_from_index = calculate_distance_from_index(
        strike_price=strike_price, index_ltp=index_ltp
    )
    return {
        "type": "opening_range_touch",
        "instrument_key": instrument_key,
        "level": str(level).upper(),
        "level_value": round(safe_float(level_value), 4),
        "trigger_price": round(safe_float(trigger_price), 4),
        "trigger_field": trigger_field,
        "touch_time": touch_time,
        "source": source,
        "date": get_now_market_time().date().isoformat(),
        "main_index_ltp": index_ltp,
        "distance_from_index": distance_from_index,
        "alert_key": build_alert_key(instrument_key, level),
        "contract_info": contract_info or {},
        "candle": serialize_candle(candle) if candle else None,
        "created_at": get_now_market_time().isoformat(),
    }


def should_skip_touch_alert(
    instrument_key: str, level: str, contract_info: dict | None = None
) -> bool:
    if not DEFAULT_TOUCH_ALERT_ENABLED:
        return True
    if DEFAULT_TOUCH_ALERT_OPTIONS_ONLY and not is_option_contract(contract_info):
        return True
    level_upper = str(level).upper()
    if level_upper not in DEFAULT_ISOLATION_TOUCH_LEVELS:
        return True
    alert_key = build_alert_key(instrument_key, level_upper)
    with _touch_lock:
        if DEFAULT_TOUCH_ALERT_ONCE_PER_LEVEL and alert_key in _alert_sent_keys:
            return True
    return False


def mark_touch_alert_sent(event: dict):
    alert_key = event.get("alert_key")
    if not alert_key:
        return
    with _touch_lock:
        _alert_sent_keys.add(alert_key)


def queue_touch_event(event: dict):
    if not isinstance(event, dict):
        return
    with _touch_lock:
        _touch_events.append(event)
        if DEFAULT_LEGACY_TOUCH_TELEGRAM_ENABLED:
            _pending_touch_events.append(event)
    with _opening_range_cache_lock:
        opening_range_cache["touch_events_count"] = len(_touch_events)
        opening_range_cache["pending_touch_events_count"] = len(_pending_touch_events)
        opening_range_cache["alert_sent_keys_count"] = len(_alert_sent_keys)
        opening_range_cache["touch_events"] = list(_touch_events)


def build_touch_status_from_events(events: list) -> dict:
    status = get_default_touch_status()
    for event in events:
        level = str(event.get("level", "")).upper()
        lower_level = level.lower()
        if level in ["R2", "S2", "R3", "S3"]:
            status[f"{lower_level}_touched"] = True
            status[f"{lower_level}_touch_time"] = event.get("touch_time")
            status[f"{lower_level}_alert_sent"] = True
        if not status.get("first_touch_level"):
            status["first_touch_level"] = level
            status["first_touch_source"] = event.get("source")
            status["first_touch_time"] = event.get("touch_time")
        status.setdefault("events", []).append(event)
    return status


def update_touch_status_in_cache(instrument_key: str, event: dict):
    level = str(event.get("level", "")).upper()
    lower_level = level.lower()
    with _opening_range_cache_lock:
        data = opening_range_cache.get("data", {})
        item = data.get(instrument_key)
        if not item:
            return
        touch_status = item.setdefault("touch_status", get_default_touch_status())
        if level in ["R2", "S2", "R3", "S3"]:
            touch_status[f"{lower_level}_touched"] = True
            touch_status[f"{lower_level}_touch_time"] = event.get("touch_time")
            touch_status[f"{lower_level}_alert_sent"] = True
        if not touch_status.get("first_touch_level"):
            touch_status["first_touch_level"] = level
            touch_status["first_touch_source"] = event.get("source")
            touch_status["first_touch_time"] = event.get("touch_time")
        touch_status.setdefault("events", []).append(event)
        item["touch_status"] = touch_status
        data[instrument_key] = item
        opening_range_cache["data"] = data


# ============================================================
# Isolation / Confirmation Helpers
# ============================================================


def get_event_option_type(event: dict) -> str | None:
    if not isinstance(event, dict):
        return None
    return normalize_option_type(
        (event.get("contract_info") or {}).get("instrument_type")
    )


def get_event_strike(event: dict) -> float:
    if not isinstance(event, dict):
        return 0.0
    return safe_float((event.get("contract_info") or {}).get("strike_price"))


def get_level_priority(level: str) -> int:
    level_upper = str(level or "").upper()
    try:
        return DEFAULT_ISOLATION_PRIORITY_LEVELS.index(level_upper)
    except ValueError:
        return 999


def get_reference_opening_range_average() -> float | None:
    with _opening_range_cache_lock:
        main_item = opening_range_cache.get("data", {}).get(DEFAULT_MAIN_INDEX_KEY)
        if main_item:
            avg = (main_item.get("range") or {}).get("average")
            if avg is not None:
                return safe_float(avg)
        latest_ltp = opening_range_cache.get("latest_main_index_ltp")
    if latest_ltp is not None:
        return safe_float(latest_ltp)
    return get_latest_main_index_ltp()


def build_average_window(reference_average: float) -> dict:
    strike_from = safe_float(getattr(config, "STRIKE_FROM", 0.0))
    strike_to = safe_float(getattr(config, "STRIKE_TO", 999999.0))
    raw_lower = reference_average - DEFAULT_ISOLATION_WINDOW_POINTS
    raw_upper = reference_average + DEFAULT_ISOLATION_WINDOW_POINTS
    final_lower = max(strike_from, raw_lower)
    final_upper = min(strike_to, raw_upper)
    return {
        "reference_average": reference_average,
        "window_points": DEFAULT_ISOLATION_WINDOW_POINTS,
        "raw_lower": raw_lower,
        "raw_upper": raw_upper,
        "configured_from": strike_from,
        "configured_to": strike_to,
        "final_lower": final_lower,
        "final_upper": final_upper,
    }


def is_event_eligible_for_isolation(event: dict) -> tuple[bool, str]:
    if not DEFAULT_ISOLATION_ENABLED:
        return False, "isolation_disabled"
    if not isinstance(event, dict):
        return False, "invalid_event"
    level = str(event.get("level", "")).upper()
    if level not in DEFAULT_ISOLATION_TOUCH_LEVELS:
        return False, "level_not_eligible"
    source = str(event.get("source", ""))
    if (
        source == "intraday_backfill_scan"
        and not DEFAULT_ISOLATION_ALLOW_BACKFILL_TOUCH
    ):
        return False, "backfill_selection_disabled"
    if source == "live_tick" and not DEFAULT_ISOLATION_ALLOW_LIVE_TOUCH:
        return False, "live_selection_disabled"
    contract_info = event.get("contract_info") or {}
    if DEFAULT_ISOLATION_OPTIONS_ONLY and not is_option_contract(contract_info):
        return False, "not_option_contract"
    strike = contract_info.get("strike_price")
    if strike is None:
        return False, "missing_strike"
    reference_average = get_reference_opening_range_average()
    if reference_average is None or reference_average <= 0:
        return False, "reference_average_not_available"
    window = build_average_window(reference_average)
    strike_value = safe_float(strike)
    if not (window["final_lower"] <= strike_value <= window["final_upper"]):
        return False, "strike_outside_average_window"
    return True, "eligible"


def choose_best_isolation_event(events: list) -> dict | None:
    # Legacy fallback only when support-confirmation is disabled.
    if not events:
        return None
    reference_average = get_reference_opening_range_average()
    if reference_average is None or reference_average <= 0:
        return None
    eligible_events = []
    for event in events:
        eligible, _reason = is_event_eligible_for_isolation(event)
        if not eligible:
            continue
        strike = get_event_strike(event)
        level = str(event.get("level", "")).upper()
        eligible_events.append(
            {
                "event": event,
                "priority": get_level_priority(level),
                "distance_to_average": abs(strike - reference_average),
                "strike": strike,
            }
        )
    if not eligible_events:
        return None
    return min(
        eligible_events,
        key=lambda item: (
            item["priority"],
            item["distance_to_average"],
            item["strike"],
        ),
    )["event"]


def choose_best_support_event(
    events: list, level: str, expected_option_type: str | None = None
) -> dict | None:
    if not events:
        return None
    level_upper = str(level or "").upper()
    expected_type = normalize_option_type(expected_option_type)
    candidates = []
    for event in events:
        if not isinstance(event, dict):
            continue
        if str(event.get("level", "")).upper() != level_upper:
            continue
        eligible, _reason = is_event_eligible_for_isolation(event)
        if not eligible:
            continue
        event_type = get_event_option_type(event)
        if expected_type and event_type != expected_type:
            continue
        if event_type not in ["CE", "PE"]:
            continue
        candidates.append(event)
    if not candidates:
        return None
    pe_candidates = [
        event for event in candidates if get_event_option_type(event) == "PE"
    ]
    ce_candidates = [
        event for event in candidates if get_event_option_type(event) == "CE"
    ]
    if expected_type == "PE" and pe_candidates:
        return max(pe_candidates, key=get_event_strike)
    if expected_type == "CE" and ce_candidates:
        return min(ce_candidates, key=get_event_strike)
    if pe_candidates:
        return max(pe_candidates, key=get_event_strike)
    if ce_candidates:
        return min(ce_candidates, key=get_event_strike)
    return None


def choose_resistance_trigger_event(events: list) -> dict | None:
    if not events:
        return None
    eligible = [
        event
        for event in events
        if isinstance(event, dict) and is_event_eligible_for_isolation(event)[0]
    ]
    if not eligible:
        return None
    ce_candidates = [
        event for event in eligible if get_event_option_type(event) == "CE"
    ]
    pe_candidates = [
        event for event in eligible if get_event_option_type(event) == "PE"
    ]
    if ce_candidates:
        return min(ce_candidates, key=get_event_strike)
    if pe_candidates:
        return max(pe_candidates, key=get_event_strike)
    return eligible[0]


def should_replace_isolated_instrument(new_event: dict) -> bool:
    with _selected_or_lock:
        already_selected = bool(_selected_or_instrument_state.get("selected"))
        current_priority = _selected_or_instrument_state.get("selection_priority")
    if not already_selected:
        return True
    if not DEFAULT_ISOLATION_LOCK_FOR_DAY:
        return True
    if not DEFAULT_ISOLATION_ALLOW_PRIORITY_UPGRADE:
        return False
    new_priority = get_level_priority(new_event.get("level"))
    if current_priority is None:
        return False
    return new_priority < int(current_priority)


def send_support_confirmation_watch_message(
    trigger_event: dict, expected_level: str
) -> bool:
    info = trigger_event.get("contract_info") or {}
    strike = info.get("strike_price", "N/A")
    option_type = normalize_option_type(info.get("instrument_type")) or "N/A"
    trigger_level = str(trigger_event.get("level", "N/A")).upper()
    trigger_price = trigger_event.get("trigger_price")
    trigger_time = trigger_event.get("touch_time")
    expected_option_type = get_opposite_option_type(option_type)
    message = (
        f"{strike} {option_type} touched {trigger_level}.\n\n"
        f"Trigger Price: {trigger_price}\n"
        f"Touch Time: {trigger_time}\n\n"
        f"This is a resistance trigger only.\n"
        f"Waiting for {expected_option_type} side {expected_level} support confirmation.\n\n"
        f"No EMA Telegram alerts will be sent until support confirmation is completed."
    )
    return telegram_service.send_message(
        title="Opening Range Resistance Trigger", message=message, level="OPENING_RANGE"
    )


def send_s2_provisional_support_message(event: dict, wait_until: str) -> bool:
    info = event.get("contract_info") or {}
    strike = info.get("strike_price", "N/A")
    option_type = normalize_option_type(info.get("instrument_type")) or "N/A"
    message = (
        f"{strike} {option_type} touched S2.\n\n"
        f"S2 is selected as provisional support candidate.\n"
        f"Waiting {DEFAULT_S2_TO_S3_WAIT_MINUTES} minutes for S3 upgrade.\n\n"
        f"S3 Wait Until: {wait_until}\n\n"
        f"If S3 does not touch within this window, this S2 instrument will be isolated."
    )
    return telegram_service.send_message(
        title="Opening Range S2 Provisional Candidate",
        message=message,
        level="OPENING_RANGE",
    )


def send_no_support_confirmation_eod_message() -> bool:
    state = get_support_confirmation_state()
    trigger = state.get("resistance_trigger_event") or {}
    info = trigger.get("contract_info") or {}
    strike = info.get("strike_price", "N/A")
    option_type = normalize_option_type(info.get("instrument_type")) or "N/A"
    level = trigger.get("level", "N/A")
    message = (
        "No final support confirmation instrument was selected today.\n\n"
        f"Resistance Trigger: {strike} {option_type} {level}\n"
        f"Current Phase: {state.get('phase')}\n"
        f"Message: {state.get('message')}\n\n"
        f"No isolated EMA Telegram alerts were enabled for the day."
    )
    return telegram_service.send_message(
        title="Opening Range No Support Confirmation", message=message, level="WARNING"
    )


def send_isolated_instrument_notification(state: dict) -> bool:
    if not DEFAULT_ISOLATED_NOTIFY_ENABLED:
        return False
    info = state.get("contract_info") or {}
    strike = info.get("strike_price", "N/A")
    option_type = (
        normalize_option_type(info.get("instrument_type"))
        or str(info.get("instrument_type", "N/A")).upper()
    )
    selected_level = state.get("selected_level", "N/A")
    trigger_price = state.get("trigger_price", "N/A")
    level_value = state.get("level_value", "N/A")
    nifty_ltp = state.get("latest_main_index_ltp")
    touch_time = state.get("touch_time")
    try:
        short_touch_time = (
            str(touch_time).split("T")[-1][:5] if touch_time else touch_time
        )
    except Exception:
        short_touch_time = touch_time
    message = (
        f"{strike} {option_type} selected after {selected_level} touch\n\n"
        f"Touch Price: {trigger_price}\n"
        f"Level Value: {level_value}\n"
        f"NIFTY: {nifty_ltp if nifty_ltp is not None else 'not_available'}\n"
        f"Touch Time: {short_touch_time}\n\n"
        f"EMA Telegram alerts will now be sent only for this instrument."
    )
    return telegram_service.send_message(
        title="Opening Range Instrument Isolated",
        message=message,
        level="OPENING_RANGE",
    )


def isolate_instrument_from_event(
    event: dict, selection_reason: str | None = None
) -> bool:

    if (
        is_manual_selected_instrument_active()
        and DEFAULT_MANUAL_SELECTION_OVERRIDES_AUTO
    ):
        logger.info("Skipping auto isolation because manual selection exists.")
        return False

    if not event:
        return False

    eligible, reason = is_event_eligible_for_isolation(event)
    if not eligible:
        logger.info(
            f"Isolation skipped. reason={reason}, instrument_key={event.get('instrument_key')}, level={event.get('level')}"
        )
        return False

    if not should_replace_isolated_instrument(event):
        return False

    instrument_key = event.get("instrument_key")
    contract_info = event.get("contract_info") or get_contract_info_by_key(
        instrument_key
    )

    reference_average = get_reference_opening_range_average()
    average_window = (
        build_average_window(reference_average) if reference_average else None
    )

    with _opening_range_cache_lock:
        item = opening_range_cache.get("data", {}).get(instrument_key, {})

    final_reason = selection_reason or "support_confirmation_final_isolation"

    state = {
        "selected": True,
        "instrument_key": instrument_key,
        "selected_level": str(event.get("level", "")).upper(),
        "level_value": event.get("level_value"),
        "trigger_price": event.get("trigger_price"),
        "trigger_field": event.get("trigger_field"),
        "touch_time": event.get("touch_time"),
        "touch_source": event.get("source"),
        "selected_at": get_now_market_time().isoformat(),
        "selection_priority": get_level_priority(event.get("level")),
        "selection_reason": final_reason,
        "reference_average": reference_average,
        "average_window": average_window,
        "contract_info": contract_info,
        "range": item.get("range"),
        "levels": item.get("levels"),
        "latest_live_data": {"ltp": get_latest_ltp_for_instrument(instrument_key)},
        "latest_main_index_ltp": get_latest_main_index_ltp(),
        "live_ema_calculation_mode_flag": DEFAULT_LIVE_EMA_CALCULATION_MODE,
        "live_ema_calculation_mode": get_live_ema_calculation_mode_text(),
        "ema_alerts_count": 0,
        "last_ema_alert": None,
        "disabled": False,
        "message": "Opening Range support instrument isolated for EMA Telegram alerts.",
    }

    with _selected_or_lock:
        previous_alert_count = _selected_or_instrument_state.get(
            "ema_alerts_count",
            0,
        )
        state["ema_alerts_count"] = previous_alert_count
        _selected_or_instrument_state.clear()
        _selected_or_instrument_state.update(state)

    with _support_confirmation_lock:
        _support_confirmation_state["phase"] = "final_support_isolated"
        _support_confirmation_state["message"] = (
            "Final support confirmation instrument isolated."
        )
        _support_confirmation_state["final_support_event"] = dict(event)
        _support_confirmation_state["final_support_level"] = str(
            event.get("level", "")
        ).upper()
        _support_confirmation_state["final_isolated_at"] = state.get("selected_at")
        _support_confirmation_state["final_isolation_reason"] = final_reason
        _support_confirmation_state["final_isolation_message_sent"] = True

    with _opening_range_cache_lock:
        opening_range_cache["isolated_instrument"] = dict(state)

        opening_range_cache["automatic_isolated_instrument"] = dict(state)

        opening_range_cache["isolated_instrument_selected"] = True

        opening_range_cache["isolated_instrument_selected_at"] = state.get(
            "selected_at"
        )

        opening_range_cache["isolated_instrument_selection_reason"] = state.get(
            "selection_reason"
        )

        opening_range_cache["effective_isolated_instrument_source"] = (
            get_effective_isolated_instrument_source()
        )

        opening_range_cache["manual_override_active"] = (
            is_manual_selected_instrument_active()
        )

        opening_range_cache["support_confirmation"] = get_support_confirmation_state()

    logger.info(
        f"Opening Range support instrument isolated. instrument_key={instrument_key}, "
        f"level={state.get('selected_level')}, strike={contract_info.get('strike_price')}, "
        f"type={contract_info.get('instrument_type')}, reason={final_reason}"
    )

    send_isolated_instrument_notification(state)

    return True


def process_s2_wait_timeout_if_needed() -> bool:
    reset_support_confirmation_state_for_today_if_needed()

    if (
        is_manual_selected_instrument_active()
        and DEFAULT_MANUAL_SELECTION_OVERRIDES_AUTO
    ):
        return False

    with _selected_or_lock:
        if _selected_or_instrument_state.get("selected"):
            return False
    with _support_confirmation_lock:
        phase = _support_confirmation_state.get("phase")
        if phase != "waiting_for_s3_after_s2":
            return False
        provisional_event = _support_confirmation_state.get("provisional_s2_event")
        wait_until = _support_confirmation_state.get("s3_wait_until")
    if not provisional_event or not wait_until:
        return False
    wait_until_dt = parse_market_datetime(wait_until)
    if not wait_until_dt:
        return False
    now_dt = get_now_market_time()
    if now_dt < wait_until_dt:
        return False
    return isolate_instrument_from_event(
        provisional_event, selection_reason="s2_confirmed_after_s3_wait_timeout"
    )


def run_support_confirmation_eod_check() -> dict:
    reset_support_confirmation_state_for_today_if_needed()
    now_dt = get_now_market_time()
    eod_dt = datetime.combine(
        now_dt.date(),
        dt_time(
            hour=DEFAULT_SUPPORT_CONFIRMATION_EOD_HOUR,
            minute=DEFAULT_SUPPORT_CONFIRMATION_EOD_MINUTE,
        ),
        tzinfo=get_market_timezone(),
    )
    if now_dt < eod_dt:
        return {
            "status": "skipped",
            "reason": "before_eod_time",
            "now": now_dt.isoformat(),
            "eod_time": eod_dt.isoformat(),
            "isolated_instrument": get_selected_or_instrument_state(),
            "support_confirmation": get_support_confirmation_state(),
            "isolated_ema_alerts_count": len(_selected_or_ema_alerts),
        }
    selected = is_selected_or_instrument_locked()

    with _support_confirmation_lock:
        phase = _support_confirmation_state.get("phase")
        trigger_event = _support_confirmation_state.get("resistance_trigger_event")
        already_sent = bool(
            _support_confirmation_state.get("eod_no_confirmation_message_sent")
        )
    if selected:
        return {
            "status": "skipped",
            "reason": "instrument_already_isolated",
            "support_confirmation": get_support_confirmation_state(),
        }
    if not trigger_event:
        return {
            "status": "skipped",
            "reason": "no_resistance_trigger",
            "support_confirmation": get_support_confirmation_state(),
        }
    if already_sent:
        return {
            "status": "skipped",
            "reason": "eod_message_already_sent",
            "support_confirmation": get_support_confirmation_state(),
        }
    sent = False
    if DEFAULT_SUPPORT_CONFIRMATION_EOD_MESSAGE_ENABLED:
        sent = send_no_support_confirmation_eod_message()
    with _support_confirmation_lock:
        _support_confirmation_state["phase"] = "closed_without_support_confirmation"
        _support_confirmation_state["message"] = (
            "Market closed without final support confirmation instrument."
        )
        _support_confirmation_state["eod_no_confirmation_message_sent"] = True
    return {
        "status": "success" if sent else "not_sent",
        "message_sent": sent,
        "phase": phase,
        "support_confirmation": get_support_confirmation_state(),
    }


def try_isolate_from_touch_events(events: list) -> bool:
    """
    New support confirmation isolation flow.

    - R3 touch starts mandatory wait for opposite-side S3.
    - R2 touch starts wait for opposite-side S2.
    - R3 can upgrade an active R2/S2 wait into mandatory S3.
    - After S2 touch, wait DEFAULT_S2_TO_S3_WAIT_MINUTES for S3.
    - S3 within the window isolates S3; otherwise timeout isolates S2.
    """

    def start_s2_wait_window(s2_event: dict) -> bool:
        if not s2_event:
            return False
        now_dt = get_now_market_time()
        wait_until_dt = now_dt + timedelta(minutes=DEFAULT_S2_TO_S3_WAIT_MINUTES)
        with _support_confirmation_lock:
            _support_confirmation_state["phase"] = "waiting_for_s3_after_s2"
            _support_confirmation_state["message"] = (
                "S2 provisional support candidate found. Waiting for S3 upgrade."
            )
            _support_confirmation_state["provisional_s2_event"] = dict(s2_event)
            _support_confirmation_state["provisional_s2_selected_at"] = (
                now_dt.isoformat()
            )
            _support_confirmation_state["s3_wait_started_at"] = now_dt.isoformat()
            _support_confirmation_state["s3_wait_until"] = wait_until_dt.isoformat()
            _support_confirmation_state["s3_wait_minutes"] = (
                DEFAULT_S2_TO_S3_WAIT_MINUTES
            )
            should_send = not _support_confirmation_state.get(
                "s2_provisional_message_sent"
            )
            _support_confirmation_state["s2_provisional_message_sent"] = True
        if should_send:
            send_s2_provisional_support_message(
                s2_event, wait_until=wait_until_dt.strftime("%H:%M")
            )
        return True

    def set_r3_mandatory_wait(trigger_event: dict, expected_type: str | None) -> bool:
        if not trigger_event:
            return False
        trigger_type = get_event_option_type(trigger_event)
        with _support_confirmation_lock:
            _support_confirmation_state["phase"] = "waiting_for_s3_mandatory"
            _support_confirmation_state["message"] = (
                "R3 resistance trigger found. Waiting for mandatory S3 confirmation."
            )
            _support_confirmation_state["resistance_trigger_event"] = dict(
                trigger_event
            )
            _support_confirmation_state["resistance_trigger_level"] = "R3"
            _support_confirmation_state["resistance_trigger_instrument_key"] = (
                trigger_event.get("instrument_key")
            )
            _support_confirmation_state["resistance_trigger_option_type"] = trigger_type
            _support_confirmation_state["expected_support_option_type"] = expected_type
            _support_confirmation_state["resistance_trigger_at"] = (
                get_now_market_time().isoformat()
            )
            should_send = not _support_confirmation_state.get(
                "resistance_watch_message_sent"
            )
            _support_confirmation_state["resistance_watch_message_sent"] = True
        if should_send:
            send_support_confirmation_watch_message(trigger_event, expected_level="S3")
        return True

    def set_r2_wait_for_s2(trigger_event: dict, expected_type: str | None) -> bool:
        if not trigger_event:
            return False
        trigger_type = get_event_option_type(trigger_event)
        with _support_confirmation_lock:
            _support_confirmation_state["phase"] = "waiting_for_s2_confirmation"
            _support_confirmation_state["message"] = (
                "R2 resistance trigger found. Waiting for S2 confirmation."
            )
            _support_confirmation_state["resistance_trigger_event"] = dict(
                trigger_event
            )
            _support_confirmation_state["resistance_trigger_level"] = "R2"
            _support_confirmation_state["resistance_trigger_instrument_key"] = (
                trigger_event.get("instrument_key")
            )
            _support_confirmation_state["resistance_trigger_option_type"] = trigger_type
            _support_confirmation_state["expected_support_option_type"] = expected_type
            _support_confirmation_state["resistance_trigger_at"] = (
                get_now_market_time().isoformat()
            )
            should_send = not _support_confirmation_state.get(
                "resistance_watch_message_sent"
            )
            _support_confirmation_state["resistance_watch_message_sent"] = True
        if should_send:
            send_support_confirmation_watch_message(
                trigger_event, expected_level="S2 first, then S3 upgrade window"
            )
        return True

    if not events:
        process_s2_wait_timeout_if_needed()
        return False

    reset_support_confirmation_state_for_today_if_needed()

    if not DEFAULT_SUPPORT_CONFIRMATION_ENABLED:
        best_event = choose_best_isolation_event(events)
        if not best_event:
            return False
        return isolate_instrument_from_event(
            best_event, selection_reason="legacy_level_priority_isolation"
        )

    with _selected_or_lock:
        if _selected_or_instrument_state.get("selected"):
            return False

    process_s2_wait_timeout_if_needed()

    with _support_confirmation_lock:
        phase = _support_confirmation_state.get("phase")
        expected_support_option_type = _support_confirmation_state.get(
            "expected_support_option_type"
        )

    r3_triggers = [
        event
        for event in events
        if str(event.get("level", "")).upper() == "R3"
        and is_event_eligible_for_isolation(event)[0]
    ]
    r2_triggers = [
        event
        for event in events
        if str(event.get("level", "")).upper() == "R2"
        and is_event_eligible_for_isolation(event)[0]
    ]

    if phase == "waiting_for_s3_mandatory":
        s3_event = choose_best_support_event(
            events=events, level="S3", expected_option_type=expected_support_option_type
        )
        if s3_event:
            return isolate_instrument_from_event(
                s3_event, selection_reason="r3_trigger_s3_mandatory_confirmation"
            )
        return False

    if phase == "waiting_for_s2_confirmation":
        if r3_triggers and DEFAULT_R3_REQUIRES_S3_CONFIRMATION:
            trigger_event = choose_resistance_trigger_event(r3_triggers)
            if trigger_event:
                trigger_type = get_event_option_type(trigger_event)
                expected_type = get_opposite_option_type(trigger_type)
                set_r3_mandatory_wait(
                    trigger_event=trigger_event, expected_type=expected_type
                )
                s3_event = choose_best_support_event(
                    events=events, level="S3", expected_option_type=expected_type
                )
                if s3_event:
                    return isolate_instrument_from_event(
                        s3_event,
                        selection_reason="r3_upgrade_s3_same_batch_confirmation",
                    )
                return False
        s2_event = choose_best_support_event(
            events=events, level="S2", expected_option_type=expected_support_option_type
        )
        if s2_event:
            start_s2_wait_window(s2_event)
            s3_event = choose_best_support_event(
                events=events,
                level="S3",
                expected_option_type=expected_support_option_type,
            )
            if s3_event:
                return isolate_instrument_from_event(
                    s3_event, selection_reason="s3_same_batch_after_s2_confirmation"
                )
            return False
        return False

    if phase == "waiting_for_s3_after_s2":
        # R3 during S2 wait also upgrades to mandatory S3, but S3 remains the only finalizer.
        if r3_triggers and DEFAULT_R3_REQUIRES_S3_CONFIRMATION:
            trigger_event = choose_resistance_trigger_event(r3_triggers)
            if trigger_event:
                trigger_type = get_event_option_type(trigger_event)
                expected_type = get_opposite_option_type(trigger_type)
                set_r3_mandatory_wait(
                    trigger_event=trigger_event, expected_type=expected_type
                )
                s3_event = choose_best_support_event(
                    events=events, level="S3", expected_option_type=expected_type
                )
                if s3_event:
                    return isolate_instrument_from_event(
                        s3_event,
                        selection_reason="r3_upgrade_from_s2_wait_s3_confirmation",
                    )
                return False
        s3_event = choose_best_support_event(
            events=events, level="S3", expected_option_type=expected_support_option_type
        )
        if s3_event:
            return isolate_instrument_from_event(
                s3_event, selection_reason="s3_upgrade_within_s2_wait_window"
            )
        process_s2_wait_timeout_if_needed()
        return False

    if r3_triggers and DEFAULT_R3_REQUIRES_S3_CONFIRMATION:
        trigger_event = choose_resistance_trigger_event(r3_triggers)
        if trigger_event:
            trigger_type = get_event_option_type(trigger_event)
            expected_type = get_opposite_option_type(trigger_type)
            set_r3_mandatory_wait(
                trigger_event=trigger_event, expected_type=expected_type
            )
            s3_event = choose_best_support_event(
                events=events, level="S3", expected_option_type=expected_type
            )
            if s3_event:
                return isolate_instrument_from_event(
                    s3_event, selection_reason="r3_trigger_s3_same_batch_confirmation"
                )
            return False

    if r2_triggers and DEFAULT_R2_REQUIRES_S2_CONFIRMATION:
        trigger_event = choose_resistance_trigger_event(r2_triggers)
        if trigger_event:
            trigger_type = get_event_option_type(trigger_event)
            expected_type = get_opposite_option_type(trigger_type)
            set_r2_wait_for_s2(trigger_event=trigger_event, expected_type=expected_type)
            s2_event = choose_best_support_event(
                events=events, level="S2", expected_option_type=expected_type
            )
            if s2_event:
                start_s2_wait_window(s2_event)
                s3_event = choose_best_support_event(
                    events=events, level="S3", expected_option_type=expected_type
                )
                if s3_event:
                    return isolate_instrument_from_event(
                        s3_event,
                        selection_reason="r2_trigger_s2_and_s3_same_batch_confirmation",
                    )
            return False

    return False


# ============================================================
# Touch Detection
# ============================================================


def detect_touch_from_candle(
    instrument_key: str, candle: dict, levels: dict, contract_info: dict, source: str
) -> list:
    if not candle or not levels:
        return []
    events = []
    level_map = {
        "R2": {
            "value": safe_float(levels.get("r2")),
            "condition_field": "high",
            "trigger": safe_float(candle.get("high")),
            "fallback": safe_float(candle.get("close")),
            "direction": "above",
        },
        "R3": {
            "value": safe_float(levels.get("r3")),
            "condition_field": "high",
            "trigger": safe_float(candle.get("high")),
            "fallback": safe_float(candle.get("close")),
            "direction": "above",
        },
        "S2": {
            "value": safe_float(levels.get("s2")),
            "condition_field": "low",
            "trigger": safe_float(candle.get("low")),
            "fallback": safe_float(candle.get("close")),
            "direction": "below",
        },
        "S3": {
            "value": safe_float(levels.get("s3")),
            "condition_field": "low",
            "trigger": safe_float(candle.get("low")),
            "fallback": safe_float(candle.get("close")),
            "direction": "below",
        },
    }
    candle_time = candle.get("timestamp") or get_now_market_time().isoformat()
    for level_name, item in level_map.items():
        if level_name not in DEFAULT_ISOLATION_TOUCH_LEVELS:
            continue
        level_value = item["value"]
        if level_value <= 0:
            continue
        trigger_price = item["trigger"]
        trigger_field = item["condition_field"]
        if trigger_price <= 0:
            trigger_price = item["fallback"]
            trigger_field = "close"
        if trigger_price <= 0:
            continue
        touched = (
            trigger_price >= level_value
            if item["direction"] == "above"
            else trigger_price <= level_value
        )
        if not touched:
            continue
        if should_skip_touch_alert(instrument_key, level_name, contract_info):
            continue
        events.append(
            create_touch_event(
                instrument_key,
                level_name,
                level_value,
                trigger_price,
                trigger_field,
                candle_time,
                source,
                contract_info,
                candle,
            )
        )
    return events


def scan_backfill_touches(
    instrument_key: str,
    candles: list,
    levels: dict,
    contract_info: dict,
    candle_count: int,
) -> list:
    if not DEFAULT_BACKFILL_SCAN_ENABLED:
        return []
    post_or_candles = select_post_opening_range_candles(
        candles=candles, candle_count=candle_count
    )
    events = []
    for candle in post_or_candles:
        detected = detect_touch_from_candle(
            instrument_key=instrument_key,
            candle=candle,
            levels=levels,
            contract_info=contract_info,
            source="intraday_backfill_scan",
        )
        for event in detected:
            events.append(event)
            if DEFAULT_TOUCH_ALERT_ONCE_PER_LEVEL:
                mark_touch_alert_sent(event)
            update_touch_status_in_cache(instrument_key, event)
    return events


def extract_feed_values(tick_data: dict) -> dict:
    if not isinstance(tick_data, dict):
        return {}
    raw_feed_obj = tick_data.get("raw_feed", tick_data)
    full_feed = raw_feed_obj.get("fullFeed", raw_feed_obj)
    ff_wrapper = full_feed.get("ff", full_feed)
    ff = (
        ff_wrapper.get("marketFF")
        or ff_wrapper.get("indexFF")
        or full_feed.get("marketFF")
        or full_feed.get("indexFF")
        or full_feed
    )
    ltpc = ff.get("ltpc") or {}
    ltp = safe_float(ltpc.get("ltp"))
    ohlc_list = []
    if "marketOHLC" in ff:
        ohlc_list = ff.get("marketOHLC", {}).get("ohlc", [])
    elif "optionOHLC" in ff:
        ohlc_list = ff.get("optionOHLC", {}).get("ohlc", [])
    latest_i1 = None
    if isinstance(ohlc_list, list):
        matching = [
            item for item in ohlc_list if str(item.get("interval", "")).upper() == "I1"
        ]
        if matching:
            try:
                latest_i1 = max(matching, key=lambda item: int(item.get("ts", 0)))
            except Exception:
                latest_i1 = matching[-1]
    high_value = 0.0
    low_value = 0.0
    close_value = ltp
    timestamp = get_now_market_time().isoformat()
    if latest_i1:
        high_value = safe_float(latest_i1.get("high"))
        low_value = safe_float(latest_i1.get("low"))
        close_value = safe_float(latest_i1.get("close"), default=ltp)
        parsed_ts = parse_candle_timestamp(latest_i1.get("ts"))
        if parsed_ts:
            timestamp = parsed_ts.isoformat()
    return {
        "ltp": ltp,
        "high": high_value,
        "low": low_value,
        "close": close_value,
        "timestamp": timestamp,
    }


def process_live_tick_for_opening_range(
    instrument_key: str, tick_data: dict, contract_info: dict | None = None
) -> list:
    if not DEFAULT_LIVE_TOUCH_ALERT_ENABLED:
        return []
    if not instrument_key or not isinstance(tick_data, dict):
        return []
    feed_values = extract_feed_values(tick_data)
    ltp = safe_float(feed_values.get("ltp"))
    updated_at = feed_values.get("timestamp")
    update_latest_ltp_for_instrument(
        instrument_key=instrument_key, ltp=ltp, updated_at=updated_at
    )
    if instrument_key == DEFAULT_MAIN_INDEX_KEY and ltp > 0:
        update_latest_main_index_ltp(ltp=ltp, source="live_tick", updated_at=updated_at)
        process_s2_wait_timeout_if_needed()
        return []
    if not contract_info:
        contract_info = get_contract_info_by_key(instrument_key)
    if DEFAULT_TOUCH_ALERT_OPTIONS_ONLY and not is_option_contract(contract_info):
        process_s2_wait_timeout_if_needed()
        return []
    with _opening_range_cache_lock:
        item = opening_range_cache.get("data", {}).get(instrument_key)
    if not item or item.get("status") != "success":
        process_s2_wait_timeout_if_needed()
        return []
    levels = item.get("levels") or {}
    if not levels:
        process_s2_wait_timeout_if_needed()
        return []
    pseudo_candle = {
        "timestamp": feed_values.get("timestamp") or get_now_market_time().isoformat(),
        "open": 0.0,
        "high": feed_values.get("high"),
        "low": feed_values.get("low"),
        "close": feed_values.get("close") or feed_values.get("ltp"),
        "volume": 0,
        "oi": 0,
    }
    if DEFAULT_TOUCH_CHECK_MODE == "ltp":
        ltp_value = safe_float(feed_values.get("ltp"))
        pseudo_candle["high"] = ltp_value
        pseudo_candle["low"] = ltp_value
        pseudo_candle["close"] = ltp_value
    events = detect_touch_from_candle(
        instrument_key=instrument_key,
        candle=pseudo_candle,
        levels=levels,
        contract_info=contract_info,
        source="live_tick",
    )
    for event in events:
        if DEFAULT_TOUCH_ALERT_ONCE_PER_LEVEL:
            mark_touch_alert_sent(event)
        update_touch_status_in_cache(instrument_key, event)
        queue_touch_event(event)
    if events:
        try_isolate_from_touch_events(events)
    else:
        process_s2_wait_timeout_if_needed()
    return events


# ============================================================
# Legacy Telegram Touch Alert Helpers
# ============================================================


def get_sorted_touch_events_for_alert(events: list) -> list:
    if not events:
        return []
    if not DEFAULT_SORT_BY_NEAREST_INDEX:
        return events
    return sorted(
        events,
        key=lambda event: float(
            event.get("distance_from_index")
            if event.get("distance_from_index") is not None
            else 999999999
        ),
    )


def format_touch_event_line(index: int, event: dict) -> str:
    info = event.get("contract_info") or {}
    strike = info.get("strike_price", "N/A")
    itype = str(info.get("instrument_type", "N/A")).upper()
    symbol = (
        info.get("trading_symbol")
        or info.get("instrument_key")
        or event.get("instrument_key")
    )
    return (
        f"{index}. {strike} {itype}\n"
        f"   Symbol: {symbol}\n"
        f"   Level: {event.get('level')}\n"
        f"   Level Value: {event.get('level_value')}\n"
        f"   Trigger {event.get('trigger_field')}: {event.get('trigger_price')}\n"
        f"   Touch Time: {event.get('touch_time')}\n"
        f"   Distance From Index: {event.get('distance_from_index')}"
    )


def send_touch_events_telegram_alert(
    events: list, source: str, force: bool = False
) -> bool:
    global _last_touch_alert_sent_at
    if (
        not DEFAULT_LEGACY_TOUCH_TELEGRAM_ENABLED
        or not DEFAULT_TOUCH_ALERT_ENABLED
        or not events
    ):
        return False
    now_ts = time.time()
    if not force and _last_touch_alert_sent_at is not None:
        if now_ts - _last_touch_alert_sent_at < DEFAULT_TOUCH_ALERT_BATCH_SECONDS:
            return False
    sorted_events = get_sorted_touch_events_for_alert(events)
    selected_events = sorted_events[:DEFAULT_TOUCH_ALERT_MAX_INSTRUMENTS]
    index_ltp = get_latest_main_index_ltp()
    lines = [
        format_touch_event_line(index + 1, event)
        for index, event in enumerate(selected_events)
    ]
    message = (
        f"Source: {source}\n"
        f"NIFTY LTP: {index_ltp if index_ltp is not None else 'not_available'}\n"
        f"Total Touched Instruments: {len(events)}\n"
        f"Alerted Instruments: {len(selected_events)}\n\n" + "\n\n".join(lines)
    )
    sent = telegram_service.send_message(
        title="Opening Range Touch Alert", message=message, level="REFRESH"
    )
    if sent:
        _last_touch_alert_sent_at = now_ts
    return sent


def flush_pending_touch_alerts(force: bool = False, source: str = "live_tick") -> bool:
    if not DEFAULT_LEGACY_TOUCH_TELEGRAM_ENABLED:
        return False
    with _touch_lock:
        pending = list(_pending_touch_events)
        _pending_touch_events.clear()
    if not pending:
        return False
    sent = send_touch_events_telegram_alert(events=pending, source=source, force=force)
    if not sent:
        with _touch_lock:
            for event in pending:
                _pending_touch_events.appendleft(event)
    with _opening_range_cache_lock:
        opening_range_cache["pending_touch_events_count"] = len(_pending_touch_events)
    return sent


def is_manual_selected_instrument_active():
    with _manual_selected_or_lock:
        return bool(
            _manual_selected_or_instrument_state.get("selected")
            and _manual_selected_or_instrument_state.get("manual_override")
        )


def get_manual_selected_instrument_state():
    with _manual_selected_or_lock:
        return dict(_manual_selected_or_instrument_state)


def get_automatic_selected_or_instrument_state():
    with _selected_or_lock:
        return dict(_selected_or_instrument_state)


def get_effective_isolated_instrument_source():

    manual = get_manual_selected_instrument_state()

    if manual.get("selected"):

        mode = manual.get("selection_mode")

        if mode == "hard_select":
            return "hard_select"

        if mode == "manual_select" and DEFAULT_MANUAL_SELECTION_OVERRIDES_AUTO:
            return "manual_select"

    with _selected_or_lock:
        if _selected_or_instrument_state.get("selected"):
            return "auto_support_confirmation"

    return "none"


def get_effective_isolated_instrument_state():

    manual = get_manual_selected_instrument_state()

    if manual.get("selected"):

        mode = manual.get("selection_mode")

        if mode == "hard_select":
            return manual

        if mode == "manual_select" and DEFAULT_MANUAL_SELECTION_OVERRIDES_AUTO:
            return manual

    return get_automatic_selected_or_instrument_state()


# ============================================================
# Selected / Isolated Instrument Compatibility Helpers
# ============================================================


def is_selected_or_instrument_locked():
    return bool(get_effective_isolated_instrument_state().get("selected"))


def get_selected_or_instrument_key():
    return get_effective_isolated_instrument_state().get("instrument_key")


def get_selected_or_instrument_state():
    return get_effective_isolated_instrument_state()


def get_selected_or_ema_alerts(limit: int = 100) -> list:
    limit = max(1, int(limit or 100))
    with _selected_or_lock:
        return list(_selected_or_ema_alerts)[-limit:]


# ============================================================
# Isolated EMA Telegram Alert Helpers
# ============================================================


def get_isolated_instrument_type_from_state(selected_state: dict) -> str | None:
    if not isinstance(selected_state, dict):
        return None
    return normalize_option_type(
        (selected_state.get("contract_info") or {}).get("instrument_type")
    )


def get_suggested_order_instruments_for_ema(
    cross_type: str, isolated_instrument_type: str | None = None
) -> list:
    nifty_ltp = get_latest_main_index_ltp()
    if not nifty_ltp or nifty_ltp <= 0:
        logger.warning(
            "Suggested EMA order instruments could not be resolved because latest NIFTY LTP is not available."
        )
        return []
    instruments = get_nearest_order_instruments_for_ema_cross(
        current_nifty_ltp=nifty_ltp,
        cross_type=cross_type,
        isolated_instrument_type=isolated_instrument_type,
    )
    output = []
    for item in instruments:
        if not isinstance(item, dict):
            continue
        instrument_key = item.get("instrument_key")
        live_ltp = (
            get_latest_ltp_for_instrument(instrument_key) if instrument_key else None
        )
        output.append({**item, "live_ltp": live_ltp})
    return output


def format_suggested_order_instruments(instruments: list) -> str:
    if not instruments:
        return "Nearest Instrument Details: not_available"
    lines = ["Nearest Instrument Details:"]
    for item in instruments:
        if not isinstance(item, dict):
            continue
        strike = item.get("strike_price", "N/A")
        option_type = str(item.get("instrument_type", "N/A")).upper()
        live_ltp = item.get("live_ltp")
        price_text = "ltp_not_available" if live_ltp is None else f"{live_ltp}rs"
        lines.append(f"- {strike}{option_type} - {price_text}")
    return (
        "\n".join(lines)
        if len(lines) > 1
        else "Nearest Instrument Details: not_available"
    )


def normalize_ema_cross_direction(ema_event: dict) -> str:
    if not isinstance(ema_event, dict):
        return "unknown"
    cross_type = str(ema_event.get("cross_type", "")).strip().lower()
    current_signal = str(ema_event.get("current_signal", "")).strip().lower()
    if "bullish" in cross_type or current_signal == "bullish":
        return "bullish"
    if "bearish" in cross_type or current_signal == "bearish":
        return "bearish"
    return "unknown"


def get_ema_alert_minute_bucket(timestamp_value=None) -> str:
    if timestamp_value:
        parsed = parse_candle_timestamp(timestamp_value)
        if parsed:
            return parsed.strftime("%Y-%m-%dT%H:%M")
        text = str(timestamp_value)
        if "T" in text:
            return text[:16]
    return get_now_market_time().strftime("%Y-%m-%dT%H:%M")


def should_skip_isolated_ema_alert_for_minute_direction(
    instrument_key: str, ema_event: dict, timestamp_value=None
) -> tuple[bool, str, str]:
    global _selected_or_ema_alert_minute_date
    direction = normalize_ema_cross_direction(ema_event)
    minute_bucket = get_ema_alert_minute_bucket(timestamp_value)
    current_date = get_now_market_time().date().isoformat()
    alert_key = f"{instrument_key}_{minute_bucket}_{direction}"
    with _selected_or_lock:
        if _selected_or_ema_alert_minute_date != current_date:
            _selected_or_ema_alert_minute_keys.clear()
            _selected_or_ema_alert_minute_date = current_date
        if alert_key in _selected_or_ema_alert_minute_keys:
            return True, alert_key, direction
        _selected_or_ema_alert_minute_keys.add(alert_key)
    return False, alert_key, direction


def process_selected_or_ema_cross_alert(ema_event: dict) -> bool:
    if not DEFAULT_EMA_ISOLATED_TELEGRAM_ENABLED or not isinstance(ema_event, dict):
        return False

    selected_state = get_effective_isolated_instrument_state()

    if not selected_state.get("selected"):
        return False

    isolated_key = selected_state.get("instrument_key")
    event_key = ema_event.get("instrument_key")

    if not isolated_key or isolated_key != event_key:
        return False

    contract_info = selected_state.get("contract_info") or {}
    strike = contract_info.get("strike_price", "N/A")
    isolated_instrument_type = get_isolated_instrument_type_from_state(selected_state)
    option_type = isolated_instrument_type if isolated_instrument_type else "N/A"
    selected_level = selected_state.get("selected_level", "N/A")
    nifty_ltp = get_latest_main_index_ltp()

    cross_type = ema_event.get("cross_type", "N/A")
    current_signal = ema_event.get("current_signal", "N/A")
    close_price = ema_event.get("close")
    event_timestamp = ema_event.get("timestamp")

    if DEFAULT_LIVE_EMA_CALCULATION_MODE:
        skip_alert, minute_alert_key, alert_direction = (
            should_skip_isolated_ema_alert_for_minute_direction(
                instrument_key=event_key,
                ema_event=ema_event,
                timestamp_value=event_timestamp,
            )
        )

        if skip_alert:
            logger.info(
                f"Skipping duplicate tick EMA Telegram alert. "
                f"instrument_key={event_key}, alert_key={minute_alert_key}"
            )
            return False

    else:
        minute_alert_key = None
        alert_direction = normalize_ema_cross_direction(ema_event)

    ema_calculation_mode = ema_event.get(
        "ema_calculation_mode",
        get_live_ema_calculation_mode_text(),
    )

    price_label = "Live Tick LTP" if ema_calculation_mode == "tick_ltp" else "EMA Close"

    mode_description = (
        "Live tick/LTP based EMA cross detection"
        if ema_calculation_mode == "tick_ltp"
        else "Completed candle close based EMA cross detection"
    )

    suggested_instruments = get_suggested_order_instruments_for_ema(
        cross_type=cross_type,
        isolated_instrument_type=isolated_instrument_type,
    )

    suggested_order_option_type = (
        suggested_instruments[0].get("instrument_type")
        if suggested_instruments
        else None
    )

    suggested_order_type_display = (
        suggested_order_option_type if suggested_order_option_type else "not_available"
    )

    suggested_text = format_suggested_order_instruments(suggested_instruments)

    signal_text = str(current_signal or cross_type or "N/A").upper()

    try:
        short_event_time = (
            str(event_timestamp).split("T")[-1][:5]
            if event_timestamp
            else event_timestamp
        )
    except Exception:
        short_event_time = event_timestamp

    effective_source = get_effective_isolated_instrument_source()

    message = (
        f"{strike} {option_type} | {selected_level} | "
        f"NIFTY {nifty_ltp if nifty_ltp is not None else 'N/A'}\n\n"
        f"Signal: {signal_text}\n"
        f"Order Side: {suggested_order_type_display}\n"
        f"{price_label}: {close_price}\n"
        f"EMA Time: {short_event_time}\n"
        f"Instrument: {event_key}\n\n"
        f"{suggested_text}"
    )

    alert_record = {
        "type": "isolated_instrument_ema_alert",
        "instrument_key": event_key,
        "contract_info": contract_info,
        "selected_level": selected_level,
        "nifty_ltp": nifty_ltp,
        "isolated_instrument_type": isolated_instrument_type,
        "suggested_order_option_type": suggested_order_option_type,
        "order_side_rule": (
            "bullish_cross uses isolated instrument side; "
            "bearish_cross uses opposite side"
        ),
        "minute_alert_key": minute_alert_key,
        "alert_direction": alert_direction,
        "ema_calculation_mode": ema_calculation_mode,
        "ema_mode_description": mode_description,
        "ema_event": dict(ema_event),
        "suggested_order_instruments": suggested_instruments,
        "selection_mode": selected_state.get("selection_mode"),
        "selection_reason": selected_state.get("selection_reason"),
        "manual_override": selected_state.get("manual_override"),
        "effective_source": effective_source,
        "support_confirmation": get_support_confirmation_state(),
        "created_at": get_now_market_time().isoformat(),
    }

    logger.info(
        f"Processing isolated EMA Telegram alert. "
        f"instrument_key={event_key}, cross_type={cross_type}, "
        f"signal={signal_text}, effective_source={effective_source}"
    )

    sent = telegram_service.send_message(
        title="Isolated Instrument EMA Alert",
        message=message,
        level="EMA",
    )

    if sent:
        with _selected_or_lock:
            _selected_or_ema_alerts.append(alert_record)

        if effective_source in ["manual_select", "hard_select"]:
            with _manual_selected_or_lock:
                _manual_selected_or_instrument_state["ema_alerts_count"] = (
                    int(
                        _manual_selected_or_instrument_state.get(
                            "ema_alerts_count",
                            0,
                        )
                    )
                    + 1
                )
                _manual_selected_or_instrument_state["last_ema_alert"] = alert_record

                _manual_selected_or_instrument_state["latest_live_data"] = {
                    "ltp": get_latest_ltp_for_instrument(event_key)
                }

                _manual_selected_or_instrument_state["latest_main_index_ltp"] = (
                    get_latest_main_index_ltp()
                )

        else:
            with _selected_or_lock:
                _selected_or_instrument_state["ema_alerts_count"] = (
                    int(
                        _selected_or_instrument_state.get(
                            "ema_alerts_count",
                            0,
                        )
                    )
                    + 1
                )
                _selected_or_instrument_state["last_ema_alert"] = alert_record

                _selected_or_instrument_state["latest_live_data"] = {
                    "ltp": get_latest_ltp_for_instrument(event_key)
                }

                _selected_or_instrument_state["latest_main_index_ltp"] = (
                    get_latest_main_index_ltp()
                )

        with _opening_range_cache_lock:
            opening_range_cache["isolated_ema_alerts_count"] = len(
                _selected_or_ema_alerts
            )

            opening_range_cache["isolated_instrument"] = (
                get_effective_isolated_instrument_state()
            )

            opening_range_cache["manual_selected_instrument"] = (
                get_manual_selected_instrument_state()
            )

            opening_range_cache["automatic_isolated_instrument"] = (
                get_automatic_selected_or_instrument_state()
            )

            opening_range_cache["effective_isolated_instrument_source"] = (
                effective_source
            )

            opening_range_cache["manual_override_active"] = (
                is_manual_selected_instrument_active()
            )

    return sent


# ============================================================
# EMA WebSocket Opening Range Enrichment Helper
# ============================================================


def get_opening_range_levels_for_ema_event(instrument_key: str) -> dict:
    fallback = {
        "opening_range": {},
        "support_confirmation": get_support_confirmation_state(),
        "touch_status": get_default_touch_status(),
        "latest_intraday_close": None,
        "latest_main_index_ltp": None,
        "processed_at": None,
        "isolated_instrument": get_selected_or_instrument_state(),
    }
    if not DEFAULT_EMA_CROSS_INCLUDE_OPENING_RANGE_LEVELS or not instrument_key:
        return fallback
    with _opening_range_cache_lock:
        item = opening_range_cache.get("data", {}).get(instrument_key)
        latest_main_index_ltp = opening_range_cache.get("latest_main_index_ltp")
    if not item:
        fallback["latest_main_index_ltp"] = latest_main_index_ltp
        return fallback
    levels = item.get("levels") or {}
    compact_levels = {
        "r1": levels.get("r1"),
        "s1": levels.get("s1"),
        "r2": levels.get("r2"),
        "s2": levels.get("s2"),
        "r3": levels.get("r3"),
        "s3": levels.get("s3"),
        "sub_resistance": levels.get("sub_resistance"),
        "sub_support": levels.get("sub_support"),
    }
    return {
        "opening_range": compact_levels,
        "support_confirmation": get_support_confirmation_state(),
        "touch_status": item.get("touch_status", get_default_touch_status()),
        "latest_intraday_close": item.get("latest_intraday_close"),
        "latest_main_index_ltp": latest_main_index_ltp,
        "processed_at": item.get("processed_at"),
        "isolated_instrument": get_selected_or_instrument_state(),
    }


# ============================================================
# Storage Helpers
# ============================================================


def save_touch_events_to_file_if_enabled():
    if not bool(getattr(config, "TEST_FLAG", False)):
        return None
    if not DEFAULT_TOUCH_EVENTS_SAVE_TEST_FILE:
        return None
    try:
        file_path = Path(DEFAULT_TOUCH_EVENTS_OUTPUT_FILE)
        file_path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "generated_at": get_now_market_time().isoformat(),
            "live_ema_calculation_mode_flag": DEFAULT_LIVE_EMA_CALCULATION_MODE,
            "live_ema_calculation_mode": get_live_ema_calculation_mode_text(),
            "events_count": len(_touch_events),
            "events": list(_touch_events),
            "isolated_instrument": get_selected_or_instrument_state(),
            "support_confirmation": get_support_confirmation_state(),
            "isolated_ema_alerts_count": len(_selected_or_ema_alerts),
            "isolated_ema_alerts": list(_selected_or_ema_alerts),
        }
        with open(file_path, "w", encoding="utf-8") as file:
            json.dump(payload, file, indent=4, default=str)
        return str(file_path)
    except Exception as ex:
        logger.error(
            f"Failed saving opening range touch events: {type(ex).__name__}: {ex}"
        )
        return None


def save_opening_range_results_to_file(
    summary: dict, output_file: str = DEFAULT_OUTPUT_FILE
) -> str:
    file_path = Path(output_file)
    file_path.parent.mkdir(parents=True, exist_ok=True)
    with open(file_path, "w", encoding="utf-8") as file:
        json.dump(summary, file, indent=4, default=str)
    return str(file_path)


# ============================================================
# Intraday Fetch / Opening Range Calculation
# ============================================================


def fetch_intraday_candles_for_instrument(
    instrument_key: str,
    unit: str = DEFAULT_INTRADAY_UNIT,
    interval: str = DEFAULT_INTRADAY_INTERVAL,
) -> dict:
    try:
        api_instance = upstox_client.HistoryV3Api()
        logger.info(
            f"Opening range intraday request: instrument_key={instrument_key}, unit={unit}, interval={interval}"
        )
        api_response = api_instance.get_intra_day_candle_data(
            instrument_key, unit, interval
        )
        raw_candles = extract_candles_from_response(api_response)
        normalized_candles = normalize_candles(raw_candles)
        logger.info(
            f"Opening range intraday completed: instrument_key={instrument_key}, candles_count={len(normalized_candles)}"
        )
        return {
            "status": "success" if normalized_candles else "empty",
            "instrument_key": instrument_key,
            "unit": unit,
            "interval": interval,
            "candles": normalized_candles,
            "candles_count": len(normalized_candles),
            "error": None,
        }
    except ApiException as ex:
        error_body = getattr(ex, "body", str(ex))
        logger.error(
            f"ApiException in opening range intraday fetch for {instrument_key}: {error_body}"
        )
        return {
            "status": "failed",
            "instrument_key": instrument_key,
            "unit": unit,
            "interval": interval,
            "candles": [],
            "candles_count": 0,
            "error": error_body,
        }
    except Exception as ex:
        error_message = f"{type(ex).__name__}: {ex}"
        logger.error(
            f"Exception in opening range intraday fetch for {instrument_key}: {error_message}"
        )
        return {
            "status": "failed",
            "instrument_key": instrument_key,
            "unit": unit,
            "interval": interval,
            "candles": [],
            "candles_count": 0,
            "error": error_message,
        }


def calculate_opening_range_for_instrument(
    instrument_key: str, candle_count: int = DEFAULT_OPENING_RANGE_CANDLE_COUNT
) -> dict:
    processed_at = get_now_market_time().isoformat()
    contract_info = get_contract_info_by_key(instrument_key)
    intraday_result = fetch_intraday_candles_for_instrument(
        instrument_key=instrument_key,
        unit=DEFAULT_INTRADAY_UNIT,
        interval=DEFAULT_INTRADAY_INTERVAL,
    )
    base_payload = {
        "instrument_key": instrument_key,
        "source": "intraday_api",
        "date": get_now_market_time().date().isoformat(),
        "interval": DEFAULT_OPENING_RANGE_INTERVAL,
        "unit": DEFAULT_INTRADAY_UNIT,
        "intraday_interval": DEFAULT_INTRADAY_INTERVAL,
        "opening_range_candle_count": candle_count,
        "contract_info": contract_info,
        "processed_at": processed_at,
    }
    if intraday_result.get("status") == "failed":
        return {
            **base_payload,
            "status": "failed",
            "message": "Intraday candle fetch failed.",
            "candles_count": 0,
            "selected_candles_count": 0,
            "latest_intraday_close": None,
            "range": None,
            "levels": None,
            "selected_candles": [],
            "post_or_candles_count": 0,
            "touch_status": get_default_touch_status(),
            "backfill_touch_events": [],
            "error": intraday_result.get("error"),
        }
    candles = intraday_result.get("candles", [])
    if not candles:
        return {
            **base_payload,
            "status": "empty",
            "message": "No intraday candles returned.",
            "candles_count": 0,
            "selected_candles_count": 0,
            "latest_intraday_close": None,
            "range": None,
            "levels": None,
            "selected_candles": [],
            "post_or_candles_count": 0,
            "touch_status": get_default_touch_status(),
            "backfill_touch_events": [],
            "error": None,
        }
    latest_intraday_close = safe_float(candles[-1].get("close"))
    if instrument_key == DEFAULT_MAIN_INDEX_KEY and latest_intraday_close > 0:
        update_latest_main_index_ltp(
            ltp=latest_intraday_close,
            source="intraday_api",
            updated_at=candles[-1].get("timestamp"),
        )
    selected_candles = select_opening_range_candles(
        candles=candles, candle_count=candle_count
    )
    if len(selected_candles) < int(candle_count):
        return {
            **base_payload,
            "status": "insufficient_data",
            "message": f"Need {candle_count} opening range candles, but only {len(selected_candles)} available.",
            "candles_count": len(candles),
            "selected_candles_count": len(selected_candles),
            "latest_intraday_close": latest_intraday_close,
            "range": None,
            "levels": None,
            "selected_candles": [serialize_candle(item) for item in selected_candles],
            "post_or_candles_count": 0,
            "touch_status": get_default_touch_status(),
            "backfill_touch_events": [],
            "error": None,
        }
    calculation = calculate_opening_range_levels(selected_candles)
    levels = calculation.get("levels") or {}
    post_or_candles = select_post_opening_range_candles(
        candles=candles, candle_count=candle_count
    )
    backfill_touch_events = []
    if calculation.get("status") == "success":
        backfill_touch_events = scan_backfill_touches(
            instrument_key=instrument_key,
            candles=candles,
            levels=levels,
            contract_info=contract_info,
            candle_count=candle_count,
        )
    touch_status = build_touch_status_from_events(backfill_touch_events)
    return {
        **base_payload,
        "status": calculation.get("status"),
        "message": calculation.get("message"),
        "candles_count": len(candles),
        "selected_candles_count": len(selected_candles),
        "latest_intraday_close": latest_intraday_close,
        "range": calculation.get("range"),
        "levels": levels,
        "selected_candles": [serialize_candle(item) for item in selected_candles],
        "post_or_candles_count": len(post_or_candles),
        "touch_status": touch_status,
        "backfill_touch_events": backfill_touch_events,
        "error": None,
    }


def calculate_opening_range_for_all_subscribed(
    candle_count: int = DEFAULT_OPENING_RANGE_CANDLE_COUNT,
    save_data: bool = DEFAULT_SAVE_FILE,
    max_workers: int = DEFAULT_MAX_WORKERS,
) -> dict:
    reset_support_confirmation_state_for_today_if_needed()
    if not is_opening_range_enabled():
        logger.info("Opening range calculation skipped because it is disabled.")
        return {
            "status": "disabled",
            "message": "Opening range calculation is disabled.",
            "total_instruments": 0,
            "success_count": 0,
            "failed_count": 0,
            "empty_count": 0,
            "insufficient_data_count": 0,
        }
    subscribed_keys = get_subscribed_instrument_keys()
    if not subscribed_keys:
        logger.warning(
            "Opening range calculation skipped. No subscribed instruments found."
        )
        return {
            "status": "skipped",
            "message": "No subscribed instruments found.",
            "total_instruments": 0,
            "success_count": 0,
            "failed_count": 0,
            "empty_count": 0,
            "insufficient_data_count": 0,
        }
    try:
        candle_count = max(1, int(candle_count))
    except Exception:
        candle_count = DEFAULT_OPENING_RANGE_CANDLE_COUNT
    try:
        max_workers = max(1, int(max_workers))
    except Exception:
        max_workers = DEFAULT_MAX_WORKERS
    now_market = get_now_market_time()
    started_at = now_market.isoformat()
    current_date = now_market.date().isoformat()
    logger.info(
        "================ OPENING RANGE INTRADAY FETCH STARTED ================"
    )
    logger.info(
        f"Calculating opening range for {len(subscribed_keys)} instruments. date={current_date}, candle_count={candle_count}, max_workers={max_workers}"
    )
    results = {}
    errors = {}
    success_count = 0
    failed_count = 0
    empty_count = 0
    insufficient_data_count = 0
    total_backfill_touch_events = 0
    backfill_touch_events = []
    completed_count = 0
    total_instruments = len(subscribed_keys)

    def worker(instrument_key: str) -> dict:
        result = calculate_opening_range_for_instrument(
            instrument_key=instrument_key, candle_count=candle_count
        )
        if DEFAULT_SLEEP_SECONDS and DEFAULT_SLEEP_SECONDS > 0:
            time.sleep(DEFAULT_SLEEP_SECONDS)
        return result

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_instrument = {
            executor.submit(worker, instrument_key): instrument_key
            for instrument_key in subscribed_keys
        }
        for future in as_completed(future_to_instrument):
            instrument_key = future_to_instrument[future]
            completed_count += 1
            logger.info(
                f"Opening range progress: {completed_count}/{total_instruments} instrument_key={instrument_key}"
            )
            try:
                result = future.result()
                result_status = result.get("status")
                results[instrument_key] = result
                instrument_backfill_events = result.get("backfill_touch_events", [])
                if instrument_backfill_events:
                    total_backfill_touch_events += len(instrument_backfill_events)
                    backfill_touch_events.extend(instrument_backfill_events)
                    for event in instrument_backfill_events:
                        queue_touch_event(event)
                if result_status == "success":
                    success_count += 1
                elif result_status == "empty":
                    empty_count += 1
                elif result_status == "insufficient_data":
                    insufficient_data_count += 1
                else:
                    failed_count += 1
                    errors[instrument_key] = result.get("error") or result.get(
                        "message"
                    )
            except Exception as ex:
                error_message = f"{type(ex).__name__}: {ex}"
                logger.error(
                    f"Opening range calculation failed for instrument_key={instrument_key}: {error_message}"
                )
                failed_count += 1
                errors[instrument_key] = error_message
                results[instrument_key] = {
                    "instrument_key": instrument_key,
                    "status": "failed",
                    "message": "Opening range worker failed.",
                    "source": "intraday_api",
                    "date": current_date,
                    "interval": DEFAULT_OPENING_RANGE_INTERVAL,
                    "opening_range_candle_count": candle_count,
                    "latest_intraday_close": None,
                    "range": None,
                    "levels": None,
                    "touch_status": get_default_touch_status(),
                    "backfill_touch_events": [],
                    "error": error_message,
                    "contract_info": get_contract_info_by_key(instrument_key),
                    "processed_at": get_now_market_time().isoformat(),
                }
    completed_at = get_now_market_time().isoformat()
    if failed_count == 0:
        overall_status = "success"
    elif success_count > 0 or empty_count > 0 or insufficient_data_count > 0:
        overall_status = "partial_success"
    else:
        overall_status = "failed"
    with _opening_range_cache_lock:
        opening_range_cache["last_run_at"] = completed_at
        opening_range_cache["date"] = current_date
        opening_range_cache["status"] = overall_status
        opening_range_cache["message"] = "Opening range calculation completed."
        opening_range_cache["source"] = "intraday_api"
        opening_range_cache["interval"] = DEFAULT_OPENING_RANGE_INTERVAL
        opening_range_cache["opening_range_candle_count"] = candle_count
        opening_range_cache["market_open_time"] = (
            f"{DEFAULT_MARKET_OPEN_HOUR:02d}:{DEFAULT_MARKET_OPEN_MINUTE:02d}"
        )
        opening_range_cache["fetch_time"] = (
            f"{DEFAULT_FETCH_HOUR:02d}:{DEFAULT_FETCH_MINUTE:02d}"
        )
        opening_range_cache["total_instruments"] = total_instruments
        opening_range_cache["success_count"] = success_count
        opening_range_cache["failed_count"] = failed_count
        opening_range_cache["empty_count"] = empty_count
        opening_range_cache["insufficient_data_count"] = insufficient_data_count
        opening_range_cache["latest_main_index_ltp"] = get_latest_main_index_ltp()
        opening_range_cache["latest_main_index_ltp_source"] = (
            _latest_main_index_ltp_source
        )
        opening_range_cache["latest_main_index_ltp_updated_at"] = (
            _latest_main_index_ltp_updated_at
        )
        opening_range_cache["touch_events_count"] = len(_touch_events)
        opening_range_cache["pending_touch_events_count"] = len(_pending_touch_events)
        opening_range_cache["alert_sent_keys_count"] = len(_alert_sent_keys)
        opening_range_cache["data"] = results
        opening_range_cache["touch_events"] = list(_touch_events)
        opening_range_cache["errors"] = errors
    if backfill_touch_events:
        try_isolate_from_touch_events(backfill_touch_events)
    else:
        process_s2_wait_timeout_if_needed()
    summary = {
        "status": overall_status,
        "message": "Opening range calculation completed.",
        "source": "intraday_api",
        "date": current_date,
        "started_at": started_at,
        "completed_at": completed_at,
        "interval": DEFAULT_OPENING_RANGE_INTERVAL,
        "unit": DEFAULT_INTRADAY_UNIT,
        "intraday_interval": DEFAULT_INTRADAY_INTERVAL,
        "opening_range_candle_count": candle_count,
        "market_open_time": f"{DEFAULT_MARKET_OPEN_HOUR:02d}:{DEFAULT_MARKET_OPEN_MINUTE:02d}",
        "live_ema_calculation_mode_flag": DEFAULT_LIVE_EMA_CALCULATION_MODE,
        "live_ema_calculation_mode": get_live_ema_calculation_mode_text(),
        "opening_range_end_time": get_opening_range_end_datetime(
            candle_count=candle_count
        ).strftime("%H:%M"),
        "scheduled_fetch_time": f"{DEFAULT_FETCH_HOUR:02d}:{DEFAULT_FETCH_MINUTE:02d}",
        "max_workers": max_workers,
        "total_instruments": total_instruments,
        "success_count": success_count,
        "failed_count": failed_count,
        "empty_count": empty_count,
        "insufficient_data_count": insufficient_data_count,
        "backfill_touch_scan_enabled": DEFAULT_BACKFILL_SCAN_ENABLED,
        "backfill_touch_events_count": total_backfill_touch_events,
        "latest_main_index_ltp": get_latest_main_index_ltp(),
        "isolated_instrument": get_selected_or_instrument_state(),
        "support_confirmation": get_support_confirmation_state(),
        "isolated_ema_alerts_count": len(_selected_or_ema_alerts),
        "results": results,
        "backfill_touch_events": backfill_touch_events,
        "errors": errors,
    }
    output_file_path = None
    if save_data:
        try:
            output_file_path = save_opening_range_results_to_file(summary)
            summary["output_file_path"] = output_file_path
            logger.info(f"Saved opening range results to {output_file_path}")
        except Exception as ex:
            error_message = f"{type(ex).__name__}: {ex}"
            logger.error(f"Failed saving opening range results: {error_message}")
            summary["output_file_error"] = error_message
    else:
        logger.info("Opening range result file not saved because save_data=False.")
    with _opening_range_cache_lock:
        opening_range_cache["output_file_path"] = output_file_path
        opening_range_cache["isolated_instrument"] = get_selected_or_instrument_state()
        opening_range_cache["isolated_instrument_selected"] = bool(
            get_selected_or_instrument_state().get("selected")
        )
        opening_range_cache["isolated_ema_alerts_count"] = len(_selected_or_ema_alerts)
        opening_range_cache["support_confirmation"] = get_support_confirmation_state()
    if (
        DEFAULT_BACKFILL_TOUCH_ALERT_ENABLED
        and DEFAULT_TOUCH_ALERT_ENABLED
        and DEFAULT_LEGACY_TOUCH_TELEGRAM_ENABLED
        and backfill_touch_events
    ):
        send_touch_events_telegram_alert(
            events=backfill_touch_events, source="intraday_backfill_scan", force=True
        )
    save_touch_events_to_file_if_enabled()
    logger.info(
        f"Opening range calculation completed. status={overall_status}, total_instruments={total_instruments}, "
        f"success={success_count}, empty={empty_count}, insufficient_data={insufficient_data_count}, "
        f"failed={failed_count}, backfill_touch_events={total_backfill_touch_events}, "
        f"isolated_selected={get_selected_or_instrument_state().get('selected')}, output_file={output_file_path}"
    )
    logger.info(
        "================ OPENING RANGE INTRADAY FETCH COMPLETED ================"
    )
    return summary


# ============================================================
# Status Helpers
# ============================================================


def get_support_confirmation_status() -> dict:
    return {
        "status": "success",
        "support_confirmation": get_support_confirmation_state(),
        "isolated_instrument": get_selected_or_instrument_state(),
        "config": {
            "enabled": DEFAULT_SUPPORT_CONFIRMATION_ENABLED,
            "r3_requires_s3_confirmation": DEFAULT_R3_REQUIRES_S3_CONFIRMATION,
            "r2_requires_s2_confirmation": DEFAULT_R2_REQUIRES_S2_CONFIRMATION,
            "s2_to_s3_wait_minutes": DEFAULT_S2_TO_S3_WAIT_MINUTES,
            "eod_hour": DEFAULT_SUPPORT_CONFIRMATION_EOD_HOUR,
            "eod_minute": DEFAULT_SUPPORT_CONFIRMATION_EOD_MINUTE,
            "eod_message_enabled": DEFAULT_SUPPORT_CONFIRMATION_EOD_MESSAGE_ENABLED,
        },
    }


def get_opening_range_status() -> dict:
    with _opening_range_cache_lock:
        return {
            "last_run_at": opening_range_cache.get("last_run_at"),
            "date": opening_range_cache.get("date"),
            "status": opening_range_cache.get("status"),
            "message": opening_range_cache.get("message"),
            "source": opening_range_cache.get("source"),
            "interval": opening_range_cache.get("interval"),
            "opening_range_candle_count": opening_range_cache.get(
                "opening_range_candle_count"
            ),
            "manual_selected_instrument": get_manual_selected_instrument_state(),
            "automatic_isolated_instrument": get_automatic_selected_or_instrument_state(),
            "effective_isolated_instrument": get_effective_isolated_instrument_state(),
            "effective_isolated_instrument_source": get_effective_isolated_instrument_source(),
            "manual_override_active": is_manual_selected_instrument_active(),
            "market_open_time": opening_range_cache.get("market_open_time"),
            "fetch_time": opening_range_cache.get("fetch_time"),
            "total_instruments": opening_range_cache.get("total_instruments"),
            "success_count": opening_range_cache.get("success_count"),
            "failed_count": opening_range_cache.get("failed_count"),
            "empty_count": opening_range_cache.get("empty_count"),
            "insufficient_data_count": opening_range_cache.get(
                "insufficient_data_count"
            ),
            "output_file_path": opening_range_cache.get("output_file_path"),
            "latest_main_index_ltp": opening_range_cache.get("latest_main_index_ltp"),
            "latest_main_index_ltp_source": opening_range_cache.get(
                "latest_main_index_ltp_source"
            ),
            "latest_main_index_ltp_updated_at": opening_range_cache.get(
                "latest_main_index_ltp_updated_at"
            ),
            "touch_events_count": opening_range_cache.get("touch_events_count"),
            "pending_touch_events_count": opening_range_cache.get(
                "pending_touch_events_count"
            ),
            "alert_sent_keys_count": opening_range_cache.get("alert_sent_keys_count"),
            "isolated_instrument": get_selected_or_instrument_state(),
            "isolated_instrument_selected": bool(
                get_selected_or_instrument_state().get("selected")
            ),
            "isolated_ema_alerts_count": len(_selected_or_ema_alerts),
            "support_confirmation": get_support_confirmation_state(),
            "ema_cross_include_opening_range_levels": DEFAULT_EMA_CROSS_INCLUDE_OPENING_RANGE_LEVELS,
            "live_ema_calculation": {
                "flag": DEFAULT_LIVE_EMA_CALCULATION_MODE,
                "mode": get_live_ema_calculation_mode_text(),
                "description": (
                    "live tick/LTP based EMA calculation"
                    if DEFAULT_LIVE_EMA_CALCULATION_MODE
                    else "completed candle close based EMA calculation"
                ),
            },
            "isolation_config": {
                "enabled": DEFAULT_ISOLATION_ENABLED,
                "window_points": DEFAULT_ISOLATION_WINDOW_POINTS,
                "touch_levels": DEFAULT_ISOLATION_TOUCH_LEVELS,
                "priority_levels": DEFAULT_ISOLATION_PRIORITY_LEVELS,
                "lock_for_day": DEFAULT_ISOLATION_LOCK_FOR_DAY,
                "allow_priority_upgrade": DEFAULT_ISOLATION_ALLOW_PRIORITY_UPGRADE,
                "support_confirmation_enabled": DEFAULT_SUPPORT_CONFIRMATION_ENABLED,
                "r3_requires_s3_confirmation": DEFAULT_R3_REQUIRES_S3_CONFIRMATION,
                "r2_requires_s2_confirmation": DEFAULT_R2_REQUIRES_S2_CONFIRMATION,
                "s2_to_s3_wait_minutes": DEFAULT_S2_TO_S3_WAIT_MINUTES,
                "eod_check_time": f"{DEFAULT_SUPPORT_CONFIRMATION_EOD_HOUR:02d}:{DEFAULT_SUPPORT_CONFIRMATION_EOD_MINUTE:02d}",
                "eod_message_enabled": DEFAULT_SUPPORT_CONFIRMATION_EOD_MESSAGE_ENABLED,
            },
            "errors": opening_range_cache.get("errors", {}),
        }


def get_opening_range_cache() -> dict:
    with _opening_range_cache_lock:
        cache_copy = dict(opening_range_cache)
    cache_copy["isolated_instrument"] = get_selected_or_instrument_state()
    cache_copy["isolated_ema_alerts_count"] = len(_selected_or_ema_alerts)
    cache_copy["support_confirmation"] = get_support_confirmation_state()
    cache_copy["live_ema_calculation_mode_flag"] = DEFAULT_LIVE_EMA_CALCULATION_MODE
    cache_copy["live_ema_calculation_mode"] = get_live_ema_calculation_mode_text()
    cache_copy["manual_selected_instrument"] = get_manual_selected_instrument_state()

    cache_copy["automatic_isolated_instrument"] = (
        get_automatic_selected_or_instrument_state()
    )

    cache_copy["effective_isolated_instrument"] = (
        get_effective_isolated_instrument_state()
    )

    cache_copy["effective_isolated_instrument_source"] = (
        get_effective_isolated_instrument_source()
    )

    cache_copy["manual_override_active"] = is_manual_selected_instrument_active()
    cache_copy["live_ema_calculation"] = {
        "flag": DEFAULT_LIVE_EMA_CALCULATION_MODE,
        "mode": get_live_ema_calculation_mode_text(),
        "description": (
            "live tick/LTP based EMA calculation"
            if DEFAULT_LIVE_EMA_CALCULATION_MODE
            else "completed candle close based EMA calculation"
        ),
    }
    return cache_copy


def get_opening_range_dashboard_summary(
    touch_limit: int = 100, alert_limit: int = 100
) -> dict:
    touch_limit = max(1, int(touch_limit or 100))
    alert_limit = max(1, int(alert_limit or 100))
    with _opening_range_cache_lock:
        cache_snapshot = dict(opening_range_cache)
        latest_main_index_ltp = opening_range_cache.get("latest_main_index_ltp")
        latest_main_index_ltp_source = opening_range_cache.get(
            "latest_main_index_ltp_source"
        )
        latest_main_index_ltp_updated_at = opening_range_cache.get(
            "latest_main_index_ltp_updated_at"
        )
    isolated_state = get_selected_or_instrument_state()
    isolated_key = isolated_state.get("instrument_key")
    isolated_opening_range_context = {}
    if isolated_key:
        try:
            isolated_opening_range_context = get_opening_range_levels_for_ema_event(
                isolated_key
            )
        except Exception as ex:
            isolated_opening_range_context = {
                "status": "error",
                "error": f"{type(ex).__name__}: {ex}",
            }
    recent_touch_events = get_opening_range_touch_events(limit=touch_limit)
    isolated_ema_alerts = get_selected_or_ema_alerts(limit=alert_limit)
    manual_state = get_manual_selected_instrument_state()

    automatic_state = get_automatic_selected_or_instrument_state()

    effective_state = get_effective_isolated_instrument_state()

    effective_source = get_effective_isolated_instrument_source()

    return {
        "status": "success",
        "generated_at": get_now_market_time().isoformat(),
        "date": get_now_market_time().date().isoformat(),
        "live_ema_calculation": {
            "flag": DEFAULT_LIVE_EMA_CALCULATION_MODE,
            "mode": get_live_ema_calculation_mode_text(),
            "description": (
                "live tick/LTP based EMA calculation"
                if DEFAULT_LIVE_EMA_CALCULATION_MODE
                else "completed candle close based EMA calculation"
            ),
        },
        "manual_selected_instrument": manual_state,
        "automatic_isolated_instrument": automatic_state,
        "effective_isolated_instrument": effective_state,
        "effective_source": effective_source,
        "manual_override_active": is_manual_selected_instrument_active(),
        "opening_range_status": get_opening_range_status(),
        "support_confirmation": get_support_confirmation_state(),
        "isolated_instrument": isolated_state,
        "selected_or_instrument": isolated_state,
        "isolated_opening_range_context": isolated_opening_range_context,
        "isolated_ema_alerts_count": len(_selected_or_ema_alerts),
        "isolated_ema_alerts": isolated_ema_alerts,
        "recent_touch_events_count": len(recent_touch_events),
        "recent_touch_events": recent_touch_events,
        "latest_main_index_ltp": latest_main_index_ltp,
        "latest_main_index_ltp_source": latest_main_index_ltp_source,
        "latest_main_index_ltp_updated_at": latest_main_index_ltp_updated_at,
        "cache_summary": {
            "last_run_at": cache_snapshot.get("last_run_at"),
            "date": cache_snapshot.get("date"),
            "status": cache_snapshot.get("status"),
            "message": cache_snapshot.get("message"),
            "source": cache_snapshot.get("source"),
            "interval": cache_snapshot.get("interval"),
            "opening_range_candle_count": cache_snapshot.get(
                "opening_range_candle_count"
            ),
            "total_instruments": cache_snapshot.get("total_instruments"),
            "success_count": cache_snapshot.get("success_count"),
            "failed_count": cache_snapshot.get("failed_count"),
            "empty_count": cache_snapshot.get("empty_count"),
            "insufficient_data_count": cache_snapshot.get("insufficient_data_count"),
            "touch_events_count": cache_snapshot.get("touch_events_count"),
            "pending_touch_events_count": cache_snapshot.get(
                "pending_touch_events_count"
            ),
            "alert_sent_keys_count": cache_snapshot.get("alert_sent_keys_count"),
            "output_file_path": cache_snapshot.get("output_file_path"),
        },
    }


def get_opening_range_for_instrument_from_cache(instrument_key: str) -> dict | None:
    with _opening_range_cache_lock:
        return opening_range_cache.get("data", {}).get(instrument_key)


def get_opening_range_touch_events(limit: int = 100) -> list:
    limit = max(1, int(limit or 100))
    with _touch_lock:
        return list(_touch_events)[-limit:]


def get_opening_range_pending_touch_events() -> list:
    with _touch_lock:
        return list(_pending_touch_events)
