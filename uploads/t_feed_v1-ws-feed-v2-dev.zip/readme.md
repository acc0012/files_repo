# Live Option Feed Engine

A FastAPI-based live market feed engine for NIFTY option contracts using the Upstox WebSocket feed. The application fetches NIFTY option contracts, subscribes to the NIFTY index and filtered option instruments, receives live ticks from Upstox, normalizes incoming feed data, calculates historical and live EMA crossover signals, and broadcasts updates to browser clients over local FastAPI WebSocket endpoints.

The project has evolved from a static single-option dashboard into a route-segregated FastAPI application with:

- A FastAPI-rendered dashboard served from `templates/index.html`
- Live `/all-feeds` WebSocket streaming
- A NIFTY index header card
- Dynamic nearest CE and PE option cards based on live NIFTY LTP
- Historical candle loading for EMA 9/21 crossover initialization
- Live EMA continuation from historical EMA state
- Global EMA crossover WebSocket stream
- Individual instrument-level EMA crossover WebSocket stream
- Scheduled daily hard refresh at 09:00 AM IST, Monday to Friday
- Manual hard refresh API and dashboard button
- Telegram notifications for startup, refresh, subscription, token, instruments, historical EMA, shutdown, and errors

---

## Project Purpose

This project acts as a local live option feed gateway and EMA crossover signal engine.

It handles:

1. Loading Upstox access tokens from MongoDB.
2. Fetching nearest NIFTY option contracts using the Upstox Options API.
3. Filtering option contracts by configured strike range.
4. Subscribing to the NIFTY index plus filtered option contracts.
5. Connecting to Upstox `MarketDataStreamerV3`.
6. Parsing raw live feed ticks into a normalized JSON format.
7. Broadcasting normalized ticks to connected FastAPI WebSocket clients.
8. Fetching historical candles for all subscribed instruments.
9. Calculating EMA 9/21 crossover summary from historical candles.
10. Initializing live EMA state from historical EMA values.
11. Continuing EMA calculation using live Upstox full-feed I1 candles.
12. Broadcasting live EMA crossover events globally and per instrument.
13. Rendering a browser dashboard through FastAPI templates.
14. Showing live NIFTY index data in the dashboard header.
15. Showing nearest CE and PE option cards based on live NIFTY LTP.
16. Supporting automatic scheduled hard refresh.
17. Supporting manual hard refresh through an API and UI button.
18. Sending Telegram alerts for important lifecycle events and failures.
19. Providing debug, health, history, and live EMA status endpoints for local testing.

---

## Current Project Structure

```text
t_feed_v1-ws-feed/
│
├── main.py
├── requirements.txt
├── Procfile
├── run.bat
├── .env
├── README.md
│
├── api/
│   ├── __init__.py
│   ├── home_routes.py
│   ├── health_routes.py
│   ├── debug_routes.py
│   ├── refresh_routes.py
│   └── history_routes.py
│
├── core/
│   ├── config.py
│   └── logger.py
│
├── data/
│   ├── nearest_nifty_option_contracts.json
│   ├── ema_cross_results.json
│   └── live_ema_cross_results.json
│
├── services/
│   ├── option_service.py
│   ├── telegram_service.py
│   ├── token_service.py
│   ├── history_service.py
│   ├── live_ema_service.py
│   └── upstox_websocket.py
│
├── templates/
│   └── index.html
│
└── ws_feed/
    ├── __init__.py
    ├── broadcaster.py
    └── websocket_routes.py
```

---

## Main Components

### `main.py`

Main FastAPI application entry point.

Responsibilities:

- Creates the FastAPI app.
- Registers CORS middleware.
- Registers all HTTP and WebSocket route modules.
- Runs startup lifecycle logic.
- Refreshes token from MongoDB during startup.
- Loads option contracts and subscription keys.
- Fetches historical candles and calculates EMA crossover summary during startup.
- Initializes live EMA state from historical EMA summary.
- Starts APScheduler background jobs.
- Starts the Upstox WebSocket streamer.
- Performs daily hard refresh scheduling.
- Recalculates historical EMA during daily hard refresh.
- Restarts Upstox streamer after refresh.
- Sends Telegram notifications for startup, scheduler, refresh, historical EMA, subscription, errors, and shutdown.
- Stops streamer and scheduler during shutdown.

Registered route modules:

```python
app.include_router(home_router)
app.include_router(health_router)
app.include_router(debug_router)
app.include_router(refresh_router)
app.include_router(history_router)
app.include_router(websocket_router)
```

Startup lifecycle flow:

```text
Application startup
    -> token_service.refresh_tokens()
    -> get_options_contracts(save_data=True)
    -> update options_cache and subscribed_keys
    -> fetch historical candles for subscribed instruments
    -> calculate EMA 9/21 crossover summary
    -> initialize live EMA service state
    -> start APScheduler
    -> start Upstox streamer
    -> send Telegram startup/subscription notifications
```

Daily hard refresh flow:

```text
Mon-Fri 09:00 AM IST
    -> refresh token from MongoDB
    -> fetch latest option contracts
    -> filter instruments by configured strike range
    -> update options_cache subscribed_keys
    -> fetch historical candles and calculate EMA 9/21 crossover
    -> reinitialize live EMA service state
    -> restart Upstox streamer
    -> send Telegram refresh/subscription notifications
```

---

## API Routes

### `api/home_routes.py`

Serves the dashboard home page.

#### Endpoint

```text
GET /
```

Renders:

```text
templates/index.html
```

This is the main browser dashboard route.

---

### `api/health_routes.py`

Contains the health check route.

#### Endpoint

```text
GET /health
```

Returns:

- Application health status
- Token availability
- Options cache status
- Upstox WebSocket streamer status
- Subscribed instrument count
- Connected WebSocket client count

Example response:

```json
{
  "status": "healthy",
  "timestamp": "2026-08-04T00:00:00+00:00",
  "services": {
    "token_service": "active",
    "options_cache": "loaded (83 keys)",
    "websocket_feed": "active"
  },
  "metrics": {
    "subscribed_instruments": 83,
    "connected_ws_clients": 1
  }
}
```

---

### `api/debug_routes.py`

Contains local testing and debugging routes.

#### Endpoints

```text
GET /test-broadcast
GET /test-broadcast-option
GET /debug/cache
GET /debug/find-option?strike=24500&striketype=ce
```

#### `/test-broadcast`

Sends a sample NIFTY index tick to connected `/ws` and `/all-feeds` clients.

#### `/test-broadcast-option`

Sends a sample `NIFTY 24500 CE` option tick to connected `/option` clients.

#### `/debug/cache`

Returns the current in-memory options cache summary.

#### `/debug/find-option`

Searches the current options cache for a matching strike and CE/PE type.

Example:

```text
http://127.0.0.1:8000/debug/find-option?strike=24500&striketype=ce
```

---

### `api/refresh_routes.py`

Contains manual market hard refresh APIs.

#### Endpoints

```text
POST /refresh/manual
GET  /refresh/status
```

#### `POST /refresh/manual`

Manually triggers the hard refresh workflow.

Steps performed:

1. Refresh token document from MongoDB.
2. Load latest token into memory.
3. Fetch latest NIFTY option contracts.
4. Filter instruments by configured strike range.
5. Update `options_cache` and `subscribed_keys`.
6. Restart Upstox streamer so latest subscription keys are applied.
7. Send Telegram notifications for success or failure.

Example response:

```json
{
  "status": "success",
  "message": "Manual market hard refresh completed successfully.",
  "started_at": "2026-08-04T03:30:00+00:00",
  "completed_at": "2026-08-04T03:30:08+00:00",
  "nearest_expiry": "2026-08-04",
  "total_contracts": 82,
  "subscribed_instruments": 83,
  "feed_mode": "full"
}
```

#### `GET /refresh/status`

Returns latest manual refresh status and current cache summary.

Example response:

```json
{
  "manual_refresh_running": false,
  "last_manual_refresh": {
    "status": "success",
    "timestamp": "2026-08-04T03:30:08+00:00",
    "message": "Manual market hard refresh completed successfully.",
    "subscribed_instruments": 83,
    "nearest_expiry": "2026-08-04"
  },
  "current_cache": {
    "nearest_expiry": "2026-08-04",
    "total_contracts": 82,
    "subscribed_keys_count": 83
  }
}
```

---

## Historical EMA Routes

### `api/history_routes.py`

Contains historical candle, historical EMA, and live EMA status APIs.

#### Endpoints

```text
GET  /history/status
POST /history/fetch
GET  /history/instrument
GET  /history/cache
GET  /history/ema-results-file
GET  /history/config
GET  /history/live-ema/status
GET  /history/live-ema/events
GET  /history/live-ema/instrument
GET  /history/live-ema/instruments
GET  /history/live-ema/file
```

#### `GET /history/status`

Returns the latest historical candle and EMA processing status.

#### `POST /history/fetch`

Manually triggers historical candle fetch and EMA crossover calculation for all subscribed instruments.

Example:

```text
POST http://127.0.0.1:8000/history/fetch?interval=1minute&history_days=10&save_results=true&max_workers=5
```

Behavior:

- Fetches historical candles for all subscribed instruments.
- Uses historical API for previous days.
- Uses intraday API for today after market open.
- Calculates EMA fast and EMA slow.
- Detects bullish and bearish EMA crossovers.
- Stores EMA result summary in memory.
- Saves output only when `save_results=true` or `TEST_FLAG=True`.
- Initializes live EMA state from historical EMA values.

#### `GET /history/instrument`

Fetches and processes historical EMA for one instrument.

Examples:

```text
http://127.0.0.1:8000/history/instrument?instrument_key=NSE_INDEX%7CNifty%2050
http://127.0.0.1:8000/history/instrument?instrument_key=NSE_FO%7C41012
http://127.0.0.1:8000/history/instrument?strike=24500&striketype=pe
```

#### `GET /history/cache`

Returns current in-memory historical EMA cache.

#### `GET /history/config`

Returns historical candle, EMA, and live EMA configuration.

#### `GET /history/live-ema/status`

Returns live EMA service status.

#### `GET /history/live-ema/events`

Returns recent live EMA crossover events.

Example:

```text
http://127.0.0.1:8000/history/live-ema/events?limit=100
```

#### `GET /history/live-ema/instrument`

Returns live EMA state for one instrument.

Examples:

```text
http://127.0.0.1:8000/history/live-ema/instrument?instrument_key=NSE_INDEX%7CNifty%2050
http://127.0.0.1:8000/history/live-ema/instrument?strike=24500&striketype=ce
```

#### `GET /history/live-ema/instruments`

Returns lightweight live EMA summaries for all tracked instruments.

---

## WebSocket Routes

### `ws_feed/websocket_routes.py`

Contains FastAPI WebSocket endpoints.

#### Endpoints

```text
WS /ws
WS /all-feeds
WS /option?strike=24500&striketype=ce
WS /ws/ema-crossover
WS /ws/ema-crossover/instrument?instrument_key=NSE_FO%7C41012
WS /ws/ema-crossover/instrument?strike=24500&striketype=ce
```

---

### `/ws` and `/all-feeds`

Both routes connect a client to all subscribed instruments.

Current dashboard uses:

```text
WS /all-feeds
```

The dashboard receives NIFTY index ticks and option ticks through this stream.

---

### `/option`

Connects a client to a specific option based on strike and option type.

Example:

```text
ws://127.0.0.1:8000/option?strike=24500&striketype=ce
```

Behavior:

- Validates `striketype` as `CE` or `PE`.
- Registers client using `broadcaster.connect_option()`.
- Uses a key format like:

```text
24500.0_CE_0
```

Here, the final `0` represents live tick interval.

---

### `/ws/ema-crossover`

Dedicated global WebSocket endpoint for live EMA crossover events.

Example:

```text
ws://127.0.0.1:8000/ws/ema-crossover
```

Behavior:

- Connects client to the global EMA crossover pool.
- Receives EMA crossover events for all instruments.
- Useful for alert dashboards or global signal monitoring.

---

### `/ws/ema-crossover/instrument`

Dedicated instrument-specific WebSocket endpoint for live EMA crossover events.

Examples:

```text
ws://127.0.0.1:8000/ws/ema-crossover/instrument?instrument_key=NSE_INDEX%7CNifty%2050
ws://127.0.0.1:8000/ws/ema-crossover/instrument?instrument_key=NSE_FO%7C41012
ws://127.0.0.1:8000/ws/ema-crossover/instrument?strike=24500&striketype=ce
ws://127.0.0.1:8000/ws/ema-crossover/instrument?strike=24500&striketype=pe
```

Behavior:

- Accepts either direct `instrument_key` or `strike + striketype`.
- Resolves option instrument key from `options_cache` when strike and option type are provided.
- Registers client using `broadcaster.connect_ema_instrument()`.
- Receives only the selected instrument's EMA crossover events.

---

## Dashboard

### `templates/index.html`

FastAPI-rendered dashboard page served at:

```text
http://127.0.0.1:8000/
```

Current dashboard features:

- Header with live NIFTY 50 LTP.
- Header with NIFTY change, percent change, OHLC, and update time.
- Hard Refresh button.
- Manual refresh status panel.
- `/all-feeds` connection status badge.
- Dynamic nearest CE option cards.
- Dynamic nearest PE option cards.
- Nearest CE/PE selection based on live NIFTY LTP.
- No separate fixed target option WebSocket connection.

Dashboard feed behavior:

```text
Browser
    -> connects to /all-feeds
    -> receives NIFTY index ticks and option ticks
    -> updates NIFTY header
    -> stores CE/PE option ticks in memory
    -> sorts options by distance from live NIFTY LTP
    -> displays nearest CE and PE cards
```

The dashboard uses:

```javascript
const wsProtocol = window.location.protocol === "https:" ? "wss" : "ws";
const wsHost = `${wsProtocol}://${window.location.host}`;
const apiHost = `${window.location.protocol}//${window.location.host}`;
```

This allows it to work locally and in deployment without hardcoding port `8000`.

---

## Core Configuration

### `core/config.py`

Central configuration file.

Expected configuration:

```python
import os
from dotenv import load_dotenv

load_dotenv()

MONGO_URI = os.getenv("MONGO_URL")
MONGO_DB = os.getenv("MONGO_DB")
TOKENS_COLLECTION = os.getenv("TOKENS_COLLECTION")
REFRESH_INTERVAL_MINUTES = 60

MAIN_NIFTY_SECURITY = "NSE_INDEX|Nifty 50"
STRIKE_FROM = 23000.0
STRIKE_TO = 25000.0

WEBSOCKET_FEED_MODE = "full"

MARKET_TIMEZONE = os.getenv("MARKET_TIMEZONE", "Asia/Kolkata")
MARKET_TIME_FORMAT = "%Y-%m-%d %H:%M:%S %Z"
MARKET_OPEN_HOUR = 9
MARKET_OPEN_MINUTE = 15

HISTORICAL_CANDLE_ENABLED = True
HISTORICAL_CANDLE_DAYS = 10
HISTORICAL_CANDLE_INTERVAL = "1minute"
HISTORICAL_CANDLE_API_VERSION = "2.0"
HISTORICAL_CANDLE_MAX_DAYS_PER_REQUEST = 7
HISTORICAL_CANDLE_MAX_WORKERS = 8
HISTORICAL_CANDLE_REQUEST_SLEEP_SECONDS = 0.15

TEST_FLAG = False

EMA_FAST_PERIOD = 9
EMA_SLOW_PERIOD = 21
EMA_CROSS_OUTPUT_FILE = "data/ema_cross_results.json"

LIVE_EMA_ENABLED = True
LIVE_EMA_INTERVAL_MINUTES = 1
LIVE_EMA_FAST_PERIOD = 9
LIVE_EMA_SLOW_PERIOD = 21
LIVE_EMA_SAVE_TEST_FILE = True
LIVE_EMA_OUTPUT_FILE = "data/live_ema_cross_results.json"
LIVE_EMA_MAX_EVENTS_IN_MEMORY = 5000

TELEGRAM_ENABLED = os.getenv("TELEGRAM_ENABLED", "false").lower() == "true"
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")
TELEGRAM_TIMEOUT_SECONDS = int(os.getenv("TELEGRAM_TIMEOUT_SECONDS", "10"))
```

Key settings:

- `MAIN_NIFTY_SECURITY`: NIFTY index instrument key.
- `STRIKE_FROM`: Lower strike filter.
- `STRIKE_TO`: Upper strike filter.
- `WEBSOCKET_FEED_MODE`: Upstox feed mode. Current value is `full`.
- `REFRESH_INTERVAL_MINUTES`: Token refresh interval.
- `MARKET_TIMEZONE`: Market timezone, default `Asia/Kolkata`.
- `HISTORICAL_CANDLE_DAYS`: Number of calendar days used for historical EMA base.
- `HISTORICAL_CANDLE_INTERVAL`: Historical candle interval.
- `HISTORICAL_CANDLE_MAX_WORKERS`: Parallel instrument worker count.
- `HISTORICAL_CANDLE_REQUEST_SLEEP_SECONDS`: Sleep delay between batch calls per instrument.
- `EMA_FAST_PERIOD`: Historical EMA fast period.
- `EMA_SLOW_PERIOD`: Historical EMA slow period.
- `LIVE_EMA_ENABLED`: Enables live EMA continuation.
- `LIVE_EMA_INTERVAL_MINUTES`: Live EMA interval in minutes.
- `LIVE_EMA_MAX_EVENTS_IN_MEMORY`: Maximum live EMA events stored in memory.
- `TELEGRAM_ENABLED`: Enables or disables Telegram alerts.

---

## Services

### `services/token_service.py`

Handles access token retrieval from MongoDB.

Responsibilities:

- Connects to MongoDB.
- Reads token document with `_id = "upstox_access_token"`.
- Stores token data in thread-safe memory cache.
- Provides access token to other services.

Expected MongoDB token document:

```json
{
  "_id": "upstox_access_token",
  "access_token": "your_upstox_access_token",
  "updated_at": "timestamp"
}
```

---

### `services/option_service.py`

Fetches and manages NIFTY option contracts.

Responsibilities:

- Calls Upstox Options API.
- Gets option contracts for `NSE_INDEX|Nifty 50`.
- Finds nearest valid expiry date.
- Filters contracts by configured strike range.
- Standardizes option contract fields.
- Updates global `options_cache`.
- Saves contracts to `data/nearest_nifty_option_contracts.json`.

Runtime cache:

```python
options_cache = {
    "nearest_expiry": None,
    "total_contracts": 0,
    "subscribed_keys": [],
    "data": [],
}
```

Subscription keys include:

1. NIFTY index key.
2. Filtered option contract keys.

---

### `services/history_service.py`

Fetches historical and intraday candles and calculates EMA crossover summaries.

Responsibilities:

- Reads subscribed instruments from `options_cache`.
- Builds default historical date ranges.
- Excludes today before market open.
- Uses intraday API for today after market open.
- Splits large historical date ranges into batches.
- Fetches all batches sequentially per instrument.
- Supports parallel execution across instruments using `ThreadPoolExecutor`.
- Deduplicates and sorts candles.
- Calculates EMA fast and slow values.
- Detects bullish and bearish crossovers.
- Stores summarized results in memory.
- Saves EMA results only when enabled.
- Initializes live EMA state from historical EMA output.

Important behavior:

```text
Inside one instrument:
    batch 1 completes
    batch 2 starts
    batch 2 completes
    batch 3 starts
    intraday fetch starts after historical batches
    EMA calculation runs after all candles are collected
```

Across instruments, execution depends on:

```python
HISTORICAL_CANDLE_MAX_WORKERS
```

For fully sequential execution across all instruments, use:

```python
HISTORICAL_CANDLE_MAX_WORKERS = 1
```

---

### `services/live_ema_service.py`

Continues EMA calculation using live Upstox full-feed candles.

Responsibilities:

- Initializes EMA state from historical EMA summary.
- Tracks EMA state per instrument.
- Reads I1 candle data from Upstox full-feed `marketOHLC`.
- Waits for candle timestamp change to treat the previous candle as completed.
- Supports interval aggregation when `LIVE_EMA_INTERVAL_MINUTES` is greater than 1.
- Calculates next EMA fast and EMA slow values from previous EMA values.
- Detects live bullish and bearish EMA crossovers.
- Stores live crossover events in memory.
- Optionally saves live EMA events to `data/live_ema_cross_results.json` when `TEST_FLAG=True`.

---

### `services/upstox_websocket.py`

Maintains the connection to Upstox live market feed.

Responsibilities:

- Reads access token from `token_service`.
- Reads subscribed instrument keys from `options_cache`.
- Creates `upstox_client.MarketDataStreamerV3`.
- Connects to Upstox WebSocket in a background thread.
- Receives tick messages.
- Sends decoded feed ticks to `broadcaster.broadcast_tick()`.
- Sends full-feed candle data to `live_ema_service.process_live_feed()`.
- Broadcasts EMA crossover events through `broadcaster.broadcast_ema_cross()`.
- Reconnects on failure.
- Supports `restart()` so refreshed subscription keys are applied after daily or manual hard refresh.
- Logs market time using `MARKET_TIMEZONE` from config.

Important behavior:

- Normal live tick broadcasting is skipped when no local clients are connected.
- Live EMA processing can continue even when no UI clients are connected if `LIVE_EMA_ENABLED=True`.

---

### `services/telegram_service.py`

Sends Telegram notifications using bot token and chat ID from config.

Telegram events include:

- Application startup started
- Application startup success or warnings
- Token refresh success or failure
- Instrument fetch success or failure
- Historical EMA fetch success or failure
- Scheduler started
- Daily hard refresh started, success, or failure
- Manual hard refresh started, success, or failure
- Upstox subscription active or failure
- Application shutdown started or completed
- Exceptions and runtime failures

Configuration comes from `.env` through `core/config.py`.

Required `.env` values:

```env
TELEGRAM_ENABLED=true
TELEGRAM_BOT_TOKEN=your_bot_token_here
TELEGRAM_CHAT_ID=your_chat_id_here
TELEGRAM_TIMEOUT_SECONDS=10
```

---

## Broadcaster

### `ws_feed/broadcaster.py`

Core local WebSocket broadcasting engine.

Responsibilities:

- Tracks connected local WebSocket clients.
- Maintains separate connection pools for:
  - generic connections
  - all-feeds connections
  - option-specific connections
  - global EMA crossover connections
  - instrument-specific EMA crossover connections
- Parses raw Upstox feed data into normalized payloads.
- Broadcasts live ticks to matching clients.
- Broadcasts live EMA crossover events to global and instrument-specific clients.
- Removes dead WebSocket clients.
- Logs raw feeds to `logs/feeds.log`.

Connection pools:

```python
self.active_connections = set()
self.ema_crossover_connections = set()
self.ema_instrument_connections = {}
self.all_feeds_connections = {}
self.option_connections = {}
```

Option connection key format:

```text
{strike_price}_{instrument_type}_{interval}
```

Example:

```text
24500.0_CE_0
```

Instrument-specific EMA connection format:

```python
self.ema_instrument_connections = {
    "NSE_INDEX|Nifty 50": {websocket1},
    "NSE_FO|41012": {websocket2},
}
```

---

## WebSocket Payload Format

### Live Tick Payload

The broadcaster normalizes Upstox feed into this structure:

```json
{
  "type": "live_tick",
  "interval": 0,
  "instrument_key": "NSE_FO|65860",
  "ltp": 120.5,
  "close": 115.0,
  "change": 5.5,
  "change_pct": 4.78,
  "ltt": 0,
  "ltq": 75,
  "open": 110.0,
  "high": 130.0,
  "low": 100.0,
  "volume": 250000,
  "atp": 118.5,
  "oi": 500000,
  "upper_circuit": 0.0,
  "lower_circuit": 0.0,
  "greeks": {
    "iv": 12.5,
    "delta": 0.52,
    "theta": -8.2,
    "gamma": 0.001,
    "vega": 10.4,
    "rho": 1.25
  },
  "depth": [],
  "info": {
    "instrument_key": "NSE_FO|65860",
    "instrument_type": "CE",
    "strike_price": 24500.0,
    "expiry": "2026-08-04",
    "trading_symbol": "NIFTY 24500 CE 04 AUG 26",
    "underlying_symbol": "NIFTY"
  }
}
```

---

### Live EMA Crossover Payload

Live EMA crossover events use this structure:

```json
{
  "type": "live_ema_cross",
  "instrument_key": "NSE_FO|41012",
  "timestamp": "2026-08-05T09:16:00+05:30",
  "cross_type": "bullish_cross",
  "interval_minutes": 1,
  "close": 24774.3,
  "ema_fast_period": 9,
  "ema_slow_period": 21,
  "ema_fast": 24613.6098,
  "ema_slow": 24593.3994,
  "previous_ema_fast": 24590.1021,
  "previous_ema_slow": 24595.7801,
  "source": "live_feed",
  "created_at": "2026-08-05T09:16:05+05:30",
  "info": {
    "instrument_key": "NSE_FO|41012",
    "instrument_type": "CE",
    "strike_price": 24500.0,
    "expiry": "2026-08-04",
    "trading_symbol": "NIFTY 24500 CE 04 AUG 26",
    "underlying_symbol": "NIFTY"
  }
}
```

Possible `cross_type` values:

```text
bullish_cross
bearish_cross
```

---

## Scheduled Refresh

The application performs a daily hard refresh:

```text
Monday to Friday at 09:00 AM Asia/Kolkata
```

Scheduled hard refresh does:

```text
1. Refresh token document from MongoDB
2. Load latest token into memory
3. Fetch latest NIFTY option instruments
4. Filter instruments by configured strike range
5. Update options_cache and subscribed_keys
6. Fetch historical candles and calculate EMA crossover summary
7. Initialize live EMA state from historical EMA summary
8. Restart Upstox streamer
9. Subscribe with the latest instrument keys
10. Send Telegram notifications
```

Scheduler configuration is in `main.py`:

```python
CronTrigger(
    day_of_week="mon-fri",
    hour=9,
    minute=0,
    timezone=getattr(config, "MARKET_TIMEZONE", "Asia/Kolkata"),
)
```

---

## Manual Refresh

Manual refresh is available from both API and dashboard.

### API

```text
POST /refresh/manual
GET  /refresh/status
```

### Dashboard

The dashboard includes a `Hard Refresh` button in the header. It calls:

```text
POST /refresh/manual
```

The UI shows:

- Refresh running
- Refresh success
- Refresh failed
- Last refresh details

---

## Setup Instructions

### 1. Create Virtual Environment

```bat
python -m venv myenv
myenv\Scripts\activate
```

### 2. Install Dependencies

```bat
pip install -r requirements.txt
```

### 3. Configure `.env`

Example `.env`:

```env
MONGO_URL=mongodb://localhost:27017
MONGO_DB=your_database_name
TOKENS_COLLECTION=your_tokens_collection_name

MARKET_TIMEZONE=Asia/Kolkata

TELEGRAM_ENABLED=true
TELEGRAM_BOT_TOKEN=your_bot_token_here
TELEGRAM_CHAT_ID=your_chat_id_here
TELEGRAM_TIMEOUT_SECONDS=10
```

Your MongoDB collection should contain a token document with `_id` as `upstox_access_token`.

---

## Requirements

```text
fastapi
uvicorn
upstox-python-sdk
pymongo
python-dotenv
pydantic
pydantic-settings
websockets
websocket-client
requests
pandas
numpy
apscheduler
jinja2
```

---

## Run the Application

Using batch file:

```bat
run.bat
```

Or directly:

```bat
python main.py
```

Server starts at:

```text
http://127.0.0.1:8000
```

Dashboard:

```text
http://127.0.0.1:8000/
```

Health endpoint:

```text
http://127.0.0.1:8000/health
```

---

## Testing the Application

### Health Check

```text
http://127.0.0.1:8000/health
```

### Cache Debug

```text
http://127.0.0.1:8000/debug/cache
```

### Find Option Contract

```text
http://127.0.0.1:8000/debug/find-option?strike=24500&striketype=ce
```

### Test All Feeds Broadcast

First connect a WebSocket client to:

```text
ws://127.0.0.1:8000/all-feeds
```

Then call:

```text
http://127.0.0.1:8000/test-broadcast
```

### Test Option Broadcast

First connect a WebSocket client to:

```text
ws://127.0.0.1:8000/option?strike=24500&striketype=ce
```

Then call:

```text
http://127.0.0.1:8000/test-broadcast-option
```

### Test Global EMA Crossover WebSocket

Connect to:

```text
ws://127.0.0.1:8000/ws/ema-crossover
```

This receives live EMA crossover events for all instruments.

### Test Instrument-Specific EMA Crossover WebSocket

Connect by direct instrument key:

```text
ws://127.0.0.1:8000/ws/ema-crossover/instrument?instrument_key=NSE_INDEX%7CNifty%2050
```

Connect by option strike and type:

```text
ws://127.0.0.1:8000/ws/ema-crossover/instrument?strike=24500&striketype=ce
```

### Manual Historical EMA Fetch

```text
POST http://127.0.0.1:8000/history/fetch?interval=1minute&history_days=10&save_results=true&max_workers=5
```

### Live EMA Status

```text
GET http://127.0.0.1:8000/history/live-ema/status
```

### Latest Live EMA Events

```text
GET http://127.0.0.1:8000/history/live-ema/events?limit=100
```

### Manual Refresh

```text
POST http://127.0.0.1:8000/refresh/manual
GET  http://127.0.0.1:8000/refresh/status
```

---

## Logs

Logs are written to the `logs/` folder.

Examples:

```text
logs/main.log
logs/option_service.log
logs/upstox_websocket.log
logs/broadcaster.log
logs/telegram_service.log
logs/history_service.log
logs/live_ema_service.log
logs/feeds.log
```

`logs/feeds.log` stores raw feed JSON lines and is capped to the latest 2,000 lines.

---

## Deployment Note

If `main.py` is located directly in the project root, the recommended `Procfile` is:

```text
web: uvicorn main:app --host 0.0.0.0 --port 8000
```

Avoid this if you do not have an `app/` package:

```text
web : uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

Also remove the extra space before the colon.

For production deployments, avoid using `--reload`.

---

## Important Notes

- This project depends on a valid Upstox access token.
- Token is expected to be stored in MongoDB.
- If token is missing, option contract loading will fail.
- If options cache is empty, Upstox subscription keys will not be available.
- Updating `options_cache` alone is not enough to apply new subscriptions.
- The Upstox streamer must be restarted after refresh so it subscribes with the latest keys.
- Historical candle batches are sequential inside each instrument.
- Multiple instruments can still run in parallel depending on `HISTORICAL_CANDLE_MAX_WORKERS`.
- Use `HISTORICAL_CANDLE_MAX_WORKERS = 1` for strict one-by-one processing across all instruments.
- Live EMA continuation depends on successful historical EMA initialization.
- Global EMA WebSocket receives all crossover events.
- Instrument-specific EMA WebSocket receives only the selected instrument's crossover events.
- If no local WebSocket clients are connected, normal tick broadcasting is skipped to reduce event-loop load.
- If `LIVE_EMA_ENABLED=True`, live EMA processing can continue even when no dashboard client is connected.
- The dashboard is served by FastAPI from `templates/index.html`.
- The dashboard currently uses `/all-feeds` and calculates nearest CE/PE from received ticks.
- Telegram notifications are optional and controlled by `TELEGRAM_ENABLED`.

---

## Quick Start Summary

```bat
python -m venv myenv
myenv\Scripts\activate
pip install -r requirements.txt
python main.py
```

Then open:

```text
http://127.0.0.1:8000/
```

---

## Owner Notes

This README reflects the current version of the project where:

- HTTP routes are moved into `api/`.
- WebSocket routes are moved into `ws_feed/websocket_routes.py`.
- Dashboard is served from `templates/index.html`.
- Manual refresh is available through `/refresh/manual`.
- Daily refresh runs Mon-Fri at 09:00 AM IST.
- Telegram notifications are integrated through `services/telegram_service.py`.
- Historical EMA 9/21 crossover calculation is integrated through `services/history_service.py`.
- Live EMA continuation is integrated through `services/live_ema_service.py`.
- Global EMA crossover streaming is available through `/ws/ema-crossover`.
- Instrument-specific EMA crossover streaming is available through `/ws/ema-crossover/instrument`.
- Dashboard displays live NIFTY 50 and nearest CE/PE option cards from `/all-feeds`.
