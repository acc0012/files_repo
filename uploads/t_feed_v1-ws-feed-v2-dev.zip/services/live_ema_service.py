import asyncio
import json
from collections import deque
from datetime import datetime
from pathlib import Path
from threading import Lock
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from core import config
from core.logger import get_logger

logger = get_logger(__file__)


class LiveEMAService:
    """
    Live EMA crossover continuation service.

    Purpose:
    1. Initialize EMA state from historical EMA summary.
    2. Read live full-mode Upstox feed candles.
    3. Continue EMA 9/21 from historical latest EMA values.
    4. Detect live bullish/bearish EMA crossovers for all initialized instruments.
    5. Support professional provisional + confirmed EMA signal flow.
    6. Store confirmed crossover events in memory.
    7. Optionally store provisional events if enabled.
    8. Optionally save compact crossover events to data/live_ema_cross_results.json.

    Signal model:
    - Provisional signal:
        Calculated from the current forming I1 candle.
        Broadcast quickly.
        Does not update committed EMA state.
        May repaint or disappear before candle close.

    - Confirmed signal:
        Calculated when candle timestamp changes and previous candle is complete.
        Updates committed EMA state.
        Treated as official confirmed EMA crossover.

    Important:
    - Raw live ticks are not stored.
    - Raw historical candles are not needed here.
    - This service works from EMA state only.
    - This service does not select an Opening Range instrument.
    - This service does not send Telegram alerts.
    - Opening Range enrichment is handled outside this service in
      services/upstox_websocket.py before WebSocket broadcast.
    - Live EMA crossover payload is intentionally compact to reduce WebSocket load.
    """

    def __init__(self):
        self.enabled = bool(getattr(config, "LIVE_EMA_ENABLED", True))

        self.interval_minutes = int(getattr(config, "LIVE_EMA_INTERVAL_MINUTES", 1))

        self.fast_period = int(
            getattr(
                config,
                "LIVE_EMA_FAST_PERIOD",
                getattr(config, "EMA_FAST_PERIOD", 9),
            )
        )

        self.slow_period = int(
            getattr(
                config,
                "LIVE_EMA_SLOW_PERIOD",
                getattr(config, "EMA_SLOW_PERIOD", 21),
            )
        )

        self.provisional_enabled = bool(
            getattr(config, "LIVE_EMA_PROVISIONAL_ENABLED", True)
        )

        self.confirmed_enabled = bool(
            getattr(config, "LIVE_EMA_CONFIRMED_ENABLED", True)
        )

        self.provisional_broadcast_only_on_change = bool(
            getattr(config, "LIVE_EMA_PROVISIONAL_BROADCAST_ONLY_ON_CHANGE", True)
        )

        self.provisional_store_events = bool(
            getattr(config, "LIVE_EMA_PROVISIONAL_STORE_EVENTS", False)
        )

        self.provisional_save_test_file = bool(
            getattr(config, "LIVE_EMA_PROVISIONAL_SAVE_TEST_FILE", False)
        )

        self.output_file = getattr(
            config,
            "LIVE_EMA_OUTPUT_FILE",
            "data/live_ema_cross_results.json",
        )

        self.save_test_file = bool(getattr(config, "LIVE_EMA_SAVE_TEST_FILE", True))

        self.max_events_in_memory = int(
            getattr(config, "LIVE_EMA_MAX_EVENTS_IN_MEMORY", 5000)
        )

        self.market_timezone = self._load_market_timezone()

        self._lock = Lock()

        # Optional async callback for broadcasting live crossovers.
        self.crossover_callback = None

        # Per instrument EMA state.
        self.state = {}

        # Recent compact live EMA crossover events.
        # By default this stores confirmed events.
        # Provisional events are stored only if LIVE_EMA_PROVISIONAL_STORE_EVENTS=True.
        self.cross_events = deque(maxlen=self.max_events_in_memory)

        logger.info(
            f"LiveEMAService initialized. "
            f"enabled={self.enabled}, "
            f"interval_minutes={self.interval_minutes}, "
            f"fast_period={self.fast_period}, "
            f"slow_period={self.slow_period}, "
            f"provisional_enabled={self.provisional_enabled}, "
            f"confirmed_enabled={self.confirmed_enabled}, "
            f"provisional_store_events={self.provisional_store_events}"
        )

    # ========================================================
    # Callback Registration
    # ========================================================

    def register_crossover_callback(self, callback):
        """
        Registers an async callback function to handle crossover events in real time.

        Expected signature:
            async def callback(event: dict)
        """

        self.crossover_callback = callback
        logger.info("Registered crossover callback in LiveEMAService.")

    # ========================================================
    # Time Helpers
    # ========================================================

    def _load_market_timezone(self):
        """Loads market timezone from config, defaulting to Asia/Kolkata."""

        timezone_name = getattr(config, "MARKET_TIMEZONE", "Asia/Kolkata")

        try:
            return ZoneInfo(timezone_name)

        except ZoneInfoNotFoundError:
            logger.error(
                f"Invalid MARKET_TIMEZONE configured: {timezone_name}. "
                "Falling back to Asia/Kolkata."
            )
            return ZoneInfo("Asia/Kolkata")

    def _now_market_time(self) -> str:
        """Returns current market time as ISO string."""

        return datetime.now(self.market_timezone).isoformat()

    def _epoch_ms_to_iso(self, ts_value) -> str | None:
        """
        Converts epoch milliseconds to ISO datetime string in market timezone.

        Upstox full feed OHLC uses:
            ts: "1725875940000"
        """

        try:
            ts_ms = int(ts_value)
            dt_obj = datetime.fromtimestamp(ts_ms / 1000, tz=self.market_timezone)
            return dt_obj.isoformat()

        except Exception:
            return None

    def _epoch_ms_to_datetime(self, ts_value) -> datetime | None:
        """Converts epoch milliseconds to datetime object in market timezone."""

        try:
            ts_ms = int(ts_value)
            return datetime.fromtimestamp(ts_ms / 1000, tz=self.market_timezone)

        except Exception:
            return None

    # ========================================================
    # Safe Helpers
    # ========================================================

    def _safe_float(self, value, default: float = 0.0) -> float:
        """Safely converts value to float."""

        try:
            if value is None:
                return default
            return float(value)

        except Exception:
            return default

    def _safe_int(self, value, default: int = 0) -> int:
        """Safely converts value to int."""

        try:
            if value is None:
                return default
            return int(value)

        except Exception:
            return default

    # ========================================================
    # Historical Initialization
    # ========================================================

    def initialize_from_history_summary(self, summary: dict) -> dict:
        """
        Initializes live EMA state from historical EMA summary.

        Expected summary shape:

        {
            "results": {
                "NSE_INDEX|Nifty 50": {
                    "status": "success",
                    "ema_result": {
                        "latest_timestamp": "...",
                        "latest_close": 24774.3,
                        "latest_ema_fast": 24613.6098,
                        "latest_ema_slow": 24593.3994,
                        "latest_signal": "bullish",
                        "last_crossover": {...}
                    },
                    "contract_info": {...}
                }
            }
        }
        """

        initialized_count = 0
        skipped_count = 0

        if not self.enabled:
            logger.info(
                "Live EMA initialization skipped because LIVE_EMA_ENABLED=False."
            )
            return {
                "initialized": False,
                "initialized_count": 0,
                "skipped_count": 0,
                "reason": "disabled",
            }

        results = (summary or {}).get("results", {})

        if not results:
            logger.warning(
                "Live EMA initialization skipped. No historical results found."
            )
            return {
                "initialized": False,
                "initialized_count": 0,
                "skipped_count": 0,
                "reason": "no_historical_results",
            }

        with self._lock:
            self.state = {}

            for instrument_key, item in results.items():
                ema_result = item.get("ema_result") or {}

                latest_ema_fast = ema_result.get("latest_ema_fast")
                latest_ema_slow = ema_result.get("latest_ema_slow")

                if latest_ema_fast is None or latest_ema_slow is None:
                    skipped_count += 1
                    continue

                self.state[instrument_key] = {
                    "instrument_key": instrument_key,
                    "initialized": True,
                    "source": "historical_ema",
                    "interval_minutes": self.interval_minutes,
                    "fast_period": self.fast_period,
                    "slow_period": self.slow_period,
                    "previous_ema_fast": self._safe_float(latest_ema_fast),
                    "previous_ema_slow": self._safe_float(latest_ema_slow),
                    "previous_signal": ema_result.get("latest_signal"),
                    "latest_close": ema_result.get("latest_close"),
                    "last_historical_timestamp": ema_result.get("latest_timestamp"),
                    "last_processed_candle_ts": ema_result.get("latest_timestamp"),
                    "last_crossover": ema_result.get("last_crossover"),
                    "last_confirmed_crossover": ema_result.get("last_crossover"),
                    "last_provisional_crossover": None,
                    "last_provisional_cross_key": None,
                    "last_provisional_signal": None,
                    "pending_live_candle": None,
                    "pending_live_candle_ts": None,
                    "aggregation_bucket": None,
                    "aggregation_bucket_start_ts": None,
                    "aggregation_bucket_start_ms": None,
                    "crossovers": [],
                    "provisional_crossovers": [],
                    "contract_info": item.get("contract_info", {}),
                    "updated_at": self._now_market_time(),
                }

                initialized_count += 1

        logger.info(
            f"Live EMA state initialized from historical summary. "
            f"initialized_count={initialized_count}, skipped_count={skipped_count}"
        )

        return {
            "initialized": initialized_count > 0,
            "initialized_count": initialized_count,
            "skipped_count": skipped_count,
        }

    # ========================================================
    # Feed Extraction Helpers
    # ========================================================

    def _get_feed_container(self, tick_data: dict) -> dict:
        """
        Extracts the feed container from Upstox full feed.

        Supports:
            tick_data["ff"]["marketFF"]
            tick_data["ff"]["indexFF"]
            tick_data["fullFeed"]["ff"]["marketFF"]
            tick_data["fullFeed"]["ff"]["indexFF"]
        """

        if not isinstance(tick_data, dict):
            return {}

        raw_feed_obj = tick_data.get("raw_feed", tick_data)
        full_feed = raw_feed_obj.get("fullFeed", raw_feed_obj)
        ff_wrapper = full_feed.get("ff", full_feed)

        ff = (
            ff_wrapper.get("marketFF")
            or ff_wrapper.get("indexFF")
            or full_feed.get("marketFF")
            or full_feed.get("indexFF")
            or full_feed
        )

        return ff if isinstance(ff, dict) else {}

    def _get_ohlc_list(self, tick_data: dict) -> list:
        """
        Extracts OHLC list from Upstox full feed.

        Supports:
            marketOHLC.ohlc
            optionOHLC.ohlc
        """

        ff = self._get_feed_container(tick_data)

        if "marketOHLC" in ff:
            ohlc_list = ff.get("marketOHLC", {}).get("ohlc", [])
        elif "optionOHLC" in ff:
            ohlc_list = ff.get("optionOHLC", {}).get("ohlc", [])
        else:
            ohlc_list = []

        return ohlc_list if isinstance(ohlc_list, list) else []

    def _find_latest_feed_candle(
        self,
        tick_data: dict,
        interval_tag: str,
    ) -> dict | None:
        """
        Returns the latest candle from OHLC list for requested interval tag.

        Example tags:
            I1
            I30
            1d
        """

        ohlc_list = self._get_ohlc_list(tick_data)

        matching = [
            item
            for item in ohlc_list
            if str(item.get("interval")).upper() == interval_tag.upper()
            and item.get("ts") is not None
        ]

        if not matching:
            return None

        try:
            return max(matching, key=lambda item: int(item.get("ts")))
        except Exception:
            return matching[-1]

    def _normalize_feed_candle(self, candle: dict) -> dict | None:
        """
        Converts Upstox OHLC candle dictionary to internal normalized candle.

        Output:
            {
                "timestamp": "2026-08-05T09:15:00+05:30",
                "timestamp_ms": 1725875940000,
                "open": 100,
                "high": 110,
                "low": 95,
                "close": 105,
                "volume": 2000
            }
        """

        if not isinstance(candle, dict):
            return None

        ts_raw = candle.get("ts")
        timestamp = self._epoch_ms_to_iso(ts_raw)

        if not timestamp:
            return None

        return {
            "timestamp": timestamp,
            "timestamp_ms": self._safe_int(ts_raw),
            "open": self._safe_float(candle.get("open")),
            "high": self._safe_float(candle.get("high")),
            "low": self._safe_float(candle.get("low")),
            "close": self._safe_float(candle.get("close")),
            "volume": self._safe_int(candle.get("volume") or candle.get("vol")),
        }

    # ========================================================
    # EMA Calculation Helpers
    # ========================================================

    def _calculate_next_ema(
        self,
        close_price: float,
        previous_ema: float,
        period: int,
    ) -> float:
        """Calculates next EMA value from previous EMA and current close."""

        multiplier = 2 / (period + 1)
        next_ema = close_price * multiplier + previous_ema * (1 - multiplier)

        return round(next_ema, 4)

    def _detect_cross(
        self,
        previous_fast: float,
        previous_slow: float,
        current_fast: float,
        current_slow: float,
    ) -> str | None:
        """Detects EMA crossover type."""

        if previous_fast <= previous_slow and current_fast > current_slow:
            return "bullish_cross"

        if previous_fast >= previous_slow and current_fast < current_slow:
            return "bearish_cross"

        return None

    def _get_signal(self, ema_fast: float, ema_slow: float) -> str:
        """Returns current EMA signal."""

        if ema_fast > ema_slow:
            return "bullish"

        if ema_fast < ema_slow:
            return "bearish"

        return "neutral"

    # ========================================================
    # Candle Completion Logic
    # ========================================================

    def _accept_live_candle_and_get_completed(
        self,
        state: dict,
        latest_candle: dict,
    ) -> dict | None:
        """
        Uses candle timestamp change as candle completion rule.

        Flow:
        - First I1 candle received:
            store as pending.
            no confirmed processing yet.

        - Same timestamp received:
            update pending.
            no confirmed processing yet.

        - New timestamp received:
            previous pending candle is completed.
            return previous pending candle for confirmed EMA calculation.
        """

        latest_ts = latest_candle.get("timestamp")

        if not latest_ts:
            return None

        pending_ts = state.get("pending_live_candle_ts")
        pending_candle = state.get("pending_live_candle")

        if pending_ts is None:
            state["pending_live_candle"] = latest_candle
            state["pending_live_candle_ts"] = latest_ts
            return None

        if latest_ts == pending_ts:
            state["pending_live_candle"] = latest_candle
            return None

        completed_candle = pending_candle

        state["pending_live_candle"] = latest_candle
        state["pending_live_candle_ts"] = latest_ts

        return completed_candle

    # ========================================================
    # Aggregation for Custom Intervals
    # ========================================================

    def _get_bucket_start_ms(self, timestamp_ms: int, interval_minutes: int) -> int:
        """
        Floors timestamp to interval bucket start.

        Example:
            09:17 with 5-minute interval becomes 09:15 bucket.
        """

        interval_ms = interval_minutes * 60 * 1000
        return (timestamp_ms // interval_ms) * interval_ms

    def _process_aggregation_bucket(
        self,
        state: dict,
        one_minute_candle: dict,
    ) -> dict | None:
        """
        Aggregates completed I1 candles into configured interval candle.

        Returns completed aggregated candle when bucket changes.

        Example for 5 minute:
            09:15, 09:16, 09:17, 09:18, 09:19 are accumulated.
            When 09:20 candle arrives, 09:15 bucket is completed.
        """

        interval_minutes = int(self.interval_minutes)

        if interval_minutes <= 1:
            return one_minute_candle

        timestamp_ms = one_minute_candle.get("timestamp_ms")

        if not timestamp_ms:
            return None

        bucket_start_ms = self._get_bucket_start_ms(timestamp_ms, interval_minutes)
        bucket_start_iso = self._epoch_ms_to_iso(bucket_start_ms)

        current_bucket = state.get("aggregation_bucket")
        current_bucket_start_ms = state.get("aggregation_bucket_start_ms")

        if current_bucket is None:
            state["aggregation_bucket_start_ts"] = bucket_start_iso
            state["aggregation_bucket_start_ms"] = bucket_start_ms
            state["aggregation_bucket"] = {
                "timestamp": bucket_start_iso,
                "timestamp_ms": bucket_start_ms,
                "open": one_minute_candle.get("open"),
                "high": one_minute_candle.get("high"),
                "low": one_minute_candle.get("low"),
                "close": one_minute_candle.get("close"),
                "volume": one_minute_candle.get("volume", 0),
            }

            return None

        if bucket_start_ms == current_bucket_start_ms:
            current_bucket["high"] = max(
                self._safe_float(current_bucket.get("high")),
                self._safe_float(one_minute_candle.get("high")),
            )
            current_bucket["low"] = min(
                self._safe_float(current_bucket.get("low")),
                self._safe_float(one_minute_candle.get("low")),
            )
            current_bucket["close"] = one_minute_candle.get("close")
            current_bucket["volume"] = self._safe_int(
                current_bucket.get("volume")
            ) + self._safe_int(one_minute_candle.get("volume"))

            state["aggregation_bucket"] = current_bucket

            return None

        completed_bucket = current_bucket

        state["aggregation_bucket_start_ts"] = bucket_start_iso
        state["aggregation_bucket_start_ms"] = bucket_start_ms
        state["aggregation_bucket"] = {
            "timestamp": bucket_start_iso,
            "timestamp_ms": bucket_start_ms,
            "open": one_minute_candle.get("open"),
            "high": one_minute_candle.get("high"),
            "low": one_minute_candle.get("low"),
            "close": one_minute_candle.get("close"),
            "volume": one_minute_candle.get("volume", 0),
        }

        return completed_bucket

    def _build_provisional_target_candle(
        self,
        state: dict,
        latest_i1_candle: dict,
    ) -> dict | None:
        """
        Builds a provisional candle for configured EMA interval.

        For LIVE_EMA_INTERVAL_MINUTES = 1:
            The latest forming I1 candle is used directly.

        For higher intervals:
            A preview candle is built by combining the current aggregation bucket
            with the latest forming I1 candle.

        Provisional candle never mutates committed EMA state.
        """

        interval_minutes = int(self.interval_minutes)

        if interval_minutes <= 1:
            return latest_i1_candle

        timestamp_ms = latest_i1_candle.get("timestamp_ms")

        if not timestamp_ms:
            return None

        bucket_start_ms = self._get_bucket_start_ms(timestamp_ms, interval_minutes)
        bucket_start_iso = self._epoch_ms_to_iso(bucket_start_ms)

        current_bucket = state.get("aggregation_bucket")
        current_bucket_start_ms = state.get("aggregation_bucket_start_ms")

        if (
            current_bucket
            and current_bucket_start_ms == bucket_start_ms
            and isinstance(current_bucket, dict)
        ):
            preview = dict(current_bucket)

            preview["high"] = max(
                self._safe_float(preview.get("high")),
                self._safe_float(latest_i1_candle.get("high")),
            )
            preview["low"] = min(
                self._safe_float(preview.get("low")),
                self._safe_float(latest_i1_candle.get("low")),
            )
            preview["close"] = latest_i1_candle.get("close")
            preview["volume"] = self._safe_int(preview.get("volume")) + self._safe_int(
                latest_i1_candle.get("volume")
            )

            return preview

        return {
            "timestamp": bucket_start_iso,
            "timestamp_ms": bucket_start_ms,
            "open": latest_i1_candle.get("open"),
            "high": latest_i1_candle.get("high"),
            "low": latest_i1_candle.get("low"),
            "close": latest_i1_candle.get("close"),
            "volume": latest_i1_candle.get("volume", 0),
        }

    # ========================================================
    # Main Live Processing
    # ========================================================

    def process_live_feed(
        self,
        instrument_key: str,
        tick_data: dict,
        contract_info: dict | None = None,
    ) -> list:
        """
        Processes one live Upstox full-mode feed tick.

        Returns:
            list of compact crossover events.

        Possible output:
            []
            [provisional_event]
            [confirmed_event]
            [confirmed_event, provisional_event]

        Important:
            This function now returns a list because one incoming tick can produce
            both a confirmed event for the previous candle and a provisional event
            for the new/current candle.
        """

        events = []

        if not self.enabled:
            return events

        if not instrument_key or not isinstance(tick_data, dict):
            return events

        with self._lock:
            state = self.state.get(instrument_key)

            if not state:
                return events

            previous_ema_fast = state.get("previous_ema_fast")
            previous_ema_slow = state.get("previous_ema_slow")

            if previous_ema_fast is None or previous_ema_slow is None:
                return events

            latest_i1_raw = self._find_latest_feed_candle(tick_data, "I1")

            if not latest_i1_raw:
                return events

            latest_i1_candle = self._normalize_feed_candle(latest_i1_raw)

            if not latest_i1_candle:
                return events

            completed_i1_candle = self._accept_live_candle_and_get_completed(
                state,
                latest_i1_candle,
            )

            # ------------------------------------------------------------
            # 1. Confirmed processing for completed candle.
            # ------------------------------------------------------------
            if completed_i1_candle and self.confirmed_enabled:
                completed_target_candle = self._process_aggregation_bucket(
                    state,
                    completed_i1_candle,
                )

                if completed_target_candle:
                    confirmed_event = self._process_completed_candle_locked(
                        instrument_key=instrument_key,
                        state=state,
                        completed_candle=completed_target_candle,
                        contract_info=contract_info,
                    )

                    if confirmed_event:
                        events.append(confirmed_event)

            # ------------------------------------------------------------
            # 2. Provisional processing for current forming candle.
            # ------------------------------------------------------------
            if self.provisional_enabled:
                provisional_target_candle = self._build_provisional_target_candle(
                    state=state,
                    latest_i1_candle=latest_i1_candle,
                )

                if provisional_target_candle:
                    provisional_event = self._process_provisional_candle_locked(
                        instrument_key=instrument_key,
                        state=state,
                        provisional_candle=provisional_target_candle,
                        contract_info=contract_info,
                    )

                    if provisional_event:
                        events.append(provisional_event)

        return events

    # ========================================================
    # Provisional EMA Processing
    # ========================================================

    def _process_provisional_candle_locked(
        self,
        instrument_key: str,
        state: dict,
        provisional_candle: dict,
        contract_info: dict | None = None,
    ) -> dict | None:
        """
        Calculates provisional EMA crossover from current forming candle.

        Very important:
            This method does not update:
            - previous_ema_fast
            - previous_ema_slow
            - previous_signal
            - last_processed_candle_ts

        Therefore, it does not corrupt confirmed EMA state.
        """

        candle_ts = provisional_candle.get("timestamp")
        close_price = self._safe_float(provisional_candle.get("close"))

        if not candle_ts or close_price <= 0:
            return None

        previous_fast = self._safe_float(state.get("previous_ema_fast"))
        previous_slow = self._safe_float(state.get("previous_ema_slow"))

        current_fast = self._calculate_next_ema(
            close_price=close_price,
            previous_ema=previous_fast,
            period=self.fast_period,
        )

        current_slow = self._calculate_next_ema(
            close_price=close_price,
            previous_ema=previous_slow,
            period=self.slow_period,
        )

        cross_type = self._detect_cross(
            previous_fast=previous_fast,
            previous_slow=previous_slow,
            current_fast=current_fast,
            current_slow=current_slow,
        )

        current_signal = self._get_signal(current_fast, current_slow)

        if not cross_type:
            state["last_provisional_signal"] = current_signal
            return None

        provisional_cross_key = (
            f"{instrument_key}|{candle_ts}|{cross_type}|{current_signal}"
        )

        if (
            self.provisional_broadcast_only_on_change
            and state.get("last_provisional_cross_key") == provisional_cross_key
        ):
            return None

        state["last_provisional_cross_key"] = provisional_cross_key
        state["last_provisional_signal"] = current_signal

        event = {
            "type": "live_ema_cross",
            "signal_status": "provisional",
            "instrument_key": instrument_key,
            "timestamp": candle_ts,
            "cross_type": cross_type,
            "interval_minutes": self.interval_minutes,
            "close": close_price,
            "ema_fast_period": self.fast_period,
            "ema_slow_period": self.slow_period,
            "ema_fast": current_fast,
            "ema_slow": current_slow,
            "previous_ema_fast": previous_fast,
            "previous_ema_slow": previous_slow,
            "previous_signal": state.get("previous_signal"),
            "current_signal": current_signal,
            "source": "live_feed_in_progress_candle",
            "is_confirmed": False,
            "is_provisional": True,
            "may_repaint": True,
            "created_at": self._now_market_time(),
            "candle": provisional_candle,
        }

        if contract_info:
            event["contract_info"] = contract_info

        state["last_provisional_crossover"] = event
        state.setdefault("provisional_crossovers", []).append(event)

        if len(state.get("provisional_crossovers", [])) > 50:
            state["provisional_crossovers"] = state["provisional_crossovers"][-50:]

        if self.provisional_store_events:
            self.cross_events.append(event)
            self._save_live_events_if_enabled_locked()

        logger.info(
            f"Provisional live EMA crossover detected. "
            f"instrument_key={instrument_key}, "
            f"cross_type={cross_type}, "
            f"timestamp={candle_ts}, "
            f"close={close_price}, "
            f"current_signal={current_signal}"
        )

        self._dispatch_crossover_callback_locked(event)

        return event

    # ========================================================
    # Confirmed EMA Processing
    # ========================================================

    def _process_completed_candle_locked(
        self,
        instrument_key: str,
        state: dict,
        completed_candle: dict,
        contract_info: dict | None = None,
    ) -> dict | None:
        """
        Processes completed candle and checks EMA crossover.

        Lock must already be held by caller.

        This method commits EMA state and creates confirmed EMA crossover events.
        """

        candle_ts = completed_candle.get("timestamp")
        close_price = self._safe_float(completed_candle.get("close"))

        if not candle_ts or close_price <= 0:
            return None

        last_processed_ts = state.get("last_processed_candle_ts")

        if last_processed_ts == candle_ts:
            return None

        previous_fast = self._safe_float(state.get("previous_ema_fast"))
        previous_slow = self._safe_float(state.get("previous_ema_slow"))
        previous_signal = state.get("previous_signal")

        current_fast = self._calculate_next_ema(
            close_price=close_price,
            previous_ema=previous_fast,
            period=self.fast_period,
        )

        current_slow = self._calculate_next_ema(
            close_price=close_price,
            previous_ema=previous_slow,
            period=self.slow_period,
        )

        cross_type = self._detect_cross(
            previous_fast=previous_fast,
            previous_slow=previous_slow,
            current_fast=current_fast,
            current_slow=current_slow,
        )

        current_signal = self._get_signal(current_fast, current_slow)

        # Commit confirmed EMA state.
        state["previous_ema_fast"] = current_fast
        state["previous_ema_slow"] = current_slow
        state["previous_signal"] = current_signal
        state["latest_close"] = close_price
        state["last_processed_candle_ts"] = candle_ts
        state["updated_at"] = self._now_market_time()

        # Reset provisional key after candle confirmation so the next candle can emit.
        state["last_provisional_cross_key"] = None
        state["last_provisional_signal"] = None

        if not cross_type:
            return None

        event = {
            "type": "live_ema_cross",
            "signal_status": "confirmed",
            "instrument_key": instrument_key,
            "timestamp": candle_ts,
            "cross_type": cross_type,
            "interval_minutes": self.interval_minutes,
            "close": close_price,
            "ema_fast_period": self.fast_period,
            "ema_slow_period": self.slow_period,
            "ema_fast": current_fast,
            "ema_slow": current_slow,
            "previous_ema_fast": previous_fast,
            "previous_ema_slow": previous_slow,
            "previous_signal": previous_signal,
            "current_signal": current_signal,
            "source": "live_feed_completed_candle",
            "is_confirmed": True,
            "is_provisional": False,
            "may_repaint": False,
            "created_at": self._now_market_time(),
            "candle": completed_candle,
        }

        if contract_info:
            event["contract_info"] = contract_info

        state["last_crossover"] = event
        state["last_confirmed_crossover"] = event
        state.setdefault("crossovers", []).append(event)

        self.cross_events.append(event)

        logger.info(
            f"Confirmed live EMA crossover detected. "
            f"instrument_key={instrument_key}, "
            f"cross_type={cross_type}, "
            f"timestamp={candle_ts}, "
            f"close={close_price}, "
            f"current_signal={current_signal}"
        )

        self._save_live_events_if_enabled_locked()
        self._dispatch_crossover_callback_locked(event)

        return event

    # ========================================================
    # Callback Dispatch
    # ========================================================

    def _dispatch_crossover_callback_locked(self, event: dict):
        """
        Dispatches crossover callback if registered.

        Lock may already be held by caller.
        """

        if not self.crossover_callback:
            return

        try:
            loop = asyncio.get_running_loop()
            loop.create_task(self.crossover_callback(event))

        except RuntimeError:
            asyncio.run(self.crossover_callback(event))

        except Exception as ex:
            logger.error(f"Failed to execute crossover callback: {ex}")

    # ========================================================
    # Storage
    # ========================================================

    def _save_live_events_if_enabled_locked(self):
        """
        Saves compact live EMA cross events to file if enabled.

        Lock must already be held by caller.
        """

        if not bool(getattr(config, "TEST_FLAG", False)):
            return

        if not self.save_test_file:
            return

        try:
            file_path = Path(self.output_file)
            file_path.parent.mkdir(parents=True, exist_ok=True)

            events = list(self.cross_events)

            if not self.provisional_save_test_file:
                events = [
                    event
                    for event in events
                    if event.get("signal_status") != "provisional"
                ]

            payload = {
                "generated_at": self._now_market_time(),
                "interval_minutes": self.interval_minutes,
                "fast_period": self.fast_period,
                "slow_period": self.slow_period,
                "provisional_enabled": self.provisional_enabled,
                "confirmed_enabled": self.confirmed_enabled,
                "provisional_store_events": self.provisional_store_events,
                "provisional_save_test_file": self.provisional_save_test_file,
                "events_count": len(events),
                "events": events,
            }

            with open(file_path, "w", encoding="utf-8") as file:
                json.dump(payload, file, indent=4, default=str)

        except Exception as ex:
            logger.error(
                f"Failed saving live EMA crossover events: "
                f"{type(ex).__name__}: {ex}"
            )

    # ========================================================
    # Read APIs
    # ========================================================

    def get_status(self) -> dict:
        """Returns live EMA service status."""

        with self._lock:
            confirmed_events_count = len(
                [
                    event
                    for event in self.cross_events
                    if event.get("signal_status") == "confirmed"
                ]
            )

            provisional_events_count = len(
                [
                    event
                    for event in self.cross_events
                    if event.get("signal_status") == "provisional"
                ]
            )

            return {
                "enabled": self.enabled,
                "interval_minutes": self.interval_minutes,
                "fast_period": self.fast_period,
                "slow_period": self.slow_period,
                "tracked_instruments": len(self.state),
                "events_count": len(self.cross_events),
                "confirmed_events_count": confirmed_events_count,
                "provisional_events_count": provisional_events_count,
                "output_file": self.output_file,
                "save_test_file": self.save_test_file,
                "max_events_in_memory": self.max_events_in_memory,
                "payload_mode": "compact",
                "signal_model": "provisional_and_confirmed",
                "provisional_enabled": self.provisional_enabled,
                "confirmed_enabled": self.confirmed_enabled,
                "provisional_broadcast_only_on_change": (
                    self.provisional_broadcast_only_on_change
                ),
                "provisional_store_events": self.provisional_store_events,
                "provisional_save_test_file": self.provisional_save_test_file,
                "opening_range_enrichment": "handled_in_upstox_websocket",
                "selected_or_filtering": "disabled",
                "telegram_alerts": "disabled",
                "updated_at": self._now_market_time(),
            }

    def get_events(self, limit: int = 100) -> list:
        """Returns latest compact live EMA crossover events."""

        limit = max(1, int(limit or 100))

        with self._lock:
            return list(self.cross_events)[-limit:]

    def get_instrument_state(self, instrument_key: str) -> dict | None:
        """Returns live EMA state for one instrument."""

        with self._lock:
            state = self.state.get(instrument_key)

            if not state:
                return None

            copied = dict(state)

            crossovers = copied.get("crossovers", [])
            provisional_crossovers = copied.get("provisional_crossovers", [])

            copied["crossovers_count"] = len(crossovers)
            copied["provisional_crossovers_count"] = len(provisional_crossovers)
            copied["recent_crossovers"] = crossovers[-20:]
            copied["recent_provisional_crossovers"] = provisional_crossovers[-20:]

            copied.pop("crossovers", None)
            copied.pop("provisional_crossovers", None)

            return copied

    def get_all_instrument_summaries(self) -> dict:
        """Returns lightweight state summary for all instruments."""

        with self._lock:
            output = {}

            for instrument_key, state in self.state.items():
                output[instrument_key] = {
                    "instrument_key": instrument_key,
                    "initialized": state.get("initialized"),
                    "interval_minutes": state.get("interval_minutes"),
                    "previous_ema_fast": state.get("previous_ema_fast"),
                    "previous_ema_slow": state.get("previous_ema_slow"),
                    "previous_signal": state.get("previous_signal"),
                    "latest_close": state.get("latest_close"),
                    "last_historical_timestamp": state.get("last_historical_timestamp"),
                    "last_processed_candle_ts": state.get("last_processed_candle_ts"),
                    "last_crossover": state.get("last_crossover"),
                    "last_confirmed_crossover": state.get("last_confirmed_crossover"),
                    "last_provisional_crossover": state.get(
                        "last_provisional_crossover"
                    ),
                    "crossovers_count": len(state.get("crossovers", [])),
                    "provisional_crossovers_count": len(
                        state.get("provisional_crossovers", [])
                    ),
                    "updated_at": state.get("updated_at"),
                    "contract_info": state.get("contract_info", {}),
                }

            return output


live_ema_service = LiveEMAService()