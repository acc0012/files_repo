"""
Compatibility wrapper for the refactored Opening Range service.

This file keeps existing imports working while actual logic is split under:
    services/opening_range/
"""

from services.opening_range import (
    calculate_opening_range_for_all_subscribed,
    calculate_opening_range_for_instrument,
    flush_pending_touch_alerts,
    get_opening_range_status,
    get_opening_range_cache,
    get_opening_range_for_instrument_from_cache,
    get_opening_range_touch_events,
    get_opening_range_pending_touch_events,
    get_selected_or_instrument_state,
    get_selected_or_instrument_key,
    is_selected_or_instrument_locked,
    get_selected_or_ema_alerts,
    get_opening_range_levels_for_ema_event,
    get_opening_range_dashboard_summary,
    process_live_tick_for_opening_range,
    process_selected_or_ema_cross_alert,
)
