import time
from services.telegram_service import telegram_service
from .config import (
    DEFAULT_LEGACY_TOUCH_TELEGRAM_ENABLED,
    DEFAULT_TOUCH_ALERT_ENABLED,
    DEFAULT_TOUCH_ALERT_BATCH_SECONDS,
    DEFAULT_TOUCH_ALERT_MAX_INSTRUMENTS,
    DEFAULT_SORT_BY_NEAREST_INDEX,
)
from .state import (
    _touch_lock,
    _opening_range_cache_lock,
    _pending_touch_events,
    opening_range_cache,
    get_latest_main_index_ltp,
)

_last_touch_alert_sent_at = None


def get_sorted_touch_events_for_alert(events: list) -> list:
    if not events:
        return []
    if not DEFAULT_SORT_BY_NEAREST_INDEX:
        return events

    def sort_key(event):
        distance = event.get("distance_from_index")
        if distance is None:
            return 999999999
        return float(distance)

    return sorted(events, key=sort_key)


def format_touch_event_line(index: int, event: dict) -> str:
    info = event.get("contract_info") or {}
    strike = info.get("strike_price", "N/A")
    itype = str(info.get("instrument_type", "N/A")).upper()
    symbol = (
        info.get("trading_symbol")
        or info.get("instrument_key")
        or event.get("instrument_key")
    )
    return (
        f"{index}. {strike} {itype}\n"
        f"   Symbol: {symbol}\n"
        f"   Level: {event.get('level')}\n"
        f"   Level Value: {event.get('level_value')}\n"
        f"   Trigger {event.get('trigger_field')}: {event.get('trigger_price')}\n"
        f"   Touch Time: {event.get('touch_time')}\n"
        f"   Distance From Index: {event.get('distance_from_index')}"
    )


def send_touch_events_telegram_alert(
    events: list, source: str, force: bool = False
) -> bool:
    global _last_touch_alert_sent_at
    if (
        not DEFAULT_LEGACY_TOUCH_TELEGRAM_ENABLED
        or not DEFAULT_TOUCH_ALERT_ENABLED
        or not events
    ):
        return False
    now_ts = time.time()
    if not force and _last_touch_alert_sent_at is not None:
        elapsed = now_ts - _last_touch_alert_sent_at
        if elapsed < DEFAULT_TOUCH_ALERT_BATCH_SECONDS:
            return False
    sorted_events = get_sorted_touch_events_for_alert(events)
    selected_events = sorted_events[:DEFAULT_TOUCH_ALERT_MAX_INSTRUMENTS]
    index_ltp = get_latest_main_index_ltp()
    lines = [
        format_touch_event_line(index + 1, event)
        for index, event in enumerate(selected_events)
    ]
    message = (
        f"Source: {source}\n"
        f"NIFTY LTP: {index_ltp if index_ltp is not None else 'not_available'}\n"
        f"Total Touched Instruments: {len(events)}\n"
        f"Alerted Instruments: {len(selected_events)}\n\n" + "\n\n".join(lines)
    )
    sent = telegram_service.send_message(
        title="Opening Range Touch Alert", message=message, level="REFRESH"
    )
    if sent:
        _last_touch_alert_sent_at = now_ts
    return sent


def flush_pending_touch_alerts(force: bool = False, source: str = "live_tick") -> bool:
    if not DEFAULT_LEGACY_TOUCH_TELEGRAM_ENABLED:
        return False
    with _touch_lock:
        pending = list(_pending_touch_events)
        _pending_touch_events.clear()
    if not pending:
        return False
    sent = send_touch_events_telegram_alert(events=pending, source=source, force=force)
    if not sent:
        with _touch_lock:
            for event in pending:
                _pending_touch_events.appendleft(event)
    with _opening_range_cache_lock:
        opening_range_cache["pending_touch_events_count"] = len(_pending_touch_events)
    return sent
