from datetime import datetime
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from core import config
from core.logger import get_logger
from services.option_service import (
    options_cache,
    get_contract_info_by_instrument_key,
)

logger = get_logger(__file__)


def is_opening_range_enabled() -> bool:
    return bool(getattr(config, "OPENING_RANGE_ENABLED", True))


def get_market_timezone():
    timezone_name = getattr(config, "MARKET_TIMEZONE", "Asia/Kolkata")

    try:
        return ZoneInfo(timezone_name)

    except ZoneInfoNotFoundError:
        logger.error(
            f"Invalid MARKET_TIMEZONE configured: {timezone_name}. "
            "Falling back to Asia/Kolkata."
        )
        return ZoneInfo("Asia/Kolkata")


def get_now_market_time() -> datetime:
    return datetime.now(get_market_timezone())


def get_live_ema_calculation_mode_text() -> str:
    """
    Returns currently active EMA calculation mode.

    Reads directly from config every time instead of using
    a value cached during module import.

    Returns:
        tick_ltp
        candle_close
    """

    return (
        "tick_ltp"
        if bool(getattr(config, "LIVE_EMA_CALCULATION_MODE", False))
        else "candle_close"
    )


def safe_float(value, default: float = 0.0) -> float:
    try:
        if value is None:
            return default

        return float(value)

    except Exception:
        return default


def safe_int(value, default: int = 0) -> int:
    try:
        if value is None:
            return default

        return int(value)

    except Exception:
        return default


def response_to_dict(api_response: Any) -> dict:
    if api_response is None:
        return {}

    if hasattr(api_response, "to_dict"):
        return api_response.to_dict()

    if isinstance(api_response, dict):
        return api_response

    try:
        return dict(api_response)

    except Exception:
        return {}


def extract_candles_from_response(api_response: Any) -> list:
    response_dict = response_to_dict(api_response)

    data = response_dict.get("data", {})

    if isinstance(data, dict):
        candles = data.get("candles", [])
        return candles if isinstance(candles, list) else []

    return []


def get_subscribed_instrument_keys() -> list:
    subscribed_keys = options_cache.get("subscribed_keys", [])

    if not subscribed_keys:
        return []

    return list(dict.fromkeys(subscribed_keys))


def get_contract_info_by_key(instrument_key: str) -> dict:
    main_key = getattr(
        config,
        "MAIN_NIFTY_SECURITY",
        "NSE_INDEX|Nifty 50",
    )

    if instrument_key == main_key:
        return {
            "instrument_key": instrument_key,
            "instrument_type": "INDEX",
            "strike_price": None,
            "expiry": None,
            "trading_symbol": "NIFTY 50",
            "underlying_type": "INDEX",
            "underlying_symbol": "NIFTY 50",
        }

    resolved = get_contract_info_by_instrument_key(instrument_key)

    if resolved:
        return resolved

    for item in options_cache.get("data", []):
        if item.get("instrument_key") == instrument_key:
            return item

    return {
        "instrument_key": instrument_key,
    }


def is_option_contract(contract_info: dict | None) -> bool:
    if not contract_info:
        return False

    return str(contract_info.get("instrument_type", "")).upper() in ["CE", "PE"]
