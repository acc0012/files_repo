import json
from pathlib import Path
from core import config
from core.logger import get_logger
from .config import DEFAULT_TOUCH_EVENTS_SAVE_TEST_FILE, DEFAULT_TOUCH_EVENTS_OUTPUT_FILE, DEFAULT_OUTPUT_FILE, DEFAULT_LIVE_EMA_CALCULATION_MODE
from .utils import get_now_market_time, get_live_ema_calculation_mode_text
from .state import _touch_events, _selected_or_ema_alerts
from .status import get_selected_or_instrument_state

logger = get_logger(__file__)


def save_touch_events_to_file_if_enabled():
    if not bool(getattr(config, "TEST_FLAG", False)):
        return None
    if not DEFAULT_TOUCH_EVENTS_SAVE_TEST_FILE:
        return None
    try:
        file_path = Path(DEFAULT_TOUCH_EVENTS_OUTPUT_FILE)
        file_path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "generated_at": get_now_market_time().isoformat(),
            "live_ema_calculation_mode_flag": DEFAULT_LIVE_EMA_CALCULATION_MODE,
            "live_ema_calculation_mode": get_live_ema_calculation_mode_text(),
            "events_count": len(_touch_events),
            "events": list(_touch_events),
            "isolated_instrument": get_selected_or_instrument_state(),
            "isolated_ema_alerts_count": len(_selected_or_ema_alerts),
            "isolated_ema_alerts": list(_selected_or_ema_alerts),
        }
        with open(file_path, "w", encoding="utf-8") as file:
            json.dump(payload, file, indent=4, default=str)
        return str(file_path)
    except Exception as ex:
        logger.error(f"Failed saving opening range touch events: {type(ex).__name__}: {ex}")
        return None


def save_opening_range_results_to_file(summary: dict, output_file: str = DEFAULT_OUTPUT_FILE) -> str:
    file_path = Path(output_file)
    file_path.parent.mkdir(parents=True, exist_ok=True)
    with open(file_path, "w", encoding="utf-8") as file:
        json.dump(summary, file, indent=4, default=str)
    return str(file_path)
