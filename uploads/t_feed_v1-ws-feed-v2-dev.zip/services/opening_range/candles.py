from datetime import datetime, timedelta, time as dt_time
import upstox_client
from upstox_client.rest import ApiException

from core.logger import get_logger
from .config import (
    DEFAULT_MARKET_OPEN_HOUR,
    DEFAULT_MARKET_OPEN_MINUTE,
    DEFAULT_OPENING_RANGE_CANDLE_COUNT,
    DEFAULT_INTRADAY_UNIT,
    DEFAULT_INTRADAY_INTERVAL,
)
from .utils import get_market_timezone, get_now_market_time, safe_float, safe_int, extract_candles_from_response

logger = get_logger(__file__)


def parse_candle_timestamp(timestamp_value) -> datetime | None:
    if timestamp_value is None:
        return None
    market_tz = get_market_timezone()
    try:
        if isinstance(timestamp_value, (int, float)):
            return datetime.fromtimestamp(int(timestamp_value) / 1000, tz=market_tz)
        text = str(timestamp_value).strip()
        if not text:
            return None
        if text.isdigit():
            return datetime.fromtimestamp(int(text) / 1000, tz=market_tz)
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=market_tz)
        else:
            parsed = parsed.astimezone(market_tz)
        return parsed
    except Exception:
        return None


def normalize_candle(candle: list) -> dict | None:
    if not isinstance(candle, list) or len(candle) < 5:
        return None
    candle_dt = parse_candle_timestamp(candle[0])
    if not candle_dt:
        return None
    return {
        "timestamp": candle_dt.isoformat(),
        "datetime": candle_dt,
        "open": safe_float(candle[1]),
        "high": safe_float(candle[2]),
        "low": safe_float(candle[3]),
        "close": safe_float(candle[4]),
        "volume": safe_int(candle[5]) if len(candle) > 5 else 0,
        "oi": safe_int(candle[6]) if len(candle) > 6 else 0,
    }


def normalize_candles(candles: list) -> list:
    normalized = []
    for candle in candles:
        item = normalize_candle(candle)
        if item:
            normalized.append(item)
    seen = set()
    unique = []
    for item in normalized:
        ts = item.get("timestamp")
        if ts not in seen:
            seen.add(ts)
            unique.append(item)
    try:
        return sorted(unique, key=lambda x: x.get("datetime"))
    except Exception:
        return unique


def serialize_candle(candle: dict) -> dict:
    return {
        "timestamp": candle.get("timestamp"),
        "open": candle.get("open"),
        "high": candle.get("high"),
        "low": candle.get("low"),
        "close": candle.get("close"),
        "volume": candle.get("volume"),
        "oi": candle.get("oi"),
    }


def get_market_open_datetime(target_date=None) -> datetime:
    market_tz = get_market_timezone()
    now_market = get_now_market_time()
    if target_date is None:
        target_date = now_market.date()
    return datetime.combine(
        target_date,
        dt_time(hour=DEFAULT_MARKET_OPEN_HOUR, minute=DEFAULT_MARKET_OPEN_MINUTE),
        tzinfo=market_tz,
    )


def get_opening_range_end_datetime(candle_count: int = DEFAULT_OPENING_RANGE_CANDLE_COUNT, target_date=None) -> datetime:
    candle_count = max(1, int(candle_count or 1))
    market_open_dt = get_market_open_datetime(target_date=target_date)
    return market_open_dt + timedelta(minutes=candle_count)


def select_opening_range_candles(candles: list, candle_count: int = DEFAULT_OPENING_RANGE_CANDLE_COUNT) -> list:
    if not candles:
        return []
    candle_count = max(1, int(candle_count or 1))
    market_open_dt = get_market_open_datetime()
    selected = []
    for candle in candles:
        candle_dt = candle.get("datetime")
        if not candle_dt:
            continue
        if candle_dt >= market_open_dt:
            selected.append(candle)
        if len(selected) >= candle_count:
            break
    return selected


def select_post_opening_range_candles(candles: list, candle_count: int = DEFAULT_OPENING_RANGE_CANDLE_COUNT) -> list:
    if not candles:
        return []
    or_end_dt = get_opening_range_end_datetime(candle_count=candle_count)
    return [c for c in candles if c.get("datetime") and c.get("datetime") >= or_end_dt]


def fetch_intraday_candles_for_instrument(instrument_key: str, unit: str = DEFAULT_INTRADAY_UNIT, interval: str = DEFAULT_INTRADAY_INTERVAL) -> dict:
    try:
        api_instance = upstox_client.HistoryV3Api()
        logger.info(f"Opening range intraday request: instrument_key={instrument_key}, unit={unit}, interval={interval}")
        api_response = api_instance.get_intra_day_candle_data(instrument_key, unit, interval)
        raw_candles = extract_candles_from_response(api_response)
        normalized_candles = normalize_candles(raw_candles)
        return {
            "status": "success" if normalized_candles else "empty",
            "instrument_key": instrument_key,
            "unit": unit,
            "interval": interval,
            "candles": normalized_candles,
            "candles_count": len(normalized_candles),
            "error": None,
        }
    except ApiException as ex:
        error_body = getattr(ex, "body", str(ex))
        logger.error(f"ApiException in opening range intraday fetch for {instrument_key}: {error_body}")
        return {"status": "failed", "instrument_key": instrument_key, "unit": unit, "interval": interval, "candles": [], "candles_count": 0, "error": error_body}
    except Exception as ex:
        error_message = f"{type(ex).__name__}: {ex}"
        logger.error(f"Exception in opening range intraday fetch for {instrument_key}: {error_message}")
        return {"status": "failed", "instrument_key": instrument_key, "unit": unit, "interval": interval, "candles": [], "candles_count": 0, "error": error_message}
