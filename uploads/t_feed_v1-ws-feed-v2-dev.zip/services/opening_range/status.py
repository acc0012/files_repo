from core import config

from .config import (
    DEFAULT_EMA_CROSS_INCLUDE_OPENING_RANGE_LEVELS,
    DEFAULT_ISOLATION_ENABLED,
    DEFAULT_ISOLATION_WINDOW_POINTS,
    DEFAULT_ISOLATION_TOUCH_LEVELS,
    DEFAULT_ISOLATION_PRIORITY_LEVELS,
    DEFAULT_ISOLATION_LOCK_FOR_DAY,
    DEFAULT_ISOLATION_ALLOW_PRIORITY_UPGRADE,
)

from .utils import (
    get_live_ema_calculation_mode_text,
    get_now_market_time,
)

from .state import (
    _opening_range_cache_lock,
    _touch_lock,
    _selected_or_lock,
    opening_range_cache,
    _touch_events,
    _pending_touch_events,
    _selected_or_instrument_state,
    _selected_or_ema_alerts,
)


def _is_live_ema_enabled() -> bool:
    return bool(getattr(config, "LIVE_EMA_CALCULATION_MODE", False))


def get_selected_or_instrument_state() -> dict:
    with _selected_or_lock:
        return dict(_selected_or_instrument_state)


def is_selected_or_instrument_locked() -> bool:
    with _selected_or_lock:
        return bool(_selected_or_instrument_state.get("selected"))


def get_selected_or_instrument_key() -> str | None:
    with _selected_or_lock:
        return _selected_or_instrument_state.get("instrument_key")


def get_selected_or_ema_alerts(limit: int = 100) -> list:
    limit = max(1, int(limit or 100))

    with _selected_or_lock:
        return list(_selected_or_ema_alerts)[-limit:]


def get_opening_range_status() -> dict:
    isolated_state = get_selected_or_instrument_state()
    live_ema_flag = _is_live_ema_enabled()

    with _opening_range_cache_lock:
        return {
            "last_run_at": opening_range_cache.get("last_run_at"),
            "date": opening_range_cache.get("date"),
            "status": opening_range_cache.get("status"),
            "message": opening_range_cache.get("message"),
            "source": opening_range_cache.get("source"),
            "interval": opening_range_cache.get("interval"),
            "opening_range_candle_count": opening_range_cache.get(
                "opening_range_candle_count"
            ),
            "market_open_time": opening_range_cache.get("market_open_time"),
            "fetch_time": opening_range_cache.get("fetch_time"),
            "total_instruments": opening_range_cache.get("total_instruments"),
            "success_count": opening_range_cache.get("success_count"),
            "failed_count": opening_range_cache.get("failed_count"),
            "empty_count": opening_range_cache.get("empty_count"),
            "insufficient_data_count": opening_range_cache.get(
                "insufficient_data_count"
            ),
            "output_file_path": opening_range_cache.get("output_file_path"),
            "latest_main_index_ltp": opening_range_cache.get("latest_main_index_ltp"),
            "latest_main_index_ltp_source": opening_range_cache.get(
                "latest_main_index_ltp_source"
            ),
            "latest_main_index_ltp_updated_at": opening_range_cache.get(
                "latest_main_index_ltp_updated_at"
            ),
            "touch_events_count": opening_range_cache.get("touch_events_count"),
            "pending_touch_events_count": opening_range_cache.get(
                "pending_touch_events_count"
            ),
            "alert_sent_keys_count": opening_range_cache.get("alert_sent_keys_count"),
            "isolated_instrument": isolated_state,
            "isolated_instrument_selected": bool(isolated_state.get("selected")),
            "isolated_ema_alerts_count": len(_selected_or_ema_alerts),
            "ema_cross_include_opening_range_levels": (
                DEFAULT_EMA_CROSS_INCLUDE_OPENING_RANGE_LEVELS
            ),
            "live_ema_calculation": {
                "flag": live_ema_flag,
                "mode": get_live_ema_calculation_mode_text(),
                "description": (
                    "live tick/LTP based EMA calculation"
                    if live_ema_flag
                    else "completed candle close based EMA calculation"
                ),
            },
            "isolation_config": {
                "enabled": DEFAULT_ISOLATION_ENABLED,
                "window_points": DEFAULT_ISOLATION_WINDOW_POINTS,
                "touch_levels": DEFAULT_ISOLATION_TOUCH_LEVELS,
                "priority_levels": DEFAULT_ISOLATION_PRIORITY_LEVELS,
                "lock_for_day": DEFAULT_ISOLATION_LOCK_FOR_DAY,
                "allow_priority_upgrade": (DEFAULT_ISOLATION_ALLOW_PRIORITY_UPGRADE),
            },
            "errors": opening_range_cache.get("errors", {}),
        }


def get_opening_range_cache() -> dict:
    live_ema_flag = _is_live_ema_enabled()

    with _opening_range_cache_lock:
        cache_copy = dict(opening_range_cache)

    cache_copy["isolated_instrument"] = get_selected_or_instrument_state()
    cache_copy["isolated_ema_alerts_count"] = len(_selected_or_ema_alerts)
    cache_copy["live_ema_calculation_mode_flag"] = live_ema_flag
    cache_copy["live_ema_calculation_mode"] = get_live_ema_calculation_mode_text()
    cache_copy["live_ema_calculation"] = {
        "flag": live_ema_flag,
        "mode": get_live_ema_calculation_mode_text(),
        "description": (
            "live tick/LTP based EMA calculation"
            if live_ema_flag
            else "completed candle close based EMA calculation"
        ),
    }

    return cache_copy


def get_opening_range_for_instrument_from_cache(
    instrument_key: str,
) -> dict | None:
    with _opening_range_cache_lock:
        return opening_range_cache.get("data", {}).get(instrument_key)


def get_opening_range_touch_events(limit: int = 100) -> list:
    limit = max(1, int(limit or 100))

    with _touch_lock:
        return list(_touch_events)[-limit:]


def get_opening_range_pending_touch_events() -> list:
    with _touch_lock:
        return list(_pending_touch_events)


def get_opening_range_dashboard_summary(
    touch_limit: int = 100,
    alert_limit: int = 100,
) -> dict:
    touch_limit = max(1, int(touch_limit or 100))
    alert_limit = max(1, int(alert_limit or 100))

    live_ema_flag = _is_live_ema_enabled()

    with _opening_range_cache_lock:
        cache_snapshot = dict(opening_range_cache)

        latest_main_index_ltp = opening_range_cache.get("latest_main_index_ltp")
        latest_main_index_ltp_source = opening_range_cache.get(
            "latest_main_index_ltp_source"
        )
        latest_main_index_ltp_updated_at = opening_range_cache.get(
            "latest_main_index_ltp_updated_at"
        )

    isolated_state = get_selected_or_instrument_state()
    isolated_key = isolated_state.get("instrument_key")

    isolated_opening_range_context = {}

    if isolated_key:
        try:
            from .enrichment import get_opening_range_levels_for_ema_event

            isolated_opening_range_context = get_opening_range_levels_for_ema_event(
                isolated_key
            )

        except Exception as ex:
            isolated_opening_range_context = {
                "status": "error",
                "error": f"{type(ex).__name__}: {ex}",
            }

    recent_touch_events = get_opening_range_touch_events(limit=touch_limit)
    isolated_ema_alerts = get_selected_or_ema_alerts(limit=alert_limit)

    return {
        "status": "success",
        "generated_at": get_now_market_time().isoformat(),
        "date": get_now_market_time().date().isoformat(),
        "live_ema_calculation": {
            "flag": live_ema_flag,
            "mode": get_live_ema_calculation_mode_text(),
            "description": (
                "live tick/LTP based EMA calculation"
                if live_ema_flag
                else "completed candle close based EMA calculation"
            ),
        },
        "opening_range_status": get_opening_range_status(),
        "isolated_instrument": isolated_state,
        "selected_or_instrument": isolated_state,
        "isolated_opening_range_context": isolated_opening_range_context,
        "isolated_ema_alerts_count": len(_selected_or_ema_alerts),
        "isolated_ema_alerts": isolated_ema_alerts,
        "recent_touch_events_count": len(recent_touch_events),
        "recent_touch_events": recent_touch_events,
        "latest_main_index_ltp": latest_main_index_ltp,
        "latest_main_index_ltp_source": latest_main_index_ltp_source,
        "latest_main_index_ltp_updated_at": latest_main_index_ltp_updated_at,
        "cache_summary": {
            "last_run_at": cache_snapshot.get("last_run_at"),
            "date": cache_snapshot.get("date"),
            "status": cache_snapshot.get("status"),
            "message": cache_snapshot.get("message"),
            "source": cache_snapshot.get("source"),
            "interval": cache_snapshot.get("interval"),
            "opening_range_candle_count": cache_snapshot.get(
                "opening_range_candle_count"
            ),
            "total_instruments": cache_snapshot.get("total_instruments"),
            "success_count": cache_snapshot.get("success_count"),
            "failed_count": cache_snapshot.get("failed_count"),
            "empty_count": cache_snapshot.get("empty_count"),
            "insufficient_data_count": cache_snapshot.get("insufficient_data_count"),
            "touch_events_count": cache_snapshot.get("touch_events_count"),
            "pending_touch_events_count": cache_snapshot.get(
                "pending_touch_events_count"
            ),
            "alert_sent_keys_count": cache_snapshot.get("alert_sent_keys_count"),
            "output_file_path": cache_snapshot.get("output_file_path"),
        },
    }
