from core import config

from .state import (
    _opening_range_cache_lock,
    opening_range_cache,
)
from .status import get_selected_or_instrument_state
from .touch import get_default_touch_status

# ============================================================
# Config Helpers
# ============================================================


def is_ema_opening_range_enrichment_enabled() -> bool:
    """
    Returns whether EMA crossover events should include Opening Range levels.

    Reads config dynamically so runtime config changes are reflected.
    """

    return bool(
        getattr(
            config,
            "EMA_CROSS_INCLUDE_OPENING_RANGE_LEVELS",
            True,
        )
    )


# ============================================================
# Payload Helpers
# ============================================================


def build_empty_opening_range_enrichment_payload(
    latest_main_index_ltp=None,
) -> dict:
    """
    Builds fallback Opening Range enrichment payload for EMA events.

    Used when:
    - enrichment is disabled
    - instrument_key is missing
    - Opening Range data is not available for the instrument
    """

    return {
        "opening_range": {},
        "touch_status": get_default_touch_status(),
        "latest_intraday_close": None,
        "latest_main_index_ltp": latest_main_index_ltp,
        "processed_at": None,
        "isolated_instrument": get_selected_or_instrument_state(),
    }


def build_compact_opening_range_levels(levels: dict) -> dict:
    """
    Builds compact Opening Range level payload for EMA WebSocket event.

    Keeps only the most useful levels for frontend/live consumers.
    """

    levels = levels or {}

    return {
        "r1": levels.get("r1"),
        "s1": levels.get("s1"),
        "r2": levels.get("r2"),
        "s2": levels.get("s2"),
        "r3": levels.get("r3"),
        "s3": levels.get("s3"),
        "sub_resistance": levels.get("sub_resistance"),
        "sub_support": levels.get("sub_support"),
    }


# ============================================================
# EMA WebSocket Opening Range Enrichment
# ============================================================


def get_opening_range_levels_for_ema_event(
    instrument_key: str,
) -> dict:
    """
    Returns lightweight Opening Range payload for EMA crossover events.

    This payload is merged into the live EMA WebSocket event.

    Output includes:
    - opening_range compact levels
    - touch_status
    - latest_intraday_close
    - latest_main_index_ltp
    - processed_at
    - isolated_instrument
    """

    if not is_ema_opening_range_enrichment_enabled():
        return build_empty_opening_range_enrichment_payload()

    if not instrument_key:
        return build_empty_opening_range_enrichment_payload()

    with _opening_range_cache_lock:
        item = opening_range_cache.get("data", {}).get(instrument_key)
        latest_main_index_ltp = opening_range_cache.get("latest_main_index_ltp")

    if not item:
        return build_empty_opening_range_enrichment_payload(
            latest_main_index_ltp=latest_main_index_ltp,
        )

    levels = item.get("levels") or {}
    compact_levels = build_compact_opening_range_levels(levels)

    return {
        "opening_range": compact_levels,
        "touch_status": item.get(
            "touch_status",
            get_default_touch_status(),
        ),
        "latest_intraday_close": item.get("latest_intraday_close"),
        "latest_main_index_ltp": latest_main_index_ltp,
        "processed_at": item.get("processed_at"),
        "isolated_instrument": get_selected_or_instrument_state(),
    }
