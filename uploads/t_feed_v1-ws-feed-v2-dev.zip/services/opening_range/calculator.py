import time
from concurrent.futures import ThreadPoolExecutor, as_completed

from core import config
from core.logger import get_logger

from .candles import (
    fetch_intraday_candles_for_instrument,
    get_opening_range_end_datetime,
    select_opening_range_candles,
    select_post_opening_range_candles,
    serialize_candle,
)
from .config import (
    DEFAULT_BACKFILL_SCAN_ENABLED,
    DEFAULT_BACKFILL_TOUCH_ALERT_ENABLED,
    DEFAULT_FETCH_HOUR,
    DEFAULT_FETCH_MINUTE,
    DEFAULT_INTRADAY_INTERVAL,
    DEFAULT_INTRADAY_UNIT,
    DEFAULT_LEGACY_TOUCH_TELEGRAM_ENABLED,
    DEFAULT_MAIN_INDEX_KEY,
    DEFAULT_MARKET_OPEN_HOUR,
    DEFAULT_MARKET_OPEN_MINUTE,
    DEFAULT_MAX_WORKERS,
    DEFAULT_OPENING_RANGE_CANDLE_COUNT,
    DEFAULT_OPENING_RANGE_INTERVAL,
    DEFAULT_SAVE_FILE,
    DEFAULT_SLEEP_SECONDS,
    DEFAULT_TOUCH_ALERT_ENABLED,
)
from .isolation import try_isolate_from_touch_events
from .legacy_alerts import send_touch_events_telegram_alert
from .levels import calculate_opening_range_levels
from .state import (
    _alert_sent_keys,
    _opening_range_cache_lock,
    _pending_touch_events,
    _selected_or_ema_alerts,
    _touch_events,
    _touch_lock,
    get_latest_main_index_ltp,
    opening_range_cache,
    update_latest_main_index_ltp,
)
from .status import get_selected_or_instrument_state
from .storage import (
    save_opening_range_results_to_file,
    save_touch_events_to_file_if_enabled,
)
from .touch import (
    build_touch_status_from_events,
    get_default_touch_status,
    queue_touch_event,
    scan_backfill_touches,
)
from .utils import (
    get_contract_info_by_key,
    get_live_ema_calculation_mode_text,
    get_now_market_time,
    get_subscribed_instrument_keys,
    is_opening_range_enabled,
    safe_float,
)

logger = get_logger(__file__)


# ============================================================
# Internal Helpers
# ============================================================


def _is_live_ema_calculation_mode_enabled() -> bool:
    """
    Returns current LIVE_EMA_CALCULATION_MODE flag dynamically.
    """

    return bool(getattr(config, "LIVE_EMA_CALCULATION_MODE", False))


def _get_touch_runtime_counts() -> dict:
    """
    Returns touch runtime counters safely.
    """

    with _touch_lock:
        return {
            "touch_events_count": len(_touch_events),
            "pending_touch_events_count": len(_pending_touch_events),
            "alert_sent_keys_count": len(_alert_sent_keys),
            "touch_events": list(_touch_events),
        }


def _build_base_instrument_payload(
    instrument_key: str,
    candle_count: int,
    contract_info: dict,
    processed_at: str,
) -> dict:
    """
    Builds common payload for one instrument Opening Range result.
    """

    return {
        "instrument_key": instrument_key,
        "source": "intraday_api",
        "date": get_now_market_time().date().isoformat(),
        "interval": DEFAULT_OPENING_RANGE_INTERVAL,
        "unit": DEFAULT_INTRADAY_UNIT,
        "intraday_interval": DEFAULT_INTRADAY_INTERVAL,
        "opening_range_candle_count": candle_count,
        "contract_info": contract_info,
        "processed_at": processed_at,
    }


def _build_failed_instrument_payload(
    base_payload: dict,
    message: str,
    error=None,
) -> dict:
    """
    Builds failed Opening Range result for one instrument.
    """

    return {
        **base_payload,
        "status": "failed",
        "message": message,
        "candles_count": 0,
        "selected_candles_count": 0,
        "latest_intraday_close": None,
        "range": None,
        "levels": None,
        "selected_candles": [],
        "post_or_candles_count": 0,
        "touch_status": get_default_touch_status(),
        "backfill_touch_events": [],
        "error": error,
    }


def _build_empty_instrument_payload(
    base_payload: dict,
    message: str,
) -> dict:
    """
    Builds empty Opening Range result for one instrument.
    """

    return {
        **base_payload,
        "status": "empty",
        "message": message,
        "candles_count": 0,
        "selected_candles_count": 0,
        "latest_intraday_close": None,
        "range": None,
        "levels": None,
        "selected_candles": [],
        "post_or_candles_count": 0,
        "touch_status": get_default_touch_status(),
        "backfill_touch_events": [],
        "error": None,
    }


def _build_insufficient_data_payload(
    base_payload: dict,
    candles: list,
    selected_candles: list,
    candle_count: int,
    latest_intraday_close,
) -> dict:
    """
    Builds insufficient data Opening Range result for one instrument.
    """

    return {
        **base_payload,
        "status": "insufficient_data",
        "message": (
            f"Need {candle_count} opening range candles, "
            f"but only {len(selected_candles)} available."
        ),
        "candles_count": len(candles),
        "selected_candles_count": len(selected_candles),
        "latest_intraday_close": latest_intraday_close,
        "range": None,
        "levels": None,
        "selected_candles": [
            serialize_candle(item) for item in selected_candles
        ],
        "post_or_candles_count": 0,
        "touch_status": get_default_touch_status(),
        "backfill_touch_events": [],
        "error": None,
    }


def _build_worker_failed_result(
    instrument_key: str,
    current_date: str,
    candle_count: int,
    error_message: str,
) -> dict:
    """
    Builds fallback result when worker execution itself fails.
    """

    return {
        "instrument_key": instrument_key,
        "status": "failed",
        "message": "Opening range worker failed.",
        "source": "intraday_api",
        "date": current_date,
        "interval": DEFAULT_OPENING_RANGE_INTERVAL,
        "opening_range_candle_count": candle_count,
        "latest_intraday_close": None,
        "range": None,
        "levels": None,
        "touch_status": get_default_touch_status(),
        "backfill_touch_events": [],
        "error": error_message,
        "contract_info": get_contract_info_by_key(instrument_key),
        "processed_at": get_now_market_time().isoformat(),
    }


# ============================================================
# Single Instrument Opening Range
# ============================================================


def calculate_opening_range_for_instrument(
    instrument_key: str,
    candle_count: int = DEFAULT_OPENING_RANGE_CANDLE_COUNT,
) -> dict:
    """
    Fetches intraday candles for one instrument and calculates Opening Range levels.

    Also scans post-Opening Range candles for already touched R2/R3/S2/S3 levels.
    """

    processed_at = get_now_market_time().isoformat()
    contract_info = get_contract_info_by_key(instrument_key)

    intraday_result = fetch_intraday_candles_for_instrument(
        instrument_key=instrument_key,
        unit=DEFAULT_INTRADAY_UNIT,
        interval=DEFAULT_INTRADAY_INTERVAL,
    )

    base_payload = _build_base_instrument_payload(
        instrument_key=instrument_key,
        candle_count=candle_count,
        contract_info=contract_info,
        processed_at=processed_at,
    )

    if intraday_result.get("status") == "failed":
        return _build_failed_instrument_payload(
            base_payload=base_payload,
            message="Intraday candle fetch failed.",
            error=intraday_result.get("error"),
        )

    candles = intraday_result.get("candles", [])

    if not candles:
        return _build_empty_instrument_payload(
            base_payload=base_payload,
            message="No intraday candles returned.",
        )

    latest_intraday_close = safe_float(candles[-1].get("close"))

    if instrument_key == DEFAULT_MAIN_INDEX_KEY and latest_intraday_close > 0:
        update_latest_main_index_ltp(
            ltp=latest_intraday_close,
            source="intraday_api",
            updated_at=candles[-1].get("timestamp"),
        )

    selected_candles = select_opening_range_candles(
        candles=candles,
        candle_count=candle_count,
    )

    if len(selected_candles) < int(candle_count):
        return _build_insufficient_data_payload(
            base_payload=base_payload,
            candles=candles,
            selected_candles=selected_candles,
            candle_count=candle_count,
            latest_intraday_close=latest_intraday_close,
        )

    calculation = calculate_opening_range_levels(selected_candles)
    levels = calculation.get("levels") or {}

    post_or_candles = select_post_opening_range_candles(
        candles=candles,
        candle_count=candle_count,
    )

    backfill_touch_events = []

    if calculation.get("status") == "success":
        backfill_touch_events = scan_backfill_touches(
            instrument_key=instrument_key,
            candles=candles,
            levels=levels,
            contract_info=contract_info,
            candle_count=candle_count,
        )

    touch_status = build_touch_status_from_events(backfill_touch_events)

    return {
        **base_payload,
        "status": calculation.get("status"),
        "message": calculation.get("message"),
        "candles_count": len(candles),
        "selected_candles_count": len(selected_candles),
        "latest_intraday_close": latest_intraday_close,
        "range": calculation.get("range"),
        "levels": levels,
        "selected_candles": [
            serialize_candle(item) for item in selected_candles
        ],
        "post_or_candles_count": len(post_or_candles),
        "touch_status": touch_status,
        "backfill_touch_events": backfill_touch_events,
        "error": None,
    }


# ============================================================
# All Subscribed Instruments Opening Range
# ============================================================


def calculate_opening_range_for_all_subscribed(
    candle_count: int = DEFAULT_OPENING_RANGE_CANDLE_COUNT,
    save_data: bool = DEFAULT_SAVE_FILE,
    max_workers: int = DEFAULT_MAX_WORKERS,
) -> dict:
    """
    Fetches intraday candles and calculates Opening Range levels
    for all subscribed instruments.
    """

    if not is_opening_range_enabled():
        logger.info("Opening range calculation skipped because it is disabled.")

        return {
            "status": "disabled",
            "message": "Opening range calculation is disabled.",
            "total_instruments": 0,
            "success_count": 0,
            "failed_count": 0,
            "empty_count": 0,
            "insufficient_data_count": 0,
        }

    subscribed_keys = get_subscribed_instrument_keys()

    if not subscribed_keys:
        logger.warning(
            "Opening range calculation skipped. No subscribed instruments found."
        )

        return {
            "status": "skipped",
            "message": "No subscribed instruments found.",
            "total_instruments": 0,
            "success_count": 0,
            "failed_count": 0,
            "empty_count": 0,
            "insufficient_data_count": 0,
        }

    try:
        candle_count = max(1, int(candle_count))
    except Exception:
        candle_count = DEFAULT_OPENING_RANGE_CANDLE_COUNT

    try:
        max_workers = max(1, int(max_workers))
    except Exception:
        max_workers = DEFAULT_MAX_WORKERS

    now_market = get_now_market_time()
    started_at = now_market.isoformat()
    current_date = now_market.date().isoformat()

    logger.info(
        "================ OPENING RANGE INTRADAY FETCH STARTED ================"
    )

    logger.info(
        f"Calculating opening range for {len(subscribed_keys)} instruments. "
        f"date={current_date}, "
        f"candle_count={candle_count}, "
        f"interval={DEFAULT_OPENING_RANGE_INTERVAL}, "
        f"unit={DEFAULT_INTRADAY_UNIT}, "
        f"intraday_interval={DEFAULT_INTRADAY_INTERVAL}, "
        f"max_workers={max_workers}"
    )

    results = {}
    errors = {}

    success_count = 0
    failed_count = 0
    empty_count = 0
    insufficient_data_count = 0

    total_backfill_touch_events = 0
    backfill_touch_events = []

    total_instruments = len(subscribed_keys)

    def worker(instrument_key: str) -> dict:
        result = calculate_opening_range_for_instrument(
            instrument_key=instrument_key,
            candle_count=candle_count,
        )

        if DEFAULT_SLEEP_SECONDS and DEFAULT_SLEEP_SECONDS > 0:
            time.sleep(DEFAULT_SLEEP_SECONDS)

        return result

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_instrument = {
            executor.submit(worker, instrument_key): instrument_key
            for instrument_key in subscribed_keys
        }

        completed_count = 0

        for future in as_completed(future_to_instrument):
            instrument_key = future_to_instrument[future]
            completed_count += 1

            logger.info(
                f"Opening range progress: {completed_count}/{total_instruments} "
                f"instrument_key={instrument_key}"
            )

            try:
                result = future.result()
                result_status = result.get("status")

                results[instrument_key] = result

                instrument_backfill_events = result.get(
                    "backfill_touch_events",
                    [],
                )

                if instrument_backfill_events:
                    total_backfill_touch_events += len(
                        instrument_backfill_events
                    )
                    backfill_touch_events.extend(instrument_backfill_events)

                    for event in instrument_backfill_events:
                        queue_touch_event(event)

                if result_status == "success":
                    success_count += 1
                elif result_status == "empty":
                    empty_count += 1
                elif result_status == "insufficient_data":
                    insufficient_data_count += 1
                else:
                    failed_count += 1
                    errors[instrument_key] = (
                        result.get("error") or result.get("message")
                    )

            except Exception as ex:
                error_message = f"{type(ex).__name__}: {ex}"

                logger.error(
                    f"Opening range calculation failed for "
                    f"instrument_key={instrument_key}: {error_message}"
                )

                failed_count += 1
                errors[instrument_key] = error_message

                results[instrument_key] = _build_worker_failed_result(
                    instrument_key=instrument_key,
                    current_date=current_date,
                    candle_count=candle_count,
                    error_message=error_message,
                )

    completed_at = get_now_market_time().isoformat()

    if failed_count == 0:
        overall_status = "success"
    elif success_count > 0 or empty_count > 0 or insufficient_data_count > 0:
        overall_status = "partial_success"
    else:
        overall_status = "failed"

    touch_counts = _get_touch_runtime_counts()

    with _opening_range_cache_lock:
        opening_range_cache.update(
            {
                "last_run_at": completed_at,
                "date": current_date,
                "status": overall_status,
                "message": "Opening range calculation completed.",
                "source": "intraday_api",
                "interval": DEFAULT_OPENING_RANGE_INTERVAL,
                "opening_range_candle_count": candle_count,
                "market_open_time": (
                    f"{DEFAULT_MARKET_OPEN_HOUR:02d}:"
                    f"{DEFAULT_MARKET_OPEN_MINUTE:02d}"
                ),
                "fetch_time": (
                    f"{DEFAULT_FETCH_HOUR:02d}:"
                    f"{DEFAULT_FETCH_MINUTE:02d}"
                ),
                "total_instruments": total_instruments,
                "success_count": success_count,
                "failed_count": failed_count,
                "empty_count": empty_count,
                "insufficient_data_count": insufficient_data_count,
                "latest_main_index_ltp": get_latest_main_index_ltp(),
                "touch_events_count": touch_counts["touch_events_count"],
                "pending_touch_events_count": (
                    touch_counts["pending_touch_events_count"]
                ),
                "alert_sent_keys_count": touch_counts["alert_sent_keys_count"],
                "data": results,
                "touch_events": touch_counts["touch_events"],
                "errors": errors,
            }
        )

    # Important:
    # Isolate after all backfill events are collected,
    # so R3/S3 priority can win over R2/S2.
    if backfill_touch_events:
        try_isolate_from_touch_events(backfill_touch_events)

    isolated_state = get_selected_or_instrument_state()
    live_ema_flag = _is_live_ema_calculation_mode_enabled()

    summary = {
        "status": overall_status,
        "message": "Opening range calculation completed.",
        "source": "intraday_api",
        "date": current_date,
        "started_at": started_at,
        "completed_at": completed_at,
        "interval": DEFAULT_OPENING_RANGE_INTERVAL,
        "unit": DEFAULT_INTRADAY_UNIT,
        "intraday_interval": DEFAULT_INTRADAY_INTERVAL,
        "opening_range_candle_count": candle_count,
        "market_open_time": (
            f"{DEFAULT_MARKET_OPEN_HOUR:02d}:"
            f"{DEFAULT_MARKET_OPEN_MINUTE:02d}"
        ),
        "live_ema_calculation_mode_flag": live_ema_flag,
        "live_ema_calculation_mode": get_live_ema_calculation_mode_text(),
        "opening_range_end_time": get_opening_range_end_datetime(
            candle_count=candle_count,
        ).strftime("%H:%M"),
        "scheduled_fetch_time": (
            f"{DEFAULT_FETCH_HOUR:02d}:{DEFAULT_FETCH_MINUTE:02d}"
        ),
        "max_workers": max_workers,
        "total_instruments": total_instruments,
        "success_count": success_count,
        "failed_count": failed_count,
        "empty_count": empty_count,
        "insufficient_data_count": insufficient_data_count,
        "backfill_touch_scan_enabled": DEFAULT_BACKFILL_SCAN_ENABLED,
        "backfill_touch_events_count": total_backfill_touch_events,
        "latest_main_index_ltp": get_latest_main_index_ltp(),
        "isolated_instrument": isolated_state,
        "isolated_ema_alerts_count": len(_selected_or_ema_alerts),
        "results": results,
        "backfill_touch_events": backfill_touch_events,
        "errors": errors,
    }

    output_file_path = None

    if save_data:
        try:
            output_file_path = save_opening_range_results_to_file(summary)
            summary["output_file_path"] = output_file_path

            logger.info(f"Saved opening range results to {output_file_path}")

        except Exception as ex:
            error_message = f"{type(ex).__name__}: {ex}"
            logger.error(f"Failed saving opening range results: {error_message}")
            summary["output_file_error"] = error_message

    else:
        logger.info("Opening range result file not saved because save_data=False.")

    isolated_state = get_selected_or_instrument_state()

    with _opening_range_cache_lock:
        opening_range_cache["output_file_path"] = output_file_path
        opening_range_cache["isolated_instrument"] = isolated_state
        opening_range_cache["isolated_instrument_selected"] = bool(
            isolated_state.get("selected")
        )
        opening_range_cache["isolated_ema_alerts_count"] = len(
            _selected_or_ema_alerts
        )

    if (
        DEFAULT_BACKFILL_TOUCH_ALERT_ENABLED
        and DEFAULT_TOUCH_ALERT_ENABLED
        and DEFAULT_LEGACY_TOUCH_TELEGRAM_ENABLED
        and backfill_touch_events
    ):
        send_touch_events_telegram_alert(
            events=backfill_touch_events,
            source="intraday_backfill_scan",
            force=True,
        )

    save_touch_events_to_file_if_enabled()

    logger.info(
        f"Opening range calculation completed. "
        f"status={overall_status}, "
        f"total_instruments={total_instruments}, "
        f"success={success_count}, "
        f"empty={empty_count}, "
        f"insufficient_data={insufficient_data_count}, "
        f"failed={failed_count}, "
        f"backfill_touch_events={total_backfill_touch_events}, "
        f"isolated_selected={isolated_state.get('selected')}, "
        f"output_file={output_file_path}"
    )

    logger.info(
        "================ OPENING RANGE INTRADAY FETCH COMPLETED ================"
    )

    return summary