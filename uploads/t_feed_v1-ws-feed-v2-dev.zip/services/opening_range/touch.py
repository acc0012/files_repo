from copy import deepcopy

from .candles import (
    parse_candle_timestamp,
    select_post_opening_range_candles,
    serialize_candle,
)
from .config import (
    DEFAULT_BACKFILL_SCAN_ENABLED,
    DEFAULT_ISOLATION_TOUCH_LEVELS,
    DEFAULT_LEGACY_TOUCH_TELEGRAM_ENABLED,
    DEFAULT_LIVE_TOUCH_ALERT_ENABLED,
    DEFAULT_MAIN_INDEX_KEY,
    DEFAULT_TOUCH_ALERT_ENABLED,
    DEFAULT_TOUCH_ALERT_ONCE_PER_LEVEL,
    DEFAULT_TOUCH_ALERT_OPTIONS_ONLY,
    DEFAULT_TOUCH_CHECK_MODE,
)
from .state import (
    _alert_sent_keys,
    _opening_range_cache_lock,
    _pending_touch_events,
    _touch_events,
    _touch_lock,
    get_latest_main_index_ltp,
    opening_range_cache,
    update_latest_ltp_for_instrument,
    update_latest_main_index_ltp,
)
from .utils import (
    get_contract_info_by_key,
    get_now_market_time,
    is_option_contract,
    safe_float,
)

# ============================================================
# Touch Event Basic Helpers
# ============================================================


def build_alert_key(instrument_key: str, level: str) -> str:
    """
    Builds unique alert key for duplicate prevention.

    Example:
        NSE_FO|41012_R3
    """

    return f"{instrument_key}_{str(level).upper()}"


def calculate_distance_from_index(strike_price, index_ltp) -> float | None:
    """
    Calculates distance between option strike and latest main index LTP.
    """

    try:
        if strike_price is None or index_ltp is None:
            return None

        return round(abs(float(strike_price) - float(index_ltp)), 4)

    except Exception:
        return None


def get_default_touch_status() -> dict:
    """
    Returns default touch status for one instrument.
    """

    return {
        "r2_touched": False,
        "s2_touched": False,
        "r3_touched": False,
        "s3_touched": False,
        "r2_touch_time": None,
        "s2_touch_time": None,
        "r3_touch_time": None,
        "s3_touch_time": None,
        "r2_alert_sent": False,
        "s2_alert_sent": False,
        "r3_alert_sent": False,
        "s3_alert_sent": False,
        "first_touch_level": None,
        "first_touch_source": None,
        "first_touch_time": None,
        "events": [],
    }


def create_touch_event(
    instrument_key: str,
    level: str,
    level_value: float,
    trigger_price: float,
    trigger_field: str,
    touch_time: str,
    source: str,
    contract_info: dict,
    candle: dict | None = None,
) -> dict:
    """
    Creates normalized Opening Range R2/R3/S2/S3 touch event.
    """

    index_ltp = get_latest_main_index_ltp()
    strike_price = contract_info.get("strike_price") if contract_info else None

    distance_from_index = calculate_distance_from_index(
        strike_price=strike_price,
        index_ltp=index_ltp,
    )

    return {
        "type": "opening_range_touch",
        "instrument_key": instrument_key,
        "level": str(level).upper(),
        "level_value": round(safe_float(level_value), 4),
        "trigger_price": round(safe_float(trigger_price), 4),
        "trigger_field": trigger_field,
        "touch_time": touch_time,
        "source": source,
        "date": get_now_market_time().date().isoformat(),
        "main_index_ltp": index_ltp,
        "distance_from_index": distance_from_index,
        "alert_key": build_alert_key(instrument_key, level),
        "contract_info": contract_info or {},
        "candle": serialize_candle(candle) if candle else None,
        "created_at": get_now_market_time().isoformat(),
    }


# ============================================================
# Touch Event Queue / Status Helpers
# ============================================================


def should_skip_touch_alert(
    instrument_key: str,
    level: str,
    contract_info: dict | None = None,
) -> bool:
    """
    Checks whether touch event should be skipped.
    """

    if not DEFAULT_TOUCH_ALERT_ENABLED:
        return True

    if DEFAULT_TOUCH_ALERT_OPTIONS_ONLY and not is_option_contract(contract_info):
        return True

    level_upper = str(level).upper()

    if level_upper not in DEFAULT_ISOLATION_TOUCH_LEVELS:
        return True

    alert_key = build_alert_key(instrument_key, level_upper)

    with _touch_lock:
        if DEFAULT_TOUCH_ALERT_ONCE_PER_LEVEL and alert_key in _alert_sent_keys:
            return True

    return False


def mark_touch_alert_sent(event: dict):
    """
    Marks instrument-level touch as already tracked.
    """

    alert_key = event.get("alert_key")

    if not alert_key:
        return

    with _touch_lock:
        _alert_sent_keys.add(alert_key)


def queue_touch_event(event: dict):
    """
    Queues touch event for internal tracking and optional legacy Telegram alert.

    Notes:
    - _touch_events is bounded by OPENING_RANGE_MAX_EVENTS_IN_MEMORY.
    - opening_range_cache["touch_events"] is kept for backward compatibility.
    """

    if not isinstance(event, dict):
        return

    with _touch_lock:
        _touch_events.append(event)

        if DEFAULT_LEGACY_TOUCH_TELEGRAM_ENABLED:
            _pending_touch_events.append(event)

        touch_events_count = len(_touch_events)
        pending_touch_events_count = len(_pending_touch_events)
        alert_sent_keys_count = len(_alert_sent_keys)
        touch_events_snapshot = list(_touch_events)

    with _opening_range_cache_lock:
        opening_range_cache["touch_events_count"] = touch_events_count
        opening_range_cache["pending_touch_events_count"] = pending_touch_events_count
        opening_range_cache["alert_sent_keys_count"] = alert_sent_keys_count
        opening_range_cache["touch_events"] = touch_events_snapshot


def build_touch_status_from_events(events: list) -> dict:
    """
    Builds touch status from detected events.
    """

    status = get_default_touch_status()

    for event in events:
        level = str(event.get("level", "")).upper()
        lower_level = level.lower()

        if level in ["R2", "S2", "R3", "S3"]:
            status[f"{lower_level}_touched"] = True
            status[f"{lower_level}_touch_time"] = event.get("touch_time")
            status[f"{lower_level}_alert_sent"] = True

        if not status.get("first_touch_level"):
            status["first_touch_level"] = level
            status["first_touch_source"] = event.get("source")
            status["first_touch_time"] = event.get("touch_time")

        status.setdefault("events", []).append(event)

    return status


def update_touch_status_in_cache(
    instrument_key: str,
    event: dict,
):
    """
    Updates touch status for one instrument inside opening_range_cache.
    """

    level = str(event.get("level", "")).upper()
    lower_level = level.lower()

    with _opening_range_cache_lock:
        data = opening_range_cache.get("data", {})
        item = data.get(instrument_key)

        if not item:
            return

        touch_status = item.setdefault(
            "touch_status",
            get_default_touch_status(),
        )

        if level in ["R2", "S2", "R3", "S3"]:
            touch_status[f"{lower_level}_touched"] = True
            touch_status[f"{lower_level}_touch_time"] = event.get("touch_time")
            touch_status[f"{lower_level}_alert_sent"] = True

        if not touch_status.get("first_touch_level"):
            touch_status["first_touch_level"] = level
            touch_status["first_touch_source"] = event.get("source")
            touch_status["first_touch_time"] = event.get("touch_time")

        touch_status.setdefault("events", []).append(event)

        item["touch_status"] = touch_status
        data[instrument_key] = item
        opening_range_cache["data"] = data


# ============================================================
# Touch Detection From Candles
# ============================================================


def detect_touch_from_candle(
    instrument_key: str,
    candle: dict,
    levels: dict,
    contract_info: dict,
    source: str,
) -> list:
    """
    Detects R2/R3/S2/S3 touch from candle high/low.

    Detection:
        R2/R3 -> high >= level
        S2/S3 -> low <= level
    """

    if not candle or not levels:
        return []

    events = []

    level_map = {
        "R2": {
            "value": safe_float(levels.get("r2")),
            "condition_field": "high",
            "trigger": safe_float(candle.get("high")),
            "fallback": safe_float(candle.get("close")),
            "direction": "above",
        },
        "R3": {
            "value": safe_float(levels.get("r3")),
            "condition_field": "high",
            "trigger": safe_float(candle.get("high")),
            "fallback": safe_float(candle.get("close")),
            "direction": "above",
        },
        "S2": {
            "value": safe_float(levels.get("s2")),
            "condition_field": "low",
            "trigger": safe_float(candle.get("low")),
            "fallback": safe_float(candle.get("close")),
            "direction": "below",
        },
        "S3": {
            "value": safe_float(levels.get("s3")),
            "condition_field": "low",
            "trigger": safe_float(candle.get("low")),
            "fallback": safe_float(candle.get("close")),
            "direction": "below",
        },
    }

    candle_time = candle.get("timestamp") or get_now_market_time().isoformat()

    for level_name, item in level_map.items():
        if level_name not in DEFAULT_ISOLATION_TOUCH_LEVELS:
            continue

        level_value = item["value"]

        if level_value <= 0:
            continue

        trigger_price = item["trigger"]
        trigger_field = item["condition_field"]

        if trigger_price <= 0:
            trigger_price = item["fallback"]
            trigger_field = "close"

        if trigger_price <= 0:
            continue

        if item["direction"] == "above":
            touched = trigger_price >= level_value
        else:
            touched = trigger_price <= level_value

        if not touched:
            continue

        if should_skip_touch_alert(
            instrument_key=instrument_key,
            level=level_name,
            contract_info=contract_info,
        ):
            continue

        events.append(
            create_touch_event(
                instrument_key=instrument_key,
                level=level_name,
                level_value=level_value,
                trigger_price=trigger_price,
                trigger_field=trigger_field,
                touch_time=candle_time,
                source=source,
                contract_info=contract_info,
                candle=candle,
            )
        )

    return events


def scan_backfill_touches(
    instrument_key: str,
    candles: list,
    levels: dict,
    contract_info: dict,
    candle_count: int,
) -> list:
    """
    Scans post-Opening Range intraday candles for R2/R3/S2/S3 touches.
    """

    if not DEFAULT_BACKFILL_SCAN_ENABLED:
        return []

    post_or_candles = select_post_opening_range_candles(
        candles=candles,
        candle_count=candle_count,
    )

    events = []

    for candle in post_or_candles:
        detected_events = detect_touch_from_candle(
            instrument_key=instrument_key,
            candle=candle,
            levels=levels,
            contract_info=contract_info,
            source="intraday_backfill_scan",
        )

        for event in detected_events:
            events.append(event)

            if DEFAULT_TOUCH_ALERT_ONCE_PER_LEVEL:
                mark_touch_alert_sent(event)

            update_touch_status_in_cache(instrument_key, event)

    return events


# ============================================================
# Live Feed Extraction
# ============================================================


def extract_feed_values(tick_data: dict) -> dict:
    """
    Extracts LTP/high/low/close from Upstox full feed payload.
    """

    if not isinstance(tick_data, dict):
        return {}

    raw_feed_obj = tick_data.get("raw_feed", tick_data)
    full_feed = raw_feed_obj.get("fullFeed", raw_feed_obj)
    ff_wrapper = full_feed.get("ff", full_feed)

    ff = (
        ff_wrapper.get("marketFF")
        or ff_wrapper.get("indexFF")
        or full_feed.get("marketFF")
        or full_feed.get("indexFF")
        or full_feed
    )

    ltpc = ff.get("ltpc") or {}
    ltp = safe_float(ltpc.get("ltp"))

    ohlc_list = []

    if "marketOHLC" in ff:
        ohlc_list = ff.get("marketOHLC", {}).get("ohlc", [])
    elif "optionOHLC" in ff:
        ohlc_list = ff.get("optionOHLC", {}).get("ohlc", [])

    latest_i1 = None

    if isinstance(ohlc_list, list):
        matching = [
            item for item in ohlc_list if str(item.get("interval", "")).upper() == "I1"
        ]

        if matching:
            try:
                latest_i1 = max(
                    matching,
                    key=lambda item: int(item.get("ts", 0)),
                )
            except Exception:
                latest_i1 = matching[-1]

    high_value = 0.0
    low_value = 0.0
    close_value = ltp
    timestamp = get_now_market_time().isoformat()

    if latest_i1:
        high_value = safe_float(latest_i1.get("high"))
        low_value = safe_float(latest_i1.get("low"))
        close_value = safe_float(latest_i1.get("close"), default=ltp)

        parsed_ts = parse_candle_timestamp(latest_i1.get("ts"))

        if parsed_ts:
            timestamp = parsed_ts.isoformat()

    return {
        "ltp": ltp,
        "high": high_value,
        "low": low_value,
        "close": close_value,
        "timestamp": timestamp,
    }


# ============================================================
# Live Touch Processing
# ============================================================


def process_live_tick_for_opening_range(
    instrument_key: str,
    tick_data: dict,
    contract_info: dict | None = None,
) -> list:
    """
    Processes live tick for Opening Range R2/R3/S2/S3 touch detection.

    Behavior:
    - Updates latest LTP for every instrument.
    - Updates main index LTP when instrument is main index.
    - Detects option touch events against cached Opening Range levels.
    - Queues touch events.
    - Attempts isolated instrument selection if touch events are found.
    """

    if not DEFAULT_LIVE_TOUCH_ALERT_ENABLED:
        return []

    if not instrument_key or not isinstance(tick_data, dict):
        return []

    feed_values = extract_feed_values(tick_data)

    ltp = safe_float(feed_values.get("ltp"))
    updated_at = feed_values.get("timestamp")

    update_latest_ltp_for_instrument(
        instrument_key=instrument_key,
        ltp=ltp,
        updated_at=updated_at,
    )

    if instrument_key == DEFAULT_MAIN_INDEX_KEY and ltp > 0:
        update_latest_main_index_ltp(
            ltp=ltp,
            source="live_tick",
            updated_at=updated_at,
        )
        return []

    if not contract_info:
        contract_info = get_contract_info_by_key(instrument_key)

    if DEFAULT_TOUCH_ALERT_OPTIONS_ONLY and not is_option_contract(contract_info):
        return []

    with _opening_range_cache_lock:
        item = deepcopy(opening_range_cache.get("data", {}).get(instrument_key))

    if not item or item.get("status") != "success":
        return []

    levels = item.get("levels") or {}

    if not levels:
        return []

    pseudo_candle = {
        "timestamp": feed_values.get("timestamp") or get_now_market_time().isoformat(),
        "open": 0.0,
        "high": feed_values.get("high"),
        "low": feed_values.get("low"),
        "close": feed_values.get("close") or feed_values.get("ltp"),
        "volume": 0,
        "oi": 0,
    }

    if DEFAULT_TOUCH_CHECK_MODE == "ltp":
        ltp_value = safe_float(feed_values.get("ltp"))

        pseudo_candle["high"] = ltp_value
        pseudo_candle["low"] = ltp_value
        pseudo_candle["close"] = ltp_value

    events = detect_touch_from_candle(
        instrument_key=instrument_key,
        candle=pseudo_candle,
        levels=levels,
        contract_info=contract_info,
        source="live_tick",
    )

    for event in events:
        if DEFAULT_TOUCH_ALERT_ONCE_PER_LEVEL:
            mark_touch_alert_sent(event)

        update_touch_status_in_cache(instrument_key, event)
        queue_touch_event(event)

    if events:
        from .isolation import try_isolate_from_touch_events

        try_isolate_from_touch_events(events)

    return events
