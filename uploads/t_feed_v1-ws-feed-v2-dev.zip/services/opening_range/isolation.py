from copy import deepcopy

from core import config
from core.logger import get_logger
from services.telegram_service import telegram_service

from .config import (
    DEFAULT_ISOLATION_ALLOW_BACKFILL_TOUCH,
    DEFAULT_ISOLATION_ALLOW_LIVE_TOUCH,
    DEFAULT_ISOLATION_ALLOW_PRIORITY_UPGRADE,
    DEFAULT_ISOLATION_ENABLED,
    DEFAULT_ISOLATION_LOCK_FOR_DAY,
    DEFAULT_ISOLATION_OPTIONS_ONLY,
    DEFAULT_ISOLATION_PRIORITY_LEVELS,
    DEFAULT_ISOLATION_TOUCH_LEVELS,
    DEFAULT_ISOLATION_WINDOW_POINTS,
    DEFAULT_MAIN_INDEX_KEY,
)
from .state import (
    _opening_range_cache_lock,
    _selected_or_instrument_state,
    _selected_or_lock,
    get_latest_ltp_for_instrument,
    get_latest_main_index_ltp,
    opening_range_cache,
)
from .utils import (
    get_contract_info_by_key,
    get_live_ema_calculation_mode_text,
    get_now_market_time,
    is_option_contract,
    safe_float,
)

logger = get_logger(__file__)


# ============================================================
# Config Helpers
# ============================================================


def is_isolated_instrument_notification_enabled() -> bool:
    """
    Returns whether Telegram notification for isolated instrument is enabled.

    Reads dynamically from config so runtime config updates are reflected.
    """

    return bool(
        getattr(
            config,
            "OPENING_RANGE_ISOLATED_INSTRUMENT_NOTIFY_ENABLED",
            True,
        )
    )


def is_live_ema_calculation_mode_enabled() -> bool:
    """
    Returns current LIVE_EMA_CALCULATION_MODE flag dynamically.
    """

    return bool(getattr(config, "LIVE_EMA_CALCULATION_MODE", False))


# ============================================================
# Priority / Reference Helpers
# ============================================================


def get_level_priority(level: str) -> int:
    """
    Returns priority rank for touched level.

    Lower value means higher priority.

    Example:
        R3/S3 before R2/S2
    """

    level_upper = str(level or "").upper()

    try:
        return DEFAULT_ISOLATION_PRIORITY_LEVELS.index(level_upper)

    except ValueError:
        return 999


def get_reference_opening_range_average() -> float | None:
    """
    Returns reference Opening Range average used for instrument isolation.

    Preference:
        1. Main index Opening Range average
        2. Latest main index LTP
    """

    with _opening_range_cache_lock:
        main_item = opening_range_cache.get("data", {}).get(
            DEFAULT_MAIN_INDEX_KEY
        )

        if main_item:
            range_payload = main_item.get("range") or {}
            average_value = range_payload.get("average")

            if average_value is not None:
                return safe_float(average_value)

        latest_ltp = opening_range_cache.get("latest_main_index_ltp")

    if latest_ltp is not None:
        return safe_float(latest_ltp)

    return get_latest_main_index_ltp()


def build_average_window(reference_average: float) -> dict:
    """
    Builds Opening Range average +/- window.

    The window is clamped inside globally configured STRIKE_FROM and STRIKE_TO.
    """

    strike_from = safe_float(getattr(config, "STRIKE_FROM", 0.0))
    strike_to = safe_float(getattr(config, "STRIKE_TO", 999999.0))

    raw_lower = reference_average - DEFAULT_ISOLATION_WINDOW_POINTS
    raw_upper = reference_average + DEFAULT_ISOLATION_WINDOW_POINTS

    final_lower = max(strike_from, raw_lower)
    final_upper = min(strike_to, raw_upper)

    return {
        "reference_average": reference_average,
        "window_points": DEFAULT_ISOLATION_WINDOW_POINTS,
        "raw_lower": raw_lower,
        "raw_upper": raw_upper,
        "configured_from": strike_from,
        "configured_to": strike_to,
        "final_lower": final_lower,
        "final_upper": final_upper,
    }


# ============================================================
# Eligibility / Selection Helpers
# ============================================================


def is_event_eligible_for_isolation(event: dict) -> tuple[bool, str]:
    """
    Checks whether a touch event can be used for isolated instrument selection.
    """

    if not DEFAULT_ISOLATION_ENABLED:
        return False, "isolation_disabled"

    if not isinstance(event, dict):
        return False, "invalid_event"

    level = str(event.get("level", "")).upper()

    if level not in DEFAULT_ISOLATION_TOUCH_LEVELS:
        return False, "level_not_eligible"

    source = str(event.get("source", ""))

    if (
        source == "intraday_backfill_scan"
        and not DEFAULT_ISOLATION_ALLOW_BACKFILL_TOUCH
    ):
        return False, "backfill_selection_disabled"

    if source == "live_tick" and not DEFAULT_ISOLATION_ALLOW_LIVE_TOUCH:
        return False, "live_selection_disabled"

    contract_info = event.get("contract_info") or {}

    if DEFAULT_ISOLATION_OPTIONS_ONLY and not is_option_contract(contract_info):
        return False, "not_option_contract"

    strike = contract_info.get("strike_price")

    if strike is None:
        return False, "missing_strike"

    reference_average = get_reference_opening_range_average()

    if reference_average is None or reference_average <= 0:
        return False, "reference_average_not_available"

    window = build_average_window(reference_average)
    strike_value = safe_float(strike)

    if not (window["final_lower"] <= strike_value <= window["final_upper"]):
        return False, "strike_outside_average_window"

    return True, "eligible"


def choose_best_isolation_event(events: list) -> dict | None:
    """
    Chooses the best isolation event using:

    1. Level priority:
       R3/S3 before R2/S2

    2. Nearest strike to Opening Range average
    """

    if not events:
        return None

    reference_average = get_reference_opening_range_average()

    if reference_average is None or reference_average <= 0:
        return None

    eligible_events = []

    for event in events:
        eligible, _reason = is_event_eligible_for_isolation(event)

        if not eligible:
            continue

        contract_info = event.get("contract_info") or {}
        strike = safe_float(contract_info.get("strike_price"))
        level = str(event.get("level", "")).upper()

        eligible_events.append(
            {
                "event": event,
                "priority": get_level_priority(level),
                "distance_to_average": abs(strike - reference_average),
                "strike": strike,
            }
        )

    if not eligible_events:
        return None

    selected = min(
        eligible_events,
        key=lambda item: (
            item["priority"],
            item["distance_to_average"],
            item["strike"],
        ),
    )

    return selected["event"]


def should_replace_isolated_instrument(new_event: dict) -> bool:
    """
    Determines whether new event can replace current isolated instrument.

    Default behavior:
        - If nothing selected, select.
        - If lock-for-day is disabled, allow replacement.
        - If lock-for-day is enabled, allow only priority upgrade when configured.
    """

    with _selected_or_lock:
        already_selected = bool(_selected_or_instrument_state.get("selected"))
        current_priority = _selected_or_instrument_state.get(
            "selection_priority"
        )

    if not already_selected:
        return True

    if not DEFAULT_ISOLATION_LOCK_FOR_DAY:
        return True

    if not DEFAULT_ISOLATION_ALLOW_PRIORITY_UPGRADE:
        return False

    new_priority = get_level_priority(new_event.get("level"))

    if current_priority is None:
        return False

    return new_priority < int(current_priority)


# ============================================================
# Telegram Notification
# ============================================================


def send_isolated_instrument_notification(state: dict) -> bool:
    """
    Sends Telegram notification when an instrument is isolated.
    """

    if not is_isolated_instrument_notification_enabled():
        return False

    try:
        return telegram_service.send_isolated_instrument_message(state)

    except Exception as ex:
        logger.error(
            "Failed sending isolated instrument Telegram notification: "
            f"{type(ex).__name__}: {ex}"
        )
        return False


# ============================================================
# Isolation State Update
# ============================================================


def isolate_instrument_from_event(event: dict) -> bool:
    """
    Isolates one instrument from a touch event.

    Selection rule:
        - R3/S3 priority before R2/S2
        - Nearest strike to Opening Range average
        - Lock selected instrument for the day unless priority upgrade is allowed
    """

    if not event:
        return False

    eligible, reason = is_event_eligible_for_isolation(event)

    if not eligible:
        logger.info(
            "Isolation skipped. "
            f"reason={reason}, "
            f"instrument_key={event.get('instrument_key')}, "
            f"level={event.get('level')}"
        )
        return False

    if not should_replace_isolated_instrument(event):
        return False

    instrument_key = event.get("instrument_key")

    contract_info = event.get("contract_info") or get_contract_info_by_key(
        instrument_key
    )

    reference_average = get_reference_opening_range_average()

    average_window = (
        build_average_window(reference_average)
        if reference_average
        else None
    )

    with _opening_range_cache_lock:
        item = deepcopy(
            opening_range_cache.get("data", {}).get(instrument_key, {})
        )

    state = {
        "selected": True,
        "instrument_key": instrument_key,
        "selected_level": str(event.get("level", "")).upper(),
        "level_value": event.get("level_value"),
        "trigger_price": event.get("trigger_price"),
        "trigger_field": event.get("trigger_field"),
        "touch_time": event.get("touch_time"),
        "touch_source": event.get("source"),
        "selected_at": get_now_market_time().isoformat(),
        "selection_priority": get_level_priority(event.get("level")),
        "selection_reason": "level_priority_nearest_to_opening_range_average",
        "reference_average": reference_average,
        "average_window": average_window,
        "contract_info": contract_info,
        "range": item.get("range"),
        "levels": item.get("levels"),
        "latest_live_data": {
            "ltp": get_latest_ltp_for_instrument(instrument_key),
        },
        "latest_main_index_ltp": get_latest_main_index_ltp(),
        "live_ema_calculation_mode_flag": (
            is_live_ema_calculation_mode_enabled()
        ),
        "live_ema_calculation_mode": get_live_ema_calculation_mode_text(),
        "ema_alerts_count": 0,
        "last_ema_alert": None,
        "disabled": False,
        "message": "Opening Range instrument isolated for EMA Telegram alerts.",
    }

    with _selected_or_lock:
        previous_alert_count = _selected_or_instrument_state.get(
            "ema_alerts_count",
            0,
        )

        state["ema_alerts_count"] = previous_alert_count

        _selected_or_instrument_state.clear()
        _selected_or_instrument_state.update(state)

        selected_state_snapshot = dict(_selected_or_instrument_state)

    with _opening_range_cache_lock:
        opening_range_cache["isolated_instrument"] = selected_state_snapshot
        opening_range_cache["isolated_instrument_selected"] = True
        opening_range_cache["isolated_instrument_selected_at"] = state.get(
            "selected_at"
        )
        opening_range_cache["isolated_instrument_selection_reason"] = (
            state.get("selection_reason")
        )

    logger.info(
        "Opening Range isolated instrument selected. "
        f"instrument_key={instrument_key}, "
        f"level={state.get('selected_level')}, "
        f"strike={contract_info.get('strike_price')}, "
        f"type={contract_info.get('instrument_type')}, "
        f"reference_average={reference_average}"
    )

    send_isolated_instrument_notification(selected_state_snapshot)

    return True


def try_isolate_from_touch_events(events: list) -> bool:
    """
    Chooses best event from a list and isolates instrument if applicable.
    """

    best_event = choose_best_isolation_event(events)

    if not best_event:
        return False

    return isolate_instrument_from_event(best_event)