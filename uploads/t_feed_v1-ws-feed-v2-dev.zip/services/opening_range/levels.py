from .utils import safe_float


def calculate_opening_range_levels(selected_candles: list) -> dict:
    if not selected_candles:
        return {"status": "empty", "message": "No opening range candles selected.", "range": None, "levels": None}

    range_open = safe_float(selected_candles[0].get("open"))
    range_close = safe_float(selected_candles[-1].get("close"))
    range_high = max(safe_float(item.get("high")) for item in selected_candles)
    range_low = min(safe_float(item.get("low")) for item in selected_candles)
    range_avg = (range_high + range_low) / 2
    high_avg_diff = abs(range_high - range_avg)
    low_avg_diff = abs(range_avg - range_low)
    sub_resistance = range_avg + (high_avg_diff / 2)
    sub_support = range_avg - (low_avg_diff / 2)
    resistance2 = range_high + high_avg_diff
    support2 = range_low - low_avg_diff
    resistance3 = resistance2 + high_avg_diff
    support3 = support2 - low_avg_diff
    r3_threshold = (resistance2 + resistance3) / 2
    s3_threshold = (support2 + support3) / 2
    return {
        "status": "success",
        "message": "Opening range levels calculated successfully.",
        "range": {
            "open": round(range_open, 4),
            "high": round(range_high, 4),
            "low": round(range_low, 4),
            "close": round(range_close, 4),
            "average": round(range_avg, 4),
            "selected_candles_count": len(selected_candles),
            "first_candle_time": selected_candles[0].get("timestamp"),
            "last_candle_time": selected_candles[-1].get("timestamp"),
        },
        "levels": {
            "r1": round(sub_resistance, 4),
            "s1": round(sub_support, 4),
            "r2": round(resistance2, 4),
            "s2": round(support2, 4),
            "r3": round(resistance3, 4),
            "s3": round(support3, 4),
            "sub_resistance": round(sub_resistance, 4),
            "sub_support": round(sub_support, 4),
            "resistance2": round(resistance2, 4),
            "support2": round(support2, 4),
            "resistance3": round(resistance3, 4),
            "support3": round(support3, 4),
            "r3_threshold": round(r3_threshold, 4),
            "s3_threshold": round(s3_threshold, 4),
        },
    }
