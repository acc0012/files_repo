from core import config

from services.option_service import (
    get_nearest_order_instruments_for_isolated_ema_cross,
    resolve_ema_order_side_summary,
)
from services.telegram_service import telegram_service

from .state import (
    _opening_range_cache_lock,
    _selected_or_ema_alerts,
    _selected_or_instrument_state,
    _selected_or_lock,
    get_latest_ltp_for_instrument,
    get_latest_main_index_ltp,
    opening_range_cache,
)
from .utils import (
    get_live_ema_calculation_mode_text,
    get_now_market_time,
)

# ============================================================
# Config Helpers
# ============================================================


def is_isolated_ema_telegram_enabled() -> bool:
    """
    Returns whether isolated instrument EMA Telegram alert flow is enabled.

    Reads from config dynamically so runtime config updates are reflected.
    """

    return bool(
        getattr(
            config,
            "EMA_ISOLATED_INSTRUMENT_TELEGRAM_ENABLED",
            True,
        )
    )


def get_ema_mode_description(ema_calculation_mode: str) -> str:
    """
    Returns readable EMA calculation mode description.
    """

    if ema_calculation_mode == "tick_ltp":
        return "Live tick/LTP based EMA cross detection"

    return "Completed candle close based EMA cross detection"


# ============================================================
# Suggested Order Instrument Helpers
# ============================================================


def get_suggested_order_instruments_for_ema(
    cross_type: str,
    selected_state: dict | None = None,
) -> list:
    """
    Returns nearest CE/PE order instruments around current NIFTY LTP.

    Isolated-side logic is handled by option_service:

        Isolated PE + bullish_cross -> PE
        Isolated PE + bearish_cross -> CE
        Isolated CE + bullish_cross -> CE
        Isolated CE + bearish_cross -> PE
    """

    nifty_ltp = get_latest_main_index_ltp()

    if not nifty_ltp or nifty_ltp <= 0:
        return []

    selected_state = selected_state or {}
    contract_info = selected_state.get("contract_info") or {}

    isolated_instrument_type = contract_info.get("instrument_type")

    instruments = get_nearest_order_instruments_for_isolated_ema_cross(
        current_nifty_ltp=nifty_ltp,
        cross_type=cross_type,
        isolated_instrument_type=isolated_instrument_type,
    )

    output = []

    for item in instruments:
        instrument_key = item.get("instrument_key")
        live_ltp = get_latest_ltp_for_instrument(instrument_key)

        output.append(
            {
                **item,
                "live_ltp": live_ltp,
            }
        )

    return output


def format_suggested_order_instruments(instruments: list) -> str:
    """
    Formats suggested instruments for debug/internal display.

    Final Telegram formatting is handled in telegram_service.py.
    """

    if not instruments:
        return "Nearest Instrument Details:\n- not_available"

    lines = ["Nearest Instrument Details:"]

    for item in instruments:
        strike = item.get("strike_price", "N/A")
        option_type = str(item.get("instrument_type", "N/A")).upper()
        live_ltp = item.get("live_ltp")

        if live_ltp is None:
            price_text = "ltp_not_available"
        else:
            price_text = f"{live_ltp}rs"

        lines.append(f"- {strike}{option_type} - {price_text}")

    return "\n".join(lines)


# ============================================================
# Isolated EMA Telegram Alert Processor
# ============================================================


def process_selected_or_ema_cross_alert(ema_event: dict) -> bool:
    """
    Sends Telegram EMA alert only for the isolated Opening Range instrument.

    Rules:
    - EMA runs for all instruments.
    - WebSocket EMA events can broadcast for all instruments.
    - Telegram EMA alert is sent only if EMA event instrument matches
      the currently isolated Opening Range instrument.
    - Entry side is resolved using isolated option side logic.
    """

    if not is_isolated_ema_telegram_enabled():
        return False

    if not isinstance(ema_event, dict):
        return False

    with _selected_or_lock:
        selected_state = dict(_selected_or_instrument_state)

    if not selected_state.get("selected"):
        return False

    isolated_key = selected_state.get("instrument_key")
    event_key = ema_event.get("instrument_key")

    if not isolated_key or isolated_key != event_key:
        return False

    contract_info = selected_state.get("contract_info") or {}
    selected_level = selected_state.get("selected_level", "N/A")

    nifty_ltp = get_latest_main_index_ltp()
    cross_type = ema_event.get("cross_type", "N/A")

    ema_calculation_mode = ema_event.get(
        "ema_calculation_mode",
        get_live_ema_calculation_mode_text(),
    )

    mode_description = get_ema_mode_description(ema_calculation_mode)

    suggested_instruments = get_suggested_order_instruments_for_ema(
        cross_type=cross_type,
        selected_state=selected_state,
    )

    entry_side_summary = resolve_ema_order_side_summary(
        current_nifty_ltp=nifty_ltp or 0,
        cross_type=cross_type,
        isolated_instrument_type=contract_info.get("instrument_type"),
    )

    alert_record = {
        "type": "isolated_instrument_ema_alert",
        "instrument_key": event_key,
        "contract_info": contract_info,
        "selected_level": selected_level,
        "nifty_ltp": nifty_ltp,
        "ema_calculation_mode": ema_calculation_mode,
        "ema_mode_description": mode_description,
        "ema_event": dict(ema_event),
        "entry_side_summary": entry_side_summary,
        "suggested_order_instruments": suggested_instruments,
        "created_at": get_now_market_time().isoformat(),
    }

    sent = telegram_service.send_isolated_ema_cross_message(
        isolated_state=selected_state,
        ema_event=ema_event,
        nifty_ltp=nifty_ltp,
        suggested_order_instruments=suggested_instruments,
    )

    if not sent:
        return False

    with _selected_or_lock:
        _selected_or_ema_alerts.append(alert_record)

        current_count = int(_selected_or_instrument_state.get("ema_alerts_count", 0))

        _selected_or_instrument_state["ema_alerts_count"] = current_count + 1
        _selected_or_instrument_state["last_ema_alert"] = alert_record

        updated_selected_state = dict(_selected_or_instrument_state)
        isolated_ema_alerts_count = len(_selected_or_ema_alerts)

    with _opening_range_cache_lock:
        opening_range_cache["isolated_ema_alerts_count"] = isolated_ema_alerts_count
        opening_range_cache["isolated_instrument"] = updated_selected_state

    return True
