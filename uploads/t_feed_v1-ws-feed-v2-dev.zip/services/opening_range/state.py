from collections import deque
from threading import Lock
from core import config

_opening_range_cache_lock = Lock()
_touch_lock = Lock()
_selected_or_lock = Lock()

opening_range_cache = {
    "last_run_at": None,
    "date": None,
    "status": "not_started",
    "message": "Opening range calculation has not run yet.",
    "source": "intraday_api",
    "interval": None,
    "opening_range_candle_count": 0,
    "market_open_time": None,
    "fetch_time": None,
    "total_instruments": 0,
    "success_count": 0,
    "failed_count": 0,
    "empty_count": 0,
    "insufficient_data_count": 0,
    "output_file_path": None,
    "latest_main_index_ltp": None,
    "latest_main_index_ltp_source": None,
    "latest_main_index_ltp_updated_at": None,
    "touch_events_count": 0,
    "pending_touch_events_count": 0,
    "alert_sent_keys_count": 0,
    "isolated_instrument": None,
    "isolated_instrument_selected": False,
    "isolated_instrument_selected_at": None,
    "isolated_instrument_selection_reason": None,
    "isolated_ema_alerts_count": 0,
    "data": {},
    "touch_events": [],
    "errors": {},
}

_pending_touch_events = deque()
_touch_events = deque(maxlen=int(getattr(config, "OPENING_RANGE_MAX_EVENTS_IN_MEMORY", 5000)))
_alert_sent_keys = set()
_last_touch_alert_sent_at = None

_latest_main_index_ltp = None
_latest_main_index_ltp_source = None
_latest_main_index_ltp_updated_at = None
_latest_ltp_by_instrument = {}
_latest_ltp_updated_at_by_instrument = {}

_selected_or_instrument_state = {
    "selected": False,
    "instrument_key": None,
    "selected_level": None,
    "level_value": None,
    "trigger_price": None,
    "trigger_field": None,
    "touch_time": None,
    "touch_source": None,
    "selected_at": None,
    "selection_priority": None,
    "selection_reason": None,
    "reference_average": None,
    "average_window": None,
    "contract_info": None,
    "range": None,
    "levels": None,
    "latest_live_data": None,
    "latest_main_index_ltp": None,
    "ema_alerts_count": 0,
    "last_ema_alert": None,
    "disabled": False,
    "message": "No isolated Opening Range instrument selected yet.",
}

_selected_or_ema_alerts = deque(maxlen=int(getattr(config, "OPENING_RANGE_MAX_EVENTS_IN_MEMORY", 5000)))


def update_latest_ltp_for_instrument(instrument_key: str, ltp, updated_at: str | None = None):
    from .utils import safe_float, get_now_market_time
    if not instrument_key:
        return
    value = safe_float(ltp)
    if value <= 0:
        return
    updated_at = updated_at or get_now_market_time().isoformat()
    with _touch_lock:
        _latest_ltp_by_instrument[instrument_key] = value
        _latest_ltp_updated_at_by_instrument[instrument_key] = updated_at


def get_latest_ltp_for_instrument(instrument_key: str) -> float | None:
    if not instrument_key:
        return None
    with _touch_lock:
        return _latest_ltp_by_instrument.get(instrument_key)


def update_latest_main_index_ltp(ltp, source: str = "unknown", updated_at: str | None = None):
    from .utils import safe_float, get_now_market_time
    global _latest_main_index_ltp, _latest_main_index_ltp_source, _latest_main_index_ltp_updated_at
    value = safe_float(ltp, default=0.0)
    if value <= 0:
        return
    updated_at = updated_at or get_now_market_time().isoformat()
    with _touch_lock:
        _latest_main_index_ltp = value
        _latest_main_index_ltp_source = source
        _latest_main_index_ltp_updated_at = updated_at
    with _opening_range_cache_lock:
        opening_range_cache["latest_main_index_ltp"] = value
        opening_range_cache["latest_main_index_ltp_source"] = source
        opening_range_cache["latest_main_index_ltp_updated_at"] = updated_at


def get_latest_main_index_ltp() -> float | None:
    with _touch_lock:
        return _latest_main_index_ltp
