import os
from django.core.asgi import get_asgi_application
from channels.routing import ProtocolTypeRouter, URLRouter
import feeds.routing

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'trading_project.settings')

application = ProtocolTypeRouter({
    "http": get_asgi_application(),
    "websocket": URLRouter(
        feeds.routing.websocket_urlpatterns
    ),
})