
# Create your views here.
import json
from django.http import JsonResponse
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync

def feed_webhook(request):
    payload = json.loads(request.body)

    security_id = payload.get("security_id")
    feed_type = payload.get("type", "quote").lower()

    group_name = f"feed_{feed_type}_{security_id}"

    channel_layer = get_channel_layer()

    async_to_sync(channel_layer.group_send)(
        group_name,
        {
            "type": "feed.message",
            "data": payload
        }
    )

    return JsonResponse({"status": "ok"})