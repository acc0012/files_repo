import json
from channels.generic.websocket import AsyncWebsocketConsumer

class FeedConsumer(AsyncWebsocketConsumer):

    async def connect(self):
        # get values from URL
        self.security_id = self.scope['url_route']['kwargs']['security_id']
        self.feed_type = self.scope['url_route']['kwargs']['feed_type']

        # unique group per feed
        self.group_name = f"feed_{self.feed_type}_{self.security_id}"

        # join group
        await self.channel_layer.group_add(
            self.group_name,
            self.channel_name
        )

        await self.accept()

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard(
            self.group_name,
            self.channel_name
        )

    # message sender
    async def feed_message(self, event):
        await self.send(text_data=json.dumps(event["data"]))