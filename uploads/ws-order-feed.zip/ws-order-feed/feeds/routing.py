from django.urls import re_path
from .consumers import FeedConsumer

websocket_urlpatterns = [
    re_path(
        r'ws/(?P<security_id>\d+)/(?P<feed_type>\w+)/$',
        FeedConsumer.as_asgi()
    ),
]