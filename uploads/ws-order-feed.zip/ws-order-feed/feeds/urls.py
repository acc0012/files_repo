from django.urls import path
from .views import feed_webhook

urlpatterns = [
    path("webhook_feed/", feed_webhook),
]