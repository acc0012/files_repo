import json
import asyncio

from channels.generic.websocket import AsyncWebsocketConsumer

from apps.dhan_services.services.option_chain import get_option_chain_data
from core.logger import get_logger

# =====================================================
# LOGGER
# =====================================================

logger = get_logger("option_chain_ws")

# =====================================================
# CONSTANTS
# =====================================================

DEFAULT_INDEX = 13  # ✅ NIFTY
DEFAULT_SEGMENT = "IDX_I"
POLL_INTERVAL = 3  # seconds


# =====================================================
# CONSUMER
# =====================================================

class OptionChainConsumer(AsyncWebsocketConsumer):

    # =================================================
    # CONNECT
    # =================================================
    async def connect(self):

        try:
            # ✅ Extract params
            self.index = self.scope["url_route"]["kwargs"].get("index")
            self.expiry = self.scope["url_route"]["kwargs"].get("expiry")

            # ✅ Default fallback
            self.index = int(self.index) if self.index else DEFAULT_INDEX

            self.running = True

            await self.accept()

            logger.info(
                f"🧠 WS Connected | index={self.index} | expiry={self.expiry}"
            )

            # ✅ Start background task
            asyncio.create_task(self.stream_data())

        except Exception as e:
            logger.exception(f"❌ WS CONNECT FAILED: {e}")
            await self.safe_close()

    # =================================================
    # DISCONNECT
    # =================================================
    async def disconnect(self, close_code):

        try:
            self.running = False

            logger.info(
                f"🔌 WS Disconnected | index={getattr(self, 'index', 'NA')} "
                f"| code={close_code}"
            )

        except Exception as e:
            logger.exception(f"❌ DISCONNECT ERROR: {e}")

    # =================================================
    # STREAM LOOP
    # =================================================
    async def stream_data(self):

        logger.info("📡 Option Chain Streaming Started")

        while getattr(self, "running", False):

            try:
                data = await self.fetch_option_chain()

                response = {
                    "status": "success",
                    "data": data,
                }

                await self.safe_send(response)

            except Exception as e:

                logger.exception(f"❌ STREAM ERROR: {e}")

                error_response = {
                    "status": "error",
                    "message": str(e),
                }

                await self.safe_send(error_response)

            # ✅ Prevent API flooding
            await asyncio.sleep(POLL_INTERVAL)

        logger.info("🛑 Option Chain Streaming Stopped")

    # =================================================
    # FETCH DATA (ASYNC SAFE)
    # =================================================
    async def fetch_option_chain(self):

        try:
            loop = asyncio.get_running_loop()

            result = await loop.run_in_executor(
                None,
                self._sync_fetch
            )

            return result

        except Exception as e:
            logger.exception(f"❌ FETCH FAILED: {e}")
            raise

    # =================================================
    # SYNC FETCH (DHAN CALL)
    # =================================================
    def _sync_fetch(self):

        try:
            # logger.info(f"📊 Fetch Option Chain | index={self.index}")

            data = get_option_chain_data(
                under_security_id=self.index,
                under_exchange_segment=DEFAULT_SEGMENT,
            )

            if not isinstance(data, dict):
                raise ValueError("Invalid option chain response")

            # ✅ Optional expiry check
            if self.expiry:
                if data.get("expiry") != self.expiry:
                    logger.warning(
                        f"⚠️ Expiry mismatch | requested={self.expiry} "
                        f"| actual={data.get('expiry')}"
                    )

            logger.debug("✅ Option chain fetched successfully")

            return data

        except Exception as e:
            logger.exception(f"❌ SYNC FETCH FAILED: {e}")
            raise

    # =================================================
    # SAFE SEND
    # =================================================
    async def safe_send(self, data):

        try:
            await self.send(
                text_data=json.dumps(data, default=str)
            )

        except Exception as e:

            error_str = str(e)
            error_type = type(e).__name__

            ignored_errors = [
                "ConnectionClosed",
                "ConnectionClosedOK",
                "ClientDisconnected",
            ]

            if (
                any(err in error_str for err in ignored_errors)
                or error_type in ignored_errors
            ):
                logger.info("🔌 WS closed normally during send")
                self.running = False
                return

            logger.exception(f"❌ SEND FAILED: {e}")

    # =================================================
    # SAFE CLOSE
    # =================================================
    async def safe_close(self):

        try:
            await self.close()

        except Exception as e:
            logger.exception(f"❌ CLOSE FAILED: {e}")
