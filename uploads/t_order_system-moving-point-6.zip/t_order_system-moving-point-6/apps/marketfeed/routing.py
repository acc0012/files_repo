from django.urls import re_path

from .consumers import MarketFeedConsumer
from .mock_consumer import MockMarketConsumer

# ✅ NEW IMPORT
from .option_chain_consumer import OptionChainConsumer


# =====================================================
# WEBSOCKET ROUTES
# =====================================================

websocket_urlpatterns = [

    # =================================================
    # ✅ MARKET FEED (EXISTING)
    # =================================================

    # ✅ ALL instruments (Dashboard - single WS)
    re_path(
        r"ws/market/$",
        MarketFeedConsumer.as_asgi(),
    ),

    # ✅ SINGLE instrument (API / external use)
    re_path(
        r"ws/market/(?P<security_id>\w+)/$",
        MarketFeedConsumer.as_asgi(),
    ),

    # ✅ MOCK FEED
    re_path(
        r"ws/mock/$",
        MockMarketConsumer.as_asgi()
    ),

    # =================================================
    # ✅ OPTION CHAIN (NEW)
    # =================================================

    # ✅ Default → nearest expiry (NIFTY)
    re_path(
        r"ws/option-chain/$",
        OptionChainConsumer.as_asgi(),
    ),

    # ✅ Index only (NIFTY / BANKNIFTY etc.)
    re_path(
        r"ws/option-chain/(?P<index>\d+)/$",
        OptionChainConsumer.as_asgi(),
    ),

    # ✅ Index + expiry
    re_path(
        r"ws/option-chain/(?P<index>\d+)/(?P<expiry>[\d\-]+)/$",
        OptionChainConsumer.as_asgi(),
    ),
]