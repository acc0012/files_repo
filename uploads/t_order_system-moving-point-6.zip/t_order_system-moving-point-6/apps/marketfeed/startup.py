import threading
import time
import datetime
import random

# ✅ IMPORTANT: Use singleton service from views
from apps.marketfeed.views import (
    get_feed_service,
    on_message,
)

from core.subscription_store import load_subscriptions
from core.logger import get_logger
from django.conf import settings

# ✅ ✅ IMPORT MARKET TIME CHECK
from apps.marketfeed.services import is_market_open

logger = get_logger("startup")


# =====================================================
# ✅ EXPIRY SCHEDULER
# =====================================================

def schedule_expiry_jobs():

    def runner():

        last_run_tag = None  # ✅ prevent duplicate runs

        while True:
            now = datetime.datetime.now()

            try:
                service = get_feed_service()

                current_tag = f"{now.date()}-{now.hour}-{now.minute}"

                # ✅ BEFORE MARKET
                if now.hour == 8 and now.minute >= 50:
                    if last_run_tag != f"pre-{current_tag}":
                        logger.info("⏰ Pre-market expiry cleanup")
                        service.cleanup_expired_subscriptions()
                        last_run_tag = f"pre-{current_tag}"

                # ✅ AFTER MARKET
                elif now.hour == 15 and now.minute >= 35:
                    if last_run_tag != f"post-{current_tag}":
                        logger.info("⏰ Post-market expiry cleanup")
                        service.cleanup_expired_subscriptions()
                        last_run_tag = f"post-{current_tag}"

            except Exception as e:
                logger.exception(f"❌ Scheduler error: {e}")

            time.sleep(30)

    threading.Thread(target=runner, daemon=True).start()


# =====================================================
# ✅ AUTO START FEED ON BOOT (FINAL ENHANCED VERSION)
# =====================================================

def start_feed_on_boot():

    def runner():

        try:
            # ✅ ALWAYS START SCHEDULER
            schedule_expiry_jobs()

            # ✅ INITIAL DELAY (ANTI-429)
            base_delay = 10
            jitter = random.uniform(2, 5)
            total_delay = base_delay + jitter

            logger.warning(
                f"⏳ Startup delay → waiting {round(total_delay, 2)}s before connecting"
            )

            time.sleep(total_delay)

            # ✅ Get singleton service
            service = get_feed_service()

            # ✅ Prevent duplicate start
            if service.is_running:
                logger.warning("⚠️ Feed already running at startup")
                return

            # =====================================================
            # ✅ ✅ WAIT UNTIL MARKET OPENS (ENHANCED LOGGING)
            # =====================================================
            last_logged_minute = None

            while not is_market_open():

                now = datetime.datetime.now()

                # ✅ Avoid log spam (log once per minute)
                if last_logged_minute != now.minute:

                    # ✅ Market open time (today 9:15)
                    today_open = now.replace(hour=9, minute=15, second=0, microsecond=0)

                    next_open = today_open

                    # ✅ If current time already passed → move to next day
                    if now >= today_open:
                        next_open = today_open + datetime.timedelta(days=1)

                    # ✅ Skip weekends (Sat=5, Sun=6)
                    while next_open.weekday() >= 5:
                        next_open += datetime.timedelta(days=1)

                    # ✅ Calculate remaining time
                    delta = next_open - now

                    days = delta.days
                    hours = delta.seconds // 3600
                    minutes = (delta.seconds % 3600) // 60
                    seconds = delta.seconds % 60

                    logger.info(
                        f"🕒 Market closed | "
                        f"Now: {now.strftime('%Y-%m-%d %H:%M:%S')} | "
                        f"Next open: {next_open.strftime('%Y-%m-%d %H:%M:%S')} | "
                        f"Time left: {days}d {hours}h {minutes}m {seconds}s"
                    )

                    last_logged_minute = now.minute

                time.sleep(10)

            # =====================================================
            # ✅ MARKET OPENED
            # =====================================================
            logger.info("🟢 Market opened → starting feed...")

            # =====================================================
            # ✅ LOAD STORED SUBSCRIPTIONS
            # =====================================================
            # =====================================================
            # ✅ USE ONLY DEFAULT INSTRUMENTS ON STARTUP
            # =====================================================

            logger.info("📦 Loading default startup instruments")

            instruments = list(settings.DEFAULT_INSTRUMENTS)

            logger.info(
                f"🚀 Auto starting feed with {len(instruments)} instruments"
            )

            # ✅ START FEED
            service.start_feed(
                instruments=instruments,
                callbacks={"on_message": on_message},
            )

            logger.info("✅ Startup feed initialized successfully")

        except Exception as e:
            logger.exception(f"❌ Startup feed failed: {e}")

    # ✅ RUN IN BACKGROUND
    threading.Thread(target=runner, daemon=True).start()
