from django.urls import path

from .views import (
    intraday_data,
    daily_data,
    ohlc_data,
)

urlpatterns = [
    path(
        "intraday/",
        intraday_data,
        name="intraday_data",
    ),
    path(
        "daily/",
        daily_data,
        name="daily_data",
    ),
    path(
        "ohlc/",
        ohlc_data,
        name="ohlc_data",
    ),
]