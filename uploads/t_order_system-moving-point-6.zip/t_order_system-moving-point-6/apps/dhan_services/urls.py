from django.urls import path

from .views import (
    intraday_data,
    daily_data,
    ohlc_data,
)
from .views import option_chain_data
from .views import expiry_list_data

urlpatterns = [
    path(
        "intraday/",
        intraday_data,
        name="intraday_data",
    ),
    path(
        "daily/",
        daily_data,
        name="daily_data",
    ),
    path(
        "ohlc/",
        ohlc_data,
        name="ohlc_data",
    ),
    
path(
    "option-chain/",
    option_chain_data,
    name="option_chain_data",
),    

path(
    "expiry-list/",
    expiry_list_data,
    name="expiry_list_data",
),

]
