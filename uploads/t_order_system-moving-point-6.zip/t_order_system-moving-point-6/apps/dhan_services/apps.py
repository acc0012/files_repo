from django.apps import AppConfig


class DhanServicesConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.dhan_services"

    def ready(self):
        from .services.option_chain_worker import option_chain_worker
        import threading

        thread = threading.Thread(target=option_chain_worker, daemon=True)
        thread.start()
