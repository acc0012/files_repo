from django.apps import AppConfig


class DhanServicesConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.dhan_services"
