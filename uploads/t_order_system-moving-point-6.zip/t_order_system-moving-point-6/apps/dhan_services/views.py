from django.http import JsonResponse

from .services.historical import (
    get_intraday_data,
    get_daily_data,
)

from .services.ohlc import get_ohlc_data


def ohlc_data(request):

    try:

        security_id = request.GET.get("security_id")

        exchange_segment = request.GET.get("exchange_segment")

        data = get_ohlc_data(
            security_id=security_id,
            exchange_segment=exchange_segment,
        )

        return JsonResponse(
            {
                "status": "success",
                "data": data,
            }
        )

    except Exception as e:

        return JsonResponse(
            {
                "status": "error",
                "message": str(e),
            },
            status=500,
        )


def intraday_data(request):
    """
    Example:
    /dhan/intraday/?security_id=1333&exchange_segment=NSE_EQ&instrument_type=EQUITY&from_date=2026-06-01&to_date=2026-06-01
    """

    try:

        security_id = request.GET.get("security_id")
        exchange_segment = request.GET.get("exchange_segment")
        instrument_type = request.GET.get("instrument_type")
        from_date = request.GET.get("from_date")
        to_date = request.GET.get("to_date")

        missing = []

        if not security_id:
            missing.append("security_id")

        if not exchange_segment:
            missing.append("exchange_segment")

        if not instrument_type:
            missing.append("instrument_type")

        if not from_date:
            missing.append("from_date")

        if not to_date:
            missing.append("to_date")

        if missing:
            return JsonResponse(
                {
                    "status": "error",
                    "message": ("Missing required parameters: " + ", ".join(missing)),
                },
                status=400,
            )

        data = get_intraday_data(
            security_id=security_id,
            exchange_segment=exchange_segment,
            instrument_type=instrument_type,
            from_date=from_date,
            to_date=to_date,
        )

        return JsonResponse(
            {
                "status": "success",
                "data": data,
            },
            safe=False,
        )

    except Exception as e:

        return JsonResponse(
            {
                "status": "error",
                "message": str(e),
            },
            status=500,
        )


def daily_data(request):
    """
    Example:
    /dhan/daily/?security_id=1333&exchange_segment=NSE_EQ&instrument_type=EQUITY&from_date=2026-05-01&to_date=2026-06-01
    """

    try:

        security_id = request.GET.get("security_id")
        exchange_segment = request.GET.get("exchange_segment")
        instrument_type = request.GET.get("instrument_type")
        from_date = request.GET.get("from_date")
        to_date = request.GET.get("to_date")

        missing = []

        if not security_id:
            missing.append("security_id")

        if not exchange_segment:
            missing.append("exchange_segment")

        if not instrument_type:
            missing.append("instrument_type")

        if not from_date:
            missing.append("from_date")

        if not to_date:
            missing.append("to_date")

        if missing:
            return JsonResponse(
                {
                    "status": "error",
                    "message": ("Missing required parameters: " + ", ".join(missing)),
                },
                status=400,
            )

        data = get_daily_data(
            security_id=security_id,
            exchange_segment=exchange_segment,
            instrument_type=instrument_type,
            from_date=from_date,
            to_date=to_date,
        )

        return JsonResponse(
            {
                "status": "success",
                "data": data,
            },
            safe=False,
        )

    except Exception as e:

        return JsonResponse(
            {
                "status": "error",
                "message": str(e),
            },
            status=500,
        )
