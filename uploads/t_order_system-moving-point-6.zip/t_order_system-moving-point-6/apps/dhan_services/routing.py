# apps/dhan_services/routing.py

from django.urls import re_path
from .consumers import OptionChainConsumer

# =====================================================
# WEBSOCKET ROUTES
# =====================================================

websocket_urlpatterns = [

    # ✅ Dynamic option chain (multi-index support)
    re_path(
        r"ws/option-chain/(?P<security_id>\d+)/$",
        OptionChainConsumer.as_asgi(),
    ),

]