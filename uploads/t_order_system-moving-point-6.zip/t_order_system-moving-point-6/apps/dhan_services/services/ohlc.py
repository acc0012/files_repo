from .client import get_dhan_client

from core.logger import get_logger

logger = get_logger("dhan_ohlc")


def get_ohlc_data(
    security_id,
    exchange_segment,
):

    try:

        if not security_id:
            raise ValueError("security_id is required")

        if not exchange_segment:
            raise ValueError("exchange_segment is required")

        dhan = get_dhan_client()

        logger.info(
            f"📊 OHLC Request | "
            f"Security={security_id} | "
            f"Segment={exchange_segment}"
        )

        response = dhan.ohlc_data(securities={exchange_segment: [int(security_id)]})

        return response

    except Exception as e:

        logger.exception(f"❌ OHLC fetch failed: {e}")

        raise
