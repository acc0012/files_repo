from .client import get_dhan_client

from core.logger import get_logger

logger = get_logger("dhan_ohlc")


def get_ohlc_data(
    security_id,
    exchange_segment,
):

    try:

        if not security_id:
            raise ValueError("security_id is required")

        if not exchange_segment:
            raise ValueError("exchange_segment is required")

        logger.info(
            f"📊 OHLC Request | "
            f"Security={security_id} | "
            f"Segment={exchange_segment}"
        )

        # ==========================================
        # GET DHAN CLIENT
        # ==========================================

        dhan = get_dhan_client()

        logger.info(f"✅ Dhan Client Initialized | " f"Type={type(dhan)}")

        # ==========================================
        # BUILD REQUEST
        # ==========================================

        securities = {exchange_segment: [int(security_id)]}

        logger.info(f"📤 Sending OHLC Request => {securities}")

        # ==========================================
        # CALL DHAN
        # ==========================================

        response = dhan.ohlc_data(securities=securities)

        logger.info(f"📥 Raw OHLC Response => {response}")

        # ==========================================
        # VALIDATION
        # ==========================================

        if not isinstance(response, dict):

            logger.error(f"❌ Unexpected Response Type => " f"{type(response)}")

            return {
                "status": "failure",
                "remarks": {
                    "error_message": (f"Unexpected response type: " f"{type(response)}")
                },
                "data": "",
            }

        logger.info(f"📊 Response Status => " f"{response.get('status')}")

        logger.info(f"📊 Response Remarks => " f"{response.get('remarks')}")

        return response

    except Exception as e:

        logger.exception(
            f"❌ OHLC fetch failed | "
            f"Security={security_id} | "
            f"Segment={exchange_segment} | "
            f"Error={str(e)}"
        )

        raise
