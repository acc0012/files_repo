# apps/dhan_services/services/option_chain_worker.py

import time

from .option_chain import get_option_chain_data
from core.logger import get_logger
from apps.marketfeed.services import is_market_open

logger = get_logger("option_chain_worker")

# =====================================================
# SINGLETON FLAG
# =====================================================

is_running = False


# =====================================================
# WORKER
# =====================================================

def option_chain_worker():
    global is_running

    # ✅ Prevent multiple workers
    if is_running:
        logger.warning("⚠️ Option chain worker already running, skipping...")
        return

    is_running = True

    logger.info("🚀 Option chain worker started")

    while True:
        try:
            # =================================================
            # ✅ SKIP IF MARKET CLOSED
            # =================================================
            if not is_market_open():
                logger.info("🕒 Market closed → skipping option chain fetch")
                time.sleep(60)
                continue

            # =================================================
            # ✅ FETCH DATA
            # =================================================
            data = get_option_chain_data()

            if not data:
                logger.warning("⚠️ Empty option chain data received")
                time.sleep(60)
                continue

            security_id = data.get("security_id")

            if not security_id:
                logger.warning("⚠️ Missing security_id in option chain data")
                time.sleep(60)
                continue

            # =================================================
            # ✅ BROADCAST TO WEBSOCKET
            # =================================================
            from .ws_broadcast import broadcast_option_chain

            broadcast_option_chain(
                security_id,
                data,
            )

            logger.info(f"📡 Option chain broadcast sent | Security={security_id}")

        except Exception as e:
            logger.exception(f"❌ Option chain worker error: {e}")

        # =================================================
        # ✅ INTERVAL (60 SEC)
        # =================================================
        time.sleep(60)
