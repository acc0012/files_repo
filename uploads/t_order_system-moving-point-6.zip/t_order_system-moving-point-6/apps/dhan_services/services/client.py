# apps/dhan_services/services/client.py

from dhanhq import DhanContext
from dhanhq import dhanhq

from core.dhan_token import load_valid_dhan_credentials
from core.logger import get_logger

logger = get_logger("dhan_client")

# =====================================================
# SINGLETONS
# =====================================================

_dhan_context = None
_dhan_client = None


# =====================================================
# DHAN CONTEXT
# =====================================================


def get_dhan_context():

    global _dhan_context

    try:

        if _dhan_context is not None:
            return _dhan_context

        creds = load_valid_dhan_credentials()

        if not creds:
            raise ValueError("No valid Dhan credentials found")

        client_id = str(creds.get("client_id", "")).strip()

        access_token = str(creds.get("access_token", "")).strip()

        if not client_id:
            raise ValueError("Dhan client_id missing")

        if not access_token:
            raise ValueError("Dhan access_token missing")

        _dhan_context = DhanContext(
            client_id,
            access_token,
        )

        logger.info(f"✅ Dhan Context Initialized | Client: {client_id}")

        return _dhan_context

    except Exception as e:

        logger.exception(f"❌ Failed creating Dhan Context: {e}")

        raise


# =====================================================
# DHAN CLIENT
# =====================================================


def get_dhan_client():

    global _dhan_client

    try:

        if _dhan_client is not None:
            return _dhan_client

        context = get_dhan_context()

        _dhan_client = dhanhq(context)

        logger.info("✅ Dhan Client Initialized")

        return _dhan_client

    except Exception as e:

        logger.exception(f"❌ Failed creating Dhan Client: {e}")

        raise


# =====================================================
# REFRESH
# =====================================================


def refresh_dhan_client():

    global _dhan_context
    global _dhan_client

    try:

        _dhan_context = None
        _dhan_client = None

        logger.info("🔄 Refreshing Dhan Client")

        return get_dhan_client()

    except Exception as e:

        logger.exception(f"❌ Dhan refresh failed: {e}")

        raise


# =====================================================
# HEALTH CHECK
# =====================================================


def is_dhan_available():

    try:

        client = get_dhan_client()

        return client is not None

    except Exception:

        return False
