# apps/dhan_services/services/historical.py

from .client import get_dhan_client

from core.logger import get_logger

logger = get_logger("dhan_historical")


# =====================================================
# VALIDATION
# =====================================================


def _validate_request(
    security_id,
    exchange_segment,
    instrument_type,
    from_date,
    to_date,
):

    if not security_id:
        raise ValueError("security_id is required")

    if not exchange_segment:
        raise ValueError("exchange_segment is required")

    if not instrument_type:
        raise ValueError("instrument_type is required")

    if not from_date:
        raise ValueError("from_date is required")

    if not to_date:
        raise ValueError("to_date is required")


# =====================================================
# INTRADAY DATA
# =====================================================


def get_intraday_data(
    security_id,
    exchange_segment,
    instrument_type,
    from_date,
    to_date,
):

    try:

        _validate_request(
            security_id,
            exchange_segment,
            instrument_type,
            from_date,
            to_date,
        )

        dhan = get_dhan_client()

        logger.info(
            f"📊 Intraday Request | "
            f"Security={security_id} | "
            f"Segment={exchange_segment} | "
            f"Type={instrument_type} | "
            f"From={from_date} | "
            f"To={to_date}"
        )

        response = dhan.intraday_minute_data(
            security_id=str(security_id),
            exchange_segment=exchange_segment,
            instrument_type=instrument_type,
            from_date=from_date,
            to_date=to_date,
        )

        logger.info("✅ Intraday data fetched successfully")

        return response

    except Exception as e:

        logger.exception(f"❌ Intraday fetch failed: {e}")

        raise


# =====================================================
# DAILY DATA
# =====================================================


def get_daily_data(
    security_id,
    exchange_segment,
    instrument_type,
    from_date,
    to_date,
):

    try:

        _validate_request(
            security_id,
            exchange_segment,
            instrument_type,
            from_date,
            to_date,
        )

        dhan = get_dhan_client()

        logger.info(
            f"📈 Daily Request | "
            f"Security={security_id} | "
            f"Segment={exchange_segment} | "
            f"Type={instrument_type} | "
            f"From={from_date} | "
            f"To={to_date}"
        )

        response = dhan.historical_daily_data(
            security_id=str(security_id),
            exchange_segment=exchange_segment,
            instrument_type=instrument_type,
            from_date=from_date,
            to_date=to_date,
        )

        logger.info("✅ Daily historical data fetched successfully")

        return response

    except Exception as e:

        logger.exception(f"❌ Daily historical fetch failed: {e}")

        raise
