# apps/dhan_services/services/option_chain.py

import time

from .client import get_dhan_client
from core.logger import get_logger

logger = get_logger("dhan_option_chain")

# =====================================================
# CONFIG
# =====================================================

# NIFTY CONFIG
NIFTY_SECURITY_ID = 13
NIFTY_SEGMENT = "IDX_I"

# =====================================================
# EXPIRY CACHE (IMPORTANT - PREVENT RATE LIMIT)
# =====================================================

_cached_expiry = None
_last_expiry_fetch = 0
EXPIRY_TTL = 3600  # 1 hour cache


# =====================================================
# GET NEAREST EXPIRY (WITH CACHE)
# =====================================================

def get_nearest_expiry(security_id, exchange_segment):
    global _cached_expiry, _last_expiry_fetch

    now = time.time()

    try:
        # ✅ USE CACHE IF VALID
        if _cached_expiry and (now - _last_expiry_fetch < EXPIRY_TTL):
            logger.info(f"⚡ Using cached expiry: {_cached_expiry}")
            return _cached_expiry

        dhan = get_dhan_client()

        logger.info("📅 Fetching expiry list from Dhan")

        expiry_list = dhan.expiry_list(
            under_security_id=security_id,
            under_exchange_segment=exchange_segment,
        )

        if not isinstance(expiry_list, dict):
            raise ValueError("Invalid expiry response (not dict)")

        expiries = expiry_list.get("data", [])

        if not expiries:
            raise ValueError("Empty expiry list received")

        # ✅ FIRST EXPIRY = NEAREST
        nearest_expiry = expiries[0]

        # ✅ CACHE IT
        _cached_expiry = nearest_expiry
        _last_expiry_fetch = now

        logger.info(f"✅ Nearest expiry cached: {nearest_expiry}")

        return nearest_expiry

    except Exception as e:
        logger.exception(f"❌ Expiry fetch failed: {e}")
        raise


# =====================================================
# GET OPTION CHAIN DATA
# =====================================================

def get_option_chain_data():
    try:
        dhan = get_dhan_client()

        # ✅ GET NEAREST EXPIRY
        expiry = get_nearest_expiry(
            NIFTY_SECURITY_ID,
            NIFTY_SEGMENT,
        )

        logger.info(f"📊 Fetching option chain | Expiry: {expiry}")

        response = dhan.option_chain(
            under_security_id=NIFTY_SECURITY_ID,
            under_exchange_segment=NIFTY_SEGMENT,
            expiry=expiry,
        )

        # ✅ SAFETY CHECK
        if not response or not isinstance(response, dict):
            raise ValueError("Invalid option chain response (not dict)")

        data = response.get("data")

        if data is None:
            raise ValueError("Option chain response missing 'data'")

        logger.info("✅ Option chain fetched successfully")

        return {
            "security_id": NIFTY_SECURITY_ID,
            "exchange_segment": NIFTY_SEGMENT,
            "expiry": expiry,
            "data": data,
        }

    except Exception as e:
        logger.exception(f"❌ Option chain fetch failed: {e}")
        raise