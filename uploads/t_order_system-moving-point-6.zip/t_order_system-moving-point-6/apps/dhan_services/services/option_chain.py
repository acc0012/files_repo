# apps/dhan_services/services/option_chain.py

from .client import get_dhan_client
from core.logger import get_logger
from django.conf import settings

logger = get_logger("dhan_option_chain")


# =====================================================
# HELPER LOGGER
# =====================================================

def log_feed(message):
    """
    Log only when OPTION_FEED_LOGS = True
    """
    try:
        if getattr(settings, "OPTION_FEED_LOGS", False):
            logger.info(message)
    except Exception:
        pass


# =====================================================
# OPTION CHAIN
# =====================================================

def get_option_chain_data(
    under_security_id,
    under_exchange_segment,
):
    try:
        if not under_security_id:
            raise ValueError("under_security_id is required")

        if not under_exchange_segment:
            raise ValueError("under_exchange_segment is required")

        logger.info(f"📊 START | index={under_security_id}")

        dhan = get_dhan_client()

        # ==========================================
        # STEP 1: EXPIRY LIST
        # ==========================================
        expiry_response = dhan.expiry_list(
            under_security_id=under_security_id,
            under_exchange_segment=under_exchange_segment,
        )

        # ✅ FIXED LOG
        log_feed(f"📥 Expiry RAW: {expiry_response}")

        expiry_data = expiry_response.get("data", {})
        expiry_list = sorted(expiry_data.get("data", []))

        if not expiry_list:
            raise ValueError("No expiry dates found")

        nearest_expiry = expiry_list[0]
        logger.info(f"✅ Using expiry: {nearest_expiry}")

        # ==========================================
        # STEP 2: OPTION CHAIN
        # ==========================================
        option_chain_response = dhan.option_chain(
            under_security_id=under_security_id,
            under_exchange_segment=under_exchange_segment,
            expiry=nearest_expiry,
        )

        # ✅ FORCE LOG (ALWAYS visible)
        log_feed(f"🔥 OPTION CHAIN FULL RESPONSE: {option_chain_response}")
        # ✅ VALIDATION
        if not isinstance(option_chain_response, dict):
            raise ValueError("Invalid option chain response format")

        status = option_chain_response.get("status")
        remarks = option_chain_response.get("remarks")

        logger.info(f"📡 API STATUS: {status}")
        logger.info(f"📡 API REMARKS: {remarks}")

        outer_data = option_chain_response.get("data", {}) or {}
        oc_data = outer_data.get("data", {}) or {} or {}

        logger.info(f"📦 oc_data keys: {list(oc_data.keys())}")

        oc_block = oc_data.get("oc", {}) or {}
        ltp = oc_data.get("last_price")

        # ✅ DEBUG
        logger.info(f"🔍 last_price: {ltp}")
        logger.info(f"🔍 oc_block size: {len(oc_block)}")

        try:
            sample_keys = list(oc_block.keys())[:5]
            logger.info(f"🔍 sample strikes: {sample_keys}")
        except Exception:
            pass

        # ==========================================
        # ✅ HANDLE EMPTY API RESPONSE (REAL FIX)
        # ==========================================
        if not oc_block:
            logger.warning("⚠️ Empty option chain from Dhan API")

            return {
                "expiry": nearest_expiry,
                "strike_range": None,
                "underlying_price": ltp or 0,
                "option_chain": {
                    "data": {
                        "last_price": ltp or 0,
                        "oc": {},
                    }
                },
                "debug": {
                    "reason": "empty_oc_block",
                    "status": status,
                    "remarks": remarks,
                }
            }

        if ltp is None:
            logger.warning("⚠️ last_price missing → fallback to 0")
            ltp = 0

        # ==========================================
        # ✅ FILTER STRIKE RANGE
        # ==========================================
        STRIKE_RANGE = 500

        lower = ltp - STRIKE_RANGE
        upper = ltp + STRIKE_RANGE

        filtered_oc = {}

        for strike_str, strike_data in oc_block.items():
            try:
                strike = float(strike_str)

                if lower <= strike <= upper:
                    filtered_oc[strike_str] = strike_data

            except Exception:
                continue

        logger.info(f"✅ Filtered strikes: {len(filtered_oc)}")

        # ==========================================
        # FINAL RESPONSE
        # ==========================================
        return {
            "expiry": nearest_expiry,
            "strike_range": STRIKE_RANGE,
            "underlying_price": ltp,
            "lower_bound": round(lower, 2),
            "upper_bound": round(upper, 2),
            "option_chain": {
                "data": {
                    "last_price": ltp,
                    "oc": filtered_oc,
                }
            },
        }

    except Exception as e:
        logger.exception(f"❌ Option Chain fetch failed: {e}")
        raise


# =====================================================
# EXPIRY LIST
# =====================================================

def get_expiry_list(
    under_security_id,
    under_exchange_segment,
):
    try:
        if not under_security_id:
            raise ValueError("under_security_id is required")

        if not under_exchange_segment:
            raise ValueError("under_exchange_segment is required")

        dhan = get_dhan_client()

        log_feed(
            f"📅 Fetching expiry list | "
            f"Security={under_security_id} | Segment={under_exchange_segment}"
        )

        response = dhan.expiry_list(
            under_security_id=under_security_id,
            under_exchange_segment=under_exchange_segment,
        )

        log_feed(f"📥 Expiry Raw Response: {response}")

        if not isinstance(response, dict):
            raise ValueError("Invalid expiry response format")

        if response.get("status") != "success":
            raise ValueError(f"Expiry API failed: {response}")

        expiry_data = response.get("data", {})
        expiry_list = expiry_data.get("data", [])

        if not expiry_list:
            raise ValueError("No expiry dates found")

        expiry_list = sorted(expiry_list)

        log_feed(f"✅ Expiry List: {expiry_list}")

        return {
            "expiries": expiry_list,
            "nearest": expiry_list[0],
        }

    except Exception as e:
        logger.exception(f"❌ Expiry list fetch failed: {e}")
        raise