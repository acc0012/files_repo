# apps/dhan_services/services/ws_broadcast.py

from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync
from core.logger import get_logger

logger = get_logger("option_chain_ws")

# =====================================================
# BROADCAST OPTION CHAIN
# =====================================================

def broadcast_option_chain(security_id, data):
    try:
        channel_layer = get_channel_layer()

        if not channel_layer:
            logger.error("❌ Channel layer not initialized")
            return

        if not security_id:
            logger.warning("⚠️ Missing security_id, skipping broadcast")
            return

        group_name = f"option_chain_{security_id}"

        async_to_sync(channel_layer.group_send)(
            group_name,
            {
                "type": "send_option_chain",
                "data": data,
            }
        )

        logger.info(f"📡 Broadcast sent → {group_name}")

    except Exception as e:
        logger.exception(f"❌ WebSocket broadcast failed: {e}")