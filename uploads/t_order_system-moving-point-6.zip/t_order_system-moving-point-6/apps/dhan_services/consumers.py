# apps/dhan_services/consumers.py

import json

from channels.generic.websocket import WebsocketConsumer
from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer

from core.logger import get_logger

logger = get_logger("option_chain_consumer")


# =====================================================
# OPTION CHAIN CONSUMER
# =====================================================

class OptionChainConsumer(WebsocketConsumer):

    # =================================================
    # CONNECT
    # =================================================

    def connect(self):
        try:
            self.accept()

            # ✅ Get security_id from URL
            self.security_id = self.scope["url_route"]["kwargs"].get(
                "security_id",
                "13",  # default to NIFTY
            )

            # ✅ Dynamic group
            self.group_name = f"option_chain_{self.security_id}"

            self.channel_layer = get_channel_layer()

            if not self.channel_layer:
                logger.error("❌ Channel layer not available")
                self.close()
                return

            async_to_sync(self.channel_layer.group_add)(
                self.group_name,
                self.channel_name
            )

            logger.info(
                f"🔌 WS Connected | Security={self.security_id} | Group={self.group_name}"
            )

        except Exception as e:
            logger.exception(f"❌ WS connect error: {e}")
            self.close()


    # =================================================
    # DISCONNECT
    # =================================================

    def disconnect(self, close_code):
        try:
            if hasattr(self, "group_name") and self.channel_layer:
                async_to_sync(self.channel_layer.group_discard)(
                    self.group_name,
                    self.channel_name
                )

            logger.info(
                f"🔌 WS Disconnected | Security={getattr(self, 'security_id', 'N/A')} "
                f"| Code={close_code}"
            )

        except Exception as e:
            logger.exception(f"❌ WS disconnect error: {e}")


    # =================================================
    # RECEIVE (Optional ping support)
    # =================================================

    def receive(self, text_data=None, bytes_data=None):
        try:
            if not text_data:
                return

            try:
                data = json.loads(text_data)
            except json.JSONDecodeError:
                return

            action = str(data.get("action", "")).lower()

            # ✅ Ping/pong support
            if action == "ping":
                self.send(text_data=json.dumps({
                    "type": "system",
                    "status": "pong",
                    "security_id": self.security_id,
                }))

        except Exception as e:
            logger.exception(f"❌ WS receive error: {e}")


    # =================================================
    # SEND OPTION CHAIN DATA
    # =================================================

    def send_option_chain(self, event):
        try:
            data = event.get("data", {})

            if not isinstance(data, dict):
                logger.warning("⚠️ Invalid event data format")
                return

            # ✅ Safe serialization
            safe_data = {
                k: (str(v) if not isinstance(v, (int, float, dict, list)) else v)
                for k, v in data.items()
            }

            self.send(
                text_data=json.dumps(safe_data, default=str)
            )

        except Exception as e:
            error_str = str(e)

            ignored_errors = [
                "ConnectionClosed",
                "ConnectionClosedOK",
                "ClientDisconnected",
            ]

            if any(err in error_str for err in ignored_errors):
                logger.info("🔌 WS connection closed normally")
                return

            logger.exception(f"❌ WS send error: {e}")