from django.http import JsonResponse
from django.shortcuts import render
from django.conf import settings

from apps.marketfeed.views import get_feed_service
from core.logger import get_logger
from django.shortcuts import render


logger = get_logger("core_views")

DEFAULT_INSTRUMENTS = settings.DEFAULT_INSTRUMENTS


# =====================================================
# JSON SAFE CONVERTER
# =====================================================

def make_json_safe(obj):

    if isinstance(obj, set):
        return list(obj)

    if isinstance(obj, tuple):
        return list(obj)

    if isinstance(obj, list):
        return [make_json_safe(x) for x in obj]

    if isinstance(obj, dict):
        return {
            k: make_json_safe(v)
            for k, v in obj.items()
        }

    return obj


# =====================================================
# ROOT DASHBOARD
# =====================================================

def home(request):

    try:

        service = get_feed_service()

        feed = getattr(
            service,
            "feed",
            None,
        )

        subscribed_count = 0
        subscribed_instruments = []

        try:

            if feed and hasattr(feed, "instruments"):

                subscribed_instruments = make_json_safe(
                    list(feed.instruments)
                )

                subscribed_count = len(
                    subscribed_instruments
                )

        except Exception as feed_error:

            logger.exception(
                f"❌ Feed access failed: {feed_error}"
            )

        data = {
            "status": (
                "running"
                if service.is_running
                else "stopped"
            ),
            "feed_initialized": feed is not None,

            # SAFE DEFAULT CONFIG
            "default_instruments": make_json_safe(
                DEFAULT_INSTRUMENTS
            ),

            # SAFE SUBSCRIPTIONS
            "subscribed_security_ids": subscribed_count,
            "subscribed_instruments": subscribed_instruments,

            "websocket_endpoint": "/ws/market/",
            "dashboard_url": "/dashboard/",

            "quote_feed_sample": {
                "type": "Quote Data",
                "exchange_segment": 0,
                "security_id": 51,
                "LTP": "78493.54",
                "LTQ": 0,
                "LTT": "17:00:01",
                "avg_price": "0.00",
                "volume": 0,
                "total_sell_quantity": 0,
                "total_buy_quantity": 0,
                "open": "77976.13",
                "close": "78493.54",
                "high": "78553.45",
                "low": "77726.23",
            },
        }

        return JsonResponse(
            make_json_safe(data)
        )

    except Exception as e:

        logger.exception(
            f"❌ Home endpoint failed: {e}"
        )

        return JsonResponse(
            {
                "status": "error",
                "message": str(e),
            },
            status=500,
        )




def option_chain_view(request):
    return render(request, "dashboard/option_chain_ws_test.html")
# =====================================================
# LIVE DASHBOARD PAGE
# =====================================================


def dashboard(request):

    try:

        return render(
            request,
            "dashboard/live_feed.html",
        )

    except Exception as e:

        logger.exception(f"❌ Dashboard render failed: {e}")

        return JsonResponse(
            {
                "status": "error",
                "message": "Dashboard failed to load",
            },
            status=500,
        )


# =====================================================
# HEALTH CHECK
# =====================================================


def health(request):

    try:

        service_status = "unknown"

        try:

            service = get_feed_service()

            service_status = "running" if service.is_running else "stopped"

        except Exception as service_error:

            logger.exception(f"❌ Service health check failed: " f"{service_error}")

        return JsonResponse(
            {
                # -------------------------------------
                # API
                # -------------------------------------
                "status": "ok",
                # -------------------------------------
                # SERVICE
                # -------------------------------------
                "market_feed_service": service_status,
            }
        )

    except Exception as e:

        logger.exception(f"❌ Health check failed: {e}")

        return JsonResponse(
            {
                "status": "error",
                "message": str(e),
            },
            status=500,
        )
