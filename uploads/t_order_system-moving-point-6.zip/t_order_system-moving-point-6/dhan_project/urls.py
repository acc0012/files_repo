"""
URL configuration for dhan_project project.
"""

from django.contrib import admin

from django.urls import (
    include,
    path,
)

from core.views import (
    dashboard,
    health,
    home,
    option_chain_view,   # ✅ NEW IMPORT
)

# =====================================================
# URL PATTERNS
# =====================================================

urlpatterns = [

    # =================================================
    # ADMIN
    # =================================================
    path("admin/", admin.site.urls),

    # =================================================
    # CORE
    # =================================================
    path("", home),
    path("dashboard/", dashboard),
    path("health/", health),

    # ✅ NEW OPTION CHAIN PAGE
    path(
        "option-chain/",
        option_chain_view,
        name="option_chain_view"
    ),

    # =================================================
    # INSTRUMENT APIs
    # =================================================
    path("api/", include("apps.instruments.urls")),

    # =================================================
    # MARKET FEED APIs
    # =================================================
    path("marketfeed/", include("apps.marketfeed.urls")),

    # =================================================
    # OPTIONAL LEGACY ROUTE
    # =================================================
    path("api/feed/", include("apps.marketfeed.urls")),

    # =================================================
    # DHAN APIs
    # =================================================
    path("dhan/", include("apps.dhan_services.urls")),
]