@echo off
cls

REM Activate virtual environment
call myenv\Scripts\activate

REM Run Uvicorn
uvicorn dhan_project.asgi:application --workers 1
