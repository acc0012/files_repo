import html
import os
import pyperclip

def should_ignore(path, ignore_dirs, ignore_files):
    path_lower = path.lower()

    for ignore in ignore_dirs:
        if ignore.lower() in path_lower:
            return True

    for fname in ignore_files:
        if path_lower.endswith(fname.lower()):
            return True

    return False


def is_large_file(file_path, max_lines=1500):
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            for i, _ in enumerate(f):
                if i > max_lines:
                    return True
        return False
    except Exception:
        return True




def clean_content(content):
    """Remove extra spaces, blank lines, and fix HTML escaped chars."""

    # ✅ Decode HTML entities FIRST (critical fix)
    content = html.unescape(content)

    lines = content.splitlines()

    cleaned_lines = []
    prev_blank = False

    for line in lines:
        stripped = line.rstrip()

        if stripped == "":
            if not prev_blank:
                cleaned_lines.append("")
            prev_blank = True
        else:
            cleaned_lines.append(stripped)
            prev_blank = False

    return "\n".join(cleaned_lines).strip()

def collect_files_content(root_folder, output_file):
    ignore_dirs = [
        "__pycache__", ".git", ".idea",
        "node_modules", "venv", "env",
        "temp", "samples", "migrations",
        "test","tests","files","output"
    ]

    ignore_files = [
        ".env",
        ".pyc",
        ".log",
        "db.sqlite3"
    ]

    with open(output_file, 'w', encoding='utf-8') as outfile:
        for root, dirs, files in os.walk(root_folder):

            dirs[:] = [
                d for d in dirs
                if not should_ignore(os.path.join(root, d), ignore_dirs, ignore_files)
            ]

            for file in files:
                file_path = os.path.join(root, file)

                if should_ignore(file_path, ignore_dirs, ignore_files):
                    continue

                if os.path.getsize(file_path) == 0:
                    continue

                if is_large_file(file_path):
                    print(f"Skipping large file: {file_path}")
                    continue

                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()

                    cleaned = clean_content(content)

                    if not cleaned:
                        continue  # skip if empty after cleaning

                    outfile.write("\n" + "=" * 80 + "\n")
                    outfile.write(f"FILE: {file_path}\n")
                    outfile.write("=" * 80 + "\n\n")
                    outfile.write(cleaned)
                    outfile.write("\n\n")

                except Exception as e:
                    print(f"Error reading {file_path}: {e}")


def main():
    folder_path = input("Enter folder path: ").strip()
    output_file = "combined_output.txt"

    if not os.path.exists(folder_path):
        print("❌ Invalid folder path")
        return

    collect_files_content(folder_path, output_file)
    print(f"\n✅ Clean content saved to: {output_file}")

    # ✅ Copy file content to clipboard
    try:
        with open(output_file, 'r', encoding='utf-8') as f:
            final_content = f.read()

        pyperclip.copy(final_content)
        print("📋 Content copied to clipboard successfully!")

    except Exception as e:
        print(f"❌ Failed to copy to clipboard: {e}")


if __name__ == "__main__":
    main()
