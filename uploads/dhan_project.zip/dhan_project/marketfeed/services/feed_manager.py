import threading
from dhanhq import DhanContext, MarketFeed
from core.dhan_token import load_valid_dhan_credentials

from core.logger import get_logger
logger = get_logger("feed_manager")


"""
🔹 MarketFeed Usage (Official)

Structure:
(exchange_segment, "security_id", subscription_type)

Exchange Segment Constants:
- MarketFeed.NSE
- MarketFeed.BSE
- MarketFeed.NSE_FNO
- MarketFeed.MCX
- MarketFeed.NSE_CURR

Subscription Types:
- MarketFeed.Ticker  -> LTP data
- MarketFeed.Quote   -> OHLC + Volume
- MarketFeed.Full    -> Full packet (Quote + Market Depth)
"""


class FeedManager:
    def __init__(self):
        self.feed = None
        self.thread = None
        self.running = False
        self.lock = threading.Lock()  # ✅ thread safety

    # ✅ START FEED
    def start(self, instruments):

        with self.lock:
            if self.running:
                return "Already running"

            creds = load_valid_dhan_credentials()
            if not creds:
                return "No valid token"

            try:
                dhan_context = DhanContext(
                    creds["client_id"],
                    creds["access_token"]
                )

                self.feed = MarketFeed(
                    dhan_context,
                    instruments,
                    version="v2"
                )

                self.running = True

                def run_feed():
                    try:
                        logger.info("Feed thread started")
                        self.feed.run_forever()

                    except Exception as e:
                        logger.error(f"Feed error: {e}")

                    finally:
                        logger.warning("Feed stopped or crashed")
                        self.running = False

                self.thread = threading.Thread(
                    target=run_feed,
                    daemon=True
                )
                self.thread.start()

                logger.info("Feed started successfully")
                return "Feed started"

            except Exception as e:
                logger.error(f"Start error: {e}")
                return f"Start error: {e}"

    # ✅ THREAD-SAFE DATA ACCESS (IMPORTANT FIX)
    def get_data(self):

        if not self.feed or not self.running:
            return None

        try:
            with self.lock:  # ✅ CRITICAL FIX
                return self.feed.get_data()

        except Exception as e:
            logger.error(f"get_data error: {e}")
            return {"error": str(e)}

    # ✅ SUBSCRIBE
    def subscribe(self, instruments):

        if not self.running or not self.feed:
            return "Feed not started"

        if not instruments:
            return "No instruments provided"

        try:
            logger.info(f"Subscribing: {instruments}")
            self.feed.subscribe_symbols(instruments)
            return "Subscribed"

        except Exception as e:
            logger.error(f"Subscribe error: {e}")
            return f"Subscribe error: {e}"

    # ✅ UNSUBSCRIBE
    def unsubscribe(self, instruments):

        if not self.running or not self.feed:
            return "Feed not started"

        if not instruments:
            return "No instruments provided"

        try:
            logger.info(f"Unsubscribing: {instruments}")
            self.feed.unsubscribe_symbols(instruments)
            return "Unsubscribed"

        except Exception as e:
            logger.error(f"Unsubscribe error: {e}")
            return f"Unsubscribe error: {e}"

    # ✅ STOP FEED
    def stop(self):

        with self.lock:
            if not self.feed:
                return "Feed not running"

            try:
                logger.info("Stopping feed")

                self.feed.close_connection()
                self.running = False

                if self.thread and self.thread.is_alive():
                    self.thread.join(timeout=2)

                logger.info("Feed stopped successfully")
                return "Stopped"

            except Exception as e:
                logger.error(f"Stop error: {e}")
                return f"Stop error: {e}"


# ✅ Singleton
feed_manager = FeedManager()
