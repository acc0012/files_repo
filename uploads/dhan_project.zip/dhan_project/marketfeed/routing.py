from django.urls import re_path
from .consumers import FeedConsumer

websocket_urlpatterns = [
    re_path(r"ws/feed/(?P<security_id>\w+)/$", FeedConsumer.as_asgi()),
]