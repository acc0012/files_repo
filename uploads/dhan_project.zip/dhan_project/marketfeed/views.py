from django.http import JsonResponse
from django.shortcuts import render
from .services.feed_manager import feed_manager
from core.logger import get_logger
import json

# ✅ Initialize logger
logger = get_logger("marketfeed_views")


"""
🔹 Exchange Segment Mapping (Dhan Official)

Attribute        Exchange    Segment                Enum
--------------------------------------------------------
IDX_I            Index       Index Value            0
NSE_EQ           NSE         Equity Cash            1
NSE_FNO          NSE         Futures & Options      2
NSE_CURRENCY     NSE         Currency               3
BSE_EQ           BSE         Equity Cash            4
MCX_COMM         MCX         Commodity              5
BSE_CURRENCY     BSE         Currency               7
BSE_FNO          BSE         Futures & Options      8


🔹 Subscription Types (RequestCode)

Type        Meaning
-----------------------------
15          Ticker  (LTP only)
17          Quote   (OHLC + Volume)
21          Full    (Quote + Market Depth)
"""


# ✅ DASHBOARD VIEW
def dashboard(request):
    return render(request, "marketfeed/dashboard.html")


# ✅ START FEED
def start_feed(request):
    try:
        logger.info("➡️ Start feed requested")

        instruments = [
            (1, "13", 17),   # NSE_EQ - Quote (NIFTY)
            (1, "51", 17),   # NSE_EQ - Quote (BANKNIFTY)
        ]

        msg = feed_manager.start(instruments)

        logger.info(f"✅ Feed start response: {msg}")
        return JsonResponse({"message": msg})

    except Exception as e:
        logger.error(f"❌ Error in start_feed: {e}")
        return JsonResponse({"error": str(e)}, status=500)


# ✅ GET LIVE DATA
def get_feed_data(request):
    try:
        data = feed_manager.get_data()
        return JsonResponse({"data": data})

    except Exception as e:
        logger.error(f"❌ Error in get_feed_data: {e}")
        return JsonResponse({"error": str(e)}, status=500)


# ✅ SUBSCRIBE (DYNAMIC)
def subscribe(request):
    try:
        logger.info("➡️ Subscribe request received")

        if request.method != "POST":
            return JsonResponse({"error": "Only POST allowed"}, status=405)

        body = json.loads(request.body or "{}")
        instruments = body.get("instruments", [])

        if not instruments:
            return JsonResponse({"error": "No instruments provided"}, status=400)

        msg = feed_manager.subscribe(instruments)

        logger.info(f"✅ Subscribe response: {msg}")
        return JsonResponse({"message": msg})

    except Exception as e:
        logger.error(f"❌ Error in subscribe: {e}")
        return JsonResponse({"error": str(e)}, status=500)


# ✅ UNSUBSCRIBE (DYNAMIC)
def unsubscribe(request):
    try:
        logger.info("➡️ Unsubscribe request received")

        if request.method != "POST":
            return JsonResponse({"error": "Only POST allowed"}, status=405)

        body = json.loads(request.body or "{}")
        instruments = body.get("instruments", [])

        if not instruments:
            return JsonResponse({"error": "No instruments provided"}, status=400)

        msg = feed_manager.unsubscribe(instruments)

        logger.info(f"✅ Unsubscribe response: {msg}")
        return JsonResponse({"message": msg})

    except Exception as e:
        logger.error(f"❌ Error in unsubscribe: {e}")
        return JsonResponse({"error": str(e)}, status=500)


# ✅ STOP FEED
def stop_feed(request):
    try:
        logger.info("➡️ Stop feed requested")

        msg = feed_manager.stop()

        logger.info(f"✅ Feed stop response: {msg}")
        return JsonResponse({"message": msg})

    except Exception as e:
        logger.error(f"❌ Error in stop_feed: {e}")
        return JsonResponse({"error": str(e)}, status=500)