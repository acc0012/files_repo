import json
from channels.generic.websocket import AsyncWebsocketConsumer
import asyncio
from marketfeed.services.feed_manager import feed_manager


class FeedConsumer(AsyncWebsocketConsumer):

    async def connect(self):
        # ✅ FIX: always treat as string
        self.security_id = str(self.scope["url_route"]["kwargs"]["security_id"])

        await self.accept()

        # ✅ start live loop
        self.running = True
        asyncio.create_task(self.send_live_data())

    async def disconnect(self, close_code):
        self.running = False

    async def send_live_data(self):
        while self.running:
            try:
                data = feed_manager.get_data()

                if data:
                    target_key = str(self.security_id)

                    # ✅ handle both int and string keys safely
                    for key, value in data.items():
                        if str(key) == target_key:
                            await self.send(text_data=json.dumps(value))
                            break

            except Exception as e:
                await self.send(text_data=json.dumps({"error": str(e)}))

            # ✅ push every 1 second
            await asyncio.sleep(1)