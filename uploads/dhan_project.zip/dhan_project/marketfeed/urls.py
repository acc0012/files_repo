from django.urls import path
from . import views

urlpatterns = [
    # ✅ Dashboard UI
    path("dashboard/", views.dashboard, name="dashboard"),

    # ✅ Feed control APIs
    path("start/", views.start_feed, name="start_feed"),
    path("data/", views.get_feed_data, name="get_feed_data"),
    path("subscribe/", views.subscribe, name="subscribe"),
    path("unsubscribe/", views.unsubscribe, name="unsubscribe"),
    path("stop/", views.stop_feed, name="stop_feed"),
]