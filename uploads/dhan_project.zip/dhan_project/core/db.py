from pymongo import MongoClient
from django.conf import settings
from core.logger import get_logger
import sys
import time

logger = get_logger("db_layer")

# -----------------------------------
# 🔧 FORCE UTF-8 LOGGING
# -----------------------------------
try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass


_client = None

# ✅ CACHE STORAGE
_doc_cache = {}
_oc_cache = {}
_cache_time = {}

CACHE_TTL = 2  # seconds


# -----------------------------------
# ✅ CACHE VALIDATION
# -----------------------------------
def is_cache_valid(index_security_id):
    if index_security_id not in _cache_time:
        return False

    return (time.time() - _cache_time[index_security_id]) < CACHE_TTL


# -----------------------------------
# 🔗 SINGLETON CLIENT
# -----------------------------------
def get_mongo_client():
    global _client

    if _client is None:
        if not settings.MONGO_URI:
            raise ValueError("MONGO_URI missing")

        _client = MongoClient(settings.MONGO_URI)
        logger.info("✅ Mongo Connected")

    return _client


# -----------------------------------
# 📦 DATABASE
# -----------------------------------
def get_db(db_name=None):
    client = get_mongo_client()

    db_to_use = db_name if db_name else settings.MONGO_DB

    if not db_to_use:
        raise ValueError("MONGO_DB missing")

    return client[db_to_use]


# -----------------------------------
# 📊 OPTION CHAIN COLLECTION
# -----------------------------------
def get_option_chain_collection():
    db_name = getattr(settings, "MONGO_OPTION_CHAIN_DB", None)

    collection_name = getattr(
        settings,
        "MONGO_OPTION_COLLECTION",
        "index_option_chain"
    )

    return get_db(db_name)[collection_name]


# -----------------------------------
# ✅ FETCH LATEST DOC (WITH CACHE)
# -----------------------------------
def get_latest_option_chain_doc(index_security_id):

    if is_cache_valid(index_security_id):
        return _doc_cache.get(index_security_id)

    collection = get_option_chain_collection()

    doc = collection.find_one(
        {"index_security_id": index_security_id},
        sort=[("fetched_at", -1)]
    )

    if not doc:
        logger.error(f"No data for index {index_security_id}")
        return None

    _doc_cache[index_security_id] = doc
    _cache_time[index_security_id] = time.time()

    return doc


# -----------------------------------
# ✅ NORMALIZE STRIKES
# -----------------------------------
def normalize_strikes(oc_dict):

    normalized = {}

    for key, value in oc_dict.items():
        try:
            clean_key = str(int(float(key)))
        except Exception:
            clean_key = key

        normalized[clean_key] = value

    return normalized


# -----------------------------------
# ✅ ORDERS COLLECTION
# -----------------------------------
def get_orders_collection():
    db = get_db(settings.AUTH_MONGO_DB)
    return db[settings.ORDERS_MONGO_COLLECTION]


# -----------------------------------
# ✅ CLEAN OPTION CHAIN (CACHE)
# -----------------------------------
def get_clean_option_chain(index_security_id):

    if is_cache_valid(index_security_id):
        return _oc_cache.get(index_security_id)

    doc = get_latest_option_chain_doc(index_security_id)

    if not doc:
        return None

    oc = doc.get("option_chain", {}).get("oc", {})

    normalized = normalize_strikes(oc)

    _oc_cache[index_security_id] = normalized

    return normalized


# -----------------------------------
# 🔥 SYMBOL → INDEX
# -----------------------------------
def get_index_security_id_from_symbol(symbol: str):

    if not symbol:
        return None

    symbol = symbol.upper()

    if "BANKNIFTY" in symbol:
        return 51
    elif "FINNIFTY" in symbol:
        return 25
    elif "NIFTY" in symbol:
        return 13

    return None


# -----------------------------------
# 🎯 SINGLE OPTION DATA
# -----------------------------------
def get_option_data(index_security_id, strike, option_type="pe"):

    oc = get_clean_option_chain(index_security_id)

    if not oc:
        return None

    strike = int(float(strike))
    strike_key = str(strike)

    if strike_key in oc:
        return oc[strike_key].get(option_type.lower())

    # ✅ nearest fallback
    closest = min(
        oc.keys(),
        key=lambda x: abs(int(x) - strike)
    )

    return oc[closest].get(option_type.lower())


# -----------------------------------
# 🔥 SYMBOL → OPTION
# -----------------------------------
def get_option_data_from_symbol(symbol, strike, option_type="pe"):

    idx = get_index_security_id_from_symbol(symbol)

    if not idx:
        return None

    return get_option_data(idx, strike, option_type)


# -----------------------------------
# 🚀 BOTH CE & PE
# -----------------------------------
def get_option_both(index_security_id, strike):

    oc = get_clean_option_chain(index_security_id)

    if not oc:
        return None

    strike = int(float(strike))
    strike_key = str(strike)

    if strike_key in oc:
        return oc[strike_key]

    closest = min(
        oc.keys(),
        key=lambda x: abs(int(x) - strike)
    )

    return oc[closest]


# -----------------------------------
# 🎯 FULL OPTION CHAIN
# -----------------------------------
def get_full_option_chain(index_security_id):

    doc = get_latest_option_chain_doc(index_security_id)

    if not doc:
        return None

    doc["_id"] = str(doc["_id"])

    doc["option_chain"]["oc"] = normalize_strikes(
        doc.get("option_chain", {}).get("oc", {})
    )

    return doc


# -----------------------------------
# 🔥 ATM STRIKE
# -----------------------------------
def get_atm_strike(index_security_id):

    doc = get_latest_option_chain_doc(index_security_id)

    if not doc:
        return None

    last_price = doc.get("option_chain", {}).get("last_price")

    if not last_price:
        return None

    return int(round(last_price / 50) * 50)


# -----------------------------------
# ✅ OPTIONAL: CREATE INDEXES (RUN ONCE)
# -----------------------------------
def create_indexes():
    try:
        col = get_orders_collection()

        col.create_index("created_at")
        col.create_index("status")
        col.create_index("security_id")

        logger.info("✅ Mongo indexes created")

    except Exception as e:
        logger.error(f"[INDEX ERROR] {e}")