"""
In‑memory market data store

KEY DESIGN:
- Keyed by security_id (string)
- Value is full market tick object
- Matches Django Channels + HTML dashboard
"""

# ✅ Global store (security_id → data)
spot_data = {}


def update_spot(security_id: str, data: dict):
    """
    Update latest market data for a security.
    """
    if not security_id or not isinstance(data, dict):
        return

    spot_data[str(security_id)] = data


def get_spot(security_id: str):
    """
    Get latest data for a single security.
    """
    return spot_data.get(str(security_id))


def get_all_spots():
    """
    Get all live market data (used by /live WS).
    """
    return spot_data