import asyncio
import json
import time
import websockets

from app.core.logger import get_logger
from app.market.spot_manager import update_spot, get_all_spots
from app.config import BASE_WS_URL

logger = get_logger("ws_client")

# =========================
# ✅ HEARTBEAT SETTINGS
# =========================
HEARTBEAT_INTERVAL = 300  # 5 minutes (seconds)

# ✅ EXPECTED INDICES (ALWAYS SHOWN)
EXPECTED_INDICES = {
    "13": "NIFTY",
    "51": "SENSEX",
    "21": "INDIA_VIX",
}


async def connect_market():
    """
    ✅ Connect to Django Channels dashboard feed:
       wss://<host>/ws/market/
    ✅ Receives ALL instruments on ONE socket
    ✅ Logs heartbeat every 5 minutes
    """

    url = f"{BASE_WS_URL}/"
    reconnect_delay = 5
    last_heartbeat_ts = 0

    logger.info("🚀 Starting Dashboard WebSocket Client")

    while True:
        try:
            logger.info("=" * 60)
            logger.info("🔌 CONNECTING TO MARKET DASHBOARD FEED")
            logger.info(f"🌐 WS URL → {url}")
            logger.info("=" * 60)

            async with websockets.connect(
                url,
                ping_interval=20,
                ping_timeout=10,
                close_timeout=5,
                max_size=None,
            ) as ws:

                logger.info("✅ CONNECTED TO DASHBOARD FEED")

                async for msg in ws:
                    try:
                        data = json.loads(msg)

                        # ✅ Expect dict payload
                        if not isinstance(data, dict):
                            continue

                        security_id = str(data.get("security_id", "")).strip()
                        if not security_id:
                            continue

                        # ✅ Normalize LTP if present
                        if "LTP" in data:
                            try:
                                data["LTP"] = float(data["LTP"])
                            except Exception:
                                pass

                        # ✅ Store latest tick (keyed by security_id)
                        update_spot(security_id, data)

                        # =========================
                        # ✅ HEARTBEAT LOGIC
                        # =========================
                        now = time.time()

                        if now - last_heartbeat_ts >= HEARTBEAT_INTERVAL:
                            snapshot = get_all_spots()

                            logger.info("💓 HEARTBEAT (5 min)")
                            logger.info("📊 Market Status:")

                            for sid, name in EXPECTED_INDICES.items():
                                tick = snapshot.get(sid)

                                if tick:
                                    ltp = tick.get("LTP")
                                    ltt = tick.get("LTT")
                                    logger.info(
                                        f"   • {name} ({sid}) → LTP={ltp}, Time={ltt}"
                                    )
                                else:
                                    logger.info(
                                        f"   • {name} ({sid}) → WAITING FOR DATA"
                                    )

                            last_heartbeat_ts = now

                    except json.JSONDecodeError:
                        logger.warning("⚠️ Invalid JSON received")

                    except Exception as e:
                        logger.error(f"❌ Message processing error → {e}")

        except Exception as e:
            logger.error(f"❌ WS connection error → {e}")

        logger.info(f"🔄 Reconnecting in {reconnect_delay}s...")
        await asyncio.sleep(reconnect_delay)