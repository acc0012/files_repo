from fastapi import Request
from app.database import collection
from app.utils import get_ist_timestamp, get_today_date_str
import uuid

INDEX_MAP = {
    '13': 'NIFTY',
    '51': 'SENSEX',
    '21': 'INDIA_VIX'
}


async def handle_webhook(webhook_id: str, request: Request):

    # ✅ GENERATE TRACE ID
    trace_id = str(uuid.uuid4())

    # ✅ PARSE REQUEST SAFELY
    try:
        raw = await request.json()
    except Exception:
        return {
            "status": "error",
            "trace_id": trace_id,
            "message": "Invalid JSON"
        }

    parsed = {
        'symbol': raw.get('symbol'),
        'high': raw.get('high'),
        'low': raw.get('low'),
        'avg': raw.get('avg')
    }

    entry = {
        "trace_id": trace_id,  # ✅ IMPORTANT
        "index_id": webhook_id,
        "index_name": INDEX_MAP.get(webhook_id, "UNKNOWN"),
        "timestamp": get_ist_timestamp(),
        "raw_data": raw,
        "parsed_data": parsed
    }

    # ✅ STORE IN MONGO (NON-BLOCKING APPROACH)
    try:
        collection.update_one(
            {"date": get_today_date_str(), "index_id": webhook_id},
            {
                "$push": {"entries": entry},
                "$setOnInsert": {
                    "date": get_today_date_str(),
                    "index_id": webhook_id
                }
            },
            upsert=True
        )

    except Exception as e:
        return {
            "status": "error",
            "trace_id": trace_id,
            "message": f"DB error: {str(e)}"
        }

    # ✅ IMMEDIATE RESPONSE
    return {
        "status": "success",
        "trace_id": trace_id
    }