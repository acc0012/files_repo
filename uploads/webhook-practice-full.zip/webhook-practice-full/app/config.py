import os
from dotenv import load_dotenv

load_dotenv()

MONGO_URL=os.getenv('MONGO_URL')
DB_NAME=os.getenv('DB_NAME')
COLLECTION_NAME=os.getenv('COLLECTION_NAME')
BASE_WS_URL=os.getenv('BASE_WS_URL')

if not BASE_WS_URL:
    raise ValueError("BASE_WS_URL not set in .env")
