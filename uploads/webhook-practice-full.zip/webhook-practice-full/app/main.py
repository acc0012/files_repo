from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse
from contextlib import asynccontextmanager
from pathlib import Path
import asyncio

from app.engine.scheduler import start
from app.webhook.handler import handle_webhook
from app.core.logger import get_logger
from app.market.spot_manager import get_all_spots

logger = get_logger("main")

BASE_DIR = Path(__file__).resolve().parent


# =========================
# ✅ APP LIFECYCLE
# =========================
@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("🚀 App starting...")

    try:
        asyncio.create_task(start())
        logger.info("✅ Market feeds started")
    except Exception as e:
        logger.error(f"❌ Startup error → {str(e)}")

    yield

    logger.info("🛑 App shutdown")


# =========================
# ✅ INIT
# =========================
app = FastAPI(lifespan=lifespan)


# =========================
# ✅ HEALTH CHECK
# =========================
@app.get("/")
def home():
    return {"status": "running"}


# =========================
# ✅ WEBHOOK ENDPOINT
# =========================
@app.post("/webhook/{webhook_id}")
async def webhook(webhook_id: str, request: Request):
    logger.info(f"📩 Webhook received → ID: {webhook_id}")
    return await handle_webhook(webhook_id, request)


# =========================
# ✅ LIVE DATA WEBSOCKET (FIXED)
# =========================
@app.websocket("/live")
async def live_data(ws: WebSocket):
    await ws.accept()
    logger.info("🔗 Client connected to /live")

    try:
        while True:
            data = get_all_spots()

            if not isinstance(data, dict):
                data = {}

            await ws.send_json(data)
            await asyncio.sleep(1)

    except WebSocketDisconnect:
        logger.info("🔌 Client disconnected from /live")

    except Exception as e:
        logger.warning(f"⚠️ Live WS error → {str(e)}")

    finally:
        logger.info("🛑 Stopping /live stream loop")


# =========================
# ✅ DASHBOARD (STATIC HTML)
# =========================
@app.get("/dashboard", response_class=HTMLResponse)
def dashboard():
    try:
        html_path = BASE_DIR / "templates" / "main" / "index.html"
        return HTMLResponse(content=html_path.read_text(encoding="utf-8"))
    except Exception as e:
        logger.error(f"❌ Dashboard load failed → {e}")
        return HTMLResponse(
            content="<h2>Error loading dashboard</h2>",
            status_code=500,
        )


# =========================
# ✅ LIVE RAW UI (STATIC HTML)
# =========================
@app.get("/live-ui", response_class=HTMLResponse)
def live_ui():
    try:
        html_path = BASE_DIR / "templates" / "main" / "live.html"
        return HTMLResponse(content=html_path.read_text(encoding="utf-8"))
    except Exception as e:
        logger.error(f"❌ Live UI load failed → {e}")
        return HTMLResponse(
            content="<h2>Error loading live UI</h2>",
            status_code=500,
        )