import asyncio
from app.market.ws_client import connect_market
from app.core.logger import get_logger

logger = get_logger("scheduler")

async def start():
    logger.info("Starting dashboard feed")
    asyncio.create_task(connect_market())   # ✅ ONLY ONE WS
    while True:
        await asyncio.sleep(5)