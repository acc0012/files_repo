from datetime import datetime
import pytz

IST=pytz.timezone('Asia/Kolkata')

def get_ist_timestamp():
    return datetime.now(IST)

def get_today_date_str():
    return get_ist_timestamp().strftime('%Y-%m-%d')
