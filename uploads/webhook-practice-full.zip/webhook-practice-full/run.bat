@echo off
cls

echo ===============================
echo 🚀 Starting Webhook Project
echo ===============================

REM ✅ Activate virtual environment
call venv\Scripts\activate

echo ✅ Starting FastAPI server...

REM ✅ Run server (port 8000)
uvicorn app.main:app --host 0.0.0.0 --port 8001 --reload
