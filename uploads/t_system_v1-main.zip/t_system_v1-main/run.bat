
cls
python app.py