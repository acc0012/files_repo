from mongo_logger import log_alert, log_system
import threading
import time
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service

from config import TRADINGVIEW_URL, PROFILE_PATH
from session_monitor import SessionMonitor
from chart_tester import ChartTester

app = FastAPI(title="TradingView Automation Controller API")

# Global lifecycle variables managed by the API
automation_driver_instance = None
session_monitor_instance = None
monitor_thread = None
stop_event = threading.Event()


class StrikePayload(BaseModel):
    chart_index: int = Field(
        default=0,
        alias="CHART_INDEX",
        description="0=Call Chart, 1=Put Chart",
    )

    strike: str = Field(
        ...,
        alias="NEAREST_STRIKE",
        description="Target strike value",
    )

    side: str = Field(
        ...,
        alias="STRIKE_TYPE",
        description="CALL or PUT",
    )

    cross: str | None = Field(
        default=None,
        alias="CROSS",
        description="BULLISH, BEARISH, BULLISH_REVERSE, BEARISH_REVERSE",
    )

    buy_trade: bool = Field(
        default=True,
        alias="BUY_TRADE",
        description="Execute Shift+B after strike verification",
    )

    class Config:
        populate_by_name = True        

def background_url_logger(driver):
    """Monitors live URL updates without switching tab focus."""
    previous_url = ""
    while not stop_event.is_set():
        try:
            current_url = driver.current_url
            if current_url != previous_url:
                print(f"\n[BROWSER CONTEXT] -> {current_url}")
                previous_url = current_url
            time.sleep(2)
        except Exception:
            if stop_event.is_set():
                break
            print("[Monitor] Error tracking active browser state elements.")
            break


@app.post("/api/start")
async def start_selenium():
    """
    Spins up the automated Chrome browser profile and background monitors.
    """
    global automation_driver_instance, session_monitor_instance, monitor_thread, stop_event

    if automation_driver_instance is not None:
        return {"success": False, "message": "Browser session is already running."}

    try:
        print("\n[API] Initializing Chrome Driver Session...")
        stop_event.clear()

        options = Options()
        options.add_argument("--start-maximized")
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_experimental_option("useAutomationExtension", False)
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.add_argument(f"--user-data-dir={PROFILE_PATH}")
        options.add_argument("--profile-directory=Default")

        service = Service()
        driver = webdriver.Chrome(service=service, options=options)

        # Obfuscate automation fingerprint signatures
        driver.execute_script(
            "Object.defineProperty(navigator, 'webdriver', {get: () => undefined});"
        )

        print(f"[API] Directing instance to: {TRADINGVIEW_URL}")
        driver.get(TRADINGVIEW_URL)

        automation_driver_instance = driver
        
        log_system(
    {
        "event": "START_BROWSER",
        "status": "SUCCESS",
        "url": TRADINGVIEW_URL,
    }
)

        # Initialize and kick-off system monitors
        session_monitor_instance = SessionMonitor(driver=driver, interval=2)
        session_monitor_instance.start()

        monitor_thread = threading.Thread(
            target=background_url_logger, args=(driver,), daemon=True
        )
        monitor_thread.start()

        return {
            "success": True,
            "message": "Browser started and initialized successfully.",
        }

    except Exception as e:
        automation_driver_instance = None
        raise HTTPException(
            status_code=500, detail=f"Failed to start Selenium: {str(e)}"
        )


@app.post("/api/stop")
async def stop_selenium():
    """
    Gracefully stops all tracking tasks and closes the Chrome instance.
    """
    global automation_driver_instance, session_monitor_instance, monitor_thread, stop_event

    if automation_driver_instance is None:
        return {
            "success": False,
            "message": "No active browser session found to terminate.",
        }

    try:
        print("\n[API] Initiating graceful teardown sequence...")
        stop_event.set()

        if session_monitor_instance:
            session_monitor_instance.stop()
            session_monitor_instance = None

        if monitor_thread:
            monitor_thread.join(timeout=2)
            monitor_thread = None

        print("[API] Closing browser tabs completely...")
        automation_driver_instance.quit()
        automation_driver_instance = None
        log_system(
    {
        "event": "STOP_BROWSER",
        "status": "SUCCESS",
    }
)
        return {"success": True, "message": "Browser session terminated safely."}
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error encountered during termination loop: {str(e)}",
        )

@app.post("/api/change-strike")
async def change_strike_endpoint(payload: StrikePayload):
    global automation_driver_instance

    if automation_driver_instance is None:
        raise HTTPException(
            status_code=503,
            detail="Selenium WebDriver instance is offline. Please hit /api/start first.",
        )

    try:

        log_alert(
            {
                "chartIndex": payload.chart_index,
                "strike": payload.strike,
                "side": payload.side,
                "cross": payload.cross,
                "buyTrade": payload.buy_trade,
            }
        )

        print(
            f"[ALERT] CROSS={payload.cross} "
            f"CHART={payload.chart_index} "
            f"SIDE={payload.side} "
            f"STRIKE={payload.strike}"
        )

        worker = ChartTester(automation_driver_instance)

        execution_response = worker.change_strike_logic(
            chart_index=int(payload.chart_index),
            strike=str(payload.strike),
            side=str(payload.side).lower(),
            buy_trade=bool(payload.buy_trade),
        )

        if not execution_response["success"] and execution_response["error"]:
            raise HTTPException(
                status_code=400,
                detail=execution_response["error"],
            )

        return execution_response

    except Exception as e:

        log_system(
            {
                "event": "API_ERROR",
                "status": "FAILED",
                "error": str(e),
            }
        )

        raise HTTPException(
            status_code=500,
            detail=f"Internal API processing failure: {str(e)}",
        )