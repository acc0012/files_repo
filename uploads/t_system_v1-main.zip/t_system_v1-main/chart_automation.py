import time
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import NoSuchElementException, WebDriverException
import re
from selenium.webdriver.common.keys import Keys

class ChartTester:
    def __init__(self, driver):
        self.driver = driver

    def get_charts(self):
        """Finds all chart container elements on the screen."""
        return self.driver.find_elements(By.CLASS_NAME, "chart-container")

    def get_active_chart(self):
        """Finds the currently active chart container."""
        try:
            return self.driver.find_element(By.CSS_SELECTOR, ".chart-container.active")
        except NoSuchElementException:
            return None

    def get_symbol(self, chart_element=None):
        """Extracts the ticker symbol text from a specific or active chart container."""
        target = chart_element if chart_element else self.get_active_chart()
        if not target:
            return "Unknown"
        try:
            symbol_btn = target.find_element(
                By.CSS_SELECTOR, 'button[aria-label="Change symbol"]'
            )
            return symbol_btn.text.strip()
        except NoSuchElementException:
            return "Unknown"

    def activate_chart(self, index: int) -> bool:
        """
        Activates a chart panel by its index using native ActionChains.
        Mimics pointer down, up, and focus changes over canvas frames.
        """
        all_charts = self.get_charts()
        if index >= len(all_charts):
            raise IndexError(
                f"Chart index {index} out of range. Found {len(all_charts)} charts."
            )

        target_chart = all_charts[index]

        try:
            pane = target_chart.find_element(By.CSS_SELECTOR, '[data-qa-id="pane"]')
        except NoSuchElementException:
            try:
                pane = target_chart.find_element(By.CLASS_NAME, "chart-gui-wrapper")
            except NoSuchElementException:
                pane = target_chart

        # Sequence hardware-level interaction signals across complex canvas bounds
        actions = ActionChains(self.driver)
        actions.move_to_element(pane).click_and_hold().release().perform()

        # Monitor loop ensuring the UI framework shifts focus status
        for _ in range(20):
            if self.get_active_chart() == target_chart:
                return True
            time.sleep(0.1)

        raise WebDriverException(f"Failed to activate chart index: {index}")

    def open_change_symbol(self):
        """Clicks the header toolbar symbol search element."""
        try:
            btn = self.driver.find_element(By.ID, "header-toolbar-symbol-search")
            btn.click()
            time.sleep(0.6)  # Layout overlay animation rendering buffer
        except NoSuchElementException:
            raise NoSuchElementException(
                "Change Symbol toolbar button element not found."
            )

    def click_strike(self, strike: str, side: str) -> bool:
        """
        Locates the option chain element cell, moves it into view,
        and executes an explicit selection event chain.
        """
        selector = f'td[data-row-id="{strike}"][data-cell-part="{side.lower()}"]'

        for _ in range(20):
            try:
                td_cell = self.driver.find_element(By.CSS_SELECTOR, selector)
                if td_cell.is_displayed():
                    # Native scrolling emulation to align element targets
                    actions = ActionChains(self.driver)
                    actions.move_to_element(td_cell).perform()
                    time.sleep(0.1)

                    td_cell.click()
                    return True
            except NoSuchElementException:
                pass
            time.sleep(0.2)

        raise NoSuchElementException(
            f"Strike target option chain row cell not found: {selector}"
        )
    def wait_for_symbol_change(self, old_symbol: str) -> str:
            """Monitors DOM tracking until a new symbol name is detected."""
            for _ in range(40):
                current_symbol = self.get_symbol()

                if current_symbol != old_symbol and current_symbol != "Unknown":
                    return current_symbol

                time.sleep(0.25)

            return self.get_symbol()

    def extract_strike_from_symbol(self, symbol: str):
        """
        Examples:

        NIFTY260630C24200 -> 24200
        NIFTY260630P24150 -> 24150
        BANKNIFTY260630C56000 -> 56000
        """

        try:
            symbol = symbol.strip()

            match = re.search(r'([CP])(\d+)$', symbol)

            if match:
                return match.group(2)

            return None

        except Exception:
            return None

    def place_buy_order(self):
        """
        Execute TradingView BUY hotkey (Shift+B)
        """

        actions = ActionChains(self.driver)

        actions.key_down(Keys.SHIFT)
        actions.send_keys("b")
        actions.key_up(Keys.SHIFT)

        actions.perform()

        time.sleep(0.5)

    def change_strike_logic(
        self,
        chart_index: int,
        strike: str,
        side: str,
        buy_trade: bool = False,
    ) -> dict:

        result = {
            "success": False,
            "chartIndex": chart_index,
            "strike": strike,
            "side": side,
            "oldSymbol": "",
            "newSymbol": "",
            "changed": False,
            "orderPlaced": False,
            "error": None,
        }

        try:

            # ------------------------------------
            # STEP 1 : Activate Target Chart
            # ------------------------------------

            self.activate_chart(chart_index)

            result["oldSymbol"] = self.get_symbol()

            current_strike = self.extract_strike_from_symbol(
                result["oldSymbol"]
            )

            target_strike = str(strike)

            print(
                f"[Strike Check] Current Strike = {current_strike} | Target Strike = {target_strike}"
            )

            # ------------------------------------
            # STEP 2 : Skip Change If Same Strike
            # ------------------------------------

            if current_strike == target_strike:

                print(
                    "[Strike Check] Strike already selected. Skipping strike change."
                )

                result["newSymbol"] = result["oldSymbol"]
                result["changed"] = False
                result["success"] = True

            else:

                print(
                    f"[Strike Change] Switching chart {chart_index} -> Strike {target_strike} {side.upper()}"
                )

                # Open TradingView option chain popup
                self.open_change_symbol()

                # Select target strike
                self.click_strike(
                    strike=target_strike,
                    side=side,
                )

                # Wait until symbol changes
                result["newSymbol"] = self.wait_for_symbol_change(
                    result["oldSymbol"]
                )

                result["changed"] = (
                    result["oldSymbol"]
                    != result["newSymbol"]
                )

                result["success"] = True

            # ------------------------------------
            # STEP 3 : Execute BUY Order
            # ------------------------------------

            if buy_trade:

                print(
                    f"[BUY ORDER] Executing Shift+B on chart index {chart_index}"
                )

                self.place_buy_order()

                result["orderPlaced"] = True

            return result

        except Exception as e:

            result["error"] = str(e)

            return result