from datetime import datetime
from pymongo import MongoClient

from config import MONGO_URL

client = MongoClient(MONGO_URL)

db = client["tv_automation"]

alert_logs = db["alert_logs"]
strike_change_logs = db["strike_change_logs"]
order_logs = db["order_logs"]
system_logs = db["system_logs"]


def log_alert(data):
    data["createdAt"] = datetime.utcnow()
    alert_logs.insert_one(data)


def log_strike_change(data):
    data["createdAt"] = datetime.utcnow()
    strike_change_logs.insert_one(data)


def log_order(data):
    data["createdAt"] = datetime.utcnow()
    order_logs.insert_one(data)


def log_system(data):
    data["createdAt"] = datetime.utcnow()
    system_logs.insert_one(data)