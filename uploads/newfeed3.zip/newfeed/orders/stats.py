from core.db import orders_collection
from core.logger import get_logger

logger = get_logger("order_stats")


def update_order_stats_in_db(order_id: str, stats: dict):
    """
    Update order stats such as:
    - max_points
    - min_points
    - sl_hit
    - t1_hit
    - t2_hit
    - last_price
    - exit_reason
    - closed_at

    This function safely updates MongoDB and logs any issues.
    """

    if not order_id:
        logger.error("update_order_stats_in_db: Missing order_id")
        return False

    if not isinstance(stats, dict):
        logger.error(f"update_order_stats_in_db: Invalid stats format → {stats}")
        return False

    try:
        orders_collection.update_one(
            {"order_id": order_id},
            {"$set": stats}
        )

        logger.info(f"Order stats updated → {order_id}: {stats}")
        return True

    except Exception as e:
        logger.error(f"Failed to update order stats for {order_id}: {e}", exc_info=True)
        return False