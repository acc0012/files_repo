from django.urls import path
from .views import get_orders
from .views import get_latest_live_order,update_order_stats


urlpatterns = [
    path("orders/", get_orders),
    path("latest-live", get_latest_live_order),
    path("update-stats", update_order_stats)
]