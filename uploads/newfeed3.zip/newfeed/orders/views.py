from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json

from core.db import orders_collection
from core.logger import get_logger

logger = get_logger("orders_api")


# =====================================================
# ✅ GET ORDERS WITH PAGINATION + LIVE IDENTIFICATION
# =====================================================
def get_orders(request):
    try:
        # ✅ Safe parsing
        try:
            page = int(request.GET.get("page", 1))
        except Exception:
            page = 1

        try:
            limit = int(request.GET.get("limit", 10))
        except Exception:
            limit = 10

        source = request.GET.get("source", "ALL")

        if page < 1:
            page = 1
        if limit < 1:
            limit = 10

        skip = (page - 1) * limit

        # ✅ Query filter
        query = {}
        if source and source != "ALL":
            query["source"] = source.upper()

        # ✅ Fetch orders
        cursor = (
            orders_collection
            .find(query)
            .sort("created_at", -1)
            .skip(skip)
            .limit(limit)
        )

        orders = []

        for o in cursor:
            try:
                o["_id"] = str(o["_id"])
            except Exception:
                pass

            # ✅ Safe security_id extraction
            security_id = None
            option_data = o.get("option_data")

            if isinstance(option_data, dict):
                security_id = option_data.get("security_id")

            o["security_id"] = security_id

            orders.append(o)

        # ✅ Counts
        total = orders_collection.count_documents(query)

        placed_count = orders_collection.count_documents({
            **query,
            "status": "PLACED"
        })

        ignored_count = orders_collection.count_documents({
            **query,
            "status": "IGNORED"
        })

        failed_count = orders_collection.count_documents({
            **query,
            "status": "FAILED"
        })

        # =====================================================
        # ✅ GET LATEST PLACED ORDER FOR LIVE FEED
        # =====================================================
        latest_order = orders_collection.find_one(
            {
                **query,
                "status": "PLACED",
                "option_data.security_id": {"$ne": None}
            },
            sort=[("created_at", -1)]
        )

        latest_order_id = None
        latest_security_id = None

        if latest_order:
            latest_order_id = latest_order.get("order_id")

            option_data = latest_order.get("option_data")
            if isinstance(option_data, dict):
                latest_security_id = option_data.get("security_id")

        return JsonResponse({
            "page": page,
            "limit": limit,
            "total": total,

            # ✅ status counts
            "placed": placed_count,
            "ignored": ignored_count,
            "failed": failed_count,

            # ✅ LIVE FIELDS
            "latest_order_id": latest_order_id,
            "latest_security_id": latest_security_id,

            # ✅ data
            "data": orders
        })

    except Exception as e:
        logger.error(f"/api/orders error: {str(e)}", exc_info=True)
        return JsonResponse({"error": "Internal server error"}, status=500)


# =====================================================
# ✅ GET ONLY LATEST LIVE ORDER (OPTIONAL API)
# =====================================================
def get_latest_live_order(request):
    try:
        order = orders_collection.find_one(
            {
                "status": "PLACED",
                "option_data.security_id": {"$ne": None}
            },
            sort=[("created_at", -1)]
        )

        if not order:
            return JsonResponse({"live": False})

        try:
            order["_id"] = str(order["_id"])
        except Exception:
            pass

        option_data = order.get("option_data", {})

        return JsonResponse({
            "live": True,
            "order_id": order.get("order_id"),
            "security_id": option_data.get("security_id"),
            "symbol": order.get("symbol"),
            "strike": order.get("strike"),
        })

    except Exception as e:
        logger.error(f"/api/latest-live error: {str(e)}", exc_info=True)
        return JsonResponse({"error": "Internal server error"}, status=500)


# =====================================================
# 🆕 NEW: UPDATE ORDER STATS (SL/TARGET/MAXPOINTS/MINPOINTS)
# =====================================================
@csrf_exempt
def update_order_stats(request):
    if request.method != "POST":
        return JsonResponse({"error": "Invalid request method"}, status=400)

    try:
        data = json.loads(request.body)

        order_id = data.get("order_id")
        updates = data.get("updates", {})

        if not order_id:
            return JsonResponse({"error": "order_id is required"}, status=400)

        # Update order stats in MongoDB
        orders_collection.update_one(
            {"order_id": order_id},
            {"$set": updates}
        )

        logger.info(f"Stats updated for {order_id} → {updates}")

        return JsonResponse({"ok": True})

    except Exception as e:
        logger.error(f"update_order_stats error → {str(e)}", exc_info=True)
        return JsonResponse({"error": "Internal server error"}, status=500)