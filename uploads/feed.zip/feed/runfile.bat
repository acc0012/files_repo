@REM uvicorn trading_project.asgi:application --host 0.0.0.0 --port 8000

python manage.py runserver 0.0.0.0:8000