# Root Orders Dashboard Setup

This adds:

- `/` root dashboard page
- Bootstrap UI
- Live/light order table
- MongoDB order fetch
- Status badges
- Auto refresh every 5s

Uses your existing Mongo helper:

`get_orders_collection()` from `core/db.py`

---

# 1️⃣ Create `core/views/dashboard.py`

```python
from django.shortcuts import render
from core.db import get_orders_collection


# -------------------------------------------------
# 🔥 ROOT DASHBOARD
# -------------------------------------------------
def dashboard_view(request):

    collection = get_orders_collection()

    # latest first
    orders = list(
        collection.find().sort("created_at", -1)
    )

    # convert _id to string
    for o in orders:
        o["_id"] = str(o["_id"])

    return render(
        request,
        "dashboard.html",
        {
            "orders": orders
        }
    )
```

---

# 2️⃣ Create `templates/dashboard.html`

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>T Order Dashboard</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">

    <style>

        body {
            background: #f4f7fb;
            font-family: Inter, sans-serif;
        }

        .topbar {
            background: white;
            border-bottom: 1px solid #e9ecef;
            padding: 18px 24px;
            margin-bottom: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.03);
        }

        .title {
            font-size: 28px;
            font-weight: 700;
            color: #1f2937;
        }

        .sub {
            color: #6b7280;
            font-size: 14px;
        }

        .stats-card {
            border: none;
            border-radius: 18px;
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.04);
        }

        .stats-number {
            font-size: 28px;
            font-weight: 700;
        }

        .table-card {
            background: white;
            border-radius: 20px;
            padding: 20px;
            box-shadow: 0 2px 14px rgba(0,0,0,0.04);
        }

        .table thead th {
            background: #f8fafc;
            border: none;
            color: #6b7280;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: .5px;
        }

        .table tbody td {
            vertical-align: middle;
            border-color: #f1f5f9;
            font-size: 14px;
        }

        .badge-soft-success {
            background: #dcfce7;
            color: #15803d;
            padding: 8px 12px;
            border-radius: 30px;
        }

        .badge-soft-danger {
            background: #fee2e2;
            color: #b91c1c;
            padding: 8px 12px;
            border-radius: 30px;
        }

        .badge-soft-warning {
            background: #fef3c7;
            color: #b45309;
            padding: 8px 12px;
            border-radius: 30px;
        }

        .live-dot {
            width: 10px;
            height: 10px;
            background: #22c55e;
            border-radius: 50%;
            display: inline-block;
            margin-right: 8px;
            animation: pulse 1.5s infinite;
        }

        @keyframes pulse {
            0% {
                transform: scale(1);
                opacity: 1;
            }
            50% {
                transform: scale(1.4);
                opacity: .6;
            }
            100% {
                transform: scale(1);
                opacity: 1;
            }
        }

        .small-text {
            font-size: 12px;
            color: #64748b;
        }

    </style>
</head>
<body>

    <div class="topbar d-flex justify-content-between align-items-center">

        <div>
            <div class="title">
                <span class="live-dot"></span>
                T Order Dashboard
            </div>

            <div class="sub">
                Live MongoDB Orders Monitor
            </div>
        </div>

        <div>
            <button class="btn btn-primary rounded-pill px-4">
                <i class="bi bi-arrow-clockwise"></i>
                Auto Refresh 5s
            </button>
        </div>

    </div>

    <div class="container-fluid px-4">

        <div class="row mb-4">

            <div class="col-md-3 mb-3">
                <div class="card stats-card p-3">
                    <div class="small-text">Total Orders</div>
                    <div class="stats-number">{{ orders|length }}</div>
                </div>
            </div>

            <div class="col-md-3 mb-3">
                <div class="card stats-card p-3">
                    <div class="small-text">Placed</div>
                    <div class="stats-number text-success">
                        {{ orders|length }}
                    </div>
                </div>
            </div>

            <div class="col-md-3 mb-3">
                <div class="card stats-card p-3">
                    <div class="small-text">Live Feed</div>
                    <div class="stats-number text-primary">ACTIVE</div>
                </div>
            </div>

            <div class="col-md-3 mb-3">
                <div class="card stats-card p-3">
                    <div class="small-text">Database</div>
                    <div class="stats-number text-warning">MongoDB</div>
                </div>
            </div>

        </div>

        <div class="table-card">

            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="mb-0">Orders</h4>

                <input
                    type="text"
                    class="form-control w-25"
                    placeholder="Search order..."
                    id="searchInput"
                >
            </div>

            <div class="table-responsive">

                <table class="table align-middle">

                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Security</th>
                            <th>Strike</th>
                            <th>Type</th>
                            <th>Status</th>
                            <th>Entry</th>
                            <th>LTP</th>
                            <th>Created</th>
                        </tr>
                    </thead>

                    <tbody id="ordersTable">

                        {% for o in orders %}

                        <tr>

                            <td>
                                <strong>{{ o.order_id }}</strong>
                            </td>

                            <td>
                                {{ o.security_id }}
                            </td>

                            <td>
                                {{ o.strike }}
                            </td>

                            <td>
                                {% if o.option_type == 'ce' %}
                                    <span class="badge bg-success">CE</span>
                                {% else %}
                                    <span class="badge bg-danger">PE</span>
                                {% endif %}
                            </td>

                            <td>

                                {% if o.status == 'placed' %}
                                    <span class="badge-soft-success">
                                        {{ o.status }}
                                    </span>

                                {% elif o.status == 'failed' %}
                                    <span class="badge-soft-danger">
                                        {{ o.status }}
                                    </span>

                                {% else %}
                                    <span class="badge-soft-warning">
                                        {{ o.status }}
                                    </span>
                                {% endif %}

                            </td>

                            <td>
                                {{ o.entry_price|default:'-' }}
                            </td>

                            <td>
                                {% if o.quote_data %}
                                    {{ o.quote_data.LTP }}
                                {% else %}
                                    -
                                {% endif %}
                            </td>

                            <td>
                                <span class="small-text">
                                    {{ o.created_at }}
                                </span>
                            </td>

                        </tr>

                        {% endfor %}

                    </tbody>

                </table>

            </div>

        </div>

    </div>

    <script>

        // auto refresh
        setTimeout(() => {
            window.location.reload();
        }, 5000);


        // search
        const searchInput = document.getElementById('searchInput');

        searchInput.addEventListener('keyup', function() {

            const value = this.value.toLowerCase();

            const rows = document.querySelectorAll('#ordersTable tr');

            rows.forEach(row => {

                if (row.innerText.toLowerCase().includes(value)) {
                    row.style.display = '';
                }
                else {
                    row.style.display = 'none';
                }

            });

        });

    </script>

</body>
</html>
```

---

# 3️⃣ Modify `TSystem/settings.py`

Find:

```python
TEMPLATES = [
```

Change `DIRS` to:

```python
"DIRS": [BASE_DIR / "templates"],
```

---

# 4️⃣ Modify `TSystem/urls.py`

```python
from django.contrib import admin
from django.urls import path, include

from core.views.dashboard import dashboard_view

urlpatterns = [

    # ROOT DASHBOARD
    path("", dashboard_view),

    path("admin/", admin.site.urls),

    # API ROUTES
    path("api/", include("core.urls")),
    path("webhook/", include("webhook.urls")),
    path("market/", include("marketfeed.urls")),
]
```

---

# 5️⃣ Run Server

```bash
python manage.py runserver 0.0.0.0:8000
```

---

# 6️⃣ Open Dashboard

```text
http://127.0.0.1:8000/
```

or VPS:

```text
http://YOUR_IP:8000/
```

---

# Dashboard Features

✅ Bootstrap UI

✅ MongoDB order viewer

✅ Auto refresh

✅ Search box

✅ Status badges

✅ CE/PE colors

✅ Live modern layout

✅ Mobile responsive

✅ Entry price display

✅ Latest LTP display

