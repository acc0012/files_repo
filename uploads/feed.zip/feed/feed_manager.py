import os
import threading
import asyncio
import time
from dotenv import load_dotenv
from dhanhq import marketfeed
from datetime import datetime
from websockets.exceptions import ConnectionClosedError

# =====================
# CONFIG
# =====================
TEST_LOG = False
RECONNECT_DELAY = 3  # seconds

def log(msg):
    if TEST_LOG:
        print(f"[FEED {datetime.now().strftime('%H:%M:%S')}] {msg}")

# =====================

load_dotenv()

CLIENT_ID = os.getenv("CLIENT_ID")
ACCESS_TOKEN = os.getenv("ACCESS_TOKEN")

# Subscribe internally to BOTH Ticker and Quote
ALLOWED_SECURITIES = {
    "13": [
        (marketfeed.IDX, "13", marketfeed.Ticker),
        (marketfeed.IDX, "13", marketfeed.Quote),
    ],
    "21": [
        (marketfeed.IDX, "21", marketfeed.Ticker),
        (marketfeed.IDX, "21", marketfeed.Quote),
    ],
    "51": [
        (marketfeed.IDX, "51", marketfeed.Ticker),
        (marketfeed.IDX, "51", marketfeed.Quote),
    ],
    "5024": [
        (marketfeed.IDX, "5024", marketfeed.Ticker),
        (marketfeed.IDX, "5024", marketfeed.Quote),
    ],
}

# (security_id, mode) -> websocket callbacks
SUBSCRIBERS = {
    (sid, "ticker"): set()
    for sid in ALLOWED_SECURITIES
} | {
    (sid, "quote"): set()
    for sid in ALLOWED_SECURITIES
}


def build_instruments():
    instruments = []
    for subs in ALLOWED_SECURITIES.values():
        instruments.extend(subs)
    return instruments


class FeedManager:
    def start(self):
        log("FeedManager thread started")

        # 🔁 Permanent reconnect loop
        while True:
            try:
                # ✅ Create private asyncio loop for dhanhq
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)

                feed = marketfeed.DhanFeed(
                    CLIENT_ID,
                    ACCESS_TOKEN,
                    build_instruments(),
                    version="v2",
                )

                log("Connecting to Dhan WebSocket...")
                feed.run_forever()
                log("✅ Dhan feed connected")

                # Main data-consumption loop
                while True:
                    msg = feed.get_data()
                    if not msg:
                        continue

                    sid = str(msg.get("security_id"))
                    msg_type = msg.get("type")

                    if msg_type == "Ticker Data":
                        key = (sid, "ticker")
                    elif msg_type == "Quote Data":
                        key = (sid, "quote")
                    else:
                        continue

                    if key not in SUBSCRIBERS:
                        continue

                    if not SUBSCRIBERS[key]:
                        continue

                    for callback in list(SUBSCRIBERS[key]):
                        callback(msg)

            except ConnectionClosedError:
                log("❌ Dhan feed connection lost. Reconnecting...")
                time.sleep(RECONNECT_DELAY)

            except Exception as e:
                log(f"❌ Unexpected error: {e}")
                time.sleep(RECONNECT_DELAY)


feed_manager = FeedManager()


def start_feed_thread():
    """
    Start feed thread exactly once:
    - With --reload → only child process
    - Without --reload → always
    """
    is_reload_child = os.environ.get("RUN_MAIN") == "true"
    is_prod = "RUN_MAIN" not in os.environ

    if not (is_reload_child or is_prod):
        return

    log("Starting feed background thread")
    t = threading.Thread(
        target=feed_manager.start,
        daemon=True
    )
    t.start()
