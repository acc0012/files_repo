import logging
import os
import sys
from logging.handlers import RotatingFileHandler

LOG_FILE = "logs/app.log"


def get_logger(name="app_logger"):
    logger = logging.getLogger(name)

    # جلوگیری duplicate handlers
    if logger.handlers:
        return logger

    logger.setLevel(logging.INFO)

    # -----------------------------------
    # 📁 Ensure logs folder exists
    # -----------------------------------
    os.makedirs("logs", exist_ok=True)

    # -----------------------------------
    # 🔧 FORCE UTF-8 (CRITICAL FIX)
    # -----------------------------------
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

    # -----------------------------------
    # 📄 File Handler (UTF-8 SAFE)
    # -----------------------------------
    file_handler = RotatingFileHandler(
        LOG_FILE,
        maxBytes=5_000_000,
        backupCount=3,
        encoding="utf-8"   # ✅ IMPORTANT
    )

    # -----------------------------------
    # 🖥 Console Handler (UTF-8 SAFE)
    # -----------------------------------
    console_handler = logging.StreamHandler(sys.stdout)

    # -----------------------------------
    # 🎨 Formatter
    # -----------------------------------
    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
    )

    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)

    # -----------------------------------
    # ➕ Add handlers
    # -----------------------------------
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    # جلوگیری propagation (duplicate logs)
    logger.propagate = False

    return logger


# -----------------------------------
# ✅ GLOBAL LOGGER (SAFE)
# -----------------------------------
logger = get_logger()