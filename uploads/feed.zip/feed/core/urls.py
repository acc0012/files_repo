from django.urls import path
from core.views.option_chain_data import (
    option_chain_view,
    option_chain_both_view,
    option_chain_atm_view,
    full_option_chain_view
)

urlpatterns = [
    path("option-chain/", option_chain_view),
    path("option-chain/both/", option_chain_both_view),
    path("option-chain/atm/", option_chain_atm_view),
    path("option-chain/full/", full_option_chain_view),
]