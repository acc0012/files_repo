from django.http import JsonResponse
from django.views.decorators.http import require_GET, require_POST
from django.views.decorators.csrf import csrf_exempt
import json

from core.db import (
    get_option_data_from_symbol,
    get_option_both,
    get_atm_strike,
    get_index_security_id_from_symbol,
    get_full_option_chain,
    get_clean_option_chain
)


# -----------------------------------
# ✅ SINGLE OPTION DATA (SMART RESPONSE)
# -----------------------------------
@csrf_exempt
@require_POST
def option_chain_view(request):
    try:
        body = json.loads(request.body)
    except Exception:
        return JsonResponse({"error": "Invalid JSON"}, status=400)

    symbol = body.get("symbol")
    strike = body.get("strike")
    option_type = body.get("type", "pe")

    # ✅ optional controls
    full = body.get("full", False)
    fields = body.get("fields")  # list

    if not symbol or not strike:
        return JsonResponse(
            {"error": "symbol and strike are required"},
            status=400
        )

    data = get_option_data_from_symbol(symbol, strike, option_type)

    if not data:
        return JsonResponse({"error": "No data found"}, status=404)

    strike = int(float(strike))

    # ✅ custom fields
    if fields and isinstance(fields, list):
        filtered = {
            f: data.get(f)
            for f in fields
            if f in data
        }

        return JsonResponse({
            "symbol": symbol.upper(),
            "strike": strike,
            "type": option_type.lower(),
            "data": filtered
        })

    # ✅ default (light)
    if not full:
        return JsonResponse({
            "symbol": symbol.upper(),
            "strike": strike,
            "type": option_type.lower(),
            "security_id": data.get("security_id")
        })

    # ✅ full
    return JsonResponse({
        "symbol": symbol.upper(),
        "strike": strike,
        "type": option_type.lower(),
        "data": data
    })

# -----------------------------------
# ✅ BOTH CE & PE (SMART)
# -----------------------------------
@require_GET
def option_chain_both_view(request):
    symbol = request.GET.get("symbol")
    strike = request.GET.get("strike")

    if not symbol or not strike:
        return JsonResponse(
            {"error": "symbol and strike are required"},
            status=400
        )

    index_security_id = get_index_security_id_from_symbol(symbol)

    if not index_security_id:
        return JsonResponse({"error": "Invalid symbol"}, status=400)

    data = get_option_both(
        index_security_id=index_security_id,
        strike=strike
    )

    if not data:
        return JsonResponse({"error": "No data found"}, status=404)

    strike = int(float(strike))

    # ✅ Only return security_ids (lightweight)
    return JsonResponse({
        "symbol": symbol.upper(),
        "strike": strike,
        "ce_security_id": data.get("ce", {}).get("security_id"),
        "pe_security_id": data.get("pe", {}).get("security_id")
    })


# -----------------------------------
# ✅ ATM STRIKE
# -----------------------------------
@require_GET
def option_chain_atm_view(request):
    symbol = request.GET.get("symbol")

    if not symbol:
        return JsonResponse({"error": "symbol is required"}, status=400)

    index_security_id = get_index_security_id_from_symbol(symbol)

    if not index_security_id:
        return JsonResponse({"error": "Invalid symbol"}, status=400)

    atm = get_atm_strike(index_security_id)

    if not atm:
        return JsonResponse({"error": "Unable to fetch ATM"}, status=404)

    return JsonResponse({
        "symbol": symbol.upper(),
        "atm_strike": atm
    })


# -----------------------------------
# ✅ FULL OPTION CHAIN
# -----------------------------------
@require_GET
def full_option_chain_view(request):
    symbol = request.GET.get("symbol")

    if not symbol:
        return JsonResponse({"error": "symbol is required"}, status=400)

    index_security_id = get_index_security_id_from_symbol(symbol)

    if not index_security_id:
        return JsonResponse({"error": "Invalid symbol"}, status=400)

    doc = get_full_option_chain(index_security_id)

    if not doc:
        return JsonResponse({"error": "No data found"}, status=404)

    return JsonResponse(doc, safe=False)


# -----------------------------------
# ✅ FILTER API (POST - SMART)
# -----------------------------------
@csrf_exempt
@require_POST
def option_chain_filter_view(request):
    try:
        body = json.loads(request.body)
    except Exception:
        return JsonResponse({"error": "Invalid JSON"}, status=400)

    symbol = body.get("symbol")
    strike = body.get("strike")
    option_type = body.get("type", "ce")

    # ✅ controls
    full = body.get("full", False)
    fields = body.get("fields")  # list expected

    if not symbol or not strike:
        return JsonResponse(
            {"error": "symbol and strike required"},
            status=400
        )

    index_security_id = get_index_security_id_from_symbol(symbol)

    if not index_security_id:
        return JsonResponse({"error": "Invalid symbol"}, status=400)

    oc = get_clean_option_chain(index_security_id)

    if not oc:
        return JsonResponse(
            {"error": "No option chain data"},
            status=404
        )

    try:
        strike = int(float(strike))
    except Exception:
        return JsonResponse({"error": "Invalid strike"}, status=400)

    strike_key = str(strike)

    # ✅ nearest fallback
    if strike_key not in oc:
        try:
            strike_key = min(
                oc.keys(),
                key=lambda x: abs(int(x) - strike)
            )
        except Exception:
            return JsonResponse({"error": "Strike not found"}, status=404)

    option_data = oc[strike_key].get(option_type.lower())

    if not option_data:
        return JsonResponse(
            {"error": f"{option_type.upper()} not found"},
            status=404
        )

    strike_key_int = int(strike_key)

    # ✅ fields filter
    if fields and isinstance(fields, list):
        filtered = {
            f: option_data.get(f)
            for f in fields
            if f in option_data
        }

        return JsonResponse({
            "symbol": symbol.upper(),
            "strike": strike_key_int,
            "type": option_type.lower(),
            "data": filtered
        })

    # ✅ light response
    if not full:
        return JsonResponse({
            "symbol": symbol.upper(),
            "strike": strike_key_int,
            "type": option_type.lower(),
            "security_id": option_data.get("security_id")
        })

    # ✅ full response
    return JsonResponse({
        "symbol": symbol.upper(),
        "strike": strike_key_int,
        "type": option_type.lower(),
        "data": option_data
    })