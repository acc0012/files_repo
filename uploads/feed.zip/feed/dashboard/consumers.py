# dashboard/consumers.py
from channels.generic.websocket import AsyncWebsocketConsumer
import json

class LiveConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        await self.channel_layer.group_add("live_feed", self.channel_name)
        await self.accept()

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard("live_feed", self.channel_name)

    async def send_price(self, event):
        await self.send(text_data=json.dumps(event["data"]))
