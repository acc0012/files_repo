from django.urls import path
from .views import orders_view, orders_api

urlpatterns = [
    path("", orders_view, name="dashboard"),
    path("api/orders/", orders_api, name="orders_api"),

    path("", orders_view, name="dashboard"),
    path("api/orders/", orders_api),
]