from django.shortcuts import render
from django.http import JsonResponse
from core.db import get_orders_collection
from marketfeed.state import get_price  # ✅ we will create this next


# ✅ UI page
def orders_view(request):
    return render(request, "dashboard/orders.html")


# ✅ API returning Mongo orders
def orders_api(request):
    col = get_orders_collection()

    docs = list(col.find().sort("created_at", -1).limit(100))

    for d in docs:
        d["_id"] = str(d["_id"])

        # ✅ attach live price
        sec_id = d.get("security_id")
        d["ltp"] = get_price(sec_id)

    return JsonResponse(docs, safe=False)