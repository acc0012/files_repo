from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST

import json
from threading import Thread

from webhook.utils import generate_temp_id
from webhook.tasks import process_webhook_async

from core.logger import get_logger

logger = get_logger("webhook")


# -------------------------------------------------
# 🔥 MAIN WEBHOOK ENDPOINT
# -------------------------------------------------
@csrf_exempt
@require_POST
def webhook_view(request, index_security_id):
    """
    Receives TradingView webhook messages.

    Example:
    {
      "message":"Break_Sup Price=24476.05 Type=buyCE Strike=24450 Time=2026-05-07 15:08"
    }

    Flow:
    Webhook
        ↓
    Parse Message
        ↓
    Extract Strike + CE/PE
        ↓
    Get security_id from Mongo Option Chain
        ↓
    Subscribe Feed
        ↓
    Start WebSocket Feed
    """

    # -------------------------------------------------
    # 1️⃣ Parse JSON Body
    # -------------------------------------------------
    try:
        body = json.loads(request.body)

    except Exception as e:
        logger.error(f"Invalid JSON: {e}")

        return JsonResponse({
            "status": "error",
            "error": "Invalid JSON"
        }, status=400)

    # -------------------------------------------------
    # 2️⃣ Extract Message
    # -------------------------------------------------
    message = body.get("message")

    if not message:
        return JsonResponse({
            "status": "error",
            "error": "message field required"
        }, status=400)

    # -------------------------------------------------
    # 3️⃣ Generate Temp Request ID
    # -------------------------------------------------
    temp_id = generate_temp_id()

    logger.info(
        f"[WEBHOOK RECEIVED] "
        f"Index={index_security_id} "
        f"ReqID={temp_id} "
        f"Message={message}"
    )

    # -------------------------------------------------
    # 4️⃣ Run Background Processing
    # -------------------------------------------------
    try:
        thread = Thread(
            target=process_webhook_async,
            args=(
                index_security_id,
                message,
                temp_id
            ),
            daemon=True
        )

        thread.start()

    except Exception as e:
        logger.error(
            f"[THREAD ERROR] ReqID={temp_id} Error={e}"
        )

        return JsonResponse({
            "status": "error",
            "req_id": temp_id,
            "error": "Unable to start processing"
        }, status=500)

    # -------------------------------------------------
    # 5️⃣ Fast Immediate Response
    # -------------------------------------------------
    return JsonResponse({
        "status": "received",
        "req_id": temp_id,
        "index_security_id": index_security_id,
        "message": message
    })