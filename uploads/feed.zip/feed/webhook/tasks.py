import traceback,time

from webhook.services import (
    parse_webhook_message,
    get_last_order,
    save_order
)

from webhook.utils import generate_order_id

from core.db import get_option_data
from core.logger import get_logger
from marketfeed.services import close_all_feeds_except

from marketfeed.subscriber import subscribe_security
from marketfeed.services import start_feed_ws


logger = get_logger("webhook_tasks")


# -------------------------------------------------
# 🔥 PROCESS WEBHOOK ASYNC
# -------------------------------------------------
def process_webhook_async(
    index_security_id,
    message,
    temp_id
):
    """
    Background processing of webhook.

    FLOW:
    -------------------------------------------------

    Webhook Message
        ↓
    Parse message
        ↓
    Extract strike + CE/PE
        ↓
    Get security_id from Mongo option chain
        ↓
    Check duplicate order
        ↓
    Save order
        ↓
    Subscribe feed
        ↓
    Start websocket

    -------------------------------------------------
    """

    try:

        logger.info(
            f"[PROCESS START] "
            f"ReqID={temp_id}"
        )

        # -------------------------------------------------
        # STEP 1️⃣ PARSE WEBHOOK MESSAGE
        # -------------------------------------------------
        parsed = parse_webhook_message(message)

        if not parsed:

            logger.error(
                f"[PARSE FAILED] "
                f"ReqID={temp_id}"
            )

            order_id = generate_order_id("failed")

            save_order({
                "order_id": order_id,
                "temp_id": temp_id,

                "index_security_id": index_security_id,

                "status": "failed",
                "reason": "Parsing failed",

                "raw_message": message
            })

            return

        strike = parsed["strike"]

        order_type = parsed["type"]   # buyCE / buyPE

        option_type = (
            "pe"
            if "PE" in order_type.upper()
            else "ce"
        )

        logger.info(
            f"[PARSED] "
            f"ReqID={temp_id} "
            f"Strike={strike} "
            f"OrderType={order_type}"
        )

        # -------------------------------------------------
        # STEP 2️⃣ FETCH OPTION CHAIN DATA
        # -------------------------------------------------
        option_data = get_option_data(
            index_security_id=index_security_id,
            strike=strike,
            option_type=option_type
        )

        if not option_data:

            logger.error(
                f"[OPTION DATA NOT FOUND] "
                f"ReqID={temp_id}"
            )

            order_id = generate_order_id("failed")

            save_order({
                "order_id": order_id,
                "temp_id": temp_id,

                "index_security_id": index_security_id,

                "status": "failed",
                "reason": "Security ID not found",

                "strike": strike,
                "order_type": order_type,

                "raw_message": message
            })

            return

        # -------------------------------------------------
        # STEP 3️⃣ SECURITY ID
        # -------------------------------------------------
        security_id = option_data.get("security_id")

        if not security_id:

            logger.error(
                f"[SECURITY ID MISSING] "
                f"ReqID={temp_id}"
            )

            order_id = generate_order_id("failed")

            save_order({
                "order_id": order_id,
                "temp_id": temp_id,

                "index_security_id": index_security_id,

                "status": "failed",
                "reason": "security_id missing",

                "strike": strike,
                "order_type": order_type,

                "raw_message": message
            })

            return

        logger.info(
            f"[SECURITY FOUND] "
            f"ReqID={temp_id} "
            f"SecurityID={security_id}"
        )

        # -------------------------------------------------
        # STEP 4️⃣ LAST ORDER CHECK
        # -------------------------------------------------
        last_order = get_last_order(index_security_id)

        status = "placed"

        if last_order:

            last_type = last_order.get("type")

            if last_type == order_type:

                status = "ignored"

                logger.info(
                    f"[IGNORED ORDER] "
                    f"ReqID={temp_id} "
                    f"LastType={last_type}"
                )

        # -------------------------------------------------
        # STEP 5️⃣ GENERATE ORDER ID
        # -------------------------------------------------
        order_id = generate_order_id(status)

        # -------------------------------------------------
        # STEP 6️⃣ SAVE ORDER
        # -------------------------------------------------
        order_doc = {
            "order_id": order_id,
            "temp_id": temp_id,

            "index_security_id": index_security_id,

            "strike": strike,

            "type": order_type,
            "option_type": option_type,

            "security_id": security_id,

            "event": parsed.get("event"),
            "price": parsed.get("price"),
            "time": parsed.get("time"),

            "status": status,

            "raw_message": message
        }

        save_order(order_doc)

        logger.info(
            f"[ORDER SAVED] "
            f"OrderID={order_id} "
            f"Status={status}"
        )

        # -------------------------------------------------
        # STEP 7️⃣ START FEED IF PLACED
        # -------------------------------------------------
        if status == "placed":

            logger.info(
                f"[SUBSCRIBING] "
                f"SecurityID={security_id}"
            )

            # ---------------------------------------------
            # 1) Subscribe Railway Feed Backend
            # ---------------------------------------------
            sub_response = subscribe_security(
                index_security_id,
                security_id
            )

            logger.info(
                f"[SUBSCRIBE RESPONSE] "
                f"{sub_response}"
            )

            # ---------------------------------------------
            # 2) Start Local WebSocket Feed
            # ---------------------------------------------

            # ✅ FIRST close everything
            close_all_feeds_except(security_id)

            # ✅ WAIT for cleanup
            time.sleep(1)

            # ✅ THEN start new feed
            start_feed_ws(security_id)

            logger.info(
                f"[WS STARTED] "
                f"SecurityID={security_id}"
            )

        else:

            logger.info(
                f"[NO FEED STARTED] "
                f"Order ignored"
            )

        logger.info(
            f"[PROCESS COMPLETE] "
            f"ReqID={temp_id}"
        )

    except Exception as e:

        logger.error(
            f"[PROCESS FAILED] "
            f"ReqID={temp_id} "
            f"Error={e}"
        )

        logger.error(traceback.format_exc())
        
        