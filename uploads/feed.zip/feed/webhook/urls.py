from django.urls import path
from webhook.views import webhook_view

urlpatterns = [
    path("<int:index_security_id>/", webhook_view),
]