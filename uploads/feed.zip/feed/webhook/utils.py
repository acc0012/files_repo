import re
import uuid
from datetime import datetime


# -------------------------------------------------
# 🔥 TEMP REQUEST ID
# -------------------------------------------------
def generate_temp_id():
    """
    Example:
    tmp_20260508_001522_ab12
    """

    return (
        "tmp_"
        + datetime.now().strftime("%Y%m%d_%H%M%S_")
        + uuid.uuid4().hex[:4]
    )


# -------------------------------------------------
# 🔥 ORDER ID
# -------------------------------------------------
def generate_order_id(order_type):
    """
    order_type:
        placed
        ignored
        failed

    Example:
        ord_ab12cd
        ign_45ff21
        fail_98aa10
    """

    prefix = {
        "placed": "ord_",
        "ignored": "ign_",
        "failed": "fail_"
    }.get(order_type, "ord_")

    return prefix + uuid.uuid4().hex[:6]


# -------------------------------------------------
# 🔥 PARSE WEBHOOK MESSAGE
# -------------------------------------------------
def parse_webhook_message(message):
    """
    Example Input:
    -------------------------------------------------

    Break_Sup Price=24476.05 Type=buyCE Strike=24450 Time=2026-05-07 15:08

    -------------------------------------------------

    Returns:
    {
        "event": "Break_Sup",
        "price": 24476.05,
        "type": "buyCE",
        "option_type": "ce",
        "strike": 24450,
        "time": "2026-05-07 15:08"
    }
    """

    if not message:
        return None

    try:

        # -------------------------------------------------
        # EVENT
        # -------------------------------------------------
        event = message.split(" ")[0].strip()

        # -------------------------------------------------
        # PRICE
        # -------------------------------------------------
        price_match = re.search(
            r"Price=([0-9.]+)",
            message
        )

        price = (
            float(price_match.group(1))
            if price_match else None
        )

        # -------------------------------------------------
        # TYPE
        # -------------------------------------------------
        type_match = re.search(
            r"Type=([a-zA-Z]+)",
            message
        )

        trade_type = (
            type_match.group(1)
            if type_match else None
        )

        # -------------------------------------------------
        # OPTION TYPE
        # -------------------------------------------------
        option_type = None

        if trade_type:
            if "CE" in trade_type.upper():
                option_type = "ce"

            elif "PE" in trade_type.upper():
                option_type = "pe"

        # -------------------------------------------------
        # STRIKE
        # -------------------------------------------------
        strike_match = re.search(
            r"Strike=([0-9.]+)",
            message
        )

        strike = (
            int(float(strike_match.group(1)))
            if strike_match else None
        )

        # -------------------------------------------------
        # TIME
        # -------------------------------------------------
        time_match = re.search(
            r"Time=([0-9:\-\s]+)",
            message
        )

        timestamp = (
            time_match.group(1).strip()
            if time_match else None
        )

        # -------------------------------------------------
        # VALIDATION
        # -------------------------------------------------
        if not strike:
            return None

        if option_type not in ["ce", "pe"]:
            return None

        # -------------------------------------------------
        # FINAL RESPONSE
        # -------------------------------------------------
        return {
            "event": event,
            "price": price,
            "type": trade_type,
            "option_type": option_type,
            "strike": strike,
            "time": timestamp,
            "raw_message": message
        }

    except Exception:
        return None