from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from contextlib import asynccontextmanager
import asyncio
from datetime import datetime

from feed_manager import (
    ALLOWED_SECURITIES,
    SUBSCRIBERS,
    start_feed_thread,
)

# =====================
# CONFIG
# =====================
TEST_LOG = True

def log(msg):
    if TEST_LOG:
        print(f"[WS {datetime.now().strftime('%H:%M:%S')}] {msg}")

# =====================


@asynccontextmanager
async def lifespan(app: FastAPI):
    log("FastAPI startup")
    start_feed_thread()
    yield
    log("FastAPI shutdown")


app = FastAPI(
    title="Dhan Market WebSocket API",
    lifespan=lifespan,
)


# -------------------------------------------------
# HOME ROUTE
# -------------------------------------------------
@app.get("/")
def home():
    routes = []
    for sid in ALLOWED_SECURITIES:
        routes.append(f"/ws/{sid}")          # default (quote)
        routes.append(f"/ws/{sid}/ticker")
        routes.append(f"/ws/{sid}/quote")
    return {"available_websockets": routes}


# -------------------------------------------------
# DEFAULT MODE = QUOTE
# -------------------------------------------------
@app.websocket("/ws/{security_id}")
async def websocket_default(ws: WebSocket, security_id: str):
    """
    If mode is not provided, default to QUOTE
    """
    await handle_ws(ws, security_id, mode="quote")


# -------------------------------------------------
# EXPLICIT MODE
# -------------------------------------------------
@app.websocket("/ws/{security_id}/{mode}")
async def websocket_with_mode(ws: WebSocket, security_id: str, mode: str):
    await handle_ws(ws, security_id, mode)


# -------------------------------------------------
# SHARED HANDLER
# -------------------------------------------------
async def handle_ws(ws: WebSocket, security_id: str, mode: str):
    log(f"WebSocket request: security_id={security_id}, mode={mode}")

    # ✅ Validate security_id
    if security_id not in ALLOWED_SECURITIES:
        log("Invalid security_id")
        await ws.close(code=1008)
        return

    # ✅ Validate mode
    if mode not in ("ticker", "quote"):
        log("Invalid mode")
        await ws.close(code=1008)
        return

    await ws.accept()
    log(f"WebSocket accepted: {security_id} ({mode})")

    loop = asyncio.get_running_loop()

    def sender(message):
        asyncio.run_coroutine_threadsafe(
            ws.send_json(message),
            loop,
        )

    key = (security_id, mode)
    SUBSCRIBERS[key].add(sender)

    log(
        f"Subscriber added for {key}, "
        f"count={len(SUBSCRIBERS[key])}"
    )

    try:
        while True:
            await ws.receive_text()  # keep alive
    except WebSocketDisconnect:
        SUBSCRIBERS[key].remove(sender)
        log(f"WebSocket disconnected: {key}")
