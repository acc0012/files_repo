from django.apps import AppConfig
import threading
import time
import os

from core.db import get_orders_collection
from core.logger import get_logger


logger = get_logger("marketfeed_boot")


class MarketfeedConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "marketfeed"

    # -------------------------------------------------
    # 🔥 DJANGO STARTUP
    # -------------------------------------------------
    def ready(self):

        # prevent duplicate execution
        # caused by Django auto-reloader
        if os.environ.get("RUN_MAIN") != "true":
            return

        # startup thread
        thread = threading.Thread(
            target=self.restore_active_feeds,
            daemon=True
        )

        thread.start()

    # -------------------------------------------------
    # 🔥 RESTORE ACTIVE FEEDS
    # -------------------------------------------------
    def restore_active_feeds(self):

        try:

            # slight delay for Django init
            time.sleep(3)

            from marketfeed.subscriber import subscribe_security
            from marketfeed.services import start_feed_ws

            collection = get_orders_collection()

            # -----------------------------------------
            # FETCH ACTIVE ORDERS
            # -----------------------------------------
            orders = list(
                collection.find(
                    {
                        "status": "placed"
                    }
                ).sort("created_at", -1)
            )

            if not orders:

                logger.info(
                    "[STARTUP] No active orders found"
                )

                return

            logger.info(
                f"[STARTUP] Restoring "
                f"{len(orders)} active orders"
            )

            restored = set()

            # -----------------------------------------
            # RESTORE FEEDS
            # -----------------------------------------
            for order in orders:

                try:

                    security_id = order.get("security_id")
                    index_security_id = order.get("index_security_id")

                    if not security_id:
                        continue

                    # avoid duplicate restore
                    if security_id in restored:
                        continue

                    restored.add(security_id)

                    logger.info(
                        f"[STARTUP RESTORE] "
                        f"Security={security_id}"
                    )

                    # ---------------------------------
                    # RE-SUBSCRIBE
                    # ---------------------------------
                    subscribe_security(
                        index_security_id,
                        security_id
                    )

                    # ---------------------------------
                    # START WEBSOCKET
                    # ---------------------------------
                    start_feed_ws(
                        security_id
                    )

                    # small delay
                    time.sleep(0.5)

                except Exception as e:

                    logger.error(
                        f"[STARTUP RESTORE ERROR] "
                        f"Order={order.get('_id')} "
                        f"Error={e}"
                    )

            logger.info(
                "[STARTUP] Feed restore completed"
            )

        except Exception as e:

            logger.error(
                f"[STARTUP FATAL ERROR] "
                f"{e}"
            )