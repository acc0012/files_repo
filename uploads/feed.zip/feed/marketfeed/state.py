live_prices = {}


def update_price(security_id, ltp):
    live_prices[security_id] = ltp


def get_price(security_id):
    return live_prices.get(security_id)
