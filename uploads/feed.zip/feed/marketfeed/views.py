from django.http import JsonResponse
from marketfeed.subscriber import subscribe_security
from marketfeed.services import start_feed_ws


def subscribe_debug(request, index_security_id, security_id):
    """
    Debug endpoint to manually trigger subscription + websocket feed.
    """

    sub = subscribe_security(index_security_id, security_id)
    start_feed_ws(security_id)

    return JsonResponse({
        "status": "started",
        "subscription_response": sub
    })