import json
import websocket
import threading
import time
import ssl

from datetime import datetime

from django.conf import settings
from core.logger import get_logger
from core.db import get_orders_collection
from marketfeed.state import update_price, get_price


logger = get_logger("marketfeed")

BASE_WS = settings.BASE_WS


# ✅ manual close tracker
MANUAL_CLOSE = set()

# -------------------------------------------------
# 🔥 ACTIVE WS STORAGE
# -------------------------------------------------
ACTIVE_WS = {}
ACTIVE_THREADS = {}
ACTIVE_SECURITIES = set()

WS_LOCK = threading.Lock()

ENTRY_CAPTURED = set()


# -------------------------------------------------
# 🔥 REMOVE WS
# -------------------------------------------------
def remove_ws(security_id):
    with WS_LOCK:
        ACTIVE_SECURITIES.discard(security_id)
        ACTIVE_WS.pop(security_id, None)
        ACTIVE_THREADS.pop(security_id, None)

    logger.info(f"[WS REMOVED] Security {security_id}")


# -------------------------------------------------
# ✅ CLOSE SINGLE WS
# -------------------------------------------------
def close_feed_ws(security_id):

    with WS_LOCK:
        ws = ACTIVE_WS.get(security_id)

        if not ws:
            return

        # ✅ mark manual close (prevents reconnect)
        MANUAL_CLOSE.add(security_id)

        try:
            logger.info(f"[WS CLOSE REQUEST] {security_id}")
            ws.close()
        except Exception as e:
            logger.error(f"[WS CLOSE ERROR] {security_id} {e}")

    remove_ws(security_id)


# -------------------------------------------------
# 🔥 CLOSE OLD FEEDS (STRICT EXIT FIRST)
# -------------------------------------------------
def close_all_feeds_except(new_security_id):

    old_list = list(ACTIVE_SECURITIES)

    for sec in old_list:

        if sec == new_security_id:
            continue

        logger.info(f"[CLOSING OLD FEED] {sec}")

        # ✅ STEP 1: SAVE EXIT
        save_exit(sec)

        # ✅ STEP 2: CLOSE WS
        close_feed_ws(sec)

        # ✅ STEP 3: allow cleanup
        time.sleep(0.5)


# -------------------------------------------------
# 🔥 SAVE ENTRY PRICE
# -------------------------------------------------
def save_entry_price(security_id, data):
    try:
        ltp = data.get("LTP")
        if ltp is None:
            return

        if security_id in ENTRY_CAPTURED:
            return

        collection = get_orders_collection()

        order = collection.find_one(
            {
                "security_id": security_id,
                "status": "placed",
                "entry_price": {"$exists": False}
            },
            sort=[("created_at", -1)]
        )

        if not order:
            return

        collection.update_one(
            {"_id": order["_id"]},
            {
                "$set": {
                    "entry_price": float(ltp),
                    "entry_time": datetime.utcnow(),
                    "quote_data": data
                }
            }
        )

        ENTRY_CAPTURED.add(security_id)
        logger.info(f"[ENTRY SAVED] {security_id} Entry={ltp}")

    except Exception as e:
        logger.error(f"[ENTRY SAVE ERROR] {security_id} {e}")


# -------------------------------------------------
# 🔥 START FEED WS (FIXED VERSION)
# -------------------------------------------------
def start_feed_ws(security_id, retry_delay=3):

    with WS_LOCK:
        if security_id in ACTIVE_SECURITIES:
            logger.info(f"[WS ALREADY RUNNING] {security_id}")
            return
        ACTIVE_SECURITIES.add(security_id)

    url = f"{BASE_WS}/{security_id}/quote"

    logger.info(f"[WS INIT] {security_id} URL={url}")

    # -------------------------------------------------
    # EVENT HANDLERS
    # -------------------------------------------------
    def on_message(ws, message):
        try:
            data = json.loads(message)

            ltp = data.get("LTP")
            if ltp is not None:
                update_price(security_id, float(ltp))

            save_entry_price(security_id, data)

            if settings.FEED_LOGS:
                logger.info(f"[LIVE DATA] {security_id} {data}")

        except Exception as e:
            logger.error(f"[WS JSON ERROR] {security_id} {e}")

    def on_open(ws):
        logger.info(f"[WS OPEN] {security_id}")

    def on_error(ws, error):
        logger.error(f"[WS ERROR] {security_id} {error}")

    def on_close(ws, close_status_code, close_msg):

        logger.warning(f"[WS CLOSED] {security_id}")

        remove_ws(security_id)

        # ✅ STOP reconnect for manual close
        if security_id in MANUAL_CLOSE:
            logger.info(f"[NO RECONNECT] {security_id}")
            MANUAL_CLOSE.discard(security_id)
            return

        # ✅ reconnect for real failure
        logger.info(f"[RECONNECT] {security_id} in {retry_delay}s")
        time.sleep(retry_delay)
        start_feed_ws(security_id)

    # -------------------------------------------------
    # ✅ CREATE WS OUTSIDE on_close (FIXED)
    # -------------------------------------------------
    try:
        ws = websocket.WebSocketApp(
            url,
            on_message=on_message,
            on_open=on_open,
            on_error=on_error,
            on_close=on_close,
        )

        with WS_LOCK:
            ACTIVE_WS[security_id] = ws

        def run_socket():
            try:
                ws.run_forever(
                    sslopt={"cert_reqs": ssl.CERT_NONE},
                    ping_interval=20,
                    ping_timeout=10
                )
            except Exception as e:
                logger.error(f"[WS THREAD ERROR] {security_id} {e}")
                remove_ws(security_id)

        thread = threading.Thread(target=run_socket, daemon=True)

        with WS_LOCK:
            ACTIVE_THREADS[security_id] = thread

        thread.start()

        logger.info(f"[WS STARTED] {security_id}")

    except Exception as e:
        logger.error(f"[WS FATAL ERROR] {security_id} {e}")
        remove_ws(security_id)


# -------------------------------------------------
# 🔥 ACTIVE FEEDS LIST
# -------------------------------------------------
def get_active_feeds():
    return list(ACTIVE_SECURITIES)


# -------------------------------------------------
# 🔥 SAVE EXIT
# -------------------------------------------------
def save_exit(security_id):

    try:
        collection = get_orders_collection()

        order = collection.find_one(
            {
                "security_id": security_id,
                "status": "placed",
                "entry_price": {"$exists": True},
                "exit_price": {"$exists": False}
            },
            sort=[("created_at", -1)]
        )

        if not order:
            return

        last_price = get_price(security_id)

        if last_price is None:
            return

        collection.update_one(
            {"_id": order["_id"]},
            {
                "$set": {
                    "exit_price": float(last_price),
                    "exit_time": datetime.utcnow(),
                    "status": "completed"
                }
            }
        )

        logger.info(f"[EXIT SAVED] {security_id} Exit={last_price}")

    except Exception as e:
        logger.error(f"[EXIT ERROR] {security_id} {e}")