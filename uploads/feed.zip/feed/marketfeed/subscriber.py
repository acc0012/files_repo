import requests
import threading
import time
import urllib3

from django.conf import settings
from core.logger import get_logger


logger = get_logger("subscriber")

BASE_HTTP = settings.BASE_HTTP

# Disable SSL warnings (because verify=False)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# -------------------------------------------------
# 🔥 ACTIVE SUBSCRIPTIONS
# -------------------------------------------------
ACTIVE_SUBSCRIPTIONS = set()
SUBSCRIPTION_LOCK = threading.Lock()

# -------------------------------------------------
# 🔥 EXCHANGE SEGMENTS
# -------------------------------------------------
EXCHANGE_SEGMENTS = {
    13: 2,   # NIFTY → NSE_FNO
    25: 2,   # FINNIFTY → NSE_FNO
    51: 8    # BANKNIFTY → BSE_FNO
}


# -------------------------------------------------
# 🔥 CHECK ACTIVE SUBSCRIPTION
# -------------------------------------------------
def is_subscribed(security_id):
    return security_id in ACTIVE_SUBSCRIPTIONS


# -------------------------------------------------
# 🔥 REMOVE SUBSCRIPTION
# -------------------------------------------------
def remove_subscription(security_id):
    with SUBSCRIPTION_LOCK:
        ACTIVE_SUBSCRIPTIONS.discard(security_id)

    logger.info(f"[UNSUBSCRIBED LOCAL] Security {security_id}")


# -------------------------------------------------
# 🔥 SUBSCRIBE SECURITY
# -------------------------------------------------
def subscribe_security(index_security_id, security_id):

    # Prevent duplicate subscription
    with SUBSCRIPTION_LOCK:
        if security_id in ACTIVE_SUBSCRIPTIONS:
            logger.info(f"[ALREADY SUBSCRIBED] Security {security_id}")
            return {
                "status": "already_subscribed",
                "security_id": security_id
            }

    # Determine exchange
    exchange = EXCHANGE_SEGMENTS.get(index_security_id, 2)

    payload = {
        "symbols": [
            [
                exchange,
                str(security_id),
                17
            ]
        ]
    }

    logger.info(
        f"[SUBSCRIBE REQUEST] Security {security_id} Exchange {exchange}"
    )

    # -----------------------------------------------------
    # 🔥 RETRY LOGIC + SSL BYPASS
    # -----------------------------------------------------
    max_retries = 3
    response = None

    for attempt in range(max_retries):
        try:
            response = requests.post(
                f"{BASE_HTTP}/subscribe",
                json=payload,
                timeout=5,
                verify=False   # SSL bypass fix
            )
            break

        except Exception as e:
            logger.error(
                f"[SUBSCRIBE RETRY {attempt+1}/{max_retries}] "
                f"Security {security_id} Error={e}"
            )
            time.sleep(1)

    # If all retries failed
    if response is None:
        logger.error(
            f"[SUBSCRIBE ERROR] Security {security_id} → "
            f"All retry attempts failed"
        )
        return {
            "status": "error",
            "security_id": security_id,
            "error": "All retry attempts failed"
        }

    # -----------------------------------------------------
    # Parse JSON response
    # -----------------------------------------------------
    try:
        data = response.json()
    except Exception:
        data = {"status": "unknown", "raw_response": response.text}

    # -----------------------------------------------------
    # 🔥 ALLOW FALLBACK EVEN IF API RETURNS 403/500
    # -----------------------------------------------------
    if response.status_code in [200, 201]:
        success = True
    else:
        logger.warning(
            f"[SUBSCRIBE API FAILED but WS fallback enabled] "
            f"Security {security_id} HTTP={response.status_code}"
        )
        success = True   # WebSocket will still work!

    # -----------------------------------------------------
    # Activate local subscription tracking
    # -----------------------------------------------------
    if success:
        with SUBSCRIPTION_LOCK:
            ACTIVE_SUBSCRIPTIONS.add(security_id)

        logger.info(f"[SUBSCRIBE SUCCESS/FALLBACK] Security {security_id}")

        return {
            "status": "success",
            "security_id": security_id,
            "exchange": exchange,
            "response": data
        }

    # Should never reach here, but just in case
    logger.error(
        f"[SUBSCRIBE FAILED] Security {security_id} HTTP={response.status_code}"
    )

    return {
        "status": "failed",
        "security_id": security_id,
        "http_status": response.status_code,
        "response": data
    }


# -------------------------------------------------
# 🔥 GET ACTIVE SUBSCRIPTIONS
# -------------------------------------------------
def get_active_subscriptions():
    return list(ACTIVE_SUBSCRIPTIONS)