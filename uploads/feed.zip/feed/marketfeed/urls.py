from django.urls import path
from marketfeed import views

urlpatterns = [
    path("subscribe/<int:index_security_id>/<int:security_id>/", views.subscribe_debug),
]