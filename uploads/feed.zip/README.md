# Dhan Live Market Feed Server

## Setup

1. Install dependencies
pip install -r requirements.txt

2. Add .env file
CLIENT_ID=your_client_id
ACCESS_TOKEN=your_access_token

3. Run server
python app.py

## WebSocket Usage

Subscribe:
{
  "security_id": "13"
}
