from flask import Flask, request
from flask_socketio import SocketIO, emit
import threading

from feed import FeedManager
from config import DEFAULT_IDS

app = Flask(__name__)
socketio = SocketIO(app, cors_allowed_origins="*")

latest_data = {}
user_subscriptions = {}

def handle_market_data(response):
    sec_id = str(response.get("security_id"))
    latest_data[sec_id] = response

    for sid, subs in user_subscriptions.items():
        if sec_id in subs:
            socketio.emit("market_data", response, room=sid)


def start_feed():
    feed = FeedManager()
    feed.start(handle_market_data)


@socketio.on("connect")
def connect():
    print("Client connected:", request.sid)
    user_subscriptions[request.sid] = []


@socketio.on("disconnect")
def disconnect():
    print("Client disconnected:", request.sid)
    user_subscriptions.pop(request.sid, None)


@socketio.on("subscribe")
def subscribe(data):
    sec_id = str(data.get("security_id"))

    if sec_id not in DEFAULT_IDS:
        emit("error", {"msg": "Invalid security_id"})
        return

    if sec_id not in user_subscriptions[request.sid]:
        user_subscriptions[request.sid].append(sec_id)

    if sec_id in latest_data:
        emit("market_data", latest_data[sec_id])

    emit("success", {"msg": f"Subscribed to {sec_id}"})


@socketio.on("unsubscribe")
def unsubscribe(data):
    sec_id = str(data.get("security_id"))

    if sec_id in user_subscriptions[request.sid]:
        user_subscriptions[request.sid].remove(sec_id)

    emit("success", {"msg": f"Unsubscribed from {sec_id}"})


if __name__ == "__main__":
    threading.Thread(target=start_feed, daemon=True).start()
    socketio.run(app, host="0.0.0.0", port=5000)
