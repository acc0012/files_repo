import json
import websocket
import threading
import time
import ssl

from datetime import datetime

from django.conf import settings
from core.logger import get_logger
from core.db import get_orders_collection
from marketfeed.state import update_price


logger = get_logger("marketfeed")

BASE_WS = settings.BASE_WS


# -------------------------------------------------
# 🔥 ACTIVE WS STORAGE
# -------------------------------------------------
ACTIVE_WS = {}
ACTIVE_THREADS = {}
ACTIVE_SECURITIES = set()

WS_LOCK = threading.Lock()

# Prevent duplicate entry save
ENTRY_CAPTURED = set()


# -------------------------------------------------
# 🔥 SAVE ENTRY PRICE
# -------------------------------------------------
def save_entry_price(security_id, data):
    try:
        ltp = data.get("LTP")
        if ltp is None:
            return

        if security_id in ENTRY_CAPTURED:
            return

        collection = get_orders_collection()

        order = collection.find_one(
            {
                "security_id": security_id,
                "status": "placed",
                "entry_price": {"$exists": False}
            },
            sort=[("created_at", -1)]
        )

        if not order:
            return

        collection.update_one(
            {"_id": order["_id"]},
            {
                "$set": {
                    "entry_price": float(ltp),
                    "entry_time": datetime.utcnow(),
                    "quote_data": data
                }
            }
        )

        ENTRY_CAPTURED.add(security_id)
        logger.info(f"[ENTRY SAVED] Security {security_id} Entry={ltp}")

    except Exception as e:
        logger.error(f"[ENTRY SAVE ERROR] Security {security_id} Error={e}")


# -------------------------------------------------
# 🔥 REMOVE WS
# -------------------------------------------------
def remove_ws(security_id):
    with WS_LOCK:
        ACTIVE_SECURITIES.discard(security_id)
        ACTIVE_WS.pop(security_id, None)
        ACTIVE_THREADS.pop(security_id, None)

    logger.info(f"[WS REMOVED] Security {security_id}")


# -------------------------------------------------
# 🔥 START FEED WS
# -------------------------------------------------
def start_feed_ws(security_id, retry_delay=3):

    with WS_LOCK:
        if security_id in ACTIVE_SECURITIES:
            logger.info(f"[WS ALREADY RUNNING] Security {security_id}")
            return
        ACTIVE_SECURITIES.add(security_id)

    url = f"{BASE_WS}/{security_id}/quote"

    logger.info(f"[WS INIT] Security {security_id} URL={url}")

    # ----------------------------------------------
    # MESSAGE HANDLER
    # ----------------------------------------------
    def on_message(ws, message):
        try:
            data = json.loads(message)

            ltp = data.get("LTP")
            if ltp is not None:
                update_price(security_id, float(ltp))

            save_entry_price(security_id, data)

            if settings.FEED_LOGS:
                logger.info(f"[LIVE DATA] Security={security_id} Data={data}")

        except Exception as e:
            logger.error(f"[WS JSON ERROR] Security {security_id} Error={e}")
            logger.error(f"[WS RAW MESSAGE] {message}")

    # ----------------------------------------------
    # OPEN HANDLER
    # ----------------------------------------------
    def on_open(ws):
        logger.info(f"[WS OPEN] Security {security_id}")

    # ----------------------------------------------
    # ERROR HANDLER
    # ----------------------------------------------
    def on_error(ws, error):
        logger.error(f"[WS ERROR] Security {security_id} Error={error}")

    # ----------------------------------------------
    # CLOSE HANDLER
    # ----------------------------------------------
    def on_close(ws, close_status_code, close_msg):
        logger.warning(
            f"[WS CLOSED] Security {security_id} "
            f"Code={close_status_code} Msg={close_msg}"
        )

        remove_ws(security_id)

        logger.info(f"[WS RECONNECT] Security {security_id} Retry in {retry_delay}s")
        time.sleep(retry_delay)

        start_feed_ws(security_id, retry_delay=retry_delay)

    # ----------------------------------------------
    # CREATE WS CLIENT
    # ----------------------------------------------
    try:
        ws = websocket.WebSocketApp(
            url,
            on_message=on_message,
            on_open=on_open,
            on_error=on_error,
            on_close=on_close,
        )

        with WS_LOCK:
            ACTIVE_WS[security_id] = ws

        def run_socket():
            try:
                ws.run_forever(
                    sslopt={"cert_reqs": ssl.CERT_NONE},  # SSL BYPASS 🔥
                    ping_interval=20,                      # Send ping every 20s
                    ping_timeout=10                        # Timeout for pong
                )

            except Exception as e:
                logger.error(
                    f"[WS THREAD ERROR] Security {security_id} Error={e}"
                )
                remove_ws(security_id)

        thread = threading.Thread(target=run_socket, daemon=True)

        with WS_LOCK:
            ACTIVE_THREADS[security_id] = thread

        thread.start()
        logger.info(f"[WS THREAD STARTED] Security {security_id}")

    except Exception as e:
        logger.error(f"[WS FATAL ERROR] Security {security_id} Error={e}")
        remove_ws(security_id)


# -------------------------------------------------
# 🔥 ACTIVE FEEDS LIST
# -------------------------------------------------
def get_active_feeds():
    return list(ACTIVE_SECURITIES)