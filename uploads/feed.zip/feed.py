from dhanhq import marketfeed
from config import CLIENT_ID, ACCESS_TOKEN, DEFAULT_IDS

def get_instruments():
    instruments = []
    for sec_id in DEFAULT_IDS:
        instruments.append((marketfeed.IDX, sec_id, marketfeed.Ticker))
        instruments.append((marketfeed.IDX, sec_id, marketfeed.Quote))
    return instruments


class FeedManager:
    def __init__(self):
        self.instruments = get_instruments()
        self.data = marketfeed.DhanFeed(
            CLIENT_ID,
            ACCESS_TOKEN,
            self.instruments,
            "v2"
        )

    def start(self, callback):
        while True:
            self.data.run_forever()
            response = self.data.get_data()

            if response:
                callback(response)
