from core.utils import (
    parse_message,
    generate_order_id,
    current_ist_time,
    should_ignore,
)
from core.db import get_orders_collection, get_option_data_from_symbol
from core.telegram import send_telegram_alert
from core.logger import get_logger
import traceback
import uuid

logger = get_logger("order_processor")

# ✅ initialize collection once
orders_collection = get_orders_collection()


def process_order(raw_message: str):
    """
    Main alert → order processing pipeline

    Guarantees:
    - Never crashes the worker
    - Every failure is persisted
    - Debug trace is recoverable from DB
    """

    # ✅ global request id for tracing this execution
    trace_id = str(uuid.uuid4())[:8]

    order_id = generate_order_id("ORD")
    metadata = {}
    option_data = None
    failed_step = "init"

    logger.info(f"[{trace_id}] 🚀 Incoming alert received")

    try:
        # =====================================================
        # STEP 1: Parse incoming alert
        # =====================================================
        failed_step = "parse_message"

        if not raw_message:
            raise ValueError("Empty raw_message")

        metadata = parse_message(raw_message)
        logger.debug(f"[{trace_id}] Parsed metadata: {metadata}")

        trade_type = metadata.get("Type")
        if not trade_type:
            raise ValueError("Missing 'Type' in parsed metadata")

        # =====================================================
        # STEP 2: Identify option type (CE / PE)
        # =====================================================
        option_type = "pe" if "PE" in trade_type.upper() else "ce"
        logger.debug(f"[{trace_id}] Option type detected: {option_type}")

        # =====================================================
        # STEP 3: Fetch option data (NON-BLOCKING)
        # =====================================================
        failed_step = "fetch_option_data"
        try:
            strike = metadata.get("Strike")
            symbol = metadata.get("Symbol")

            if not strike or not symbol:
                raise ValueError("Missing strike or symbol")

            raw_data = get_option_data_from_symbol(
                symbol=symbol,
                strike=strike,
                option_type=option_type
            )

            if not raw_data:
                raise ValueError("Option lookup returned None")

            option_data = {
                "security_id": raw_data.get("security_id"),
                "last_price": raw_data.get("last_price"),
                "oi": raw_data.get("oi"),
                "implied_volatility": raw_data.get("implied_volatility"),
                "delta": raw_data.get("greeks", {}).get("delta"),
                "theta": raw_data.get("greeks", {}).get("theta"),
                "gamma": raw_data.get("greeks", {}).get("gamma"),
                "vega": raw_data.get("greeks", {}).get("vega"),
            }

            logger.info(
                f"[{trace_id}] ✅ Option data fetched | SecID={option_data.get('security_id')}"
            )

        except Exception as opt_err:
            # ✅ Important: option failure must NOT kill order
            logger.warning(
                f"[{trace_id}] ⚠️ Option data fetch failed: {opt_err}"
            )
            option_data = None

        # =====================================================
        # STEP 4: Fetch last placed order
        # =====================================================
        failed_step = "fetch_last_order"

        last_order = orders_collection.find_one(
            {"status": "PLACED"},
            sort=[("created_at", -1)]
        )

        logger.debug(
            f"[{trace_id}] Last placed order: {last_order.get('order_id') if last_order else None}"
        )

        # =====================================================
        # STEP 5: Ignore decision
        # =====================================================
        failed_step = "should_ignore"

        ignored = should_ignore(last_order, trade_type)

        order_id = generate_order_id("IG" if ignored else "ORD")

        logger.info(
            f"[{trace_id}] 🧠 Ignore decision → {'IGNORED' if ignored else 'PLACED'}"
        )

        # =====================================================
        # STEP 6: Prepare order document
        # =====================================================
        failed_step = "prepare_doc"

        order_doc = {
            "order_id": order_id,
            "status": "IGNORED" if ignored else "PLACED",
            "source": "ALERT",

            "trade_type": trade_type,
            "symbol": metadata.get("Symbol"),
            "strike": metadata.get("Strike"),
            "strike_price": metadata.get("StrikeLivePrice"),
            "alert_price": metadata.get("Price"),

            "option_data": option_data,

            "trace_id": trace_id,
            "created_at": current_ist_time(),
            "metadata": metadata,
        }

        # =====================================================
        # STEP 7: Persist order
        # =====================================================
        failed_step = "db_insert"

        orders_collection.insert_one(order_doc)

        logger.info(
            f"[{trace_id}] ✅ Order saved | {order_id} | {order_doc['status']}"
        )

        # =====================================================
        # STEP 8: Telegram notification (BEST EFFORT)
        # =====================================================
        failed_step = "telegram_notify"

        try:
            send_telegram_alert({
                "order_id": order_doc["order_id"],
                "status": order_doc["status"],
                "trade_type": order_doc["trade_type"],
                "symbol": order_doc["symbol"],
                "strike": order_doc["strike"],
                "strike_price": order_doc["strike_price"],
                "alert_price": order_doc["alert_price"],
                "created_at": order_doc["created_at"],
            })

            logger.info(
                f"[{trace_id}] 📩 Telegram sent"
            )

        except Exception as tg_err:
            logger.error(
                f"[{trace_id}] ❌ Telegram failed: {tg_err}",
                exc_info=True
            )

        return order_doc

    # =========================================================
    # ❌ GLOBAL FAILURE HANDLER
    # =========================================================
    except Exception as fatal_err:
        logger.error(
            f"[{trace_id}] 💥 Fatal error at [{failed_step}] → {fatal_err}",
            exc_info=True
        )

        failed_order = {
            "order_id": generate_order_id("FAIL"),
            "status": "FAILED",
            "source": "ALERT",
            "trace_id": trace_id,

            "error_reason": str(fatal_err),
            "error_type": type(fatal_err).__name__,
            "failed_step": failed_step,
            "stack_trace": traceback.format_exc(),

            "raw_message": raw_message,
            "metadata": metadata,
            "created_at": current_ist_time(),
        }

        try:
            orders_collection.insert_one(failed_order)
            logger.warning(
                f"[{trace_id}] 🧨 Failed order stored"
            )

            try:
                send_telegram_alert({
                    "order_id": failed_order["order_id"],
                    "status": "FAILED",
                    "trade_type": metadata.get("Type", "NA"),
                    "symbol": metadata.get("Symbol", "NA"),
                    "strike": metadata.get("Strike", "NA"),
                    "alert_price": metadata.get("Price", "NA"),
                    "failed_step": failed_step,
                    "error": failed_order["error_reason"],
                })

            except Exception:
                logger.error(
                    f"[{trace_id}] Telegram FAILED alert also failed",
                    exc_info=True
                )

        except Exception:
            logger.critical(
                f"[{trace_id}] 🚨 DB FAILURE — could not save FAILED order",
                exc_info=True
            )