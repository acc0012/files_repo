from django.http import JsonResponse
from core.db import orders_collection
from core.logger import get_logger
from core.services.live_prices import get_price

logger = get_logger("orders_api")


def serialize_order(o):
    """
    Clean serializer for dashboard + API.
    Ensures:
    - No ObjectId leaks
    - Missing fields safely handled
    - Live price injected
    """
    try:
        sec_id = None
        option_data = o.get("option_data")

        if option_data and isinstance(option_data, dict):
            sec_id = option_data.get("security_id")

        return {
            "order_id": o.get("order_id"),
            "status": o.get("status"),
            "trade_type": o.get("trade_type"),
            "symbol": o.get("symbol"),
            "strike": o.get("strike"),
            "strike_price": o.get("strike_price"),
            "alert_price": o.get("alert_price"),
            "created_at": o.get("created_at"),

            # Option info
            "security_id": sec_id,
            "option_data": option_data or {},

            # 🔥 NEW LIVE PRICE
            "live_price": get_price(str(sec_id)) if sec_id else None,
        }

    except Exception as err:
        logger.error(f"Serialization error: {err}", exc_info=True)
        return {}  # fallback safe


def get_orders(request):
    try:
        # -------------------------------------------
        # Pagination handling
        # -------------------------------------------
        page = int(request.GET.get("page", 1))
        limit = int(request.GET.get("limit", 10))
        source = request.GET.get("source", "ALL")

        if page < 1:
            page = 1
        if limit < 1:
            limit = 10

        skip = (page - 1) * limit

        # -------------------------------------------
        # Query filter
        # -------------------------------------------
        query = {}
        if source and source != "ALL":
            query["source"] = source.upper()

        logger.debug(f"Fetching orders | Page={page} Limit={limit} Filter={query}")

        # -------------------------------------------
        # Fetch paginated orders
        # -------------------------------------------
        cursor = (
            orders_collection
            .find(query)
            .sort("created_at", -1)
            .skip(skip)
            .limit(limit)
        )

        orders = []
        for o in cursor:
            o["_id"] = str(o["_id"])  # convert ObjectId
            orders.append(serialize_order(o))

        # -------------------------------------------
        # Metadata counters
        # -------------------------------------------
        total = orders_collection.count_documents(query)

        placed_count = orders_collection.count_documents({
            **query,
            "status": "PLACED"
        })

        ignored_count = orders_collection.count_documents({
            **query,
            "status": "IGNORED"
        })

        failed_count = orders_collection.count_documents({
            **query,
            "status": "FAILED"
        })

        return JsonResponse({
            "page": page,
            "limit": limit,
            "total": total,
            "placed": placed_count,
            "ignored": ignored_count,
            "failed": failed_count,
            "data": orders
        })

    except Exception as e:
        logger.error(f"/api/orders error: {str(e)}", exc_info=True)
        return JsonResponse({"error": str(e)}, status=500)