import json
import threading
import websocket
from django.conf import settings

from core.services.live_prices import update_price
from core.logger import get_logger

logger = get_logger("dhan_ws")

DHAN_WS_URL = settings.SOCKET_URL


class DhanFeedManager:
    subscribed = set()
    ws = None

    def connect(self):
        if self.ws:
            return

        self.ws = websocket.WebSocketApp(
            DHAN_WS_URL,
            on_message=self.on_message,
            on_error=self.on_error
        )

        threading.Thread(target=self.ws.run_forever, daemon=True).start()

    def on_message(self, ws, message):
        data = json.loads(message)

        sec_id = data.get("security_id")
        ltp = data.get("last_price")

        if sec_id and ltp:
            update_price(str(sec_id), ltp)

    def on_error(self, ws, error):
        logger.error(f"WS error: {error}")

    def subscribe(self, security_id):
        if security_id in self.subscribed:
            return

        payload = {
            "symbols": [[2, str(security_id), 17]]  # NSE_FNO + QUOTE ✅
        }

        self.ws.send(json.dumps(payload))
        self.subscribed.add(security_id)


# ✅ SINGLE INSTANCE
dhan_feed_manager = DhanFeedManager()
dhan_feed_manager.connect()