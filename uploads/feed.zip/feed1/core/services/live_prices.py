# core/services/live_prices.py

import threading

# security_id -> price
LIVE_PRICES = {}
LOCK = threading.Lock()

def update_price(security_id, price):
    with LOCK:
        LIVE_PRICES[security_id] = price

def get_price(security_id):
    with LOCK:
        return LIVE_PRICES.get(security_id)