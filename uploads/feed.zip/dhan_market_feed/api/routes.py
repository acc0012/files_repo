from flask import Blueprint,request,jsonify
from core.feed_url_builder import build_feed_url
from config.settings import CLIENT_ID
api=Blueprint('api',__name__)
@api.route('/generate-feed',methods=['POST'])
def gen():
    d=request.json
    url=build_feed_url(CLIENT_ID,int(d['exchange']),d['security_id'],int(d['request_code']))
    return jsonify({'success':True,'feed_url':url})
