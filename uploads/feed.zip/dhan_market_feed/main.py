from flask import Flask
from api.routes import api
from core.websocket_manager import init_socket

app=Flask(__name__)
app.register_blueprint(api,url_prefix='/api')
socketio=init_socket(app)

@app.route('/')
def health():
    return {'status':'running'}

if __name__=='__main__':
    socketio.run(app,host='0.0.0.0',port=8000)
