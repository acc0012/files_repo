from dhanhq import marketfeed
from config.settings import CLIENT_ID,ACCESS_TOKEN
class DhanLiveFeed:
    def __init__(self,socketio): self.socketio=socketio
    def start(self,instruments):
        feed=marketfeed.DhanFeed(CLIENT_ID,ACCESS_TOKEN,instruments,'v2')
        while True:
            feed.run_forever(); data=feed.get_data();
            if data: self.socketio.emit('market_data',data)
