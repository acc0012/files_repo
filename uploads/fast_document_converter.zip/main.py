"""Entry point for the Fast Document Converter app.

Run:
    uvicorn main:app --reload

The actual FastAPI application lives inside converter_app/web.py so future
requirements can be added inside the converter_app package without making
this file large.
"""

from converter_app.web import app

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
