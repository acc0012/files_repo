# Fast Document Converter

A Uvicorn based FastAPI web app for common document conversion workflows using Python packages only.

## Run

```bash
cd fast_document_converter
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload
```

Open: <http://127.0.0.1:8000>

## Project layout

```text
fast_document_converter/
├── main.py                  # Small entry point. Run by uvicorn main:app
├── requirements.txt         # Python packages only
├── README.md
└── converter_app/           # Main app package for future requirements
    ├── __init__.py
    ├── web.py               # FastAPI routes
    ├── services.py          # Conversion actions
    ├── templates/index.html # UI
    └── static/styles.css    # Layout design
```

## Current actions

- Multiple images to one PDF
- Combine multiple PDFs into one PDF
- PDF to Word DOCX
- Word DOCX to PDF
- Multiple DOCX files to one PDF
- Multiple PDFs to one Word DOCX

## Important note about Python-only conversion

This project intentionally does not use LibreOffice, Microsoft Office, wkhtmltopdf, pandoc, or any other external software.
Because of that, DOCX to PDF is a best-effort renderer that extracts paragraphs and tables and writes a clean PDF using ReportLab.
For exact DOCX visual fidelity, an external Office rendering engine is normally required, but that is excluded by design here.

`.doc` legacy Word files are not supported because reliable conversion of old binary Word files generally requires external software.
Use `.docx` files.

## How to add next actions

Add a key inside `ACTIONS` in `converter_app/services.py`, then add one function and route it inside `process_files()`.
The UI will automatically show new actions because it reads from `ACTIONS`.
