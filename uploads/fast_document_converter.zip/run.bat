@echo off
setlocal EnableExtensions

REM Fast Document Converter runner
REM Creates myenv if missing, installs packages, activates env, and runs project with Uvicorn.

cd /d "%~dp0"

set "ENV_DIR=myenv"
set "PYTHON_CMD=python"

where %PYTHON_CMD% >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python was not found in PATH.
    echo Please install Python 3.10+ and select "Add Python to PATH".
    pause
    exit /b 1
)

if not exist "%ENV_DIR%\Scripts\python.exe" (
    echo [INFO] Virtual environment not found.
    echo [INFO] Creating %ENV_DIR% ...

    %PYTHON_CMD% -m venv "%ENV_DIR%"
    if errorlevel 1 (
        echo [ERROR] Failed to create virtual environment.
        pause
        exit /b 1
    )

    echo [INFO] Activating %ENV_DIR% ...
    call "%ENV_DIR%\Scripts\activate.bat"

    echo [INFO] Upgrading pip ...
    python -m pip install --upgrade pip
    if errorlevel 1 (
        echo [ERROR] Failed to upgrade pip.
        pause
        exit /b 1
    )

    echo [INFO] Installing packages from requirements.txt ...
    pip install -r requirements.txt
    if errorlevel 1 (
        echo [ERROR] Package installation failed.
        pause
        exit /b 1
    )
) else (
    echo [INFO] Existing virtual environment found: %ENV_DIR%
    echo [INFO] Activating %ENV_DIR% ...
    call "%ENV_DIR%\Scripts\activate.bat"
)

echo.
echo [INFO] Starting project with Uvicorn ...
echo [INFO] Open this URL in browser:
echo http://127.0.0.1:8000
echo.

uvicorn main:app  --port 8000 --reload

endlocal