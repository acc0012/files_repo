"""Fast Document Converter application package."""
