from __future__ import annotations

import zipfile
from datetime import datetime
from pathlib import Path
from typing import Iterable, List

from PIL import Image
from pypdf import PdfReader, PdfWriter
from docx import Document
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib import colors
from reportlab.lib.units import inch

ACTIONS = {
    "images_to_pdf": {
        "label": "Multiple images to one PDF",
        "input": "JPG, JPEG, PNG, WEBP, BMP, TIFF",
        "output": "PDF",
        "multiple": True,
    },
    "combine_pdfs": {
        "label": "Combine multiple PDFs into one PDF",
        "input": "PDF",
        "output": "PDF",
        "multiple": True,
    },
    "pdf_to_docx": {
        "label": "PDF to Word DOCX",
        "input": "PDF",
        "output": "DOCX or ZIP for multiple files",
        "multiple": True,
    },
    "docx_to_pdf": {
        "label": "Word DOCX to PDF",
        "input": "DOCX",
        "output": "PDF or ZIP for multiple files",
        "multiple": True,
    },
    "multiple_docx_to_one_pdf": {
        "label": "Multiple DOCX files to one PDF",
        "input": "DOCX",
        "output": "PDF",
        "multiple": True,
    },
    "multiple_pdfs_to_one_docx": {
        "label": "Multiple PDFs to one Word DOCX",
        "input": "PDF",
        "output": "DOCX",
        "multiple": True,
    },
}

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff"}
PDF_EXTS = {".pdf"}
DOCX_EXTS = {".docx"}


def make_default_name(action: str) -> str:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"{action}_{stamp}"


def _clean_stem(name: str) -> str:
    name = Path(name).stem if Path(name).suffix else name
    name = "".join(ch if ch.isalnum() or ch in ("-", "_", " ") else "_" for ch in name)
    return name.strip().replace(" ", "_") or make_default_name("output")


def _with_suffix(name: str, suffix: str) -> str:
    p = Path(name)
    if p.suffix.lower() == suffix.lower():
        return _clean_stem(p.stem) + suffix
    return _clean_stem(name) + suffix


def _validate(paths: Iterable[Path], allowed: set[str], action_label: str) -> None:
    bad = [p.name for p in paths if p.suffix.lower() not in allowed]
    if bad:
        raise ValueError(f"{action_label} received unsupported files: {', '.join(bad)}")


def process_files(action: str, input_paths: list[Path], output_dir: Path, requested_name: str) -> Path:
    if action not in ACTIONS:
        raise ValueError(f"Unsupported action: {action}")
    if not input_paths:
        raise ValueError("Please upload at least one file.")

    if action == "images_to_pdf":
        _validate(input_paths, IMAGE_EXTS, ACTIONS[action]["label"])
        return images_to_pdf(input_paths, output_dir / _with_suffix(requested_name, ".pdf"))

    if action == "combine_pdfs":
        _validate(input_paths, PDF_EXTS, ACTIONS[action]["label"])
        return combine_pdfs(input_paths, output_dir / _with_suffix(requested_name, ".pdf"))

    if action == "pdf_to_docx":
        _validate(input_paths, PDF_EXTS, ACTIONS[action]["label"])
        outputs = [pdf_to_docx(p, output_dir / f"{p.stem}.docx") for p in input_paths]
        return outputs[0] if len(outputs) == 1 else zip_outputs(outputs, output_dir / _with_suffix(requested_name, ".zip"))

    if action == "docx_to_pdf":
        _validate(input_paths, DOCX_EXTS, ACTIONS[action]["label"])
        outputs = [docx_to_pdf(p, output_dir / f"{p.stem}.pdf") for p in input_paths]
        return outputs[0] if len(outputs) == 1 else zip_outputs(outputs, output_dir / _with_suffix(requested_name, ".zip"))

    if action == "multiple_docx_to_one_pdf":
        _validate(input_paths, DOCX_EXTS, ACTIONS[action]["label"])
        return multiple_docx_to_one_pdf(input_paths, output_dir / _with_suffix(requested_name, ".pdf"))

    if action == "multiple_pdfs_to_one_docx":
        _validate(input_paths, PDF_EXTS, ACTIONS[action]["label"])
        return multiple_pdfs_to_one_docx(input_paths, output_dir / _with_suffix(requested_name, ".docx"))

    raise ValueError(f"Action not implemented: {action}")


def images_to_pdf(image_paths: list[Path], output_pdf: Path) -> Path:
    images = []
    for path in image_paths:
        img = Image.open(path)
        if img.mode in ("RGBA", "LA"):
            background = Image.new("RGB", img.size, (255, 255, 255))
            background.paste(img, mask=img.split()[-1])
            img = background
        else:
            img = img.convert("RGB")
        images.append(img)
    if not images:
        raise ValueError("No valid images supplied.")
    images[0].save(output_pdf, save_all=True, append_images=images[1:])
    return output_pdf


def combine_pdfs(pdf_paths: list[Path], output_pdf: Path) -> Path:
    writer = PdfWriter()
    for path in pdf_paths:
        reader = PdfReader(str(path))
        for page in reader.pages:
            writer.add_page(page)
    with output_pdf.open("wb") as f:
        writer.write(f)
    return output_pdf


def pdf_to_docx(pdf_path: Path, output_docx: Path) -> Path:
    # Best effort layout conversion using pdf2docx when installed.
    # Fallback extracts readable text using pypdf.
    try:
        from pdf2docx import Converter
        cv = Converter(str(pdf_path))
        cv.convert(str(output_docx), start=0, end=None)
        cv.close()
        return output_docx
    except Exception:
        doc = Document()
        doc.add_heading(pdf_path.name, level=1)
        reader = PdfReader(str(pdf_path))
        for i, page in enumerate(reader.pages, start=1):
            doc.add_heading(f"Page {i}", level=2)
            text = page.extract_text() or ""
            doc.add_paragraph(text if text.strip() else "[No extractable text on this page]")
        doc.save(output_docx)
        return output_docx


def _docx_story_elements(docx_path: Path):
    doc = Document(str(docx_path))
    styles = getSampleStyleSheet()
    story = []
    story.append(Paragraph(docx_path.name, styles["Title"]))
    story.append(Spacer(1, 0.15 * inch))

    for para in doc.paragraphs:
        text = para.text.strip()
        if text:
            style = styles["Heading2"] if para.style.name.lower().startswith("heading") else styles["BodyText"]
            story.append(Paragraph(text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"), style))
            story.append(Spacer(1, 0.08 * inch))

    for table in doc.tables:
        data = []
        for row in table.rows:
            data.append([cell.text for cell in row.cells])
        if data:
            tbl = Table(data, repeatRows=1)
            tbl.setStyle(TableStyle([
                ("GRID", (0, 0), (-1, -1), 0.25, colors.grey),
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#EAF2FF")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 6),
                ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]))
            story.append(tbl)
            story.append(Spacer(1, 0.15 * inch))
    return story


def docx_to_pdf(docx_path: Path, output_pdf: Path) -> Path:
    story = _docx_story_elements(docx_path)
    pdf = SimpleDocTemplate(str(output_pdf), pagesize=A4, rightMargin=54, leftMargin=54, topMargin=54, bottomMargin=54)
    pdf.build(story)
    return output_pdf


def multiple_docx_to_one_pdf(docx_paths: list[Path], output_pdf: Path) -> Path:
    story = []
    for idx, path in enumerate(docx_paths):
        if idx:
            story.append(PageBreak())
        story.extend(_docx_story_elements(path))
    pdf = SimpleDocTemplate(str(output_pdf), pagesize=A4, rightMargin=54, leftMargin=54, topMargin=54, bottomMargin=54)
    pdf.build(story)
    return output_pdf


def multiple_pdfs_to_one_docx(pdf_paths: list[Path], output_docx: Path) -> Path:
    doc = Document()
    doc.add_heading("Combined PDF Text Export", level=1)
    for pdf_index, path in enumerate(pdf_paths, start=1):
        if pdf_index > 1:
            doc.add_page_break()
        doc.add_heading(path.name, level=2)
        reader = PdfReader(str(path))
        for page_index, page in enumerate(reader.pages, start=1):
            doc.add_heading(f"Page {page_index}", level=3)
            text = page.extract_text() or ""
            doc.add_paragraph(text if text.strip() else "[No extractable text on this page]")
    doc.save(output_docx)
    return output_docx


def zip_outputs(paths: list[Path], zip_path: Path) -> Path:
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in paths:
            zf.write(path, arcname=path.name)
    return zip_path
