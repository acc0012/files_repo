from __future__ import annotations

import shutil
import tempfile
from pathlib import Path
from typing import List, Optional

from fastapi import FastAPI, File, Form, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from .services import ACTIONS, make_default_name, process_files

BASE_DIR = Path(__file__).resolve().parent

app = FastAPI(
    title="Fast Document Converter",
    description="Python-only document conversion and merge utility running with Uvicorn.",
    version="1.0.0",
)

app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(
        "index.html",
        {"request": request, "actions": ACTIONS},
    )


@app.post("/convert")
async def convert(
    action: str = Form(...),
    output_filename: Optional[str] = Form(default=None),
    files: List[UploadFile] = File(...),
):
    # Each request receives an independent temp workspace.
    temp_root = Path(tempfile.mkdtemp(prefix="fast_doc_converter_"))
    input_dir = temp_root / "input"
    output_dir = temp_root / "output"
    input_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)

    saved_paths: list[Path] = []
    for upload in files:
        safe_name = Path(upload.filename or "uploaded_file").name
        target = input_dir / safe_name
        with target.open("wb") as f:
            shutil.copyfileobj(upload.file, f)
        saved_paths.append(target)

    if not output_filename or not output_filename.strip():
        output_filename = make_default_name(action)

    result_path = process_files(
        action=action,
        input_paths=saved_paths,
        output_dir=output_dir,
        requested_name=output_filename.strip(),
    )

    return FileResponse(
        path=str(result_path),
        filename=result_path.name,
        media_type="application/octet-stream",
        background=None,
    )
