import json
import pandas as pd

# Load JSON data
with open("data.json", "r",encoding='utf-8') as f:
    data = json.load(f)

# Create DataFrame
df = pd.DataFrame(data)

# Convert slaDate to datetime and remove timezone safely
df["slaDate"] = pd.to_datetime(df["slaDate"], utc=True).dt.tz_localize(None)

# Create month and date columns
df["month"] = df["slaDate"].dt.to_period("M")
df["date"] = df["slaDate"].dt.date

# ------------------------------------
# ✅ 1. Create FULL month range from file
# ------------------------------------
all_months = pd.period_range(
    start=df["month"].min(),
    end=df["month"].max(),
    freq="M"
)

# ------------------------------------
# ✅ 2. Filter resolved tickets
# ------------------------------------
resolved_df = df[df["status"] == "Resolved"]

# ------------------------------------
# ✅ 3. Month-wise completed tickets (ALL months)
# ------------------------------------
month_wise_count = (
    resolved_df
    .groupby("month")
    .size()
    .reindex(all_months, fill_value=0)
    .reset_index()
)

month_wise_count.columns = ["month", "completed_tickets"]

print("\n📌 Month-wise Completed Tickets (All Months):")
print(month_wise_count)

# ------------------------------------
# ✅ 4. Day-wise closed tickets
# ------------------------------------
day_wise_count = (
    resolved_df
    .groupby("date")
    .size()
    .reset_index(name="closed_tickets")
)

print("\n📌 Day-wise Closed Tickets:")
print(day_wise_count)

# ------------------------------------
# ✅ 5. Month-wise MAX & MIN tickets closed per day
# ------------------------------------
daily_monthly = (
    resolved_df
    .groupby(["month", "date"])
    .size()
    .reset_index(name="daily_closed")
)

month_max_min = (
    daily_monthly
    .groupby("month")["daily_closed"]
    .agg(
        max_tickets_closed="max",
        min_tickets_closed="min"
    )
    .reindex(all_months)
    .fillna(0)
    .reset_index()
)

print("\n📌 Month-wise Max & Min Tickets Closed in a Day:")
print(month_max_min)
