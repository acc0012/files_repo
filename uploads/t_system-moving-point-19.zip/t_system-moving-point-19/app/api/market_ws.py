import asyncio

from fastapi import APIRouter
from fastapi import WebSocket
from fastapi import WebSocketDisconnect

from app.logger import get_logger

from app.services.websocket_manager import (
    connect,
    disconnect,
)

logger = get_logger()

router = APIRouter()

# ==========================================================
# MARKET FEED WEBSOCKET
# ==========================================================


@router.websocket("/ws/feed")
async def market_feed_socket(
    websocket: WebSocket,
):

    await connect(websocket)

    logger.info("Frontend websocket connected")

    try:

        while True:

            # Keep websocket alive
            await asyncio.sleep(30)

            try:

                await websocket.send_json({"type": "heartbeat"})

            except Exception:

                break

    except WebSocketDisconnect:

        logger.info("Frontend websocket disconnected")

    except Exception:

        logger.exception("Frontend websocket failed")

    finally:

        await disconnect(websocket)

        logger.info("Frontend websocket disconnected")
