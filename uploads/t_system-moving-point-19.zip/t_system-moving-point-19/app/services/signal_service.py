from app.logger import get_logger
import threading
from app.utils.datetime_helper import (
    ist_now,
)

from app.services.mongo_service import (
    index_signal_collection,
    option_signal_collection,
)

from app.services.payload_normalizer import (
    normalize_signal_payload,
)

from app.services.telegram_service import (
    send_telegram_message,
)

from app.services.telegram_message_service import (
    build_signal_message,
)

logger = get_logger()

# ==========================================================
# PROCESS SIGNAL
# ==========================================================


def process_signal(trace_id: str, payload: dict):

    try:
        source = payload.get("ALERT_SOURCE")
        normalized = normalize_signal_payload(payload)

        logger.info(
            f"Processing Signal "
            f"trace_id={trace_id} "
            f"source={source} "
            f"type={payload.get('TYPE')} "
            f"symbol={payload.get('SYMBOL')}"
        )

        signal_type = payload.get("TYPE")

        live_ce_strike = payload.get("LIVE_CE_STRIKE")
        live_pe_strike = payload.get("LIVE_PE_STRIKE")

        # ✅ FIX: Handle OBJECT strike from Pine
        suggested_strike_raw = payload.get("SUGGESTED_STRIKE", {})

        strike_50 = None
        strike_100 = None
        recommended_strike = ""

        if isinstance(suggested_strike_raw, dict):
            strike_50 = suggested_strike_raw.get("STRIKE_50")
            strike_100 = suggested_strike_raw.get("STRIKE_100")
            recommended_strike = strike_50 or strike_100 or ""
        else:
            recommended_strike = suggested_strike_raw or ""

        signal_direction = ""
        signal_title = ""
        signal_message = ""

        # ==================================================
        # ✅ SIGNAL LOGIC (CLEAN + SAFE)
        # ==================================================

        if signal_type == "BUY_CE":

            signal_direction = "BUY"
            signal_title = "MARKET RISING"

            if not recommended_strike:
                recommended_strike = f"{live_ce_strike} CE"

            if isinstance(suggested_strike_raw, dict):
                signal_message = (
                    "Market is showing bullish momentum. "
                    f"ATM: {strike_50 or '-'} | Safe: {strike_100 or '-'}"
                )
            else:
                signal_message = (
                    f"Market is showing bullish momentum. "
                    f"Take CALL Option {recommended_strike}"
                )

        elif signal_type == "SELL_CE":

            signal_direction = "SELL"
            signal_title = "EXIT CALL POSITION"

            if not recommended_strike:
                recommended_strike = f"{live_ce_strike} CE"

            if isinstance(suggested_strike_raw, dict):
                signal_message = (
                    "Bullish momentum is weakening. "
                    f"ATM: {strike_50 or '-'} | Safe: {strike_100 or '-'}"
                )
            else:
                signal_message = (
                    f"Bullish momentum is weakening. "
                    f"Exit CALL Option {recommended_strike}"
                )

        elif signal_type == "BUY_PE":

            signal_direction = "BUY"
            signal_title = "MARKET FALLING"

            if not recommended_strike:
                recommended_strike = f"{live_pe_strike} PE"

            if isinstance(suggested_strike_raw, dict):
                signal_message = (
                    "Market is showing bearish momentum. "
                    f"ATM: {strike_50 or '-'} | Safe: {strike_100 or '-'}"
                )
            else:
                signal_message = (
                    f"Market is showing bearish momentum. "
                    f"Take PUT Option {recommended_strike}"
                )

        elif signal_type == "SELL_PE":

            signal_direction = "SELL"
            signal_title = "EXIT PUT POSITION"

            if not recommended_strike:
                recommended_strike = f"{live_pe_strike} PE"

            if isinstance(suggested_strike_raw, dict):
                signal_message = (
                    "Bearish momentum is weakening. "
                    f"ATM: {strike_50 or '-'} | Safe: {strike_100 or '-'}"
                )
            else:
                signal_message = (
                    f"Bearish momentum is weakening. "
                    f"Exit PUT Option {recommended_strike}"
                )

        # ==================================================
        # ✅ DOCUMENT (FIXED)
        # ==================================================
        or_data = normalized.get("opening_range", {})
        opt_or_data = normalized.get("option_opening_range", {})

        doc = {
            "trace_id": trace_id,
            "alert_source": source,
            "alert_category": payload.get("ALERT_CATEGORY"),
            "type": signal_type,
            "ticker": payload.get("TICKER"),
            "symbol": payload.get("SYMBOL"),
            "date": payload.get("DATE"),
            "time": payload.get("TIME"),
            "timeframe": payload.get("TF"),
            # ✅ UI fields
            "signal_direction": signal_direction,
            "signal_title": signal_title,
            "signal_message": signal_message,
            # ✅ FIXED STRIKE STORAGE
            "recommended_strike": recommended_strike,
            "suggested_strike_50": strike_50,
            "suggested_strike_100": strike_100,
            "strike_meta": suggested_strike_raw,
            "ema_cross_history": normalized.get("ema_cross_history"),  # Core data
            "price": normalized.get("price"),
            "ema9": normalized.get("ema9"),
            "ema21": normalized.get("ema21"),
            "diff": normalized.get("diff"),
            "live_main_ltp": normalized.get("live_main_ltp"),
            "live_ce_strike": live_ce_strike,
            "live_pe_strike": live_pe_strike,
            
            "high": or_data.get("HIGH") or opt_or_data.get("HIGH"),
            "low": or_data.get("LOW") or opt_or_data.get("LOW"),
            "avg": or_data.get("AVG") or opt_or_data.get("AVG"),
            
            # ==================================================
            # NEW PINE STRUCTURES
            # ==================================================
            "level_status": normalized.get("level_status", {}),
            "ema_level_info": normalized.get("ema_level_info", {}),
            "opening_range": normalized.get("opening_range", {}),
            "option_opening_range": normalized.get("option_opening_range", {}),
            "suggested_strike": normalized.get("suggested_strike", {}),
            "raw_payload": normalized.get("raw_payload", {}),
            "created_at": ist_now(),
        }

        telegram_message = build_signal_message(
            payload=payload,
            signal_title=signal_title,
            signal_direction=signal_direction,
            signal_message=signal_message,
            recommended_strike=recommended_strike,
        )

        # ==================================================
        # SAVE
        # ==================================================

        if source == "INDEX":

            result = index_signal_collection.insert_one(doc)

            logger.info(
                f"Index signal saved "
                f"trace_id={trace_id} "
                f"mongo_id={result.inserted_id}"
            )

            threading.Thread(
                target=send_telegram_message,
                args=(telegram_message,),
                daemon=True,
            ).start()

            logger.info(f"Telegram alert triggered " f"trace_id={trace_id}")

            return result.inserted_id

        elif source == "OPTION":

            result = option_signal_collection.insert_one(doc)

            logger.info(
                f"Option signal saved "
                f"trace_id={trace_id} "
                f"mongo_id={result.inserted_id}"
            )

            threading.Thread(
                target=send_telegram_message,
                args=(telegram_message,),
                daemon=True,
            ).start()

            logger.info(f"Telegram alert triggered " f"trace_id={trace_id}")

            return result.inserted_id

        else:
            raise ValueError(f"Unknown ALERT_SOURCE: {source}")

    except Exception:
        logger.exception(f"Signal processing failed trace_id={trace_id}")
        raise
