def build_signal_message(
    payload,
    signal_title,
    signal_direction,
    signal_message,
    recommended_strike,
):
    return f"""
🔥 <b>{signal_title}</b>

<b>Direction:</b> {signal_direction}

<b>Category:</b> {payload.get("ALERT_CATEGORY")}

<b>Symbol:</b> {payload.get("SYMBOL")}

<b>Price:</b> {payload.get("PRICE")}

<b>LTP:</b> {payload.get("LIVE_MAIN_LTP")}

<b>Recommended Strike:</b>
{recommended_strike}

<b>Signal:</b>
{signal_message}

<b>Time:</b>
{payload.get("DATE")} {payload.get("TIME")}
""".strip()