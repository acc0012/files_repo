from app.logger import get_logger

logger = get_logger()

# ==========================================================
# SAFE FLOAT
# ==========================================================


def safe_float(value, default=0.0):

    try:

        if value is None:
            return default

        if value == "":
            return default

        return float(value)

    except Exception:

        return default


# ==========================================================
# SAFE DICT
# ==========================================================


def safe_dict(value):

    if isinstance(value, dict):
        return value

    return {}


# ==========================================================
# NORMALIZE SIGNAL PAYLOAD
# ==========================================================


def normalize_signal_payload(payload: dict) -> dict:

    try:

        normalized = {
            # ==================================================
            # ROOT META
            # ==================================================
            "alert_source": payload.get("ALERT_SOURCE"),
            "alert_category": payload.get("ALERT_CATEGORY"),
            "type": payload.get("TYPE"),
            "ticker": payload.get("TICKER"),
            "symbol": payload.get("SYMBOL"),
            "date": payload.get("DATE"),
            "time": payload.get("TIME"),
            "timeframe": payload.get("TF"),
            # ==================================================
            # CORE PRICE DATA
            # ==================================================
            "price": safe_float(payload.get("PRICE")),
            "ema9": safe_float(payload.get("EMA9")),
            "ema21": safe_float(payload.get("EMA21")),
            "diff": safe_float(payload.get("DIFF")),
            # ==================================================
            # LIVE MARKET DATA
            # ==================================================
            "live_main_ltp": safe_float(payload.get("LIVE_MAIN_LTP")),
            "live_ce_strike": payload.get("LIVE_CE_STRIKE"),
            "live_pe_strike": payload.get("LIVE_PE_STRIKE"),
            # ==================================================
            # OPTION SPECIFIC
            # ==================================================
            "ema_cross_history": payload.get("EMA_CROSS_HISTORY"),
            "suggested_strike": safe_dict(payload.get("SUGGESTED_STRIKE")),
            # ==================================================
            # INDEX LEVEL STATUS
            # ==================================================
            "level_status": safe_dict(payload.get("LEVEL_STATUS")),
            # ==================================================
            # EMA LEVEL INFORMATION
            # ==================================================
            "ema_level_info": safe_dict(payload.get("EMA_LEVEL_INFO")),
            # ==================================================
            # INDEX OPENING RANGE
            # ==================================================
            "opening_range": safe_dict(payload.get("OPENING_RANGE")),
            # ==================================================
            # OPTION OPENING RANGE
            # ==================================================
            "option_opening_range": safe_dict(payload.get("OPTION_OPENING_RANGE")),
            # ==================================================
            # RAW PAYLOAD
            # ==================================================
            "raw_payload": payload,
        }

        return normalized

    except Exception:

        logger.exception("Failed normalizing signal payload")

        raise


# ==========================================================
# NORMALIZE OPENING RANGE PAYLOAD
# ==========================================================


def normalize_opening_range_payload(
    payload: dict,
) -> dict:

    try:

        normalized = {
            "type": payload.get("TYPE"),
            "ticker": payload.get("TICKER"),
            "symbol": payload.get("SYMBOL"),
            "high": safe_float(payload.get("HIGH")),
            "low": safe_float(payload.get("LOW")),
            "avg": safe_float(payload.get("AVG")),
            "sub_resistance": safe_float(payload.get("SUB_RESISTANCE")),
            "sub_support": safe_float(payload.get("SUB_SUPPORT")),
            "resistance2": safe_float(payload.get("RESISTANCE2")),
            "support2": safe_float(payload.get("SUPPORT2")),
            "resistance3": safe_float(payload.get("RESISTANCE3")),
            "support3": safe_float(payload.get("SUPPORT3")),
            "resistance3_ce_strike": payload.get("RESISTANCE3_CE_STRIKE"),
            "resistance3_pe_strike": payload.get("RESISTANCE3_PE_STRIKE"),
            "support3_ce_strike": payload.get("SUPPORT3_CE_STRIKE"),
            "support3_pe_strike": payload.get("SUPPORT3_PE_STRIKE"),
            "buy_ce": payload.get("BUY_CE"),
            "buy_pe": payload.get("BUY_PE"),
            "raw_payload": payload,
        }

        return normalized

    except Exception:

        logger.exception("Failed normalizing opening range payload")

        raise
