import requests

from app.logger import get_logger

from app.config import (
    TELEGRAM_SERVICE_ENABLED,
    TELEGRAM_BOT_TOKEN,
    TELEGRAM_CHAT_ID,
)

logger = get_logger()


def send_telegram_message(message: str):

    try:

        if not TELEGRAM_SERVICE_ENABLED:
            return

        if not TELEGRAM_BOT_TOKEN:
            logger.warning("Telegram bot token missing")
            return

        if not TELEGRAM_CHAT_ID:
            logger.warning("Telegram chat id missing")
            return

        url = f"https://api.telegram.org/bot" f"{TELEGRAM_BOT_TOKEN}" f"/sendMessage"

        payload = {"chat_id": TELEGRAM_CHAT_ID, "text": message, "parse_mode": "HTML"}

        response = requests.post(url, json=payload, timeout=10)

        if response.status_code != 200:

            logger.error(f"Telegram failed : " f"{response.text}")

    except Exception:

        logger.exception("Telegram send failed")
