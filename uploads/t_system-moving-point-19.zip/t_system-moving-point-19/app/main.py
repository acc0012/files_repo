from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from app.logger import get_logger

from app.api.webhook import router as webhook_router
from app.api.status import router as status_router
from app.api.dashboard import router as dashboard_router
from app.api.login import router as login_router
from app.services.market_feed_service import (
    start_market_feed,
)
import asyncio

import app.services.runtime_state as runtime_state

from app.services.worker_service import start_worker

from app.services.upstox_service import (
    initialize_token,
)

from app.services.upstox_client_service import (
    initialize_upstox_client,
)

from app.services.upstox_monitor_service import (
    start_upstox_monitor,
)

from app.api.market_ws import router as market_ws_router

logger = get_logger()


@asynccontextmanager
async def lifespan(app: FastAPI):

    try:

        logger.info("=" * 80)
        logger.info("T_SYSTEM ALERT ENGINE STARTING")
        logger.info("=" * 80)

        runtime_state.MAIN_EVENT_LOOP = asyncio.get_running_loop()

        logger.info("Main event loop registered")


        # ==================================================
        # MARKET FEED
        # ==================================================

        logger.info("Starting market feed service")

        start_market_feed()

        logger.info("Market feed service started")


        # ==================================================
        # UPSTOX TOKEN INITIALIZATION
        # ==================================================

        logger.info("Initializing Upstox token service")

        initialize_token()

        logger.info("Upstox token initialization completed")

        # ==================================================
        # UPSTOX CLIENT INITIALIZATION
        # ==================================================

        logger.info("Initializing Upstox SDK client")

        client_initialized = initialize_upstox_client()

        if client_initialized:

            logger.info("Upstox SDK client initialized successfully")

        else:

            logger.warning(
                "Upstox SDK client initialization skipped " "(no active token found)"
            )

        # ==================================================
        # UPSTOX TOKEN MONITOR
        # ==================================================

        logger.info("Starting Upstox token monitor")

        start_upstox_monitor()

        logger.info("Upstox token monitor started")


        # ==================================================
        # WORKER SERVICE
        # ==================================================

        logger.info("Initializing worker service")

        start_worker()

        logger.info("Worker service initialized")

        logger.info("Application startup completed")

        yield

    except Exception:

        logger.exception("Application startup failed")

        raise

    finally:

        logger.info("Application shutdown initiated")

        logger.info("Application shutdown completed")


try:

    app = FastAPI(title="T_SYSTEM_ALERT_ENGINE", lifespan=lifespan)

    # ==================================================
    # STATIC FILES
    # ==================================================

    app.mount("/static", StaticFiles(directory="app/static"), name="static")

    # ==================================================
    # ROUTERS
    # ==================================================

    app.include_router(webhook_router)

    app.include_router(status_router)

    app.include_router(dashboard_router)

    app.include_router(login_router)

    app.include_router(market_ws_router)

    logger.info("Routers registered successfully")

except Exception:

    logger.exception("FastAPI application initialization failed")

    raise
