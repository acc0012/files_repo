@echo off
cls


REM Activate virtual environment
call myenv\Scripts\activate

REM Run FastAPI app with uvicorn
uvicorn app.main:app --reload --port 8001

