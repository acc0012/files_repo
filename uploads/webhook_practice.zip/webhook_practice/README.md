# Trading Webhook App

## Run
```
uvicorn app.main:app --reload
```