from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

from contextlib import asynccontextmanager
import asyncio
from datetime import datetime, time, timedelta
import pytz

from app.api.routes import webhook, socket_ws
from app.core.database import get_db
from app.core.config import settings
from app.services.socket_manager import start_socket
from app.core.logger import setup_logger

# =========================
# ✅ LOGGER
# =========================
logger = setup_logger("market_scheduler")

# ✅ Templates setup
templates = Jinja2Templates(directory="app/templates")

# ✅ Timezone
ist = pytz.timezone("Asia/Kolkata")

# ✅ MARKET TIMINGS
MARKET_START = time(9, 15)
MARKET_END = time(15, 40)


# =========================
# ✅ HELPERS
# =========================
def is_weekday():
    return datetime.now(ist).weekday() < 5


def is_market_open():
    now = datetime.now(ist).time()
    return MARKET_START <= now <= MARKET_END


def format_seconds(seconds: float):
    mins, sec = divmod(int(seconds), 60)
    hrs, mins = divmod(mins, 60)
    return f"{hrs}h {mins}m {sec}s"


def get_next_market_open():
    now = datetime.now(ist)

    next_open = datetime.combine(now.date(), MARKET_START)
    next_open = ist.localize(next_open)

    if now.time() > MARKET_START:
        next_open += timedelta(days=1)

    while next_open.weekday() >= 5:
        next_open += timedelta(days=1)

    return next_open


# =========================
# ✅ WAIT LOGIC
# =========================
async def wait_until_market_opens():
    while True:
        now = datetime.now(ist)

        if is_weekday() and is_market_open():
            logger.info("✅ Market OPEN (weekday). No waiting needed.")
            return

        next_open = get_next_market_open()
        sleep_seconds = max((next_open - now).total_seconds(), 60)

        if not is_weekday():
            logger.info(
                f"📅 Weekend | {now.strftime('%A')} | "
                f"Next Open: {next_open.strftime('%Y-%m-%d %H:%M:%S')} | "
                f"Sleep: {format_seconds(sleep_seconds)}"
            )
        else:
            logger.info(
                f"⏳ Market CLOSED | {now.strftime('%Y-%m-%d %H:%M:%S')} | "
                f"Next Open: {next_open.strftime('%Y-%m-%d %H:%M:%S')} | "
                f"Sleep: {format_seconds(sleep_seconds)}"
            )

        await asyncio.sleep(sleep_seconds)


# =========================
# ✅ SCHEDULER
# =========================
async def market_socket_scheduler():
    while True:
        now = datetime.now(ist)
        logger.info(f"🚀 Scheduler Tick | {now.strftime('%Y-%m-%d %H:%M:%S')}")

        await wait_until_market_opens()

        start_time = datetime.now(ist)

        logger.info(f"✅ Market OPEN | Starting sockets")

        try:
            start_socket("NIFTY", "/ws/market/13/")
            start_socket("SENSEX", "/ws/market/51/")
        except Exception as e:
            logger.error(f"❌ Socket error: {str(e)}")

        market_close_dt = datetime.combine(start_time.date(), MARKET_END)
        market_close_dt = ist.localize(market_close_dt)

        sleep_seconds = max((market_close_dt - start_time).total_seconds(), 0)

        if sleep_seconds > 0:
            logger.info(f"📉 Market running for {format_seconds(sleep_seconds)}")
            await asyncio.sleep(sleep_seconds)

        logger.info("🛑 Market CLOSED")


# =========================
# ✅ LIFESPAN
# =========================
@asynccontextmanager
async def lifespan(app: FastAPI):
    db = get_db()

    try:
        db[settings.PARSED_COLLECTION].create_index("date")
        db[settings.PARSED_COLLECTION].create_index("webhooks.trace_id")
        logger.info("✅ MongoDB indexes created")
    except Exception as e:
        logger.error(f"❌ Index error: {str(e)}")

    now = datetime.now(ist)

    if is_weekday() and is_market_open():
        logger.info("🟢 Started during market")
    elif is_weekday():
        logger.info("🟡 Started outside market")
    else:
        logger.info("🔴 Weekend start")

    try:
        asyncio.create_task(market_socket_scheduler())
    except Exception as e:
        logger.error(f"❌ Scheduler failed: {str(e)}")

    yield

    logger.info("🛑 App shutdown")


# =========================
# ✅ APP INIT
# =========================
app = FastAPI(
    title="Trading Webhook Service",
    lifespan=lifespan
)


# =========================
# ✅ UI ROUTES (NEW ✅)
# =========================
@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    return templates.TemplateResponse(
        "dashboard.html",
        {"request": request}
    )


@app.get("/logs", response_class=HTMLResponse)
async def logs(request: Request):
    return templates.TemplateResponse(
        "logs.html",
        {"request": request}
    )


# =========================
# ✅ API ROUTES
# =========================
app.include_router(webhook.router)
app.include_router(socket_ws.router)