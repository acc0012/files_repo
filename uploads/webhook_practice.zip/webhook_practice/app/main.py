from fastapi import FastAPI, Request, WebSocket
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, WebSocket
from fastapi.middleware.cors import CORSMiddleware

import asyncio
import logging
import json
from datetime import datetime, time, timedelta
import pytz

from app.api.routes import webhook
from app.core.database import get_db
from app.core.config import settings
from app.services.socket_manager import start_socket
from app.core.logger import setup_logger

# ✅ LOGGER
logger = setup_logger("market_scheduler")

# ✅ Reduce noisy logs
logging.getLogger("socket_manager").setLevel(logging.ERROR)
logging.getLogger("market_scheduler").setLevel(logging.WARNING)

# ✅ TIMEZONE
ist = pytz.timezone("Asia/Kolkata")

# ✅ TEMPLATE SETUP
templates = Jinja2Templates(directory="app/templates")

templates.env.globals.update({
    "type": type,
    "str": str,
    "repr": repr
})

# ✅ MARKET TIMINGS
MARKET_START = time(9, 15)
MARKET_END = time(15, 40)

# =========================
# ✅ HELPERS
# =========================
def is_weekday():
    return datetime.now(ist).weekday() < 5

def is_market_open():
    now = datetime.now(ist).time()
    return MARKET_START <= now <= MARKET_END

def get_next_market_open():
    now = datetime.now(ist)

    next_open = datetime.combine(now.date(), MARKET_START)
    next_open = ist.localize(next_open)

    if now.time() > MARKET_START:
        next_open += timedelta(days=1)

    while next_open.weekday() >= 5:
        next_open += timedelta(days=1)

    return next_open

# =========================
# ✅ WAIT UNTIL MARKET
# =========================
async def wait_until_market_opens():
    while True:
        now = datetime.now(ist)

        if is_weekday() and is_market_open():
            return

        next_open = get_next_market_open()
        sleep_seconds = (next_open - now).total_seconds()

        await asyncio.sleep(max(sleep_seconds, 60))

# =========================
# ✅ SOCKET SCHEDULER
# =========================
async def market_socket_scheduler():
    while True:
        await wait_until_market_opens()

        try:
            start_socket("NIFTY", "/ws/market/13/")
            start_socket("SENSEX", "/ws/market/51/")
        except Exception as e:
            logger.error(f"Socket error: {str(e)}")

        market_close_dt = datetime.combine(datetime.now(ist).date(), MARKET_END)
        market_close_dt = ist.localize(market_close_dt)

        remaining = (market_close_dt - datetime.now(ist)).total_seconds()

        if remaining > 0:
            await asyncio.sleep(remaining)

# =========================
# ✅ FASTAPI LIFESPAN
# =========================
@asynccontextmanager
async def lifespan(app: FastAPI):
    db = get_db()

    try:
        db[settings.PARSED_COLLECTION].create_index("date")
        db[settings.PARSED_COLLECTION].create_index("webhooks.trace_id")
    except Exception as e:
        logger.error(f"Index error: {e}")

    asyncio.create_task(market_socket_scheduler())

    yield

# =========================
# ✅ APP INIT
# =========================
app = FastAPI(
    title="Trading Webhook Service",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(webhook.router)

# =========================
# ✅ HOME PAGE
# =========================
@app.get("/", response_class=HTMLResponse)
async def home(request: Request):

    from app.services.trade.trade_state import active_trade
    from app.services.trade.trade_manager import (
        index_prices,
        index_full_data
    )

    try:
        safe_active_trade = (
            active_trade if isinstance(active_trade, dict) else None
        )

        template = templates.get_template("home.html")

        rendered = template.render(
            request=request,
            index_prices=index_prices,
            index_data=index_full_data,
            active_trade=safe_active_trade
        )

        return HTMLResponse(rendered)

    except Exception as e:
        logger.error(f"Template error: {str(e)}")

        return HTMLResponse(f"""
        <h2>Error</h2>
        <pre>{str(e)}</pre>
        """)
@app.websocket("/ws/logs")
async def websocket_logs(ws: WebSocket):
    await ws.accept()

    from app.core.logger import log_store
    import json
    import asyncio

    while True:
        try:
            await ws.send_text(json.dumps(log_store[-100:]))
            await asyncio.sleep(1)
        except Exception:
            break
        
# =========================
# ✅ ✅ NEW: REAL-TIME WEBSOCKET
# =========================
@app.websocket("/ws/live")
async def websocket_live(ws: WebSocket):
    await ws.accept()

    from app.services.trade.trade_manager import index_full_data
    from app.services.trade.trade_state import active_trade

    while True:
        try:
            data = {
                "index_data": index_full_data,
                "active_trade": active_trade
            }

            await ws.send_text(json.dumps(data))

            await asyncio.sleep(1)  # ✅ push every second

        except Exception:
            break

# =========================
# ✅ LOG PAGE (REAL LOGS ✅)
# =========================
@app.get("/logs", response_class=HTMLResponse)
async def logs(request: Request):
    try:
        from app.core.logger import log_store

        template = templates.get_template("logs.html")

        return HTMLResponse(
            template.render(
                request=request,
                logs=log_store[::-1]  # ✅ latest logs first
            )
        )

    except Exception as e:
        logger.error(f"Logs template error: {str(e)}")

        return HTMLResponse(f"""
        <h2>Error</h2>
        <pre>{str(e)}</pre>
        """)