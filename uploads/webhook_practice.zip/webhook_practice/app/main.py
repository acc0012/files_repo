from fastapi import FastAPI
from contextlib import asynccontextmanager
import asyncio
from datetime import datetime, time, timedelta
import pytz

from app.api.routes import webhook
from app.core.database import get_db
from app.core.config import settings
from app.services.socket_manager import start_socket
from app.core.logger import setup_logger

# ✅ LOGGER
logger = setup_logger("market_scheduler")

ist = pytz.timezone("Asia/Kolkata")

# ✅ MARKET TIMINGS
MARKET_START = time(9, 15)
MARKET_END = time(15, 40)


# =========================
# ✅ HELPERS
# =========================
def is_weekday():
    return datetime.now(ist).weekday() < 5  # Mon–Fri


def is_market_open():
    now = datetime.now(ist).time()
    return MARKET_START <= now <= MARKET_END


def format_seconds(seconds: float):
    mins, sec = divmod(int(seconds), 60)
    hrs, mins = divmod(mins, 60)
    return f"{hrs}h {mins}m {sec}s"


def get_next_market_open():
    now = datetime.now(ist)

    next_open = datetime.combine(now.date(), MARKET_START)
    next_open = ist.localize(next_open)

    # ✅ If already past today's 9:15 → move to next day
    if now.time() > MARKET_START:
        next_open += timedelta(days=1)

    # ✅ Skip weekends
    while next_open.weekday() >= 5:
        next_open += timedelta(days=1)

    return next_open


# =========================
# ✅ WAIT LOGIC
# =========================
async def wait_until_market_opens():
    while True:
        now = datetime.now(ist)

        if is_weekday() and is_market_open():
            logger.info("✅ Market OPEN (weekday). No waiting needed.")
            return

        next_open = get_next_market_open()
        sleep_seconds = (next_open - now).total_seconds()

        if not is_weekday():
            logger.info(
                f"📅 Weekend detected | Today: {now.strftime('%A')} | "
                f"Next Market Open: {next_open.strftime('%Y-%m-%d %H:%M:%S')} | "
                f"Sleep: {format_seconds(sleep_seconds)}"
            )
        else:
            logger.info(
                f"⏳ Market CLOSED | Current: {now.strftime('%Y-%m-%d %H:%M:%S')} | "
                f"Next Open: {next_open.strftime('%Y-%m-%d %H:%M:%S')} | "
                f"Sleep: {format_seconds(sleep_seconds)}"
            )

        await asyncio.sleep(max(sleep_seconds, 60))


# =========================
# ✅ MAIN SCHEDULER
# =========================
async def market_socket_scheduler():
    while True:
        now = datetime.now(ist)

        logger.info(f"🚀 Scheduler Tick | Time: {now.strftime('%Y-%m-%d %H:%M:%S')}")

        # ✅ WAIT FOR MARKET
        await wait_until_market_opens()

        start_time = datetime.now(ist)

        logger.info(
            f"✅ Market OPEN | Starting sockets at {start_time.strftime('%H:%M:%S')}"
        )

        try:
            start_socket("NIFTY", "/ws/market/13/")
            start_socket("SENSEX", "/ws/market/51/")

            logger.info("✅ Default sockets started (NIFTY, SENSEX)")

        except Exception as e:
            logger.error(f"❌ Socket start error: {str(e)}")

        # ✅ MARKET CLOSE CALC
        market_close_dt = datetime.combine(start_time.date(), MARKET_END)
        market_close_dt = ist.localize(market_close_dt)

        sleep_seconds = (market_close_dt - start_time).total_seconds()

        if sleep_seconds > 0:
            logger.info(
                f"📉 Market RUNNING | Duration: {format_seconds(sleep_seconds)} | "
                f"Until: {market_close_dt.strftime('%H:%M:%S')}"
            )

            await asyncio.sleep(sleep_seconds)

        logger.info("🛑 Market CLOSED | Waiting for next session...")


# =========================
# ✅ FASTAPI LIFESPAN
# =========================
@asynccontextmanager
async def lifespan(app: FastAPI):
    db = get_db()

    db[settings.PARSED_COLLECTION].create_index("date")
    db[settings.PARSED_COLLECTION].create_index("webhooks.trace_id")

    logger.info("✅ MongoDB indexes created successfully")

    now = datetime.now(ist)

    # ✅ START STATE LOG
    if is_weekday() and is_market_open():
        logger.info(
            f"🟢 App started DURING MARKET HOURS | {now.strftime('%Y-%m-%d %H:%M:%S')}"
        )
    elif is_weekday():
        logger.info(
            f"🟡 App started OUTSIDE MARKET HOURS (weekday) | {now.strftime('%Y-%m-%d %H:%M:%S')}"
        )
    else:
        logger.info(
            f"🔴 App started on WEEKEND | {now.strftime('%Y-%m-%d %H:%M:%S')}"
        )

    # ✅ START SCHEDULER
    asyncio.create_task(market_socket_scheduler())

    logger.info("✅ Market scheduler started")

    yield

    logger.info("🛑 Application shutting down...")


# =========================
# ✅ APP INIT
# =========================
app = FastAPI(
    title="Trading Webhook Service",
    lifespan=lifespan
)

app.include_router(webhook.router)