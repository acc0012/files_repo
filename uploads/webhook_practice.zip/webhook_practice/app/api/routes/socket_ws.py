from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from app.core.logger import setup_logger

# ✅ FIX: use shared state instead of local list
from app.services.socket_state import dashboard_clients

router = APIRouter()
logger = setup_logger("socket_ws")


# =========================
# ✅ WEBSOCKET ENDPOINT
# =========================
@router.websocket("/ws/dashboard")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()

    # ✅ add client safely
    if websocket not in dashboard_clients:
        dashboard_clients.append(websocket)

    logger.info(f"[WS CONNECT] New client connected | Total: {len(dashboard_clients)}")

    try:
        while True:
            # ✅ keep connection alive
            await websocket.receive_text()

    except WebSocketDisconnect:
        logger.warning("[WS DISCONNECT] Client disconnected")

    except Exception as e:
        logger.error(f"[WS ERROR ❌] {str(e)}")

    finally:
        # ✅ SAFE REMOVE
        if websocket in dashboard_clients:
            dashboard_clients.remove(websocket)
            logger.info(f"[WS CLEANUP] Client removed | Total: {len(dashboard_clients)}")

        # ✅ Ensure socket closed
        try:
            await websocket.close()
        except:
            pass