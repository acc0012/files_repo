from fastapi import APIRouter, Request, BackgroundTasks
from app.services.background_service import process_webhook, generate_trace_id
from app.utils.helper import get_index_name

router = APIRouter()

@router.post("/webhook/{index_id}")
async def receive_webhook(
    index_id: str,
    request: Request,
    background_tasks: BackgroundTasks
):
    payload = await request.json()

    # ✅ generate trace id
    trace_id = generate_trace_id()

    # ✅ resolve index name
    index_name = get_index_name(index_id)

    # ✅ attach meta info to payload
    payload["index_id"] = index_id
    payload["index_name"] = index_name

    # ✅ background processing
    background_tasks.add_task(process_webhook, trace_id, payload)

    return {
        "status": "accepted",
        "trace_id": trace_id,
        "index_id": index_id,
        "index_name": index_name
    }