INDEX_MAPPING = {
    "13": "NIFTY",
    "51": "SENSEX",
    "21": "INDIA_VIX"
}


def get_index_name(index_id: str):
    return INDEX_MAPPING.get(index_id, "UNKNOWN")