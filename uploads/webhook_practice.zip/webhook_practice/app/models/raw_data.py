from pydantic import BaseModel
from typing import Dict, Any

class RawWebhook(BaseModel):
    message: str
    full_payload: Dict[str, Any]