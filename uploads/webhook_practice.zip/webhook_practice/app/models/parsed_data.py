from pydantic import BaseModel
from datetime import datetime

class ParsedWebhook(BaseModel):
    count: str
    description: str
    price: float
    type: str
    strike: int
    status: str
    dl: float
    dl_avg: float
    dh: float
    dh_avg: float
    time: datetime