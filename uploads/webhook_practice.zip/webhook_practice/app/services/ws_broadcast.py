# app/services/ws_broadcast.py

import asyncio
from app.services.socket_state import dashboard_clients  # ✅ FIXED


# =========================
# ✅ BROADCAST TO ALL CLIENTS
# =========================
async def broadcast(data: dict):
    if not dashboard_clients:
        return

    dead_clients = []

    for client in list(dashboard_clients):
        try:
            await client.send_json(data)
        except:
            dead_clients.append(client)

    # ✅ cleanup
    for dc in dead_clients:
        if dc in dashboard_clients:
            dashboard_clients.remove(dc)

            try:
                loop = asyncio.get_running_loop()
                loop.create_task(dc.close())
            except:
                pass
