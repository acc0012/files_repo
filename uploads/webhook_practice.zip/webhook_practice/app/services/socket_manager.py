import asyncio
import websockets
import json

from app.core.logger import setup_logger
from app.core.config import settings
from app.services.trade.trade_manager import process_option_tick
import ast
from app.services.socket_state import active_connections

logger = setup_logger("socket_manager")



# ✅ retry config
MAX_RETRIES = 3
RETRY_DELAY = 10  # seconds


# =========================
# ✅ URL NORMALIZATION
# =========================
def normalize_ws_url(url: str) -> str:
    if url.startswith("http://"):
        logger.warning(f"[WS FIX] Converting HTTP → WS: {url}")
        return url.replace("http://", "ws://", 1)
    elif url.startswith("https://"):
        logger.warning(f"[WS FIX] Converting HTTPS → WSS: {url}")
        return url.replace("https://", "wss://", 1)
    return url


# =========================
# ✅ CORE CONNECTION LOGIC
# =========================
async def connect_and_listen(name: str, full_url: str):
    retry_count = 0

    # ✅ ensure correct protocol
    full_url = normalize_ws_url(full_url)

    while retry_count < MAX_RETRIES:
        try:
            logger.info(
                f"[WS CONNECT] Attempt {retry_count + 1}/{MAX_RETRIES} | {name} → {full_url}"
            )

            async with websockets.connect(full_url) as websocket:
                active_connections[name] = websocket

                logger.info(f"[WS CONNECTED ✅] {name}")

                # ✅ reset retry counter after success
                retry_count = 0

                while True:
                    data = await websocket.recv()

                    # ✅ RAW LOG (optional)
                    logger.info(f"[LIVE DATA] {name} => {data}")

                    # =========================
                    # ✅ PROCESS LIVE DATA
                    # =========================
                    try:
                        # Handle string/dict safely
                        if isinstance(data, str):
                            try:
                                parsed = json.loads(data)
                            except:
                                parsed = ast.literal_eval(data)  # fallback if needed
                        else:
                            parsed = data

                        # ✅ Extract LTP
                        ltp = parsed.get("LTP")

                        if ltp:
                            process_option_tick(name, float(ltp))

                    except Exception as e:
                        logger.error(f"[PROCESS ERROR ❌] {name} → {str(e)}")

        except Exception as e:
            retry_count += 1

            logger.error(
                f"[WS ERROR ❌] {name} | Attempt {retry_count}/{MAX_RETRIES} | Error: {str(e)}"
            )

            if retry_count < MAX_RETRIES:
                logger.info(
                    f"[WS RETRY ⏳] {name} | Retrying in {RETRY_DELAY} seconds..."
                )
                await asyncio.sleep(RETRY_DELAY)
            else:
                logger.error(
                    f"[WS FAILED 🚫] {name} | Max retries reached. Giving up."
                )

        finally:
            # ✅ cleanup
            active_connections.pop(name, None)
            logger.warning(f"[WS CLOSED] {name}")


# =========================
# ✅ START SOCKET
# =========================
def start_socket(name: str, websocket_url: str):
    full_url = f"{settings.FEED_SOCKET_URL}{websocket_url}"

    # ✅ avoid duplicate connections
    if name in active_connections:
        logger.info(f"[WS SKIP] Already running: {name}")
        return

    logger.info(f"[WS INIT] Starting socket: {name}")

    asyncio.create_task(connect_and_listen(name, full_url))