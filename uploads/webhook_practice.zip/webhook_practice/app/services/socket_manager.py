import asyncio
import websockets
import json
import ast

from app.core.logger import setup_logger
from app.core.config import settings
from app.services.socket_state import active_connections

# ✅ IMPORT BOTH FUNCTIONS
from app.services.trade.trade_manager import (
    process_option_tick,
    process_index_tick
)

logger = setup_logger("socket_manager")

# ✅ retry config
MAX_RETRIES = 3
RETRY_DELAY = 10  # seconds

# =========================
# ✅ URL NORMALIZATION
# =========================
def normalize_ws_url(url: str) -> str:
    if url.startswith("http://"):
        return url.replace("http://", "ws://", 1)
    elif url.startswith("https://"):
        return url.replace("https://", "wss://", 1)
    return url

# =========================
# ✅ CORE CONNECTION LOGIC
# =========================
async def connect_and_listen(name: str, full_url: str):
    retry_count = 0

    full_url = normalize_ws_url(full_url)

    while retry_count < MAX_RETRIES:
        try:
            async with websockets.connect(full_url) as websocket:
                active_connections[name] = websocket

                retry_count = 0

                while True:
                    data = await websocket.recv()

                    try:
                        # ✅ SAFE PARSE
                        if isinstance(data, str):
                            try:
                                parsed = json.loads(data)
                            except:
                                parsed = ast.literal_eval(data)
                        else:
                            parsed = data

                        if not isinstance(parsed, dict):
                            continue

                        # ============================================
                        # ✅ INDEX FEED (IMPORTANT FIX ✅)
                        # ============================================
                        if name in ["NIFTY", "SENSEX"]:
                            process_index_tick(name, parsed)

                        # ============================================
                        # ✅ OPTION FEED
                        # ============================================
                        else:
                            ltp = parsed.get("LTP")

                            if not ltp:
                                continue

                            process_option_tick(name, float(ltp))

                    except Exception as e:
                        logger.error(f"[PROCESS ERROR ❌] {name} → {str(e)}")

        except Exception as e:
            retry_count += 1

            if retry_count < MAX_RETRIES:
                await asyncio.sleep(RETRY_DELAY)
            else:
                logger.error(f"[WS FAILED 🚫] {name} → {str(e)}")

        finally:
            active_connections.pop(name, None)

# =========================
# ✅ START SOCKET
# =========================
def start_socket(name: str, websocket_url: str):
    full_url = f"{settings.FEED_SOCKET_URL}{websocket_url}"

    if name in active_connections:
        return

    asyncio.create_task(connect_and_listen(name, full_url))