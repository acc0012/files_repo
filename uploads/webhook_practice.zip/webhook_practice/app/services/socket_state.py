# Central shared socket state

active_connections = {}