# app/services/socket_state.py

# ✅ option sockets
active_connections = {}

# ✅ dashboard websocket clients
dashboard_clients = []