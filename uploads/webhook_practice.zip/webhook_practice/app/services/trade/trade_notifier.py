from datetime import datetime
import pytz

from app.services.telegram_service import send_telegram_message

ist = pytz.timezone("Asia/Kolkata")


def now():
    return datetime.now(ist).strftime("%H:%M:%S")


def signal(name, ttype, trace):
    send_telegram_message(
        f"""📡 SIGNAL
{name}
{ttype.upper()}
{trace}
{now()}"""
    )


def entry(name, trace, price, sl):
    send_telegram_message(
        f"""🟢 ENTRY
{name}
{price}
SL:{sl}
{trace}
{now()}"""
    )


def target1(name, trace, entry_price):
    send_telegram_message(
        f"""🎯 T1
{name}
SL→{entry_price}
{trace}
{now()}"""
    )


def target2(name, trace, t2):
    send_telegram_message(
        f"""🚀 T2
{name}
SL→{t2}
{trace}
{now()}"""
    )


def exit(name, trace, reason, entry_price, exit_price, pnl):
    send_telegram_message(
        f"""🔴 EXIT
{name}
{reason}
{entry_price}->{exit_price}
PnL:{pnl}
{trace}
{now()}"""
    )