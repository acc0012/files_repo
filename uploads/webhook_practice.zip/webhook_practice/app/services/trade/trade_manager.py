import asyncio

from app.core.logger import setup_logger
from app.services.socket_state import active_connections

from app.services.trade.trade_state import active_trade
import app.services.trade.trade_state as trade_state

from app.services.trade.trade_logger import log_trade_event
from app.services.trade.trade_notifier import (
    signal,
    entry,
    target1,
    target2,
    exit
)

logger = setup_logger("trade_manager")


def handle_new_signal(name, parsed_data, trace_id):
    new_type = parsed_data.get("type").lower()

    signal(name, new_type, trace_id)

    if trade_state.active_trade:
        current_type = trade_state.active_trade["type"]

        if current_type == new_type:
            return False
        else:
            exit_trade("signal_switch")

    trade_state.active_trade = {
        "trace_id": trace_id,
        "name": name,
        "type": new_type,
        "entry": None,
        "exit": None,
        "pnl": None,
        "target1": None,
        "target2": None,
        "stoploss": None,
        "stage": 0,
        "status": "waiting",
        "dl_avg": parsed_data.get("dl_avg"),
        "dh_avg": parsed_data.get("dh_avg")
    }

    log_trade_event(trade_state.active_trade, "CREATED")

    return True


def process_option_tick(name, ltp):
    trade = trade_state.active_trade

    if not trade or trade["name"] != name:
        return

    ltp = float(ltp)

    if trade["entry"] is None:
        trade["entry"] = ltp
        trade["target1"] = ltp + 5
        trade["target2"] = ltp + 10
        trade["status"] = "active"

        trade["stoploss"] = (
            trade["dl_avg"] if trade["type"].endswith("ce")
            else trade["dh_avg"]
        )

        entry(name, trade["trace_id"], ltp, trade["stoploss"])
        log_trade_event(trade, "ENTRY", ltp)
        return

    sl = trade.get("stoploss")

    if sl is not None:
        if trade["type"].endswith("ce") and ltp <= sl:
            exit_trade("stoploss", ltp)
            return
        if trade["type"].endswith("pe") and ltp >= sl:
            exit_trade("stoploss", ltp)
            return

    if trade["stage"] == 0 and ltp >= trade["target1"]:
        trade["stage"] = 1
        trade["stoploss"] = trade["entry"]

        target1(name, trade["trace_id"], trade["entry"])
        log_trade_event(trade, "TARGET1", ltp)
        return

    if trade["stage"] == 1 and ltp >= trade["target2"]:
        trade["stage"] = 2
        trade["stoploss"] = trade["target2"]

        target2(name, trade["trace_id"], trade["target2"])
        log_trade_event(trade, "TARGET2", ltp)
        return


def exit_trade(reason="unknown", exit_price=None):
    trade = trade_state.active_trade

    if not trade or trade["status"] == "completed":
        return

    entry_price = trade["entry"]
    exit_price = float(exit_price) if exit_price else entry_price

    if entry_price is not None:
        pnl = (
            exit_price - entry_price
            if trade["type"].endswith("ce")
            else entry_price - exit_price
        )
        trade["pnl"] = round(pnl, 2)

    trade["exit"] = exit_price
    trade["status"] = "completed"

    exit(
        trade["name"],
        trade["trace_id"],
        reason,
        entry_price,
        exit_price,
        trade["pnl"]
    )

    log_trade_event(trade, "EXIT", exit_price, {"reason": reason})

    ws = active_connections.get(trade["name"])
    if ws:
        asyncio.create_task(ws.close())

    trade_state.active_trade = None
