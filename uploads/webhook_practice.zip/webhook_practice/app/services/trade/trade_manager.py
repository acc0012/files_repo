import asyncio
from datetime import datetime

from app.core.logger import setup_logger
from app.services.socket_state import active_connections

from app.services.trade.trade_state import active_trade
import app.services.trade.trade_state as trade_state

from app.services.trade.trade_logger import log_trade_event
from app.services.trade.trade_notifier import (
    signal,
    entry,
    target1,
    target2,
    exit
)

from app.services.ws_broadcast import broadcast

logger = setup_logger("trade_manager")


# =========================
# ✅ SAFE BROADCAST HELPER
# =========================
def send_trade_update(trade: dict):
    try:
        loop = asyncio.get_running_loop()
        loop.create_task(
            broadcast({
                "type": "trade",
                "data": {
                    **trade,
                    "updated_at": datetime.now().isoformat()
                }
            })
        )
    except RuntimeError:
        # ✅ no running event loop (safe skip)
        pass
    except Exception as e:
        logger.error(f"[BROADCAST ERROR ❌] {str(e)}")


# =========================
# ✅ HANDLE NEW SIGNAL
# =========================
def handle_new_signal(name, parsed_data, trace_id):
    new_type = parsed_data.get("type").lower()

    # ✅ notify
    signal(name, new_type, trace_id)

    if trade_state.active_trade:
        current_type = trade_state.active_trade["type"]

        if current_type == new_type:
            return False
        else:
            exit_trade("signal_switch")

    trade_state.active_trade = {
        "trace_id": trace_id,
        "name": name,
        "type": new_type,
        "entry": None,
        "exit": None,
        "pnl": None,
        "target1": None,
        "target2": None,
        "stoploss": None,
        "stage": 0,
        "status": "waiting",
        "dl_avg": parsed_data.get("dl_avg"),
        "dh_avg": parsed_data.get("dh_avg")
    }

    log_trade_event(trade_state.active_trade, "CREATED")

    # ✅ broadcast new trade
    send_trade_update(trade_state.active_trade)

    return True


# =========================
# ✅ PROCESS LIVE TICKS
# =========================
def process_option_tick(name, ltp):
    trade = trade_state.active_trade

    if not trade or trade["name"] != name:
        return

    ltp = float(ltp)

    # =========================
    # ✅ ENTRY
    # =========================
    if trade["entry"] is None:
        trade["entry"] = ltp
        trade["target1"] = ltp + 5
        trade["target2"] = ltp + 10
        trade["status"] = "active"

        trade["stoploss"] = (
            trade["dl_avg"] if trade["type"].endswith("ce")
            else trade["dh_avg"]
        )

        entry(name, trade["trace_id"], ltp, trade["stoploss"])
        log_trade_event(trade, "ENTRY", ltp)

        send_trade_update(trade)
        return

    # =========================
    # ✅ STOPLOSS
    # =========================
    sl = trade.get("stoploss")

    if sl is not None:
        if trade["type"].endswith("ce") and ltp <= sl:
            exit_trade("stoploss", ltp)
            return

        if trade["type"].endswith("pe") and ltp >= sl:
            exit_trade("stoploss", ltp)
            return

    # =========================
    # ✅ TARGET 1
    # =========================
    if trade["stage"] == 0 and ltp >= trade["target1"]:
        trade["stage"] = 1
        trade["stoploss"] = trade["entry"]

        target1(name, trade["trace_id"], trade["entry"])
        log_trade_event(trade, "TARGET1", ltp)

        send_trade_update(trade)
        return

    # =========================
    # ✅ TARGET 2
    # =========================
    if trade["stage"] == 1 and ltp >= trade["target2"]:
        trade["stage"] = 2
        trade["stoploss"] = trade["target2"]

        target2(name, trade["trace_id"], trade["target2"])
        log_trade_event(trade, "TARGET2", ltp)

        send_trade_update(trade)
        return


# =========================
# ✅ EXIT TRADE
# =========================
def exit_trade(reason="unknown", exit_price=None):
    trade = trade_state.active_trade

    if not trade or trade["status"] == "completed":
        return

    entry_price = trade["entry"]
    exit_price = float(exit_price) if exit_price else entry_price

    # ✅ calculate pnl
    if entry_price is not None:
        pnl = (
            exit_price - entry_price
            if trade["type"].endswith("ce")
            else entry_price - exit_price
        )
        trade["pnl"] = round(pnl, 2)

    trade["exit"] = exit_price
    trade["status"] = "completed"

    # ✅ notify
    exit(
        trade["name"],
        trade["trace_id"],
        reason,
        entry_price,
        exit_price,
        trade["pnl"]
    )

    log_trade_event(trade, "EXIT", exit_price, {"reason": reason})

    # ✅ broadcast exit
    send_trade_update(trade)

    # ✅ safely close socket
    ws = active_connections.get(trade["name"])
    if ws:
        try:
            loop = asyncio.get_running_loop()
            loop.create_task(ws.close())
        except RuntimeError:
            pass

    trade_state.active_trade = None