from datetime import datetime
import pytz

from app.core.database import get_db
from app.core.config import settings
from app.core.logger import setup_logger

logger = setup_logger("trade_logger")

ist = pytz.timezone("Asia/Kolkata")


def log_trade_event(trade, event, price=None, extra=None):
    try:
        db = get_db()

        db[settings.TRADE_LOG_COLLECTION].insert_one({
            "trace_id": trade.get("trace_id"),
            "trade_name": trade.get("name"),
            "type": trade.get("type"),
            "event": event,
            "price": price,
            "details": extra or {},
            "timestamp": datetime.now(ist)
        })

    except Exception as e:
        logger.error(f"[LOG ERROR ❌] {str(e)}")
