import uuid
from datetime import datetime, time
import pytz

# ✅ CORE
from app.core.database import get_db
from app.core.config import settings
from app.core.logger import setup_logger

# ✅ SERVICES (NON-TRADE)
from app.services.parser_service import parse_message
from app.services.socket_service import fetch_socket_details
from app.services.socket_manager import start_socket
from app.services.telegram_service import send_telegram_message

# ✅ ✅ TRADE MODULE (UPDATED ✅)
from app.services.trade.trade_manager import handle_new_signal

# ✅ LOGGER
logger = setup_logger("webhook_background")

ist = pytz.timezone("Asia/Kolkata")


# ✅ MARKET TIMINGS
MARKET_START = time(9, 15)
MARKET_END = time(15, 40)


# =========================
# ✅ MARKET CHECK HELPERS
# =========================
def is_weekday():
    return datetime.now(ist).weekday() < 5


def is_market_open():
    now = datetime.now(ist).time()
    return MARKET_START <= now <= MARKET_END


def is_trading_time():
    return is_weekday() and is_market_open()


# =========================
# ✅ CORE UTILS
# =========================
def generate_trace_id():
    return str(uuid.uuid4())


def extract_option_type(trade_type: str):
    if not trade_type:
        return None
    if "CE" in trade_type.upper():
        return "ce"
    elif "PE" in trade_type.upper():
        return "pe"
    return None


# =========================
# ✅ MAIN PROCESS
# =========================
async def process_webhook(trace_id: str, payload: dict):
    db = get_db()

    start_time = datetime.now(ist)
    now = start_time
    today = now.strftime("%Y-%m-%d")

    try:
        logger.info(f"[START] Webhook | trace_id={trace_id}")

        # ✅ TELEGRAM
        send_telegram_message(
            f"📥 WEBHOOK RECEIVED\nTrace: {trace_id}"
        )

        # =========================
        # STEP 1: PARSE
        # =========================
        message = payload.get("message")

        if not message:
            raise ValueError("Message missing in payload")

        parsed_data = parse_message(message)

        if not parsed_data or parsed_data.get("error"):
            raise ValueError(f"Parsing failed: {parsed_data.get('error')}")

        # ✅ SAFE POSITION
        parsed_data["index_id"] = payload.get("index_id")

        logger.info(f"[PARSE ✅] trace_id={trace_id}")


        # ✅ TELEGRAM
        send_telegram_message(
            f"🧠 PARSED\nType: {parsed_data.get('type')}\n"
            f"Strike: {parsed_data.get('strike')}\n"
            f"Trace: {trace_id}"
        )

        # =========================
        # EXTRACT
        # =========================
        strike = parsed_data.get("strike")
        trade_type = parsed_data.get("type")
        option_type = extract_option_type(trade_type)

        index_id = payload.get("index_id")
        index_name = payload.get("index_name")

        # =========================
        # STEP 2: TRADE VALIDATION
        # =========================
        socket_name = None

        if strike and option_type:
            socket_name = f"{index_id}_{strike}_{option_type}"

            # ✅ PASS trace_id (IMPORTANT FIX)
            allowed = handle_new_signal(socket_name, parsed_data, trace_id)

            if not allowed:
                logger.warning(f"[IGNORED] {socket_name}")

                send_telegram_message(
                    f"⚠️ SIGNAL IGNORED\n"
                    f"Trade: {socket_name}\n"
                    f"Trace: {trace_id}"
                )
                return

        # =========================
        # STEP 3: ENRICHMENT
        # =========================
        socket_data = None

        if strike and option_type:
            logger.info(f"[API CALL] {index_id} | {strike} | {option_type}")

            socket_data = fetch_socket_details(index_id, strike, option_type)

            if socket_data and socket_data.get("status") != "failed":

                websocket_url = socket_data.get("websocket_url")

                if websocket_url:
                    if is_trading_time():
                        start_socket(socket_name, websocket_url)

                        logger.info(f"[SOCKET START ✅] {socket_name}")

                        send_telegram_message(
                            f"📶 SOCKET STARTED\n"
                            f"Trade: {socket_name}\n"
                            f"Trace: {trace_id}"
                        )

                    else:
                        logger.warning(f"[MARKET CLOSED] {socket_name}")

                        send_telegram_message(
                            f"🟡 MARKET CLOSED\n"
                            f"Trade: {socket_name}\n"
                            f"Trace: {trace_id}"
                        )
                else:
                    logger.warning("[NO WS URL]")
            else:
                logger.warning("[SOCKET FAIL]")

                send_telegram_message(
                    f"❌ SOCKET FETCH FAILED\n"
                    f"Trade: {socket_name}\n"
                    f"Trace: {trace_id}"
                )

        else:
            logger.warning("[MISSING STRIKE/TYPE]")

        # =========================
        # STEP 4: SAVE TO DB
        # =========================
        webhook_entry = {
            "trace_id": trace_id,
            "index_id": index_id,
            "index_name": index_name,
            "created_at": now,
            "status": "processed",
            "raw": payload,
            "parsed": parsed_data,
            "socket_data": socket_data,
            "market_status": "open" if is_trading_time() else "closed"
        }

        if is_trading_time():
            db[settings.PARSED_COLLECTION].update_one(
                {"date": today},
                {
                    "$push": {
                        "webhooks": {
                            "$each": [webhook_entry],
                            "$slice": -1000
                        }
                    },
                    "$set": {"last_updated": now},
                    "$setOnInsert": {
                        "date": today,
                        "created_at": now
                    }
                },
                upsert=True
            )
        else:
            db[settings.OUTSIDE_MARKET_COLLECTION].insert_one(webhook_entry)

        duration = (datetime.now(ist) - start_time).total_seconds()

        logger.info(f"[END ✅] trace_id={trace_id} | {duration}s")

    except Exception as e:
        logger.error(f"[FAIL ❌] trace_id={trace_id} | {str(e)}")

        # ✅ TELEGRAM ERROR
        send_telegram_message(
            f"🚨 ERROR\nTrace: {trace_id}\nError: {str(e)}"
        )

        db[settings.PARSED_COLLECTION].update_one(
            {"date": today},
            {
                "$push": {
                    "webhooks": {
                        "trace_id": trace_id,
                        "index_id": payload.get("index_id"),
                        "index_name": payload.get("index_name"),
                        "status": "failed",
                        "error": str(e),
                        "raw": payload,
                        "created_at": datetime.now(ist)
                    }
                }
            },
            upsert=True
        )