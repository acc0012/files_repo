import re
from datetime import datetime

def parse_message(message: str):
    try:
        data = {}

        patterns = {
            "count": r"Count=(\S+)",
            "description": r"Count=\S+\s+(\S+)",
            "price": r"Price=([\d.]+)",
            "type": r"Type=(\S+)",
            "strike": r"Strike=(\d+)",
            "status": r"Status=(\S+)",
            "dl": r"DL=([\d.]+)",
            "dl_avg": r"DL_Avg=([\d.]+)",
            "dh": r"DH=([\d.]+)",
            "dh_avg": r"DH_Avg=([\d.]+)",
            "time": r"Time=([\d\-:\s]+)"
        }

        for key, pattern in patterns.items():
            match = re.search(pattern, message)
            if match:
                data[key] = match.group(1)

        data["price"] = float(data.get("price", 0))
        data["strike"] = int(data.get("strike", 0))
        data["dl"] = float(data.get("dl", 0))
        data["dl_avg"] = float(data.get("dl_avg", 0))
        data["dh"] = float(data.get("dh", 0))
        data["dh_avg"] = float(data.get("dh_avg", 0))
        data["time"] = datetime.strptime(data["time"], "%Y-%m-%d %H:%M")

        return data

    except Exception as e:
        return {"error": str(e)}