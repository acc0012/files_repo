import requests

from app.core.config import settings
from app.core.logger import setup_logger

logger = setup_logger("telegram_service")


def send_telegram_message(message: str):
    try:
        if not settings.TELEGRAM_BOT_TOKEN or not settings.TELEGRAM_CHAT_ID:
            logger.warning("[TG WARNING] Telegram config missing")
            return

        url = f"https://api.telegram.org/bot{settings.TELEGRAM_BOT_TOKEN}/sendMessage"

        payload = {
            "chat_id": settings.TELEGRAM_CHAT_ID,
            "text": message
        }

        response = requests.post(url, json=payload, timeout=5)

        if response.status_code != 200:
            logger.error(f"[TG ERROR ❌] {response.text}")

    except Exception as e:
        logger.error(f"[TG FAIL ❌] {str(e)}")