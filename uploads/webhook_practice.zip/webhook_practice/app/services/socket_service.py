import requests
import urllib3

from datetime import datetime
from app.core.config import settings
from app.core.logger import setup_logger

# ✅ disable SSL warnings (dev)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logger = setup_logger("socket_service")


def fetch_socket_details(index_id: str, strike: int, option_type: str):
    start_time = datetime.now()  # ✅ track duration

    try:
        logger.info(
            f"[SOCKET START] Fetching socket details | index={index_id} | strike={strike} | type={option_type}"
        )

        url = f"{settings.BASE_WEBSOCKET_URL}/{index_id}/"

        payload = {
            "strike_price": strike,
            "option_type": option_type.lower()
        }

        # -------------------------
        # STEP 1: API CALL
        # -------------------------
        logger.info(f"[SOCKET STEP 1] Calling API | url={url}")

        response = requests.post(
            url,
            json=payload,
            timeout=5,
            verify=False   # ⚠️ dev only
        )

        # -------------------------
        # STEP 2: STATUS CHECK
        # -------------------------
        if response.status_code != 200:
            raise Exception(f"API failed | status={response.status_code}")

        logger.info(f"[SOCKET STEP 2 ✅] API response received")

        # -------------------------
        # STEP 3: PARSE RESPONSE
        # -------------------------
        data = response.json()

        api_status = data.get("status")  # ✅ dynamic status
        websocket_url = data.get("websocket_url")
        instrument = data.get("instrument")
        mode = data.get("mode")  # ✅ dummy/live support

        # -------------------------
        # STEP 4: BUILD FULL WS URL
        # -------------------------
        full_socket_url = None

        if websocket_url:
            full_socket_url = f"{settings.FEED_SOCKET_URL}{websocket_url}"

        logger.info(
            f"[SOCKET STEP 3 ✅] Parsed response | status={api_status} | mode={mode} | instrument={instrument}"
        )

        # -------------------------
        # END
        # -------------------------
        duration = (datetime.now() - start_time).total_seconds()

        logger.info(
            f"[SOCKET END ✅] Socket fetch complete | index={index_id} | duration={duration}s"
        )

        return {
            "status": api_status if api_status else "success",  # ✅ flexible handling
            "instrument": instrument,
            "websocket_url": websocket_url,
            "full_socket_url": full_socket_url,
            "mode": mode
        }

    except Exception as e:
        duration = (datetime.now() - start_time).total_seconds()

        logger.error(
            f"[SOCKET FAIL ❌] Socket fetch failed | index={index_id} | error={str(e)} | duration={duration}s"
        )

        return {
            "status": "failed",
            "error": str(e)
        }