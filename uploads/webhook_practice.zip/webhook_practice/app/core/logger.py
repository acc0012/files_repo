import logging
import sys

def setup_logger(name: str):
    logger = logging.getLogger(name)

    if logger.handlers:
        return logger  # ✅ avoid duplicate handlers

    logger.setLevel(logging.INFO)

    formatter = logging.Formatter(
        "[%(asctime)s] [%(levelname)s] [%(name)s] - %(message)s\n"
    )

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(formatter)

    logger.addHandler(handler)

    return logger