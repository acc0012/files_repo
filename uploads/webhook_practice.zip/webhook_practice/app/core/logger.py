import logging
import sys
import asyncio

from app.services.ws_broadcast import broadcast


# =========================
# ✅ CUSTOM LOG HANDLER
# =========================
class WebSocketLogHandler(logging.Handler):
    def emit(self, record):
        try:
            log_message = self.format(record)

            # ✅ SAFE event loop handling
            try:
                loop = asyncio.get_running_loop()
                loop.create_task(
                    broadcast({
                        "type": "log",
                        "message": log_message.strip()
                    })
                )
            except RuntimeError:
                # ✅ no event loop → skip safely
                pass

        except Exception:
            # ✅ never break logging system
            pass


# =========================
# ✅ LOGGER SETUP
# =========================
def setup_logger(name: str):
    logger = logging.getLogger(name)

    # ✅ prevent duplicate handlers
    if logger.handlers:
        return logger

    logger.setLevel(logging.INFO)

    formatter = logging.Formatter(
        "[%(asctime)s] [%(levelname)s] [%(name)s] - %(message)s"
    )

    # ✅ Console Handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)

    # ✅ WebSocket Handler
    ws_handler = WebSocketLogHandler()
    ws_handler.setFormatter(formatter)

    # ✅ attach handlers
    logger.addHandler(console_handler)
    logger.addHandler(ws_handler)

    # ✅ optional: stop propagation (avoid duplicate logs in root logger)
    logger.propagate = False

    return logger