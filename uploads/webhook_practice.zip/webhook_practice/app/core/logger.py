import logging
import sys
import os
import uuid

# ✅ store logs (for UI)
log_store = []

# ✅ ensure logs directory exists
LOG_FILE = "app.log"


class InMemoryHandler(logging.Handler):
    def emit(self, record):
        log_entry = self.format(record)

        # ✅ store last 200 logs
        log_store.append(log_entry)
        if len(log_store) > 200:
            log_store.pop(0)


class UniqueIDFilter(logging.Filter):
    def filter(self, record):
        # ✅ add unique id to every log
        record.log_id = str(uuid.uuid4())[:8]  # short ID
        return True


def setup_logger(name: str):
    logger = logging.getLogger(name)

    if logger.handlers:
        return logger

    logger.setLevel(logging.INFO)  # ✅ better keep INFO for logs

    # ✅ FORMAT WITH UNIQUE ID + TIME
    formatter = logging.Formatter(
        "[%(asctime)s] [%(levelname)s] [%(name)s] [ID:%(log_id)s] - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )

    # =========================
    # ✅ CONSOLE HANDLER
    # =========================
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    console_handler.addFilter(UniqueIDFilter())

    # =========================
    # ✅ FILE HANDLER (app.log)
    # =========================
    file_handler = logging.FileHandler(LOG_FILE, encoding="utf-8")
    file_handler.setFormatter(formatter)
    file_handler.addFilter(UniqueIDFilter())

    # =========================
    # ✅ MEMORY HANDLER (for UI logs page)
    # =========================
    memory_handler = InMemoryHandler()
    memory_handler.setFormatter(formatter)
    memory_handler.addFilter(UniqueIDFilter())

    # ✅ attach handlers
    logger.addHandler(console_handler)
    logger.addHandler(file_handler)
    logger.addHandler(memory_handler)

    return logger
