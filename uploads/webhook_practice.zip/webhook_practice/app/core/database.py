from pymongo import MongoClient
from app.core.config import settings
from app.core.logger import setup_logger

# ✅ setup logger
logger = setup_logger("mongodb")

# ✅ initialize client
try:
    client = MongoClient(settings.MONGODB_URI)

    # ✅ select DB
    db = client[settings.DB_NAME]

    # ✅ test connection
    client.admin.command("ping")
    logger.info("✅ MongoDB connected successfully")

except Exception as e:
    logger.error(f"❌ MongoDB connection failed: {str(e)}")
    raise


def get_db():
    return db