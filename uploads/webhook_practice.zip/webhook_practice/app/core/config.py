from dotenv import load_dotenv
import os

load_dotenv()

class Settings:
    MONGODB_URI = os.getenv("MONGO_URI")
    DB_NAME = os.getenv("DB_NAME")
    RAW_COLLECTION = os.getenv("RAW_COLLECTION")
    PARSED_COLLECTION = os.getenv("PARSED_COLLECTION")
    BASE_WEBSOCKET_URL = os.getenv("BASE_WEBSOCKET_URL")
    FEED_SOCKET_URL = os.getenv("FEED_SOCKET_URL")
    OUTSIDE_MARKET_COLLECTION = os.getenv("OUTSIDE_MARKET_COLLECTION")

    # ✅ FIXED
    TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")
    TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
    TRADE_LOG_COLLECTION = os.getenv("TRADE_LOG_COLLECTION")

settings = Settings()