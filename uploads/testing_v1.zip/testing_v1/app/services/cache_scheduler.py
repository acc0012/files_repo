from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger

from app.core.logger import get_logger
from app.services.instrument_loader import load_instruments

logger = get_logger("cache_scheduler")

scheduler = BackgroundScheduler(timezone="Asia/Kolkata")


def refresh_cache():
    logger.info("Starting scheduled instrument cache refresh...")

    load_instruments()

    logger.info("Instrument cache refresh completed.")


def start_scheduler():
    scheduler.add_job(
        refresh_cache,
        CronTrigger(hour=7, minute=30),
        id="instrument_cache_refresh",
        replace_existing=True,
    )

    scheduler.start()

    logger.info(
        "Instrument cache scheduler started. "
        "Daily refresh scheduled at 07:30 AM IST."
    )


def stop_scheduler():
    if scheduler.running:
        scheduler.shutdown()
        logger.info("Instrument cache scheduler stopped.")
