from app.db.upstox_db import instrument_collection
from app.core.cache import instrument_cache
from app.core.logger import get_logger

logger = get_logger("instrument_loader")


def get_strike(strike: str | int):
    return instrument_cache.get(str(strike))


def get_ce(strike: str | int):
    strike_data = instrument_cache.get(str(strike))

    if not strike_data:
        return None

    return strike_data.get("ce")


def get_pe(strike: str | int):
    strike_data = instrument_cache.get(str(strike))

    if not strike_data:
        return None

    return strike_data.get("pe")


def load_instruments() -> None:
    """
    Load the latest instrument document into memory cache.
    """

    try:
        logger.info("Loading instruments from MongoDB...")

        doc = instrument_collection.find_one()

        if not doc:
            logger.warning("No instrument document found.")
            return

        instrument_cache.clear()

        data = doc.get("data", {})
        instrument_cache.update(data)

        total_strikes = doc.get(
            "total_strikes",
            len(instrument_cache)
        )

        expiry = doc.get("expiry")

        logger.info(
            "Successfully loaded %s strikes into memory cache "
            "(expiry=%s)",
            total_strikes,
            expiry,
        )

    except Exception as exc:
        logger.exception(
            "Failed to load instruments from MongoDB: %s",
            str(exc),
        )
        raise