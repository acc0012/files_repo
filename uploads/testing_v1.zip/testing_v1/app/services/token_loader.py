import app.core.token_cache as token_cache

from app.db.upstox_db import token_collection
from app.core.logger import get_logger

logger = get_logger("upstox_token")


def mask_token(token: str) -> str:
    """
    Show only first few and last few characters
    of the token for logging purposes.
    """
    if not token:
        return "EMPTY"

    if len(token) <= 15:
        return f"{token[:5]}*****"

    return f"{token[:10]}...{token[-5:]}"


def get_access_token() -> str | None:
    return token_cache.upstox_access_token


def load_access_token() -> None:
    """
    Load Upstox access token from MongoDB.
    """

    try:
        logger.info("Loading Upstox access token from MongoDB...")

        doc = token_collection.find_one({"_id": "upstox_access_token"})

        if not doc:
            logger.warning("Upstox access token document not found.")
            return

        access_token = doc.get("access_token")

        if not access_token:
            logger.warning("Access token is empty.")
            return

        token_cache.upstox_access_token = access_token

        logger.info(
            "Upstox access token fetched successfully. " "token=%s updated_at=%s",
            mask_token(access_token),
            doc.get("updated_at"),
        )

    except Exception as exc:
        logger.exception(
            "Failed to load Upstox access token: %s",
            str(exc),
        )
        raise
