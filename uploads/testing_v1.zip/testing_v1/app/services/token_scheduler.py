from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger

from app.services.token_loader import load_access_token
from app.core.logger import get_logger

logger = get_logger("token_scheduler")

scheduler = BackgroundScheduler(timezone="Asia/Kolkata")


def refresh_access_token():
    logger.info("Starting scheduled Upstox token refresh...")

    load_access_token()

    logger.info("Upstox token refresh completed.")


def start_token_scheduler():

    scheduler.add_job(
        refresh_access_token,
        CronTrigger(hour=8, minute=30),
        id="upstox_token_refresh",
        replace_existing=True,
    )

    scheduler.start()

    logger.info(
        "Upstox token scheduler started. " "Daily refresh scheduled at 08:30 AM IST."
    )


def stop_token_scheduler():
    if scheduler.running:
        scheduler.shutdown()
