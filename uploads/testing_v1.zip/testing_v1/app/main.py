from contextlib import asynccontextmanager

from fastapi import FastAPI

from app.core.logger import get_logger

from app.routes.instruments import router as instrument_router

from app.services.instrument_loader import load_instruments
from app.services.token_loader import load_access_token

from app.services.cache_scheduler import (
    start_scheduler,
    stop_scheduler,
)

from app.services.token_scheduler import (
    start_token_scheduler,
    stop_token_scheduler,
)

from app.upstox_app.upstox_connection import (
    initialize_upstox_connection,
)

from app.upstox_app.get_funds import (
    validate_token,
)

logger = get_logger("main")


@asynccontextmanager
async def lifespan(app: FastAPI):

    logger.info("Loading instrument cache...")
    load_instruments()

    logger.info("Loading Upstox access token...")
    load_access_token()

    logger.info("Initializing Upstox connection...")
    initialize_upstox_connection()

    logger.info("Validating Upstox access token using funds API...")

    if not validate_token():
        logger.error("Upstox token validation failed. " "Application startup aborted.")
        raise RuntimeError("Invalid Upstox access token.")

    logger.info("Upstox token validation successful.")

    start_scheduler()
    start_token_scheduler()

    logger.info("Application startup completed.")

    yield

    stop_scheduler()
    stop_token_scheduler()

    logger.info("Application shutdown.")


app = FastAPI(
    title="Upstox API",
    lifespan=lifespan,
)

app.include_router(instrument_router)


@app.get("/health")
def health():
    return {"status": "ok"}
