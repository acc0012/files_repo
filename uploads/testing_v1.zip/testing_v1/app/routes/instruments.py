# app/routes/instruments.py

from fastapi import APIRouter, HTTPException

from app.core.cache import instrument_cache
from app.models.instrument import InstrumentRequest

router = APIRouter(prefix="/api/v1", tags=["Instruments"])


@router.post("/instrument")
async def get_instrument(payload: InstrumentRequest):

    strike_data = instrument_cache.get(str(payload.strike))

    if not strike_data:
        raise HTTPException(
            status_code=404, detail=f"Strike {payload.strike} not found"
        )

    instrument = strike_data.get(payload.type)

    if not instrument:
        raise HTTPException(
            status_code=404,
            detail=f"{payload.type.upper()} data not found for strike {payload.strike}",
        )

    return {
        "success": True,
        "strike": payload.strike,
        "type": payload.type,
        "data": instrument,
    }
