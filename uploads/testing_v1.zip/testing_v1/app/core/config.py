from dotenv import load_dotenv
import os

load_dotenv()


class Settings:
    MONGO_URL = os.getenv("MONGO_URL")

    UPSTOX_DB = os.getenv("UPSTOX_DB", "UPSTOX_APP")

    UPSTOX_INST_COLLECTION = os.getenv("UPSTOX_INST_COLLECTION", "latest_instruments")

    UPSTOX_TOKEN_COLLECTION: str = os.getenv("UPSTOX_TOKEN_COLLECTION", "upstox_tokens")


settings = Settings()
