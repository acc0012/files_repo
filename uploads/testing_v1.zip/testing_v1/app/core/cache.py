from typing import Dict, Any


instrument_cache: Dict[str, Any] = {}