# app/models/instrument.py

from pydantic import BaseModel
from typing import Literal


class InstrumentRequest(BaseModel):
    strike: int
    type: Literal["ce", "pe"]