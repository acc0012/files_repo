import upstox_client
from upstox_client.rest import ApiException

from app.core.logger import get_logger
from app.upstox_app.upstox_connection import get_api_client

logger = get_logger("get_funds")

API_VERSION = "2.0"


def validate_token() -> bool:
    """
    Validate current Upstox token by
    fetching fund details.
    """

    try:
        user_api = upstox_client.UserApi(get_api_client())

        response = user_api.get_user_fund_margin(API_VERSION)

        response_dict = response.to_dict()

        equity = response_dict.get("data", {}).get("equity", {})

        available_margin = equity.get("available_margin", 0)

        used_margin = equity.get("used_margin", 0)

        payin_amount = equity.get("payin_amount", 0)

        logger.info(
            "Upstox token validation successful. "
            "Available Margin=%.2f | Used Margin=%.2f | Payin Amount=%.2f",
            available_margin,
            used_margin,
            payin_amount,
        )

        return True

    except ApiException as exc:
        logger.error(
            "Upstox token validation failed: %s",
            str(exc),
        )
        return False

    except Exception as exc:
        logger.exception(
            "Unexpected error validating token: %s",
            str(exc),
        )
        return False
