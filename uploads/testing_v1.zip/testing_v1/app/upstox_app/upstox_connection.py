import upstox_client

from app.core.logger import get_logger

from app.services.token_loader import (
    get_access_token,
    load_access_token,
)

logger = get_logger("upstox_connection")

_configuration = None
_api_client = None


def mask_token(token: str) -> str:
    """
    Mask token for logging.
    """

    if not token:
        return "EMPTY"

    if len(token) <= 15:
        return f"{token[:5]}*****"

    return f"{token[:10]}...{token[-5:]}"


def initialize_upstox_connection() -> None:
    """
    Initialize global Upstox API client.

    If token is not available in memory,
    automatically load it from MongoDB.
    """

    global _configuration
    global _api_client

    access_token = get_access_token()

    if not access_token:
        logger.warning("Access token not found in cache. " "Loading from MongoDB...")

        load_access_token()

        access_token = get_access_token()

    if not access_token:
        raise ValueError("Unable to load Upstox access token.")

    configuration = upstox_client.Configuration()

    configuration.access_token = access_token

    api_client = upstox_client.ApiClient(configuration)

    _configuration = configuration
    _api_client = api_client

    logger.info(
        "Upstox connection initialized successfully. " "token=%s",
        mask_token(access_token),
    )


def get_configuration():
    """
    Get global configuration instance.
    """

    if _configuration is None:
        initialize_upstox_connection()

    return _configuration


def get_api_client() -> upstox_client.ApiClient:
    """
    Get global ApiClient instance.
    """

    if _api_client is None:
        initialize_upstox_connection()

    return _api_client


def refresh_connection() -> None:
    """
    Recreate Upstox client using the
    latest token from MongoDB.
    """

    global _configuration
    global _api_client

    logger.info("Refreshing Upstox connection...")

    _configuration = None
    _api_client = None

    load_access_token()
    initialize_upstox_connection()

    logger.info("Upstox connection refreshed successfully.")
