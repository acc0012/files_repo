from datetime import date, timedelta

import upstox_client
from upstox_client.rest import ApiException

from app.core.logger import get_logger
from app.upstox_app.upstox_connection import get_api_client

logger = get_logger("historical_data")

API_VERSION = "2.0"


def get_intraday_data(
    instrument_key: str,
    interval: str = "1minute",
):
    """
    Fetch today's intraday candles.
    """

    try:
        logger.info(
            "Fetching intraday data | instrument=%s interval=%s",
            instrument_key,
            interval,
        )

        history_api = upstox_client.HistoryApi(get_api_client())

        response = history_api.get_intra_day_candle_data(
            instrument_key,
            interval,
            API_VERSION,
        )

        response_dict = response.to_dict()

        candles = response_dict.get("data", {}).get("candles", [])

        candle_count = len(candles)

        actual_start_candle = None
        actual_end_candle = None

        if candles:
            # Upstox returns newest -> oldest
            actual_end_candle = candles[0][0]
            actual_start_candle = candles[-1][0]

        logger.info(
            "Fetched %s intraday candles. Start=%s End=%s",
            candle_count,
            actual_start_candle,
            actual_end_candle,
        )

        return {
            "status": response_dict.get("status"),
            "summary": {
                "instrument_key": instrument_key,
                "interval": interval,
                "actual_start_candle": actual_start_candle,
                "actual_end_candle": actual_end_candle,
                "total_candles": candle_count,
            },
            "data": {"candles": candles},
        }

    except ApiException as exc:
        logger.exception(
            "Upstox intraday API exception: %s",
            str(exc),
        )
        raise

    except Exception as exc:
        logger.exception(
            "Unexpected error fetching intraday data: %s",
            str(exc),
        )
        raise


def get_historical_data(
    instrument_key: str,
    interval: str,
    from_date: str,
    to_date: str,
):
    """
    Fetch historical candles.
    """

    try:
        logger.info(
            "Fetching historical data | instrument=%s interval=%s from=%s to=%s",
            instrument_key,
            interval,
            from_date,
            to_date,
        )

        history_api = upstox_client.HistoryApi(get_api_client())

        response = history_api.get_historical_candle_data1(
            instrument_key,
            interval,
            to_date,
            from_date,
            API_VERSION,
        )

        response_dict = response.to_dict()

        candles = response_dict.get("data", {}).get("candles", [])

        candle_count = len(candles)

        actual_start_candle = None
        actual_end_candle = None

        if candles:
            actual_end_candle = candles[0][0]
            actual_start_candle = candles[-1][0]

        logger.info(
            "Fetched %s historical candles. Start=%s End=%s",
            candle_count,
            actual_start_candle,
            actual_end_candle,
        )

        return {
            "status": response_dict.get("status"),
            "summary": {
                "instrument_key": instrument_key,
                "interval": interval,
                "requested_from_date": from_date,
                "requested_to_date": to_date,
                "actual_start_candle": actual_start_candle,
                "actual_end_candle": actual_end_candle,
                "total_candles": candle_count,
            },
            "data": {"candles": candles},
        }

    except ApiException as exc:
        logger.exception(
            "Upstox API exception: %s",
            str(exc),
        )
        raise

    except Exception as exc:
        logger.exception(
            "Unexpected error: %s",
            str(exc),
        )
        raise


def get_last_n_market_days_data(
    instrument_key: str,
    days: int = 3,
    interval: str = "1minute",
):
    """
    Fetch last N market days INCLUDING today's intraday candles.
    """

    try:
        today = date.today()

        historical_days_required = max(
            days - 1,
            0,
        )

        market_days_found = 0
        current_date = today - timedelta(days=1)

        while market_days_found < historical_days_required:

            if current_date.weekday() < 5:
                market_days_found += 1

            current_date -= timedelta(days=1)

        from_date = (current_date + timedelta(days=1)).strftime("%Y-%m-%d")

        to_date = (today - timedelta(days=1)).strftime("%Y-%m-%d")

        historical_candles = []

        if historical_days_required > 0:

            historical_response = get_historical_data(
                instrument_key=instrument_key,
                interval=interval,
                from_date=from_date,
                to_date=to_date,
            )

            historical_candles = historical_response["data"]["candles"]

        logger.info("Fetching today's intraday candles...")

        intraday_response = get_intraday_data(
            instrument_key=instrument_key,
            interval=interval,
        )

        intraday_candles = intraday_response["data"]["candles"]

        merged_candles = intraday_candles + historical_candles

        candle_count = len(merged_candles)

        actual_start_candle = None
        actual_end_candle = None

        if merged_candles:
            actual_end_candle = merged_candles[0][0]
            actual_start_candle = merged_candles[-1][0]

        trading_dates = sorted({candle[0][:10] for candle in merged_candles})

        logger.info(
            "Merged candle count=%s Start=%s End=%s",
            candle_count,
            actual_start_candle,
            actual_end_candle,
        )

        return {
            "status": "success",
            "summary": {
                "instrument_key": instrument_key,
                "interval": interval,
                "requested_market_days": days,
                "actual_start_candle": actual_start_candle,
                "actual_end_candle": actual_end_candle,
                "total_candles": candle_count,
                "historical_candles": len(historical_candles),
                "intraday_candles": len(intraday_candles),
                "trading_days_returned": len(trading_dates),
                "trading_dates": trading_dates,
            },
            "data": {"candles": merged_candles},
        }

    except Exception as exc:
        logger.exception(
            "Failed to fetch merged market data: %s",
            str(exc),
        )
        raise
