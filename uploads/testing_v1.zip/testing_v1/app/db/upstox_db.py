from pymongo import MongoClient

from app.core.config import settings
from app.core.logger import get_logger

logger = get_logger("upstox_db")

client = MongoClient(settings.MONGO_URL)

db = client[settings.UPSTOX_DB]

instrument_collection = db[
    settings.UPSTOX_INST_COLLECTION
]

token_collection = db[
    settings.UPSTOX_TOKEN_COLLECTION
]

logger.info(
    f"Connected to DB={settings.UPSTOX_DB}"
)