# test_history.py

import json

from app.upstox_app.get_historical_data import (
    get_last_n_market_days_data,
)

try:
    print("Fetching historical data...")

    data = get_last_n_market_days_data(
        instrument_key="NSE_FO|51375",
        days=3,
        interval="1minute",
    )

    with open("output.json", "w", encoding="utf-8") as f:
        json.dump(
            data,
            f,
            indent=4,
            default=str,
        )

    print(
        f"Historical data saved successfully. "
        f"Candles Count: "
        f"{len(data.get('data', {}).get('candles', []))}"
    )

except Exception as exc:
    print(f"Failed to fetch historical data: {exc}")
    raise
