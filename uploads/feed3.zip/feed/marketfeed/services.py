import json
import websocket
import threading
import time
import ssl

from datetime import datetime

from django.conf import settings
from core.logger import get_logger
from core.db import get_orders_collection
from marketfeed.state import update_price, get_price
from core.telegram import send_telegram_alert

logger = get_logger("marketfeed")

BASE_WS = settings.BASE_WS

MANUAL_CLOSE = set()

ACTIVE_WS = {}
ACTIVE_THREADS = {}
ACTIVE_SECURITIES = set()

WS_LOCK = threading.Lock()


# -------------------------------------------------
# REMOVE WS
# -------------------------------------------------
def remove_ws(security_id):
    with WS_LOCK:
        ACTIVE_SECURITIES.discard(security_id)
        ACTIVE_WS.pop(security_id, None)
        ACTIVE_THREADS.pop(security_id, None)

    logger.info(f"[WS REMOVED] Security {security_id}")


# -------------------------------------------------
# CLOSE SINGLE WS
# -------------------------------------------------
def close_feed_ws(security_id):

    with WS_LOCK:
        ws = ACTIVE_WS.get(security_id)

        if not ws:
            return

        MANUAL_CLOSE.add(security_id)

        try:
            logger.info(f"[WS CLOSE] {security_id}")
            ws.close()
        except Exception as e:
            logger.error(f"[WS CLOSE ERROR] {security_id} {e}")

    remove_ws(security_id)


# -------------------------------------------------
# ✅ SAVE EXIT (WITH TELEGRAM)
# -------------------------------------------------
def save_exit(security_id):

    try:
        collection = get_orders_collection()

        order = collection.find_one(
            {
                "security_id": security_id,
                "status": "placed",
                "entry_price": {"$exists": True},
                "exit_price": {"$exists": False}
            },
            sort=[("created_at", -1)]
        )

        if not order:
            return

        last_price = None

        for _ in range(5):
            last_price = get_price(security_id)
            if last_price is not None:
                break
            time.sleep(0.3)

        if last_price is None:
            logger.warning("[EXIT SKIPPED] No LTP")
            return

        collection.update_one(
            {"_id": order["_id"]},
            {
                "$set": {
                    "exit_price": float(last_price),
                    "exit_time": datetime.utcnow(),
                    "status": "completed"
                }
            }
        )

        logger.info(f"[EXIT SAVED] {security_id} Exit={last_price}")

        # ✅ TELEGRAM EXIT ALERT
        try:
            order["exit_price"] = float(last_price)
            order["status"] = "exit"
            send_telegram_alert(order)
        except Exception:
            pass

    except Exception as e:
        logger.error(f"[EXIT ERROR] {security_id} {e}")


# -------------------------------------------------
# CLOSE OLD FEEDS
# -------------------------------------------------
def close_all_feeds_except(new_security_id):

    old_list = list(ACTIVE_SECURITIES)

    for sec in old_list:

        if sec == new_security_id:
            continue

        logger.info(f"[CLOSING OLD] {sec}")

        save_exit(sec)
        close_feed_ws(sec)

        time.sleep(0.3)


# -------------------------------------------------
# ✅ SAVE ENTRY PRICE (WITH TELEGRAM)
# -------------------------------------------------
def save_entry_price(security_id, data):

    try:
        ltp = data.get("LTP")
        if ltp is None:
            return

        collection = get_orders_collection()

        order = collection.find_one(
            {
                "security_id": security_id,
                "status": "placed",
                "entry_price": {"$exists": False}
            },
            sort=[("created_at", -1)]
        )

        if not order:
            return

        collection.update_one(
            {"_id": order["_id"]},
            {
                "$set": {
                    "entry_price": float(ltp),
                    "entry_time": datetime.utcnow(),
                    "quote_data": data
                }
            }
        )

        logger.info(f"[ENTRY SAVED] {security_id} Entry={ltp}")

        # ✅ TELEGRAM ENTRY ALERT
        try:
            order["entry_price"] = float(ltp)
            order["status"] = "entry"
            send_telegram_alert(order)
        except Exception:
            pass

    except Exception as e:
        logger.error(f"[ENTRY ERROR] {security_id} {e}")


# -------------------------------------------------
# TRADE LEVELS
# -------------------------------------------------
def update_trade_levels(order, ltp):

    entry = order.get("entry_price")
    if not entry:
        return None

    sl = entry - 20
    t1 = entry + 5
    t2 = entry + 10

    current_sl = order.get("sl", sl)

    if ltp > t2:
        current_sl = t2

    return {
        "sl": current_sl,
        "t1": t1,
        "t2": t2
    }


# -------------------------------------------------
# START FEED WS
# -------------------------------------------------
RETRY_COUNTER = {}

def start_feed_ws(security_id, retry_delay=3):

    with WS_LOCK:
        if security_id in ACTIVE_SECURITIES:
            logger.info(f"[WS ALREADY RUNNING] {security_id}")
            return

        ACTIVE_SECURITIES.add(security_id)

    url = f"{BASE_WS}/{security_id}/quote"

    logger.info(f"[WS INIT] {security_id}")

    def on_message(ws, message):
        try:
            data = json.loads(message)

            ltp = data.get("LTP")
            if ltp is not None:
                update_price(security_id, float(ltp))

            # ✅ handles entry + alert internally
            save_entry_price(security_id, data)

            collection = get_orders_collection()

            order = collection.find_one(
                {
                    "security_id": security_id,
                    "status": "placed",
                    "entry_price": {"$exists": True}
                },
                sort=[("created_at", -1)]
            )

            if not order or ltp is None:
                return

            levels = update_trade_levels(order, float(ltp))

            if levels:

                # ✅ SL HIT → EXIT
                if ltp <= levels["sl"]:
                    logger.info(f"[SL HIT] {security_id}")
                    save_exit(security_id)
                    return

                if ltp >= levels["t2"]:
                    logger.info(f"[T2 HIT] {security_id}")

                collection.update_one(
                    {"_id": order["_id"]},
                    {
                        "$set": {
                            "sl": levels["sl"],
                            "t1": levels["t1"],
                            "t2": levels["t2"],
                            "ltp": float(ltp)
                        }
                    }
                )

        except Exception as e:
            logger.error(f"[WS ERROR] {security_id} {e}")

    def on_open(ws):
        logger.info(f"[WS OPEN] {security_id}")
        RETRY_COUNTER[security_id] = 0

    def on_close(ws, code, msg):

        logger.warning(f"[WS CLOSED] {security_id}")

        remove_ws(security_id)

        if security_id in MANUAL_CLOSE:
            MANUAL_CLOSE.discard(security_id)
            return

        count = RETRY_COUNTER.get(security_id, 0)

        if count >= 5:
            logger.error(f"[MAX RETRY] {security_id}")
            return

        RETRY_COUNTER[security_id] = count + 1

        time.sleep(retry_delay)
        start_feed_ws(security_id)

    try:
        ws = websocket.WebSocketApp(
            url,
            on_message=on_message,
            on_open=on_open,
            on_close=on_close,
        )

        with WS_LOCK:
            ACTIVE_WS[security_id] = ws

        def run():
            ws.run_forever(
                sslopt={"cert_reqs": ssl.CERT_NONE},
                ping_interval=20,
                ping_timeout=10
            )

        thread = threading.Thread(target=run, daemon=True)

        with WS_LOCK:
            ACTIVE_THREADS[security_id] = thread

        thread.start()

        logger.info(f"[WS STARTED] {security_id}")

    except Exception as e:
        logger.error(f"[WS FATAL] {security_id} {e}")
        remove_ws(security_id)


# -------------------------------------------------
# ACTIVE FEEDS
# -------------------------------------------------
def get_active_feeds():
    return list(ACTIVE_SECURITIES)