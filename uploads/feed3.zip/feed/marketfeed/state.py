from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer

live_prices = {}


def update_price(security_id, ltp):
    live_prices[security_id] = ltp

    # ✅ send to dashboard WS
    try:
        channel_layer = get_channel_layer()

        async_to_sync(channel_layer.group_send)(
            "live_feed",
            {
                "type": "send_price",
                "data": {
                    "security_id": security_id,
                    "ltp": ltp
                }
            }
        )
    except Exception:
        pass

def get_price(security_id):
    return live_prices.get(security_id)
