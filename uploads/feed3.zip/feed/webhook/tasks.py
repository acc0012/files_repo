import traceback
import time
from threading import Lock

from webhook.services import (
    parse_webhook_message,
    get_last_active_order,
    save_order
)

from webhook.utils import generate_order_id

from core.db import (
    get_option_data,
    get_orders_collection
)

from core.logger import get_logger

from marketfeed.services import (
    close_all_feeds_except,
    start_feed_ws,
    get_active_feeds
)

from marketfeed.subscriber import subscribe_security

# ✅ TELEGRAM IMPORT
from core.telegram import send_telegram_alert

logger = get_logger("webhook_tasks")

# ✅ GLOBAL LOCK
order_lock = Lock()


def process_webhook_async(index_security_id, message, temp_id):

    try:
        logger.info(f"[PROCESS START] ReqID={temp_id}")

        parsed = parse_webhook_message(message)

        # -------------------------------------------------
        # ❌ PARSE FAILED
        # -------------------------------------------------
        if not parsed:

            order_id = generate_order_id("failed")

            order_doc = {
                "order_id": order_id,
                "temp_id": temp_id,
                "index_security_id": index_security_id,
                "status": "failed",
                "reason": "Parsing failed",
                "raw_message": message
            }

            save_order(order_doc)

            # ✅ TELEGRAM ALERT
            try:
                send_telegram_alert(order_doc)
            except Exception as e:
                logger.error(f"[TELEGRAM ERROR] {e}")

            return

        # -------------------------------------------------
        # ✅ EXTRACT DATA
        # -------------------------------------------------
        strike = parsed["strike"]
        order_type = parsed["type"]

        option_type = "pe" if "PE" in order_type.upper() else "ce"

        option_data = get_option_data(
            index_security_id=index_security_id,
            strike=strike,
            option_type=option_type
        )

        # -------------------------------------------------
        # ❌ OPTION NOT FOUND
        # -------------------------------------------------
        if not option_data:

            order_id = generate_order_id("failed")

            order_doc = {
                "order_id": order_id,
                "temp_id": temp_id,
                "index_security_id": index_security_id,
                "status": "failed",
                "reason": "Security ID not found",
                "strike": strike,
                "type": order_type,
                "raw_message": message
            }

            save_order(order_doc)

            # ✅ TELEGRAM ALERT
            try:
                send_telegram_alert(order_doc)
            except Exception as e:
                logger.error(f"[TELEGRAM ERROR] {e}")

            return

        # -------------------------------------------------
        # ✅ SECURITY ID
        # -------------------------------------------------
        security_id = option_data.get("security_id")

        if not security_id:
            return

        # -------------------------------------------------
        # ✅ CRITICAL SECTION (LOCK)
        # -------------------------------------------------
        with order_lock:

            col = get_orders_collection()

            last_order = get_last_active_order(index_security_id)

            status = "placed"

            if last_order and last_order.get("type") == order_type:
                status = "ignored"
                logger.info(f"[IGNORED ORDER] ReqID={temp_id}")

            # ✅ FORCE CLOSE OLD ORDERS
            if status == "placed":
                col.update_many(
                    {
                        "index_security_id": index_security_id,
                        "status": "placed"
                    },
                    {
                        "$set": {
                            "status": "completed",
                            "force_closed": True
                        }
                    }
                )

        # -------------------------------------------------
        # ✅ FINAL ORDER BUILD
        # -------------------------------------------------
        order_id = generate_order_id(status)

        order_doc = {
            "order_id": order_id,
            "temp_id": temp_id,
            "index_security_id": index_security_id,
            "strike": strike,
            "type": order_type,
            "option_type": option_type,
            "security_id": security_id,
            "event": parsed.get("event"),
            "price": parsed.get("price"),
            "time": parsed.get("time"),
            "status": status,
            "raw_message": message
        }

        save_order(order_doc)

        # ✅ TELEGRAM ALERT (MAIN PART 🔥)
        try:
            send_telegram_alert(order_doc)
        except Exception as e:
            logger.error(f"[TELEGRAM ERROR] {e}")

        # -------------------------------------------------
        # ✅ START TRADING FLOW
        # -------------------------------------------------
        if status == "placed":

            subscribe_security(index_security_id, security_id)

            close_all_feeds_except(security_id)

            # wait for cleanup
            for _ in range(10):
                if len(get_active_feeds()) <= 1:
                    break
                time.sleep(0.3)

            start_feed_ws(security_id)

        logger.info(f"[PROCESS COMPLETE] ReqID={temp_id}")

    except Exception as e:
        logger.error(f"[PROCESS FAILED] ReqID={temp_id} Error={e}")
        logger.error(traceback.format_exc())
