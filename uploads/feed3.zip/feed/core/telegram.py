import requests
from django.conf import settings


# --------------------------------------------------
# ✅ MAIN TELEGRAM SENDER (SAFE)
# --------------------------------------------------
def send_telegram_alert(order):

    if not settings.TELEGRAM_BOT_TOKEN or not settings.TELEGRAM_CHAT_ID:
        return

    try:
        msg = format_message(order)

        url = f"https://api.telegram.org/bot{settings.TELEGRAM_BOT_TOKEN}/sendMessage"

        payload = {
            "chat_id": settings.TELEGRAM_CHAT_ID,
            "text": msg,
            "parse_mode": "HTML"
        }

        response = requests.post(url, json=payload, timeout=3)

        if response.status_code != 200:
            print("Telegram API error:", response.text)

    except Exception as e:
        print("Telegram send error:", e)


# --------------------------------------------------
# ✅ MESSAGE FORMATTER (FINAL CLEAN)
# --------------------------------------------------
def format_message(o):

    # ✅ normalize status
    status = str(o.get("status", "unknown")).lower()

    # --------------------------------------------------
    # 🎯 STATUS MAPPING
    # --------------------------------------------------
    if status == "placed":
        emoji = "🟢"
        title = "ORDER PLACED"

    elif status == "ignored":
        emoji = "🟡"
        title = "ORDER IGNORED"

    elif status == "failed":
        emoji = "🔴"
        title = "ORDER FAILED"

    elif status == "entry":
        emoji = "🔵"
        title = "ENTRY FILLED"

    elif status == "exit":
        emoji = "🟣"
        title = "EXIT CLOSED"

    else:
        emoji = "⚪"
        title = "ORDER UPDATE"

    # --------------------------------------------------
    # ✅ SAFE DATA EXTRACTION
    # --------------------------------------------------
    order_id = o.get("order_id", "NA")
    order_type = o.get("type", "NA")
    option_type = str(o.get("option_type", "")).upper()
    strike = o.get("strike", "-")

    price = o.get("price", "-")

    entry = o.get("entry_price")
    exit_price = o.get("exit_price")

    time_val = o.get("time") or o.get("created_at") or "-"

    # --------------------------------------------------
    # ✅ BASE MESSAGE
    # --------------------------------------------------
    msg = f"""
<b>{emoji} {title}</b>

<b>ID:</b> {order_id}
<b>Type:</b> {order_type}
<b>Option:</b> {option_type}
<b>Strike:</b> {strike}
<b>Status:</b> {status.upper()}

<b>Alert Price:</b> {price}
<b>Time:</b> {time_val}
"""

    # --------------------------------------------------
    # ✅ ENTRY INFO
    # --------------------------------------------------
    if entry is not None:
        msg += f"\n<b>Entry:</b> {entry}"

    # --------------------------------------------------
    # ✅ EXIT INFO + PNL
    # --------------------------------------------------
    if exit_price is not None and entry is not None:
        try:
            pnl = float(exit_price) - float(entry)
            pnl_emoji = "🟢" if pnl > 0 else "🔴"

            msg += f"""
<b>Exit:</b> {exit_price}
<b>PNL:</b> {pnl_emoji} {round(pnl, 2)}
"""
        except Exception:
            pass

    # --------------------------------------------------
    # ✅ FAILURE
    # --------------------------------------------------
    if status == "failed":
        msg += f"\n<b>Reason:</b> {o.get('reason', 'NA')}"

    # --------------------------------------------------
    # ✅ IGNORED NOTE
    # --------------------------------------------------
    if status == "ignored":
        msg += "\n<i>Duplicate / skipped signal</i>"

    return msg.strip()