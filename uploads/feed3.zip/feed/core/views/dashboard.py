from django.shortcuts import render
from core.db import get_orders_collection


# -------------------------------------------------
# 🔥 ROOT DASHBOARD VIEW
# -------------------------------------------------
def dashboard_view(request):

    try:
        collection = get_orders_collection()

        # ✅ LIMIT added to prevent crash on large DB
        orders = list(
            collection.find()
            .sort("created_at", -1)
            .limit(200)
        )

        # ✅ Convert Mongo ObjectId to string
        for o in orders:
            o["_id"] = str(o["_id"])

        # ✅ Basic stats (optional but useful)
        total_orders = len(orders)
        placed = sum(1 for o in orders if o.get("status") == "placed")
        failed = sum(1 for o in orders if o.get("status") == "failed")
        ignored = sum(1 for o in orders if o.get("status") == "ignored")

        return render(
            request,
            "dashboard.html",
            {
                "orders": orders,
                "total_orders": total_orders,
                "placed_count": placed,
                "failed_count": failed,
                "ignored_count": ignored,
            }
        )

    except Exception as e:
        # ✅ fail-safe (dashboard should never crash)
        return render(
            request,
            "dashboard.html",
            {
                "orders": [],
                "error": str(e)
            }
        )
