from django.shortcuts import render
from django.http import JsonResponse

from core.db import get_orders_collection
from marketfeed.state import get_price


# ✅ UI page
def orders_view(request):
    return render(request, "dashboard/orders.html")


# ✅ API returning Mongo orders
def orders_api(request):

    col = get_orders_collection()

    docs = list(
        col.find()
        .sort("created_at", -1)
        .limit(100)
    )

    for d in docs:

        # ✅ Mongo ID → string
        d["_id"] = str(d["_id"])

        sec_id = d.get("security_id")

        # ✅ LIVE PRICE
        ltp = get_price(sec_id)
        d["ltp"] = ltp

        # ✅ ENTRY PRICE
        entry = d.get("entry_price")

        # ✅ PNL CALCULATION
        if entry is not None and ltp is not None:
            pnl = float(ltp) - float(entry)
            d["pnl"] = round(pnl, 2)
        else:
            d["pnl"] = None

        # ✅ SL / T1 / T2 (already saved in DB if logic added)
        d["sl"] = d.get("sl")
        d["t1"] = d.get("t1")
        d["t2"] = d.get("t2")

        # ✅ OPTIONAL: PNL STATUS COLOR (UI use)
        if d["pnl"] is not None:
            d["pnl_status"] = "profit" if d["pnl"] > 0 else "loss"
        else:
            d["pnl_status"] = None

    return JsonResponse(docs, safe=False)