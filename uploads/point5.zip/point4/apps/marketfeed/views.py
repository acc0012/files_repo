# apps/marketfeed/views.py

import asyncio
import os

from rest_framework.decorators import api_view
from rest_framework.response import Response

# from datetime import datetime
# from datetime import timezone as timezone_dt
from django.utils import timezone

from channels.layers import get_channel_layer

from dhanhq.marketfeed import MarketFeed

from apps.marketfeed.services import MarketFeedService
from core.logger import get_logger

from core.option_lookup import get_option_security_id
from apps.marketfeed.utils import resolve_exchange_segment

from core.subscription_store import get_collection


from apps.marketfeed.services import is_market_open
from core.subscription_store import get_dummy_collection

# =====================================================
# LOGGER
# =====================================================

logger = get_logger("marketfeed_views")

# =====================================================
# SINGLETON SERVICE
# =====================================================

_feed_service_instance = None


def get_feed_service():
    global _feed_service_instance

    if _feed_service_instance is None:
        _feed_service_instance = MarketFeedService()

    return _feed_service_instance


# =====================================================
# BASE WS URL
# =====================================================

BASE_WS_URL = os.getenv("BASE_WS_URL", "")

# =====================================================
# CONSTANT MAPS
# =====================================================

SEGMENT_MAP = {
    "IDX": MarketFeed.IDX,
    "NSE_FNO": MarketFeed.NSE_FNO,
}

TYPE_MAP = {
    "Quote": MarketFeed.Quote,
    "Full": MarketFeed.Full,
}

# =====================================================
# WS URL BUILDER
# =====================================================


def get_ws_url(request=None):
    base = BASE_WS_URL

    if base:
        return base

    if request:
        scheme = "wss" if request.is_secure() else "ws"
        host = request.get_host()
        return f"{scheme}://{host}/ws/market/"

    return "/ws/market/"


# =====================================================
# VALIDATOR
# =====================================================


def is_valid_tuple(inst):
    return isinstance(inst, (list, tuple)) and len(inst) == 3


# =====================================================
# FORMAT CONVERTER
# =====================================================


def convert_to_tuple_format(instruments):

    result = []
    invalid = []

    for inst in instruments:
        try:
            if isinstance(inst, dict):
                segment_name = inst.get("segment")
                security_id = inst.get("security_id")
                type_name = inst.get("type")

                if segment_name not in SEGMENT_MAP:
                    raise ValueError(f"Invalid segment: {segment_name}")

                if type_name not in TYPE_MAP:
                    raise ValueError(f"Invalid type: {type_name}")

                if not security_id:
                    raise ValueError("security_id missing")

                result.append(
                    (
                        SEGMENT_MAP[segment_name],
                        str(security_id),
                        TYPE_MAP[type_name],
                    )
                )

            elif isinstance(inst, list):
                if not is_valid_tuple(inst):
                    raise ValueError("List must contain 3 items")

                result.append(tuple(inst))

            elif isinstance(inst, tuple):
                if not is_valid_tuple(inst):
                    raise ValueError("Tuple must contain 3 items")

                result.append(inst)

            else:
                raise ValueError(f"Unsupported format: {type(inst)}")

        except Exception as e:
            invalid.append(
                {
                    "instrument": str(inst),
                    "error": str(e),
                }
            )

            logger.exception(f"❌ Invalid instrument: {inst} => {e}")

    logger.info(f"📡 Converted instruments: {result}")

    return result, invalid


# =====================================================
# ✅ WEBSOCKET CALLBACK (UPDATED)
# =====================================================


def on_message(instance, message):

    try:
        if not isinstance(message, dict):
            return

        security_id = str(message.get("security_id"))

        if not security_id:
            logger.debug(f"⚠️ Ignored non-market msg: {message}")
            return

        service = get_feed_service()
        service.update_tick(message)

        channel_layer = get_channel_layer()

        if not channel_layer:
            logger.error("❌ Channel layer not initialized")
            return

        async def send():
            try:
                # ✅ SEND TO DASHBOARD (ALL instruments)
                await channel_layer.group_send(
                    "market_feed",
                    {
                        "type": "send_market_data",
                        "data": message,
                    },
                )

                # ✅ SEND TO SINGLE INSTRUMENT
                await channel_layer.group_send(
                    f"market_{security_id}",
                    {
                        "type": "send_market_data",
                        "data": message,
                    },
                )

            except Exception as send_error:
                logger.exception(f"❌ group_send failed: {send_error}")

        try:
            loop = asyncio.get_running_loop()
            loop.create_task(send())
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            loop.run_until_complete(send())
            loop.close()

    except Exception as e:
        logger.exception(f"❌ WebSocket send failed: {e}")


# =====================================================
# START FEED
# =====================================================


@api_view(["POST"])
def start_feed(request):

    try:
        instruments = request.data.get("instruments", [])

        if not instruments:
            return Response({"error": "instruments required"}, status=400)

        service = get_feed_service()

        # ✅ MARKET CLOSED → DUMMY MODE
        if not is_market_open():
            dummy_collection = get_dummy_collection()

            dummy_collection.insert_one(
                {
                    "type": "start_feed",
                    "instruments": instruments,
                    "timestamp": timezone.now(),
                    "mode": "dummy",
                }
            )

            return Response(
                {
                    "status": "feed_started",  # ✅ same as real
                    "parsed": [],
                    "invalid": [],
                    "count": 0,
                    "websocket_url": "/ws/mock/",
                    "mode": "dummy",
                }
            )

        if service.is_running:
            return Response(
                {
                    "status": "already_running",
                    "websocket_url": get_ws_url(),
                }
            )

        parsed, invalid = convert_to_tuple_format(instruments)

        if not parsed:
            return Response(
                {
                    "error": "No valid instruments",
                    "invalid": invalid,
                },
                status=400,
            )

        service.start_feed(parsed, callbacks={"on_message": on_message})

        return Response(
            {
                "status": "feed_started",
                "parsed": parsed,
                "invalid": invalid,
                "count": len(parsed),
                "websocket_url": get_ws_url(),
            }
        )

    except Exception as e:
        logger.exception(f"❌ Start failed: {e}")
        return Response({"error": str(e)}, status=500)


# =====================================================
# SUBSCRIBE (UPDATED)
# =====================================================


@api_view(["POST"])
def subscribe(request):

    try:
        instruments = request.data.get("instruments", [])

        if not instruments:
            return Response({"error": "instruments required"}, status=400)

        parsed, invalid = convert_to_tuple_format(instruments)

        service = get_feed_service()

        if not service.is_running:
            # ✅ MARKET CLOSED → DUMMY MODE
            if not is_market_open():
                dummy_collection = get_dummy_collection()

                dummy_collection.insert_one(
                    {
                        "type": "subscribe",
                        "instruments": instruments,
                        "timestamp": timezone.now(),
                        "mode": "dummy",
                    }
                )

                return Response(
                    {
                        "status": "subscribed",  # ✅ same as real
                        "parsed": parsed if "parsed" in locals() else [],
                        "invalid": [],
                        "total": 0,
                        "websocket_urls": ["/ws/mock/"],
                        "mode": "dummy",
                    }
                )

            return Response({"error": "feed not started"}, status=400)

        if not parsed:
            return Response(
                {
                    "error": "No valid instruments",
                    "invalid": invalid,
                },
                status=400,
            )

        service.subscribe(parsed)

        return Response(
            {
                "status": "subscribed",
                "parsed": parsed,
                "invalid": invalid,
                "total": len(service.subscribed_instruments),
                # ✅ RETURN WS URLS PER INSTRUMENT
                "websocket_urls": [f"/ws/market/{inst[1]}/" for inst in parsed],
            }
        )

    except Exception as e:
        logger.exception(f"❌ Subscribe failed: {e}")
        return Response({"error": str(e)}, status=500)


# =====================================================
# SUBSCRIBE OPTION (UPDATED)
# =====================================================
@api_view(["POST"])
def subscribe_option(request, index_security_id):

    try:
        strike_price = request.data.get("strike_price")
        option_type = request.data.get("option_type", "ce")

        if not strike_price:
            return Response({"error": "strike_price required"}, status=400)

        # ✅ Get option data
        option_data = get_option_security_id(
            index_security_id, strike_price, option_type
        )

        if not option_data:
            return Response(
                {"error": "Option not found"},
                status=404,
            )

        # ✅ Extract values
        security_id = option_data["security_id"]
        exchange = resolve_exchange_segment(index_security_id)

        # ✅ Tuple for feed
        instrument_tuple = (
            exchange,
            security_id,
            MarketFeed.Quote,
        )

        # ✅ Object for Mongo
        instrument_obj = {
            "exchange": exchange,
            "security_id": security_id,
            "subscription_type": MarketFeed.Quote,
            "index_security_id": option_data["index_security_id"],
            "expiry": option_data["expiry"],
            "strike": option_data["strike"],
            "option_type": option_data["option_type"],
        }

        service = get_feed_service()

        # =====================================================
        # ✅ ✅ DUMMY MODE (MARKET CLOSED)
        # =====================================================
        if not is_market_open():
            dummy_collection = get_dummy_collection()

            dummy_collection.insert_one(
                {
                    "type": "subscribe_option",
                    "instrument": instrument_obj,
                    "timestamp": timezone.now(),
                    "mode": "dummy",
                }
            )

            return Response(
                {
                    "status": "subscribed_option",  # ✅ match real
                    "instrument": instrument_obj,
                    "websocket_url": "/ws/mock/",
                    "mode": "dummy",
                }
            )

        # =====================================================
        # ✅ FEED NOT RUNNING (MARKET OPEN BUT SERVICE DOWN)
        # =====================================================
        if not service.is_running:
            return Response({"error": "feed not started"}, status=400)

        # =====================================================
        # ✅ REAL SUBSCRIPTION FLOW
        # =====================================================

        # ✅ Subscribe to feed
        service.subscribe([instrument_tuple])

        # ✅ Save metadata to Mongo
        collection = get_collection()

        collection.update_one(
            {
                "_id": "active_subscriptions",
                "instruments.tuple": {"$ne": instrument_tuple},
            },
            {
                "$push": {
                    "instruments": {
                        "tuple": instrument_tuple,
                        "metadata": instrument_obj,
                    }
                },
                "$set": {"updated_at": timezone.now()},
            },
            upsert=True,
        )

        return Response(
            {
                "status": "subscribed_option",
                "instrument": instrument_obj,
                "websocket_url": f"/ws/market/{security_id}/",
            }
        )

    except Exception as e:
        logger.exception(f"❌ Option subscribe failed: {e}")
        return Response({"error": str(e)}, status=500)


@api_view(["GET"])
def expired_subscriptions(request):

    try:
        collection = get_collection()

        data = list(collection.database["expired_subscriptions"].find({}))

        for item in data:
            item["_id"] = str(item["_id"])

        return Response({"count": len(data), "data": data})

    except Exception as e:
        return Response({"error": str(e)}, status=500)


# =====================================================
# OTHER APIs (UNCHANGED)
# =====================================================


@api_view(["GET"])
def feed_status(request):
    return Response(get_feed_service().get_status())


@api_view(["POST"])
def unsubscribe(request):

    instruments = request.data.get("instruments", [])

    service = get_feed_service()

    parsed, _ = convert_to_tuple_format(instruments)

    service.unsubscribe(parsed)

    return Response({"status": "unsubscribed"})


@api_view(["POST"])
def stop_feed(request):

    service = get_feed_service()

    service.stop_feed()

    return Response({"status": "feed_stopped"})


@api_view(["GET"])
def dashboard_data(request):

    return Response(get_feed_service().get_dashboard_data())
