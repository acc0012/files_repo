from django.urls import path

from . import views

urlpatterns = [
    # =================================================
    # FEED CONTROL
    # =================================================
    path("start/", views.start_feed, name="start_feed"),
    path("subscribe/", views.subscribe, name="subscribe"),
    path("unsubscribe/", views.unsubscribe, name="unsubscribe"),
    path("stop/", views.stop_feed, name="stop_feed"),
    # =================================================
    # FEED STATUS / MONITORING
    # =================================================
    path("status/", views.feed_status, name="feed_status"),
    path("dashboard-data/", views.dashboard_data, name="dashboard_data"),
    path(
        "subscribe-option/<int:index_security_id>/",
        views.subscribe_option,
        name="subscribe_option",
    ),
    
    path("expired/", views.expired_subscriptions),    
]
