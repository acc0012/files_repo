import asyncio
import json
import random
from channels.generic.websocket import AsyncWebsocketConsumer

class MockMarketConsumer(AsyncWebsocketConsumer):

    async def connect(self):
        await self.accept()
        self.running = True
        asyncio.create_task(self.send_data())

    async def disconnect(self, close_code):
        self.running = False

    async def send_data(self):
        while self.running:
            await self.send(text_data=json.dumps({
                "security_id": "MOCK",
                "price": round(random.uniform(100, 500), 2),
                "mode": "dummy"
            }))
            await asyncio.sleep(1)
