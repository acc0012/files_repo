from django.apps import AppConfig

# ✅ GLOBAL FLAG (prevents duplicate startup)
_started = False

class MarketfeedConfig(AppConfig):
    name = "apps.marketfeed"

    def ready(self):
        global _started

        # ✅ Prevent multiple executions (critical in production)
        if _started:
            return

        _started = True

        try:
            from .startup import start_feed_on_boot
            start_feed_on_boot()

        except Exception as e:
            import logging
            logger = logging.getLogger(__name__)
            logger.exception(f"❌ Marketfeed startup failed: {e}")
