from django.urls import re_path

from .consumers import MarketFeedConsumer
from .mock_consumer import MockMarketConsumer

# =====================================================
# WEBSOCKET ROUTES
# =====================================================

websocket_urlpatterns = [

    # ✅ ALL instruments (Dashboard - single WS)
    re_path(
        r"ws/market/$",
        MarketFeedConsumer.as_asgi(),
    ),

    # ✅ SINGLE instrument (API / external use)
    re_path(
        r"ws/market/(?P<security_id>\w+)/$",
        MarketFeedConsumer.as_asgi(),
    ),
    

re_path(r"ws/mock/$", MockMarketConsumer.as_asgi()),
    
]