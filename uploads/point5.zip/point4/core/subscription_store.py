from datetime import datetime,timezone
from django.conf import settings

from core.db import get_db
from core.logger import get_logger

# =====================================================
# LOGGER
# =====================================================

logger = get_logger("subscription_store")

# =====================================================
# COLLECTION NAME
# =====================================================

COLLECTION_NAME = getattr(
    settings,
    "SUBSCRIPTION_COLLECTION",
    "subscriptions",
)

# =====================================================
# GET COLLECTION
# =====================================================

def get_collection():

    try:
        db = get_db(settings.MONGO_DB)

        if db is None:
            raise ValueError("Mongo DB not available")

        return db[COLLECTION_NAME]

    except Exception as e:
        logger.exception(f"❌ Failed to get subscription collection: {e}")
        raise


def get_dummy_collection():
    db = get_db(settings.MONGO_DB)
    return db["dummy_subscriptions"]

# =====================================================
# ✅ SAVE SUBSCRIPTIONS (HYBRID STRUCTURE)
# =====================================================

def save_subscriptions(instruments):

    """
    ✅ Stores BOTH:
    - tuple (for Dhan usage)
    - metadata (for business logic)
    """

    try:
        if not isinstance(instruments, list):
            raise ValueError("instruments must be a list")

        clean_instruments = []

        for item in instruments:

            try:
                # -------------------------------------------------
                # ✅ CASE 1: FULL OBJECT (WITH METADATA)
                # -------------------------------------------------
                if isinstance(item, dict):

                    required = ["exchange", "security_id", "subscription_type"]

                    if not all(k in item for k in required):
                        logger.warning(f"⚠️ Missing required keys: {item}")
                        continue

                    exchange = item["exchange"]
                    security_id = str(item["security_id"])
                    sub_type = item["subscription_type"]

                    clean_instruments.append({
                        # ✅ Tuple (for Dhan)
                        "tuple": (exchange, security_id, sub_type),

                        # ✅ Metadata (for logic)
                        "metadata": {
                            "exchange": exchange,
                            "security_id": security_id,
                            "subscription_type": sub_type,
                            "index_security_id": item.get("index_security_id"),
                            "expiry": item.get("expiry"),
                            "strike": item.get("strike"),
                            "option_type": item.get("option_type"),
                        }
                    })

                # -------------------------------------------------
                # ✅ CASE 2: TUPLE ONLY
                # -------------------------------------------------
                elif isinstance(item, (list, tuple)) and len(item) == 3:

                    exchange, security_id, sub_type = item

                    clean_instruments.append({
                        "tuple": (exchange, str(security_id), sub_type),
                        "metadata": {
                            "exchange": exchange,
                            "security_id": str(security_id),
                            "subscription_type": sub_type,
                        }
                    })

                else:
                    logger.warning(f"⚠️ Invalid instrument skipped: {item}")

            except Exception as inner_error:
                logger.warning(f"⚠️ Failed processing item {item}: {inner_error}")

        collection = get_collection()

        collection.update_one(
            {"_id": "active_subscriptions"},
            {
                "$set": {
                    "instruments": clean_instruments,
                    "updated_at": datetime.now(timezone.utc),
                }
            },
            upsert=True,
        )

        logger.info(f"✅ Subscriptions saved | Count: {len(clean_instruments)}")

    except Exception as e:
        logger.exception(f"❌ Failed to save subscriptions: {e}")


# =====================================================
# ✅ LOAD SUBSCRIPTIONS (RETURN TUPLES FOR DHAN)
# =====================================================

def load_subscriptions():

    """
    ✅ Returns ONLY tuples → used by MarketFeed
    """

    try:
        collection = get_collection()

        doc = collection.find_one({"_id": "active_subscriptions"})

        if not doc:
            logger.info("ℹ️ No stored subscriptions found")
            return []

        instruments = doc.get("instruments", [])

        result = []

        for item in instruments:

            try:
                # ✅ New structure
                if isinstance(item, dict) and "tuple" in item:
                    tup = item["tuple"]

                    if isinstance(tup, (list, tuple)) and len(tup) == 3:
                        result.append(tuple(tup))

                # ✅ Backward compatibility
                elif isinstance(item, dict):
                    exchange = item.get("exchange")
                    security_id = item.get("security_id")
                    sub_type = item.get("subscription_type")

                    if exchange and security_id and sub_type:
                        result.append((exchange, str(security_id), sub_type))

                elif isinstance(item, (list, tuple)) and len(item) == 3:
                    result.append(tuple(item))

                else:
                    logger.warning(f"⚠️ Invalid format: {item}")

            except Exception as e:
                logger.warning(f"⚠️ Failed parsing: {item} → {e}")

        logger.info(f"📦 Loaded subscriptions | Count: {len(result)}")

        return result

    except Exception as e:
        logger.exception(f"❌ Failed to load subscriptions: {e}")
        return []


# =====================================================
# ✅ GET FULL METADATA (NEW - FOR CLEANUP / LOGIC)
# =====================================================

def load_full_subscriptions():

    """
    ✅ Returns FULL DATA (metadata + tuple)
    Use for expiry cleanup / analytics
    """

    try:
        collection = get_collection()

        doc = collection.find_one({"_id": "active_subscriptions"})

        if not doc:
            return []

        return doc.get("instruments", [])

    except Exception as e:
        logger.exception(f"❌ Failed loading full subscriptions: {e}")
        return []


# =====================================================
# ✅ CLEAR SUBSCRIPTIONS
# =====================================================

def clear_subscriptions():

    try:
        collection = get_collection()

        collection.delete_one({"_id": "active_subscriptions"})

        logger.info("🗑️ Cleared all subscriptions from MongoDB")

    except Exception as e:
        logger.exception(f"❌ Failed to clear subscriptions: {e}")