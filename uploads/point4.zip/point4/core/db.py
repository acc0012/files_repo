import sys
import time
import threading

from pymongo import MongoClient
from django.conf import settings

from core.logger import get_logger

# =====================================================
# LOGGER
# =====================================================

logger = get_logger("db_layer")

# =====================================================
# FORCE UTF-8 LOGGING
# =====================================================

try:

    sys.stdout.reconfigure(encoding="utf-8")

except Exception:
    pass

# =====================================================
# GLOBALS
# =====================================================

_client = None

mongo_lock = threading.RLock()

# =====================================================
# CACHE STORAGE
# =====================================================

_doc_cache = {}

_oc_cache = {}

_cache_time = {}

CACHE_TTL = 2

MAX_CACHE_ITEMS = 100

# =====================================================
# CACHE CLEANUP
# =====================================================


def cleanup_old_cache():

    try:

        with mongo_lock:

            if len(_cache_time) <= MAX_CACHE_ITEMS:

                return

            sorted_items = sorted(
                _cache_time.items(),
                key=lambda item: item[1],
            )

            remove_count = len(sorted_items) - MAX_CACHE_ITEMS

            for key, _ in sorted_items[:remove_count]:

                _cache_time.pop(
                    key,
                    None,
                )

                _doc_cache.pop(
                    key,
                    None,
                )

                _oc_cache.pop(
                    key,
                    None,
                )

    except Exception as e:

        logger.exception(f"❌ Cache cleanup failed: {e}")


# =====================================================
# CACHE VALIDATION
# =====================================================


def is_cache_valid(index_security_id):

    try:

        with mongo_lock:

            if index_security_id not in _cache_time:

                return False

            cache_age = time.time() - _cache_time[index_security_id]

            return cache_age < CACHE_TTL

    except Exception as e:

        logger.exception(f"❌ Cache validation failed: {e}")

        return False


# =====================================================
# SINGLETON CLIENT
# =====================================================


def get_mongo_client():

    global _client

    try:

        with mongo_lock:

            if _client is None:

                if not settings.MONGO_URI:

                    raise ValueError("MONGO_URI missing")

                _client = MongoClient(
                    settings.MONGO_URI,
                    serverSelectionTimeoutMS=5000,
                    connectTimeoutMS=5000,
                    socketTimeoutMS=5000,
                    maxPoolSize=50,
                )

                # -------------------------------------
                # TEST CONNECTION
                # -------------------------------------

                _client.admin.command("ping")

                logger.info("✅ Mongo Connected")

            return _client

    except Exception as e:

        logger.exception(f"❌ Mongo connection failed: {e}")

        raise


# =====================================================
# DATABASE
# =====================================================


def get_db(db_name=None):

    try:

        client = get_mongo_client()

        db_to_use = db_name if db_name else settings.MONGO_DB

        if not db_to_use:

            raise ValueError("MONGO_DB missing")

        return client[db_to_use]

    except Exception as e:

        logger.exception(f"❌ Database access failed: {e}")

        raise


# =====================================================
# OPTION CHAIN COLLECTION
# =====================================================


def get_option_chain_collection():

    try:

        db_name = getattr(
            settings,
            "MONGO_OPTION_CHAIN_DB",
            None,
        )

        collection_name = getattr(
            settings,
            "MONGO_OPTION_COLLECTION",
            "index_option_chain",
        )

        return get_db(db_name)[collection_name]

    except Exception as e:

        logger.exception(f"❌ Option collection failed: {e}")

        raise


# =====================================================
# FETCH LATEST DOC
# =====================================================


def get_latest_option_chain_doc(index_security_id):

    try:

        with mongo_lock:

            # -----------------------------------------
            # CACHE HIT
            # -----------------------------------------

            if is_cache_valid(index_security_id):

                cached_doc = _doc_cache.get(index_security_id)

                if cached_doc:

                    return cached_doc

        # ---------------------------------------------
        # DB FETCH
        # ---------------------------------------------

        collection = get_option_chain_collection()

        doc = collection.find_one(
            {"index_security_id": index_security_id},
            sort=[
                (
                    "fetched_at",
                    -1,
                )
            ],
        )

        if not doc:

            logger.warning(f"⚠️ No data for index " f"{index_security_id}")

            return None

        # ---------------------------------------------
        # SAVE CACHE
        # ---------------------------------------------

        with mongo_lock:

            _doc_cache[index_security_id] = doc

            _cache_time[index_security_id] = time.time()

            cleanup_old_cache()

        return doc

    except Exception as e:

        logger.exception(f"❌ Fetch latest doc failed: {e}")

        return None


# =====================================================
# NORMALIZE STRIKES
# =====================================================


def normalize_strikes(oc_dict):

    normalized = {}

    try:

        if not isinstance(
            oc_dict,
            dict,
        ):

            return normalized

        for key, value in oc_dict.items():

            try:

                clean_key = str(int(float(key)))

            except Exception:

                clean_key = str(key)

            normalized[clean_key] = value

    except Exception as e:

        logger.exception(f"❌ Normalize strikes failed: {e}")

    return normalized


# =====================================================
# ORDERS COLLECTION
# =====================================================


def get_orders_collection():

    try:

        db = get_db(settings.AUTH_MONGO_DB)

        return db[settings.ORDERS_MONGO_COLLECTION]

    except Exception as e:

        logger.exception(f"❌ Orders collection failed: {e}")

        raise


# =====================================================
# CLEAN OPTION CHAIN
# =====================================================


def get_clean_option_chain(index_security_id):

    try:

        with mongo_lock:

            if is_cache_valid(index_security_id):

                cached_oc = _oc_cache.get(index_security_id)

                if cached_oc:

                    return cached_oc

        doc = get_latest_option_chain_doc(index_security_id)

        if not doc:

            return None

        oc = doc.get(
            "option_chain",
            {},
        ).get("oc", {})

        normalized = normalize_strikes(oc)

        with mongo_lock:

            _oc_cache[index_security_id] = normalized

        return normalized

    except Exception as e:

        logger.exception(f"❌ Clean OC failed: {e}")

        return None


# =====================================================
# SYMBOL -> INDEX
# =====================================================


def get_index_security_id_from_symbol(symbol: str):

    try:

        if not symbol:

            return None

        symbol = str(symbol).upper()

        if "BANKNIFTY" in symbol:

            return 51

        elif "FINNIFTY" in symbol:

            return 25

        elif "NIFTY" in symbol:

            return 13

        return None

    except Exception as e:

        logger.exception(f"❌ Symbol conversion failed: {e}")

        return None


# =====================================================
# SINGLE OPTION
# =====================================================


def get_option_data(
    index_security_id,
    strike,
    option_type="pe",
):

    try:

        oc = get_clean_option_chain(index_security_id)

        if not oc:

            return None

        strike = int(float(strike))

        strike_key = str(strike)

        if strike_key in oc:

            return oc[strike_key].get(option_type.lower())

        # ---------------------------------------------
        # FIND CLOSEST
        # ---------------------------------------------

        closest = min(
            oc.keys(),
            key=lambda x: abs(int(x) - strike),
        )

        return oc[closest].get(option_type.lower())

    except Exception as e:

        logger.exception(f"❌ Get option data failed: {e}")

        return None


# =====================================================
# SYMBOL FETCH
# =====================================================


def get_option_data_from_symbol(
    symbol,
    strike,
    option_type="pe",
):

    try:

        idx = get_index_security_id_from_symbol(symbol)

        if not idx:

            return None

        return get_option_data(
            idx,
            strike,
            option_type,
        )

    except Exception as e:

        logger.exception(f"❌ Symbol option fetch failed: {e}")

        return None


# =====================================================
# BOTH CE & PE
# =====================================================


def get_option_both(
    index_security_id,
    strike,
):

    try:

        oc = get_clean_option_chain(index_security_id)

        if not oc:

            return None

        strike = int(float(strike))

        strike_key = str(strike)

        if strike_key in oc:

            return oc[strike_key]

        closest = min(
            oc.keys(),
            key=lambda x: abs(int(x) - strike),
        )

        return oc[closest]

    except Exception as e:

        logger.exception(f"❌ Get both option failed: {e}")

        return None


# =====================================================
# FULL CHAIN
# =====================================================


def get_full_option_chain(index_security_id):

    try:

        doc = get_latest_option_chain_doc(index_security_id)

        if not doc:

            return None

        if "_id" in doc:

            doc["_id"] = str(doc["_id"])

        option_chain = doc.get(
            "option_chain",
            {},
        )

        option_chain["oc"] = normalize_strikes(
            option_chain.get(
                "oc",
                {},
            )
        )

        doc["option_chain"] = option_chain

        return doc

    except Exception as e:

        logger.exception(f"❌ Full option chain failed: {e}")

        return None


# =====================================================
# ATM STRIKE
# =====================================================


def get_atm_strike(index_security_id):

    try:

        doc = get_latest_option_chain_doc(index_security_id)

        if not doc:

            return None

        last_price = doc.get(
            "option_chain",
            {},
        ).get("last_price")

        if not last_price:

            return None

        return int(round(float(last_price) / 50) * 50)

    except Exception as e:

        logger.exception(f"❌ ATM strike failed: {e}")

        return None
