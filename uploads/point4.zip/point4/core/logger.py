import logging
import os
import sys
import glob

from datetime import datetime

from logging.handlers import (
    RotatingFileHandler,
)

# =====================================================
# LOG DIRECTORY
# =====================================================

LOG_DIR = "logs"

os.makedirs(
    LOG_DIR,
    exist_ok=True,
)

# =====================================================
# LOG CONFIG
# =====================================================

MAX_LOG_FILES = 10

LOG_LEVEL = os.getenv(
    "LOG_LEVEL",
    "INFO",
).upper()

MAX_LOG_SIZE = 5_000_000

BACKUP_COUNT = 3

# =====================================================
# FORCE UTF-8
# =====================================================

try:

    sys.stdout.reconfigure(encoding="utf-8")

    sys.stderr.reconfigure(encoding="utf-8")

except Exception:
    pass

# =====================================================
# LOG FILE
# =====================================================

timestamp = datetime.now().strftime("%Y%m%d")

LOG_FILE = os.path.join(
    LOG_DIR,
    f"app_{timestamp}.log",
)

# Example:
# logs/app_20260513.log

# =====================================================
# CLEANUP OLD LOGS
# =====================================================


def cleanup_old_logs():

    try:

        log_files = sorted(
            glob.glob(
                os.path.join(
                    LOG_DIR,
                    "app_*.log*",
                )
            ),
            key=os.path.getmtime,
            reverse=True,
        )

        if len(log_files) <= MAX_LOG_FILES:

            return

        files_to_remove = log_files[MAX_LOG_FILES:]

        for file_path in files_to_remove:

            try:

                os.remove(file_path)

                print(f"🗑️ Removed old log: " f"{file_path}")

            except Exception as remove_error:

                print(f"❌ Failed removing log: " f"{remove_error}")

    except Exception as e:

        print(f"❌ Log cleanup failed: {e}")


# =====================================================
# LOGGER FACTORY
# =====================================================


def get_logger(name="app_logger"):

    logger = logging.getLogger(name)

    # ---------------------------------------------
    # PREVENT DUPLICATE HANDLERS
    # ---------------------------------------------

    if logger.handlers:

        return logger

    # ---------------------------------------------
    # LEVEL
    # ---------------------------------------------

    logger.setLevel(LOG_LEVEL)

    # ---------------------------------------------
    # CLEANUP OLD FILES
    # ---------------------------------------------

    cleanup_old_logs()

    # ---------------------------------------------
    # FORMATTER
    # ---------------------------------------------

    formatter = logging.Formatter(
        ("%(asctime)s | " "%(levelname)s | " "%(name)s | " "%(message)s")
    )

    # ---------------------------------------------
    # FILE HANDLER
    # ---------------------------------------------

    try:

        file_handler = RotatingFileHandler(
            LOG_FILE,
            maxBytes=MAX_LOG_SIZE,
            backupCount=BACKUP_COUNT,
            encoding="utf-8",
        )

        file_handler.setLevel(LOG_LEVEL)

        file_handler.setFormatter(formatter)

        logger.addHandler(file_handler)

    except Exception as file_error:

        print(f"❌ File logger failed: " f"{file_error}")

    # ---------------------------------------------
    # CONSOLE HANDLER
    # ---------------------------------------------

    try:

        console_handler = logging.StreamHandler(sys.stdout)

        console_handler.setLevel(LOG_LEVEL)

        console_handler.setFormatter(formatter)

        logger.addHandler(console_handler)

    except Exception as console_error:

        print(f"❌ Console logger failed: " f"{console_error}")

    # ---------------------------------------------
    # NO PROPAGATION
    # ---------------------------------------------

    logger.propagate = False

    # ---------------------------------------------
    # STARTUP LOG
    # ---------------------------------------------

    try:

        logger.info(f"🚀 Logger initialized -> " f"{LOG_FILE}")

    except Exception:
        pass

    return logger


# =====================================================
# GLOBAL LOGGER
# =====================================================

logger = get_logger()
