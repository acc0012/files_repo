from datetime import datetime
from django.conf import settings

from core.db import get_db
from core.logger import get_logger

# =====================================================
# LOGGER
# =====================================================

logger = get_logger("subscription_store")

# =====================================================
# COLLECTION NAME
# =====================================================

COLLECTION_NAME = getattr(
    settings,
    "SUBSCRIPTION_COLLECTION",
    "subscriptions",
)

# =====================================================
# GET COLLECTION
# =====================================================


def get_collection():

    try:
        db = get_db(settings.MONGO_DB)

        if db is None:
            raise ValueError("Mongo DB not available")

        return db[COLLECTION_NAME]

    except Exception as e:
        logger.exception(f"❌ Failed to get subscription collection: {e}")
        raise


# =====================================================
# SAVE SUBSCRIPTIONS (UPSERT)
# =====================================================


def save_subscriptions(instruments):

    try:
        if not isinstance(instruments, list):
            raise ValueError("instruments must be a list")

        # ✅ Ensure safe format (list of tuples/lists)
        clean_instruments = []

        for item in instruments:
            if not isinstance(item, (list, tuple)) or len(item) != 3:
                logger.warning(f"⚠️ Skipping invalid instrument: {item}")
                continue

            # Convert tuple → list (Mongo-friendly)
            clean_instruments.append(list(item))

        collection = get_collection()

        collection.update_one(
            {"_id": "active_subscriptions"},
            {
                "$set": {
                    "instruments": clean_instruments,
                    "updated_at": datetime.utcnow(),
                }
            },
            upsert=True,
        )

        logger.info(f"✅ Subscriptions saved | Count: {len(clean_instruments)}")

    except Exception as e:
        logger.exception(f"❌ Failed to save subscriptions: {e}")


# =====================================================
# LOAD SUBSCRIPTIONS
# =====================================================


def load_subscriptions():

    try:
        collection = get_collection()

        doc = collection.find_one({"_id": "active_subscriptions"})

        if not doc:
            logger.info("ℹ️ No stored subscriptions found")
            return []

        instruments = doc.get("instruments", [])

        # ✅ Convert back to tuple format (required by feed)
        result = []

        for item in instruments:
            try:
                if isinstance(item, (list, tuple)) and len(item) == 3:
                    result.append(tuple(item))
                else:
                    logger.warning(f"⚠️ Invalid stored instrument: {item}")

            except Exception as e:
                logger.warning(f"⚠️ Failed parsing instrument {item}: {e}")

        logger.info(f"📦 Loaded subscriptions | Count: {len(result)}")

        return result

    except Exception as e:
        logger.exception(f"❌ Failed to load subscriptions: {e}")
        return []


# =====================================================
# CLEAR SUBSCRIPTIONS
# =====================================================


def clear_subscriptions():

    try:
        collection = get_collection()

        collection.delete_one({"_id": "active_subscriptions"})

        logger.info("🗑️ Cleared all subscriptions from MongoDB")

    except Exception as e:
        logger.exception(f"❌ Failed to clear subscriptions: {e}")
