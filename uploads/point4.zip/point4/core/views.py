from django.http import JsonResponse
from django.shortcuts import render

from apps.marketfeed.views import (
    get_feed_service,
)

from core.logger import get_logger

# =====================================================
# LOGGER
# =====================================================

logger = get_logger("core_views")

# =====================================================
# ROOT DASHBOARD
# =====================================================


def home(request):

    try:

        # ---------------------------------------------
        # GET SERVICE
        # ---------------------------------------------

        service = get_feed_service()

        feed = getattr(
            service,
            "feed",
            None,
        )

        subscribed_count = 0

        subscribed_instruments = []

        # ---------------------------------------------
        # SAFE FEED ACCESS
        # ---------------------------------------------

        try:

            if feed and hasattr(
                feed,
                "instruments",
            ):

                subscribed_instruments = list(feed.instruments)

                subscribed_count = len(subscribed_instruments)

        except Exception as feed_error:

            logger.exception(f"❌ Feed access failed: " f"{feed_error}")

        # ---------------------------------------------
        # BUILD RESPONSE
        # ---------------------------------------------

        data = {
            # -----------------------------------------
            # STATUS
            # -----------------------------------------
            "status": ("running" if service.is_running else "stopped"),
            "feed_initialized": feed is not None,
            # -----------------------------------------
            # SUBSCRIPTIONS
            # -----------------------------------------
            "subscribed_security_ids": subscribed_count,
            "subscribed_instruments": subscribed_instruments,
            # -----------------------------------------
            # WEBSOCKET
            # -----------------------------------------
            "websocket_endpoint": "/ws/market/",
            # -----------------------------------------
            # DASHBOARD
            # -----------------------------------------
            "dashboard_url": "/dashboard/",
        }

        return JsonResponse(data)

    except Exception as e:

        logger.exception(f"❌ Home endpoint failed: {e}")

        return JsonResponse(
            {
                "status": "error",
                "message": str(e),
            },
            status=500,
        )


# =====================================================
# LIVE DASHBOARD PAGE
# =====================================================


def dashboard(request):

    try:

        return render(
            request,
            "dashboard/live_feed.html",
        )

    except Exception as e:

        logger.exception(f"❌ Dashboard render failed: {e}")

        return JsonResponse(
            {
                "status": "error",
                "message": "Dashboard failed to load",
            },
            status=500,
        )


# =====================================================
# HEALTH CHECK
# =====================================================


def health(request):

    try:

        service_status = "unknown"

        try:

            service = get_feed_service()

            service_status = "running" if service.is_running else "stopped"

        except Exception as service_error:

            logger.exception(f"❌ Service health check failed: " f"{service_error}")

        return JsonResponse(
            {
                # -------------------------------------
                # API
                # -------------------------------------
                "status": "ok",
                # -------------------------------------
                # SERVICE
                # -------------------------------------
                "market_feed_service": service_status,
            }
        )

    except Exception as e:

        logger.exception(f"❌ Health check failed: {e}")

        return JsonResponse(
            {
                "status": "error",
                "message": str(e),
            },
            status=500,
        )
