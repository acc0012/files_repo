from core.db import get_db
from django.conf import settings
from core.logger import get_logger

# =====================================================
# LOGGER
# =====================================================

logger = get_logger("option_lookup")


def get_option_security_id(index_security_id, strike_price, option_type="ce"):

    try:
        logger.info(
            f"🔍 Lookup Option | Index: {index_security_id} | Strike: {strike_price} | Type: {option_type}"
        )

        # -----------------------------------------
        # DB ACCESS
        # -----------------------------------------

        db = get_db(settings.MONGO_OPTION_CHAIN_DB)

        if db is None:
            logger.error("❌ Mongo DB is None")
            return None

        collection = db[settings.MONGO_OPTION_COLLECTION]

        # -----------------------------------------
        # FETCH DOCUMENT
        # -----------------------------------------

        doc = collection.find_one({"index_security_id": int(index_security_id)})

        if not doc:
            logger.warning(
                f"⚠️ No document found for index_security_id={index_security_id}"
            )
            return None

        # -----------------------------------------
        # PREPARE STRIKE KEY
        # -----------------------------------------

        try:
            strike_key = f"{float(strike_price):.6f}"
        except Exception:
            logger.error(f"❌ Invalid strike_price format: {strike_price}")
            return None

        oc = doc.get("option_chain", {}).get("oc", {})

        if not oc:
            logger.warning("⚠️ Option chain 'oc' missing or empty")
            return None

        # -----------------------------------------
        # STRIKE CHECK
        # -----------------------------------------

        if strike_key not in oc:
            logger.warning(
                f"⚠️ Strike not found: {strike_key} | Available sample: {list(oc.keys())[:5]}"
            )
            return None

        # -----------------------------------------
        # OPTION TYPE CHECK
        # -----------------------------------------

        option = oc[strike_key].get(option_type.lower())

        if not option:
            logger.warning(
                f"⚠️ Option type '{option_type}' not found for strike {strike_key}"
            )
            return None

        # -----------------------------------------
        # SECURITY ID
        # -----------------------------------------

        security_id = option.get("security_id")

        if not security_id:
            logger.warning(
                f"⚠️ security_id missing for strike={strike_key}, type={option_type}"
            )
            return None

        logger.info(
            f"✅ Found security_id={security_id} | index={index_security_id} | strike={strike_key} | type={option_type}"
        )

        return str(security_id)

    except Exception as e:
        logger.exception(f"❌ Option lookup failed: {e}")
        return None
