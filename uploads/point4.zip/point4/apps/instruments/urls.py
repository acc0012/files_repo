from rest_framework.routers import DefaultRouter
from .views import InstrumentViewSet

router = DefaultRouter()

# ✅ ADD basename
router.register(
    r'instruments',
    InstrumentViewSet,
    basename='instrument'
)

urlpatterns = router.urls