from rest_framework import status

from rest_framework.response import Response

from rest_framework.viewsets import (
    ModelViewSet,
)

from .models import Instrument

from .serializers import (
    InstrumentSerializer,
)

from core.logger import get_logger

# =====================================================
# LOGGER
# =====================================================

logger = get_logger("instrument_viewset")

# =====================================================
# VIEWSET
# =====================================================


class InstrumentViewSet(ModelViewSet):

    serializer_class = InstrumentSerializer

    # =================================================
    # QUERYSET
    # =================================================

    def get_queryset(self):

        try:

            queryset = Instrument.objects.all().order_by("-id")

            return queryset

        except Exception as e:

            logger.exception(f"❌ Queryset fetch failed: {e}")

            return Instrument.objects.none()

    # =================================================
    # CREATE
    # =================================================

    def create(
        self,
        request,
        *args,
        **kwargs,
    ):

        try:

            serializer = self.get_serializer(data=request.data)

            serializer.is_valid(raise_exception=True)

            self.perform_create(serializer)

            logger.info(f"✅ Instrument created: " f"{serializer.data}")

            return Response(
                {
                    "status": "success",
                    "data": serializer.data,
                },
                status=status.HTTP_201_CREATED,
            )

        except Exception as e:

            logger.exception(f"❌ Create failed: {e}")

            return Response(
                {
                    "status": "error",
                    "message": str(e),
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

    # =================================================
    # UPDATE
    # =================================================

    def update(
        self,
        request,
        *args,
        **kwargs,
    ):

        try:

            partial = kwargs.pop(
                "partial",
                False,
            )

            instance = self.get_object()

            serializer = self.get_serializer(
                instance,
                data=request.data,
                partial=partial,
            )

            serializer.is_valid(raise_exception=True)

            self.perform_update(serializer)

            logger.info(f"✅ Instrument updated: " f"{serializer.data}")

            return Response(
                {
                    "status": "success",
                    "data": serializer.data,
                }
            )

        except Exception as e:

            logger.exception(f"❌ Update failed: {e}")

            return Response(
                {
                    "status": "error",
                    "message": str(e),
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

    # =================================================
    # DELETE
    # =================================================

    def destroy(
        self,
        request,
        *args,
        **kwargs,
    ):

        try:

            instance = self.get_object()

            instrument_id = instance.id

            self.perform_destroy(instance)

            logger.info(f"🗑️ Instrument deleted: " f"{instrument_id}")

            return Response(
                {
                    "status": "success",
                    "message": "Instrument deleted",
                }
            )

        except Exception as e:

            logger.exception(f"❌ Delete failed: {e}")

            return Response(
                {
                    "status": "error",
                    "message": str(e),
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

    # =================================================
    # LIST
    # =================================================

    def list(
        self,
        request,
        *args,
        **kwargs,
    ):

        try:

            queryset = self.filter_queryset(self.get_queryset())

            serializer = self.get_serializer(
                queryset,
                many=True,
            )

            return Response(
                {
                    "status": "success",
                    "count": len(serializer.data),
                    "data": serializer.data,
                }
            )

        except Exception as e:

            logger.exception(f"❌ List failed: {e}")

            return Response(
                {
                    "status": "error",
                    "message": str(e),
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

    # =================================================
    # RETRIEVE
    # =================================================

    def retrieve(
        self,
        request,
        *args,
        **kwargs,
    ):

        try:

            instance = self.get_object()

            serializer = self.get_serializer(instance)

            return Response(
                {
                    "status": "success",
                    "data": serializer.data,
                }
            )

        except Exception as e:

            logger.exception(f"❌ Retrieve failed: {e}")

            return Response(
                {
                    "status": "error",
                    "message": str(e),
                },
                status=status.HTTP_404_NOT_FOUND,
            )
