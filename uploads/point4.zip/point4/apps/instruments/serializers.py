from rest_framework import serializers

from .models import Instrument

# =====================================================
# SERIALIZER
# =====================================================


class InstrumentSerializer(serializers.ModelSerializer):

    # =================================================
    # META
    # =================================================

    class Meta:

        model = Instrument

        fields = "__all__"

    # =================================================
    # VALIDATE EXCHANGE SEGMENT
    # =================================================

    def validate_exchange_segment(
        self,
        value,
    ):

        try:

            if value is None:

                raise serializers.ValidationError("exchange_segment is required")

            if not isinstance(
                value,
                int,
            ):

                raise serializers.ValidationError("exchange_segment must be integer")

            if value < 0:

                raise serializers.ValidationError("exchange_segment cannot be negative")

            return value

        except Exception as e:

            raise serializers.ValidationError(str(e))

    # =================================================
    # VALIDATE SECURITY ID
    # =================================================

    def validate_security_id(
        self,
        value,
    ):

        try:

            if not value:

                raise serializers.ValidationError("security_id is required")

            value = str(value).strip()

            if len(value) == 0:

                raise serializers.ValidationError("security_id cannot be empty")

            if len(value) > 50:

                raise serializers.ValidationError("security_id too long")

            return value

        except Exception as e:

            raise serializers.ValidationError(str(e))

    # =================================================
    # VALIDATE SUBSCRIPTION TYPE
    # =================================================

    def validate_subscription_type(
        self,
        value,
    ):

        try:

            if value is None:

                raise serializers.ValidationError("subscription_type is required")

            if not isinstance(
                value,
                int,
            ):

                raise serializers.ValidationError("subscription_type must be integer")

            if value < 0:

                raise serializers.ValidationError(
                    "subscription_type cannot be negative"
                )

            return value

        except Exception as e:

            raise serializers.ValidationError(str(e))

    # =================================================
    # GLOBAL VALIDATION
    # =================================================

    def validate(
        self,
        attrs,
    ):

        try:

            exchange_segment = attrs.get("exchange_segment")

            security_id = attrs.get("security_id")

            subscription_type = attrs.get("subscription_type")

            # -----------------------------------------
            # REQUIRED CHECK
            # -----------------------------------------

            if exchange_segment is None:

                raise serializers.ValidationError(
                    {"exchange_segment": "Required field"}
                )

            if not security_id:

                raise serializers.ValidationError({"security_id": "Required field"})

            if subscription_type is None:

                raise serializers.ValidationError(
                    {"subscription_type": "Required field"}
                )

            # -----------------------------------------
            # DUPLICATE CHECK
            # -----------------------------------------

            queryset = Instrument.objects.filter(
                exchange_segment=exchange_segment,
                security_id=security_id,
                subscription_type=subscription_type,
            )

            # Ignore same instance during update
            if self.instance:

                queryset = queryset.exclude(id=self.instance.id)

            if queryset.exists():

                raise serializers.ValidationError(
                    {"duplicate": ("Instrument already exists")}
                )

            return attrs

        except Exception as e:

            if isinstance(
                e,
                serializers.ValidationError,
            ):

                raise e

            raise serializers.ValidationError(str(e))

    # =================================================
    # CREATE
    # =================================================

    def create(
        self,
        validated_data,
    ):

        try:

            instrument = Instrument.objects.create(**validated_data)

            return instrument

        except Exception as e:

            raise serializers.ValidationError(f"Create failed: {e}")

    # =================================================
    # UPDATE
    # =================================================

    def update(
        self,
        instance,
        validated_data,
    ):

        try:

            instance.exchange_segment = validated_data.get(
                "exchange_segment",
                instance.exchange_segment,
            )

            instance.security_id = validated_data.get(
                "security_id",
                instance.security_id,
            )

            instance.subscription_type = validated_data.get(
                "subscription_type",
                instance.subscription_type,
            )

            instance.save()

            return instance

        except Exception as e:

            raise serializers.ValidationError(f"Update failed: {e}")
