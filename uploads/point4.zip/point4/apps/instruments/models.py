from django.db import models

class Instrument(models.Model):
    exchange_segment = models.IntegerField()
    security_id = models.CharField(max_length=50)
    subscription_type = models.IntegerField()

    def __str__(self):
        return self.security_id