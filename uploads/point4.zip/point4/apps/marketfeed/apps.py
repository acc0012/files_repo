from django.apps import AppConfig

class MarketfeedConfig(AppConfig):
    name = "apps.marketfeed"

    def ready(self):
        from .startup import start_feed_on_boot
        start_feed_on_boot()