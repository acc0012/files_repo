import threading
from datetime import datetime

from dhanhq.marketfeed import MarketFeed
from dhanhq.dhan_context import DhanContext

from core.dhan_token import load_valid_dhan_credentials
from core.logger import get_logger

# ✅ PERSISTENCE LAYER
from core.subscription_store import (
    save_subscriptions,
    load_subscriptions,
    clear_subscriptions,
)

# =====================================================
# LOGGER
# =====================================================

logger = get_logger("marketfeed_service")

# =====================================================
# LOAD DHAN CREDENTIALS
# =====================================================

creds = load_valid_dhan_credentials()

if not creds:
    logger.error("❌ No valid Dhan credentials found")
    raise Exception("No valid Dhan credentials found")

CLIENT_ID = creds["client_id"]
ACCESS_TOKEN = creds["access_token"]

logger.info("✅ Dhan credentials loaded successfully")

# =====================================================
# DHAN CONTEXT
# =====================================================

try:
    dhan_context = DhanContext(
        CLIENT_ID,
        ACCESS_TOKEN,
    )
    logger.info("✅ DhanContext initialized successfully")

except Exception as e:
    logger.exception(f"❌ Failed to initialize DhanContext: {e}")
    raise

# =====================================================
# THREAD LOCK
# =====================================================

lock = threading.RLock()

# =====================================================
# MAX CACHE SIZE
# =====================================================

MAX_TICK_CACHE = 5000


# =====================================================
# MARKET FEED SERVICE
# =====================================================


class MarketFeedService:
    def __init__(self):

        # ---------------------------------------------
        # FEED STATE
        # ---------------------------------------------

        self.feed = None
        self.is_running = False

        # ---------------------------------------------
        # TRACKING
        # ---------------------------------------------

        self.subscribed_instruments = set()  # ✅ store tuple directly
        self.latest_ticks = {}
        self.total_messages = 0
        self.started_at = None
        self.last_message_time = None

        # ✅ LOAD FROM MONGO
        try:
            self.persisted_instruments = load_subscriptions()
            logger.info(
                f"📦 Loaded persisted instruments: {self.persisted_instruments}"
            )
        except Exception as e:
            logger.exception(f"❌ Failed loading persisted subscriptions: {e}")
            self.persisted_instruments = []

        logger.info("🚀 MarketFeedService initialized")

    # =================================================
    # START FEED
    # =================================================

    def start_feed(self, instruments=None, callbacks=None):

        with lock:
            if self.is_running:
                logger.warning("⚠️ Feed already running")
                return self.feed

            try:
                # ✅ Use persisted if not provided
                if not instruments:
                    instruments = self.persisted_instruments

                if not instruments:
                    raise ValueError("No instruments provided or persisted")

                logger.info("🚀 Starting market feed...")
                logger.info(f"📡 Instruments Count: {len(instruments)}")
                logger.info(f"📡 Instruments: {instruments}")

                # ✅ Track subscriptions as tuple
                for item in instruments:
                    self.subscribed_instruments.add(tuple(item))

                # ✅ Create feed
                self.feed = MarketFeed(
                    dhan_context=dhan_context,
                    instruments=instruments,
                    version="v2",
                    **(callbacks or {}),
                )

                logger.info("⏳ Connecting to Dhan WebSocket...")

                self.feed.start()

                self.started_at = datetime.now()
                self.is_running = True

                # ✅ Persist state
                save_subscriptions(list(self.subscribed_instruments))

                logger.info("✅ Market feed started successfully")

                return self.feed

            except Exception as e:
                self.feed = None
                self.is_running = False
                self.started_at = None

                logger.exception(f"❌ Failed to start market feed: {e}")
                raise

    # =================================================
    # SUBSCRIBE
    # =================================================

    def subscribe(self, instruments):

        if not self.feed:
            logger.error("❌ Cannot subscribe. Feed not started")
            raise Exception("Feed is not started")

        try:
            with lock:
                logger.info(f"📥 Subscribing instruments: {instruments}")

                filtered = []

                for item in instruments:
                    key = tuple(item)

                    if key not in self.subscribed_instruments:
                        filtered.append(item)

                if not filtered:
                    logger.warning("⚠️ All instruments already subscribed")
                    return

                # ✅ Subscribe
                self.feed.subscribe_symbols(filtered)

                # ✅ Track
                for item in filtered:
                    self.subscribed_instruments.add(tuple(item))

                # ✅ Persist
                save_subscriptions(list(self.subscribed_instruments))

                logger.info(
                    f"✅ Subscription successful | Total: {len(self.subscribed_instruments)}"
                )

        except Exception as e:
            logger.exception(f"❌ Subscribe failed: {e}")
            raise

    # =================================================
    # UNSUBSCRIBE
    # =================================================

    def unsubscribe(self, instruments):

        if not self.feed:
            logger.error("❌ Cannot unsubscribe. Feed not started")
            raise Exception("Feed is not started")

        try:
            with lock:
                logger.info(f"📤 Unsubscribing instruments: {instruments}")

                # ✅ Unsubscribe
                self.feed.unsubscribe_symbols(instruments)

                for item in instruments:
                    key = tuple(item)
                    self.subscribed_instruments.discard(key)

                    try:
                        security_id = str(item[1])
                        self.latest_ticks.pop(security_id, None)
                    except Exception:
                        pass

                # ✅ Persist
                save_subscriptions(list(self.subscribed_instruments))

                logger.info(
                    f"✅ Unsubscribe successful | Remaining: {len(self.subscribed_instruments)}"
                )

        except Exception as e:
            logger.exception(f"❌ Unsubscribe failed: {e}")
            raise

    # =================================================
    # UPDATE TICK CACHE
    # =================================================

    def update_tick(self, message):

        try:
            security_id = str(message.get("security_id", "UNKNOWN"))

            with lock:
                if len(self.latest_ticks) >= MAX_TICK_CACHE:
                    oldest_key = next(iter(self.latest_ticks))
                    self.latest_ticks.pop(oldest_key, None)

                self.latest_ticks[security_id] = message
                self.total_messages += 1
                self.last_message_time = datetime.now()

        except Exception as e:
            logger.exception(f"❌ Failed to update tick cache: {e}")

    # =================================================
    # STOP FEED
    # =================================================

    def stop_feed(self):

        with lock:
            if not self.feed:
                logger.warning("⚠️ Feed already stopped")
                return

            try:
                logger.info("🛑 Closing market feed connection...")

                try:
                    self.feed.close_connection()
                except Exception as close_error:
                    logger.warning(f"⚠️ Close connection issue: {close_error}")

                # ✅ Clear Mongo
                clear_subscriptions()

                # ✅ Reset state
                self.feed = None
                self.is_running = False
                self.subscribed_instruments.clear()
                self.latest_ticks.clear()
                self.total_messages = 0
                self.started_at = None
                self.last_message_time = None

                logger.info("✅ Market feed stopped successfully")

            except Exception as e:
                logger.exception(f"❌ Failed to stop feed: {e}")

    # =================================================
    # GET STATUS
    # =================================================

    def get_status(self):

        try:
            uptime_seconds = 0

            if self.started_at:
                uptime_seconds = int((datetime.now() - self.started_at).total_seconds())

            with lock:
                return {
                    "is_running": self.is_running,
                    "feed_initialized": self.feed is not None,
                    "subscribed_count": len(self.subscribed_instruments),
                    "subscribed_instruments": list(self.subscribed_instruments),
                    "cached_ticks": len(self.latest_ticks),
                    "total_messages": self.total_messages,
                    "started_at": str(self.started_at) if self.started_at else None,
                    "last_message_time": (
                        str(self.last_message_time) if self.last_message_time else None
                    ),
                    "uptime_seconds": uptime_seconds,
                }

        except Exception as e:
            logger.exception(f"❌ Failed to get status: {e}")
            return {"error": str(e)}

    # =================================================
    # DASHBOARD DATA
    # =================================================

    def get_dashboard_data(self):

        try:
            with lock:
                return {
                    "status": self.get_status(),
                    "latest_ticks": dict(self.latest_ticks),
                }

        except Exception as e:
            logger.exception(f"❌ Failed dashboard data: {e}")
            return {"error": str(e)}
