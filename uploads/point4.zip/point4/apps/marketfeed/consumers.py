import json
import logging

from channels.generic.websocket import AsyncWebsocketConsumer

logger = logging.getLogger(__name__)


# =====================================================
# MARKET FEED CONSUMER
# =====================================================

class MarketFeedConsumer(AsyncWebsocketConsumer):

    # =================================================
    # CONNECT
    # =================================================

    async def connect(self):

        try:
            self.security_id = self.scope["url_route"]["kwargs"].get("security_id")

            # ✅ DASHBOARD (ALL)
            if not self.security_id:
                self.group_name = "market_feed"
                logger.info("📡 Dashboard connected (ALL instruments)")

            # ✅ SINGLE
            else:
                self.group_name = f"market_{self.security_id}"
                logger.info(
                    f"[WS CONNECTED] security_id={self.security_id} | group={self.group_name}"
                )

            if not self.channel_layer:
                await self.close(code=1011)
                return

            await self.channel_layer.group_add(
                self.group_name,
                self.channel_name,
            )

            await self.accept()

        except Exception as e:
            logger.exception(f"[WS CONNECT ERROR] {e}")
            try:
                await self.close(code=1011)
            except Exception:
                pass

    # =================================================
    # DISCONNECT
    # =================================================

    async def disconnect(self, close_code):

        try:
            if getattr(self, "group_name", None):
                await self.channel_layer.group_discard(
                    self.group_name,
                    self.channel_name,
                )

            logger.info(
                f"[WS DISCONNECTED] security_id={getattr(self, 'security_id', 'ALL')} "
                f"| Channel: {self.channel_name}, Code: {close_code}"
            )

        except Exception as e:
            logger.exception(f"[WS DISCONNECT ERROR] {e}")

    # =================================================
    # RECEIVE
    # =================================================

    async def receive(self, text_data=None, bytes_data=None):

        try:
            if text_data:
                try:
                    data = json.loads(text_data)
                except json.JSONDecodeError:
                    return

                action = str(data.get("action", "")).lower()

                # ✅ Ping support
                if action == "ping":
                    await self.safe_send({
                        "type": "system",
                        "status": "pong",
                        "security_id": self.security_id or "ALL",
                    })

        except Exception as e:
            logger.exception(f"[WS RECEIVE ERROR] {e}")

    # =================================================
    # SEND MARKET DATA
    # =================================================

    async def send_market_data(self, event):

        try:
            message = event.get("data", {})

            if not isinstance(message, dict):
                return

            msg_security_id = str(message.get("security_id"))

            # ✅ FILTER only for single WS
            if self.security_id:
                if msg_security_id != str(self.security_id):
                    return

            safe_message = {
                k: (str(v) if not isinstance(v, (int, float, dict, list)) else v)
                for k, v in message.items()
            }

            await self.safe_send(safe_message)

        except Exception as e:

            error_str = str(e)

            # ✅ CLEAN LOG (client closed connection)
            if "ConnectionClosed" in error_str or "ClientDisconnected" in error_str:
                logger.info("🔌 WS stopped sending (client disconnected)")
                return

            logger.exception(f"[WS SEND ERROR] {e}")

    # =================================================
    # SAFE SEND
    # =================================================

    async def safe_send(self, data):

        try:
            await self.send(
                text_data=json.dumps(data, default=str)
            )

        except Exception as e:

            error_str = str(e)

            # ✅ CLEAN LOG (refresh / tab close)
            if "ConnectionClosed" in error_str or "ClientDisconnected" in error_str:
                logger.info("🔌 WS connection closed (client refresh / tab close)")
                return

            logger.exception(f"[WS SAFE SEND ERROR] {e}")