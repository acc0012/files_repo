import threading
import time

# ✅ IMPORTANT: Use singleton service from views
from apps.marketfeed.views import (
    get_feed_service,
    on_message,
)

from core.subscription_store import load_subscriptions
from core.logger import get_logger

logger = get_logger("startup")


# =====================================================
# AUTO START FEED ON BOOT
# =====================================================

def start_feed_on_boot():

    def runner():

        try:
            # -----------------------------------------
            # LET DJANGO FULLY INIT
            # -----------------------------------------
            time.sleep(3)

            # -----------------------------------------
            # LOAD STORED SUBSCRIPTIONS
            # -----------------------------------------
            instruments = load_subscriptions()

            if not instruments:
                logger.info("ℹ️ No persisted subscriptions found")
                return

            logger.info(
                f"🚀 Auto starting feed with {len(instruments)} instruments"
            )

            # ✅ IMPORTANT: USE SINGLETON
            service = get_feed_service()

            # -----------------------------------------
            # AVOID DUPLICATE START
            # -----------------------------------------
            if service.is_running:
                logger.warning("⚠️ Feed already running at startup")
                return

            # -----------------------------------------
            # START FEED
            # -----------------------------------------
            service.start_feed(
                instruments,
                callbacks={"on_message": on_message},
            )

            logger.info("✅ Startup feed initialized successfully")

        except Exception as e:
            logger.exception(f"❌ Startup feed failed: {e}")

    # ✅ RUN IN BACKGROUND THREAD
    thread = threading.Thread(target=runner, daemon=True)
    thread.start()
