import os

from channels.auth import (
    AuthMiddlewareStack,
)

from channels.routing import (
    ProtocolTypeRouter,
    URLRouter,
)

from django.core.asgi import (
    get_asgi_application,
)

from apps.marketfeed.routing import (
    websocket_urlpatterns,
)

# =====================================================
# DJANGO SETTINGS
# =====================================================

os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "dhan_project.settings",
)

# =====================================================
# DJANGO ASGI APP
# =====================================================

django_asgi_app = get_asgi_application()

# =====================================================
# MAIN APPLICATION
# =====================================================

application = ProtocolTypeRouter(
    {
        # =============================================
        # HTTP
        # =============================================
        "http": django_asgi_app,
        # =============================================
        # WEBSOCKET
        # =============================================
        "websocket": AuthMiddlewareStack(URLRouter(websocket_urlpatterns)),
    }
)
