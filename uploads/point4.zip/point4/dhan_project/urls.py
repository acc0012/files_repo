"""
URL configuration for dhan_project project.

The `urlpatterns` list routes URLs to views.

For more information please see:
https://docs.djangoproject.com/en/6.0/topics/http/urls/
"""

from django.contrib import admin

from django.urls import (
    include,
    path,
)

from core.views import (
    dashboard,
    health,
    home,
)

# =====================================================
# URL PATTERNS
# =====================================================

urlpatterns = [
    # =================================================
    # ADMIN
    # =================================================
    path(
        "admin/",
        admin.site.urls,
    ),
    # =================================================
    # CORE
    # =================================================
    path(
        "",
        home,
    ),
    path(
        "dashboard/",
        dashboard,
    ),
    path(
        "health/",
        health,
    ),
    # =================================================
    # INSTRUMENT APIs
    # =================================================
    path(
        "api/",
        include("apps.instruments.urls"),
    ),
    # =================================================
    # MARKET FEED APIs
    # =================================================
    path(
        "marketfeed/",
        include("apps.marketfeed.urls"),
    ),
    # =================================================
    # OPTIONAL LEGACY ROUTE
    # =================================================
    path(
        "api/feed/",
        include("apps.marketfeed.urls"),
    ),
]
