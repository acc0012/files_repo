from dhanhq.marketfeed import MarketFeed

def resolve_exchange_segment(index_security_id):
    index_list = [13, 51]
    index_security_id = int(index_security_id)

    # ✅ NIFTY / BANKNIFTY / FINNIFTY
    if index_security_id in index_list:
        return MarketFeed.NSE_FNO  # = 2

    # ✅ SENSEX (future support)
    if index_security_id in index_list:
        return MarketFeed.BSE_FNO  # = 8

    # ✅ fallback
    return MarketFeed.NSE_FNO