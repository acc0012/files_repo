from django.urls import re_path

from .consumers import (
    MarketFeedConsumer,
)

websocket_urlpatterns = [
    re_path(
        r"ws/market/$",
        MarketFeedConsumer.as_asgi(),
    ),
]
