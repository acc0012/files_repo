import json
import logging

from channels.generic.websocket import AsyncWebsocketConsumer

logger = logging.getLogger(__name__)


# =====================================================
# MARKET FEED CONSUMER
# =====================================================


class MarketFeedConsumer(AsyncWebsocketConsumer):
    # =================================================
    # CONNECT
    # =================================================

    async def connect(self):

        try:
            self.group_name = "market_feed"

            # ✅ Validate channel layer
            if not self.channel_layer:
                logger.error("❌ Channel layer not available")
                await self.close(code=1011)
                return

            # ✅ Join group
            await self.channel_layer.group_add(
                self.group_name,
                self.channel_name,
            )

            await self.accept()

            logger.info(f"[WS CONNECTED] Channel: {self.channel_name}")

            # ✅ REMOVED noisy "connected" message
            # (this was causing UNKNOWN rows in frontend)

        except Exception as e:
            logger.exception(f"[WS CONNECT ERROR] {e}")

            try:
                await self.close(code=1011)
            except Exception:
                pass

    # =================================================
    # DISCONNECT
    # =================================================

    async def disconnect(self, close_code):

        try:
            if getattr(self, "group_name", None):
                await self.channel_layer.group_discard(
                    self.group_name,
                    self.channel_name,
                )

            logger.info(
                f"[WS DISCONNECTED] Channel: {self.channel_name}, Code: {close_code}"
            )

        except Exception as e:
            logger.exception(f"[WS DISCONNECT ERROR] {e}")

    # =================================================
    # RECEIVE (CLIENT → SERVER)
    # =================================================

    async def receive(self, text_data=None, bytes_data=None):

        try:
            # ✅ Only process valid JSON
            if text_data:
                try:
                    data = json.loads(text_data)
                except json.JSONDecodeError:
                    logger.warning("[WS RECEIVE] Invalid JSON")
                    return  # ✅ silently ignore

                logger.info(f"[WS RECEIVE] {data}")

                # ✅ Only handle ping
                action = str(data.get("action", "")).lower()

                if action == "ping":
                    await self.safe_send({"type": "system", "status": "pong"})
                    return

                # ✅ REMOVE ACK RESPONSE (was causing noise)
                # DO NOT send "received" back to client

            elif bytes_data:
                logger.warning("[WS RECEIVE] Binary ignored")

        except Exception as e:
            logger.exception(f"[WS RECEIVE ERROR] {e}")

    # =================================================
    # SEND MARKET DATA
    # =================================================

    async def send_market_data(self, event):

        try:
            message = event.get("data", {})

            # ✅ HARD FILTER (CRITICAL)
            if not isinstance(message, dict):
                return

            if not message.get("security_id"):
                # ✅ Ignore system / bad messages
                return

            # ✅ Ensure serializable
            safe_message = {
                k: (str(v) if not isinstance(v, (int, float, dict, list)) else v)
                for k, v in message.items()
            }

            await self.safe_send(safe_message)

        except Exception as e:
            logger.exception(f"[WS SEND ERROR] {e}")

            try:
                await self.close(code=1011)
            except Exception:
                pass

    # =================================================
    # SAFE SEND
    # =================================================

    async def safe_send(self, data):

        try:
            await self.send(
                text_data=json.dumps(
                    data,
                    default=str,
                )
            )

        except Exception as e:
            logger.exception(f"[WS SAFE SEND ERROR] {e}")
            raise
