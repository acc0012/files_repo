# apps/marketfeed/views.py

import asyncio
import os

from rest_framework.decorators import api_view
from rest_framework.response import Response

from channels.layers import get_channel_layer

from dhanhq.marketfeed import MarketFeed

from apps.marketfeed.services import MarketFeedService
from core.logger import get_logger

from core.option_lookup import get_option_security_id
from apps.marketfeed.utils import resolve_exchange_segment


# =====================================================
# LOGGER
# =====================================================

logger = get_logger("marketfeed_views")

# =====================================================
# SINGLETON SERVICE
# =====================================================

_feed_service_instance = None


def get_feed_service():
    global _feed_service_instance

    if _feed_service_instance is None:
        _feed_service_instance = MarketFeedService()

    return _feed_service_instance


# =====================================================
# BASE WS URL
# =====================================================

BASE_WS_URL = os.getenv("BASE_WS_URL", "")

# =====================================================
# CONSTANT MAPS
# =====================================================

SEGMENT_MAP = {
    "IDX": MarketFeed.IDX,
    "NSE_FNO": MarketFeed.NSE_FNO,
}

TYPE_MAP = {
    "Quote": MarketFeed.Quote,
    "Full": MarketFeed.Full,
}

# =====================================================
# VALIDATOR
# =====================================================


def is_valid_tuple(inst):
    return isinstance(inst, (list, tuple)) and len(inst) == 3


# =====================================================
# FORMAT CONVERTER
# =====================================================


def convert_to_tuple_format(instruments):

    result = []
    invalid = []

    for inst in instruments:
        try:
            if isinstance(inst, dict):
                segment_name = inst.get("segment")
                security_id = inst.get("security_id")
                type_name = inst.get("type")

                if segment_name not in SEGMENT_MAP:
                    raise ValueError(f"Invalid segment: {segment_name}")

                if type_name not in TYPE_MAP:
                    raise ValueError(f"Invalid type: {type_name}")

                if not security_id:
                    raise ValueError("security_id missing")

                result.append(
                    (
                        SEGMENT_MAP[segment_name],
                        str(security_id),
                        TYPE_MAP[type_name],
                    )
                )

            elif isinstance(inst, list):
                if not is_valid_tuple(inst):
                    raise ValueError("List must contain 3 items")

                result.append(tuple(inst))

            elif isinstance(inst, tuple):
                if not is_valid_tuple(inst):
                    raise ValueError("Tuple must contain 3 items")

                result.append(inst)

            else:
                raise ValueError(f"Unsupported format: {type(inst)}")

        except Exception as e:
            invalid.append(
                {
                    "instrument": str(inst),
                    "error": str(e),
                }
            )

            logger.exception(f"❌ Invalid instrument: {inst} => {e}")

    logger.info(f"📡 Converted instruments: {result}")

    return result, invalid


# =====================================================
# WEBSOCKET CALLBACK (✅ FIXED)
# =====================================================


def on_message(instance, message):

    try:
        # ✅ FILTER NON-MARKET MESSAGES (CRITICAL FIX)
        if not isinstance(message, dict):
            return

        if not message.get("security_id"):
            logger.debug(f"⚠️ Ignored non-market msg: {message}")
            return

        # ✅ OPTIONAL STRICT FILTER (UNCOMMENT IF NEEDED)
        # if not message.get("LTP"):
        #     return

        service = get_feed_service()

        # ✅ Update tick only for valid messages
        service.update_tick(message)

        channel_layer = get_channel_layer()

        if not channel_layer:
            logger.error("❌ Channel layer not initialized")
            return

        async def send():
            try:
                await channel_layer.group_send(
                    "market_feed",
                    {
                        "type": "send_market_data",
                        "data": message,
                    },
                )
            except Exception as send_error:
                logger.exception(f"❌ group_send failed: {send_error}")

        try:
            loop = asyncio.get_running_loop()
            loop.create_task(send())
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            loop.run_until_complete(send())
            loop.close()

    except Exception as e:
        logger.exception(f"❌ WebSocket send failed: {e}")


# =====================================================
# START FEED
# =====================================================


@api_view(["POST"])
def start_feed(request):

    try:
        instruments = request.data.get("instruments", [])

        if not instruments:
            return Response({"error": "instruments required"}, status=400)

        service = get_feed_service()

        if service.is_running:
            return Response(
                {
                    "status": "already_running",
                    "websocket_url": BASE_WS_URL or "/ws/market/",
                    "dashboard": "/dashboard/",
                }
            )

        parsed, invalid = convert_to_tuple_format(instruments)

        if not parsed:
            return Response(
                {
                    "error": "No valid instruments",
                    "invalid": invalid,
                },
                status=400,
            )

        service.start_feed(parsed, callbacks={"on_message": on_message})

        return Response(
            {
                "status": "feed_started",
                "parsed": parsed,
                "invalid": invalid,
                "count": len(parsed),
                "websocket_url": BASE_WS_URL or "/ws/market/",
                "dashboard": "/dashboard/",
            }
        )

    except Exception as e:
        logger.exception(f"❌ Start failed: {e}")
        return Response({"error": str(e)}, status=500)


# =====================================================
# SUBSCRIBE
# =====================================================


@api_view(["POST"])
def subscribe(request):

    try:
        instruments = request.data.get("instruments", [])

        if not instruments:
            return Response({"error": "instruments required"}, status=400)

        service = get_feed_service()

        if not service.is_running:
            return Response({"error": "feed not started"}, status=400)

        parsed, invalid = convert_to_tuple_format(instruments)

        if not parsed:
            return Response(
                {
                    "error": "No valid instruments",
                    "invalid": invalid,
                },
                status=400,
            )

        service.subscribe(parsed)

        return Response(
            {
                "status": "subscribed",
                "parsed": parsed,
                "invalid": invalid,
                "total": len(service.subscribed_instruments),
            }
        )

    except Exception as e:
        logger.exception(f"❌ Subscribe failed: {e}")
        return Response({"error": str(e)}, status=500)


# =====================================================
# UNSUBSCRIBE
# =====================================================


@api_view(["POST"])
def unsubscribe(request):

    try:
        instruments = request.data.get("instruments", [])

        if not instruments:
            return Response({"error": "instruments required"}, status=400)

        service = get_feed_service()

        if not service.is_running:
            return Response({"error": "feed not started"}, status=400)

        parsed, invalid = convert_to_tuple_format(instruments)

        if not parsed:
            return Response(
                {
                    "error": "No valid instruments",
                    "invalid": invalid,
                },
                status=400,
            )

        service.unsubscribe(parsed)

        return Response(
            {
                "status": "unsubscribed",
                "parsed": parsed,
                "invalid": invalid,
                "remaining": len(service.subscribed_instruments),
            }
        )

    except Exception as e:
        logger.exception(f"❌ Unsubscribe failed: {e}")
        return Response({"error": str(e)}, status=500)


# =====================================================
# STOP FEED
# =====================================================


@api_view(["POST"])
def stop_feed(request):

    try:
        service = get_feed_service()

        if not service.is_running:
            return Response({"status": "already_stopped"})

        service.stop_feed()

        return Response({"status": "feed_stopped"})

    except Exception as e:
        logger.exception(f"❌ Stop failed: {e}")
        return Response({"error": str(e)}, status=500)


# =====================================================
# STATUS
# =====================================================


@api_view(["GET"])
def feed_status(request):

    try:
        return Response(get_feed_service().get_status())
    except Exception as e:
        logger.exception(f"❌ Status failed: {e}")
        return Response({"error": str(e)}, status=500)


# =====================================================
# DASHBOARD DATA
# =====================================================


@api_view(["POST"])
def subscribe_option(request, index_security_id):

    try:

        strike_price = request.data.get("strike_price")
        option_type = request.data.get("option_type", "ce")

        if not strike_price:
            return Response({"error": "strike_price required"}, status=400)

        # -----------------------------------------
        # GET OPTION SECURITY ID FROM MONGO
        # -----------------------------------------

        option_security_id = get_option_security_id(
            index_security_id,
            strike_price,
            option_type
        )

        if not option_security_id:
            return Response({
                "error": "Option not found",
                "index_security_id": index_security_id,
                "strike_price": strike_price,
                "option_type": option_type
            }, status=404)

        # -----------------------------------------
        # BUILD INSTRUMENT
        # -----------------------------------------

        exchange = resolve_exchange_segment(index_security_id)

        instrument = (
            exchange,
            option_security_id,
            MarketFeed.Quote  # = 17
        )

        # -----------------------------------------
        # SUBSCRIBE
        # -----------------------------------------

        service = get_feed_service()

        if not service.is_running:
            return Response({"error": "feed not started"}, status=400)

        service.subscribe([instrument])

        return Response({
            "status": "subscribed_option",
            "instrument": instrument,
            "index_security_id": index_security_id,
            "strike_price": strike_price,
            "option_type": option_type
        })

    except Exception as e:
        logger.exception(f"❌ Option subscribe failed: {e}")
        return Response({"error": str(e)}, status=500)

@api_view(["GET"])
def dashboard_data(request):

    try:
        return Response(get_feed_service().get_dashboard_data())
    except Exception as e:
        logger.exception(f"❌ Dashboard failed: {e}")
        return Response({"error": str(e)}, status=500)
