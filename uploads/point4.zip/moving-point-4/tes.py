from dhanhq import DhanContext, MarketFeed
import os
from dotenv import load_dotenv

load_dotenv()

ACCESS_TOKEN = os.getenv("ACCESS_TOKEN")
DHAIN_ID = os.getenv("DHAIN_ID")

# Initialize context
dhan_context = DhanContext(ACCESS_TOKEN, DHAIN_ID)

# Subscription setup
instruments = [
    (MarketFeed.IDX, "13", MarketFeed.Quote)
]

version = "v2"

try:
    print("Initializing MarketFeed...")
    
    data = MarketFeed(dhan_context, instruments, version)
    
    print("Starting WebSocket connection...")
    data.run_forever()
    
    print("Connection established. Listening for data...\n")
    
    while True:
        response = data.get_data()
        
        if response:
            print("Received Data:", response)
        else:
            print("No data received...")

except KeyboardInterrupt:
    print("\nExecution stopped by user (Ctrl+C).")

except ValueError as ve:
    print("ValueError occurred:")
    print(ve)

except ConnectionError as ce:
    print("ConnectionError occurred:")
    print(ce)

except Exception as e:
    print("Unexpected error occurred:")
    print(type(e).__name__, "-", e)

finally:
    print("\nCleaning up resources (if any)...")
