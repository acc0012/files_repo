#!/usr/bin/env bash
export PYTHONUNBUFFERED=1
uvicorn app.main:app --host ${HOST:-0.0.0.0} --port ${PORT:-8000} --reload
