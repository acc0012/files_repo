# Dhan MarketFeed Server

A production-ready FastAPI service that connects to **Dhan MarketFeed**, supports **dynamic subscribe/unsubscribe** of instruments, exposes **REST APIs** for instrument CRUD, and streams **raw ticks and aggregated candles** via **WebSockets**.

## Features
- Connects using `from dhanhq import marketfeed` (v2)
- Dynamic **subscribe/unsubscribe** while the connection is open
- REST API for **CRUD** on instrument registry
- WebSocket: **/ws/quotes** (raw) and **/ws/candles** (1s–1h)
- Optional **local JSONL persistence** per security/type

## Quickstart

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scriptsctivate
pip install -r requirements.txt
cp .env.example .env  # edit CLIENT_ID and ACCESS_TOKEN
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

### Health
```
GET http://localhost:8000/health
```

### REST Examples
```bash
# Add instruments to registry (no subscribe)
curl -X POST http://localhost:8000/instruments   -H 'Content-Type: application/json'   -d '{
        "instruments": [
          {"security_id": "62588"},
          {"exchange_segment":"IDX","security_id":"13","subscription_type":"Quote"}
        ]
      }'

# Subscribe
curl -X POST http://localhost:8000/subscribe   -H 'Content-Type: application/json'   -d '{
        "instruments": [
          {"exchange_segment":"NSE_FNO","security_id":"62588","subscription_type":"Quote"},
          {"exchange_segment":"IDX","security_id":"13","subscription_type":"Quote"}
        ]
      }'

# Unsubscribe
curl -X POST http://localhost:8000/unsubscribe   -H 'Content-Type: application/json'   -d '{
        "instruments": [
          {"exchange_segment":"IDX","security_id":"13","subscription_type":"Quote"}
        ]
      }'

# List
curl http://localhost:8000/instruments
```

### WebSockets
```bash
# Raw quotes (top-of-book)
wscat -c "ws://localhost:8000/ws/quotes?exchange_segment=IDX&security_id=13&subscription_type=Quote"

# Live candles (e.g., 1m from Quote feed)
wscat -c "ws://localhost:8000/ws/candles?exchange_segment=IDX&security_id=13&interval=1m&source=Quote"
```

## Notes
- Candle volume is based on `LTQ` when present; otherwise 0 (typical for indices).
- Interval alignment uses `received_at` (epoch seconds). You can switch to `LTT` with date handling if needed.
- Local storage mirrors your JSONL design when `ENABLE_LOCAL_STORAGE=true` in `.env`.

## License
MIT
