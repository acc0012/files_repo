from __future__ import annotations
from typing import Dict, Tuple, Optional
from .models import Candle
from .utils import parse_interval_to_seconds, align_start, safe_float

class CandleAggregator:
    """
    Builds OHLCV candles per (exchange_segment, security_id, interval).
    Publishes updates through provided callback.
    """
    def __init__(self, on_candle):
        self._current: Dict[Tuple[str, str, str], Candle] = {}
        self._on_candle = on_candle  # async fn(topic:str, candle:dict)

    def _extract_price_volume(self, payload: dict):
        price = None
        vol = 0.0
        if "LTP" in payload:
            price = safe_float(payload.get("LTP"))
        elif "last_traded_price" in payload:
            price = safe_float(payload.get("last_traded_price"))
        ltq = payload.get("LTQ") or payload.get("last_traded_quantity")
        vol = safe_float(ltq, 0.0) or 0.0
        return price, vol

    async def ingest(self, exchange_segment: str, security_id: str, interval: str, payload: dict):
        interval_sec = parse_interval_to_seconds(interval)
        price, vol = self._extract_price_volume(payload)
        if price is None:
            return
        ts = payload.get("received_at")
        if ts is None:
            return
        key = (exchange_segment, security_id, interval)
        start_ts = align_start(ts, interval_sec)
        end_ts = start_ts + interval_sec
        cur = self._current.get(key)
        if not cur:
            cur = Candle(
                exchange_segment=exchange_segment,
                security_id=security_id,
                interval=interval,
                start_ts=start_ts,
                end_ts=end_ts,
                open=price, high=price, low=price, close=price,
                volume=vol,
                trades=1,
                closed=False
            )
            self._current[key] = cur
            await self._on_candle(self._topic_for(key), cur.model_dump())
            return
        if ts >= cur.end_ts:
            cur.closed = True
            await self._on_candle(self._topic_for(key), cur.model_dump())
            start_ts = align_start(ts, interval_sec)
            end_ts = start_ts + interval_sec
            cur = Candle(
                exchange_segment=exchange_segment,
                security_id=security_id,
                interval=interval,
                start_ts=start_ts,
                end_ts=end_ts,
                open=price, high=price, low=price, close=price,
                volume=vol,
                trades=1,
                closed=False
            )
            self._current[key] = cur
            await self._on_candle(self._topic_for(key), cur.model_dump())
            return
        cur.high = max(cur.high, price)
        cur.low = min(cur.low, price)
        cur.close = price
        cur.volume += vol
        cur.trades += 1
        await self._on_candle(self._topic_for(key), cur.model_dump())

    @staticmethod
    def _topic_for(key: Tuple[str, str, str]) -> str:
        exch, sec_id, interval = key
        return f"CANDLE:{exch}:{sec_id}:{interval}"
