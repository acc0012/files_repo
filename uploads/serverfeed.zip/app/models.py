from __future__ import annotations
from pydantic import BaseModel, Field
from typing import Literal, Optional, List, Any, Dict

ExchangeSegment = Literal["NSE", "NSE_FNO", "BSE", "IDX"]
SubscriptionType = Literal["Ticker", "Quote", "Full", "OI"]

class Instrument(BaseModel):
    exchange_segment: ExchangeSegment = Field(..., examples=["NSE_FNO"])
    security_id: str = Field(..., examples=["62588"])
    subscription_type: SubscriptionType = Field(..., examples=["Quote"])

    @property
    def topic_key(self) -> str:
        return f"{self.exchange_segment}:{self.security_id}:{self.subscription_type}"

class InstrumentIn(BaseModel):
    exchange_segment: Optional[ExchangeSegment] = None
    security_id: str
    subscription_type: Optional[SubscriptionType] = None

class InstrumentBatchIn(BaseModel):
    instruments: List[InstrumentIn]

class SubscribeRequest(BaseModel):
    instruments: List[Instrument]

class UnsubscribeRequest(BaseModel):
    instruments: List[Instrument]

class CandleSubscribeRequest(BaseModel):
    exchange_segment: ExchangeSegment
    security_id: str
    interval: str
    source: SubscriptionType = "Quote"

class ApiResponse(BaseModel):
    ok: bool = True
    message: Optional[str] = None
    data: Optional[Any] = None

class Candle(BaseModel):
    exchange_segment: ExchangeSegment
    security_id: str
    interval: str
    start_ts: float
    end_ts: float
    open: float
    high: float
    low: float
    close: float
    volume: float
    closed: bool = False
    trades: int = 0

RawFeed = Dict[str, Any]
