from __future__ import annotations
import os, json, time
from typing import Dict, Any
from .config import ENABLE_LOCAL_STORAGE, BASE_DIR

TYPE_FILE_MAP = {
    "Ticker Data": "ticker.jsonl",
    "Quote Data": "quote.jsonl",
    "Full Data": "full.jsonl",
    "OI Data": "oi.jsonl",
    "Previous Close": "prev_close.jsonl",
}

if ENABLE_LOCAL_STORAGE:
    os.makedirs(BASE_DIR, exist_ok=True)

def save_locally(response: Dict[str, Any]):
    if not ENABLE_LOCAL_STORAGE:
        return
    sec_id = response.get("security_id")
    feed_type = response.get("type")
    file_name = TYPE_FILE_MAP.get(feed_type)
    if not sec_id or not file_name:
        return
    response["received_at"] = response.get("received_at") or time.time()
    sec_dir = os.path.join(BASE_DIR, str(sec_id))
    os.makedirs(sec_dir, exist_ok=True)
    file_path = os.path.join(sec_dir, file_name)
    with open(file_path, "a", encoding="utf-8") as f:
        json.dump(response, f)
        f.write("
")
