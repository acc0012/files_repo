from __future__ import annotations
import os
from dotenv import load_dotenv

load_dotenv()

CLIENT_ID = os.getenv("CLIENT_ID") or ""
ACCESS_TOKEN = os.getenv("ACCESS_TOKEN") or ""
VERSION = os.getenv("VERSION", "v2")

DEFAULT_EXCHANGE_SEGMENT = os.getenv("DEFAULT_EXCHANGE_SEGMENT", "NSE_FNO")
DEFAULT_SUBSCRIPTION_TYPE = os.getenv("DEFAULT_SUBSCRIPTION_TYPE", "Quote")

ENABLE_LOCAL_STORAGE = os.getenv("ENABLE_LOCAL_STORAGE", "false").lower() == "true"
BASE_DIR = os.getenv("BASE_DIR", "local_market_data")

HOST = os.getenv("HOST", "0.0.0.0")
PORT = int(os.getenv("PORT", "8000"))
