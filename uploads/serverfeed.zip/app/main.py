from __future__ import annotations
import asyncio
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Query
from .config import DEFAULT_EXCHANGE_SEGMENT, DEFAULT_SUBSCRIPTION_TYPE
from .models import (
    Instrument, InstrumentIn, InstrumentBatchIn,
    SubscribeRequest, UnsubscribeRequest, ApiResponse
)
from .market_manager import MarketFeedManager

app = FastAPI(title="Dhan MarketFeed Server", version="1.0.0")

loop = asyncio.get_event_loop()
mgr = MarketFeedManager(loop)
mgr.start()

def normalize_instrument_in(i: InstrumentIn) -> Instrument:
    exch = i.exchange_segment or DEFAULT_EXCHANGE_SEGMENT
    sub = i.subscription_type or DEFAULT_SUBSCRIPTION_TYPE
    return Instrument(exchange_segment=exch, security_id=i.security_id, subscription_type=sub)

@app.get("/health", response_model=ApiResponse)
async def health():
    return ApiResponse(ok=True, message="OK")

@app.get("/instruments", response_model=ApiResponse)
async def list_instruments():
    return ApiResponse(ok=True, data={
        "registered": [i.model_dump() for i in mgr.list_registered()],
        "active": [i.model_dump() for i in mgr.list_active()],
    })

@app.post("/instruments", response_model=ApiResponse)
async def add_instruments(payload: InstrumentBatchIn):
    items = [normalize_instrument_in(i) for i in payload.instruments]
    mgr.add_instruments(items, subscribe=False)
    return ApiResponse(ok=True, message=f"Added {len(items)} instruments")

@app.delete("/instruments", response_model=ApiResponse)
async def remove_instruments(payload: InstrumentBatchIn):
    items = [normalize_instrument_in(i) for i in payload.instruments]
    mgr.remove_instruments(items, unsubscribe=False)
    return ApiResponse(ok=True, message=f"Removed {len(items)} instruments")

@app.post("/subscribe", response_model=ApiResponse)
async def subscribe(payload: SubscribeRequest):
    mgr.subscribe(payload.instruments)
    return ApiResponse(ok=True, message=f"Subscribed {len(payload.instruments)}")

@app.post("/unsubscribe", response_model=ApiResponse)
async def unsubscribe(payload: UnsubscribeRequest):
    mgr.unsubscribe(payload.instruments)
    return ApiResponse(ok=True, message=f"Unsubscribed {len(payload.instruments)}")

@app.websocket("/ws/quotes")
async def ws_quotes(
    ws: WebSocket,
    exchange_segment: str = Query(DEFAULT_EXCHANGE_SEGMENT),
    security_id: str = Query(...),
    subscription_type: str = Query(DEFAULT_SUBSCRIPTION_TYPE),
):
    await ws.accept()
    inst = Instrument(exchange_segment=exchange_segment, security_id=security_id, subscription_type=subscription_type)
    mgr.add_instruments([inst], subscribe=True)
    topic = inst.topic_key
    q = await mgr.broadcaster.subscribe(topic)
    try:
        while True:
            msg = await q.get()
            await ws.send_json(msg)
    except WebSocketDisconnect:
        pass
    except Exception:
        pass
    finally:
        await mgr.broadcaster.unsubscribe(topic, q)

@app.websocket("/ws/candles")
async def ws_candles(
    ws: WebSocket,
    exchange_segment: str = Query(DEFAULT_EXCHANGE_SEGMENT),
    security_id: str = Query(...),
    interval: str = Query("1m"),
    source: str = Query("Quote")
):
    await ws.accept()
    candle_topic, q_candle = await mgr.subscribe_candles_stream(exchange_segment, security_id, interval, source)
    raw_inst = Instrument(exchange_segment=exchange_segment, security_id=security_id, subscription_type=source)
    raw_topic = raw_inst.topic_key
    q_raw = await mgr.broadcaster.subscribe(raw_topic)
    try:
        while True:
            done, pending = await asyncio.wait(
                {asyncio.create_task(q_raw.get()), asyncio.create_task(q_candle.get())},
                return_when=asyncio.FIRST_COMPLETED
            )
            for task in done:
                item = task.result()
                if isinstance(item, dict) and item.get("type"):
                    await mgr.on_raw_for_candles(item, interval, source)
                else:
                    await ws.send_json(item)
            for p in pending:
                p.cancel()
    except WebSocketDisconnect:
        pass
    except Exception:
        pass
    finally:
        await mgr.broadcaster.unsubscribe(raw_topic, q_raw)
        await mgr.unsubscribe_candles_stream(candle_topic, q_candle)
