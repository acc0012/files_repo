from __future__ import annotations
import asyncio
from collections import defaultdict
from typing import Dict, Set

class Broadcaster:
    """
    Simple in-memory pub/sub for asyncio tasks and websockets.
    """
    def __init__(self):
        self._subs: Dict[str, Set[asyncio.Queue]] = defaultdict(set)
        self._lock = asyncio.Lock()

    async def subscribe(self, topic: str) -> asyncio.Queue:
        q: asyncio.Queue = asyncio.Queue(maxsize=1000)
        async with self._lock:
            self._subs[topic].add(q)
        return q

    async def unsubscribe(self, topic: str, q: asyncio.Queue):
        async with self._lock:
            if q in self._subs.get(topic, set()):
                self._subs[topic].remove(q)
            if not self._subs[topic]:
                self._subs.pop(topic, None)

    async def publish(self, topic: str, message):
        async with self._lock:
            subs = list(self._subs.get(topic, []))
        for q in subs:
            try:
                q.put_nowait(message)
            except asyncio.QueueFull:
                try:
                    _ = q.get_nowait()
                except Exception:
                    pass
                try:
                    q.put_nowait(message)
                except Exception:
                    pass
