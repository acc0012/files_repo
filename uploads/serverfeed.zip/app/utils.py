from __future__ import annotations
import re
import time

def now() -> float:
    return time.time()

def parse_interval_to_seconds(interval_str: str) -> int:
    s = interval_str.strip().lower()
    m = re.fullmatch(r"(\d+)(s|m|h)", s)
    if not m:
        raise ValueError("Interval must match pattern like '1s', '5s', '1m', '15m', '1h'")
    n, unit = int(m.group(1)), m.group(2)
    if unit == 's':
        return n
    if unit == 'm':
        return n * 60
    if unit == 'h':
        return n * 3600
    raise ValueError(f"Unsupported unit: {unit}")

def align_start(ts: float, interval_seconds: int) -> float:
    return ts - (int(ts) % interval_seconds)

def safe_float(val, default=None):
    try:
        return float(val)
    except Exception:
        return default
