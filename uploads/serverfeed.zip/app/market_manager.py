from __future__ import annotations
import threading, time
from typing import List, Tuple, Dict, Any, Optional
from dhanhq import marketfeed
from .models import Instrument
from .config import CLIENT_ID, ACCESS_TOKEN, VERSION
from .broadcaster import Broadcaster
from .storage import save_locally
from .candles import CandleAggregator

class MarketFeedManager:
    def __init__(self, loop):
        self.loop = loop
        self.broadcaster = Broadcaster()
        self._feed: Optional[marketfeed.DhanFeed] = None
        self._connect_thread: Optional[threading.Thread] = None
        self._reader_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._registered: Dict[str, Instrument] = {}
        self._active: Dict[str, Instrument] = {}

        async def on_candle(topic: str, candle_dict: dict):
            await self.broadcaster.publish(topic, candle_dict)
        self.candles = CandleAggregator(on_candle)

    def _exch_map(self, exch: str):
        return {
            "NSE": marketfeed.NSE,
            "NSE_FNO": marketfeed.NSE_FNO,
            "BSE": marketfeed.BSE,
            "IDX": marketfeed.IDX,
        }[exch]

    def _sub_map(self, sub: str):
        return {
            "Ticker": marketfeed.Ticker,
            "Quote": marketfeed.Quote,
            "Full": marketfeed.Full,
            "OI": marketfeed.OI,
        }[sub]

    def _to_tuple(self, i: Instrument) -> Tuple:
        return (self._exch_map(i.exchange_segment), i.security_id, self._sub_map(i.subscription_type))

    def start(self):
        if self._connect_thread and self._connect_thread.is_alive():
            return
        self._stop_event.clear()
        self._connect_thread = threading.Thread(target=self._run_feed_forever, daemon=True)
        self._connect_thread.start()
        self._reader_thread = threading.Thread(target=self._read_loop, daemon=True)
        self._reader_thread.start()

    def stop(self):
        self._stop_event.set()
        try:
            if self._feed:
                self._feed.disconnect()
        except Exception:
            pass

    def _run_feed_forever(self):
        initial = [self._to_tuple(i) for i in self._active.values()] or [(marketfeed.NSE_FNO, "62588", marketfeed.Quote)]
        while not self._stop_event.is_set():
            try:
                self._feed = marketfeed.DhanFeed(CLIENT_ID, ACCESS_TOKEN, initial, VERSION)
                self._feed.run_forever()
            except Exception as e:
                print("Feed error, reconnecting in 3s:", e)
                time.sleep(3)

    def _read_loop(self):
        while not self._stop_event.is_set():
            try:
                if not self._feed:
                    time.sleep(0.05)
                    continue
                response = self._feed.get_data()
                if not response:
                    time.sleep(0.001)
                    continue
                response["received_at"] = response.get("received_at") or time.time()
                save_locally(response)
                exch_seg = response.get("exchange_segment")
                sec_id = str(response.get("security_id"))
                packet_type = response.get("type")
                if packet_type == "Quote Data":
                    sub_label = "Quote"
                elif packet_type == "Ticker Data":
                    sub_label = "Ticker"
                elif packet_type == "Full Data":
                    sub_label = "Full"
                elif packet_type == "OI Data":
                    sub_label = "OI"
                else:
                    sub_label = "Quote"
                topic = f"{exch_seg}:{sec_id}:{sub_label}"
                self.loop.call_soon_threadsafe(
                    lambda: self.loop.create_task(self.broadcaster.publish(topic, response))
                )
            except Exception:
                time.sleep(0.01)

    def add_instruments(self, instruments: List[Instrument], subscribe: bool = False):
        for i in instruments:
            self._registered[i.topic_key] = i
        if subscribe:
            self.subscribe(instruments)

    def remove_instruments(self, instruments: List[Instrument], unsubscribe: bool = False):
        if unsubscribe:
            self.unsubscribe(instruments)
        for i in instruments:
            self._registered.pop(i.topic_key, None)

    def list_registered(self) -> List[Instrument]:
        return list(self._registered.values())

    def list_active(self) -> List[Instrument]:
        return list(self._active.values())

    def subscribe(self, instruments: List[Instrument]):
        if not instruments:
            return
        tuples = [self._to_tuple(i) for i in instruments]
        try:
            if self._feed:
                self._feed.subscribe_symbols(tuples)
        except Exception as e:
            print("Subscribe error:", e)
        for i in instruments:
            self._active[i.topic_key] = i

    def unsubscribe(self, instruments: List[Instrument]):
        if not instruments:
            return
        tuples = [self._to_tuple(i) for i in instruments]
        try:
            if self._feed:
                self._feed.unsubscribe_symbols(tuples)
        except Exception as e:
            print("Unsubscribe error:", e)
        for i in instruments:
            self._active.pop(i.topic_key, None)

    async def subscribe_candles_stream(self, exchange_segment: str, security_id: str, interval: str, source: str):
        src_inst = Instrument(exchange_segment=exchange_segment, security_id=security_id, subscription_type=source)
        if src_inst.topic_key not in self._active:
            self.add_instruments([src_inst], subscribe=True)
        candle_topic = f"CANDLE:{exchange_segment}:{security_id}:{interval}"
        q = await self.broadcaster.subscribe(candle_topic)
        return candle_topic, q

    async def unsubscribe_candles_stream(self, candle_topic: str, q):
        await self.broadcaster.unsubscribe(candle_topic, q)

    async def on_raw_for_candles(self, payload: Dict[str, Any], interval: str, expected_source: str):
        exch_seg = payload.get("exchange_segment")
        sec_id = str(payload.get("security_id"))
        pkt_type = payload.get("type")
        if expected_source == "Quote" and pkt_type != "Quote Data":
            return
        if expected_source == "Ticker" and pkt_type != "Ticker Data":
            return
        if expected_source == "Full" and pkt_type != "Full Data":
            return
        await self.candles.ingest(exch_seg, sec_id, interval, payload)
