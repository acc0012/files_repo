# Strategy Feed Engine

This is a FastAPI strategy observation engine for NIFTY option feeds.

It is designed to:

1. Fetch NIFTY 50 intraday candle data around 09:17 AM.
2. Use the 09:15 to 09:16 candle to calculate Opening Range average and R/S levels.
3. Build a dynamic subscription range using `NIFTY_OR_AVERAGE +/- 500` points.
4. Subscribe to CE and PE option contracts only inside that dynamic range.
5. Calculate option Opening Range levels for subscribed options.
6. Track R3/S3 touches.
7. Confirm strategy observations with live EMA crossover events.
8. Send Telegram strategy observation alerts with NIFTY LTP and opposite-side candidate option LTPs.

## Important

This project sends strategy observation alerts only. It does not provide financial advice or automated trade instructions.

## Run

```bat
python -m venv myenv
myenv\Scriptsctivate
pip install -r requirements.txt
python main.py
```

Open:

```text
http://127.0.0.1:8000/docs
```

## Main endpoints

```text
GET  /health
GET  /strategy/status
POST /strategy/nifty-opening-range/fetch
POST /strategy/subscription/refresh
POST /strategy/option-opening-ranges/fetch
GET  /strategy/touch-events
GET  /strategy/signals
POST /strategy/streamer/restart
GET  /debug/cache
GET  /debug/strategy-memory
```

## Workflow

```text
09:17 AM
    -> fetch NIFTY intraday candle
    -> calculate NIFTY OR average and levels
    -> build avg +/- 500 strike range
    -> fetch nearest expiry options
    -> subscribe CE/PE within range
    -> calculate option OR levels
    -> monitor live touches and EMA confirmations
```
