from collections import deque
from datetime import datetime
from threading import Lock
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
from core import config
from core.logger import get_logger

logger = get_logger(__file__)

class LiveEMAService:
    def __init__(self):
        self.enabled = config.LIVE_EMA_ENABLED
        self.fast_period = config.LIVE_EMA_FAST_PERIOD
        self.slow_period = config.LIVE_EMA_SLOW_PERIOD
        self.interval_minutes = config.LIVE_EMA_INTERVAL_MINUTES
        self.state = {}
        self.events = deque(maxlen=5000)
        self._lock = Lock()
        self.tz = self._load_tz()

    def _load_tz(self):
        try:
            return ZoneInfo(config.MARKET_TIMEZONE)
        except ZoneInfoNotFoundError:
            return ZoneInfo("Asia/Kolkata")

    def _now(self):
        return datetime.now(self.tz).isoformat()

    def _safe_float(self, value, default=0.0):
        try:
            return float(value)
        except Exception:
            return default

    def initialize_instrument(self, instrument_key: str, close_price: float, contract_info=None):
        close_price = self._safe_float(close_price)
        with self._lock:
            if instrument_key not in self.state:
                self.state[instrument_key] = {
                    "instrument_key": instrument_key,
                    "previous_ema_fast": close_price,
                    "previous_ema_slow": close_price,
                    "previous_signal": "neutral",
                    "last_processed_candle_ts": None,
                    "pending_live_candle": None,
                    "pending_live_candle_ts": None,
                    "last_provisional_cross_key": None,
                    "contract_info": contract_info or {},
                    "updated_at": self._now(),
                }

    def _get_feed_container(self, tick_data):
        full_feed = tick_data.get("fullFeed", tick_data) if isinstance(tick_data, dict) else {}
        ff_wrapper = full_feed.get("ff", full_feed)
        return ff_wrapper.get("marketFF") or ff_wrapper.get("indexFF") or full_feed.get("marketFF") or full_feed.get("indexFF") or ff_wrapper or {}

    def _find_i1_candle(self, tick_data):
        ff = self._get_feed_container(tick_data)
        ohlc = []
        if isinstance(ff, dict):
            ohlc = ff.get("marketOHLC", {}).get("ohlc", []) or ff.get("optionOHLC", {}).get("ohlc", []) or []
        candles = [x for x in ohlc if str(x.get("interval", "")).upper() == "I1" and x.get("ts")]
        if not candles:
            return None
        try:
            raw = max(candles, key=lambda x: int(x.get("ts")))
            ts_ms = int(raw.get("ts"))
            return {
                "timestamp": datetime.fromtimestamp(ts_ms / 1000, tz=self.tz).isoformat(),
                "timestamp_ms": ts_ms,
                "open": self._safe_float(raw.get("open")),
                "high": self._safe_float(raw.get("high")),
                "low": self._safe_float(raw.get("low")),
                "close": self._safe_float(raw.get("close")),
                "volume": int(self._safe_float(raw.get("volume") or raw.get("vol"))),
            }
        except Exception:
            return None

    def _next_ema(self, price, prev, period):
        multiplier = 2 / (period + 1)
        return round(price * multiplier + prev * (1 - multiplier), 4)

    def _signal(self, fast, slow):
        if fast > slow:
            return "bullish"
        if fast < slow:
            return "bearish"
        return "neutral"

    def _cross(self, prev_fast, prev_slow, fast, slow):
        if prev_fast <= prev_slow and fast > slow:
            return "bullish_cross"
        if prev_fast >= prev_slow and fast < slow:
            return "bearish_cross"
        return None

    def _accept_and_get_completed(self, state, candle):
        ts = candle.get("timestamp")
        pending_ts = state.get("pending_live_candle_ts")
        pending = state.get("pending_live_candle")
        if pending_ts is None:
            state["pending_live_candle"] = candle
            state["pending_live_candle_ts"] = ts
            return None
        if pending_ts == ts:
            state["pending_live_candle"] = candle
            return None
        state["pending_live_candle"] = candle
        state["pending_live_candle_ts"] = ts
        return pending

    def _calculate_event(self, instrument_key, state, candle, status):
        close = self._safe_float(candle.get("close"))
        if close <= 0:
            return None
        prev_fast = self._safe_float(state.get("previous_ema_fast"))
        prev_slow = self._safe_float(state.get("previous_ema_slow"))
        fast = self._next_ema(close, prev_fast, self.fast_period)
        slow = self._next_ema(close, prev_slow, self.slow_period)
        cross = self._cross(prev_fast, prev_slow, fast, slow)
        current_signal = self._signal(fast, slow)

        if status == "confirmed":
            if state.get("last_processed_candle_ts") == candle.get("timestamp"):
                return None
            state["previous_ema_fast"] = fast
            state["previous_ema_slow"] = slow
            state["previous_signal"] = current_signal
            state["last_processed_candle_ts"] = candle.get("timestamp")
            state["last_provisional_cross_key"] = None
        elif status == "provisional":
            key = f"{instrument_key}|{candle.get('timestamp')}|{cross}|{current_signal}"
            if config.LIVE_EMA_PROVISIONAL_BROADCAST_ONLY_ON_CHANGE and state.get("last_provisional_cross_key") == key:
                return None
            if cross:
                state["last_provisional_cross_key"] = key

        if not cross:
            return None
        event = {
            "type": "live_ema_cross",
            "signal_status": status,
            "instrument_key": instrument_key,
            "timestamp": candle.get("timestamp"),
            "cross_type": cross,
            "interval_minutes": self.interval_minutes,
            "close": close,
            "ema_fast_period": self.fast_period,
            "ema_slow_period": self.slow_period,
            "ema_fast": fast,
            "ema_slow": slow,
            "previous_ema_fast": prev_fast,
            "previous_ema_slow": prev_slow,
            "previous_signal": state.get("previous_signal"),
            "current_signal": current_signal,
            "source": "live_feed_in_progress_candle" if status == "provisional" else "live_feed_completed_candle",
            "is_confirmed": status == "confirmed",
            "is_provisional": status == "provisional",
            "may_repaint": status == "provisional",
            "created_at": self._now(),
            "candle": candle,
            "contract_info": state.get("contract_info", {}),
        }
        if status == "confirmed":
            self.events.append(event)
        return event

    def process_live_feed(self, instrument_key: str, tick_data: dict, contract_info=None):
        events = []
        if not self.enabled:
            return events
        candle = self._find_i1_candle(tick_data)
        if not candle:
            return events
        with self._lock:
            if instrument_key not in self.state:
                self.initialize_instrument(instrument_key, candle.get("close"), contract_info)
            state = self.state.get(instrument_key)
            if contract_info:
                state["contract_info"] = contract_info
            completed = self._accept_and_get_completed(state, candle)
            if completed and config.LIVE_EMA_CONFIRMED_ENABLED:
                ev = self._calculate_event(instrument_key, state, completed, "confirmed")
                if ev:
                    events.append(ev)
            if config.LIVE_EMA_PROVISIONAL_ENABLED:
                ev = self._calculate_event(instrument_key, state, candle, "provisional")
                if ev:
                    events.append(ev)
            state["updated_at"] = self._now()
        return events

    def get_status(self):
        with self._lock:
            return {"enabled": self.enabled, "tracked_instruments": len(self.state), "events_count": len(self.events), "signal_model": "provisional_and_confirmed"}

    def get_events(self, limit=100):
        with self._lock:
            return list(self.events)[-int(limit):]

live_ema_service = LiveEMAService()
