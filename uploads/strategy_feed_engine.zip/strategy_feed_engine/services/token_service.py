from threading import Lock
from pymongo import MongoClient
from core import config
from core.logger import get_logger

logger = get_logger(__file__)

class TokenService:
    def __init__(self):
        self._cache = {}
        self._lock = Lock()
        self._client = None
        self._collection = None
        self._connect()

    def _connect(self):
        try:
            if config.MONGO_URI and config.MONGO_DB and config.TOKENS_COLLECTION:
                self._client = MongoClient(config.MONGO_URI)
                self._collection = self._client[config.MONGO_DB][config.TOKENS_COLLECTION]
                logger.info("MongoDB token collection initialized.")
            else:
                logger.warning("MongoDB env variables are incomplete. Token refresh will not work until configured.")
        except Exception as ex:
            logger.error(f"MongoDB connection failed: {type(ex).__name__}: {ex}")

    def refresh_tokens(self):
        if self._collection is None:
            self._connect()
        if self._collection is None:
            return None
        try:
            doc = self._collection.find_one({"_id": config.TOKEN_DOCUMENT_ID})
            if doc:
                with self._lock:
                    self._cache = doc
                logger.info("Token cache refreshed successfully.")
                return doc
            logger.warning(f"Token document not found: {config.TOKEN_DOCUMENT_ID}")
        except Exception as ex:
            logger.error(f"Token refresh failed: {type(ex).__name__}: {ex}")
        return None

    def get_access_token(self):
        with self._lock:
            return self._cache.get("access_token")

    def get_token_document(self):
        with self._lock:
            return dict(self._cache)

token_service = TokenService()
