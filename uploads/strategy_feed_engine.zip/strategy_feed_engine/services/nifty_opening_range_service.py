from datetime import datetime, time as dt_time
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
import upstox_client
from upstox_client.rest import ApiException
from core import config
from core.logger import get_logger
from services.storage import save_json, load_json

logger = get_logger(__file__)

def market_tz():
    try:
        return ZoneInfo(config.MARKET_TIMEZONE)
    except ZoneInfoNotFoundError:
        return ZoneInfo("Asia/Kolkata")

def safe_float(value, default=0.0):
    try:
        return float(value)
    except Exception:
        return default

def extract_candles(resp):
    d = resp.to_dict() if hasattr(resp, "to_dict") else resp
    data = d.get("data", {}) if isinstance(d, dict) else {}
    candles = data.get("candles", []) if isinstance(data, dict) else []
    return candles if isinstance(candles, list) else []

def parse_candle(candle):
    return {
        "timestamp": candle[0],
        "open": safe_float(candle[1]),
        "high": safe_float(candle[2]),
        "low": safe_float(candle[3]),
        "close": safe_float(candle[4]),
        "volume": safe_float(candle[5]) if len(candle) > 5 else 0,
        "oi": safe_float(candle[6]) if len(candle) > 6 else 0,
    }

def calculate_levels(high: float, low: float):
    avg = (high + low) / 2
    high_avg_diff = abs(high - avg)
    low_avg_diff = abs(avg - low)
    r1 = avg + (high_avg_diff / 2)
    s1 = avg - (low_avg_diff / 2)
    r2 = high + high_avg_diff
    s2 = low - low_avg_diff
    r3 = r2 + high_avg_diff
    s3 = s2 - low_avg_diff
    return {
        "average": round(avg, 4),
        "r1": round(r1, 4), "s1": round(s1, 4),
        "r2": round(r2, 4), "s2": round(s2, 4),
        "r3": round(r3, 4), "s3": round(s3, 4),
        "sub_resistance": round(r1, 4),
        "sub_support": round(s1, 4),
        "r3_threshold": round((r2 + r3) / 2, 4),
        "s3_threshold": round((s2 + s3) / 2, 4),
    }

def fetch_intraday_candles(instrument_key: str):
    api = upstox_client.HistoryV3Api()
    resp = api.get_intra_day_candle_data(
        instrument_key,
        config.NIFTY_OR_INTRADAY_UNIT,
        config.NIFTY_OR_INTRADAY_INTERVAL,
    )
    return extract_candles(resp)

def calculate_nifty_opening_range(save_data=True):
    logger.info("Calculating NIFTY opening range.")
    try:
        raw = fetch_intraday_candles(config.MAIN_NIFTY_SECURITY)
        candles = [parse_candle(c) for c in raw if isinstance(c, list) and len(c) >= 5]
        candles = sorted(candles, key=lambda x: x["timestamp"])
        if not candles:
            return {"status": "empty", "message": "No candles returned."}
        selected = candles[:config.NIFTY_OR_CANDLE_COUNT]
        high = max(c["high"] for c in selected)
        low = min(c["low"] for c in selected)
        payload = {
            "status": "success",
            "instrument_key": config.MAIN_NIFTY_SECURITY,
            "date": datetime.now(market_tz()).date().isoformat(),
            "source": "intraday_api",
            "selected_candles_count": len(selected),
            "selected_candles": selected,
            "range": {
                "open": selected[0]["open"],
                "high": high,
                "low": low,
                "close": selected[-1]["close"],
                "average": round((high + low) / 2, 4),
            },
            "levels": calculate_levels(high, low),
            "processed_at": datetime.now(market_tz()).isoformat(),
        }
        if save_data:
            save_json(config.NIFTY_OR_OUTPUT_FILE, payload)
        return payload
    except ApiException as ex:
        return {"status": "failed", "error": getattr(ex, "body", str(ex))}
    except Exception as ex:
        logger.error(f"NIFTY OR failed: {type(ex).__name__}: {ex}")
        return {"status": "failed", "error": f"{type(ex).__name__}: {ex}"}

def get_nifty_opening_range():
    return load_json(config.NIFTY_OR_OUTPUT_FILE, default={"status": "not_available"})
