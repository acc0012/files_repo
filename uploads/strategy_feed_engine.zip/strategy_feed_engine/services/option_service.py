from datetime import datetime, date
from threading import Lock
import upstox_client
from upstox_client.rest import ApiException
from core import config
from core.logger import get_logger
from services.token_service import token_service
from services.storage import save_json

logger = get_logger(__file__)

_cache_lock = Lock()
options_cache = {
    "nearest_expiry": None,
    "contracts": [],
    "subscribed_keys": [],
    "contract_by_key": {},
    "latest_ltp_by_key": {},
}

def parse_expiry_date(value):
    if not value:
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, str):
        try:
            return datetime.strptime(value.split()[0], "%Y-%m-%d").date()
        except Exception:
            return None
    return None

def clean_contract(item: dict):
    exp = parse_expiry_date(item.get("expiry"))
    return {
        "instrument_key": item.get("instrument_key"),
        "instrument_type": item.get("instrument_type"),
        "strike_price": item.get("strike_price"),
        "expiry": exp.strftime("%Y-%m-%d") if exp else str(item.get("expiry")),
        "trading_symbol": item.get("trading_symbol"),
        "underlying_type": item.get("underlying_type"),
        "underlying_symbol": item.get("underlying_symbol"),
    }

def fetch_nifty_option_contracts(expiry_date: str | None = None):
    access_token = token_service.get_access_token()
    if not access_token:
        logger.error("No Upstox access token available.")
        return []
    cfg = upstox_client.Configuration()
    cfg.access_token = access_token
    api = upstox_client.OptionsApi(upstox_client.ApiClient(cfg))
    try:
        kwargs = {}
        if expiry_date:
            kwargs["expiry_date"] = expiry_date
        resp = api.get_option_contracts(config.MAIN_NIFTY_SECURITY, **kwargs)
        data = resp.to_dict().get("data", []) if hasattr(resp, "to_dict") else resp.get("data", [])
        return [clean_contract(x) for x in data]
    except ApiException as ex:
        logger.error(f"Options API failed: {getattr(ex, 'body', str(ex))}")
    except Exception as ex:
        logger.error(f"Options fetch failed: {type(ex).__name__}: {ex}")
    return []

def filter_nearest_expiry_contracts(contracts: list):
    today = datetime.now().date()
    valid_dates = [parse_expiry_date(c.get("expiry")) for c in contracts]
    valid_dates = [d for d in valid_dates if d and d >= today]
    if not valid_dates:
        return None, []
    nearest = min(valid_dates)
    nearest_str = nearest.strftime("%Y-%m-%d")
    return nearest_str, [c for c in contracts if parse_expiry_date(c.get("expiry")) == nearest]

def update_dynamic_contracts(contracts: list, output_file=None):
    keys = [config.MAIN_NIFTY_SECURITY] + [c["instrument_key"] for c in contracts if c.get("instrument_key")]
    keys = list(dict.fromkeys(keys))
    contract_by_key = {config.MAIN_NIFTY_SECURITY: {
        "instrument_key": config.MAIN_NIFTY_SECURITY,
        "instrument_type": "INDEX",
        "strike_price": None,
        "trading_symbol": "NIFTY 50",
    }}
    for c in contracts:
        contract_by_key[c.get("instrument_key")] = c
    with _cache_lock:
        options_cache["contracts"] = list(contracts)
        options_cache["subscribed_keys"] = keys
        options_cache["contract_by_key"] = contract_by_key
    payload = {"total_contracts": len(contracts), "subscribed_keys_count": len(keys), "data": contracts}
    if output_file:
        save_json(output_file, payload)
    return payload

def get_subscribed_keys():
    with _cache_lock:
        return list(options_cache.get("subscribed_keys", []))

def get_contract_info(instrument_key: str):
    with _cache_lock:
        return dict(options_cache.get("contract_by_key", {}).get(instrument_key, {"instrument_key": instrument_key}))

def update_ltp(instrument_key: str, ltp):
    try:
        ltp = float(ltp)
    except Exception:
        return
    with _cache_lock:
        options_cache.setdefault("latest_ltp_by_key", {})[instrument_key] = ltp

def get_ltp_by_key(instrument_key: str):
    with _cache_lock:
        return options_cache.get("latest_ltp_by_key", {}).get(instrument_key)

def get_latest_ltp_for_strike(strike: float, option_type: str):
    option_type = str(option_type).upper()
    with _cache_lock:
        for key, info in options_cache.get("contract_by_key", {}).items():
            try:
                if float(info.get("strike_price")) == float(strike) and str(info.get("instrument_type")).upper() == option_type:
                    return options_cache.get("latest_ltp_by_key", {}).get(key), key, dict(info)
            except Exception:
                continue
    return None, None, None
