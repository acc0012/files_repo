import math
from core import config
from core.logger import get_logger
from services.nifty_opening_range_service import calculate_nifty_opening_range, get_nifty_opening_range
from services.option_service import fetch_nifty_option_contracts, filter_nearest_expiry_contracts, update_dynamic_contracts
from services.storage import save_json

logger = get_logger(__file__)

def round_down_to_step(value: float, step: int):
    return math.floor(float(value) / step) * step

def round_up_to_step(value: float, step: int):
    return math.ceil(float(value) / step) * step

def build_dynamic_strike_range(avg: float):
    lower = round_down_to_step(avg - config.DYNAMIC_SUBSCRIPTION_RANGE_POINTS, config.NIFTY_STRIKE_STEP)
    upper = round_up_to_step(avg + config.DYNAMIC_SUBSCRIPTION_RANGE_POINTS, config.NIFTY_STRIKE_STEP)
    lower = max(float(lower), float(config.MIN_AVAILABLE_STRIKE))
    upper = min(float(upper), float(config.MAX_AVAILABLE_STRIKE))
    return lower, upper

def refresh_dynamic_subscription():
    or_payload = get_nifty_opening_range()
    if or_payload.get("status") != "success":
        or_payload = calculate_nifty_opening_range(save_data=True)
    if or_payload.get("status") != "success":
        return {"status": "failed", "reason": "nifty_opening_range_unavailable", "opening_range": or_payload}

    avg = float(or_payload.get("range", {}).get("average") or or_payload.get("levels", {}).get("average"))
    strike_from, strike_to = build_dynamic_strike_range(avg)

    all_contracts = fetch_nifty_option_contracts()
    nearest_expiry, nearest_contracts = filter_nearest_expiry_contracts(all_contracts)
    selected = []
    for c in nearest_contracts:
        try:
            strike = float(c.get("strike_price"))
            itype = str(c.get("instrument_type", "")).upper()
            if strike_from <= strike <= strike_to and itype in ["CE", "PE"]:
                selected.append(c)
        except Exception:
            continue

    update_payload = update_dynamic_contracts(selected, output_file=None)
    payload = {
        "status": "success",
        "center_source": config.DYNAMIC_SUBSCRIPTION_CENTER,
        "nifty_or_average": avg,
        "strike_from": strike_from,
        "strike_to": strike_to,
        "nearest_expiry": nearest_expiry,
        "total_contracts": len(selected),
        "subscribed_keys_count": update_payload.get("subscribed_keys_count"),
        "data": selected,
    }
    save_json(config.DYNAMIC_SUBSCRIPTION_OUTPUT_FILE, payload)
    logger.info(f"Dynamic subscription built: {strike_from}-{strike_to}, contracts={len(selected)}")
    return payload

def get_dynamic_subscription_status():
    from services.storage import load_json
    return load_json(config.DYNAMIC_SUBSCRIPTION_OUTPUT_FILE, default={"status": "not_available"})
