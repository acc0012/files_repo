import asyncio
import json
from datetime import datetime
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
import upstox_client
from core import config
from core.logger import get_logger
from services.token_service import token_service
from services.option_service import get_subscribed_keys, get_contract_info, update_ltp
from services.live_ema_service import live_ema_service
from services.strategy_signal_service import strategy_signal_service

logger = get_logger(__file__)

class UpstoxWebSocketService:
    def __init__(self):
        self.is_running = False
        self.streamer = None
        self.task = None
        self.loop = None
        self.message_count = 0
        self.feed_count = 0
        self.ema_events_count = 0
        self.strategy_signals_count = 0
        self.touch_events_count = 0
        self.tz = self._load_tz()

    def _load_tz(self):
        try:
            return ZoneInfo(config.MARKET_TIMEZONE)
        except ZoneInfoNotFoundError:
            return ZoneInfo("Asia/Kolkata")

    def _now(self):
        return datetime.now(self.tz).strftime(config.MARKET_TIME_FORMAT)

    async def start(self):
        if self.is_running:
            return
        self.is_running = True
        self.loop = asyncio.get_running_loop()
        self.task = asyncio.create_task(self._run_loop())

    async def stop(self):
        self.is_running = False
        if self.streamer:
            try:
                self.streamer.disconnect()
            except Exception:
                pass
            self.streamer = None
        if self.task:
            self.task.cancel()
            try:
                await self.task
            except Exception:
                pass
            self.task = None

    async def restart(self):
        await self.stop()
        await asyncio.sleep(2)
        await self.start()

    async def _run_loop(self):
        while self.is_running:
            token = token_service.get_access_token()
            if not token:
                logger.warning("No access token. Retrying in 10 seconds.")
                await asyncio.sleep(10)
                continue
            keys = get_subscribed_keys()
            if not keys:
                logger.warning("No subscribed keys. Retrying in 10 seconds.")
                await asyncio.sleep(10)
                continue
            try:
                cfg = upstox_client.Configuration()
                cfg.access_token = token
                api_client = upstox_client.ApiClient(cfg)
                self.streamer = upstox_client.MarketDataStreamerV3(api_client, keys, config.WEBSOCKET_FEED_MODE)

                def on_open():
                    logger.info(f"Connected to Upstox streamer with {len(keys)} keys.")

                def on_message(message):
                    self.message_count += 1
                    if self.loop and self.loop.is_running():
                        asyncio.run_coroutine_threadsafe(self._process_message(message), self.loop)

                def on_error(error):
                    logger.error(f"Upstox websocket error: {error}")

                def on_close(code, msg):
                    logger.warning(f"Upstox websocket closed: {code} {msg}")

                self.streamer.on("open", on_open)
                self.streamer.on("message", on_message)
                self.streamer.on("error", on_error)
                self.streamer.on("close", on_close)
                await asyncio.to_thread(self.streamer.connect)
                while self.is_running:
                    await asyncio.sleep(30)
            except asyncio.CancelledError:
                break
            except Exception as ex:
                logger.error(f"Streamer loop failed: {type(ex).__name__}: {ex}. Retrying.")
                await asyncio.sleep(5)

    def _safe_float(self, value, default=0.0):
        try:
            return float(value)
        except Exception:
            return default

    def _build_live_payload(self, key, tick_data, info):
        full = tick_data.get("fullFeed", tick_data) if isinstance(tick_data, dict) else {}
        ffw = full.get("ff", full)
        ff = ffw.get("marketFF") or ffw.get("indexFF") or full.get("marketFF") or full.get("indexFF") or ffw or {}
        ltpc = ff.get("ltpc", {}) if isinstance(ff, dict) else {}
        ltp = self._safe_float(ltpc.get("ltp"))
        if "marketOHLC" in ff:
            ohlc = ff.get("marketOHLC", {}).get("ohlc", [])
        else:
            ohlc = ff.get("optionOHLC", {}).get("ohlc", []) if isinstance(ff, dict) else []
        daily = next((x for x in ohlc if x.get("interval") == "1d"), {})
        payload = {
            "type": "live_tick",
            "instrument_key": key,
            "ltp": ltp,
            "high": self._safe_float(daily.get("high")) or ltp,
            "low": self._safe_float(daily.get("low")) or ltp,
            "close": self._safe_float(ltpc.get("cp")),
            "info": info or {},
            "received_at": datetime.now(self.tz).isoformat(),
        }
        update_ltp(key, ltp)
        return payload

    async def _process_message(self, message):
        try:
            if isinstance(message, bytes):
                msg = json.loads(message.decode("utf-8"))
            elif isinstance(message, str):
                msg = json.loads(message)
            else:
                msg = message
            feeds = msg.get("feeds", {}) if isinstance(msg, dict) else {}
            if not isinstance(feeds, dict):
                return
            self.feed_count += len(feeds)
            for key, tick in feeds.items():
                info = get_contract_info(key)
                live_payload = self._build_live_payload(key, tick, info)
                touches = strategy_signal_service.process_tick_for_touch(key, live_payload, info)
                self.touch_events_count += len(touches)
                ema_events = live_ema_service.process_live_feed(key, tick, info)
                for event in ema_events:
                    self.ema_events_count += 1
                    signal = strategy_signal_service.process_ema_event(event)
                    if signal:
                        self.strategy_signals_count += 1
        except Exception as ex:
            logger.error(f"Process websocket message failed: {type(ex).__name__}: {ex}")

    def get_status(self):
        return {
            "is_running": self.is_running,
            "message_count": self.message_count,
            "feed_count": self.feed_count,
            "ema_events_count": self.ema_events_count,
            "touch_events_count": self.touch_events_count,
            "strategy_signals_count": self.strategy_signals_count,
            "market_time": self._now(),
        }

upstox_ws_service = UpstoxWebSocketService()
