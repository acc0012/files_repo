from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
import time
from core import config
from core.logger import get_logger
from services.option_service import get_subscribed_keys, get_contract_info
from services.nifty_opening_range_service import fetch_intraday_candles, parse_candle, calculate_levels
from services.storage import save_json

logger = get_logger(__file__)

def _tz():
    try:
        return ZoneInfo(config.MARKET_TIMEZONE)
    except ZoneInfoNotFoundError:
        return ZoneInfo("Asia/Kolkata")

def calculate_option_opening_range_for_key(instrument_key: str):
    info = get_contract_info(instrument_key)
    if str(info.get("instrument_type", "")).upper() not in ["CE", "PE"]:
        return None
    raw = fetch_intraday_candles(instrument_key)
    candles = [parse_candle(c) for c in raw if isinstance(c, list) and len(c) >= 5]
    candles = sorted(candles, key=lambda x: x["timestamp"])
    if not candles:
        return {"instrument_key": instrument_key, "status": "empty", "contract_info": info}
    selected = candles[:config.OPTION_OR_CANDLE_COUNT]
    high = max(c["high"] for c in selected)
    low = min(c["low"] for c in selected)
    levels = calculate_levels(high, low)
    return {
        "instrument_key": instrument_key,
        "status": "success",
        "contract_info": info,
        "range": {
            "open": selected[0]["open"],
            "high": high,
            "low": low,
            "close": selected[-1]["close"],
            "average": levels.get("average"),
        },
        "levels": levels,
        "selected_candles": selected,
        "processed_at": datetime.now(_tz()).isoformat(),
    }

def calculate_option_opening_ranges(save_data=True, max_workers=None):
    keys = get_subscribed_keys()
    max_workers = int(max_workers or config.OPTION_OR_FETCH_MAX_WORKERS)
    results = {}
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = {ex.submit(calculate_option_opening_range_for_key, k): k for k in keys}
        for fut in as_completed(futures):
            key = futures[fut]
            try:
                result = fut.result()
                if result:
                    results[key] = result
            except Exception as exc:
                results[key] = {"instrument_key": key, "status": "failed", "error": f"{type(exc).__name__}: {exc}"}
            time.sleep(0.05)
    payload = {"status": "success", "total": len(results), "results": results, "processed_at": datetime.now(_tz()).isoformat()}
    if save_data:
        save_json(config.OPTION_OR_OUTPUT_FILE, payload)
    from services.strategy_signal_service import strategy_signal_service
    strategy_signal_service.load_option_opening_range_levels()
    return payload
