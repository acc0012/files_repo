import json
from pathlib import Path
from threading import Lock
from typing import Any

_storage_lock = Lock()

def save_json(path: str, payload: Any):
    file_path = Path(path)
    file_path.parent.mkdir(parents=True, exist_ok=True)
    with _storage_lock:
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=4, default=str)
    return str(file_path)

def load_json(path: str, default=None):
    file_path = Path(path)
    if not file_path.exists():
        return default
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default
