import html
from datetime import datetime
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
import requests
from core import config
from core.logger import get_logger

logger = get_logger(__file__)

class TelegramService:
    def __init__(self):
        self.enabled = bool(config.TELEGRAM_ENABLED)
        self.bot_token = config.TELEGRAM_BOT_TOKEN
        self.chat_id = config.TELEGRAM_CHAT_ID
        self.timeout = int(config.TELEGRAM_TIMEOUT_SECONDS)
        self.api_url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage" if self.bot_token else None
        self.tz = self._load_tz()

    def _load_tz(self):
        try:
            return ZoneInfo(config.MARKET_TIMEZONE)
        except ZoneInfoNotFoundError:
            return ZoneInfo("Asia/Kolkata")

    def is_configured(self):
        return bool(self.enabled and self.bot_token and self.chat_id and self.api_url)

    def _escape(self, value):
        return html.escape(str(value), quote=False)

    def send_message(self, title: str, message: str, level: str = "INFO"):
        if not self.is_configured():
            logger.warning("Telegram skipped: disabled or missing token/chat id.")
            return False
        now = datetime.now(self.tz).strftime(config.MARKET_TIME_FORMAT)
        payload_text = (
            f"<b>{self._escape(title)}</b>

"
            f"{self._escape(message)}

"
            f"<b>Level:</b> {self._escape(level)}
"
            f"<b>Time:</b> {self._escape(now)}"
        )
        try:
            resp = requests.post(self.api_url, json={
                "chat_id": self.chat_id,
                "text": payload_text,
                "parse_mode": "HTML",
                "disable_web_page_preview": True,
            }, timeout=self.timeout)
            if resp.status_code != 200:
                logger.error(f"Telegram failed: {resp.status_code} {resp.text}")
                return False
            return True
        except Exception as ex:
            logger.error(f"Telegram exception: {type(ex).__name__}: {ex}")
            return False

    def send_strategy_signal(self, signal: dict):
        if not getattr(config, "STRATEGY_TELEGRAM_ENABLED", True):
            return False
        trigger = signal.get("trigger", {})
        market = signal.get("market", {})
        candidates = signal.get("opposite_side_candidates", [])
        lines = [
            "Strategy signal observation generated.",
            "This is not an automated trade instruction.",
            "",
            f"Signal Type: {signal.get('signal_type')}",
            f"Market Bias: {signal.get('market_bias')}",
            f"NIFTY LTP: {market.get('nifty_ltp')}",
            "",
            "Touched Instrument:",
            f"Symbol: {trigger.get('trading_symbol')}",
            f"Strike: {trigger.get('strike')}",
            f"Option Type: {trigger.get('option_type')}",
            f"Touched Level: {trigger.get('touched_level')}",
            f"Touch Time: {trigger.get('touch_time')}",
            f"EMA Cross: {trigger.get('ema_cross_type')}",
            f"EMA Time: {trigger.get('ema_cross_time')}",
            "",
            "Candidate instruments for review:",
        ]
        for idx, item in enumerate(candidates, start=1):
            lines.append(f"{idx}. {item.get('strike')} {item.get('option_type')} | LTP: {item.get('ltp')}")
        lines.append("")
        lines.append("Review risk, liquidity, spread, and your own trade plan before acting.")
        return self.send_message("EMA + OR Strategy Observation", "
".join(lines), level="STRATEGY")

telegram_service = TelegramService()
