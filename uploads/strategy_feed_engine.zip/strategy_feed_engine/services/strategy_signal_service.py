from datetime import datetime, timedelta
from threading import Lock
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
from core import config
from core.logger import get_logger
from services.storage import save_json, load_json
from services.option_service import get_latest_ltp_for_strike, get_contract_info, get_ltp_by_key
from services.telegram_service import telegram_service

logger = get_logger(__file__)

class StrategySignalService:
    def __init__(self):
        self._lock = Lock()
        self.touch_events = load_json(config.STRATEGY_TOUCH_EVENTS_OUTPUT_FILE, default=[] ) or []
        self.signals = load_json(config.STRATEGY_SIGNALS_OUTPUT_FILE, default=[] ) or []
        self.option_or_levels = {}
        self.tz = self._load_tz()

    def _load_tz(self):
        try:
            return ZoneInfo(config.MARKET_TIMEZONE)
        except ZoneInfoNotFoundError:
            return ZoneInfo("Asia/Kolkata")

    def _now(self):
        return datetime.now(self.tz).isoformat()

    def load_option_opening_range_levels(self):
        payload = load_json(config.OPTION_OR_OUTPUT_FILE, default={}) or {}
        data = payload.get("results", payload if isinstance(payload, dict) else {})
        with self._lock:
            self.option_or_levels = data
        return data

    def _safe_float(self, value, default=0.0):
        try:
            return float(value)
        except Exception:
            return default

    def process_tick_for_touch(self, instrument_key: str, live_payload: dict, contract_info: dict | None = None):
        with self._lock:
            levels_payload = self.option_or_levels.get(instrument_key)
        if not levels_payload:
            return []
        levels = levels_payload.get("levels", {})
        info = contract_info or get_contract_info(instrument_key)
        itype = str(info.get("instrument_type", "")).upper()
        if itype not in ["CE", "PE"]:
            return []
        price_high = self._safe_float(live_payload.get("high") or live_payload.get("ltp"))
        price_low = self._safe_float(live_payload.get("low") or live_payload.get("ltp"))
        ltp = self._safe_float(live_payload.get("ltp"))
        triggered = []
        for level_name in config.STRATEGY_TOUCH_LEVELS:
            lv = self._safe_float(levels.get(level_name.lower()) or levels.get(level_name))
            if lv <= 0:
                continue
            touched = False
            trigger_price = ltp
            if level_name == "R3":
                touched = price_high >= lv
                trigger_price = price_high
            elif level_name == "S3":
                touched = price_low <= lv
                trigger_price = price_low
            if not touched:
                continue
            alert_key = f"{instrument_key}_{level_name}"
            with self._lock:
                if any(e.get("alert_key") == alert_key for e in self.touch_events):
                    continue
                event = {
                    "event_type": "or_touch",
                    "alert_key": alert_key,
                    "instrument_key": instrument_key,
                    "strike": info.get("strike_price"),
                    "option_type": itype,
                    "trading_symbol": info.get("trading_symbol"),
                    "level": level_name,
                    "level_value": lv,
                    "trigger_price": trigger_price,
                    "touch_time": self._now(),
                    "nifty_ltp_at_touch": get_ltp_by_key(config.MAIN_NIFTY_SECURITY),
                    "status": "waiting_for_ema_confirmation",
                }
                self.touch_events.append(event)
                save_json(config.STRATEGY_TOUCH_EVENTS_OUTPUT_FILE, self.touch_events)
                triggered.append(event)
        return triggered

    def _rule_key(self, option_type, level, cross_type):
        if cross_type != "bearish_cross":
            return None
        return f"{option_type}_{level}_THEN_BEARISH_EMA"

    def _candidate_strikes(self, touched_strike, nifty_ltp, side):
        step = config.STRATEGY_OPPOSITE_SIDE_STRIKE_STEP
        count = config.STRATEGY_OPPOSITE_SIDE_CANDIDATE_COUNT
        touched = self._safe_float(touched_strike)
        nifty = self._safe_float(nifty_ltp)
        if nifty <= 0:
            nifty = touched
        offset = abs(nifty - touched)
        center = nifty + offset if side == "CE" else nifty - offset
        rounded = round(center / step) * step
        half = count // 2
        strikes = []
        for i in range(-half, half + 1):
            strikes.append(float(rounded + i * step))
        strikes = [s for s in strikes if config.MIN_AVAILABLE_STRIKE <= s <= config.MAX_AVAILABLE_STRIKE]
        return strikes[:count]

    def _build_candidates(self, touched_strike, side):
        nifty_ltp = get_ltp_by_key(config.MAIN_NIFTY_SECURITY)
        candidates = []
        for strike in self._candidate_strikes(touched_strike, nifty_ltp, side):
            ltp, key, info = get_latest_ltp_for_strike(strike, side)
            candidates.append({
                "strike": strike,
                "option_type": side,
                "instrument_key": key,
                "trading_symbol": (info or {}).get("trading_symbol"),
                "ltp": ltp,
            })
        return candidates

    def process_ema_event(self, ema_event: dict):
        if not ema_event or ema_event.get("signal_status", "confirmed") != "confirmed":
            return None
        instrument_key = ema_event.get("instrument_key")
        cross_type = ema_event.get("cross_type")
        with self._lock:
            pending = [e for e in self.touch_events if e.get("instrument_key") == instrument_key and e.get("status") == "waiting_for_ema_confirmation"]
        if not pending:
            return None
        touch = pending[-1]
        rule_key = self._rule_key(touch.get("option_type"), touch.get("level"), cross_type)
        if not rule_key or rule_key not in config.STRATEGY_SIGNAL_RULES:
            return None
        rule = config.STRATEGY_SIGNAL_RULES[rule_key]
        candidate_side = rule.get("candidate_side")
        candidates = self._build_candidates(touch.get("strike"), candidate_side)
        signal = {
            "event_type": "strategy_signal",
            "signal_type": rule_key,
            "signal_status": "confirmed",
            "market_bias": rule.get("market_bias"),
            "message": rule.get("message"),
            "trigger": {
                "touch_event_id": touch.get("alert_key"),
                "instrument_key": instrument_key,
                "trading_symbol": touch.get("trading_symbol"),
                "strike": touch.get("strike"),
                "option_type": touch.get("option_type"),
                "touched_level": touch.get("level"),
                "touch_time": touch.get("touch_time"),
                "ema_cross_type": cross_type,
                "ema_cross_time": ema_event.get("timestamp"),
            },
            "market": {
                "nifty_ltp": get_ltp_by_key(config.MAIN_NIFTY_SECURITY),
                "nifty_ltp_at_touch": touch.get("nifty_ltp_at_touch"),
            },
            "opposite_side_candidates": candidates,
            "disclaimer": "Strategy observation only. Not financial advice or an automated trade instruction.",
            "created_at": self._now(),
        }
        with self._lock:
            for e in self.touch_events:
                if e.get("alert_key") == touch.get("alert_key"):
                    e["status"] = "confirmed_signal_generated"
                    e["confirmed_signal_type"] = rule_key
                    e["confirmed_at"] = signal["created_at"]
            self.signals.append(signal)
            save_json(config.STRATEGY_TOUCH_EVENTS_OUTPUT_FILE, self.touch_events)
            save_json(config.STRATEGY_SIGNALS_OUTPUT_FILE, self.signals)
        telegram_service.send_strategy_signal(signal)
        return signal

    def get_status(self):
        with self._lock:
            return {"touch_events_count": len(self.touch_events), "signals_count": len(self.signals), "option_or_levels_count": len(self.option_or_levels)}

strategy_signal_service = StrategySignalService()
