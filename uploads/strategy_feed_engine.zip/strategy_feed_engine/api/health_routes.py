from datetime import datetime, timezone
from fastapi import APIRouter
from services.token_service import token_service
from services.option_service import get_subscribed_keys
from services.upstox_websocket_service import upstox_ws_service
from services.live_ema_service import live_ema_service
from services.strategy_signal_service import strategy_signal_service

router = APIRouter()

@router.get("/health")
async def health():
    has_token = bool(token_service.get_access_token())
    keys = get_subscribed_keys()
    return {
        "status": "healthy" if has_token and keys else "degraded",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "has_token": has_token,
        "subscribed_keys_count": len(keys),
        "websocket": upstox_ws_service.get_status(),
        "live_ema": live_ema_service.get_status(),
        "strategy": strategy_signal_service.get_status(),
    }
