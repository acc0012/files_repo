from fastapi import APIRouter
from services.option_service import options_cache, get_subscribed_keys
from services.strategy_signal_service import strategy_signal_service

router = APIRouter()

@router.get("/debug/cache")
async def debug_cache():
    return {
        "subscribed_keys_count": len(get_subscribed_keys()),
        "sample_keys": get_subscribed_keys()[:10],
        "contracts_count": len(options_cache.get("contracts", [])),
        "latest_ltp_sample": dict(list(options_cache.get("latest_ltp_by_key", {}).items())[:10]),
    }

@router.get("/debug/strategy-memory")
async def debug_strategy_memory():
    return {
        "status": "success",
        "strategy_status": strategy_signal_service.get_status(),
        "touch_events_sample": strategy_signal_service.touch_events[-5:],
        "signals_sample": strategy_signal_service.signals[-5:],
    }
