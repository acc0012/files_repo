from fastapi import APIRouter, HTTPException, Query
from fastapi.concurrency import run_in_threadpool
from core import config
from services.nifty_opening_range_service import calculate_nifty_opening_range, get_nifty_opening_range
from services.dynamic_subscription_service import refresh_dynamic_subscription, get_dynamic_subscription_status
from services.option_opening_range_service import calculate_option_opening_ranges
from services.strategy_signal_service import strategy_signal_service
from services.upstox_websocket_service import upstox_ws_service

router = APIRouter()

@router.get("/strategy/status")
async def strategy_status():
    return {
        "status": "success",
        "nifty_opening_range": get_nifty_opening_range(),
        "dynamic_subscription": get_dynamic_subscription_status(),
        "strategy": strategy_signal_service.get_status(),
        "websocket": upstox_ws_service.get_status(),
        "config": {
            "subscription_range_points": config.DYNAMIC_SUBSCRIPTION_RANGE_POINTS,
            "strike_step": config.NIFTY_STRIKE_STEP,
            "signal_rules": config.STRATEGY_SIGNAL_RULES,
        }
    }

@router.post("/strategy/nifty-opening-range/fetch")
async def manual_nifty_or_fetch():
    result = await run_in_threadpool(calculate_nifty_opening_range, True)
    return result

@router.post("/strategy/subscription/refresh")
async def manual_dynamic_subscription_refresh(restart_streamer: bool = Query(default=True)):
    result = await run_in_threadpool(refresh_dynamic_subscription)
    if restart_streamer and result.get("status") == "success":
        await upstox_ws_service.restart()
    return result

@router.post("/strategy/option-opening-ranges/fetch")
async def manual_option_or_fetch(max_workers: int = Query(default=None, ge=1, le=25)):
    result = await run_in_threadpool(calculate_option_opening_ranges, True, max_workers)
    return result

@router.get("/strategy/touch-events")
async def get_touch_events(limit: int = Query(default=100, ge=1, le=1000)):
    return {"status": "success", "events": strategy_signal_service.touch_events[-limit:]}

@router.get("/strategy/signals")
async def get_signals(limit: int = Query(default=100, ge=1, le=1000)):
    return {"status": "success", "signals": strategy_signal_service.signals[-limit:]}

@router.post("/strategy/streamer/restart")
async def restart_streamer():
    await upstox_ws_service.restart()
    return {"status": "success", "message": "Streamer restarted."}
