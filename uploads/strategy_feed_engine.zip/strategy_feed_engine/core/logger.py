import logging
import os

LOGS_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logs")

class LineCountRotatingHandler(logging.FileHandler):
    def __init__(self, filename, maxLines=1000, backupCount=3, encoding="utf-8"):
        super().__init__(filename, mode="a", encoding=encoding)
        self.maxLines = maxLines
        self.backupCount = backupCount
        self.line_count = self._count_existing_lines()

    def _count_existing_lines(self):
        if os.path.exists(self.baseFilename):
            try:
                with open(self.baseFilename, "r", encoding=self.encoding, errors="ignore") as f:
                    return sum(1 for _ in f)
            except Exception:
                return 0
        return 0

    def emit(self, record):
        if self.line_count >= self.maxLines:
            self.doRollover()
        super().emit(record)
        self.line_count += 1

    def doRollover(self):
        if self.stream:
            self.stream.close()
            self.stream = None
        if self.backupCount > 0:
            for i in range(self.backupCount - 1, 0, -1):
                src = f"{self.baseFilename}.{i}"
                dst = f"{self.baseFilename}.{i + 1}"
                if os.path.exists(src):
                    if os.path.exists(dst):
                        os.remove(dst)
                    os.rename(src, dst)
            dst = f"{self.baseFilename}.1"
            if os.path.exists(dst):
                os.remove(dst)
            if os.path.exists(self.baseFilename):
                os.rename(self.baseFilename, dst)
        self.stream = self._open()
        self.line_count = 0

def get_logger(filename: str, log_level=logging.INFO):
    base_name = os.path.splitext(os.path.basename(filename))[0]
    os.makedirs(LOGS_DIR, exist_ok=True)
    logger = logging.getLogger(base_name)
    logger.setLevel(log_level)
    if logger.handlers:
        return logger
    formatter = logging.Formatter("%(asctime)s [%(levelname)s] [%(name)s]: %(message)s", "%Y-%m-%d %H:%M:%S")
    console = logging.StreamHandler()
    console.setFormatter(formatter)
    logger.addHandler(console)
    file_handler = LineCountRotatingHandler(os.path.join(LOGS_DIR, f"{base_name}.log"), maxLines=1000, backupCount=3)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    return logger
