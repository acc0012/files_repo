import os
from dotenv import load_dotenv

load_dotenv()

# ============================================================
# MongoDB / Token
# ============================================================
MONGO_URI = os.getenv("MONGO_URL")
MONGO_DB = os.getenv("MONGO_DB")
TOKENS_COLLECTION = os.getenv("TOKENS_COLLECTION")
TOKEN_DOCUMENT_ID = os.getenv("TOKEN_DOCUMENT_ID", "upstox_access_token")

# ============================================================
# Market / Instruments
# ============================================================
MARKET_TIMEZONE = os.getenv("MARKET_TIMEZONE", "Asia/Kolkata")
MARKET_TIME_FORMAT = "%Y-%m-%d %H:%M:%S %Z"
MAIN_NIFTY_SECURITY = os.getenv("MAIN_NIFTY_SECURITY", "NSE_INDEX|Nifty 50")
WEBSOCKET_FEED_MODE = os.getenv("WEBSOCKET_FEED_MODE", "full")

# NIFTY option settings
NIFTY_STRIKE_STEP = int(os.getenv("NIFTY_STRIKE_STEP", "50"))
MAX_AVAILABLE_STRIKE = float(os.getenv("MAX_AVAILABLE_STRIKE", "25000"))
MIN_AVAILABLE_STRIKE = float(os.getenv("MIN_AVAILABLE_STRIKE", "20000"))

# ============================================================
# NIFTY Opening Range
# ============================================================
NIFTY_OR_ENABLED = True
NIFTY_OR_FETCH_HOUR = int(os.getenv("NIFTY_OR_FETCH_HOUR", "9"))
NIFTY_OR_FETCH_MINUTE = int(os.getenv("NIFTY_OR_FETCH_MINUTE", "17"))
NIFTY_OR_MARKET_OPEN_HOUR = int(os.getenv("NIFTY_OR_MARKET_OPEN_HOUR", "9"))
NIFTY_OR_MARKET_OPEN_MINUTE = int(os.getenv("NIFTY_OR_MARKET_OPEN_MINUTE", "15"))
NIFTY_OR_CANDLE_COUNT = int(os.getenv("NIFTY_OR_CANDLE_COUNT", "1"))
NIFTY_OR_INTRADAY_UNIT = os.getenv("NIFTY_OR_INTRADAY_UNIT", "minutes")
NIFTY_OR_INTRADAY_INTERVAL = os.getenv("NIFTY_OR_INTRADAY_INTERVAL", "1")
NIFTY_OR_OUTPUT_FILE = os.getenv("NIFTY_OR_OUTPUT_FILE", "data/nifty_opening_range.json")

# ============================================================
# Dynamic Subscription
# ============================================================
DYNAMIC_SUBSCRIPTION_ENABLED = True
DYNAMIC_SUBSCRIPTION_CENTER = "nifty_or_average"
DYNAMIC_SUBSCRIPTION_RANGE_POINTS = float(os.getenv("DYNAMIC_SUBSCRIPTION_RANGE_POINTS", "500"))
DYNAMIC_SUBSCRIPTION_OUTPUT_FILE = os.getenv("DYNAMIC_SUBSCRIPTION_OUTPUT_FILE", "data/dynamic_subscribed_contracts.json")

# ============================================================
# Option Opening Range / Touch
# ============================================================
OPTION_OR_ENABLED = True
OPTION_OR_CANDLE_COUNT = int(os.getenv("OPTION_OR_CANDLE_COUNT", "1"))
OPTION_OR_FETCH_MAX_WORKERS = int(os.getenv("OPTION_OR_FETCH_MAX_WORKERS", "8"))
OPTION_OR_OUTPUT_FILE = os.getenv("OPTION_OR_OUTPUT_FILE", "data/option_opening_range_levels.json")
STRATEGY_TOUCH_LEVELS = ["R3", "S3"]
STRATEGY_TOUCH_CHECK_MODE = os.getenv("STRATEGY_TOUCH_CHECK_MODE", "high_low")
STRATEGY_TOUCH_EVENTS_OUTPUT_FILE = os.getenv("STRATEGY_TOUCH_EVENTS_OUTPUT_FILE", "data/strategy_touch_events.json")

# ============================================================
# Live EMA
# ============================================================
LIVE_EMA_ENABLED = True
LIVE_EMA_INTERVAL_MINUTES = int(os.getenv("LIVE_EMA_INTERVAL_MINUTES", "1"))
LIVE_EMA_FAST_PERIOD = int(os.getenv("LIVE_EMA_FAST_PERIOD", "9"))
LIVE_EMA_SLOW_PERIOD = int(os.getenv("LIVE_EMA_SLOW_PERIOD", "21"))
LIVE_EMA_PROVISIONAL_ENABLED = True
LIVE_EMA_CONFIRMED_ENABLED = True
LIVE_EMA_PROVISIONAL_BROADCAST_ONLY_ON_CHANGE = True

# ============================================================
# Strategy Signal Rules
# ============================================================
STRATEGY_ENABLED = True
STRATEGY_EMA_CONFIRMATION_MAX_WAIT_MINUTES = int(os.getenv("STRATEGY_EMA_CONFIRMATION_MAX_WAIT_MINUTES", "90"))
STRATEGY_OPPOSITE_SIDE_CANDIDATE_COUNT = int(os.getenv("STRATEGY_OPPOSITE_SIDE_CANDIDATE_COUNT", "5"))
STRATEGY_OPPOSITE_SIDE_STRIKE_STEP = int(os.getenv("STRATEGY_OPPOSITE_SIDE_STRIKE_STEP", "50"))
STRATEGY_SIGNALS_OUTPUT_FILE = os.getenv("STRATEGY_SIGNALS_OUTPUT_FILE", "data/strategy_signals.json")

# IMPORTANT: Alerts are phrased as strategy observations, not trade instructions.
STRATEGY_TELEGRAM_ENABLED = True
STRATEGY_TELEGRAM_SEND_DIRECT_TRADE_ADVICE = False

# User-customizable rule mapping. Adjust to match your strategy interpretation.
STRATEGY_SIGNAL_RULES = {
    "PE_R3_THEN_BEARISH_EMA": {
        "market_bias": "custom_bearish_observation",
        "candidate_side": "CE",
        "message": "PE R3 touch followed by bearish EMA crossover.",
    },
    "PE_S3_THEN_BEARISH_EMA": {
        "market_bias": "custom_bearish_observation",
        "candidate_side": "CE",
        "message": "PE S3 touch followed by bearish EMA crossover.",
    },
    "CE_R3_THEN_BEARISH_EMA": {
        "market_bias": "custom_bearish_observation",
        "candidate_side": "PE",
        "message": "CE R3 touch followed by bearish EMA crossover.",
    },
    "CE_S3_THEN_BEARISH_EMA": {
        "market_bias": "custom_bearish_observation",
        "candidate_side": "PE",
        "message": "CE S3 touch followed by bearish EMA crossover.",
    },
}

# ============================================================
# Telegram
# ============================================================
TELEGRAM_ENABLED = os.getenv("TELEGRAM_ENABLED", "false").lower() == "true"
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")
TELEGRAM_TIMEOUT_SECONDS = int(os.getenv("TELEGRAM_TIMEOUT_SECONDS", "10"))

# ============================================================
# Scheduler
# ============================================================
TOKEN_REFRESH_INTERVAL_MINUTES = int(os.getenv("TOKEN_REFRESH_INTERVAL_MINUTES", "60"))
