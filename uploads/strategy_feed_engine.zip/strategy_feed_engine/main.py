import asyncio
from contextlib import asynccontextmanager
import uvicorn
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from core import config
from core.logger import get_logger
from services.token_service import token_service
from services.nifty_opening_range_service import calculate_nifty_opening_range
from services.dynamic_subscription_service import refresh_dynamic_subscription
from services.option_opening_range_service import calculate_option_opening_ranges
from services.upstox_websocket_service import upstox_ws_service
from services.strategy_signal_service import strategy_signal_service
from api.health_routes import router as health_router
from api.strategy_routes import router as strategy_router
from api.debug_routes import router as debug_router

logger = get_logger(__file__)

scheduler = None

def run_daily_strategy_bootstrap():
    logger.info("Daily strategy bootstrap started.")
    token_service.refresh_tokens()
    nifty_or = calculate_nifty_opening_range(save_data=True)
    if nifty_or.get("status") != "success":
        logger.error(f"NIFTY OR failed: {nifty_or}")
        return
    sub = refresh_dynamic_subscription()
    if sub.get("status") != "success":
        logger.error(f"Dynamic subscription failed: {sub}")
        return
    option_or = calculate_option_opening_ranges(save_data=True)
    logger.info(f"Daily strategy bootstrap completed. options={option_or.get('total')}")

def start_scheduler():
    global scheduler
    scheduler = BackgroundScheduler(timezone=config.MARKET_TIMEZONE)
    scheduler.add_job(
        token_service.refresh_tokens,
        trigger="interval",
        minutes=config.TOKEN_REFRESH_INTERVAL_MINUTES,
        id="token_refresh_job",
        replace_existing=True,
    )
    scheduler.add_job(
        run_daily_strategy_bootstrap,
        trigger=CronTrigger(day_of_week="mon-fri", hour=config.NIFTY_OR_FETCH_HOUR, minute=config.NIFTY_OR_FETCH_MINUTE, timezone=config.MARKET_TIMEZONE),
        id="daily_strategy_bootstrap_job",
        replace_existing=True,
    )
    scheduler.start()
    logger.info("Scheduler started.")
    return scheduler

@asynccontextmanager
async def lifespan(app: FastAPI):
    global scheduler
    logger.info("Application startup.")
    token_service.refresh_tokens()
    strategy_signal_service.load_option_opening_range_levels()
    scheduler = start_scheduler()
    await upstox_ws_service.start()
    try:
        yield
    finally:
        logger.info("Application shutdown.")
        await upstox_ws_service.stop()
        if scheduler and scheduler.running:
            scheduler.shutdown()

app = FastAPI(title="Strategy Feed Engine", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(health_router)
app.include_router(strategy_router)
app.include_router(debug_router)

@app.get("/")
async def root():
    return {
        "name": "Strategy Feed Engine",
        "status": "running",
        "note": "Strategy observations only. This project does not provide financial advice or automated trade instructions.",
        "docs": "/docs",
        "health": "/health",
    }

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")
