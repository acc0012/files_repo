// ======================================================
// GLOBAL
// ======================================================

let refreshInterval = null;
let marketFeedSocket = null;
let initialFeedLogged = false;

function getSelectedDate() {
  return document.getElementById("selectedDate").value;
}

function isTodaySelected() {
  const today = new Date().toISOString().split("T")[0];

  return getSelectedDate() === today;
}

// ======================================================
// DIAGNOSTIC METADATA OVERLAY MODAL HANDLER
// ======================================================

function showMetaPayload(title, encodedPayload) {
  try {
    const rawPayload = decodeURIComponent(encodedPayload);
    const parsedObj = JSON.parse(rawPayload);

    document.getElementById("metaModalTitle").innerText = title;
    document.getElementById("metaModalPayload").innerText = JSON.stringify(
      parsedObj,
      null,
      2,
    );

    const elementsModal = new bootstrap.Modal(
      document.getElementById("metaInfoModal"),
    );
    elementsModal.show();
  } catch (e) {
    console.error(
      "Failed unpacking technical levels metadata context window",
      e,
    );
  }
}

// ======================================================
// LOAD DASHBOARD
// ======================================================

async function loadDashboard() {
  await loadSummary();

  await loadOpeningRange();

  await loadIndexAlerts();

  await loadOptionAlerts();

  await loadUpstoxStatus();

  await loadMonitorStatus();

  document.getElementById("lastRefreshTime").innerText =
    new Date().toLocaleTimeString();
}

// ======================================================
// UPSTOX STATUS
// ======================================================

async function loadUpstoxStatus() {
  try {
    const response = await fetch("/api/upstox/status");

    const result = await response.json();

    if (!result.success) {
      return;
    }

    const data = result.data;

    const availableMargin = document.getElementById("availableMargin");

    const statusElement = document.getElementById("upstoxTokenStatus");

    if (availableMargin) {
      availableMargin.innerText = `₹ ${formatAmount(data.balance || 0)}`;
    }

    if (statusElement) {
      statusElement.innerText = data.token_valid ? "ACTIVE" : "EXPIRED";

      statusElement.className = data.token_valid
        ? "text-success fw-bold"
        : "text-danger fw-bold";
    }
  } catch (error) {
    console.error("Upstox Status Load Error", error);
  }
}

// ======================================================
// MONITOR STATUS
// ======================================================

async function loadMonitorStatus() {
  try {
    const response = await fetch("/api/upstox/monitor-status");

    const result = await response.json();

    if (!result.success) {
      return;
    }

    const data = result.data;

    const statusElement = document.getElementById("monitorStatus");

    const lastRunElement = document.getElementById("monitorLastRun");

    const lastSuccessElement = document.getElementById("monitorLastSuccess");

    const nextRunElement = document.getElementById("monitorNextRun");

    const intervalElement = document.getElementById("monitorInterval");

    if (statusElement) {
      statusElement.innerText = data.running ? "RUNNING" : "STOPPED";

      statusElement.className = data.running
        ? "fw-bold text-success"
        : "fw-bold text-danger";
    }

    if (lastRunElement) {
      lastRunElement.innerText = formatDateTime(data.last_run_at);
    }

    if (lastSuccessElement) {
      lastSuccessElement.innerText = formatDateTime(data.last_success_at);
    }

    if (nextRunElement) {
      nextRunElement.innerText = formatDateTime(data.next_run_at);
    }

    if (intervalElement) {
      intervalElement.innerText = `${data.interval_minutes} Minutes`;
    }
  } catch (error) {
    console.error("Monitor Status Load Error", error);
  }
}

// ======================================================
// SUMMARY
// ======================================================

async function loadSummary() {
  try {
    const date = getSelectedDate();

    const response = await fetch(`/api/dashboard/summary?date=${date}`);

    const result = await response.json();

    if (!result.success) {
      return;
    }

    const data = result.data;

    document.getElementById("openingRangeCount").innerText =
      data.opening_range_count;

    document.getElementById("indexSignalCount").innerText =
      data.index_signal_count;

    document.getElementById("optionSignalCount").innerText =
      data.option_signal_count;

    document.getElementById("totalAlertCount").innerText = data.total_alerts;
  } catch (error) {
    console.error("Summary Load Error", error);
  }
}

// ======================================================
// OPENING RANGE
// ======================================================

async function loadOpeningRange() {
  try {
    const date = getSelectedDate();

    const response = await fetch(`/api/dashboard/opening-range?date=${date}`);

    const result = await response.json();

    const tbody = document.getElementById("openingRangeTableBody");

    tbody.innerHTML = "";

    if (!result.success || result.data.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="18" class="text-center text-muted py-3">
            No Opening Range Alerts Found
          </td>
        </tr>
      `;

      return;
    }

    result.data.forEach((row) => {
      const or = row.opening_range || row;

      tbody.innerHTML += `
        <tr class="text-nowrap">
          <td class="fw-bold text-dark">${row.symbol ?? row.SYMBOL ?? ""}</td>
          <td>${or.HIGH ?? or.high ?? ""}</td>
          <td>${or.LOW ?? or.low ?? ""}</td>
          <td class="bg-light fw-semibold">${or.AVG ?? or.avg ?? ""}</td>
          <td>${or.SUB_RESISTANCE ?? or.sub_resistance ?? ""}</td>
          <td>${or.SUB_SUPPORT ?? or.sub_support ?? ""}</td>
          <td>${or.RESISTANCE2 ?? or.resistance2 ?? ""}</td>
          <td>${or.SUPPORT2 ?? or.support2 ?? ""}</td>
          <td class="text-primary fw-semibold">${or.RESISTANCE3 ?? or.resistance3 ?? ""}</td>
          <td class="text-danger fw-semibold">${or.SUPPORT3 ?? or.support3 ?? ""}</td>
          <td><span class="badge bg-light text-dark border font-monospace-sm">${or.RESISTANCE3_CE_STRIKE ?? or.resistance3_ce_strike ?? "-"}</span></td>
          <td><span class="badge bg-light text-dark border font-monospace-sm">${or.RESISTANCE3_PE_STRIKE ?? or.resistance3_pe_strike ?? "-"}</span></td>
          <td><span class="badge bg-light text-dark border font-monospace-sm">${or.SUPPORT3_CE_STRIKE ?? or.support3_ce_strike ?? "-"}</span></td>
          <td><span class="badge bg-light text-dark border font-monospace-sm">${or.SUPPORT3_PE_STRIKE ?? or.support3_pe_strike ?? "-"}</span></td>          
          <td class="text-muted font-monospace-sm">${formatDateTime(row.created_at)}</td>
        </tr>
      `;
    });
  } catch (error) {
    console.error("Opening Range Load Error", error);
  }
}

// ======================================================
// INDEX ALERTS
// ======================================================

async function loadIndexAlerts() {
  try {
    const date = getSelectedDate();

    const response = await fetch(`/api/dashboard/index-alerts?date=${date}`);

    const result = await response.json();

    const tbody = document.getElementById("indexAlertsTableBody");

    tbody.innerHTML = "";

    if (!result.success || result.data.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="17" class="text-center text-muted py-3">
            No Index Alerts Found
          </td>
        </tr>
      `;

      return;
    }

    result.data.forEach((row) => {
      const encodedMeta = encodeURIComponent(
        JSON.stringify(row.ema_level_info || {}),
      );
      const or = row.opening_range || {};

      tbody.innerHTML += `
  <tr class="text-nowrap">
    <td class="font-monospace-sm">${row.time ?? ""}</td>
    <td>${getAlertTypeBadge(row)}</td>

<td class="signal-message">
  ${getSignalMessage(row)}
</td>

<td>
  <small class="text-uppercase fw-bold text-secondary text-xs border rounded p-1 bg-light">
    ${row.alert_category ?? ""}
  </small>
</td>

    <td class="fw-bold text-dark">${row.symbol ?? ""}</td>

    <td class="fw-bold text-primary">${row.price ?? ""}</td>

    <td class="fw-bold text-dark">${row.live_main_ltp ?? "-"}</td>
    <td><span class="badge bg-light text-dark border font-monospace-sm">${row.live_ce_strike ?? "-"}</span></td>
    <td><span class="badge bg-light text-dark border font-monospace-sm">${row.live_pe_strike ?? "-"}</span></td>

    <td>${row.ema9 ?? ""}</td>

    <td>${row.ema21 ?? ""}</td>

    <td class="fw-bold">${row.diff ?? ""}</td>

    <td>${or.HIGH ?? or.high ?? "-"}</td>

    <td>${or.LOW ?? or.low ?? "-"}</td>

    <td>${or.AVG ?? or.avg ?? "-"}</td>

    <td>${or.RESISTANCE3 ?? or.resistance3 ?? "-"}</td>

    <td>${or.SUPPORT3 ?? or.support3 ?? "-"}</td>

    <td>
      <button
        class="btn btn-sm btn-outline-dark font-monospace-sm"
        onclick="showMetaPayload('${row.symbol ?? "INDEX"} EMA Metadata', '${encodedMeta}')"
      >
        Open Info (${Object.keys(row.ema_level_info || {}).length})
      </button>
    </td>
  </tr>
`;
    });
  } catch (error) {
    console.error("Index Alerts Load Error", error);
  }
}

// ======================================================
// OPTION ALERTS
// ======================================================

async function loadOptionAlerts() {
  try {
    const date = getSelectedDate();

    const response = await fetch(`/api/dashboard/option-alerts?date=${date}`);

    const result = await response.json();

    const tbody = document.getElementById("optionAlertsTableBody");

    tbody.innerHTML = "";

    if (!result.success || result.data.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="18" class="text-center text-muted py-3">
            No Option Alerts Found
          </td>
        </tr>
      `;

      return;
    }

    result.data.forEach((row) => {
      const encodedMeta = encodeURIComponent(
        JSON.stringify(row.ema_level_info || {}),
      );

      const or = row.option_opening_range || row.opening_range || {};

      tbody.innerHTML += `
        <tr class="text-nowrap">
          <td class="font-monospace-sm">${row.time ?? ""}</td>
          <td>${getCategoryBadge(row.alert_category)}</td>

          <td>${getAlertTypeBadge(row)}</td>

          <td class="signal-message">
            ${getSignalMessage(row)}
          </td>

          <td class="font-monospace text-dark fw-bold">
            ${row.ticker ?? ""}
          </td>
          <td class="fw-bold text-primary">${row.price ?? ""}</td>

          <td class="fw-bold text-dark">${row.live_main_ltp ?? "-"}</td>
          <td><span class="badge bg-light text-dark border font-monospace-sm">${row.live_ce_strike ?? "-"}</span></td>
          <td><span class="badge bg-light text-dark border font-monospace-sm">${row.live_pe_strike ?? "-"}</span></td>

          <td>${row.ema9 ?? ""}</td>
          <td>${row.ema21 ?? ""}</td>
          <td class="fw-bold">${row.diff ?? ""}</td>
          
          <td>${row.high ?? or.HIGH ?? or.high ?? "-"}</td>
          <td>${row.low ?? or.LOW ?? or.low ?? "-"}</td>
          <td>${row.avg ?? or.AVG ?? or.avg ?? "-"}</td>
          <td class="fw-semibold text-success">${row.resistance3 ?? or.RESISTANCE3 ?? or.resistance3 ?? "-"}</td>
          <td class="fw-semibold text-danger">${row.support3 ?? or.SUPPORT3 ?? or.support3 ?? "-"}</td>
          <td>
            <button class="btn btn-sm btn-outline-dark font-monospace-sm" onclick="showMetaPayload('${row.alert_category || "OPTION"} Info Matrix', '${encodedMeta}')">
              Open Info (${Object.keys(row.ema_level_info || {}).length})
            </button>
          </td>
        </tr>
      `;
    });
  } catch (error) {
    console.error("Option Alerts Load Error", error);
  }
}

// ======================================================
// ALERT TYPE BADGES
// ======================================================

function getAlertTypeBadge(row) {
  let direction = row.signal_direction;

  if (!direction) {
    switch (row.type) {
      case "BUY_CE":
      case "BUY_PE":
        direction = "BUY";
        break;

      case "SELL_CE":
      case "SELL_PE":
        direction = "SELL";
        break;

      default:
        direction = "";
    }
  }

  const title =
    row.signal_title ||
    {
      BUY_CE: "MARKET RISING",
      SELL_CE: "EXIT CALL POSITION",
      BUY_PE: "MARKET FALLING",
      SELL_PE: "EXIT PUT POSITION",
    }[row.type] ||
    row.type;

  const strike =
    row.recommended_strike ||
    (row.type === "BUY_CE" || row.type === "SELL_CE"
      ? `${row.live_ce_strike ?? ""} CE`
      : `${row.live_pe_strike ?? ""} PE`);

  const cssClass = direction === "BUY" ? "buy-signal" : "sell-signal";

  return `
    <div class="alert-type ${cssClass}">
      <div>${title}</div>
      <small>${strike}</small>
    </div>
  `;
}

function getSignalMessage(row) {
  if (row.signal_message) {
    return row.signal_message;
  }

  switch (row.type) {
    case "BUY_CE":
      return `Market is showing bullish momentum. Take CALL Option ${row.live_ce_strike ?? ""} CE`;

    case "SELL_CE":
      return `Bullish momentum is weakening. Exit CALL Option ${row.live_ce_strike ?? ""} CE`;

    case "BUY_PE":
      return `Market is showing bearish momentum. Take PUT Option ${row.live_pe_strike ?? ""} PE`;

    case "SELL_PE":
      return `Bearish momentum is weakening. Exit PUT Option ${row.live_pe_strike ?? ""} PE`;

    default:
      return "-";
  }
}

// ======================================================
// CATEGORY BADGES
// ======================================================

function getCategoryBadge(category) {
  if (!category) {
    return "";
  }

  let cssClass = "";

  switch (category) {
    case "R3_CE_OPTION":
      cssClass = "r3-ce";
      break;

    case "R3_PE_OPTION":
      cssClass = "r3-pe";
      break;

    case "S3_CE_OPTION":
      cssClass = "s3-ce";
      break;

    case "S3_PE_OPTION":
      cssClass = "s3-pe";
      break;

    default:
      cssClass = "bg-secondary text-white";
  }

  return `
    <span class="category-badge ${cssClass}">
      ${category}
    </span>
  `;
}

// ======================================================
// DATETIME FORMATTER
// ======================================================

function formatDateTime(dateValue) {
  if (!dateValue) {
    return "";
  }

  try {
    const dt = new Date(dateValue);

    return dt.toLocaleString();
  } catch {
    return dateValue;
  }
}

// ======================================================
// CURRENCY FORMAT
// ======================================================

function formatAmount(value) {
  try {
    return Number(value || 0).toLocaleString("en-IN", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  } catch {
    return value;
  }
}

// ======================================================
// AUTO REFRESH
// ======================================================

function startAutoRefresh() {
  if (refreshInterval) {
    clearInterval(refreshInterval);
  }

  refreshInterval = setInterval(async () => {
    if (!isTodaySelected()) {
      return;
    }

    // console.log("Dashboard Auto Refresh : ", new Date().toLocaleTimeString());

    await loadDashboard();
  }, 5000);
}

// ======================================================
// MARKET FEED WEBSOCKET
// ======================================================

function connectMarketFeedSocket() {
  try {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";

    const wsUrl = `${protocol}//${window.location.host}/ws/feed`;

    // console.log("Connecting Market Feed Socket :", wsUrl);

    marketFeedSocket = new WebSocket(wsUrl);

    marketFeedSocket.onopen = () => {
      console.log("Market Feed Socket Connected");

      const statusEl = document.getElementById("feedStatus");

      if (statusEl) {
        statusEl.innerText = "CONNECTED";

        statusEl.className = "badge bg-success";
      }
    };

    marketFeedSocket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);

        if (data.type === "heartbeat") {
          return;
        }

        if (!initialFeedLogged) {
          console.log("Initial Market Feed Payload:", data);

          initialFeedLogged = true;
        }

        updateMarketFeedUI(data);
      } catch (e) {
        console.error("Feed Parse Error", e);
      }
    };

    marketFeedSocket.onclose = () => {
      console.warn("Market Feed Socket Disconnected");

      const statusEl = document.getElementById("feedStatus");

      if (statusEl) {
        statusEl.innerText = "DISCONNECTED";

        statusEl.className = "badge bg-danger";
      }

      setTimeout(connectMarketFeedSocket, 5000);
    };

    marketFeedSocket.onerror = (error) => {
      console.error("Market Feed Socket Error", error);
    };
  } catch (error) {
    console.error("Failed Connecting Feed Socket", error);
  }
}

// ======================================================
// LIVE MARKET FEED UPDATE
// ======================================================

function updateMarketFeedUI(data) {
  // console.log("LIVE FEED :", data);

  const statusEl = document.getElementById("feedStatus");

  const securityIdEl = document.getElementById("feedSecurityId");

  const ltpEl = document.getElementById("feedLtp");

  const highEl = document.getElementById("feedHigh");

  const lowEl = document.getElementById("feedLow");

  const volumeEl = document.getElementById("feedVolume");

  if (statusEl) {
    statusEl.innerText = "CONNECTED";
    statusEl.className = "badge bg-success";
  }

  if (securityIdEl) {
    securityIdEl.innerText = data.security_id ?? "-";
  }

  if (ltpEl) {
    ltpEl.innerText = data.LTP ?? "-";
  }

  if (highEl) {
    highEl.innerText = data.high ?? "-";
  }

  if (lowEl) {
    lowEl.innerText = data.low ?? "-";
  }

  if (volumeEl) {
    volumeEl.innerText = data.volume ?? "-";
  }
}

document.addEventListener("DOMContentLoaded", async function () {
  let today = new Date().toISOString().split("T")[0];

  document.getElementById("selectedDate").value = today;

  connectMarketFeedSocket();

  await loadDashboard();

  startAutoRefresh();

  document
    .getElementById("selectedDate")
    .addEventListener("change", async function () {
      await loadDashboard();
    });
});
