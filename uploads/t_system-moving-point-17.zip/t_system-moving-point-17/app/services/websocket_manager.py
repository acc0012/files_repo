from fastapi import WebSocket

from app.logger import get_logger

logger = get_logger()

# ==========================================================
# CONNECTED CLIENTS
# ==========================================================

CONNECTED_CLIENTS = set()

# ==========================================================
# CONNECT
# ==========================================================


async def connect(
    websocket: WebSocket,
):

    await websocket.accept()

    CONNECTED_CLIENTS.add(websocket)

    logger.info(
        f"WebSocket client connected " f"total_clients={len(CONNECTED_CLIENTS)}"
    )


# ==========================================================
# DISCONNECT
# ==========================================================


async def disconnect(
    websocket: WebSocket,
):

    try:

        CONNECTED_CLIENTS.discard(websocket)

        logger.info(
            f"WebSocket client disconnected " f"total_clients={len(CONNECTED_CLIENTS)}"
        )

    except Exception:

        logger.exception("Failed disconnecting websocket client")


# ==========================================================
# BROADCAST JSON MESSAGE
# ==========================================================


async def broadcast(
    data: dict,
):

    if not CONNECTED_CLIENTS:

        return

    disconnected_clients = []

    for client in CONNECTED_CLIENTS:

        try:

            await client.send_json(data)

        except Exception:

            disconnected_clients.append(client)

    for client in disconnected_clients:

        CONNECTED_CLIENTS.discard(client)

    if disconnected_clients:

        logger.warning(
            f"Removed disconnected clients " f"count={len(disconnected_clients)}"
        )


# ==========================================================
# CLIENT COUNT
# ==========================================================


def get_client_count():

    return len(CONNECTED_CLIENTS)


# ==========================================================
# STATUS
# ==========================================================


def get_websocket_status():

    return {"connected_clients": len(CONNECTED_CLIENTS)}
