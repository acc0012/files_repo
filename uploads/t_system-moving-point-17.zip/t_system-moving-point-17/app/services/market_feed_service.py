import asyncio
import json
import threading
import time

import websocket

from app.logger import get_logger

from app.config import (
    MARKET_FEED_URL,
    MARKET_FEED_HEALTH_INTERVAL_MINUTES,
)

from app.services.websocket_manager import (
    broadcast,
)

import app.services.runtime_state as runtime_state

logger = get_logger()

# ==========================================================
# GLOBAL STATE
# ==========================================================

MARKET_FEED_STATE = {
    "connected": False,
    "started_at": None,
    "last_message_at": None,
    "last_health_log_at": None,
    "last_quote": {},
}

# ==========================================================
# MESSAGE HANDLER
# ==========================================================


def on_message(ws, message):

    try:

        data = json.loads(message)

        MARKET_FEED_STATE["last_message_at"] = time.time()

        MARKET_FEED_STATE["last_quote"] = data

        if runtime_state.MAIN_EVENT_LOOP:



            asyncio.run_coroutine_threadsafe(
                broadcast(data),
                runtime_state.MAIN_EVENT_LOOP,
            )

    except Exception:

        logger.exception("Feed message parse failed")


# ==========================================================
# CONNECTION OPEN
# ==========================================================


def on_open(ws):

    MARKET_FEED_STATE["connected"] = True

    MARKET_FEED_STATE["started_at"] = time.time()

    logger.info(f"Market feed connected : " f"{MARKET_FEED_URL}")


# ==========================================================
# CONNECTION CLOSE
# ==========================================================


def on_close(
    ws,
    close_status_code,
    close_msg,
):

    MARKET_FEED_STATE["connected"] = False

    logger.warning(
        f"Market feed disconnected " f"code={close_status_code} " f"message={close_msg}"
    )


# ==========================================================
# ERROR HANDLER
# ==========================================================


def on_error(
    ws,
    error,
):

    logger.error(f"Market feed error : {error}")


# ==========================================================
# FEED WORKER
# ==========================================================


def feed_worker():

    while True:

        try:

            logger.info(f"Connecting to Market Feed : " f"{MARKET_FEED_URL}")

            ws = websocket.WebSocketApp(
                MARKET_FEED_URL,
                on_open=on_open,
                on_message=on_message,
                on_error=on_error,
                on_close=on_close,
            )

            ws.run_forever()

        except Exception:

            logger.exception("Feed connection crashed")

        logger.warning("Reconnecting in 10 seconds...")

        time.sleep(10)


# ==========================================================
# HEALTH WORKER
# ==========================================================


def health_worker():

    while True:

        try:

            if not MARKET_FEED_STATE["connected"]:

                time.sleep(5)

                continue

            last_quote = MARKET_FEED_STATE.get(
                "last_quote",
                {},
            )

            if not last_quote:

                time.sleep(5)

                continue

            MARKET_FEED_STATE["last_health_log_at"] = time.time()

            logger.info(
                "[MARKET FEED STATUS] "
                f"security_id={last_quote.get('security_id')} "
                f"ltp={last_quote.get('LTP')} "
                f"high={last_quote.get('high')} "
                f"low={last_quote.get('low')} "
                f"volume={last_quote.get('volume')} "
                f"connected={MARKET_FEED_STATE['connected']}"
            )

        except Exception:

            logger.exception("Feed health log failed")

        time.sleep(MARKET_FEED_HEALTH_INTERVAL_MINUTES * 60)


# ==========================================================
# GET STATUS
# ==========================================================


def get_market_feed_status():

    return {
        "connected": MARKET_FEED_STATE["connected"],
        "started_at": MARKET_FEED_STATE["started_at"],
        "last_message_at": MARKET_FEED_STATE["last_message_at"],
        "last_health_log_at": MARKET_FEED_STATE["last_health_log_at"],
        "last_quote": MARKET_FEED_STATE["last_quote"],
    }


# ==========================================================
# START SERVICE
# ==========================================================


def start_market_feed():

    feed_thread = threading.Thread(
        target=feed_worker,
        daemon=True,
        name="MarketFeedWorker",
    )

    feed_thread.start()

    health_thread = threading.Thread(
        target=health_worker,
        daemon=True,
        name="MarketFeedHealthMonitor",
    )

    health_thread.start()

    logger.info("Market feed services started")
