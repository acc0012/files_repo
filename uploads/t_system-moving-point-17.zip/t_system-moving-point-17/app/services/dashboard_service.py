from datetime import datetime, timedelta

from app.logger import get_logger

from app.services.mongo_service import (
    opening_range_collection,
    index_signal_collection,
    option_signal_collection,
)

logger = get_logger()


# ============================================================
# DATE RANGE HELPER
# ============================================================


def get_date_range(date_str: str):

    start_date = datetime.strptime(date_str, "%Y-%m-%d")

    end_date = start_date + timedelta(days=1)

    return start_date, end_date


# ============================================================
# DASHBOARD SUMMARY
# ============================================================


def get_dashboard_summary(date_str: str):

    try:

        start_date, end_date = get_date_range(date_str)

        opening_range_count = opening_range_collection.count_documents(
            {"created_at": {"$gte": start_date, "$lt": end_date}}
        )

        index_signal_count = index_signal_collection.count_documents(
            {"created_at": {"$gte": start_date, "$lt": end_date}}
        )

        option_signal_count = option_signal_collection.count_documents(
            {"created_at": {"$gte": start_date, "$lt": end_date}}
        )

        return {
            "opening_range_count": opening_range_count,
            "index_signal_count": index_signal_count,
            "option_signal_count": option_signal_count,
            "total_alerts": (
                opening_range_count + index_signal_count + option_signal_count
            ),
        }

    except Exception:

        logger.exception(f"Dashboard summary failed " f"date={date_str}")

        raise


# ============================================================
# OPENING RANGE ALERTS
# ============================================================
def get_opening_range_alerts(date_str: str):

    try:

        start_date, end_date = get_date_range(date_str)

        cursor = opening_range_collection.find(
            {"created_at": {"$gte": start_date, "$lt": end_date}}
        ).sort("created_at", -1)

        results = []

        for doc in cursor:

            results.append(
                {
                    "trace_id": doc.get("trace_id"),
                    "ticker": doc.get("ticker"),
                    "symbol": doc.get("symbol"),
                    "high": doc.get("high"),
                    "low": doc.get("low"),
                    "avg": doc.get("avg"),
                    "sub_resistance": doc.get("sub_resistance"),
                    "sub_support": doc.get("sub_support"),
                    "resistance2": doc.get("resistance2"),
                    "support2": doc.get("support2"),
                    "resistance3": doc.get("resistance3"),
                    "support3": doc.get("support3"),
                    # Strike reference fields
                    "resistance3_ce_strike": doc.get("resistance3_ce_strike"),
                    "resistance3_pe_strike": doc.get("resistance3_pe_strike"),
                    "support3_ce_strike": doc.get("support3_ce_strike"),
                    "support3_pe_strike": doc.get("support3_pe_strike"),
                    # Direct Strategy Buy References
                    "buy_ce": doc.get("buy_ce"),
                    "buy_pe": doc.get("buy_pe"),
                    "created_at": doc.get("created_at"),
                }
            )

        return results

    except Exception:

        logger.exception(f"Opening range fetch failed " f"date={date_str}")

        raise


# ============================================================
# INDEX ALERTS
# ============================================================
def get_index_alerts(date_str: str):

    try:

        start_date, end_date = get_date_range(date_str)

        cursor = index_signal_collection.find(
            {"created_at": {"$gte": start_date, "$lt": end_date}}
        ).sort("created_at", -1)

        results = []

        for doc in cursor:

            results.append(
                {
                    "trace_id": doc.get("trace_id"),
                    "alert_source": doc.get("alert_source"),
                    "alert_category": doc.get("alert_category"),
                    "type": doc.get("type"),
                    # ==================================================
                    # USER FRIENDLY SIGNAL CONTEXT
                    # ==================================================
                    "signal_direction": doc.get("signal_direction"),
                    "signal_title": doc.get("signal_title"),
                    "signal_message": doc.get("signal_message"),
                    "recommended_strike": doc.get("recommended_strike"),
                    "suggested_strike": doc.get("suggested_strike"),    
                    "ticker": doc.get("ticker"),
                    "symbol": doc.get("symbol"),
                    "date": doc.get("date"),
                    "time": doc.get("time"),
                    "timeframe": doc.get("timeframe"),
                    "price": doc.get("price"),
                    "ema9": doc.get("ema9"),
                    "ema21": doc.get("ema21"),
                    "diff": doc.get("diff"),
                    # Dynamic LTP & Strike references
                    "live_main_ltp": doc.get("live_main_ltp"),
                    "live_ce_strike": doc.get("live_ce_strike"),
                    "live_pe_strike": doc.get("live_pe_strike"),
                    # Strike fields
                    "resistance3_ce_strike": doc.get("resistance3_ce_strike"),
                    "resistance3_pe_strike": doc.get("resistance3_pe_strike"),
                    "support3_ce_strike": doc.get("support3_ce_strike"),
                    "support3_pe_strike": doc.get("support3_pe_strike"),
                    "ema_level_info": doc.get(
                        "ema_level_info",
                        {},
                    ),
                    "opening_range": doc.get(
                        "opening_range",
                        {},
                    ),
                    "created_at": doc.get("created_at"),
                }
            )
        return results

    except Exception:

        logger.exception(f"Index alerts fetch failed " f"date={date_str}")

        raise


# ============================================================
# OPTION ALERTS
# ============================================================
def get_option_alerts(date_str: str):

    try:

        start_date, end_date = get_date_range(date_str)

        cursor = option_signal_collection.find(
            {"created_at": {"$gte": start_date, "$lt": end_date}}
        ).sort("created_at", -1)

        results = []

        for doc in cursor:

            oor = doc.get("option_opening_range", {})

            results.append(
                {
                    "trace_id": doc.get("trace_id"),
                    "alert_source": doc.get("alert_source"),
                    "alert_category": doc.get("alert_category"),
                    "type": doc.get("type"),
                    # ==================================================
                    # USER FRIENDLY SIGNAL CONTEXT
                    # ==================================================
                    "signal_direction": doc.get("signal_direction"),
                    "signal_title": doc.get("signal_title"),
                    "signal_message": doc.get("signal_message"),
                    "recommended_strike": doc.get("recommended_strike"),
                    "suggested_strike": doc.get("suggested_strike"),
                    "ticker": doc.get("ticker"),
                    "symbol": doc.get("symbol"),
                    "date": doc.get("date"),
                    "time": doc.get("time"),
                    "timeframe": doc.get("timeframe"),
                    "price": doc.get("price"),
                    "ema9": doc.get("ema9"),
                    "ema21": doc.get("ema21"),
                    "diff": doc.get("diff"),
                    # Dynamic LTP & Strike references
                    "live_main_ltp": doc.get("live_main_ltp"),
                    "live_ce_strike": doc.get("live_ce_strike"),
                    "live_pe_strike": doc.get("live_pe_strike"),
                    # Level mapping
                    "high": doc.get("high") or oor.get("high") or oor.get("HIGH"),
                    "low": doc.get("low") or oor.get("low") or oor.get("LOW"),
                    "avg": doc.get("avg") or oor.get("avg") or oor.get("AVG"),
                    "resistance3": doc.get("resistance3")
                    or oor.get("resistance3")
                    or oor.get("RESISTANCE3"),
                    "support3": doc.get("support3")
                    or oor.get("support3")
                    or oor.get("SUPPORT3"),
                    "ema_level_info": doc.get(
                        "ema_level_info",
                        {},
                    ),
                    "option_opening_range": oor,
                    "created_at": doc.get("created_at"),
                }
            )
        return results

    except Exception:

        logger.exception(f"Option alerts fetch failed " f"date={date_str}")

        raise
