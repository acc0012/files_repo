from app.logger import get_logger

from app.utils.datetime_helper import (
    ist_now,
)

from app.services.mongo_service import (
    index_signal_collection,
    option_signal_collection,
)

logger = get_logger()

# ==========================================================
# PROCESS SIGNAL
# ==========================================================


def process_signal(trace_id: str, payload: dict):

    try:
        source = payload.get("ALERT_SOURCE")

        logger.info(
            f"Processing Signal "
            f"trace_id={trace_id} "
            f"source={source} "
            f"type={payload.get('TYPE')} "
            f"symbol={payload.get('SYMBOL')}"
        )

        # Base document containing universally common metadata and core EMA statistics

        signal_type = payload.get("TYPE")

        live_ce_strike = payload.get("LIVE_CE_STRIKE")

        live_pe_strike = payload.get("LIVE_PE_STRIKE")
        
        suggested_strike = payload.get("SUGGESTED_STRIKE")

        signal_direction = ""

        signal_title = ""

        signal_message = ""

        recommended_strike = suggested_strike or ""

        if signal_type == "BUY_CE":

            signal_direction = "BUY"

            signal_title = "MARKET RISING"

            recommended_strike = suggested_strike or f"{live_ce_strike} CE"

            signal_message = (
                f"Market is showing bullish momentum. "
                f"Take CALL Option {recommended_strike}"
            )

        elif signal_type == "SELL_CE":

            signal_direction = "SELL"

            signal_title = "EXIT CALL POSITION"

            recommended_strike = suggested_strike or f"{live_ce_strike} CE"

            signal_message = (
                f"Bullish momentum is weakening. "
                f"Exit CALL Option {recommended_strike}"
            )

        elif signal_type == "BUY_PE":

            signal_direction = "BUY"

            signal_title = "MARKET FALLING"

            recommended_strike = suggested_strike or f"{live_pe_strike} PE"

            signal_message = (
                f"Market is showing bearish momentum. "
                f"Take PUT Option {recommended_strike}"
            )

        elif signal_type == "SELL_PE":

            signal_direction = "SELL"

            signal_title = "EXIT PUT POSITION"

            recommended_strike = suggested_strike or f"{live_pe_strike} PE"

            signal_message = (
                f"Bearish momentum is weakening. "
                f"Exit PUT Option {recommended_strike}"
            )

        doc = {
            "trace_id": trace_id,
            "alert_source": source,
            "alert_category": payload.get("ALERT_CATEGORY"),
            "type": signal_type,
            "ticker": payload.get("TICKER"),
            "symbol": payload.get("SYMBOL"),
            "date": payload.get("DATE"),
            "time": payload.get("TIME"),
            "timeframe": payload.get("TF"),
            # ==================================================
            # USER FRIENDLY SIGNAL CONTEXT
            # ==================================================
            "signal_direction": signal_direction,
            "signal_title": signal_title,
            "signal_message": signal_message,
            
            "recommended_strike": recommended_strike,
            "suggested_strike": suggested_strike,


            # ==================================================
            # CORE MARKET PRICE & TECHNICALS
            # ==================================================
            "price": float(payload.get("PRICE", 0) or 0),
            "ema9": float(payload.get("EMA9", 0) or 0),
            "ema21": float(payload.get("EMA21", 0) or 0),
            "diff": float(payload.get("DIFF", 0) or 0),
            # ==================================================
            # DYNAMIC LTP STRIKE REFERENCES
            # ==================================================
            "live_main_ltp": float(payload.get("LIVE_MAIN_LTP", 0) or 0),
            "live_ce_strike": live_ce_strike,
            "live_pe_strike": live_pe_strike,
            # ==================================================
            # HIGH LEVEL ALERT METRICS
            # ==================================================
            "high": float(payload.get("HIGH", 0) or 0),
            "low": float(payload.get("LOW", 0) or 0),
            "avg": float(payload.get("AVG", 0) or 0),
            "sub_resistance": float(payload.get("SUB_RESISTANCE", 0) or 0),
            "sub_support": float(payload.get("SUB_SUPPORT", 0) or 0),
            "resistance2": float(payload.get("RESISTANCE2", 0) or 0),
            "support2": float(payload.get("SUPPORT2", 0) or 0),
            "resistance3": float(payload.get("RESISTANCE3", 0) or 0),
            "support3": float(payload.get("SUPPORT3", 0) or 0),
            # ==================================================
            # META DATA
            # ==================================================
            "ema_level_info": payload.get("EMA_LEVEL_INFO", {}),
            "created_at": ist_now(),
        }
        # ==================================================
        # INDEX SIGNAL PROCESSING
        # ==================================================

        if source == "INDEX":

            # Save strike references for INDEX alerts

            doc["resistance3_ce_strike"] = payload.get("RESISTANCE3_CE_STRIKE")

            doc["resistance3_pe_strike"] = payload.get("RESISTANCE3_PE_STRIKE")

            doc["support3_ce_strike"] = payload.get("SUPPORT3_CE_STRIKE")

            doc["support3_pe_strike"] = payload.get("SUPPORT3_PE_STRIKE")

            # Map historical root keys or fall back to payload block structure
            opening_range_payload = payload.get("OPENING_RANGE", {})
            doc["opening_range"] = {
                "high": float(
                    opening_range_payload.get("HIGH", 0) or payload.get("HIGH", 0) or 0
                ),
                "low": float(
                    opening_range_payload.get("LOW", 0) or payload.get("LOW", 0) or 0
                ),
                "avg": float(
                    opening_range_payload.get("AVG", 0) or payload.get("AVG", 0) or 0
                ),
                "sub_resistance": float(
                    opening_range_payload.get("SUB_RESISTANCE", 0)
                    or payload.get("SUB_RESISTANCE", 0)
                    or 0
                ),
                "sub_support": float(
                    opening_range_payload.get("SUB_SUPPORT", 0)
                    or payload.get("SUB_SUPPORT", 0)
                    or 0
                ),
                "resistance2": float(
                    opening_range_payload.get("RESISTANCE2", 0)
                    or payload.get("RESISTANCE2", 0)
                    or 0
                ),
                "support2": float(
                    opening_range_payload.get("SUPPORT2", 0)
                    or payload.get("SUPPORT2", 0)
                    or 0
                ),
                "resistance3": float(
                    opening_range_payload.get("RESISTANCE3", 0)
                    or payload.get("RESISTANCE3", 0)
                    or 0
                ),
                "support3": float(
                    opening_range_payload.get("SUPPORT3", 0)
                    or payload.get("SUPPORT3", 0)
                    or 0
                ),
                "buy_ce": opening_range_payload.get("BUY_CE") or payload.get("BUY_CE"),
                "buy_pe": opening_range_payload.get("BUY_PE") or payload.get("BUY_PE"),
            }

            result = index_signal_collection.insert_one(doc)

            logger.info(
                f"Index Signal saved "
                f"trace_id={trace_id} "
                f"type={payload.get('TYPE')} "
                f"symbol={payload.get('SYMBOL')} "
                f"mongo_id={result.inserted_id}"
            )

            return result.inserted_id

        # ==================================================
        # OPTION SIGNAL PROCESSING
        # ==================================================

        elif source == "OPTION":

            option_or_payload = payload.get("OPTION_OPENING_RANGE", {})
            doc["option_opening_range"] = {
                "high": float(
                    option_or_payload.get("HIGH", 0) or payload.get("HIGH", 0) or 0
                ),
                "low": float(
                    option_or_payload.get("LOW", 0) or payload.get("LOW", 0) or 0
                ),
                "avg": float(
                    option_or_payload.get("AVG", 0) or payload.get("AVG", 0) or 0
                ),
                "sub_resistance": float(
                    option_or_payload.get("SUB_RESISTANCE", 0)
                    or payload.get("SUB_RESISTANCE", 0)
                    or 0
                ),
                "sub_support": float(
                    option_or_payload.get("SUB_SUPPORT", 0)
                    or payload.get("SUB_SUPPORT", 0)
                    or 0
                ),
                "resistance2": float(
                    option_or_payload.get("RESISTANCE2", 0)
                    or payload.get("RESISTANCE2", 0)
                    or 0
                ),
                "support2": float(
                    option_or_payload.get("SUPPORT2", 0)
                    or payload.get("SUPPORT2", 0)
                    or 0
                ),
                "resistance3": float(
                    option_or_payload.get("RESISTANCE3", 0)
                    or payload.get("RESISTANCE3", 0)
                    or 0
                ),
                "support3": float(
                    option_or_payload.get("SUPPORT3", 0)
                    or payload.get("SUPPORT3", 0)
                    or 0
                ),
            }

            result = option_signal_collection.insert_one(doc)

            logger.info(
                f"Option Signal saved "
                f"trace_id={trace_id} "
                f"type={payload.get('TYPE')} "
                f"ticker={payload.get('TICKER')} "
                f"mongo_id={result.inserted_id}"
            )

            return result.inserted_id

        # ==================================================
        # UNKNOWN SOURCE
        # ==================================================

        else:

            logger.warning(
                f"Unknown alert source " f"trace_id={trace_id} " f"source={source}"
            )

            raise ValueError(f"Unknown ALERT_SOURCE: {source}")

    except Exception:

        logger.exception(
            f"Signal processing failed "
            f"trace_id={trace_id} "
            f"source={payload.get('ALERT_SOURCE')} "
            f"type={payload.get('TYPE')}"
        )

        raise
