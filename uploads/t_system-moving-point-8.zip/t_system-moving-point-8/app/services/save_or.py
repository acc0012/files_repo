from datetime import datetime
from zoneinfo import ZoneInfo

from app.database import collection
from app.parser import parse_levels
from app.logger import logger
from concurrent.futures import ThreadPoolExecutor, as_completed

from app.config import settings

from app.services.strike_mapper import build_security_mapping

from app.services.intraday_fetcher import fetch_intraday_data

from app.services.option_subscriber import subscribe_option_marketfeed

def save_opening_range(trace_id: str, payload: dict):

    try:

        logger.info(f"[{trace_id}] SAVE_OR started")

        ist_now = datetime.now(ZoneInfo("Asia/Kolkata"))

        index_security_id = payload.get("INDEX_SECURITY_ID")

        if index_security_id is None:

            raise ValueError("INDEX_SECURITY_ID is required")

        logger.info(f"[{trace_id}] Index Security ID : " f"{index_security_id}")

        logger.info(f"[{trace_id}] Parsing levels")

        parsed = parse_levels(trace_id, payload)

        logger.info(f"[{trace_id}] Levels parsed successfully")

        logger.info(f"[{trace_id}] Building security mapping")

        security_mapping = build_security_mapping(int(index_security_id), parsed)

        logger.info(f"[{trace_id}] Security mapping built successfully")

        # ==========================================
        # OPTION SUBSCRIPTION
        # ==========================================

        logger.info(
            f"[{trace_id}] Option market subscription started"
        )

        subscription_result = subscribe_option_marketfeed(
            trace_id,
            security_mapping
        )

        logger.info(
            f"[{trace_id}] Option market subscription completed"
        )


        # ==========================================
        # MULTITHREADED INTRADAY FETCH
        # ==========================================

        logger.info(f"[{trace_id}] Fetching intraday data")

        intraday_data = {}

        futures = {}

        with ThreadPoolExecutor(max_workers=settings.WORKERS_NUM) as executor:

            for level_name, level_data in security_mapping.items():

                intraday_data[level_name] = {"strike": level_data.get("strike")}

                ce_security_id = level_data.get("ce_security_id")

                pe_security_id = level_data.get("pe_security_id")

                if ce_security_id:

                    futures[
                        executor.submit(
                            fetch_intraday_data,
                            security_id=ce_security_id,
                            exchange_segment=settings.OPTION_EXCHANGE_SEGMENT,
                            instrument_type=settings.OPTION_INSTRUMENT_TYPE,
                            from_date=payload.get("FROM_DATE"),
                            to_date=payload.get("TO_DATE"),
                        )
                    ] = (level_name, "ce_intraday")

                if pe_security_id:

                    futures[
                        executor.submit(
                            fetch_intraday_data,
                            security_id=pe_security_id,
                            exchange_segment=settings.OPTION_EXCHANGE_SEGMENT,
                            instrument_type=settings.OPTION_INSTRUMENT_TYPE,
                            from_date=payload.get("FROM_DATE"),
                            to_date=payload.get("TO_DATE"),
                        )
                    ] = (level_name, "pe_intraday")

            for future in as_completed(futures):

                level_name, field_name = futures[future]

                try:

                    result = future.result()

                    intraday_data[level_name][field_name] = result

                except Exception as e:

                    logger.exception(
                        f"[{trace_id}] "
                        f"Threaded intraday fetch failed : "
                        f"{str(e)}"
                    )

                    intraday_data[level_name][field_name] = {
                        "success": False,
                        "error": str(e),
                    }

        logger.info(f"[{trace_id}] Intraday data fetched successfully")

        # ==========================================
        # MONGO DOCUMENT
        # ==========================================

        doc = {
            "trace_id": trace_id,
            "status": "COMPLETED",
            "trade_date": ist_now.strftime("%Y-%m-%d"),
            "received_at": ist_now,
            "processed_at": datetime.now(ZoneInfo("Asia/Kolkata")),
            "index_security_id": int(index_security_id),
            "original": payload,
            "parsed": parsed,
            "security_mapping": security_mapping,
            "subscription_result": subscription_result,
            "intraday_data": intraday_data,
        }

        logger.info(f"[{trace_id}] Mongo insert started")

        result = collection.insert_one(doc)

        if not result.inserted_id:

            raise Exception("MongoDB insert failed")

        inserted_id = str(result.inserted_id)

        logger.info(f"[{trace_id}] Mongo insert completed")

        logger.info(f"[{trace_id}] Document created successfully")

        return inserted_id

    except Exception as e:

        logger.exception(f"[{trace_id}] SAVE_OR failed : " f"{str(e)}")

        raise

    finally:

        logger.info(f"[{trace_id}] SAVE_OR finished")
