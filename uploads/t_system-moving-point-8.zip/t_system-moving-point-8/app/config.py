import os

from dotenv import load_dotenv

load_dotenv()


class Settings:

    # =====================================================
    # MONGODB
    # =====================================================

    MONGO_URL = os.getenv(
        "MONGO_URL"
    )

    MONGO_DB = os.getenv(
        "MONGO_DB"
    )

    MONGO_COLLECTION = os.getenv(
        "MONGO_COLLECTION"
    )

    # =====================================================
    # OPTION CHAIN CACHE
    # =====================================================

    MONGO_OPTION_CHAIN_DB = os.getenv(
        "MONGO_OPTION_CHAIN_DB"
    )

    MONGO_OPTION_COLLECTION = os.getenv(
        "MONGO_OPTION_COLLECTION"
    )

    # =====================================================
    # EXTERNAL API
    # =====================================================

    BASE_URL = os.getenv(
        "BASE_URL"
    )

    REQUEST_TIMEOUT = int(
        os.getenv(
            "REQUEST_TIMEOUT",
            "30"
        )
    )

    # =====================================================
    # INTRADAY DEFAULTS
    # =====================================================

    OPTION_EXCHANGE_SEGMENT = os.getenv(
        "OPTION_EXCHANGE_SEGMENT",
        "NSE_FNO"
    )

    OPTION_INSTRUMENT_TYPE = os.getenv(
        "OPTION_INSTRUMENT_TYPE",
        "OPTIDX"
    )

    INDEX_EXCHANGE_SEGMENT = os.getenv(
        "INDEX_EXCHANGE_SEGMENT",
        "IDX_I"
    )

    INDEX_INSTRUMENT_TYPE = os.getenv(
        "INDEX_INSTRUMENT_TYPE",
        "INDEX"
    )

    # =====================================================
    # WEBHOOK VALIDATION
    # =====================================================

    REQUIRED_FIELDS = [

        "TYPE",

        "HIGH",

        "LOW",

        "AVG",

        "RESISTANCE2",

        "SUPPORT2",

        "RESISTANCE3",

        "SUPPORT3"
    ]
    WORKERS_NUM=3
    TEST_LOG_FILES = os.getenv(
        "TEST_LOG_FILES",
        "false"
    ).lower() == "true"

    LOG_FOLDER = os.getenv(
        "LOG_FOLDER",
        "test_logs"
    )

settings = Settings()