let socket = null;

function connectMarketSocket() {

    const protocol =
        window.location.protocol === "https:"
            ? "wss"
            : "ws";

    const wsUrl =
        `${protocol}://${window.location.host}/ws/live-market`;

    socket = new WebSocket(wsUrl);

    socket.onopen = () => {

        console.log(
            "Market websocket connected"
        );
    };

    socket.onmessage = (event) => {

        const result =
            JSON.parse(event.data);

        if (!result.success) {
            return;
        }

        result.data.forEach(item => {

            if (item.index_name === "NIFTY") {

                document.getElementById(
                    "nifty-ltp"
                ).innerText =
                    Number(item.ltp).toFixed(2);

                document.getElementById(
                    "nifty-time"
                ).innerText =
                    item.updated_at || "--";
            }

            if (item.index_name === "SENSEX") {

                document.getElementById(
                    "sensex-ltp"
                ).innerText =
                    Number(item.ltp).toFixed(2);

                document.getElementById(
                    "sensex-time"
                ).innerText =
                    item.updated_at || "--";
            }

            if (item.index_name === "INDIA-VIX") {

                document.getElementById(
                    "vix-ltp"
                ).innerText =
                    Number(item.ltp).toFixed(2);

                document.getElementById(
                    "vix-time"
                ).innerText =
                    item.updated_at || "--";
            }

        });

    };

    socket.onerror = (error) => {

        console.error(
            "Market websocket error",
            error
        );
    };

    socket.onclose = () => {

        console.log(
            "Market websocket disconnected"
        );

        setTimeout(
            connectMarketSocket,
            5000
        );
    };

}

connectMarketSocket();