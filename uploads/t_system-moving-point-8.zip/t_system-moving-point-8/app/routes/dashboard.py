from datetime import timezone, datetime, timedelta

import pytz

from pymongo import DESCENDING

from fastapi import APIRouter
from fastapi import HTTPException
from fastapi.responses import HTMLResponse

from app.database import collection
from app.logger import logger

router = APIRouter(tags=["Dashboard"])

# ==========================================================
# DASHBOARD HTML PAGE
# ==========================================================


@router.get("/", response_class=HTMLResponse)
async def dashboard_page():

    try:

        logger.info("Dashboard HTML page requested")

        with open("app/templates/dashboard.html", "r", encoding="utf-8") as file:

            html_content = file.read()

        logger.info("Dashboard HTML loaded successfully")

        return HTMLResponse(content=html_content)

    except FileNotFoundError:

        logger.exception("dashboard.html file not found")

        raise HTTPException(status_code=500, detail="Dashboard HTML file missing")

    except Exception as e:

        logger.exception(f"Dashboard HTML failed : {str(e)}")

        raise HTTPException(status_code=500, detail="Internal Server Error")

    finally:

        logger.info("Dashboard HTML request finished")


# ==========================================================
# DASHBOARD META API
# ==========================================================


@router.get("/dashboard/meta")
async def dashboard_meta():

    try:

        logger.info("Dashboard META API requested")

        ist = pytz.timezone("Asia/Kolkata")

        # ==================================================
        # TOTAL DOCUMENTS
        # ==================================================

        total_documents = collection.count_documents({})

        # ==================================================
        # DATE WISE COUNTS
        # ==================================================

        pipeline = [
            {"$group": {"_id": "$trade_date", "count": {"$sum": 1}}},
            {"$sort": {"_id": -1}},
        ]

        grouped_dates = list(collection.aggregate(pipeline))

        available_dates = []

        for item in grouped_dates:

            available_dates.append(
                {"trade_date": item.get("_id"), "documents": item.get("count", 0)}
            )

        # ==================================================
        # LATEST DOCUMENT
        # ==================================================

        latest_doc = collection.find_one({}, sort=[("received_at", DESCENDING)])

        latest_trade_date = None

        latest_received_at_ist = None

        if latest_doc:

            latest_trade_date = latest_doc.get("trade_date")

            received_at = latest_doc.get("received_at")

            if received_at:

                latest_received_at_ist = (
                    received_at.replace(tzinfo=timezone.utc)
                    .astimezone(ist)
                    .strftime("%Y-%m-%d %I:%M:%S %p")
                )

        logger.info("Dashboard META response prepared")

        return {
            "success": True,
            "total_documents": total_documents,
            "total_dates": len(available_dates),
            "latest_trade_date": latest_trade_date,
            "latest_received_at_ist": latest_received_at_ist,
            "available_dates": available_dates,
        }

    except Exception as e:

        logger.exception(f"Dashboard META API failed : {str(e)}")

        raise HTTPException(status_code=500, detail="Internal Server Error")

    finally:

        logger.info("Dashboard META API request finished")


# ==========================================================
# DASHBOARD API
# ==========================================================


@router.get("/dashboard/api")
async def dashboard_api(page: int = 1, limit: int = 10, selected_date: str = None):

    try:

        logger.info(
            f"Dashboard API requested "
            f"page={page}, "
            f"limit={limit}, "
            f"selected_date={selected_date}"
        )

        # ==================================================
        # VALIDATION
        # ==================================================

        if page < 1:

            raise HTTPException(status_code=400, detail="page must be greater than 0")

        if limit < 1 or limit > 100:

            raise HTTPException(
                status_code=400, detail="limit must be between 1 and 100"
            )

        # ==================================================
        # IST TIMEZONE
        # ==================================================

        ist = pytz.timezone("Asia/Kolkata")

        # ==================================================
        # DEFAULT TODAY DATE
        # ==================================================

        if not selected_date:

            selected_date = datetime.now(ist).strftime("%Y-%m-%d")

        logger.info(f"Using dashboard selected_date={selected_date}")

        # ==================================================
        # DATE VALIDATION
        # ==================================================

        try:

            start_date = datetime.strptime(selected_date, "%Y-%m-%d")

        except ValueError:

            raise HTTPException(
                status_code=400,
                detail=("selected_date must be " "in YYYY-MM-DD format"),
            )

        # ==================================================
        # START + END DATE
        # ==================================================

        start_date = ist.localize(start_date)

        end_date = start_date + timedelta(days=1)

        logger.info(f"Mongo date filter " f"start={start_date}, " f"end={end_date}")

        # ==================================================
        # MONGO QUERY
        # ==================================================

        query = {"received_at": {"$gte": start_date, "$lt": end_date}}

        # ==================================================
        # PAGINATION
        # ==================================================

        skip = (page - 1) * limit

        total_documents = collection.count_documents(query)

        total_pages = (
            (total_documents + limit - 1) // limit if total_documents > 0 else 1
        )

        # ==================================================
        # FETCH DOCUMENTS
        # ==================================================

        docs = list(
            collection.find(query, {"_id": 0})
            .sort("received_at", -1)
            .skip(skip)
            .limit(limit)
        )

        logger.info(f"Fetched {len(docs)} documents " f"page={page}")

        dashboard_rows = []

        bullish_count = 0

        bearish_count = 0

        # ======================================================
        # DOCUMENT LOOP
        # ======================================================

        for idx, doc in enumerate(docs, start=skip + 1):

            try:

                trace_id = doc.get("trace_id")

                trade_date = doc.get("trade_date")

                index_security_id = doc.get("index_security_id")

                intraday_data = doc.get("intraday_data", {})

                received_at = doc.get("received_at")

                processed_at = doc.get("processed_at")

                # ==================================================
                # UTC -> IST
                # ==================================================

                received_at_ist = None

                processed_at_ist = None

                if received_at:

                    received_at_ist = (
                        received_at.replace(tzinfo=timezone.utc)
                        .astimezone(ist)
                        .strftime("%Y-%m-%d %I:%M:%S %p")
                    )

                if processed_at:

                    processed_at_ist = (
                        processed_at.replace(tzinfo=timezone.utc)
                        .astimezone(ist)
                        .strftime("%Y-%m-%d %I:%M:%S %p")
                    )

                logger.info(f"[{trace_id}] " f"Processing dashboard document")

                # ==================================================
                # MAIN ROW
                # ==================================================

                row = {
                    # ==========================================
                    # COMMON INFO
                    # ==========================================
                    "serial_no": idx,
                    "trace_id": trace_id,
                    "trade_date": trade_date,
                    "received_at_ist": (received_at_ist),
                    "processed_at_ist": (processed_at_ist),
                    "index_security_id": (index_security_id),
                    # ==========================================
                    # ORIGINAL OPENING RANGE
                    # ==========================================
                    "high": (doc.get("original", {}).get("HIGH")),
                    "low": (doc.get("original", {}).get("LOW")),
                    "avg": (doc.get("original", {}).get("AVG")),
                    "r2": (doc.get("original", {}).get("RESISTANCE2")),
                    "s2": (doc.get("original", {}).get("SUPPORT2")),
                    "r3": (doc.get("original", {}).get("RESISTANCE3")),
                    "s3": (doc.get("original", {}).get("SUPPORT3")),
                }

                # ==================================================
                # LEVEL LOOP
                # ==================================================

                for level_name, level_data in intraday_data.items():

                    try:

                        ce_intraday = level_data.get("ce_intraday", {})

                        pe_intraday = level_data.get("pe_intraday", {})

                        # ======================================
                        # FIRST CANDLE
                        # ======================================

                        ce_first_candle = ce_intraday.get("first_candle", {})

                        pe_first_candle = pe_intraday.get("first_candle", {})

                        # ======================================
                        # FIRST 5 CANDLES
                        # ======================================

                        ce_first5 = ce_intraday.get("first_5_candles", {})

                        pe_first5 = pe_intraday.get("first_5_candles", {})

                        ce_avg = ce_first5.get("AVG", 0)

                        pe_avg = pe_first5.get("AVG", 0)

                        signal = "BULLISH" if ce_avg > pe_avg else "BEARISH"

                        if signal == "BULLISH":

                            bullish_count += 1

                        else:

                            bearish_count += 1

                        # ======================================
                        # LEVEL DATA
                        # ======================================

                        row[level_name] = {
                            "strike": level_data.get("strike"),
                            "ce_first_high": ce_first_candle.get("HIGH"),
                            "ce_first_low": ce_first_candle.get("LOW"),
                            "ce_first_range": ce_first_candle.get("RANGE"),
                            "ce_first_avg": ce_first_candle.get("AVG"),
                            "ce_first_r1": ce_first_candle.get("RESISTANCE1"),
                            "ce_first_s1": ce_first_candle.get("SUPPORT1"),
                            "ce_first_r2": ce_first_candle.get("RESISTANCE2"),
                            "ce_first_s2": ce_first_candle.get("SUPPORT2"),
                            "ce_first_r3": ce_first_candle.get("RESISTANCE3"),
                            "ce_first_s3": ce_first_candle.get("SUPPORT3"),
                            "pe_first_high": pe_first_candle.get("HIGH"),
                            "pe_first_low": pe_first_candle.get("LOW"),
                            "pe_first_range": pe_first_candle.get("RANGE"),
                            "pe_first_avg": pe_first_candle.get("AVG"),
                            "pe_first_r1": pe_first_candle.get("RESISTANCE1"),
                            "pe_first_s1": pe_first_candle.get("SUPPORT1"),
                            "pe_first_r2": pe_first_candle.get("RESISTANCE2"),
                            "pe_first_s2": pe_first_candle.get("SUPPORT2"),
                            "pe_first_r3": pe_first_candle.get("RESISTANCE3"),
                            "pe_first_s3": pe_first_candle.get("SUPPORT3"),
                            "ce_5_high": ce_first5.get("HIGH"),
                            "ce_5_low": ce_first5.get("LOW"),
                            "ce_5_range": ce_first5.get("RANGE"),
                            "ce_5_avg": ce_first5.get("AVG"),
                            "ce_5_r1": ce_first5.get("RESISTANCE1"),
                            "ce_5_s1": ce_first5.get("SUPPORT1"),
                            "ce_5_r2": ce_first5.get("RESISTANCE2"),
                            "ce_5_s2": ce_first5.get("SUPPORT2"),
                            "ce_5_r3": ce_first5.get("RESISTANCE3"),
                            "ce_5_s3": ce_first5.get("SUPPORT3"),
                            "pe_5_high": pe_first5.get("HIGH"),
                            "pe_5_low": pe_first5.get("LOW"),
                            "pe_5_range": pe_first5.get("RANGE"),
                            "pe_5_avg": pe_first5.get("AVG"),
                            "pe_5_r1": pe_first5.get("RESISTANCE1"),
                            "pe_5_s1": pe_first5.get("SUPPORT1"),
                            "pe_5_r2": pe_first5.get("RESISTANCE2"),
                            "pe_5_s2": pe_first5.get("SUPPORT2"),
                            "pe_5_r3": pe_first5.get("RESISTANCE3"),
                            "pe_5_s3": pe_first5.get("SUPPORT3"),
                            "signal": signal,
                        }

                        logger.info(
                            f"[{trace_id}] " f"{level_name} " f"processed successfully"
                        )

                    except Exception as e:

                        logger.exception(
                            f"[{trace_id}] "
                            f"Level processing failed "
                            f"{level_name} : "
                            f"{str(e)}"
                        )

                        row[level_name] = {"strike": None, "signal": "ERROR"}

                dashboard_rows.append(row)

                logger.info(f"[{trace_id}] " f"Dashboard row prepared successfully")

            except Exception as e:

                logger.exception(f"Document processing failed : " f"{str(e)}")

        logger.info(
            f"Dashboard API response prepared " f"documents={len(dashboard_rows)}"
        )

        return {
            "success": True,
            "selected_date": selected_date,
            "page": page,
            "limit": limit,
            "total_documents": total_documents,
            "total_pages": total_pages,
            "count": len(dashboard_rows),
            "bullish_count": bullish_count,
            "bearish_count": bearish_count,
            "data": dashboard_rows,
        }

    except HTTPException:

        raise

    except Exception as e:

        logger.exception(f"Dashboard API failed : {str(e)}")

        raise HTTPException(status_code=500, detail="Internal Server Error")

    finally:

        logger.info("Dashboard API request finished")
