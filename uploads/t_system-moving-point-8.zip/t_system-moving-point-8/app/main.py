from contextlib import asynccontextmanager
import asyncio
from datetime import datetime
from zoneinfo import ZoneInfo

from fastapi import FastAPI
from fastapi import Request
from fastapi.responses import JSONResponse

from app.routes.webhook import router as webhook_router

from app.routes.option_chain import router as option_chain_router

from app.routes.dashboard import router as dashboard_router

from app.logger import logger

from app.services.master_loader import load_option_master

# ==========================================================
# DAILY CACHE REFRESH TASK
# ==========================================================


async def daily_cache_refresh():

    logger.info("Daily cache refresh task started")

    last_refresh_date = None

    while True:

        try:

            now = datetime.now(ZoneInfo("Asia/Kolkata"))

            current_date = now.strftime("%Y-%m-%d")

            # ==========================================
            # REFRESH CACHE DAILY AT 08:55 AM IST
            # ==========================================

            if now.hour == 8 and now.minute == 55 and last_refresh_date != current_date:

                logger.info("Daily cache refresh initiated")

                count = load_option_master()

                last_refresh_date = current_date

                logger.info(
                    f"Daily cache refresh completed. " f"Loaded {count} records"
                )

        except Exception as e:

            logger.exception(f"Daily cache refresh failed : {str(e)}")

        await asyncio.sleep(60)


# ==========================================================
# APPLICATION LIFESPAN
# ==========================================================


@asynccontextmanager
async def lifespan(app: FastAPI):

    refresh_task = None

    try:

        logger.info("Application startup initiated")

        logger.info("Loading option chain cache")

        count = load_option_master()

        logger.info(
            f"Option chain cache loaded successfully. " f"Records loaded : {count}"
        )

        refresh_task = asyncio.create_task(daily_cache_refresh())

        logger.info("Background cache refresh task started")

        logger.info("Opening Range API started successfully")

        yield

    except Exception as e:

        logger.exception(f"Startup failed : {str(e)}")

        raise

    finally:

        logger.info("Application shutdown initiated")

        try:

            if refresh_task:

                refresh_task.cancel()

                try:

                    await refresh_task

                except asyncio.CancelledError:

                    logger.info("Background refresh task cancelled")

        except Exception as e:

            logger.exception(f"Shutdown cleanup failed : {str(e)}")

        logger.info("Opening Range API stopped")


# ==========================================================
# FASTAPI APP
# ==========================================================

app = FastAPI(title="Opening Range Dashboard API", version="1.0.0", lifespan=lifespan)

# ==========================================================
# GLOBAL EXCEPTION HANDLER
# ==========================================================


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):

    logger.exception(f"Unhandled exception : {str(exc)}")

    return JSONResponse(
        status_code=500, content={"status": "error", "message": "Internal Server Error"}
    )


# ==========================================================
# HEALTH CHECK ROUTE
# ==========================================================


@app.get("/health")
async def health_check():

    logger.info("Health check requested")

    return {"status": "healthy"}


# ==========================================================
# ROUTERS
# ==========================================================

# ------------------------------------------
# WEBHOOK ROUTES
# ------------------------------------------

app.include_router(webhook_router)

logger.info("Webhook routes registered successfully")

# ------------------------------------------
# OPTION CHAIN ROUTES
# ------------------------------------------

app.include_router(option_chain_router)

logger.info("Option chain routes registered successfully")

# ------------------------------------------
# DASHBOARD ROUTES
# ------------------------------------------

app.include_router(dashboard_router)

logger.info("Dashboard routes registered successfully")

# ==========================================================
# APPLICATION READY
# ==========================================================

logger.info("Application startup configuration completed")
