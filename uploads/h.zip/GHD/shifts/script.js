function extractRosterData() {
  const tables = [...document.querySelectorAll("table")];

  const employees = {};

  const VALID_SHIFTS = [
    "Morning",
    "GEN",
    "GEN 2",
    "MID",
    "Second",
    "Night",
    "BG",
  ];

  for (const table of tables) {
    const text = table.innerText || "";

    // Skip shift timing/legend tables
    if (
      text.includes("Shift Timings") ||
      (text.includes("Morning") && text.includes("6:30-3:30"))
    ) {
      continue;
    }

    const rows = [...table.querySelectorAll("tr")];

    if (!rows.length) continue;

    const headerCells = [...rows[0].querySelectorAll("td,th")].map((x) =>
      x.innerText.trim(),
    );

    const isRosterTable =
      headerCells.includes("Emp No") && headerCells.includes("Name");

    if (!isRosterTable) continue;

    for (let i = 1; i < rows.length; i++) {
      const cols = [...rows[i].querySelectorAll("td")].map((td) =>
        td.innerText.trim().replace(/\u00A0/g, " "),
      );

      if (cols.length < 4) continue;

      const empId = cols[0];
      const name = cols[1];
      const location = cols[2];

      if (!empId) continue;

      if (!employees[empId]) {
        employees[empId] = {
          empId,
          name,
          location,
          shifts: {
            Morning: 0,
            GEN: 0,
            "GEN 2": 0,
            MID: 0,
            Second: 0,
            Night: 0,
            BG: 0,
          },
        };
      }

      // Shift columns for this week/table
      const weekShifts = cols.slice(3);

      // Count each shift only once per table/week
      const uniqueShifts = [
        ...new Set(weekShifts.filter((shift) => VALID_SHIFTS.includes(shift))),
      ];

      uniqueShifts.forEach((shift) => {
        employees[empId].shifts[shift]++;
      });
    }
  }

  // Group employees by location
  const locationWise = {};

  Object.values(employees).forEach((emp) => {
    if (!locationWise[emp.location]) {
      locationWise[emp.location] = [];
    }

    locationWise[emp.location].push(emp);
  });

  return locationWise;
}

const locationWiseRoster = extractRosterData();

console.log(locationWiseRoster);
