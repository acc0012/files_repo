function startBitlockerMonitor() {
  const STORAGE_KEY = "bitlockerFilteredTickets";
  const ASSIGNED_KEY = "bitlockerAssignedTickets";
  const ASSIGNMENT_RESPONSE_KEY = "bitlockerAssignmentResponses";
  const ELIGIBILITY_KEY = "bitlockerEligibilityResults";
  const reverseOrder = false;

  const includeKeywords = [
    "bitlocker recovery",
    "bit locker recovery",
    "recovery key",
    "bitlocker key",
    "bit locker key",
    "recovery code",
    "unlock key",
    "locked out",
    "youre locked out",
    "system locked",
    "laptop locked",
    "account locked",
    "bitlocker locked",
    "need recovery key",
    "asking for recovery key",
    "require recovery key",
    "enter the recovery key",
    "bitlocker recovery key",
    "unlock my device",
    "unlock my laptop",
    "unable to login due to bitlocker",
  ];

  const excludeKeywords = [
    "outlook",
    "ultimatix",
    "setup",
    "installation",
    "booting",
    "install",
    "configure",
    "configuration",
    "config",
    "deployment",
    "enable",
    "disable",
    "policy",
    "group policy",
    "gpo",
    "repair",
    "security group",
    "aad group",
    "azure group",
    "active directory",
    "automatic repair",
    "repair mode",
    "auto repair",
    "recovery mode",
    "pin reset",
    "pin change",
    "change pin",
    "bitlocker pin changer",
    "bitlocker setup required",
    "bitlocker installation",
    "bit locker installation",
    "encryption setup",
    "bit locker not instantiated",
    "teams",
  ];
  let refreshCount = 0;
  let lastAssignedCount = JSON.parse(
    localStorage.getItem(ASSIGNED_KEY) || "[]",
  ).length;
  let baselineCaptured = false;
  let existingTicketsAtStartup = new Set();

  const audioCtx = new (window.AudioContext || window.webkitAudioContext)();

  function chatNotification() {
    function beep(delay) {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();

      osc.connect(gain);
      gain.connect(audioCtx.destination);

      osc.type = "triangle";
      osc.frequency.value = 1400;

      gain.gain.setValueAtTime(0.15, audioCtx.currentTime + delay);

      gain.gain.exponentialRampToValueAtTime(
        0.001,
        audioCtx.currentTime + delay + 0.15,
      );

      osc.start(audioCtx.currentTime + delay);
      osc.stop(audioCtx.currentTime + delay + 0.15);
    }

    beep(0);
    beep(0.2);
    beep(0.4);
  }

  function checkAssignedCountChange() {
    const currentAssignedCount = JSON.parse(
      localStorage.getItem(ASSIGNED_KEY) || "[]",
    ).length;

    if (currentAssignedCount > lastAssignedCount) {
      console.log(
        `🔔 Assigned count increased: ${lastAssignedCount} → ${currentAssignedCount}`,
      );

      chatNotification();
    }

    lastAssignedCount = currentAssignedCount;
  }

  function saveEligibilityResult(ticket, result) {
    const today = new Date().toDateString();

    let data = JSON.parse(localStorage.getItem(ELIGIBILITY_KEY) || "{}");

    if (!data.date || data.date !== today) {
      data = {
        date: today,
        tickets: {},
      };
    }

    // Save only if ticket does not already exist
    if (!data.tickets[ticket.ticketNo]) {
      data.tickets[ticket.ticketNo] = {
        ticketNo: ticket.ticketNo,
        userId: ticket.userId,
        userName: ticket.userName,
        locationName: ticket.locationName,
        userMail: ticket.userMail,
        loggedDate: ticket.loggedDate,
        agingDays: ticket.agingDays,
        status: ticket.status,
        description: ticket.description,
        eligible: result.eligible,
        reasons: result.reasons,
        excludedKeywords: result.matchedExcludedKeywords || [],
        savedAt: new Date().toLocaleString(),
      };

      localStorage.setItem(ELIGIBILITY_KEY, JSON.stringify(data));
    }
  }

  function getEligibilityResult(ticket, assignedTickets) {
    const reasons = [];

    const description = (ticket.description || "").toLowerCase();

    if (!hasBitlockerKeyword(ticket)) {
      reasons.push("Missing BitLocker keyword");
    }

    const matchedExcludedKeywords = excludeKeywords.filter((keyword) =>
      description.includes(keyword.toLowerCase()),
    );

    if (matchedExcludedKeywords.length > 0) {
      reasons.push(
        `Contains excluded keyword(s): ${matchedExcludedKeywords.join(", ")}`,
      );
    }
    if ((ticket.status || "").toLowerCase() === "reopened") {
      reasons.push("Ticket status is Reopened");
    }

    if (!hasValidUserId(ticket)) {
      reasons.push(`Invalid User ID (${ticket.userId || "blank"})`);
    }

    if (!hasShortDescription(ticket)) {
      reasons.push(
        `Description too long (${ticket.description?.length || 0} chars)`,
      );
    }

    if (isAlreadyAssigned(ticket, assignedTickets)) {
      reasons.push("Already auto-assigned");
    }

    return {
      eligible: reasons.length === 0,
      reasons,
      matchedExcludedKeywords,
    };
  }
  function saveAssignmentResponse(ticketNo, responseData) {
    const today = new Date().toDateString();

    let existingData = JSON.parse(
      localStorage.getItem(ASSIGNMENT_RESPONSE_KEY) || "{}",
    );

    if (!existingData.date || existingData.date !== today) {
      existingData = {
        date: today,
        tickets: {},
      };
    }

    existingData.tickets[ticketNo] = {
      assignedDate: new Date().toLocaleString("en-US", {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
        hour: "numeric",
        minute: "numeric",
        second: "numeric",
        hour12: true,
      }),

      response: responseData,
    };

    localStorage.setItem(ASSIGNMENT_RESPONSE_KEY, JSON.stringify(existingData));
  }

  async function assignTicket(ticketNo) {
    try {
      const response = await fetch(
        "https://nextgenghd.ultimatix.net/NextGenGHDIncidentService/rest/assignTickets",
        {
          headers: {
            accept: "application/json, text/plain, */*",
            "content-type": "application/json",
          },
          body: JSON.stringify([ticketNo]),
          method: "POST",
          credentials: "include",
        },
      );

      const rawResponse = await response.text();

      let responseData;

      try {
        responseData = JSON.parse(rawResponse);
      } catch {
        responseData = rawResponse;
      }

      saveAssignmentResponse(ticketNo, responseData);

      console.log(
        `%c✅ Assigned Ticket ${ticketNo}`,
        "color:green;font-weight:bold",
      );

      console.log("📄 Raw Assignment Response:", responseData);
      return responseData;
    } catch (error) {
      saveAssignmentResponse(ticketNo, {
        error: String(error),
      });

      console.error(`❌ Assignment Failed ${ticketNo}`, error);

      return null;
    }
  }

  function hasBitlockerKeyword(ticket) {
    const text = (ticket.description || "").toLowerCase();

    return includeKeywords.some((keyword) => text.includes(keyword));
  }

  function hasExcludedKeyword(ticket) {
    const text = (ticket.description || "").toLowerCase();

    return excludeKeywords.some((keyword) => text.includes(keyword));
  }

  function hasValidUserId(ticket) {
    const userId = String(ticket.userId || "").trim();

    return /^\d{6,}$/.test(userId);
  }

  function hasShortDescription(ticket) {
    const description = String(ticket.description || "").trim();

    return description.length <= 250;
  }

  function isAlreadyAssigned(ticket, assignedTickets) {
    return assignedTickets.has(ticket.ticketNo);
  }

  async function fetchAndFilterTickets() {
    try {
      refreshCount++;

      const refreshTime = new Date();

      console.clear();

      console.log(
        `%c🔄 Refresh #${refreshCount}`,
        "color:#2196F3;font-weight:bold;font-size:14px",
      );

      console.log("🕒 Refresh Time:", refreshTime.toLocaleString());

      const response = await fetch(
        "https://nextgenghd.ultimatix.net/NextGenGHDIncidentService/rest/getAllCommonQTickets",
        {
          headers: {
            accept: "application/json, text/plain, */*",
            "content-type": "text/plain",
          },
          body: "2854348",
          method: "POST",
          credentials: "include",
        },
      );

      const tickets = await response.json();

      if (!baselineCaptured) {
        tickets.forEach((ticket) => {
          existingTicketsAtStartup.add(ticket.ticketNo);
        });

        baselineCaptured = true;

        console.log(
          `📌 Baseline captured (${existingTicketsAtStartup.size} existing tickets)`,
        );
      }

      let savedTickets = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");

      const assignedTickets = new Set(
        JSON.parse(localStorage.getItem(ASSIGNED_KEY) || "[]"),
      );

      const today = new Date().toDateString();

      const eligibilityHistory = JSON.parse(
        localStorage.getItem(ELIGIBILITY_KEY) || "{}",
      );

      if (eligibilityHistory.date && eligibilityHistory.date !== today) {
        localStorage.removeItem(ELIGIBILITY_KEY);
        console.log("🧹 Removed previous day's eligibility history");
      }

      const assignmentHistory = JSON.parse(
        localStorage.getItem(ASSIGNMENT_RESPONSE_KEY) || "{}",
      );

      if (assignmentHistory.date && assignmentHistory.date !== today) {
        localStorage.removeItem(ASSIGNMENT_RESPONSE_KEY);
        console.log("🧹 Removed previous day's assignment history");
      }

      savedTickets = savedTickets.filter(
        (ticket) =>
          ticket.loggedDate &&
          new Date(ticket.loggedDate).toDateString() === today,
      );

      const existingTicketNos = new Set(savedTickets.map((t) => t.ticketNo));

      const bitlockerTickets = tickets
        .filter((ticket) => hasBitlockerKeyword(ticket))
        .sort((a, b) => new Date(a.loggedDate) - new Date(b.loggedDate));

      const displayTickets = reverseOrder
        ? [...bitlockerTickets].reverse()
        : bitlockerTickets;

      console.log(`🎯 BitLocker Tickets: ${displayTickets.length}`);

      let newTicketsCount = 0;
      let autoAssignedCount = 0;

      for (const [index, ticket] of displayTickets.entries()) {
        if (!existingTicketNos.has(ticket.ticketNo)) {
          savedTickets.push(ticket);
          existingTicketNos.add(ticket.ticketNo);
          newTicketsCount++;
        }

        console.group(
          `%c#${index + 1} Ticket ${ticket.ticketNo}`,
          "color:green;font-weight:bold",
        );

        console.log("🎫 Ticket:", ticket.ticketNo);
        console.log("👤 User ID:", ticket.userId);
        console.log("🙍 User:", ticket.userName);
        console.log("📍 Location:", ticket.locationName);
        console.log("📅 Logged:", ticket.loggedDate);
        console.log("⌛ Aging Days:", ticket.agingDays);
        console.log("📌 Status:", ticket.status);
        console.log("📧 Mail:", ticket.userMail);
        console.log("📝 Description:", ticket.description);

        const existedBeforeMonitorStarted = existingTicketsAtStartup.has(
          ticket.ticketNo,
        );

        if (existedBeforeMonitorStarted) {
          console.log(
            `⏭️ Skipping Old Ticket ${ticket.ticketNo} (already existed when monitor started)`,
          );

          console.groupEnd();
          continue;
        }

        const eligibilityResult = getEligibilityResult(ticket, assignedTickets);

        saveEligibilityResult(ticket, eligibilityResult);

        console.log("🤖 Eligible:", eligibilityResult.eligible);

        if (!eligibilityResult.eligible) {
          console.log("❌ Reasons:", eligibilityResult.reasons);
        }

        if (eligibilityResult.eligible) {
          console.log(
            `%c🚀 Auto Assigning Ticket ${ticket.ticketNo}`,
            "color:orange;font-weight:bold",
          );

          const assignmentResponse = await assignTicket(ticket.ticketNo);

          if (assignmentResponse) {
            assignedTickets.add(ticket.ticketNo);

            localStorage.setItem(
              ASSIGNED_KEY,
              JSON.stringify([...assignedTickets]),
            );

            autoAssignedCount++;
          }
        }

        console.groupEnd();
      }

      localStorage.setItem(STORAGE_KEY, JSON.stringify(savedTickets));

      // ✅ Check if assigned ticket count increased
      checkAssignedCountChange();

      console.log(
        `%c💾 Today's Stored Tickets: ${savedTickets.length}`,
        "color:#2196F3;font-weight:bold",
      );

      console.log(
        `%c✅ New Tickets Found: ${newTicketsCount}`,
        "color:green;font-weight:bold",
      );

      console.log(
        `%c🤖 Auto Assigned This Cycle: ${autoAssignedCount}`,
        "color:orange;font-weight:bold",
      );
    } catch (error) {
      console.error("❌ Monitor Failed", error);
    }
  }

  fetchAndFilterTickets();

  return setInterval(fetchAndFilterTickets, 5000);
}

// Start
// const bitlockerMonitor = startBitlockerMonitor();

// Stop
// clearInterval(bitlockerMonitor);
