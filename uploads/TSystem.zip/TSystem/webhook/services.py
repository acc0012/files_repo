import re
import uuid
from datetime import datetime, timezone
from core.db import get_orders_collection, get_option_data


# -------------------------------------------------
# 🔹 Parse webhook incoming message
# -------------------------------------------------
def parse_webhook_message(message: str):
    """
    Extract Type and Strike from message string.
    Example: "Type=buyPE Strike=24200"
    """
    try:
        type_match = re.search(r"Type=(\w+)", message)
        strike_match = re.search(r"Strike=(\d+)", message)

        order_type = type_match.group(1) if type_match else None
        strike = int(strike_match.group(1)) if strike_match else None

        if not order_type or not strike:
            return None

        return {
            "type": order_type,
            "strike": strike
        }

    except Exception:
        return None


# -------------------------------------------------
# 🔹 Generate request temp ID
# -------------------------------------------------
def generate_temp_id():
    return "tmp_" + datetime.now().strftime("%Y%m%d_%H%M%S_") + uuid.uuid4().hex[:4]


# -------------------------------------------------
# 🔹 Generate final order ID ("ord_", "ign_", "fail_")
# -------------------------------------------------
def generate_order_id(status):
    prefix_map = {
        "placed": "ord_",
        "ignored": "ign_",
        "failed": "fail_"
    }
    prefix = prefix_map.get(status, "ord_")
    return prefix + uuid.uuid4().hex[:6]


# -------------------------------------------------
# 🔹 Save order in MongoDB
# -------------------------------------------------
def save_order(data):
    col = get_orders_collection()
    col.insert_one({
        **data,
        "created_at": datetime.now(timezone.utc)
    })


# -------------------------------------------------
# 🔹 Fetch last placed/ignored order for index
# -------------------------------------------------
def get_last_order(index_security_id):
    col = get_orders_collection()

    return col.find_one(
        {"index_security_id": index_security_id},
        sort=[("created_at", -1)]
    )


# -------------------------------------------------
# 🔹 Background processing of webhook
# -------------------------------------------------
def process_webhook_async(index_security_id, message, temp_id):
    """
    Heavy processing runs in background (thread).
    """

    # Step 1 → Parse message
    parsed = parse_webhook_message(message)

    if not parsed:
        order_id = generate_order_id("failed")
        save_order({
            "order_id": order_id,
            "temp_id": temp_id,
            "index_security_id": index_security_id,
            "status": "failed",
            "reason": "Parsing failed",
            "raw_message": message
        })
        return

    strike = parsed["strike"]
    order_type = parsed["type"]
    option_type = "pe" if "PE" in order_type.upper() else "ce"

    # Step 2 → Fetch security_id from option chain
    option_data = get_option_data(
        index_security_id=index_security_id,
        strike=strike,
        option_type=option_type
    )

    if not option_data:
        order_id = generate_order_id("failed")
        save_order({
            "order_id": order_id,
            "temp_id": temp_id,
            "index_security_id": index_security_id,
            "status": "failed",
            "reason": "Security ID not found",
            "strike": strike,
            "order_type": order_type,
            "raw_message": message
        })
        return

    security_id = option_data.get("security_id")

    # Step 3 → Check last order to see if ignored or placed
    last_order = get_last_order(index_security_id)

    status = "placed"

    if last_order:
        last_type = last_order.get("type")
        if last_type == order_type:
            status = "ignored"

    # Step 4 → Generate real order ID
    order_id = generate_order_id(status)

    # Step 5 → Save final order
    save_order({
        "order_id": order_id,
        "temp_id": temp_id,
        "index_security_id": index_security_id,
        "strike": strike,
        "type": order_type,
        "option_type": option_type,
        "security_id": security_id,
        "status": status,
        "raw_message": message
    })