import uuid
from datetime import datetime

def generate_temp_id():
    return "tmp_" + datetime.now().strftime("%Y%m%d_%H%M%S_") + uuid.uuid4().hex[:4]


def generate_order_id(order_type):
    """
    order_type → placed / ignored / failed
    """
    prefix = {
        "placed": "ord_",
        "ignored": "ign_",
        "failed": "fail_"
    }.get(order_type, "ord_")

    return prefix + uuid.uuid4().hex[:6]