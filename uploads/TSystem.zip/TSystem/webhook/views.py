from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
import json
from threading import Thread

from webhook.utils import generate_temp_id
from webhook.tasks import process_webhook_async


# -------------------------------------------------
# 🔥 MAIN WEBHOOK ENDPOINT (ASYNC + FAST RESPONSE)
# -------------------------------------------------
@csrf_exempt
@require_POST
def webhook_view(request, index_security_id):
    """
    This endpoint receives a webhook message and IMMEDIATELY returns
    a temporary request ID. The heavy processing of the webhook
    is done in a background thread so the caller does not wait.
    """

    # 1️⃣ Extract JSON body
    try:
        body = json.loads(request.body)
        message = body.get("message")
    except Exception:
        return JsonResponse({"error": "Invalid JSON"}, status=400)

    # 2️⃣ Validate message
    if not message:
        return JsonResponse({"error": "Message required"}, status=400)

    # 3️⃣ Generate a lightweight temporary ID
    temp_id = generate_temp_id()

    # 4️⃣ Process webhook in background
    Thread(
        target=process_webhook_async,
        args=(index_security_id, message, temp_id)
    ).start()

    # 5️⃣ Immediately respond to webhook sender
    return JsonResponse({
        "req_id": temp_id,
        "status": "received"
    })