from webhook.services import (
    parse_webhook_message,
    get_last_order,
    save_order
)

from webhook.utils import generate_order_id
from core.db import get_option_data

from marketfeed.subscriber import subscribe_security
from marketfeed.services import start_feed_ws


def process_webhook_async(index_security_id, message, temp_id):
    """
    Background processing of webhook — non-blocking.
    Runs in a thread started by webhook_view.
    """

    # -------------------------------------------------
    # STEP 1: Parse incoming webhook message
    # -------------------------------------------------
    parsed = parse_webhook_message(message)

    if not parsed:
        order_id = generate_order_id("failed")
        save_order({
            "order_id": order_id,
            "temp_id": temp_id,
            "index_security_id": index_security_id,
            "status": "failed",
            "reason": "Parsing failed",
            "raw_message": message
        })
        return

    strike = parsed["strike"]
    order_type = parsed["type"]       # buyPE / buyCE
    option_type = "pe" if "PE" in order_type.upper() else "ce"

    # -------------------------------------------------
    # STEP 2: Lookup option chain data → get security_id
    # -------------------------------------------------
    option_data = get_option_data(
        index_security_id=index_security_id,
        strike=strike,
        option_type=option_type
    )

    if not option_data:
        order_id = generate_order_id("failed")
        save_order({
            "order_id": order_id,
            "temp_id": temp_id,
            "index_security_id": index_security_id,
            "status": "failed",
            "reason": "Security ID not found",
            "strike": strike,
            "order_type": order_type,
            "raw_message": message
        })
        return

    security_id = option_data.get("security_id")

    # -------------------------------------------------
    # STEP 3: Detect last order → check for ignored
    # -------------------------------------------------
    last_order = get_last_order(index_security_id)

    status = "placed"   # default behavior

    if last_order:
        if last_order.get("type") == order_type:
            status = "ignored"

    # -------------------------------------------------
    # STEP 4: Generate final order_id
    # -------------------------------------------------
    order_id = generate_order_id(status)

    # -------------------------------------------------
    # STEP 5: Save order in database
    # -------------------------------------------------
    save_order({
        "order_id": order_id,
        "temp_id": temp_id,
        "index_security_id": index_security_id,
        "strike": strike,
        "type": order_type,
        "option_type": option_type,
        "security_id": security_id,
        "status": status,
        "raw_message": message,
    })

    # -------------------------------------------------
    # STEP 6: If order placed → Subscribe to market feed
    # -------------------------------------------------
    if status == "placed":
        # 1) subscribe to Railway backend feed server
        subscribe_security(index_security_id, security_id)

        # 2) open websocket live stream
        start_feed_ws(security_id)

        # Now live ticks will appear in logs (if FEED_LOGS=true)
