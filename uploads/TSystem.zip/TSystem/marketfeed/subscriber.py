import requests
from django.conf import settings

BASE_HTTP = settings.BASE_HTTP


EXCHANGE_SEGMENTS = {
    13: 2,   # NIFTY      → NSE_FNO
    25: 2,   # FINNIFTY   → NSE_FNO
    51: 8    # BANKNIFTY  → BSE_FNO
}


def subscribe_security(index_security_id, security_id):
    """
    Subscribes to a security on the remote WS feed (Railway backend)
    """

    exchange = EXCHANGE_SEGMENTS.get(index_security_id, 2)

    payload = {
        "symbols": [
            [exchange, str(security_id), 17]   # 17 = Quote feed
        ]
    }

    try:
        res = requests.post(
            f"{BASE_HTTP}/subscribe",
            json=payload,
            timeout=3
        )
        return res.json()

    except Exception as e:
        return {"status": "error", "error": str(e)}