import json
import websocket
import threading
import time
from django.conf import settings
from core.logger import get_logger

logger = get_logger("marketfeed")

BASE_WS = settings.BASE_WS


def start_feed_ws(security_id, retry_delay=3):
    """
    Opens WebSocket stream for a given security_id.
    Logs incoming feed ticks (if FEED_LOGS = true)
    and gracefully handles reconnection, errors, and closure.
    """

    url = f"{BASE_WS}/{security_id}/quote"

    # ---------------------------------------------
    # 🔹 Message Handler
    # ---------------------------------------------
    def on_message(ws, message):
        try:
            data = json.loads(message)
            pretty = json.dumps(data, indent=2)

            if settings.FEED_LOGS:
                logger.info(f"\n=== LIVE FEED | Security {security_id} ===\n{pretty}")

        except Exception as e:
            logger.error(f"JSON parse error for Security {security_id}: {e}")
            logger.error(f"RAW FEED: {message}")

    # ---------------------------------------------
    # 🔹 WS Connected
    # ---------------------------------------------
    def on_open(ws):
        logger.info(f"[WS OPEN] Live feed started for Security {security_id}")

    # ---------------------------------------------
    # 🔹 WS Error
    # ---------------------------------------------
    def on_error(ws, error):
        logger.error(f"[WS ERROR] Security {security_id} → {error}")

    # ---------------------------------------------
    # 🔹 WS Closed
    # ---------------------------------------------
    def on_close(ws, close_status_code, close_msg):
        logger.warning(f"[WS CLOSED] Security {security_id} | Code={close_status_code} Msg={close_msg}")

        # Auto-reconnect logic
        logger.info(f"[WS RECONNECT] Attempting reconnect for Security {security_id} in {retry_delay}s...")
        time.sleep(retry_delay)
        start_feed_ws(security_id)  # reconnect

    # ---------------------------------------------
    # 🔹 Create WebSocket Client
    # ---------------------------------------------
    try:
        ws = websocket.WebSocketApp(
            url,
            on_message=on_message,
            on_open=on_open,
            on_close=on_close,
            on_error=on_error
        )

        logger.info(f"[WS INIT] Connecting to {url}")
        threading.Thread(target=ws.run_forever, daemon=True).start()

    except Exception as e:
        logger.error(f"[WS FATAL ERROR] Could not start WebSocket for {security_id}: {e}")