from growwapi import GrowwAPI
import pandas as pd
from config import GrowwConfig
from utils_clock import IST

cfg = GrowwConfig()

def fetch_candles(symbol, start, end, interval):
    api = GrowwAPI(cfg.access_token)

    interval_map = {
        1: api.CANDLE_INTERVAL_MIN_1,
        5: api.CANDLE_INTERVAL_MIN_5
    }

    res = api.get_historical_candles(
        exchange=cfg.exchange,
        segment=cfg.segment,
        groww_symbol=symbol,
        start_time=start.strftime('%Y-%m-%d %H:%M:%S'),
        end_time=end.strftime('%Y-%m-%d %H:%M:%S'),
        candle_interval=interval_map[interval]
    )

    rows = []
    for c in res['candles']:
        ts = pd.to_datetime(c[0]).tz_localize(IST)
        rows.append((ts, c[1], c[2], c[3], c[4], c[5]))

    df = pd.DataFrame(rows, columns=['ts','open','high','low','close','volume'])
    df.set_index('ts', inplace=True)
    return df
