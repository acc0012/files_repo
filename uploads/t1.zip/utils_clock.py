from datetime import datetime, timedelta
import pytz

IST = pytz.timezone("Asia/Kolkata")

def now_ist():
    return datetime.now(IST)

def last_n_days(n):
    end = now_ist()
    start = end - timedelta(days=n)
    return start, end
