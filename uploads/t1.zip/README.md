# Groww NIFTY Options WaveTrend Project

This project uses the **official Groww Trade API (Python SDK)** to:

• Fetch **last 30 days of 1‑minute historical candles** for NIFTY options  
• Continuously fetch **last 5 minutes** for live updates  
• Detect new candles and append safely  
• Compute **WaveTrend with Crosses (LazyBear)**  

---

## 1. Setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Set your Groww access token:

```bash
export GROWW_ACCESS_TOKEN="YOUR_ACCESS_TOKEN"
```

---

## 2. Backfill 30 Days

```bash
python run_backfill.py --symbol NSE-NIFTY-30Sep25-24650-CE
```

---

## 3. Live Updater

```bash
python run_live.py --symbol NSE-NIFTY-30Sep25-24650-CE
```

---

## Notes
• Uses official Groww API (documented & stable)
• 1‑minute candles support **30 days per request**
• CSV storage with deduplication
• WaveTrend logic is a faithful port of LazyBear PineScript
