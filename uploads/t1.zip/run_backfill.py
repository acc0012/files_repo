import argparse
from utils_clock import last_n_days
from data_groww import fetch_candles
from storage import append
from indicator_wavetrend import wavetrend

parser = argparse.ArgumentParser()
parser.add_argument('--symbol', required=True)
args = parser.parse_args()

start, end = last_n_days(30)
df = fetch_candles(args.symbol, start, end, 1)
df = append(args.symbol, df)
df = wavetrend(df)
print(df.tail())
