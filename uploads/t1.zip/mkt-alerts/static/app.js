
async function loadDocs() {
  const res = await fetch('/api/docs');
  const docs = await res.json();
  const ul = document.getElementById('docs');
  ul.innerHTML = '';
  docs.forEach(d => {
    const li = document.createElement('li');
    li.className = 'list-group-item list-group-item-dark';
    li.textContent = d.type_name + ' (' + d.count + ')';
    li.onclick = () => loadDoc(d.type_name);
    ul.appendChild(li);
  });
}

async function loadDoc(type) {
  const res = await fetch('/api/docs/' + type);
  const doc = await res.json();
  document.getElementById('content').textContent = JSON.stringify(doc, null, 2);
}

loadDocs();
setInterval(loadDocs, 10000);
