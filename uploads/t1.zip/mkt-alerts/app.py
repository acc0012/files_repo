
from flask import Flask, request, jsonify, render_template
from pymongo import MongoClient, ASCENDING
from dotenv import load_dotenv
import os, json
from datetime import datetime, timedelta, timezone
import requests

load_dotenv()

MONGO_URI = os.getenv("MONGO_URI")
MONGO_DB = os.getenv("MONGO_DB", "mkt")
MONGO_COLLECTION = os.getenv("MONGO_COLLECTION", "alerts")

TELE_BOT = os.getenv("TELE_BOT", "false").lower() in ("1", "true", "yes")
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")

app = Flask(__name__)

mongo = MongoClient(MONGO_URI)
db = mongo[MONGO_DB]
coll = db[MONGO_COLLECTION]
coll.create_index([("type_name", ASCENDING)], unique=True)

IST = timezone(timedelta(hours=5, minutes=30))

def utc_now():
    return datetime.now(timezone.utc)

def save_alert(alert):
    type_name = alert.get("type_name") or "DEFAULT"
    doc_alert = {
        **alert,
        "received_at_utc": utc_now().isoformat(),
        "received_at_ist": utc_now().astimezone(IST).isoformat(),
    }
    coll.update_one(
        {"type_name": type_name},
        {
            "$setOnInsert": {
                "type_name": type_name,
                "created_at": utc_now().isoformat(),
                "alerts": [],
                "count": 0
            },
            "$push": {"alerts": doc_alert},
            "$inc": {"count": 1},
            "$set": {"updated_at": utc_now().isoformat()}
        },
        upsert=True
    )

    if TELE_BOT:
        send_telegram(alert)


def send_telegram(alert):
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        return
    msg = f"{alert.get('symbol')} {alert.get('signal')} @ {alert.get('price')}"
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    requests.post(url, json={"chat_id": TELEGRAM_CHAT_ID, "text": msg})

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/webhook/alerts", methods=["POST"])
def webhook():
    data = request.get_json(force=True)
    alerts = data if isinstance(data, list) else [data]
    for alert in alerts:
        save_alert(alert)
    return jsonify({"status": "ok", "received": len(alerts)})

@app.route("/api/docs")
def docs():
    return jsonify(list(coll.find({}, {"_id": 0, "type_name": 1, "count": 1})))

@app.route("/api/docs/<type_name>")
def doc(type_name):
    d = coll.find_one({"type_name": type_name}, {"_id": 0})
    return jsonify(d or {})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
