import os
from dataclasses import dataclass

IST_TZ = "Asia/Kolkata"

@dataclass(frozen=True)
class GrowwConfig:
    access_token: str = os.getenv("GROWW_ACCESS_TOKEN", "")
    exchange: str = "NSE"
    segment: str = "FNO"
    interval_minutes: int = 1

DATA_DIR = "data"
os.makedirs(DATA_DIR, exist_ok=True)
