import argparse, time
from datetime import timedelta
from utils_clock import now_ist
from data_groww import fetch_candles
from storage import append
from indicator_wavetrend import wavetrend

parser = argparse.ArgumentParser()
parser.add_argument('--symbol', required=True)
args = parser.parse_args()

last_ts = None
while True:
    end = now_ist()
    start = end - timedelta(minutes=5)
    df = fetch_candles(args.symbol, start, end, 1)
    df = append(args.symbol, df)
    df = wavetrend(df)

    row = df.tail(1)
    if not row.empty and row.index[0] != last_ts:
        last_ts = row.index[0]
        r = row.iloc[0]
        if r['cross']:
            print(f"{last_ts} WT CROSS {('BULL' if r['cross_dir']>0 else 'BEAR')}")
        else:
            print(f"{last_ts} WT1={r['wt1']:.2f} WT2={r['wt2']:.2f}")
    time.sleep(5)
