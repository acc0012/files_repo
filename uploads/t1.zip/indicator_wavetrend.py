import pandas as pd
import numpy as np

def wavetrend(df, n1=10, n2=21):
    ap = (df['high'] + df['low'] + df['close']) / 3.0
    esa = ap.ewm(span=n1, adjust=False).mean()
    d = (ap - esa).abs().ewm(span=n1, adjust=False).mean()
    ci = (ap - esa) / (0.015 * d.replace(0, np.nan))
    tci = ci.ewm(span=n2, adjust=False).mean()

    df['wt1'] = tci
    df['wt2'] = df['wt1'].rolling(4).mean()
    df['wt_hist'] = df['wt1'] - df['wt2']

    prev = df['wt1'].shift(1) - df['wt2'].shift(1)
    curr = df['wt1'] - df['wt2']
    df['cross'] = (prev * curr) < 0
    df['cross_dir'] = np.sign(curr).where(df['cross'], 0)
    return df
