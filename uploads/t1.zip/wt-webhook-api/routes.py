from flask import Blueprint, request, jsonify
from db import signals_collection
from models import build_signal
from utils import find_open_buy, close_trade

webhook = Blueprint('webhook', __name__)

@webhook.route('/webhook', methods=['POST'])
def tradingview_webhook():
    try:
        data = request.get_json(force=True)
        signal_type = data.get('type')
        symbol = data.get('symbol')
        interval = data.get('interval')

        if not signal_type or not symbol:
            return jsonify({'error': 'Invalid payload'}), 400

        signal_doc = build_signal(data)

        if signal_type == 'BUY':
            signals_collection.insert_one(signal_doc)
            return jsonify({'status': 'BUY stored'}), 200

        if signal_type == 'SELL':
            open_buy = find_open_buy(symbol, interval)
            if open_buy:
                close_trade(open_buy['_id'], signal_doc)
                return jsonify({'status': 'SELL matched'}), 200
            else:
                signal_doc['status'] = 'UNMATCHED'
                signals_collection.insert_one(signal_doc)
                return jsonify({'status': 'SELL stored without BUY'}), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 500
