
from flask import Blueprint, request, jsonify
from services.normalizer import normalize_payload
from services.storage import store_alert
from services.logger import log_event

webhook_bp = Blueprint('webhook', __name__)

@webhook_bp.route('/tradingview', methods=['POST'])
def tradingview():
    try:
        payload = request.get_json(silent=True) or request.data.decode()
        log_event('INFO', 'Webhook received')
        normalized = normalize_payload(payload)
        store_alert(normalized)
        return jsonify({'status': 'success'}), 200
    except Exception as e:
        log_event('ERROR', 'Webhook processing failed', {'error': str(e)})
        return jsonify({'status': 'error'}), 400
