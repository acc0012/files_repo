
from pymongo import MongoClient
from config import MONGODB_URI
from datetime import datetime
client = MongoClient(MONGODB_URI)
logs = client.alerts_db.logs
def log_event(level, message, meta=None):
    logs.insert_one({
        'level': level,
        'message': message,
        'meta': meta or {},
        'timestamp': datetime.utcnow()
    })
