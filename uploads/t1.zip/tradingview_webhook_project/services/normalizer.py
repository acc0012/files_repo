
import json, datetime
def normalize_payload(payload):
    data = payload
    if isinstance(payload, str):
        try: data = json.loads(payload)
        except: data = {'raw': payload}
    return {
        'group_id': f"{data.get('Ticker','UNKNOWN')}|{data.get('Name','UNKNOWN')}",
        'ticker': data.get('Ticker'),
        'indicator': data.get('Name'),
        'alert': {
            'alert_id': data.get('Alert ID'),
            'description': data.get('Description'),
            'timestamp': data.get('Time', str(datetime.datetime.utcnow()))
        }
    }
