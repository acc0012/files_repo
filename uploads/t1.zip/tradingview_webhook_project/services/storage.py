
from pymongo import MongoClient
from config import MONGODB_URI
from services.logger import log_event
client = MongoClient(MONGODB_URI)
db = client.alerts_db
alerts = db.alerts
def store_alert(data):
    alerts.update_one(
        {'_id': data['group_id']},
        {'$setOnInsert': {'ticker': data['ticker'], 'indicator': data['indicator']}, '$push': {'alerts': data['alert']}},
        upsert=True
    )
    log_event('INFO', 'Alert stored',{ 'group_id': data['group_id']})
