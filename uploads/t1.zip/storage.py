import os
import pandas as pd
from config import DATA_DIR

def path(symbol):
    return os.path.join(DATA_DIR, symbol.replace('-', '_') + '.csv')

def load(symbol):
    p = path(symbol)
    if os.path.exists(p):
        df = pd.read_csv(p, parse_dates=['ts'])
        df.set_index('ts', inplace=True)
        return df
    return pd.DataFrame()

def save(symbol, df):
    df.reset_index().to_csv(path(symbol), index=False)

def append(symbol, new_df):
    df = load(symbol)
    df = pd.concat([df, new_df]).sort_index()
    df = df[~df.index.duplicated(keep='last')]
    save(symbol, df)
    return df
