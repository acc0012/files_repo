from fastapi import APIRouter, Request

from core import config
from core.logger import get_logger

logger = get_logger(__file__)

router = APIRouter()


def get_live_ema_calculation_mode_text() -> str:
    """
    Returns configured live EMA calculation mode.
    """

    return (
        "tick_ltp"
        if bool(getattr(config, "LIVE_EMA_CALCULATION_MODE", False))
        else "candle_close"
    )


def get_live_ema_calculation_mode_payload() -> dict:
    """
    Returns live EMA calculation mode payload.
    """

    flag = bool(getattr(config, "LIVE_EMA_CALCULATION_MODE", False))
    mode = get_live_ema_calculation_mode_text()

    return {
        "flag": flag,
        "mode": mode,
        "description": (
            "live tick/LTP based EMA calculation"
            if flag
            else "completed candle close based EMA calculation"
        ),
    }


def get_ema_entry_side_logic_payload() -> dict:
    """
    Returns isolated EMA Telegram entry-side logic.

    New rule:
        Bullish EMA on isolated option -> same side entry.
        Bearish EMA on isolated option -> opposite side entry.
    """

    use_isolated_side_logic = bool(
        getattr(config, "EMA_ALERT_USE_ISOLATED_OPTION_SIDE_LOGIC", True)
    )

    return {
        "enabled": use_isolated_side_logic,
        "message_format": getattr(config, "EMA_ALERT_MESSAGE_FORMAT", "simple"),
        "include_entry_reason": getattr(
            config,
            "EMA_ALERT_INCLUDE_ENTRY_REASON",
            True,
        ),
        "rule": (
            "Bullish EMA on isolated option suggests same side. "
            "Bearish EMA on isolated option suggests opposite side."
        ),
        "examples": {
            "isolated_pe_bullish_cross": "suggest nearest PE instruments",
            "isolated_pe_bearish_cross": "suggest nearest CE instruments",
            "isolated_ce_bullish_cross": "suggest nearest CE instruments",
            "isolated_ce_bearish_cross": "suggest nearest PE instruments",
        },
        "fallback_rule_if_disabled_or_missing_type": {
            "bullish_cross": getattr(config, "EMA_ALERT_BULLISH_OPTION_TYPE", "CE"),
            "bearish_cross": getattr(config, "EMA_ALERT_BEARISH_OPTION_TYPE", "PE"),
        },
    }


@router.get("/docs/websockets")
async def get_websocket_docs(request: Request):
    """
    Returns WebSocket endpoint documentation and sample connection URLs.

    Note:
    FastAPI Swagger/OpenAPI does not execute WebSocket routes directly.
    This HTTP endpoint exposes WebSocket connection examples so they are visible
    from /docs.

    Current flow:
    - Opening Range is calculated for all subscribed instruments.
    - One Opening Range instrument can be isolated using R3/S3 before R2/S2,
      then nearest strike to Opening Range average.
    - Live EMA crossover is calculated for all initialized instruments.
    - EMA crossover WebSocket payloads include Opening Range levels
      for the same instrument when available.
    - WebSocket EMA events are not filtered by isolated instrument.
    - Telegram EMA alerts are sent only for the isolated instrument.
    - Telegram entry side suggestion uses isolated option side logic:
        bullish on isolated option -> same side
        bearish on isolated option -> opposite side
    """

    host = request.headers.get("host", "127.0.0.1:8000")
    scheme = request.url.scheme

    ws_scheme = "wss" if scheme == "https" else "ws"
    base_ws_url = f"{ws_scheme}://{host}"

    live_ema_payload = get_live_ema_calculation_mode_payload()
    entry_side_logic = get_ema_entry_side_logic_payload()

    return {
        "status": "success",
        "title": "WebSocket Connection Examples",
        "note": (
            "Swagger UI does not directly execute WebSocket routes. "
            "Use these URLs in browser JavaScript, Postman, Hoppscotch, "
            "websocat, or any WebSocket client."
        ),
        "current_flow": {
            "description": (
                "The app subscribes to configured instruments, calculates Opening Range "
                "levels for every subscribed instrument, calculates live EMA crossovers "
                "for every initialized instrument, and broadcasts EMA crossover events "
                "through WebSocket with that instrument's Opening Range levels when available."
            ),
            "opening_range_isolated_instrument_flow": "enabled",
            "websocket_ema_filtering_by_isolated_instrument": "not_applied",
            "telegram_ema_alerts": "isolated_instrument_only",
            "ema_websocket_opening_range_enrichment": getattr(
                config,
                "EMA_CROSS_INCLUDE_OPENING_RANGE_LEVELS",
                True,
            ),
            "live_ema_calculation": live_ema_payload,
            "telegram_entry_side_logic": entry_side_logic,
        },
        "telegram_alert_logic": {
            "scope": (
                "Telegram EMA alerts are sent only when the EMA crossover belongs "
                "to the currently isolated Opening Range instrument."
            ),
            "entry_side_rule": (
                "Bullish EMA on isolated option means same-side momentum. "
                "Bearish EMA on isolated option means isolated option weakness, "
                "so opposite side is suggested."
            ),
            "examples": {
                "isolated_pe_bullish_cross": {
                    "interpretation": "PE price expected to gain momentum",
                    "suggested_entry_side": "PE",
                    "nearest_instruments": "nearest PE strikes around current NIFTY spot",
                },
                "isolated_pe_bearish_cross": {
                    "interpretation": "PE price expected to weaken",
                    "suggested_entry_side": "CE",
                    "nearest_instruments": "nearest CE strikes around current NIFTY spot",
                },
                "isolated_ce_bullish_cross": {
                    "interpretation": "CE price expected to gain momentum",
                    "suggested_entry_side": "CE",
                    "nearest_instruments": "nearest CE strikes around current NIFTY spot",
                },
                "isolated_ce_bearish_cross": {
                    "interpretation": "CE price expected to weaken",
                    "suggested_entry_side": "PE",
                    "nearest_instruments": "nearest PE strikes around current NIFTY spot",
                },
            },
            "sample_telegram_alert_layout": {
                "title": "Isolated Instrument EMA Alert",
                "example": (
                    "24550 PE - crossed R3\n"
                    "NIFTY Spot: 24287.85\n\n"
                    "-----------------------\n"
                    "EMA Cross Details\n"
                    "-----------------------\n"
                    "Signal: Bullish\n"
                    "EMA Calculation Mode: candle_close\n"
                    "EMA Mode: Candle Close\n"
                    "EMA Candle Close: 252.85\n"
                    "EMA Candle Time: 12 Aug 2026, 01:44:00 PM IST\n\n"
                    "Instrument Key: NSE_FO|45115\n"
                    "Strike: 24550 PE\n\n"
                    "-----------------------\n"
                    "Entry Side Suggestion\n"
                    "-----------------------\n"
                    "Entry Side: PE\n"
                    "Reason: Bullish EMA on PE, expecting PE momentum. "
                    "Suggested entry side is PE.\n\n"
                    "Nearest Instrument Details:\n"
                    "- 24250PE - 188.9rs\n"
                    "- 24300PE - 158.95rs\n"
                    "- 24350PE - 131.3rs"
                ),
            },
        },
        "base_ws_url": base_ws_url,
        "websockets": [
            {
                "name": "All Feeds",
                "endpoint": "/all-feeds",
                "method": "WebSocket",
                "url": f"{base_ws_url}/all-feeds",
                "alternate_url": f"{base_ws_url}/ws",
                "description": (
                    "Streams live ticks for all subscribed instruments. "
                    "This includes NIFTY index and filtered option contracts. "
                    "It can also receive EMA crossover and Opening Range events "
                    "when broadcast by the backend."
                ),
                "sample_connected_response": {
                    "type": "connected",
                    "endpoint": "/all-feeds",
                    "message": (
                        "Connected to all feeds websocket. Waiting for live ticks, "
                        "EMA crossover events, and Opening Range events."
                    ),
                    "subscribed_instruments": 83,
                    "live_ema_calculation": live_ema_payload,
                    "telegram_ema_alerts": "isolated_instrument_only",
                },
                "sample_live_tick_payload": {
                    "type": "live_tick",
                    "interval": 0,
                    "instrument_key": "NSE_FO|41012",
                    "ltp": 120.5,
                    "close": 115.0,
                    "change": 5.5,
                    "change_pct": 4.78,
                    "open": 110.0,
                    "high": 130.0,
                    "low": 100.0,
                    "volume": 250000,
                    "oi": 500000,
                    "info": {
                        "instrument_key": "NSE_FO|41012",
                        "instrument_type": "CE",
                        "strike_price": 24500.0,
                        "trading_symbol": "NIFTY 24500 CE",
                    },
                },
            },
            {
                "name": "Single Option Feed",
                "endpoint": "/option",
                "method": "WebSocket",
                "url": f"{base_ws_url}/option?strike=24500&striketype=ce",
                "alternate_examples": [
                    f"{base_ws_url}/option?strike=24500&striketype=pe",
                    f"{base_ws_url}/option?strike=24600&striketype=ce",
                ],
                "query_parameters": {
                    "strike": {
                        "required": True,
                        "example": 24500,
                        "description": "Option strike price.",
                    },
                    "striketype": {
                        "required": True,
                        "example": "ce",
                        "allowed_values": ["ce", "pe", "CE", "PE"],
                        "description": "Option type.",
                    },
                },
                "description": (
                    "Streams live ticks for one option contract based on strike price "
                    "and CE/PE type. It may also receive matching EMA crossover events "
                    "and Opening Range events for the same option."
                ),
                "sample_connected_response": {
                    "type": "connected",
                    "endpoint": "/option",
                    "strike": 24500,
                    "striketype": "CE",
                    "message": (
                        "Connected to option websocket. Waiting for matching option ticks, "
                        "EMA crossover events, and Opening Range events."
                    ),
                    "live_ema_calculation": live_ema_payload,
                    "telegram_ema_alerts": "isolated_instrument_only",
                },
            },
            {
                "name": "Global EMA Crossover Feed",
                "endpoint": "/ws/ema-crossover",
                "method": "WebSocket",
                "url": f"{base_ws_url}/ws/ema-crossover",
                "description": (
                    "Streams live EMA crossover events for all initialized instruments. "
                    "Each EMA crossover payload can include Opening Range levels for "
                    "the same instrument when available. WebSocket broadcast is not "
                    "filtered by isolated instrument."
                ),
                "sample_connected_response": {
                    "type": "connected",
                    "endpoint": "/ws/ema-crossover",
                    "message": (
                        "Connected to EMA Crossover feed. Waiting for EMA crossover "
                        "signals enriched with Opening Range levels when available."
                    ),
                    "scope": "all_instruments",
                    "live_ema_calculation": live_ema_payload,
                    "telegram_ema_alerts": "isolated_instrument_only",
                },
                "sample_ema_cross_payload": {
                    "type": "live_ema_cross",
                    "instrument_key": "NSE_FO|41012",
                    "timestamp": "2026-08-06T09:21:00+05:30",
                    "cross_type": "bullish_cross",
                    "interval_minutes": 1,
                    "close": 124.5,
                    "ema_fast_period": 9,
                    "ema_slow_period": 21,
                    "ema_fast": 123.8,
                    "ema_slow": 122.9,
                    "previous_ema_fast": 122.1,
                    "previous_ema_slow": 122.4,
                    "previous_signal": "bearish",
                    "current_signal": "bullish",
                    "source": "live_feed",
                    "ema_calculation_mode": "candle_close",
                    "created_at": "2026-08-06T09:21:05+05:30",
                    "candle": {
                        "timestamp": "2026-08-06T09:21:00+05:30",
                        "timestamp_ms": 1785988260000,
                        "open": 121.5,
                        "high": 126.0,
                        "low": 120.0,
                        "close": 124.5,
                        "volume": 2000,
                    },
                    "info": {
                        "instrument_key": "NSE_FO|41012",
                        "instrument_type": "CE",
                        "strike_price": 24500.0,
                        "trading_symbol": "NIFTY 24500 CE",
                    },
                    "opening_range": {
                        "r1": 124.5,
                        "s1": 121.5,
                        "r2": 129.0,
                        "s2": 117.0,
                        "r3": 132.0,
                        "s3": 114.0,
                        "sub_resistance": 124.5,
                        "sub_support": 121.5,
                    },
                    "touch_status": {
                        "r2_touched": False,
                        "s2_touched": False,
                        "r3_touched": False,
                        "s3_touched": False,
                        "first_touch_level": None,
                        "first_touch_source": None,
                        "first_touch_time": None,
                        "events": [],
                    },
                    "latest_intraday_close": 124.0,
                    "latest_main_index_ltp": 24580.25,
                    "isolated_instrument": {
                        "selected": True,
                        "instrument_key": "NSE_FO|41012",
                        "selected_level": "R3",
                        "contract_info": {
                            "instrument_key": "NSE_FO|41012",
                            "instrument_type": "CE",
                            "strike_price": 24500.0,
                            "trading_symbol": "NIFTY 24500 CE",
                        },
                        "telegram_alert_scope": "isolated_instrument_only",
                    },
                },
                "sample_ema_cross_payload_without_opening_range": {
                    "type": "live_ema_cross",
                    "instrument_key": "NSE_FO|41012",
                    "timestamp": "2026-08-06T09:21:00+05:30",
                    "cross_type": "bullish_cross",
                    "interval_minutes": 1,
                    "close": 124.5,
                    "ema_fast": 123.8,
                    "ema_slow": 122.9,
                    "opening_range": {},
                    "touch_status": {},
                    "latest_intraday_close": None,
                    "latest_main_index_ltp": None,
                    "isolated_instrument": {
                        "selected": False,
                        "message": "No isolated Opening Range instrument selected yet.",
                    },
                },
            },
            {
                "name": "Instrument-Specific EMA Crossover Feed By Instrument Key",
                "endpoint": "/ws/ema-crossover/instrument",
                "method": "WebSocket",
                "url": (
                    f"{base_ws_url}/ws/ema-crossover/instrument"
                    f"?instrument_key=NSE_INDEX%7CNifty%2050"
                ),
                "alternate_examples": [
                    (
                        f"{base_ws_url}/ws/ema-crossover/instrument"
                        f"?instrument_key=NSE_FO%7C41012"
                    )
                ],
                "query_parameters": {
                    "instrument_key": {
                        "required": False,
                        "example": "NSE_INDEX|Nifty 50",
                        "description": (
                            "Direct instrument key. Use URL encoding for pipe and spaces."
                        ),
                    },
                    "strike": {
                        "required": False,
                        "example": 24500,
                        "description": (
                            "Option strike. Used only when instrument_key is not provided."
                        ),
                    },
                    "striketype": {
                        "required": False,
                        "example": "ce",
                        "allowed_values": ["ce", "pe", "CE", "PE"],
                        "description": (
                            "Option type. Used only when instrument_key is not provided."
                        ),
                    },
                },
                "description": (
                    "Streams live EMA crossover events for one resolved instrument only. "
                    "Each event includes Opening Range levels for that instrument when available. "
                    "Telegram alert is sent only if this instrument is also the isolated instrument."
                ),
                "sample_connected_response": {
                    "type": "connected",
                    "endpoint": "/ws/ema-crossover/instrument",
                    "instrument_key": "NSE_INDEX|Nifty 50",
                    "message": (
                        "Connected to instrument-specific EMA crossover feed. "
                        "Waiting for crossover signals."
                    ),
                    "live_ema_calculation": live_ema_payload,
                    "telegram_ema_alerts": "only_if_this_instrument_is_isolated",
                },
            },
            {
                "name": "Instrument-Specific EMA Crossover Feed By Strike",
                "endpoint": "/ws/ema-crossover/instrument",
                "method": "WebSocket",
                "url": (
                    f"{base_ws_url}/ws/ema-crossover/instrument"
                    f"?strike=24500&striketype=ce"
                ),
                "alternate_examples": [
                    (
                        f"{base_ws_url}/ws/ema-crossover/instrument"
                        f"?strike=24500&striketype=pe"
                    )
                ],
                "description": (
                    "Resolves option instrument from options_cache using strike and CE/PE type, "
                    "then streams EMA crossover events only for that resolved instrument. "
                    "Each EMA event includes Opening Range levels when available."
                ),
            },
            {
                "name": "Global Opening Range Feed",
                "endpoint": "/ws/opening-range",
                "method": "WebSocket",
                "url": f"{base_ws_url}/ws/opening-range",
                "description": (
                    "Streams Opening Range events for all instruments. "
                    "This includes R2/R3/S2/S3 touch events when available. "
                    "Touch events are also used by backend isolation logic."
                ),
                "sample_connected_response": {
                    "type": "connected",
                    "endpoint": "/ws/opening-range",
                    "message": (
                        "Connected to Opening Range feed. Waiting for opening range events."
                    ),
                    "isolated_instrument_flow": getattr(
                        config,
                        "OPENING_RANGE_ISOLATED_INSTRUMENT_ENABLED",
                        True,
                    ),
                },
                "sample_opening_range_touch_payload": {
                    "type": "opening_range_touch",
                    "instrument_key": "NSE_FO|41012",
                    "level": "R3",
                    "level_value": 126.75,
                    "trigger_price": 128.5,
                    "trigger_field": "high",
                    "touch_time": "2026-08-06T09:16:00+05:30",
                    "source": "intraday_backfill_scan",
                    "date": "2026-08-06",
                    "main_index_ltp": 24580.25,
                    "distance_from_index": 19.75,
                    "alert_key": "NSE_FO|41012_R3",
                    "contract_info": {
                        "instrument_key": "NSE_FO|41012",
                        "instrument_type": "CE",
                        "strike_price": 24600.0,
                        "trading_symbol": "NIFTY 24600 CE",
                    },
                },
            },
            {
                "name": "Instrument-Specific Opening Range Feed By Instrument Key",
                "endpoint": "/ws/opening-range/instrument",
                "method": "WebSocket",
                "url": (
                    f"{base_ws_url}/ws/opening-range/instrument"
                    f"?instrument_key=NSE_INDEX%7CNifty%2050"
                ),
                "alternate_examples": [
                    (
                        f"{base_ws_url}/ws/opening-range/instrument"
                        f"?instrument_key=NSE_FO%7C41012"
                    )
                ],
                "query_parameters": {
                    "instrument_key": {
                        "required": False,
                        "example": "NSE_INDEX|Nifty 50",
                        "description": (
                            "Direct instrument key. Use URL encoding for pipe and spaces."
                        ),
                    },
                    "strike": {
                        "required": False,
                        "example": 24500,
                        "description": (
                            "Option strike. Used only when instrument_key is not provided."
                        ),
                    },
                    "striketype": {
                        "required": False,
                        "example": "ce",
                        "allowed_values": ["ce", "pe", "CE", "PE"],
                        "description": (
                            "Option type. Used only when instrument_key is not provided."
                        ),
                    },
                },
                "description": (
                    "Streams Opening Range events for one resolved instrument only. "
                    "This does not automatically mean the instrument is isolated."
                ),
                "sample_connected_response": {
                    "type": "connected",
                    "endpoint": "/ws/opening-range/instrument",
                    "instrument_key": "NSE_INDEX|Nifty 50",
                    "message": (
                        "Connected to instrument-specific Opening Range feed. "
                        "Waiting for opening range events."
                    ),
                },
            },
            {
                "name": "Instrument-Specific Opening Range Feed By Strike",
                "endpoint": "/ws/opening-range/instrument",
                "method": "WebSocket",
                "url": (
                    f"{base_ws_url}/ws/opening-range/instrument"
                    f"?strike=24500&striketype=ce"
                ),
                "alternate_examples": [
                    (
                        f"{base_ws_url}/ws/opening-range/instrument"
                        f"?strike=24500&striketype=pe"
                    )
                ],
                "description": (
                    "Resolves option instrument from options_cache using strike and CE/PE type, "
                    "then streams Opening Range events only for that resolved instrument."
                ),
            },
        ],
        "related_http_endpoints": {
            "health": "GET /health",
            "opening_range_status": "GET /opening-range/status",
            "opening_range_config": "GET /opening-range/config",
            "opening_range_dashboard": "GET /opening-range/dashboard",
            "manual_opening_range_fetch": (
                "POST /opening-range/fetch?candle_count=1&save_results=true&max_workers=8"
            ),
            "opening_range_ema_context": (
                "GET /opening-range/ema-context?strike=24500&striketype=ce"
            ),
            "opening_range_isolated_instrument": (
                "GET /opening-range/isolated-instrument"
            ),
            "opening_range_isolated_ema_alerts": (
                "GET /opening-range/isolated-instrument/ema-alerts?limit=100"
            ),
            "live_ema_events": (
                "GET /history/live-ema/events?limit=100&include_opening_range=true"
            ),
            "live_ema_instrument": (
                "GET /history/live-ema/instrument?strike=24500&striketype=ce"
                "&include_opening_range=true"
            ),
        },
        "browser_javascript_examples": {
            "all_feeds": {
                "description": "Simple browser JavaScript example for all feeds.",
                "code": (
                    "const ws = new WebSocket('"
                    f"{base_ws_url}/all-feeds"
                    "');\n"
                    "ws.onopen = () => console.log('connected to all feeds');\n"
                    "ws.onmessage = (event) => console.log(JSON.parse(event.data));\n"
                    "ws.onerror = (error) => console.error(error);\n"
                    "ws.onclose = () => console.log('closed');"
                ),
            },
            "ema_crossover": {
                "description": (
                    "Browser JavaScript example for global EMA crossover feed. "
                    "Each event can include opening_range, touch_status, and isolated_instrument."
                ),
                "code": (
                    "const emaWs = new WebSocket('"
                    f"{base_ws_url}/ws/ema-crossover"
                    "');\n"
                    "emaWs.onopen = () => console.log('connected to EMA feed');\n"
                    "emaWs.onmessage = (event) => {\n"
                    "  const payload = JSON.parse(event.data);\n"
                    "  console.log('EMA event:', payload);\n"
                    "  console.log('Opening Range:', payload.opening_range);\n"
                    "  console.log('Isolated Instrument:', payload.isolated_instrument);\n"
                    "};\n"
                    "emaWs.onerror = (error) => console.error(error);\n"
                    "emaWs.onclose = () => console.log('EMA feed closed');"
                ),
            },
            "opening_range": {
                "description": "Browser JavaScript example for global Opening Range feed.",
                "code": (
                    "const orWs = new WebSocket('"
                    f"{base_ws_url}/ws/opening-range"
                    "');\n"
                    "orWs.onopen = () => console.log('connected to OR feed');\n"
                    "orWs.onmessage = (event) => {\n"
                    "  const payload = JSON.parse(event.data);\n"
                    "  console.log('Opening Range event:', payload);\n"
                    "};\n"
                    "orWs.onerror = (error) => console.error(error);\n"
                    "orWs.onclose = () => console.log('OR feed closed');"
                ),
            },
        },
        "websocat_examples": [
            f"websocat {base_ws_url}/all-feeds",
            f"websocat '{base_ws_url}/option?strike=24500&striketype=ce'",
            f"websocat {base_ws_url}/ws/ema-crossover",
            (
                f"websocat '{base_ws_url}/ws/ema-crossover/instrument"
                f"?strike=24500&striketype=ce'"
            ),
            f"websocat {base_ws_url}/ws/opening-range",
            (
                f"websocat '{base_ws_url}/ws/opening-range/instrument"
                f"?strike=24500&striketype=ce'"
            ),
        ],
    }
