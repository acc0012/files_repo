import html
from datetime import datetime
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

import requests

from core import config
from core.logger import get_logger

logger = get_logger(__file__)


class TelegramService:
    """
    Telegram notification service.

    Used for sending project lifecycle, scheduler, token, instrument,
    subscription, refresh, Opening Range job status, isolated instrument
    selection, isolated EMA crossover alerts, shutdown, and error notifications.

    Current behavior:
    - Normal main-flow Telegram notifications remain unchanged.
    - Sends Telegram notification when one Opening Range instrument is isolated.
    - Sends EMA Telegram alerts only for the isolated instrument.
    - Other instruments can continue live EMA processing and WebSocket broadcast,
      but should not trigger Telegram EMA alerts.

    Live EMA calculation mode:
    - LIVE_EMA_CALCULATION_MODE=False means completed candle close based EMA.
    - LIVE_EMA_CALCULATION_MODE=True means live tick/LTP based EMA.

    Updated isolated EMA alert behavior:
    - Bullish EMA on isolated option suggests same side entry.
    - Bearish EMA on isolated option suggests opposite side entry.
    - Suggested instruments are formatted in a simple one-look Telegram layout.
    """

    def __init__(self):
        self.bot_token = config.TELEGRAM_BOT_TOKEN
        self.chat_id = config.TELEGRAM_CHAT_ID
        self.enabled = config.TELEGRAM_ENABLED

        self.timeout_seconds = int(getattr(config, "TELEGRAM_TIMEOUT_SECONDS", 10))

        self.market_timezone = self._load_market_timezone()
        self.market_time_format = getattr(
            config,
            "MARKET_TIME_FORMAT",
            "%Y-%m-%d %H:%M:%S %Z",
        )

        self.api_url = (
            f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
            if self.bot_token
            else None
        )

    # ========================================================
    # Time / Config Helpers
    # ========================================================

    def _load_market_timezone(self):
        """Loads market timezone from config, defaulting to Asia/Kolkata."""

        timezone_name = getattr(config, "MARKET_TIMEZONE", "Asia/Kolkata")

        try:
            return ZoneInfo(timezone_name)

        except ZoneInfoNotFoundError:
            logger.error(
                f"Invalid MARKET_TIMEZONE configured: {timezone_name}. "
                "Falling back to Asia/Kolkata."
            )
            return ZoneInfo("Asia/Kolkata")

    def _now_market_time(self) -> str:
        """Returns current market time as formatted string."""

        return datetime.now(self.market_timezone).strftime(self.market_time_format)

    def _now_readable_market_time(self) -> str:
        """
        Returns current market time in simple readable format.

        Example:
            12 Aug 2026, 01:46:09 PM IST
        """

        return datetime.now(self.market_timezone).strftime("%d %b %Y, %I:%M:%S %p IST")

    def _format_datetime_ist(self, value) -> str:
        """
        Formats timestamp into readable IST format.

        Accepts:
            - ISO string with timezone
            - ISO string without timezone
            - datetime object

        Output:
            12 Aug 2026, 01:44:00 PM IST
        """

        if not value:
            return "not_available"

        try:
            if isinstance(value, datetime):
                dt_obj = value
            else:
                text = str(value).strip()

                if text.endswith("Z"):
                    text = text.replace("Z", "+00:00")

                dt_obj = datetime.fromisoformat(text)

            if dt_obj.tzinfo is None:
                dt_obj = dt_obj.replace(tzinfo=self.market_timezone)
            else:
                dt_obj = dt_obj.astimezone(self.market_timezone)

            return dt_obj.strftime("%d %b %Y, %I:%M:%S %p IST")

        except Exception:
            return str(value)

    def is_configured(self) -> bool:
        """Returns True if Telegram service has required configuration."""

        return bool(self.enabled and self.bot_token and self.chat_id and self.api_url)

    def _escape(self, value) -> str:
        """Escapes text for Telegram HTML parse mode."""

        return html.escape(str(value), quote=False)

    def _get_live_ema_calculation_mode(self) -> str:
        """
        Returns configured live EMA calculation mode.

        LIVE_EMA_CALCULATION_MODE=False:
            candle_close

        LIVE_EMA_CALCULATION_MODE=True:
            tick_ltp
        """

        tick_based_mode = bool(getattr(config, "LIVE_EMA_CALCULATION_MODE", False))

        return "tick_ltp" if tick_based_mode else "candle_close"

    def _get_live_ema_calculation_mode_description(
        self,
        mode: str | None = None,
    ) -> str:
        """Returns readable description for EMA calculation mode."""

        mode = mode or self._get_live_ema_calculation_mode()

        if mode == "tick_ltp":
            return "Live tick/LTP based EMA cross detection"

        return "Completed candle close based EMA cross detection"

    def _get_ema_mode_label(self, mode: str | None = None) -> str:
        """
        Returns short readable EMA mode label.

        Example:
            candle_close -> Candle Close
            tick_ltp -> Tick LTP
        """

        mode = mode or self._get_live_ema_calculation_mode()

        if mode == "tick_ltp":
            return "Tick LTP"

        return "Candle Close"

    def _format_number(self, value, default: str = "not_available") -> str:
        """
        Formats numeric value safely.

        Keeps normal decimal form without forcing too many decimals.
        """

        if value is None:
            return default

        try:
            number = float(value)

            if number.is_integer():
                return str(int(number))

            return str(round(number, 4))

        except Exception:
            return str(value)

    def _format_strike_type(self, strike, instrument_type) -> str:
        """
        Formats strike and option type.

        Example:
            24550 PE
        """

        strike_text = self._format_number(strike, default="N/A")
        type_text = str(instrument_type or "N/A").upper()

        return f"{strike_text} {type_text}"

    def _format_signal(self, signal: str | None, cross_type: str | None = None) -> str:
        """
        Returns simple readable signal.

        Example:
            bullish -> Bullish
            bearish_cross -> Bearish
        """

        signal_text = str(signal or "").strip().lower()
        cross_text = str(cross_type or "").strip().lower()

        if "bullish" in signal_text or "bullish" in cross_text:
            return "Bullish"

        if "bearish" in signal_text or "bearish" in cross_text:
            return "Bearish"

        if signal:
            return str(signal).replace("_", " ").title()

        return "N/A"

    # ========================================================
    # Raw Send Helper
    # ========================================================

    def _send_raw_message(self, message: str) -> bool:
        """
        Sends raw HTML message to Telegram.

        Returns:
            True if message was sent successfully, False otherwise.
        """

        if not self.is_configured():
            logger.warning(
                "Telegram notification skipped. "
                "Service is disabled or bot token/chat id is missing."
            )
            return False

        payload = {
            "chat_id": self.chat_id,
            "text": message,
            "parse_mode": "HTML",
            "disable_web_page_preview": True,
        }

        try:
            response = requests.post(
                self.api_url,
                json=payload,
                timeout=self.timeout_seconds,
            )

            if response.status_code != 200:
                logger.error(
                    f"Telegram send failed. "
                    f"status_code={response.status_code}, response={response.text}"
                )
                return False

            logger.info("Telegram notification sent successfully.")
            return True

        except Exception as ex:
            logger.error(f"Telegram send exception: {type(ex).__name__}: {ex}")
            return False

    def send_message(
        self,
        title: str,
        message: str,
        level: str = "INFO",
    ) -> bool:
        """
        Sends a formatted Telegram notification.

        Args:
            title: Notification title.
            message: Notification body.
            level: INFO, SUCCESS, WARNING, ERROR, STARTUP, REFRESH,
                   SUBSCRIPTION, TOKEN, INSTRUMENTS, EMA, OPENING_RANGE.
        """

        level_upper = str(level or "INFO").upper()

        emoji_map = {
            "INFO": "ℹ️",
            "SUCCESS": "✅",
            "WARNING": "⚠️",
            "ERROR": "❌",
            "STARTUP": "🚀",
            "REFRESH": "🔄",
            "SUBSCRIPTION": "📡",
            "TOKEN": "🔐",
            "INSTRUMENTS": "📊",
            "SHUTDOWN": "🛑",
            "EMA": "📈",
            "OPENING_RANGE": "🎯",
        }

        emoji = emoji_map.get(level_upper, "ℹ️")

        safe_title = self._escape(title)
        safe_message = self._escape(message)
        market_time = self._escape(self._now_readable_market_time())

        formatted_message = (
            f"{emoji} <b>{safe_title}</b>\n\n"
            f"{safe_message}\n\n"
            f"<b>Level:</b> {self._escape(level_upper)}\n"
            f"<b>Time:</b> {market_time}"
        )

        return self._send_raw_message(formatted_message)

    # ========================================================
    # Application Lifecycle Messages
    # ========================================================

    def send_startup_message(self, status: str, details: str = "") -> bool:
        """Sends application startup notification."""

        message = f"Application startup status: {status}"

        if details:
            message += f"\n\n{details}"

        return self.send_message(
            title="Option Feed Engine Startup",
            message=message,
            level="STARTUP",
        )

    def send_shutdown_message(self, details: str = "") -> bool:
        """Sends application shutdown notification."""

        message = "Application shutdown sequence executed."

        if details:
            message += f"\n\n{details}"

        return self.send_message(
            title="Option Feed Engine Shutdown",
            message=message,
            level="SHUTDOWN",
        )

    # ========================================================
    # Token / Instrument / Subscription Messages
    # ========================================================

    def send_token_refresh_message(
        self,
        success: bool,
        updated_at=None,
        error: str = "",
    ) -> bool:
        """Sends token refresh notification."""

        if success:
            message = "Access token document refreshed successfully from MongoDB."

            if updated_at:
                message += f"\nToken Updated At: {updated_at}"

            return self.send_message(
                title="Token Refresh Successful",
                message=message,
                level="TOKEN",
            )

        message = "Access token refresh failed."

        if error:
            message += f"\nError: {error}"

        return self.send_message(
            title="Token Refresh Failed",
            message=message,
            level="ERROR",
        )

    def send_instruments_fetched_message(
        self,
        success: bool,
        nearest_expiry=None,
        total_contracts=0,
        subscribed_keys_count=0,
        strike_from=None,
        strike_to=None,
        error: str = "",
    ) -> bool:
        """Sends option instruments fetch notification."""

        if success:
            message = (
                "Option instruments fetched and cache updated successfully.\n\n"
                f"Nearest Expiry: {nearest_expiry}\n"
                f"Total Contracts: {total_contracts}\n"
                f"Subscribed Keys: {subscribed_keys_count}\n"
                f"Strike Range: {strike_from} to {strike_to}"
            )

            return self.send_message(
                title="Instruments Fetch Successful",
                message=message,
                level="INSTRUMENTS",
            )

        message = "Option instruments fetch failed."

        if error:
            message += f"\nError: {error}"

        return self.send_message(
            title="Instruments Fetch Failed",
            message=message,
            level="ERROR",
        )

    def send_subscription_message(
        self,
        success: bool,
        subscribed_keys_count=0,
        feed_mode=None,
        error: str = "",
    ) -> bool:
        """Sends Upstox subscription or streamer restart notification."""

        if success:
            message = (
                "Upstox streamer subscription is active.\n\n"
                f"Subscribed Instruments: {subscribed_keys_count}\n"
                f"Feed Mode: {feed_mode}"
            )

            return self.send_message(
                title="Feed Subscription Successful",
                message=message,
                level="SUBSCRIPTION",
            )

        message = "Upstox feed subscription failed."

        if error:
            message += f"\nError: {error}"

        return self.send_message(
            title="Feed Subscription Failed",
            message=message,
            level="ERROR",
        )

    # ========================================================
    # Refresh Messages
    # ========================================================

    def send_daily_refresh_message(
        self,
        success: bool,
        subscribed_keys_count=0,
        nearest_expiry=None,
        error: str = "",
    ) -> bool:
        """Sends daily hard refresh notification."""

        if success:
            message = (
                "Daily market hard refresh completed successfully.\n\n"
                f"Nearest Expiry: {nearest_expiry}\n"
                f"Subscribed Instruments: {subscribed_keys_count}"
            )

            return self.send_message(
                title="Daily Market Hard Refresh Successful",
                message=message,
                level="REFRESH",
            )

        message = "Daily market hard refresh failed."

        if error:
            message += f"\nError: {error}"

        return self.send_message(
            title="Daily Market Hard Refresh Failed",
            message=message,
            level="ERROR",
        )

    # ========================================================
    # Opening Range Isolated Instrument Messages
    # ========================================================

    def send_selected_or_instrument_message(
        self,
        instrument_key: str,
        symbol: str,
        level: str,
        level_value,
        trigger_field: str,
        trigger_price,
        touch_time,
        source: str,
        nifty_ltp=None,
        strike_price=None,
        instrument_type=None,
        reference_average=None,
        average_window=None,
    ) -> bool:
        """
        Sends Telegram notification when an Opening Range instrument is isolated.

        Selection logic is handled outside this service:
        - Average +/- configured window.
        - R3/S3 priority before R2/S2.
        - Nearest strike to Opening Range average.
        - Day-level isolated instrument.
        """

        if not bool(
            getattr(config, "OPENING_RANGE_ISOLATED_INSTRUMENT_NOTIFY_ENABLED", True)
        ):
            logger.info(
                "Isolated instrument Telegram notification skipped because "
                "OPENING_RANGE_ISOLATED_INSTRUMENT_NOTIFY_ENABLED=False."
            )
            return False

        strike_type_text = self._format_strike_type(strike_price, instrument_type)

        window_text = "not_available"

        if isinstance(average_window, dict):
            window_text = (
                f"{self._format_number(average_window.get('final_lower'))} to "
                f"{self._format_number(average_window.get('final_upper'))}"
            )

        readable_touch_time = self._format_datetime_ist(touch_time)

        message = (
            f"Selected Instrument: {strike_type_text}\n"
            f"Level Touched: {level}\n"
            f"Level Value: {self._format_number(level_value)}\n"
            f"Trigger {trigger_field}: {self._format_number(trigger_price)}\n"
            f"NIFTY Spot: {self._format_number(nifty_ltp)}\n\n"
            "-----------------------\n"
            "Selection Reason\n"
            "-----------------------\n"
            "R3/S3 has higher priority than R2/S2.\n"
            "If multiple instruments qualify, nearest strike to Opening Range average is selected.\n\n"
            f"Symbol: {symbol}\n"
            f"Instrument Key: {instrument_key}\n"
            f"Touch Source: {source}\n"
            f"Touch Time: {readable_touch_time}\n"
            f"Opening Range Average: {self._format_number(reference_average)}\n"
            f"Average Window: {window_text}\n\n"
            "From now, EMA Telegram alerts will be sent only for this isolated instrument."
        )

        return self.send_message(
            title="Opening Range Instrument Isolated",
            message=message,
            level="OPENING_RANGE",
        )

    def send_selected_or_ema_cross_message(
        self,
        selected_state: dict,
        ema_event: dict,
        nifty_ltp=None,
        suggested_order_instruments: list | None = None,
    ) -> bool:
        """
        Sends EMA crossover Telegram alert for isolated instrument only.

        Updated alert behavior:
        - Bullish EMA on isolated option means same side momentum.
        - Bearish EMA on isolated option means isolated side weakness,
          so opposite side is suggested.
        """

        if not bool(getattr(config, "EMA_ISOLATED_INSTRUMENT_TELEGRAM_ENABLED", True)):
            logger.info(
                "Isolated EMA Telegram notification skipped because "
                "EMA_ISOLATED_INSTRUMENT_TELEGRAM_ENABLED=False."
            )
            return False

        selected_state = selected_state or {}
        ema_event = ema_event or {}
        suggested_order_instruments = suggested_order_instruments or []

        contract_info = (
            selected_state.get("contract_info")
            or ema_event.get("contract_info")
            or ema_event.get("info")
            or {}
        )

        strike = contract_info.get("strike_price", "N/A")
        instrument_type = str(contract_info.get("instrument_type", "N/A")).upper()

        selected_level = selected_state.get("selected_level", "N/A")
        instrument_key = ema_event.get("instrument_key") or selected_state.get(
            "instrument_key"
        )

        cross_type = ema_event.get("cross_type", "N/A")
        current_signal = ema_event.get("current_signal", "N/A")
        close_price = ema_event.get("close")
        event_timestamp = ema_event.get("timestamp")

        ema_mode = ema_event.get(
            "ema_calculation_mode",
            self._get_live_ema_calculation_mode(),
        )

        if ema_mode == "tick_ltp":
            price_label = "Live Tick LTP"
            time_label = "Tick Time"
        else:
            price_label = "EMA Candle Close"
            time_label = "EMA Candle Time"

        signal_text = self._format_signal(current_signal, cross_type)
        ema_mode_label = self._get_ema_mode_label(ema_mode)
        readable_event_time = self._format_datetime_ist(event_timestamp)
        strike_type_text = self._format_strike_type(strike, instrument_type)
        nifty_text = self._format_number(nifty_ltp, default="NIFTY_LTP_NOT_AVAILABLE")

        entry_side = self._get_entry_side_from_suggestions(suggested_order_instruments)
        entry_reason = self._get_entry_reason_from_suggestions(
            suggested_order_instruments
        )

        header = (
            f"{strike_type_text} - crossed {selected_level}\nNIFTY Spot: {nifty_text}"
        )

        order_details_text = self._format_suggested_order_instruments(
            suggested_order_instruments
        )

        message = (
            f"{header}\n\n"
            "-----------------------\n"
            "EMA Cross Details\n"
            "-----------------------\n"
            f"Signal: {signal_text}\n"
            f"EMA Calculation Mode: {ema_mode}\n"
            f"EMA Mode: {ema_mode_label}\n"
            f"{price_label}: {self._format_number(close_price)}\n"
            f"{time_label}: {readable_event_time}\n\n"
            f"Instrument Key: {instrument_key}\n"
            f"Strike: {strike_type_text}\n\n"
            "-----------------------\n"
            "Entry Side Suggestion\n"
            "-----------------------\n"
            f"Entry Side: {entry_side}\n"
            f"Reason: {entry_reason}\n\n"
            f"{order_details_text}"
        )

        return self.send_message(
            title="Isolated Instrument EMA Alert",
            message=message,
            level="EMA",
        )

    def send_isolated_instrument_message(
        self,
        isolated_state: dict,
    ) -> bool:
        """
        Convenience wrapper for isolated instrument notification.

        This allows opening_range_service.py to pass the full isolated state
        instead of individual fields.
        """

        isolated_state = isolated_state or {}
        contract_info = isolated_state.get("contract_info") or {}

        symbol = (
            contract_info.get("trading_symbol")
            or contract_info.get("instrument_key")
            or isolated_state.get("instrument_key")
            or "N/A"
        )

        return self.send_selected_or_instrument_message(
            instrument_key=isolated_state.get("instrument_key"),
            symbol=symbol,
            level=isolated_state.get("selected_level"),
            level_value=isolated_state.get("level_value"),
            trigger_field=isolated_state.get("trigger_field"),
            trigger_price=isolated_state.get("trigger_price"),
            touch_time=isolated_state.get("touch_time"),
            source=isolated_state.get("touch_source"),
            nifty_ltp=isolated_state.get("latest_main_index_ltp"),
            strike_price=contract_info.get("strike_price"),
            instrument_type=contract_info.get("instrument_type"),
            reference_average=isolated_state.get("reference_average"),
            average_window=isolated_state.get("average_window"),
        )

    def send_isolated_ema_cross_message(
        self,
        isolated_state: dict,
        ema_event: dict,
        nifty_ltp=None,
        suggested_order_instruments: list | None = None,
    ) -> bool:
        """
        Convenience wrapper for isolated instrument EMA alert.
        """

        return self.send_selected_or_ema_cross_message(
            selected_state=isolated_state,
            ema_event=ema_event,
            nifty_ltp=nifty_ltp,
            suggested_order_instruments=suggested_order_instruments,
        )

    # ========================================================
    # Formatting Helpers
    # ========================================================

    def _get_entry_side_from_suggestions(
        self,
        suggested_order_instruments: list,
    ) -> str:
        """
        Gets entry side from suggested order instruments.

        The new option_service.py adds:
            entry_side
        """

        for item in suggested_order_instruments or []:
            if not isinstance(item, dict):
                continue

            entry_side = item.get("entry_side") or item.get("instrument_type")

            if entry_side:
                return str(entry_side).upper()

        return "not_available"

    def _get_entry_reason_from_suggestions(
        self,
        suggested_order_instruments: list,
    ) -> str:
        """
        Gets entry side reason from suggested order instruments.

        The new option_service.py adds:
            entry_side_reason
        """

        for item in suggested_order_instruments or []:
            if not isinstance(item, dict):
                continue

            reason = item.get("entry_side_reason")

            if reason:
                return str(reason)

        return "Entry side selected from isolated instrument EMA signal."

    def _format_suggested_order_instruments(
        self,
        suggested_order_instruments: list,
    ) -> str:
        """
        Formats nearest CE/PE instruments for EMA alert.

        Example:
            Nearest Instrument Details:
            - 24300PE - 120rs
            - 24350PE - 135rs
            - 24400PE - 150rs
        """

        if not suggested_order_instruments:
            return "Nearest Instrument Details:\n- not_available"

        lines = ["Nearest Instrument Details:"]

        for item in suggested_order_instruments:
            if not isinstance(item, dict):
                continue

            strike = self._format_number(item.get("strike_price", "N/A"))
            instrument_type = str(item.get("instrument_type", "N/A")).upper()
            live_ltp = item.get("live_ltp")

            if live_ltp is None:
                price_text = "ltp_not_available"
            else:
                price_text = f"{self._format_number(live_ltp)}rs"

            lines.append(f"- {strike}{instrument_type} - {price_text}")

        if len(lines) == 1:
            return "Nearest Instrument Details:\n- not_available"

        return "\n".join(lines)

    # ========================================================
    # Exception Messages
    # ========================================================

    def send_exception_message(
        self,
        title: str,
        exception: Exception,
        context: str = "",
    ) -> bool:
        """Sends exception notification."""

        message = (
            f"Exception Type: {type(exception).__name__}\n"
            f"Exception Message: {exception}"
        )

        if context:
            message = f"Context: {context}\n\n{message}"

        return self.send_message(
            title=title,
            message=message,
            level="ERROR",
        )


telegram_service = TelegramService()
