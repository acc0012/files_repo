from datetime import datetime, timedelta
from typing import Any

import upstox_client
from upstox_client.rest import ApiException

from fastapi import APIRouter, HTTPException, Query

from core import config
from core.logger import get_logger
from services.option_service import options_cache
from services.token_service import token_service

logger = get_logger(__file__)

router = APIRouter(
    prefix="/upstox",
    tags=["Upstox App"],
)


# ============================================================
# Basic Helpers
# ============================================================


def response_to_dict(api_response: Any) -> dict:
    """
    Converts Upstox SDK response object to dictionary safely.
    """

    if api_response is None:
        return {}

    if hasattr(api_response, "to_dict"):
        return api_response.to_dict()

    if isinstance(api_response, dict):
        return api_response

    try:
        return dict(api_response)
    except Exception:
        return {}


def extract_candles_from_response(api_response: Any) -> list:
    """
    Extracts candle list from Upstox historical or intraday response.
    """

    response_dict = response_to_dict(api_response)
    data = response_dict.get("data", {})

    if isinstance(data, dict):
        candles = data.get("candles", [])
        return candles if isinstance(candles, list) else []

    return []


def normalize_option_type(striketype: str | None) -> str | None:
    """
    Normalizes option type.
    """

    if not striketype:
        return None

    value = str(striketype).strip().upper()

    if value in ["CE", "CALL"]:
        return "CE"

    if value in ["PE", "PUT"]:
        return "PE"

    return None


def resolve_instrument_key(
    instrument_key: str | None = None,
    strike: float | None = None,
    striketype: str | None = None,
) -> tuple[str, dict]:
    """
    Resolves Upstox instrument key from either:

    1. Direct instrument_key
       Example:
           NSE_FO|45115
           NSE_INDEX|Nifty 50

    2. strike + striketype
       Example:
           strike=24550, striketype=pe
    """

    if instrument_key:
        contract_info = get_contract_info_for_key(instrument_key)
        return instrument_key, contract_info

    if strike is None or not striketype:
        raise HTTPException(
            status_code=400,
            detail=(
                "Provide either instrument_key or both strike and striketype. "
                "Example: /upstox/history/candles?strike=24550&striketype=pe&from_date=2026-08-01&to_date=2026-08-12"
            ),
        )

    option_type = normalize_option_type(striketype)

    if option_type not in ["CE", "PE"]:
        raise HTTPException(
            status_code=400,
            detail="Invalid striketype. Allowed values: ce, pe, CE, PE.",
        )

    try:
        target_strike = float(strike)
    except Exception:
        raise HTTPException(
            status_code=400,
            detail="Invalid strike value.",
        )

    cache_data = options_cache.get("data", [])

    for item in cache_data:
        try:
            item_strike = float(item.get("strike_price"))
            item_type = normalize_option_type(item.get("instrument_type"))

            if item_strike == target_strike and item_type == option_type:
                resolved_key = item.get("instrument_key")

                if resolved_key:
                    return resolved_key, item

        except Exception:
            continue

    raise HTTPException(
        status_code=404,
        detail=(
            f"No option instrument found for strike={target_strike}, "
            f"striketype={option_type}. Make sure option contracts are loaded."
        ),
    )


def get_contract_info_for_key(instrument_key: str) -> dict:
    """
    Returns contract info for an instrument key.
    """

    main_key = getattr(config, "MAIN_NIFTY_SECURITY", "NSE_INDEX|Nifty 50")

    if instrument_key == main_key:
        return {
            "instrument_key": instrument_key,
            "instrument_type": "INDEX",
            "strike_price": None,
            "expiry": None,
            "trading_symbol": "NIFTY 50",
            "underlying_type": "INDEX",
            "underlying_symbol": "NIFTY 50",
        }

    for item in options_cache.get("data", []):
        if item.get("instrument_key") == instrument_key:
            return item

    return {
        "instrument_key": instrument_key,
    }


def get_upstox_api_client():
    """
    Creates Upstox ApiClient using current in-memory access token.
    """

    access_token = token_service.get_access_token()

    if not access_token:
        raise HTTPException(
            status_code=401,
            detail=(
                "Upstox access token not available. "
                "Run token refresh or check MongoDB token document."
            ),
        )

    configuration = upstox_client.Configuration()
    configuration.access_token = access_token

    return upstox_client.ApiClient(configuration)


def validate_date_text(value: str, field_name: str) -> str:
    """
    Validates date string in YYYY-MM-DD format.
    """

    try:
        datetime.strptime(value, "%Y-%m-%d")
        return value

    except Exception:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid {field_name}. Expected format: YYYY-MM-DD.",
        )


def build_date_batches(
    from_date: str,
    to_date: str,
    max_days_per_request: int,
) -> list:
    """
    Splits date range into smaller Upstox historical API batches.
    """

    from_date_obj = datetime.strptime(from_date, "%Y-%m-%d").date()
    to_date_obj = datetime.strptime(to_date, "%Y-%m-%d").date()

    if from_date_obj > to_date_obj:
        raise HTTPException(
            status_code=400,
            detail="from_date cannot be greater than to_date.",
        )

    batches = []
    current_from = from_date_obj

    while current_from <= to_date_obj:
        current_to = min(
            current_from + timedelta(days=max_days_per_request - 1),
            to_date_obj,
        )

        batches.append(
            {
                "from_date": current_from.strftime("%Y-%m-%d"),
                "to_date": current_to.strftime("%Y-%m-%d"),
            }
        )

        current_from = current_to + timedelta(days=1)

    return batches


# ============================================================
# Route Index
# ============================================================


@router.get("/candles/routes")
async def get_upstox_candle_routes():
    """
    Shows available Upstox candle helper routes.
    """

    return {
        "status": "success",
        "title": "Upstox Candle API Routes",
        "routes": {
            "historical_by_date_range": {
                "method": "GET",
                "path": "/upstox/history/candles",
                "description": (
                    "Fetch historical candles by date range using instrument_key "
                    "or strike + striketype."
                ),
                "examples": [
                    "/upstox/history/candles?instrument_key=NSE_INDEX%7CNifty%2050&interval=1minute&from_date=2026-08-01&to_date=2026-08-12",
                    "/upstox/history/candles?strike=24550&striketype=pe&interval=1minute&from_date=2026-08-01&to_date=2026-08-12",
                ],
            },
            "historical_by_days": {
                "method": "GET",
                "path": "/upstox/history/candles-by-days",
                "description": (
                    "Fetch historical candles for last N calendar days using "
                    "instrument_key or strike + striketype."
                ),
                "examples": [
                    "/upstox/history/candles-by-days?instrument_key=NSE_INDEX%7CNifty%2050&interval=1minute&days=5",
                    "/upstox/history/candles-by-days?strike=24550&striketype=pe&interval=1minute&days=5",
                ],
            },
            "intraday": {
                "method": "GET",
                "path": "/upstox/intraday/candles",
                "description": (
                    "Fetch today's intraday candles using instrument_key "
                    "or strike + striketype."
                ),
                "examples": [
                    "/upstox/intraday/candles?instrument_key=NSE_INDEX%7CNifty%2050&unit=minutes&interval=1",
                    "/upstox/intraday/candles?strike=24550&striketype=pe&unit=minutes&interval=1",
                ],
            },
        },
    }


# ============================================================
# Historical Candles by Date Range
# ============================================================


@router.get("/history/candles")
async def get_upstox_historical_candles(
    instrument_key: str = Query(
        default=None,
        description="Instrument key, e.g. NSE_FO|45115 or NSE_INDEX|Nifty 50.",
    ),
    strike: float = Query(
        default=None,
        description="Option strike price, e.g. 24550. Optional if instrument_key is given.",
    ),
    striketype: str = Query(
        default=None,
        description="Option type: ce or pe. Optional if instrument_key is given.",
    ),
    interval: str = Query(
        default="1minute",
        description="Historical candle interval, e.g. 1minute, 3minute, 5minute, 15minute.",
    ),
    from_date: str = Query(
        ...,
        description="Start date in YYYY-MM-DD format.",
    ),
    to_date: str = Query(
        ...,
        description="End date in YYYY-MM-DD format.",
    ),
    api_version: str = Query(
        default=None,
        description="Upstox historical API version. Default comes from config.",
    ),
    max_days_per_request: int = Query(
        default=None,
        ge=1,
        le=30,
        description="Date batch size. Default comes from config.",
    ),
):
    """
    Fetches historical candles for a given instrument.

    Supports:
        1. instrument_key
        2. strike + striketype
    """

    resolved_key, contract_info = resolve_instrument_key(
        instrument_key=instrument_key,
        strike=strike,
        striketype=striketype,
    )

    from_date = validate_date_text(from_date, "from_date")
    to_date = validate_date_text(to_date, "to_date")

    selected_api_version = api_version or getattr(
        config,
        "HISTORICAL_CANDLE_API_VERSION",
        "2.0",
    )

    selected_max_days = max_days_per_request or int(
        getattr(config, "HISTORICAL_CANDLE_MAX_DAYS_PER_REQUEST", 7)
    )

    api_client = get_upstox_api_client()
    api_instance = upstox_client.HistoryApi(api_client)

    batches = build_date_batches(
        from_date=from_date,
        to_date=to_date,
        max_days_per_request=selected_max_days,
    )

    all_candles = []
    batch_results = []
    errors = []

    for batch in batches:
        batch_from = batch["from_date"]
        batch_to = batch["to_date"]

        try:
            api_response = api_instance.get_historical_candle_data1(
                resolved_key,
                interval,
                batch_to,
                batch_from,
                selected_api_version,
            )

            candles = extract_candles_from_response(api_response)
            all_candles.extend(candles)

            batch_results.append(
                {
                    "from_date": batch_from,
                    "to_date": batch_to,
                    "status": "success" if candles else "empty",
                    "candles_count": len(candles),
                }
            )

        except ApiException as ex:
            error_body = getattr(ex, "body", str(ex))

            errors.append(
                {
                    "from_date": batch_from,
                    "to_date": batch_to,
                    "error": error_body,
                }
            )

            batch_results.append(
                {
                    "from_date": batch_from,
                    "to_date": batch_to,
                    "status": "failed",
                    "candles_count": 0,
                    "error": error_body,
                }
            )

        except Exception as ex:
            error_message = f"{type(ex).__name__}: {ex}"

            errors.append(
                {
                    "from_date": batch_from,
                    "to_date": batch_to,
                    "error": error_message,
                }
            )

            batch_results.append(
                {
                    "from_date": batch_from,
                    "to_date": batch_to,
                    "status": "failed",
                    "candles_count": 0,
                    "error": error_message,
                }
            )

    overall_status = "success"

    if errors and all_candles:
        overall_status = "partial_success"
    elif errors and not all_candles:
        overall_status = "failed"
    elif not all_candles:
        overall_status = "empty"

    return {
        "status": overall_status,
        "source": "upstox_historical_api",
        "input": {
            "instrument_key": instrument_key,
            "strike": strike,
            "striketype": striketype,
            "interval": interval,
            "from_date": from_date,
            "to_date": to_date,
            "api_version": selected_api_version,
            "max_days_per_request": selected_max_days,
        },
        "resolved": {
            "instrument_key": resolved_key,
            "contract_info": contract_info,
        },
        "batches": batch_results,
        "candles_count": len(all_candles),
        "candles": all_candles,
        "errors": errors,
    }


# ============================================================
# Historical Candles by Number of Days
# ============================================================


@router.get("/history/candles-by-days")
async def get_upstox_historical_candles_by_days(
    instrument_key: str = Query(
        default=None,
        description="Instrument key, e.g. NSE_FO|45115 or NSE_INDEX|Nifty 50.",
    ),
    strike: float = Query(
        default=None,
        description="Option strike price, e.g. 24550. Optional if instrument_key is given.",
    ),
    striketype: str = Query(
        default=None,
        description="Option type: ce or pe. Optional if instrument_key is given.",
    ),
    interval: str = Query(
        default="1minute",
        description="Historical candle interval, e.g. 1minute, 3minute, 5minute, 15minute.",
    ),
    days: int = Query(
        default=5,
        ge=1,
        le=365,
        description="Number of calendar days ending today.",
    ),
    api_version: str = Query(
        default=None,
        description="Upstox historical API version. Default comes from config.",
    ),
    max_days_per_request: int = Query(
        default=None,
        ge=1,
        le=30,
        description="Date batch size. Default comes from config.",
    ),
):
    """
    Fetches historical candles for last N calendar days.
    """

    today = datetime.now().date()
    from_date = today - timedelta(days=days - 1)
    to_date = today

    return await get_upstox_historical_candles(
        instrument_key=instrument_key,
        strike=strike,
        striketype=striketype,
        interval=interval,
        from_date=from_date.strftime("%Y-%m-%d"),
        to_date=to_date.strftime("%Y-%m-%d"),
        api_version=api_version,
        max_days_per_request=max_days_per_request,
    )


# ============================================================
# Intraday Candles
# ============================================================


@router.get("/intraday/candles")
async def get_upstox_intraday_candles(
    instrument_key: str = Query(
        default=None,
        description="Instrument key, e.g. NSE_FO|45115 or NSE_INDEX|Nifty 50.",
    ),
    strike: float = Query(
        default=None,
        description="Option strike price, e.g. 24550. Optional if instrument_key is given.",
    ),
    striketype: str = Query(
        default=None,
        description="Option type: ce or pe. Optional if instrument_key is given.",
    ),
    unit: str = Query(
        default="minutes",
        description="Intraday unit. Common value: minutes.",
    ),
    interval: str = Query(
        default="1",
        description="Intraday interval. Example: 1, 3, 5, 15, 30.",
    ),
):
    """
    Fetches today's intraday candles for a given instrument.

    Supports:
        1. instrument_key
        2. strike + striketype
    """

    resolved_key, contract_info = resolve_instrument_key(
        instrument_key=instrument_key,
        strike=strike,
        striketype=striketype,
    )

    api_client = get_upstox_api_client()
    api_instance = upstox_client.HistoryV3Api(api_client)

    try:
        api_response = api_instance.get_intra_day_candle_data(
            resolved_key,
            unit,
            interval,
        )

        candles = extract_candles_from_response(api_response)

        return {
            "status": "success" if candles else "empty",
            "source": "upstox_intraday_api",
            "input": {
                "instrument_key": instrument_key,
                "strike": strike,
                "striketype": striketype,
                "unit": unit,
                "interval": interval,
            },
            "resolved": {
                "instrument_key": resolved_key,
                "contract_info": contract_info,
            },
            "candles_count": len(candles),
            "candles": candles,
            "error": None,
        }

    except ApiException as ex:
        error_body = getattr(ex, "body", str(ex))

        logger.error(
            f"Upstox intraday candle fetch failed for {resolved_key}: {error_body}"
        )

        raise HTTPException(
            status_code=500,
            detail={
                "message": "Upstox intraday candle fetch failed.",
                "instrument_key": resolved_key,
                "error": error_body,
            },
        )

    except Exception as ex:
        error_message = f"{type(ex).__name__}: {ex}"

        logger.error(
            f"Upstox intraday candle fetch failed for {resolved_key}: {error_message}"
        )

        raise HTTPException(
            status_code=500,
            detail={
                "message": "Upstox intraday candle fetch failed.",
                "instrument_key": resolved_key,
                "error": error_message,
            },
        )
