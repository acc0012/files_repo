import pandas as pd

def build_df(data):
    df = pd.DataFrame(data['data'])
    df['time'] = pd.to_datetime(df['time'])
    df['close'] = df['close'].astype(float)
    df['open'] = df['open'].astype(float)
    df['volume'] = df['volume'].astype(float)
    return df
