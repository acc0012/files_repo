import os
from dotenv import load_dotenv

load_dotenv()

class Settings:
    CLIENT_ID = os.getenv("CLIENT_ID")
    ACCESS_TOKEN = os.getenv("ACCESS_TOKEN")
    BASE_API_URL = os.getenv("BASE_API_URL")
    FEED_SOCKET_URL = os.getenv("FEED_SOCKET_URL")
    TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
    TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")
    TELE_FLAG = os.getenv("TELE_FLAG",False)
    
settings = Settings()
