import requests
from app.core.config import settings
from app.core.logger import get_logger

logger = get_logger("notifier")

# ✅ GLOBAL FLAG
TELEGRAM_ENABLED = settings.TELE_FLAG   # 🔥 change to True when needed

def send(msg):
    # =========================
    # ✅ FLAG CHECK
    # =========================
    if not TELEGRAM_ENABLED:
        logger.info("🔕 Telegram disabled → skipping message")
        return

    if not settings.TELEGRAM_TOKEN or not settings.TELEGRAM_CHAT_ID:
        logger.warning("⚠️ Telegram config missing")
        return

    try:
        url = f"https://api.telegram.org/bot{settings.TELEGRAM_TOKEN}/sendMessage"

        response = requests.post(
            url,
            json={
                "chat_id": settings.TELEGRAM_CHAT_ID,
                "text": msg
            },
            timeout=5
        )

        if response.status_code != 200:
            logger.error(f"❌ Telegram Error → {response.text}")

    except Exception as e:
        logger.error(f"❌ Telegram Exception → {str(e)}")