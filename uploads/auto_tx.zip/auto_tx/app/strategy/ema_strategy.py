def apply_strategy(df):
    df['ema9'] = df['close'].ewm(span=9).mean()
    df['ema21'] = df['close'].ewm(span=21).mean()
    df['ema50'] = df['close'].ewm(span=50).mean()
    df['vol_ma'] = df['volume'].rolling(20).mean()
    signals = []
    for i in range(1, len(df)):
        c = df.iloc[i]
        p = df.iloc[i-1]
        green = c['close'] > c['open']
        red = c['close'] < c['open']
        high_vol = c['volume'] > c['vol_ma']
        buy = p['ema9'] < p['ema21'] and c['ema9'] > c['ema21'] and c['close'] > c['ema50'] and green and high_vol
        sell = p['ema9'] > p['ema21'] and c['ema9'] < c['ema21'] and c['close'] < c['ema50'] and red and high_vol
        if buy:
            signals.append(('BUY', c['close'], str(c['time'])))
        elif sell:
            signals.append(('SELL', c['close'], str(c['time'])))
    return signals
