import requests
import urllib3

from app.core.config import settings
from app.core.logger import get_logger

# ✅ LOGGER
logger = get_logger("instrument_service")

# ✅ DISABLE SSL WARNING (DEV ONLY)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def get_security_id(index_id, strike, option_type):
    try:
        url = f"{settings.BASE_API_URL}/{index_id}/"

        payload = {
            "strike_price": int(strike),
            "option_type": str(option_type).lower()   # ✅ ensure correct format
        }

        # =========================
        # ✅ REQUEST DEBUG
        # =========================
        logger.info(f"🌐 API CALL → {url}")
        logger.info(f"📦 Payload → {payload}")

        # =========================
        # ✅ API CALL
        # =========================
        response = requests.post(
            url,
            json=payload,
            timeout=10,
            verify=False   # ✅ DEV MODE FIX
        )

        # =========================
        # ✅ RESPONSE DEBUG
        # =========================
        logger.info(f"📡 Status Code → {response.status_code}")

        try:
            response_data = response.json()
        except Exception:
            response_data = response.text  # ✅ fallback for HTML errors

        logger.info(f"📡 Response → {response_data}")

        # =========================
        # ✅ ERROR HANDLING
        # =========================
        if response.status_code != 200:
            raise Exception(f"API Error {response.status_code} → {response_data}")

        return response_data

    except Exception as e:
        logger.error(f"❌ Instrument API Failed → {str(e)}")
        return {}
