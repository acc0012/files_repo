def get_strikes(spot):
    base = int(spot / 50) * 50
    ce = base
    pe = base + 50
    return ce, pe
