spot_data = {'NIFTY': None, 'SENSEX': None}

def update_spot(index, price):
    spot_data[index] = price

def get_spot(index):
    return spot_data.get(index)
