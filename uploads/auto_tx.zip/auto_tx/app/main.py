from fastapi import FastAPI
from contextlib import asynccontextmanager
import asyncio

from app.engine.scheduler import start
from app.core.logger import get_logger

# ✅ LOGGER
logger = get_logger("main")


# =========================
# ✅ LIFESPAN (APP START)
# =========================
@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("🚀 Starting Auto Trader Application...")

    try:
        # ✅ Start background engine
        asyncio.create_task(start())

        logger.info("✅ Engine scheduler started")

    except Exception as e:
        logger.error(f"❌ Startup Error: {str(e)}")

    yield

    # ✅ Shutdown log (optional)
    logger.info("🛑 Shutting down Auto Trader Application...")


# =========================
# ✅ APP INIT
# =========================
app = FastAPI(
    title="Auto Trader Engine",
    lifespan=lifespan
)


# =========================
# ✅ HEALTH CHECK
# =========================
@app.get("/")
def home():
    return {
        "status": "running",
        "message": "✅ Auto Trader Running",
    }
