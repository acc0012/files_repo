import asyncio

from app.market.strike_selector import get_strikes
from app.market.spot_manager import get_spot
from app.market.instrument_service import get_security_id
from app.broker.dhan_client import get_intraday
from app.data.dataframe_builder import build_df
from app.strategy.ema_strategy import apply_strategy
from app.services.notifier import send
from app.core.logger import get_logger

# ✅ LOGGER
logger = get_logger("engine")

# ✅ STATE
state = {
    "ce": None,
    "pe": None,
    "last_spot": None   # ✅ track last spot for controlled logging
}


async def run_engine():

    logger.info("🚀 Auto Trader Engine Started")

    while True:
        try:
            # =========================
            # ✅ GET SPOT
            # =========================
            spot = get_spot("NIFTY")

            if not spot:
                logger.info("⏳ Waiting for spot data...")
                await asyncio.sleep(1)
                continue

            # =========================
            # ✅ LOG ONLY ON CHANGE
            # =========================
            if state["last_spot"] is None:
                logger.info(f"📊 Initial Spot → {spot}")

            elif spot != state["last_spot"]:
                logger.info(f"📊 Spot Changed → {spot}")

            # ✅ update last spot
            state["last_spot"] = spot

            # =========================
            # ✅ GET STRIKES
            # =========================
            ce, pe = get_strikes(spot)

            # =========================
            # ✅ CHECK FOR STRIKE CHANGE
            # =========================
            if ce != state["ce"] or pe != state["pe"]:

                logger.info("🎯 New Strike Selection Triggered")
                logger.info(f"👉 CE: {ce} | PE: {pe}")

                state["ce"], state["pe"] = ce, pe

                send(f"NEW STRIKES → CE: {ce}, PE: {pe}")

                # =========================
                # ✅ FETCH SECURITY IDs
                # =========================
                logger.info("📥 Fetching Instrument Details...")

                ce_info = get_security_id("13", ce, "ce")
                pe_info = get_security_id("13", pe, "pe")

                ce_id = ce_info.get("security_id")
                pe_id = pe_info.get("security_id")

                if not ce_id or not pe_id:
                    logger.error("❌ Failed to fetch security IDs")
                    await asyncio.sleep(2)
                    continue

                logger.info(f"✅ CE Security ID → {ce_id}")
                logger.info(f"✅ PE Security ID → {pe_id}")

                # =========================
                # ✅ FETCH INTRADAY DATA
                # =========================
                logger.info("📈 Fetching Intraday Data...")

                ce_raw = get_intraday(ce_id)
                pe_raw = get_intraday(pe_id)

                if not ce_raw or not pe_raw:
                    logger.error("❌ Intraday fetch failed")
                    await asyncio.sleep(2)
                    continue

                ce_df = build_df(ce_raw)
                pe_df = build_df(pe_raw)

                logger.info("✅ Historical Data Loaded")

                # =========================
                # ✅ APPLY STRATEGY
                # =========================
                logger.info("🧠 Running EMA Strategy...")

                ce_signals = apply_strategy(ce_df)
                pe_signals = apply_strategy(pe_df)

                # =========================
                # ✅ SIGNAL PROCESSING
                # =========================
                if ce_signals:
                    last = ce_signals[-1]
                    logger.info(f"🔥 CE SIGNAL → {last}")
                    send(f"CE SIGNAL: {last}")
                else:
                    logger.info("ℹ️ No CE signal")

                if pe_signals:
                    last = pe_signals[-1]
                    logger.info(f"🔥 PE SIGNAL → {last}")
                    send(f"PE SIGNAL: {last}")
                else:
                    logger.info("ℹ️ No PE signal")

        except Exception as e:
            logger.error(f"❌ Engine Error: {str(e)}")

        # =========================
        # ✅ LOOP DELAY
        # =========================
        await asyncio.sleep(2)