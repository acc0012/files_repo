import asyncio

from app.engine.core_engine import run_engine
from app.core.logger import get_logger
from app.market.spot_manager import update_spot

# ✅ LOGGER
logger = get_logger("scheduler")


# =========================
# ✅ MAIN START FUNCTION
# =========================
async def start():
    logger.info("🚀 Scheduler started")

    try:
        # ✅ Start main trading engine
        asyncio.create_task(run_engine())
        logger.info("✅ Engine task started")

        # =========================
        # ✅ TEMP: FAKE SPOT GENERATOR (REMOVE LATER)
        # =========================
        async def fake_spot_feed():
            logger.info("🧪 Starting fake spot feed (for testing)")

            price = 23730

            while True:
                update_spot("NIFTY", price)

                logger.info(f"📡 Spot Updated → NIFTY: {price}")

                # simulate movement
                price += 10

                await asyncio.sleep(5)

        # ✅ Run fake feed in background
        asyncio.create_task(fake_spot_feed())

    except Exception as e:
        logger.error(f"❌ Scheduler Error: {str(e)}")
