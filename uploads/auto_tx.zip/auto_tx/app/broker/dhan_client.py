from dhanhq import DhanContext, dhanhq
from datetime import datetime, timedelta
from app.core.config import settings

context = DhanContext(settings.CLIENT_ID, settings.ACCESS_TOKEN)
dhan = dhanhq(context)

def get_intraday(security_id):
    today = datetime.today()
    from_date = (today - timedelta(days=3)).strftime('%Y-%m-%d')
    to_date = today.strftime('%Y-%m-%d')

    return dhan.intraday_minute_data(
        security_id=security_id,
        exchange_segment='NSE_FNO',
        instrument_type='OPTION',
        from_date=from_date,
        to_date=to_date
    )
