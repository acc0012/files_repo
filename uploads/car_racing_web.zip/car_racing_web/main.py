
import pygame, sys, random
pygame.init()
WIDTH, HEIGHT = 500,600
screen = pygame.display.set_mode((WIDTH,HEIGHT))
pygame.display.set_caption('Car Racing - Web Version')
clock = pygame.time.Clock()
road = pygame.image.load('assets/road.png')
road = pygame.transform.scale(road,(WIDTH,HEIGHT))
car = pygame.image.load('assets/car.png')
car = pygame.transform.scale(car,(60,100))
enemy_car = pygame.image.load('assets/enemy_car.png')
enemy_car = pygame.transform.scale(enemy_car,(60,100))
car_x = WIDTH//2 - 30
car_y = HEIGHT - 120
enemy_x = random.randint(50, WIDTH - 110)
enemy_y = -150
enemy_speed = 5
score = 0
font = pygame.font.SysFont('Arial',30)
def draw_text(text,x,y): screen.blit(font.render(text,True,(255,255,255)),(x,y))
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit();sys.exit()
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT] and car_x>20: car_x -= 6
    if keys[pygame.K_RIGHT] and car_x<WIDTH-80: car_x += 6
    enemy_y += enemy_speed
    if enemy_y > HEIGHT:
        score += 1
        enemy_y = -150
        enemy_x = random.randint(50, WIDTH - 110)
        enemy_speed += 0.5
    car_rect = pygame.Rect(car_x,car_y,60,100)
    enemy_rect = pygame.Rect(enemy_x,enemy_y,60,100)
    if car_rect.colliderect(enemy_rect):
        score = 0; enemy_y = -150; enemy_speed = 5
    screen.blit(road,(0,0))
    screen.blit(car,(car_x,car_y))
    screen.blit(enemy_car,(enemy_x,enemy_y))
    draw_text(f'Score: {score}',20,20)
    pygame.display.update(); clock.tick(60)
