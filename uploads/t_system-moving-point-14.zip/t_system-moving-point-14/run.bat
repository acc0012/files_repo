@echo off
cls

call myenv\Scripts\activate

uvicorn app.main:app --host 0.0.0.0 --port 8001 --reload