# app/services/queue_service.py

from datetime import datetime
from uuid import uuid4

from app.logger import logger
from app.services.mongo_service import (
    save_request_queue,
    get_request_queue,
    update_request_queue_status,
)


def generate_trace_id(prefix: str) -> str:
    """
    Examples:
    OR_20260617_021835_ab12cd
    INDEX_EMA_20260617_021835_ab12cd
    OPTION_EMA_20260617_021835_ab12cd
    """

    timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")

    return f"{prefix}_{timestamp}_{uuid4().hex[:6]}"


async def enqueue_opening_range(payload):
    try:
        trace_id = generate_trace_id("OR")

        document = {
            "trace_id": trace_id,
            "request_type": "OPENING_RANGE",
            "status": "PENDING",
            "payload": payload.model_dump(),
            "created_at": datetime.utcnow(),
            "started_at": None,
            "completed_at": None,
            "error": None,
        }

        await save_request_queue(document)

        logger.info(f"OPENING_RANGE QUEUED " f"trace_id={trace_id}")

        return trace_id

    except Exception as e:
        logger.exception(f"Queue opening range failed: {e}")
        raise


async def enqueue_index_ema(payload):
    try:
        trace_id = generate_trace_id("INDEX_EMA")

        document = {
            "trace_id": trace_id,
            "request_type": "INDEX_EMA",
            "status": "PENDING",
            "payload": payload.model_dump(),
            "created_at": datetime.utcnow(),
            "started_at": None,
            "completed_at": None,
            "error": None,
        }

        await save_request_queue(document)

        logger.info(f"INDEX_EMA QUEUED " f"trace_id={trace_id}")

        return trace_id

    except Exception as e:
        logger.exception(f"Queue index ema failed: {e}")
        raise


async def enqueue_option_ema(payload):
    try:
        trace_id = generate_trace_id("OPTION_EMA")

        document = {
            "trace_id": trace_id,
            "request_type": "OPTION_EMA",
            "status": "PENDING",
            "payload": payload.model_dump(),
            "created_at": datetime.utcnow(),
            "started_at": None,
            "completed_at": None,
            "error": None,
        }

        await save_request_queue(document)

        logger.info(f"OPTION_EMA QUEUED " f"trace_id={trace_id}")

        return trace_id

    except Exception as e:
        logger.exception(f"Queue option ema failed: {e}")
        raise


async def mark_processing(trace_id: str):
    try:
        await update_request_queue_status(
            trace_id=trace_id,
            status="PROCESSING",
            started_at=datetime.utcnow(),
        )

        logger.info(f"REQUEST PROCESSING " f"trace_id={trace_id}")

    except Exception as e:
        logger.exception(f"Mark processing failed: {e}")
        raise


async def mark_completed(trace_id: str):
    try:
        await update_request_queue_status(
            trace_id=trace_id,
            status="COMPLETED",
            completed_at=datetime.utcnow(),
        )

        logger.info(f"REQUEST COMPLETED " f"trace_id={trace_id}")

    except Exception as e:
        logger.exception(f"Mark completed failed: {e}")
        raise


async def mark_failed(trace_id: str, error: str):
    try:
        await update_request_queue_status(
            trace_id=trace_id,
            status="FAILED",
            completed_at=datetime.utcnow(),
            error=error,
        )

        logger.error(f"REQUEST FAILED " f"trace_id={trace_id} " f"error={error}")

    except Exception as e:
        logger.exception(f"Mark failed failed: {e}")
        raise


async def get_trace_status(trace_id: str):
    try:
        document = await get_request_queue(trace_id)

        if not document:
            return None

        return {
            "trace_id": document.get("trace_id"),
            "request_type": document.get("request_type"),
            "status": document.get("status"),
            "created_at": str(document.get("created_at")),
            "started_at": (
                str(document.get("started_at")) if document.get("started_at") else None
            ),
            "completed_at": (
                str(document.get("completed_at"))
                if document.get("completed_at")
                else None
            ),
            "error": document.get("error"),
        }

    except Exception as e:
        logger.exception(f"Get trace status failed: {e}")
        raise
