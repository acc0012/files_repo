# app/services/ema_service.py

from datetime import datetime

from app.logger import logger

from app.services.mongo_service import (
    save_ema_signal,
)

from app.services.telegram_service import (
    send_buy_ce_alert,
    send_sell_ce_alert,
    send_buy_pe_alert,
    send_sell_pe_alert,
)


async def process_index_ema(payload):
    try:

        data = payload.model_dump()

        document = {
            "type": data.get("TYPE"),
            "DATE": data.get("DATE"),
            "TIME": data.get("TIME"),
            "TF": data.get("TF"),
            "PRICE": data.get("PRICE"),
            "EMA9": data.get("EMA9"),
            "EMA21": data.get("EMA21"),
            "DIFF": data.get("DIFF"),
            "OPENING_RANGE": data.get(
                "OPENING_RANGE",
                {},
            ),
            "signal_source": "INDEX",
            "created_at": datetime.utcnow(),
        }

        ema_id = await save_ema_signal(document)

        signal_type = document["type"]

        try:

            if signal_type == "BUY_CE":

                await send_buy_ce_alert(document)

            elif signal_type == "SELL_CE":

                await send_sell_ce_alert(document)

            elif signal_type == "BUY_PE":

                await send_buy_pe_alert(document)

            elif signal_type == "SELL_PE":

                await send_sell_pe_alert(document)

        except Exception as telegram_error:

            logger.exception(f"INDEX EMA TELEGRAM FAILED: " f"{telegram_error}")

        logger.info(f"INDEX EMA processed " f"{signal_type}")

        return {
            "success": True,
            "type": signal_type,
            "ema_id": ema_id,
        }

    except Exception as e:

        logger.exception(f"Index EMA failed: {e}")

        raise


async def process_option_ema(payload):
    try:

        data = payload.model_dump()

        document = {
            "type": data.get("TYPE"),
            "SYMBOL": data.get("SYMBOL"),
            "STRIKE": data.get("STRIKE"),
            "DATE": data.get("DATE"),
            "TIME": data.get("TIME"),
            "PRICE": data.get("PRICE"),
            "EMA9": data.get("EMA9"),
            "EMA21": data.get("EMA21"),
            "OPENING_RANGE": data.get(
                "OPENING_RANGE",
                {},
            ),
            "signal_source": "OPTION",
            "created_at": datetime.utcnow(),
        }

        ema_id = await save_ema_signal(document)

        signal_type = document["type"]

        try:

            if signal_type == "BUY_CE":

                await send_buy_ce_alert(document)

            elif signal_type == "SELL_CE":

                await send_sell_ce_alert(document)

            elif signal_type == "BUY_PE":

                await send_buy_pe_alert(document)

            elif signal_type == "SELL_PE":

                await send_sell_pe_alert(document)

        except Exception as telegram_error:

            logger.exception(f"OPTION EMA TELEGRAM FAILED: " f"{telegram_error}")

        logger.info(f"OPTION EMA processed " f"{signal_type}")

        return {
            "success": True,
            "type": signal_type,
            "ema_id": ema_id,
        }

    except Exception as e:

        logger.exception(f"Option EMA failed: {e}")

        raise
