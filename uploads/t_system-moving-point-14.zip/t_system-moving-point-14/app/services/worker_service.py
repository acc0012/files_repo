# app/services/worker_service.py

from app.logger import logger

from app.models.opening_range import OpeningRangeModel
from app.models.ema_signal import EMASignalModel

from app.services.mongo_service import (
    get_pending_requests,
)

from app.services.queue_service import (
    mark_processing,
    mark_completed,
    mark_failed,
)

from app.services.opening_range_service import process_opening_range
from app.services.ema_service import (
    process_index_ema,
    process_option_ema,
)


async def process_pending_requests():
    try:
        pending_requests = await get_pending_requests()

        if not pending_requests:
            return

        logger.info(f"PENDING REQUESTS FOUND " f"count={len(pending_requests)}")

        for request in pending_requests:

            trace_id = request.get("trace_id")
            request_type = request.get("request_type")
            payload = request.get("payload", {})

            try:

                await mark_processing(trace_id)

                logger.info(
                    f"PROCESSING REQUEST "
                    f"trace_id={trace_id} "
                    f"type={request_type}"
                )

                if request_type == "OPENING_RANGE":

                    model = OpeningRangeModel(**payload)

                    await process_opening_range(model)

                elif request_type == "INDEX_EMA":

                    model = EMASignalModel(**payload)

                    await process_index_ema(model)

                elif request_type == "OPTION_EMA":

                    model = EMASignalModel(**payload)

                    await process_option_ema(model)

                else:

                    raise Exception(f"Unsupported request type: " f"{request_type}")

                await mark_completed(trace_id)

                logger.info(f"REQUEST COMPLETED " f"trace_id={trace_id}")

            except Exception as request_error:

                await mark_failed(
                    trace_id=trace_id,
                    error=str(request_error),
                )

                logger.exception(
                    f"REQUEST FAILED " f"trace_id={trace_id} " f"error={request_error}"
                )

    except Exception as e:

        logger.exception(f"Worker processing failed: {e}")


async def process_single_request(trace_id: str):
    """
    Optional helper for manual processing
    """

    try:

        pending_requests = await get_pending_requests()

        request = next(
            (item for item in pending_requests if item.get("trace_id") == trace_id),
            None,
        )

        if not request:

            logger.warning(f"REQUEST NOT FOUND " f"trace_id={trace_id}")

            return

        request_type = request.get("request_type")
        payload = request.get("payload", {})

        await mark_processing(trace_id)

        if request_type == "OPENING_RANGE":

            model = OpeningRangeModel(**payload)

            await process_opening_range(model)

        elif request_type == "INDEX_EMA":

            model = EMASignalModel(**payload)

            await process_index_ema(model)

        elif request_type == "OPTION_EMA":

            model = EMASignalModel(**payload)

            await process_option_ema(model)

        else:

            raise Exception(f"Unsupported request type: " f"{request_type}")

        await mark_completed(trace_id)

        logger.info(f"MANUAL REQUEST COMPLETED " f"trace_id={trace_id}")

    except Exception as e:

        await mark_failed(
            trace_id=trace_id,
            error=str(e),
        )

        logger.exception(f"MANUAL REQUEST FAILED " f"trace_id={trace_id} " f"error={e}")
