import requests

from app.config import TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID

from app.logger import logger

BASE_URL = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}"


def init_telegram():
    logger.info("Telegram service initialized")


async def send_message(message: str):
    try:
        url = f"{BASE_URL}/sendMessage"

        payload = {"chat_id": TELEGRAM_CHAT_ID, "text": message, "parse_mode": "HTML"}

        response = requests.post(url, json=payload, timeout=30)

        response.raise_for_status()

        logger.info("Telegram message sent")

        return response.json()

    except Exception as e:
        logger.exception(f"Telegram send failed: {e}")
        raise


async def send_opening_range_alert(data: dict):
    try:
        message = f"""
🔔 <b>OPENING RANGE GENERATED</b>

<b>HIGH</b> : {data.get("HIGH")}
<b>LOW</b> : {data.get("LOW")}
<b>AVG</b> : {data.get("AVG")}

<b>SUB RESISTANCE</b> : {data.get("SUB_RESISTANCE")}
<b>SUB SUPPORT</b> : {data.get("SUB_SUPPORT")}

<b>RESISTANCE2</b> : {data.get("RESISTANCE2")}
<b>SUPPORT2</b> : {data.get("SUPPORT2")}

<b>RESISTANCE3</b> : {data.get("RESISTANCE3")}
<b>SUPPORT3</b> : {data.get("SUPPORT3")}

━━━━━━━━━━━━━━

<b>CREATE TV ALERTS</b>

R3 CE : {data.get("RESISTANCE3_CE_STRIKE")}
R3 PE : {data.get("RESISTANCE3_PE_STRIKE")}

S3 CE : {data.get("SUPPORT3_CE_STRIKE")}
S3 PE : {data.get("SUPPORT3_PE_STRIKE")}

BUY CE : {data.get("BUY_CE")}
BUY PE : {data.get("BUY_PE")}

━━━━━━━━━━━━━━

After creating alerts:

/confirm NIFTY
"""

        return await send_message(message)

    except Exception as e:
        logger.exception(f"Opening range telegram failed: {e}")
        raise


async def send_buy_ce_alert(data: dict):
    message = f"""
🟢 <b>BUY CE SIGNAL</b>

Price : {data.get("PRICE")}

EMA9  : {data.get("EMA9")}
EMA21 : {data.get("EMA21")}

BUY CE : {data.get("OPENING_RANGE", {}).get("BUY_CE")}
"""

    return await send_message(message)


async def send_sell_ce_alert(data: dict):
    message = f"""
🔴 <b>SELL CE SIGNAL</b>

Price : {data.get("PRICE")}

EMA9  : {data.get("EMA9")}
EMA21 : {data.get("EMA21")}
"""

    return await send_message(message)


async def send_buy_pe_alert(data: dict):
    message = f"""
🟣 <b>BUY PE SIGNAL</b>

Price : {data.get("PRICE")}

EMA9  : {data.get("EMA9")}
EMA21 : {data.get("EMA21")}

BUY PE : {data.get("OPENING_RANGE", {}).get("BUY_PE")}
"""

    return await send_message(message)


async def send_sell_pe_alert(data: dict):
    message = f"""
🟡 <b>SELL PE SIGNAL</b>

Price : {data.get("PRICE")}

EMA9  : {data.get("EMA9")}
EMA21 : {data.get("EMA21")}
"""

    return await send_message(message)


async def send_reminder_alert(data: dict):
    try:
        message = f"""
⚠️ <b>REMINDER</b>

TradingView alerts not confirmed.

R3 CE : {data.get("RESISTANCE3_CE_STRIKE")}
R3 PE : {data.get("RESISTANCE3_PE_STRIKE")}

S3 CE : {data.get("SUPPORT3_CE_STRIKE")}
S3 PE : {data.get("SUPPORT3_PE_STRIKE")}

Please configure TradingView alerts.

Reply:

/confirm NIFTY
"""

        return await send_message(message)

    except Exception as e:
        logger.exception(f"Reminder telegram failed: {e}")
        raise
