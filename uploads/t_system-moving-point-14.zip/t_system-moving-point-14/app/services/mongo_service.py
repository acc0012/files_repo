# app/services/mongo_service.py

from pymongo import MongoClient
from pymongo.collection import Collection

from app.config import (
    MONGO_URL,
    MONGO_DB,
    OPENING_RANGE_COLLECTION,
    EMA_COLLECTION,
    CONFIRMATION_COLLECTION,
    REQUEST_QUEUE_COLLECTION,
)

from app.logger import logger

client: MongoClient | None = None
db = None

opening_range_collection: Collection | None = None
ema_collection: Collection | None = None
confirmation_collection: Collection | None = None
request_queue_collection: Collection | None = None


def init_mongo():
    global client
    global db

    global opening_range_collection
    global ema_collection
    global confirmation_collection
    global request_queue_collection

    try:
        client = MongoClient(MONGO_URL)

        db = client[MONGO_DB]

        opening_range_collection = db[OPENING_RANGE_COLLECTION]
        ema_collection = db[EMA_COLLECTION]
        confirmation_collection = db[CONFIRMATION_COLLECTION]
        request_queue_collection = db[REQUEST_QUEUE_COLLECTION]

        logger.info("MongoDB connected")

    except Exception as e:
        logger.exception(f"Mongo init failed: {e}")
        raise


def get_opening_range_collection():
    return opening_range_collection


def get_ema_collection():
    return ema_collection


def get_confirmation_collection():
    return confirmation_collection


def get_request_queue_collection():
    return request_queue_collection


# =====================================================
# OPENING RANGE
# =====================================================


async def save_opening_range(document: dict):
    try:
        result = opening_range_collection.insert_one(document)

        logger.info(f"Opening Range saved " f"id={result.inserted_id}")

        return str(result.inserted_id)

    except Exception as e:
        logger.exception(f"Save opening range failed: {e}")
        raise


# =====================================================
# EMA
# =====================================================


async def save_ema_signal(document: dict):
    try:
        result = ema_collection.insert_one(document)

        logger.info(f"EMA Signal saved " f"id={result.inserted_id}")

        return str(result.inserted_id)

    except Exception as e:
        logger.exception(f"Save ema failed: {e}")
        raise


# =====================================================
# CONFIRMATION
# =====================================================


async def save_confirmation(document: dict):
    try:
        result = confirmation_collection.insert_one(document)

        logger.info(f"Confirmation saved " f"id={result.inserted_id}")

        return str(result.inserted_id)

    except Exception as e:
        logger.exception(f"Save confirmation failed: {e}")
        raise


async def get_pending_confirmations():
    try:
        cursor = confirmation_collection.find({"confirmed": False})

        return list(cursor)

    except Exception as e:
        logger.exception(f"Get pending confirmations failed: {e}")
        raise


async def mark_confirmed(index_name: str):
    try:
        result = confirmation_collection.update_one(
            {
                "index_name": index_name,
                "confirmed": False,
            },
            {
                "$set": {
                    "confirmed": True,
                }
            },
        )

        return result.modified_count

    except Exception as e:
        logger.exception(f"Mark confirmed failed: {e}")
        raise


async def get_confirmation(index_name: str):
    try:
        return confirmation_collection.find_one(
            {"index_name": index_name},
            sort=[("created_at", -1)],
        )

    except Exception as e:
        logger.exception(f"Get confirmation failed: {e}")
        raise


# =====================================================
# OPENING RANGE QUERY
# =====================================================


async def get_latest_opening_range(
    index_name: str,
):
    try:
        return opening_range_collection.find_one(
            {"index_name": index_name},
            sort=[("created_at", -1)],
        )

    except Exception as e:
        logger.exception(f"Get latest opening range failed: {e}")
        raise


# =====================================================
# REQUEST QUEUE
# =====================================================


async def save_request_queue(
    document: dict,
):
    try:

        result = request_queue_collection.insert_one(document)

        logger.info(f"REQUEST QUEUED " f"trace_id={document.get('trace_id')}")

        return str(result.inserted_id)

    except Exception as e:

        logger.exception(f"Save request queue failed: {e}")

        raise


async def get_request_queue(
    trace_id: str,
):
    try:

        return request_queue_collection.find_one(
            {
                "trace_id": trace_id,
            }
        )

    except Exception as e:

        logger.exception(f"Get request queue failed: {e}")

        raise


async def get_pending_requests():
    try:

        cursor = request_queue_collection.find(
            {
                "status": "PENDING",
            }
        ).sort(
            "created_at",
            1,
        )

        return list(cursor)

    except Exception as e:

        logger.exception(f"Get pending requests failed: {e}")

        raise


async def update_request_queue_status(
    trace_id: str,
    status: str,
    started_at=None,
    completed_at=None,
    error=None,
):
    try:

        update_data = {
            "status": status,
        }

        if started_at:
            update_data["started_at"] = started_at

        if completed_at:
            update_data["completed_at"] = completed_at

        if error:
            update_data["error"] = error

        result = request_queue_collection.update_one(
            {
                "trace_id": trace_id,
            },
            {
                "$set": update_data,
            },
        )

        return result.modified_count

    except Exception as e:

        logger.exception(f"Update request status failed: {e}")

        raise
