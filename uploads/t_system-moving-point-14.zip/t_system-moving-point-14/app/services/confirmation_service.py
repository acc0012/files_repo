from datetime import datetime

from app.logger import logger

from app.services.mongo_service import (
    mark_confirmed,
    get_confirmation,
    get_pending_confirmations,
)


async def confirm_index_alerts(index_name: str):
    try:

        modified_count = await mark_confirmed(index_name=index_name)

        logger.info(f"Confirmed " f"{index_name}")

        return {
            "index_name": index_name,
            "confirmed": True,
            "modified_count": modified_count,
            "confirmed_at": str(datetime.utcnow()),
        }

    except Exception as e:
        logger.exception(f"Confirmation failed: {e}")
        raise


async def get_confirmation_status(index_name: str):
    try:

        data = await get_confirmation(index_name=index_name)

        if not data:
            return {"index_name": index_name, "exists": False}

        return {
            "index_name": data.get("index_name"),
            "confirmed": data.get("confirmed", False),
            "created_at": str(data.get("created_at")),
        }

    except Exception as e:
        logger.exception(f"Status failed: {e}")
        raise


async def get_pending_confirmations_list():
    try:

        items = await get_pending_confirmations()

        result = []

        for item in items:

            result.append(
                {
                    "index_name": item.get("index_name"),
                    "confirmed": item.get("confirmed", False),
                    "created_at": str(item.get("created_at")),
                }
            )

        return result

    except Exception as e:
        logger.exception(f"Pending list failed: {e}")
        raise


# API Compatibility Wrapper
async def get_pending_confirmations():
    return await get_pending_confirmations_list()
