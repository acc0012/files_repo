# app/services/reminder_service.py

from app.logger import logger

from app.services.mongo_service import (
    get_pending_confirmations,
    get_latest_opening_range,
)

from app.services.telegram_service import (
    send_reminder_alert,
)


async def process_reminders():
    try:

        pending_items = await get_pending_confirmations()

        if not pending_items:

            logger.info("No pending confirmations")

            return

        logger.info(f"Pending confirmations " f"{len(pending_items)}")

        for item in pending_items:

            try:

                index_name = item.get("index_name")

                opening_range = await get_latest_opening_range(index_name)

                if not opening_range:

                    logger.warning(f"Opening range not found " f"{index_name}")

                    continue

                await send_reminder_alert(opening_range)

                logger.info(f"Reminder sent " f"{index_name}")

            except Exception as item_error:

                logger.exception(
                    f"Reminder failed " f"{index_name} " f"error={item_error}"
                )

    except Exception as e:

        logger.exception(f"Reminder service failed: {e}")
