# app/services/opening_range_service.py

from datetime import datetime

from app.logger import logger

from app.services.mongo_service import (
    save_opening_range,
    save_confirmation,
)

from app.services.telegram_service import (
    send_opening_range_alert,
)


async def process_opening_range(payload):
    try:

        data = payload.model_dump()

        document = {
            "type": data.get("TYPE"),
            "index_name": data.get(
                "INDEX_NAME",
                "NIFTY",
            ),
            "HIGH": data.get("HIGH"),
            "LOW": data.get("LOW"),
            "AVG": data.get("AVG"),
            "SUB_RESISTANCE": data.get("SUB_RESISTANCE"),
            "SUB_SUPPORT": data.get("SUB_SUPPORT"),
            "RESISTANCE2": data.get("RESISTANCE2"),
            "SUPPORT2": data.get("SUPPORT2"),
            "RESISTANCE3": data.get("RESISTANCE3"),
            "SUPPORT3": data.get("SUPPORT3"),
            "RESISTANCE3_CE_STRIKE": data.get("RESISTANCE3_CE_STRIKE"),
            "RESISTANCE3_PE_STRIKE": data.get("RESISTANCE3_PE_STRIKE"),
            "SUPPORT3_CE_STRIKE": data.get("SUPPORT3_CE_STRIKE"),
            "SUPPORT3_PE_STRIKE": data.get("SUPPORT3_PE_STRIKE"),
            "BUY_CE": data.get("BUY_CE"),
            "BUY_PE": data.get("BUY_PE"),
            "created_at": datetime.utcnow(),
        }

        opening_range_id = await save_opening_range(document)

        confirmation_document = {
            "index_name": document["index_name"],
            "confirmed": False,
            "created_at": datetime.utcnow(),
        }

        confirmation_id = await save_confirmation(confirmation_document)

        try:

            await send_opening_range_alert(document)

        except Exception as telegram_error:

            logger.exception(f"Opening Range Telegram Failed: " f"{telegram_error}")

        logger.info(f"Opening Range processed " f"{document['index_name']}")

        return {
            "success": True,
            "index_name": document["index_name"],
            "opening_range_id": opening_range_id,
            "confirmation_id": confirmation_id,
        }

    except Exception as e:

        logger.exception(f"Opening Range processing failed: {e}")

        raise
