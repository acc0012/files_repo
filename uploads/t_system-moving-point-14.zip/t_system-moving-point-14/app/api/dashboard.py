import os
from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

from app.services.mongo_service import (
    get_opening_range_collection,
    get_ema_collection,
    get_request_queue_collection,
)

router = APIRouter()

# ✅ Proper absolute path (final safe version)
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

templates = Jinja2Templates(
    directory=os.path.join(BASE_DIR, "templates")
)

@router.get("/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request):

    # ✅ Fetch safely
    def safe_fetch(collection):
        if collection is None:
            return []
        return list(
            collection.find()
            .sort("created_at", -1)
            .limit(10)
        )

    opening_ranges = safe_fetch(get_opening_range_collection())
    ema_signals = safe_fetch(get_ema_collection())
    queue_items = safe_fetch(get_request_queue_collection())

    # ✅ Serialize Mongo ObjectId → string
    def serialize(data):
        cleaned = []
        for item in data:
            obj = dict(item)

            # Convert _id
            if "_id" in obj:
                obj["_id"] = str(obj["_id"])

            # ✅ Ensure OPENING_RANGE always dict (critical fix)
            if "OPENING_RANGE" in obj and not isinstance(obj["OPENING_RANGE"], dict):
                obj["OPENING_RANGE"] = {}

            cleaned.append(obj)

        return cleaned

    opening_ranges = serialize(opening_ranges)
    ema_signals = serialize(ema_signals)
    queue_items = serialize(queue_items)

    # ✅ IMPORTANT: pass context correctly (no nesting issues)
    context = {
        "request": request,
        "opening_ranges": opening_ranges,
        "ema_signals": ema_signals,
        "queue_items": queue_items,
    }

    return templates.TemplateResponse(
    request,
    "index.html",
    context
)

