from fastapi import APIRouter, HTTPException

from app.logger import logger
from app.services.confirmation_service import (
    confirm_index_alerts,
    get_confirmation_status,
    get_pending_confirmations,
)

router = APIRouter()


@router.post("/confirm/{index_name}")
async def confirm_alerts(index_name: str):
    try:
        result = await confirm_index_alerts(index_name)

        return {"success": True, "message": f"{index_name} confirmed", "data": result}

    except Exception as e:
        logger.exception(f"CONFIRM ERROR: {e}")

        raise HTTPException(status_code=500, detail=str(e))


@router.get("/status/{index_name}")
async def confirmation_status(index_name: str):
    try:
        result = await get_confirmation_status(index_name)

        return {"success": True, "data": result}

    except Exception as e:
        logger.exception(f"STATUS ERROR: {e}")

        raise HTTPException(status_code=500, detail=str(e))


@router.get("/pending")
async def pending_confirmations():
    try:
        result = await get_pending_confirmations()

        return {"success": True, "count": len(result), "data": result}

    except Exception as e:
        logger.exception(f"PENDING ERROR: {e}")

        raise HTTPException(status_code=500, detail=str(e))
