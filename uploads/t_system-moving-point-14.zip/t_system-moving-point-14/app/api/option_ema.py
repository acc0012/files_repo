# app/api/option_ema.py

from fastapi import APIRouter
from fastapi import HTTPException

from app.logger import logger

from app.models.ema_signal import EMASignalModel

from app.services.queue_service import (
    enqueue_option_ema,
)

router = APIRouter()


@router.post("/option-ema")
async def option_ema_webhook(
    payload: EMASignalModel,
):
    try:

        logger.info(f"OPTION EMA RECEIVED " f"TYPE={payload.TYPE}")

        trace_id = await enqueue_option_ema(payload)

        return {
            "success": True,
            "message": "Option EMA queued",
            "trace_id": trace_id,
            "status": "PENDING",
        }

    except Exception as e:

        logger.exception(f"OPTION EMA ERROR: {e}")

        raise HTTPException(
            status_code=500,
            detail=str(e),
        )
