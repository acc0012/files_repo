# app/api/status.py

from fastapi import APIRouter
from fastapi import HTTPException

from app.logger import logger

from app.services.queue_service import get_trace_status

router = APIRouter()


@router.get("/status/{trace_id}")
async def request_status(trace_id: str):
    try:

        result = await get_trace_status(trace_id)

        if not result:

            return {
                "success": False,
                "message": "Trace ID not found",
                "trace_id": trace_id,
            }

        return {
            "success": True,
            "data": result,
        }

    except Exception as e:

        logger.exception(f"STATUS ERROR " f"trace_id={trace_id} " f"error={e}")

        raise HTTPException(
            status_code=500,
            detail=str(e),
        )
