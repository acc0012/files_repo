# app/api/index_ema.py

from fastapi import APIRouter
from fastapi import HTTPException

from app.logger import logger

from app.models.ema_signal import EMASignalModel

from app.services.queue_service import (
    enqueue_index_ema,
)

router = APIRouter()


@router.post("/index-ema")
async def index_ema_webhook(
    payload: EMASignalModel,
):
    try:

        logger.info(f"INDEX EMA RECEIVED " f"TYPE={payload.TYPE}")

        trace_id = await enqueue_index_ema(payload)

        return {
            "success": True,
            "message": "Index EMA queued",
            "trace_id": trace_id,
            "status": "PENDING",
        }

    except Exception as e:

        logger.exception(f"INDEX EMA ERROR: {e}")

        raise HTTPException(
            status_code=500,
            detail=str(e),
        )
