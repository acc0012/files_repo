# app/api/opening_range.py

from fastapi import APIRouter
from fastapi import HTTPException

from app.logger import logger

from app.models.opening_range import OpeningRangeModel

from app.services.queue_service import (
    enqueue_opening_range,
)

router = APIRouter()


@router.post("/opening-range")
async def opening_range_webhook(
    payload: OpeningRangeModel,
):
    try:

        logger.info(
            f"OPENING_RANGE RECEIVED "
            f"R3={payload.RESISTANCE3} "
            f"S3={payload.SUPPORT3}"
        )

        trace_id = await enqueue_opening_range(payload)

        return {
            "success": True,
            "message": "Opening range queued",
            "trace_id": trace_id,
            "status": "PENDING",
        }

    except Exception as e:

        logger.exception(f"OPENING_RANGE ERROR: {e}")

        raise HTTPException(
            status_code=500,
            detail=str(e),
        )
