# app/scheduler/reminder_scheduler.py

from zoneinfo import ZoneInfo

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger

from app.logger import logger

from app.services.reminder_service import (
    process_reminders,
)

from app.services.worker_service import (
    process_pending_requests,
)

scheduler = AsyncIOScheduler(timezone=ZoneInfo("Asia/Kolkata"))


async def reminder_job():
    try:

        logger.info("REMINDER JOB STARTED")

        await process_reminders()

        logger.info("REMINDER JOB COMPLETED")

    except Exception as e:

        logger.exception(f"Reminder job failed: {e}")


async def worker_job():
    try:

        await process_pending_requests()

    except Exception as e:

        logger.exception(f"Worker job failed: {e}")


def start_scheduler():
    try:

        if scheduler.running:

            logger.info("Scheduler already running")

            return

        # =================================================
        # QUEUE WORKER
        # =================================================

        scheduler.add_job(
            worker_job,
            trigger=IntervalTrigger(seconds=2),
            id="request_worker",
            replace_existing=True,
            max_instances=1,
            coalesce=True,
        )

        # =================================================
        # REMINDER JOB
        # =================================================

        scheduler.add_job(
            reminder_job,
            trigger=IntervalTrigger(minutes=30),
            id="pending_alert_reminder",
            replace_existing=True,
            max_instances=1,
            coalesce=True,
        )

        scheduler.start()

        logger.info("Queue worker started (2 seconds)")

        logger.info("Reminder scheduler started (30 minutes)")

    except Exception as e:

        logger.exception(f"Scheduler startup failed: {e}")

        raise


def stop_scheduler():
    try:

        if scheduler.running:

            scheduler.shutdown(wait=False)

            logger.info("Scheduler stopped")

    except Exception as e:

        logger.exception(f"Scheduler stop failed: {e}")
