import logging
import sys

from app.config import LOG_LEVEL

LOG_FORMAT = "%(asctime)s | " "%(levelname)s | " "%(name)s | " "%(message)s"

logging.basicConfig(
    level=getattr(logging, LOG_LEVEL.upper(), logging.INFO),
    format=LOG_FORMAT,
    handlers=[logging.StreamHandler(sys.stdout)],
)

logger = logging.getLogger("t_system_alert_engine")

logger.setLevel(getattr(logging, LOG_LEVEL.upper(), logging.INFO))
