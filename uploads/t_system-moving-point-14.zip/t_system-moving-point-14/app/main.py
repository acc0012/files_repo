# app/main.py

from contextlib import asynccontextmanager

from fastapi import FastAPI

from app.logger import logger

from app.services.mongo_service import init_mongo
from app.services.telegram_service import init_telegram

from app.scheduler.reminder_scheduler import (
    start_scheduler,
    stop_scheduler,
)

from app.api.opening_range import router as opening_range_router
from app.api.index_ema import router as index_ema_router
from app.api.option_ema import router as option_ema_router
from app.api.telegram import router as telegram_router
from app.api.status import router as status_router
from app.api.dashboard import router as dashboard_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    try:
        logger.info("========================================")
        logger.info("T_SYSTEM ALERT ENGINE STARTING")
        logger.info("========================================")

        # Mongo
        init_mongo()
        logger.info("MongoDB initialized")

        # Telegram
        init_telegram()
        logger.info("Telegram initialized")

        # Scheduler
        start_scheduler()
        logger.info("Reminder scheduler started")

        logger.info("System startup completed")

        yield

    except Exception as e:

        logger.exception(f"Startup failed: {e}")

        raise

    finally:

        try:
            stop_scheduler()
        except Exception:
            pass

        logger.info("========================================")
        logger.info("T_SYSTEM ALERT ENGINE STOPPED")
        logger.info("========================================")


app = FastAPI(
    title="T System Alert Engine",
    description="Opening Range + EMA Alert Engine",
    version="1.0.0",
    lifespan=lifespan,
)

# =====================================================
# ROUTERS
# =====================================================

app.include_router(
    opening_range_router,
    prefix="/webhook",
    tags=["Opening Range"],
)

app.include_router(
    index_ema_router,
    prefix="/webhook",
    tags=["Index EMA"],
)

app.include_router(
    option_ema_router,
    prefix="/webhook",
    tags=["Option EMA"],
)

app.include_router(
    telegram_router,
    prefix="/telegram",
    tags=["Telegram"],
)

app.include_router(
    status_router,
    tags=["Status"],
)


app.include_router(
    dashboard_router,
    tags=["Dashboard"],
)

# =====================================================
# HEALTH
# =====================================================


@app.get("/")
async def root():
    return {
        "status": "running",
        "service": "t_system_alert_engine",
        "version": "1.0.0",
    }


@app.get("/health")
async def health():
    return {
        "success": True,
        "message": "Service Healthy",
    }


@app.get("/ping")
async def ping():
    return {
        "pong": True,
    }
