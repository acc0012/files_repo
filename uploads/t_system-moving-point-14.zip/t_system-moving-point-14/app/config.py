# app/config.py

import os

from dotenv import load_dotenv

load_dotenv()

# =====================================================
# APP
# =====================================================

APP_NAME = "t_system_alert_engine"
APP_VERSION = "1.0.0"

# =====================================================
# MONGODB
# =====================================================

MONGO_URL = os.getenv("MONGO_URL", "mongodb://localhost:27017")

MONGO_DB = os.getenv("MONGO_DB", "t_system_alert_engine")

OPENING_RANGE_COLLECTION = os.getenv("OPENING_RANGE_COLLECTION", "opening_ranges")

EMA_COLLECTION = os.getenv("EMA_COLLECTION", "ema_signals")

CONFIRMATION_COLLECTION = os.getenv("CONFIRMATION_COLLECTION", "confirmations")

REQUEST_QUEUE_COLLECTION = os.getenv("REQUEST_QUEUE_COLLECTION", "request_queue")

# =====================================================
# TELEGRAM
# =====================================================

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")

TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")

# =====================================================
# REMINDER
# =====================================================

REMINDER_INTERVAL_MINUTES = int(os.getenv("REMINDER_INTERVAL_MINUTES", "30"))

# =====================================================
# LOGGING
# =====================================================

LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")

# =====================================================
# API
# =====================================================

REQUEST_TIMEOUT = int(os.getenv("REQUEST_TIMEOUT", "30"))
