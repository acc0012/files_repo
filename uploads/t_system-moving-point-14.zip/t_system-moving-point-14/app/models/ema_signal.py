from typing import Optional
from typing import Dict
from typing import Any

from pydantic import BaseModel


class EMASignalModel(BaseModel):

    TYPE: str

    DATE: Optional[str] = None
    TIME: Optional[str] = None

    TF: Optional[str] = None

    PRICE: Optional[str] = None

    EMA9: Optional[str] = None
    EMA21: Optional[str] = None
    DIFF: Optional[str] = None

    SYMBOL: Optional[str] = None
    STRIKE: Optional[str] = None

    OPENING_RANGE: Optional[Dict[str, Any]] = {}

    class Config:
        extra = "allow"
