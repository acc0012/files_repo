from typing import Optional

from pydantic import BaseModel


class OpeningRangeModel(BaseModel):
    TYPE: str

    INDEX_NAME: Optional[str] = "NIFTY"

    HIGH: str
    LOW: str
    AVG: str

    SUB_RESISTANCE: str
    SUB_SUPPORT: str

    RESISTANCE2: str
    SUPPORT2: str

    RESISTANCE3: str
    SUPPORT3: str

    RESISTANCE3_CE_STRIKE: Optional[str] = None
    RESISTANCE3_PE_STRIKE: Optional[str] = None

    SUPPORT3_CE_STRIKE: Optional[str] = None
    SUPPORT3_PE_STRIKE: Optional[str] = None

    BUY_CE: Optional[str] = None
    BUY_PE: Optional[str] = None

    class Config:
        extra = "allow"
