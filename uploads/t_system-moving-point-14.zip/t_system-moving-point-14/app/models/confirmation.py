from datetime import datetime

from pydantic import BaseModel


class ConfirmationModel(BaseModel):

    index_name: str

    confirmed: bool = False

    created_at: datetime | None = None

    confirmed_at: datetime | None = None
