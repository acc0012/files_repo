from datetime import datetime

from logger import get_logger

logger = get_logger("strategy_levels")

# =====================================================
# LEVEL GENERATION (OPENING RANGE MODEL)
# =====================================================

def generate_levels(ohlc: dict) -> dict:
    """
    Generate trading levels (High, Low, Avg, Support/Resistance)
    based on OHLC data.
    """

    try:
        logger.info("📊 Generating Levels from OHLC")

        if not ohlc:
            raise ValueError("OHLC input is empty")

        high = float(ohlc["high"])
        low = float(ohlc["low"])

        if high <= 0 or low <= 0:
            raise ValueError(f"Invalid OHLC values | High={high} | Low={low}")

        avg = (high + low) / 2
        range_val = high - low

        levels = {
            "TYPE": "OPENING_RANGE",

            "HIGH": round(high, 2),
            "LOW": round(low, 2),
            "AVG": round(avg, 2),

            "RESISTANCE2": round(high + (range_val * 0.5), 2),
            "SUPPORT2": round(low - (range_val * 0.5), 2),

            "RESISTANCE3": round(high + range_val, 2),
            "SUPPORT3": round(low - range_val, 2),

            "FROM_DATE": str(datetime.now().date()),
            "TO_DATE": str(datetime.now().date()),
        }

        logger.info(
            f"✅ Levels Generated | "
            f"High={levels['HIGH']} | "
            f"Low={levels['LOW']} | "
            f"Range={round(range_val, 2)}"
        )

        return levels

    except KeyError as e:
        logger.exception(f"❌ Missing OHLC key: {str(e)}")
        raise ValueError(f"Missing OHLC field: {str(e)}")

    except Exception as e:
        logger.exception(f"❌ Failed to generate levels: {str(e)}")
        raise


# =====================================================
# STRIKE GENERATION FROM LEVEL RANGE
# =====================================================

def generate_level_strikes(levels: dict) -> list:
    """
    Generate strikes between SUPPORT3 and RESISTANCE3
    using both 50 and 100 step intervals.
    """

    try:
        logger.info("🎯 Generating Strikes from Levels")

        if not levels:
            raise ValueError("Levels input is empty")

        lower = int(float(levels["SUPPORT3"]))
        upper = int(float(levels["RESISTANCE3"]))

        if lower >= upper:
            raise ValueError(
                f"Invalid range | SUPPORT3={lower} >= RESISTANCE3={upper}"
            )

        strikes = set()

        # ✅ 50 step strikes
        start_50 = (lower // 50) * 50
        for strike in range(start_50, upper + 50, 50):
            strikes.add(strike)

        # ✅ 100 step strikes
        start_100 = (lower // 100) * 100
        for strike in range(start_100, upper + 100, 100):
            strikes.add(strike)

        final_strikes = sorted(strikes)

        logger.info(
            f"✅ Strikes Generated | "
            f"Count={len(final_strikes)} | "
            f"Range=({lower} → {upper})"
        )

        return final_strikes

    except KeyError as e:
        logger.exception(f"❌ Missing level key: {str(e)}")
        raise ValueError(f"Missing level field: {str(e)}")

    except Exception as e:
        logger.exception(f"❌ Failed to generate strikes: {str(e)}")
        raise


# =====================================================
# BUILD CONTRACTS (CE + PE)
# =====================================================

def build_contracts(strikes: list) -> list:
    """
    Convert strikes into option contracts (CE & PE)
    """

    try:
        logger.info("📦 Building Contracts (CE/PE)")

        if not strikes:
            logger.warning("⚠️ Empty strike list received")
            return []

        contracts = []

        for strike in strikes:
            contracts.append({
                "strike": strike,
                "type": "CE"
            })
            contracts.append({
                "strike": strike,
                "type": "PE"
            })

        logger.info(
            f"✅ Contracts Built | "
            f"Strikes={len(strikes)} | "
            f"TotalContracts={len(contracts)}"
        )

        return contracts

    except Exception as e:
        logger.exception(f"❌ Failed to build contracts: {str(e)}")
        raise


# =====================================================
# FULL PIPELINE (HELPER)
# =====================================================

def generate_full_strategy(ohlc: dict) -> dict:
    """
    End-to-end helper:
    OHLC -> Levels -> Strikes -> Contracts
    """

    try:
        logger.info("=" * 80)
        logger.info("🚀 Starting Full Strategy Generation")

        levels = generate_levels(ohlc)
        strikes = generate_level_strikes(levels)
        contracts = build_contracts(strikes)

        logger.info(
            f"✅ Strategy Ready | "
            f"Levels=1 | Strikes={len(strikes)} | Contracts={len(contracts)}"
        )

        logger.info("=" * 80)

        return {
            "levels": levels,
            "strikes": strikes,
            "contracts": contracts
        }

    except Exception as e:
        logger.exception(f"❌ Full strategy generation failed: {str(e)}")
        raise