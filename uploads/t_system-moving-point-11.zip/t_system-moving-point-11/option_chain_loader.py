import requests
from datetime import datetime

from config import settings

from database import option_collection

from logger import get_logger

logger = get_logger("option_chain_loader")

# =====================================================
# IN-MEMORY CACHE
# =====================================================

OPTION_CHAIN_CACHE = {}


# =====================================================
# SUBSCRIBE OPTIONS
# =====================================================
import time
import requests

from datetime import datetime

from config import settings
from database import option_collection
from logger import get_logger

logger = get_logger("option_chain_loader")


def subscribe_option_contracts(
    index_security_id,
    range_points=500,
    step=50,
):

    try:

        contracts = get_option_security_ids(
            index_security_id=index_security_id,
            range_points=range_points,
            step=step,
        )

        if not contracts:

            logger.warning(f"⚠️ No Contracts Available | " f"Index={index_security_id}")

            return []

        subscribed = []
        failed_contracts = []

        url = (
            f"{settings.BASE_URL}"
            f"/marketfeed/subscribe-option/"
            f"{index_security_id}/"
        )

        logger.info("=" * 80)

        logger.info(f"📡 Starting Option Subscription | " f"Index={index_security_id}")

        logger.info(f"📊 Total Contracts={len(contracts)}")

        logger.info(f"🌐 Subscribe URL={url}")

        for contract in contracts:

            payload = {
                "strike_price": contract["strike"],
                "option_type": contract["type"].lower(),
            }

            success = False
            response_data = None

            for attempt in range(1, 4):

                try:

                    logger.info(
                        f"📤 Subscribe Request | "
                        f"Strike={contract['strike']} | "
                        f"Type={contract['type']} | "
                        f"Attempt={attempt}/3"
                    )

                    response = requests.post(
                        url,
                        json=payload,
                        timeout=settings.REQUEST_TIMEOUT,
                    )

                    response.raise_for_status()

                    try:

                        response_data = response.json()

                    except Exception as e:

                        raise ValueError(f"Invalid JSON Response: {str(e)}")

                    success = True

                    break

                except requests.Timeout:

                    logger.warning(
                        f"⏰ Timeout | "
                        f"Strike={contract['strike']} | "
                        f"Type={contract['type']} | "
                        f"Attempt={attempt}/3"
                    )

                except requests.ConnectionError:

                    logger.warning(
                        f"🔌 Connection Error | "
                        f"Strike={contract['strike']} | "
                        f"Type={contract['type']} | "
                        f"Attempt={attempt}/3"
                    )

                except requests.HTTPError as e:

                    logger.warning(
                        f"🚨 HTTP Error | "
                        f"Strike={contract['strike']} | "
                        f"Type={contract['type']} | "
                        f"Attempt={attempt}/3 | "
                        f"Error={str(e)}"
                    )

                except Exception as e:

                    logger.warning(
                        f"⚠️ Subscribe Error | "
                        f"Strike={contract['strike']} | "
                        f"Type={contract['type']} | "
                        f"Attempt={attempt}/3 | "
                        f"Error={str(e)}"
                    )

                if attempt < 3:

                    logger.info(
                        f"🔄 Retrying In 2 Seconds | "
                        f"Strike={contract['strike']} | "
                        f"Type={contract['type']}"
                    )

                    time.sleep(2)

            # =====================================
            # SUCCESS
            # =====================================

            if success:

                subscribed.append(response_data)

                instrument = response_data.get(
                    "instrument",
                    {},
                )

                logger.info(
                    f"✅ Subscribed | "
                    f"Strike={instrument.get('strike')} | "
                    f"Type={instrument.get('option_type')} | "
                    f"SID={instrument.get('security_id')}"
                )

            # =====================================
            # FAILED
            # =====================================

            else:

                failed_contracts.append(
                    {
                        "strike": contract["strike"],
                        "type": contract["type"],
                        "security_id": contract["security_id"],
                    }
                )

                logger.error(
                    f"❌ Subscription Failed After 3 Attempts | "
                    f"Strike={contract['strike']} | "
                    f"Type={contract['type']} | "
                    f"SID={contract['security_id']}"
                )

        # =====================================
        # SAVE RESULTS
        # =====================================

        option_collection.update_one(
            {
                "index_security_id": index_security_id,
            },
            {
                "$set": {
                    "subscribed_contracts": subscribed,
                    "failed_subscriptions": failed_contracts,
                    "subscription_updated_at": datetime.utcnow(),
                }
            },
            upsert=True,
        )

        logger.info("=" * 80)

        logger.info(
            f"💾 Subscription Results Saved | "
            f"Success={len(subscribed)} | "
            f"Failed={len(failed_contracts)}"
        )

        logger.info("=" * 80)

        return subscribed

    except Exception as e:

        logger.exception(
            f"❌ subscribe_option_contracts failed | "
            f"Index={index_security_id} | "
            f"Error={str(e)}"
        )

        return []


# =====================================================
# STRIKE GENERATOR
# =====================================================


def generate_strikes(
    ltp,
    range_points=500,
    step=50,
):

    lower = ltp - range_points
    upper = ltp + range_points

    start = int(lower // step) * step
    end = int(upper // step) * step

    strikes = list(
        range(
            start,
            end + step,
            step,
        )
    )

    logger.info(
        f"Generated {len(strikes)} strikes | " f"LTP={ltp} | " f"Range={range_points}"
    )

    return strikes


# =====================================================
# LOAD CACHE
# =====================================================


def load_option_chain_cache():

    global OPTION_CHAIN_CACHE

    try:

        logger.info("=" * 80)

        logger.info("📦 Loading Option Chain Cache From MongoDB...")

        docs = list(option_collection.find({}))

        OPTION_CHAIN_CACHE = {}

        if not docs:

            logger.warning("⚠️ No Option Chain Documents Found")

            return OPTION_CHAIN_CACHE

        loaded_count = 0

        for doc in docs:

            try:

                index_security_id = str(doc.get("index_security_id"))

                expiry = doc.get("expiry")

                OPTION_CHAIN_CACHE[index_security_id] = doc

                loaded_count += 1

                logger.info(
                    f"✅ Loaded Option Chain | "
                    f"Index={index_security_id} | "
                    f"Expiry={expiry}"
                )

            except Exception as e:

                logger.exception(
                    f"❌ Failed Processing Option Chain Doc | " f"Error={str(e)}"
                )

        logger.info(f"🎯 Option Chain Cache Ready | " f"Documents={loaded_count}")

        logger.info("=" * 80)

        return OPTION_CHAIN_CACHE

    except Exception as e:

        logger.exception(f"❌ Option Chain Cache Load Failed | " f"Error={str(e)}")

        return {}


# =====================================================
# GET SINGLE CHAIN
# =====================================================


def get_option_chain(
    index_security_id,
):

    try:

        return OPTION_CHAIN_CACHE.get(str(index_security_id))

    except Exception as e:

        logger.exception(
            f"❌ get_option_chain failed | "
            f"Index={index_security_id} | "
            f"Error={str(e)}"
        )

        return None


# =====================================================
# GET OPTION SECURITY IDS
# =====================================================


def get_option_security_ids(
    index_security_id,
    range_points=500,
    step=50,
):

    try:

        chain_doc = OPTION_CHAIN_CACHE.get(str(index_security_id))

        if not chain_doc:

            logger.warning(f"⚠️ No Option Chain Found | " f"Index={index_security_id}")

            return []

        option_chain = chain_doc.get("option_chain", {})

        ltp = option_chain.get("last_price")

        if not ltp:

            logger.warning(f"⚠️ No LTP Found | " f"Index={index_security_id}")

            return []

        strikes = generate_strikes(
            ltp=ltp,
            range_points=range_points,
            step=step,
        )
        logger.info(f"🎯 Generated Strikes={strikes}")
        oc = option_chain.get("oc", {})

        contracts = []

        for strike in strikes:

            strike_key = f"{strike:.6f}"

            strike_data = oc.get(strike_key)

            if not strike_data:

                logger.warning(f"⚠️ Strike Missing | " f"Strike={strike_key}")

                continue

            ce = strike_data.get("ce")
            pe = strike_data.get("pe")

            if ce:

                ce_sid = ce.get("security_id")

                if ce_sid:

                    contracts.append(
                        {
                            "strike": strike,
                            "type": "CE",
                            "security_id": ce_sid,
                        }
                    )

            if pe:

                pe_sid = pe.get("security_id")

                if pe_sid:

                    contracts.append(
                        {
                            "strike": strike,
                            "type": "PE",
                            "security_id": pe_sid,
                        }
                    )

        logger.info(
            f"🎯 Found "
            f"{len(contracts)} "
            f"Contracts | "
            f"Index={index_security_id}"
        )

        return contracts

    except Exception as e:

        logger.exception(
            f"❌ get_option_security_ids failed | "
            f"Index={index_security_id} | "
            f"Error={str(e)}"
        )

        return []


# =====================================================
# GET SUBSCRIPTION INSTRUMENTS
# =====================================================


def get_subscription_instruments(
    index_security_id,
    range_points=500,
    step=50,
):

    try:

        contracts = get_option_security_ids(
            index_security_id=index_security_id,
            range_points=range_points,
            step=step,
        )

        instruments = []

        for contract in contracts:

            instruments.append(
                (
                    2,
                    str(contract["security_id"]),
                    15,
                )
            )

        logger.info(f"📡 Subscription Instruments Ready | " f"Count={len(instruments)}")

        return instruments

    except Exception as e:

        logger.exception(
            f"❌ get_subscription_instruments failed | "
            f"Index={index_security_id} | "
            f"Error={str(e)}"
        )

        return []


# =====================================================
# CACHE STATUS
# =====================================================


def get_cache_status():

    try:

        indexes = list(OPTION_CHAIN_CACHE.keys())

        return {
            "loaded": True,
            "count": len(indexes),
            "indexes": indexes,
        }

    except Exception as e:

        logger.exception(f"❌ get_cache_status failed | " f"Error={str(e)}")

        return {
            "loaded": False,
            "count": 0,
            "indexes": [],
        }


# =====================================================
# CLEAR CACHE
# =====================================================


def clear_option_chain_cache():

    global OPTION_CHAIN_CACHE

    try:

        OPTION_CHAIN_CACHE = {}

        logger.info("🧹 Option Chain Cache Cleared")

    except Exception as e:

        logger.exception(f"❌ Cache Clear Failed | " f"Error={str(e)}")
