from config import settings

from index_levels import save_index_ohlc

from logger import get_logger

logger = get_logger("index_capture")


def save_all_indices(source="unknown"):

    try:

        logger.info("=" * 80)

        logger.info(f"🚀 Index OHLC Capture Started | " f"Source={source}")

        logger.info(f"📊 Total Configured Instruments=" f"{len(settings.INSTRUMENTS)}")

        success_count = 0
        failed_count = 0
        skipped_count = 0

        for index in settings.INSTRUMENTS:

            try:

                index_name = index.get(
                    "index_name",
                    "UNKNOWN",
                )

                security_id = index.get(
                    "security_id",
                    "UNKNOWN",
                )

                automation = index.get(
                    "automation",
                    False,
                )

                # ==========================================
                # AUTOMATION CHECK
                # ==========================================

                if not automation:

                    skipped_count += 1

                    logger.info(
                        f"⏭ Skipping Instrument | "
                        f"Index={index_name} | "
                        f"SecurityID={security_id} | "
                        f"Automation=False"
                    )

                    continue

                # ==========================================
                # FETCH OHLC
                # ==========================================

                logger.info(
                    f"📥 Fetching OHLC | "
                    f"Index={index_name} | "
                    f"SecurityID={security_id} | "
                    f"Source={source}"
                )

                result = save_index_ohlc(
                    index=index,
                    source=source,
                )

                success_count += 1

                logger.info(
                    f"✅ Saved | "
                    f"Index={index_name} | "
                    f"Open={result.get('open')} | "
                    f"High={result.get('high')} | "
                    f"Low={result.get('low')} | "
                    f"Close={result.get('close')} | "
                    f"LTP={result.get('last_price')}"
                )

            except Exception as e:

                failed_count += 1

                logger.exception(
                    f"❌ Failed Saving Index | "
                    f"Index={index.get('index_name')} | "
                    f"SecurityID={index.get('security_id')} | "
                    f"Error={str(e)}"
                )

        logger.info(
            f"🏁 Capture Finished | "
            f"Source={source} | "
            f"Success={success_count} | "
            f"Failed={failed_count} | "
            f"Skipped={skipped_count}"
        )

        logger.info("=" * 80)

    except Exception as e:

        logger.exception(
            f"❌ save_all_indices() failed | " f"Source={source} | " f"Error={str(e)}"
        )

        raise
