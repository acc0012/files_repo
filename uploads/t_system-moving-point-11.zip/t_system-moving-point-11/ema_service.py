import asyncio
import json
from datetime import datetime
from zoneinfo import ZoneInfo

import anyio
import requests

from cache import EMA_CACHE, EMA_SIGNALS, EMA_TASKS
from ws_listener import LIVE_TICKS

from config import settings
from logger import get_logger
from database import collection

logger = get_logger("ema_service")

# ==========================================================
# EMA CONFIG
# ==========================================================

EMA_FAST = 9
EMA_SLOW = 21

IST = ZoneInfo("Asia/Kolkata")

# ==========================================================
# MARKET HOURS
# ==========================================================

def is_market_open():

    now = datetime.now(IST)
    current_minutes = (now.hour * 60) + now.minute

    market_start = (9 * 60) + 15
    market_end = (15 * 60) + 40

    return market_start <= current_minutes <= market_end

# ==========================================================
# EMA CALC
# ==========================================================

def calculate_ema_value(previous_ema: float, close_price: float, period: int):
    multiplier = 2 / (period + 1)
    return (close_price * multiplier) + (previous_ema * (1 - multiplier))

# ==========================================================
# LOAD INITIAL HISTORY
# ==========================================================

def load_historical_data(security_id: int):

    logger.info(f"EMA history loading started security_id={security_id}")

    today = datetime.now(IST).strftime("%Y-%m-%d")

    url = f"{settings.BASE_URL}/dhan/intraday/"

    params = {
        "security_id": security_id,
        "exchange_segment": settings.INDEX_EXCHANGE_SEGMENT,
        "instrument_type": settings.INDEX_INSTRUMENT_TYPE,
        "from_date": today,
        "to_date": today,
    }

    response = requests.get(url, params=params, timeout=settings.REQUEST_TIMEOUT)
    response.raise_for_status()

    data = response.json()
    market_data = data.get("data", {}).get("data", {})

    closes = market_data.get("close", [])

    if not closes:
        raise ValueError(f"No close data found security_id={security_id}")

    ema9 = closes[0]
    ema21 = closes[0]

    for price in closes[1:]:
        ema9 = calculate_ema_value(ema9, price, EMA_FAST)
        ema21 = calculate_ema_value(ema21, price, EMA_SLOW)

    logger.info(
        f"EMA history loaded security_id={security_id} EMA9={round(ema9, 2)} EMA21={round(ema21, 2)}"
    )

    return {
        "ema9": ema9,
        "ema21": ema21,
        "last_close": closes[-1],
    }

# ==========================================================
# PROCESS CANDLE
# ==========================================================

def process_closed_candle(
    mongo_id,
    level_name,
    strike_group,
    option_side,
    security_id,
    close_price,
    candle_timestamp,
):

    try:
        state = EMA_CACHE.get(security_id)

        if not state:
            return

        old_fast_above = state["ema9"] > state["ema21"]

        state["ema9"] = calculate_ema_value(state["ema9"], close_price, EMA_FAST)
        state["ema21"] = calculate_ema_value(state["ema21"], close_price, EMA_SLOW)

        new_fast_above = state["ema9"] > state["ema21"]

        signal = None

        if not old_fast_above and new_fast_above:
            signal = "BUY"
        elif old_fast_above and not new_fast_above:
            signal = "SELL"

        EMA_CACHE[security_id] = {
            "ema9": round(state["ema9"], 2),
            "ema21": round(state["ema21"], 2),
            "last_close": round(close_price, 2),
        }

        if signal:
            signal_data = {
                "security_id": security_id,
                "signal": signal,
                "close_price": round(close_price, 2),
                "ema9": round(state["ema9"], 2),
                "ema21": round(state["ema21"], 2),
                "timestamp": candle_timestamp,
            }

            EMA_SIGNALS.setdefault(security_id, []).append(signal_data)

            collection.update_one(
                {"_id": mongo_id},
                {
                    "$push": {
                        f"intraday_data.{level_name}.{strike_group}.{option_side}.ema_signals_1_minute": signal_data
                    }
                },
            )

            logger.info(f"EMA SIGNAL: {json.dumps(signal_data)}")

    except Exception as e:
        logger.exception(f"EMA processing failed security_id={security_id} : {str(e)}")

# ==========================================================
# EMA ENGINE (NO WEBSOCKET)
# ==========================================================

async def run_ema_engine(
    mongo_id, level_name, strike_group, option_side, security_id
):

    logger.info(f"EMA engine started security_id={security_id}")

    current_candle = None

    try:
        history = load_historical_data(security_id)

        EMA_CACHE[security_id] = {
            "ema9": history["ema9"],
            "ema21": history["ema21"],
            "last_close": history["last_close"],
        }

        while True:

            try:

                if not is_market_open():
                    await asyncio.sleep(60)
                    continue

                tick = LIVE_TICKS.get(str(security_id))

                if not tick:
                    await asyncio.sleep(1)
                    continue

                if "LTP" not in tick:
                    await asyncio.sleep(1)
                    continue

                close_price = float(tick.get("LTP"))

                now = datetime.now(IST)
                minute_bucket = (now.hour * 60) + now.minute

                if current_candle is None:
                    current_candle = {
                        "minute": minute_bucket,
                        "close": close_price,
                    }
                    continue

                if minute_bucket != current_candle["minute"]:

                    process_closed_candle(
                        mongo_id,
                        level_name,
                        strike_group,
                        option_side,
                        security_id,
                        current_candle["close"],
                        current_candle["minute"] * 60,
                    )

                    current_candle = {
                        "minute": minute_bucket,
                        "close": close_price,
                    }

                else:
                    current_candle["close"] = close_price

                await asyncio.sleep(1)

            except Exception as e:
                logger.exception(f"EMA loop error security_id={security_id}: {str(e)}")
                await asyncio.sleep(2)

    except Exception as e:
        logger.exception(f"EMA engine failed security_id={security_id}: {str(e)}")

    finally:
        EMA_TASKS.pop(security_id, None)
        logger.info(f"EMA engine stopped security_id={security_id}")

# ==========================================================
# START ENGINE
# ==========================================================

def start_ema_engine(
    mongo_id, level_name, strike_group, option_side, security_id
):

    try:
        if security_id in EMA_TASKS:
            return

        result = anyio.from_thread.run(
            run_ema_engine,
            mongo_id,
            level_name,
            strike_group,
            option_side,
            security_id,
        )

        EMA_TASKS[security_id] = result

        logger.info(f"EMA engine started security_id={security_id}")

    except Exception as e:
        logger.exception(f"Failed starting EMA security_id={security_id}: {str(e)}")