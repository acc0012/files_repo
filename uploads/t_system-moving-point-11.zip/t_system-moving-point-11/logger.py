import logging
import sys
import os

# ✅ LOG DIRECTORY
LOG_DIR = "app_logs"

# ✅ Ensure folder exists
os.makedirs(LOG_DIR, exist_ok=True)


def get_logger(name: str):

    logger = logging.getLogger(name)

    # ✅ Prevent duplicate handlers
    if logger.handlers:
        return logger

    logger.setLevel(logging.INFO)

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
    )

    # =====================================================
    # ✅ CONSOLE HANDLER
    # =====================================================

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)

    # =====================================================
    # ✅ FILE HANDLER (PER MODULE)
    # =====================================================

    log_file_path = os.path.join(LOG_DIR, f"{name}.log")

    file_handler = logging.FileHandler(log_file_path, encoding="utf-8")
    file_handler.setFormatter(formatter)

    # =====================================================
    # ✅ ADD HANDLERS
    # =====================================================

    logger.addHandler(console_handler)
    logger.addHandler(file_handler)

    logger.propagate = False

    return logger