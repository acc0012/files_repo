import time
import requests

from datetime import datetime

from config import settings
from database import option_collection
from logger import get_logger

from strategy_levels import generate_full_strategy

# ✅ EXISTING
from ws_listener import start_option_feed

# ✅ NEW
from ema_service import start_ema_engine

logger = get_logger("strategy_runner")


# =====================================================
# FETCH OHLC
# =====================================================

def fetch_ohlc(security_id: int) -> dict:
    try:
        url = (
            f"{settings.BASE_URL}/dhan/ohlc/"
            f"?security_id={security_id}"
            f"&exchange_segment=IDX_I"
        )

        logger.info(f"🌐 Fetching OHLC | SecurityID={security_id}")
        logger.info(f"🔗 URL={url}")

        response = requests.get(
            url,
            timeout=settings.REQUEST_TIMEOUT,
        )

        response.raise_for_status()

        data = response.json()

        idx_data = data["data"]["data"]["data"]["IDX_I"][str(security_id)]

        ohlc = idx_data.get("ohlc")

        if not ohlc:
            raise ValueError("OHLC missing in API response")

        logger.info(
            f"✅ OHLC Received | "
            f"Open={ohlc.get('open')} | "
            f"High={ohlc.get('high')} | "
            f"Low={ohlc.get('low')} | "
            f"Close={ohlc.get('close')}"
        )

        return ohlc

    except Exception as e:
        logger.exception(
            f"❌ Failed to fetch OHLC | SecurityID={security_id} | Error={str(e)}"
        )
        raise


# =====================================================
# SUBSCRIBE CONTRACTS
# =====================================================

def subscribe_from_levels(security_id: int, contracts: list, index_name: str):
    try:
        if not contracts:
            logger.warning("⚠️ No contracts to subscribe")
            return [], []

        url = f"{settings.BASE_URL}/marketfeed/subscribe-option/{security_id}/"

        logger.info("=" * 80)
        logger.info(f"📡 Starting Subscription | SecurityID={security_id}")
        logger.info(f"📊 Total Contracts={len(contracts)}")

        subscribed = []
        failed = []

        mongo_id = f"{index_name}_{datetime.now().date()}"

        for contract in contracts:
            payload = {
                "strike_price": contract["strike"],
                "option_type": contract["type"].lower(),
            }

            success = False
            response_data = None

            for attempt in range(1, 4):
                try:
                    logger.info(
                        f"📤 Subscribe | "
                        f"Strike={contract['strike']} | "
                        f"Type={contract['type']} | "
                        f"Attempt={attempt}/3"
                    )

                    response = requests.post(
                        url,
                        json=payload,
                        timeout=settings.REQUEST_TIMEOUT,
                    )

                    response.raise_for_status()

                    response_data = response.json()

                    success = True
                    break

                except Exception as e:
                    logger.warning(
                        f"⚠️ Subscription Failed | "
                        f"Strike={contract['strike']} | "
                        f"Type={contract['type']} | "
                        f"Attempt={attempt} | "
                        f"Error={str(e)}"
                    )

                    if attempt < 3:
                        time.sleep(2)

            # ✅ SUCCESS CASE
            if success:
                subscribed.append(response_data)

                try:
                    instrument = response_data.get("instrument", {})
                    websocket_url = response_data.get("websocket_url")

                    security_id_opt = instrument.get("security_id")
                    strike = instrument.get("strike")
                    option_type = instrument.get("option_type")

                    # ✅ START WS
                    start_option_feed(
                        instrument=instrument,
                        websocket_url=websocket_url
                    )

                    # ✅ START EMA ENGINE (OPTION LEVEL)
                    try:
                        start_ema_engine(
                            mongo_id=mongo_id,
                            level_name="options",
                            strike_group=str(strike),
                            option_side=option_type,
                            security_id=int(security_id_opt),
                        )
                    except Exception as ema_err:
                        logger.warning(
                            f"⚠️ EMA Start Failed | SID={security_id_opt} | Error={str(ema_err)}"
                        )

                except Exception as ws_err:
                    logger.warning(
                        f"⚠️ WS Start Failed | "
                        f"Strike={contract['strike']} | "
                        f"Type={contract['type']} | "
                        f"Error={str(ws_err)}"
                    )

            # ❌ FAILED CASE
            else:
                failed.append(contract)

        logger.info(
            f"✅ Subscription Completed | "
            f"Success={len(subscribed)} | "
            f"Failed={len(failed)}"
        )

        logger.info("=" * 80)

        return subscribed, failed

    except Exception as e:
        logger.exception(
            f"❌ subscribe_from_levels failed | SecurityID={security_id} | Error={str(e)}"
        )
        return [], contracts


# =====================================================
# MAIN EXECUTION FUNCTION
# =====================================================

def run_level_based_subscription(index: dict, source="manual"):
    """
    Full pipeline:
    OHLC -> Levels -> Strikes -> Contracts -> Subscription -> EMA -> Save Mongo
    """

    try:
        security_id = index["security_id"]
        index_name = index.get("index_name", "UNKNOWN")

        logger.info("=" * 80)
        logger.info(
            f"🚀 Starting Strategy Run | "
            f"Index={index_name} | "
            f"SecurityID={security_id} | "
            f"Source={source}"
        )

        # =====================================================
        # STEP 1: FETCH OHLC
        # =====================================================

        ohlc = fetch_ohlc(security_id)

        # =====================================================
        # START EMA FOR MAIN INDEX (SPOT)
        # =====================================================

        try:
            start_ema_engine(
                mongo_id=f"{index_name}_{datetime.now().date()}",
                level_name="index",
                strike_group="spot",
                option_side="index",
                security_id=security_id,
            )
        except Exception as e:
            logger.warning(f"⚠️ Index EMA start failed | Error={str(e)}")

        # =====================================================
        # STEP 2–4: GENERATE STRATEGY
        # =====================================================

        strategy = generate_full_strategy(ohlc)

        levels = strategy["levels"]
        strikes = strategy["strikes"]
        contracts = strategy["contracts"]

        logger.info(
            f"📊 Strategy Generated | "
            f"Strikes={len(strikes)} | "
            f"Contracts={len(contracts)}"
        )

        # =====================================================
        # STEP 5: SUBSCRIBE + WS + EMA
        # =====================================================

        subscribed, failed = subscribe_from_levels(
            security_id,
            contracts,
            index_name
        )

        # =====================================================
        # STEP 6: SAVE TO MONGO
        # =====================================================

        document = {
            "_id": f"{index_name}_{datetime.now().date()}",
            "index_security_id": security_id,
            "index_name": index_name,

            "levels": levels,
            "strikes": strikes,
            "contracts": contracts,

            "subscribed": subscribed,
            "failed_subscriptions": failed,

            "source": source,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
        }

        result = option_collection.replace_one(
            {"_id": document["_id"]},
            document,
            upsert=True,
        )

        logger.info(
            f"💾 Mongo Saved | "
            f"Matched={result.matched_count} | "
            f"Modified={result.modified_count}"
        )

        logger.info(
            f"✅ Strategy Run Completed | "
            f"Index={index_name} | "
            f"SuccessSubs={len(subscribed)} | "
            f"FailedSubs={len(failed)}"
        )

        logger.info("=" * 80)

        return document

    except Exception as e:
        logger.exception(
            f"❌ Strategy execution failed | "
            f"Index={index.get('index_name')} | "
            f"Error={str(e)}"
        )
        raise
