import json
import time
import threading
import websocket

from config import settings
from logger import get_logger
from cache import LIVE_TICKS
logger = get_logger("ws_listener")

# =====================================================
# GLOBAL CONNECTION TRACKER
# =====================================================

ACTIVE_CONNECTIONS = set()
LOCK = threading.Lock()

# ✅ LIMIT (safety for thread explosion)
MAX_CONNECTIONS = 150


# =====================================================
# START OPTION FEED
# =====================================================

def start_option_feed(instrument: dict, websocket_url: str = None):
    """
    Starts WebSocket listener for a given option instrument.
    """

    try:
        security_id = str(instrument.get("security_id"))
        strike = instrument.get("strike")
        option_type = instrument.get("option_type")

        # =====================================================
        # CONNECTION CONTROL
        # =====================================================

        with LOCK:
            if security_id in ACTIVE_CONNECTIONS:
                logger.warning(f"⚠️ Already Connected | SID={security_id}")
                return

            if len(ACTIVE_CONNECTIONS) >= MAX_CONNECTIONS:
                logger.warning(
                    f"⚠️ Max WS Connections Reached | Limit={MAX_CONNECTIONS} | Skipping SID={security_id}"
                )
                return

            ACTIVE_CONNECTIONS.add(security_id)

        # =====================================================
        # BUILD WS URL
        # =====================================================

        if websocket_url:
            ws_url = f"{settings.BASE_WS_URL}{websocket_url}"
        else:
            ws_url = f"{settings.BASE_WS_URL}/market/{security_id}/"

        logger.info(
            f"🔌 Connecting WS | SID={security_id} | "
            f"Strike={strike} | Type={option_type}"
        )
        logger.info(f"🌐 WS URL = {ws_url}")

        last_log_time = 0

        # =====================================================
        # WS CALLBACKS
        # =====================================================

        def on_message(ws, message):
            nonlocal last_log_time

            try:
                data = json.loads(message)
                now = time.time()

                # ✅ NEW: STORE LIVE TICK
                LIVE_TICKS[security_id] = data

                # ✅ Rate-limited logging
                if now - last_log_time > 5:
                    logger.info(
                        f"📡 LIVE | SID={security_id} | "
                        f"LTP={data.get('LTP')} | "
                        f"Time={data.get('LTT')} | "
                        f"Status=ACTIVE"
                    )
                    last_log_time = now

            except Exception as e:
                logger.warning(
                    f"⚠️ Message Parse Error | SID={security_id} | Error={str(e)}"
                )

        def on_error(ws, error):
            logger.error(
                f"❌ WS Error | SID={security_id} | Error={str(error)}"
            )

        def on_close(ws, close_status_code, close_msg):
            logger.warning(
                f"🔌 WS Closed | SID={security_id} | Code={close_status_code}"
            )

            # ✅ Remove from active before reconnect
            with LOCK:
                ACTIVE_CONNECTIONS.discard(security_id)

            # ✅ Auto-reconnect
            time.sleep(2)
            start_thread()

        def on_open(ws):
            logger.info(f"✅ WS Connected | SID={security_id}")

        # =====================================================
        # RUN SOCKET
        # =====================================================

        def run(ws_url_to_use):
            ws = websocket.WebSocketApp(
                ws_url_to_use,
                on_open=on_open,
                on_message=on_message,
                on_error=on_error,
                on_close=on_close,
            )

            ws.run_forever()

        # =====================================================
        # THREAD STARTER
        # =====================================================

        def start_thread():
            def runner():

                # ✅ RE-ADD BEFORE CONNECT
                with LOCK:
                    ACTIVE_CONNECTIONS.add(security_id)

                try:
                    run(ws_url)

                except Exception as e:
                    logger.warning(
                        f"⚠️ Primary WS Failed | SID={security_id} | Error={str(e)}"
                    )

                    fallback_url = f"{settings.BASE_WS_URL}/market/{security_id}/"

                    try:
                        run(fallback_url)
                    except Exception as e2:
                        logger.error(
                            f"❌ Fallback WS Failed | SID={security_id} | Error={str(e2)}"
                        )

            thread = threading.Thread(target=runner, daemon=True)
            thread.start()

        # ✅ Start connection
        start_thread()

    except Exception as e:
        logger.exception(
            f"❌ start_option_feed failed | SID={instrument.get('security_id')} | Error={str(e)}"
        )