from contextlib import asynccontextmanager

from fastapi import FastAPI

from scheduler import start_scheduler
from services import save_all_indices

from strategy_runner import run_level_based_subscription
from config import settings
from logger import get_logger

logger = get_logger("application")


@asynccontextmanager
async def lifespan(app: FastAPI):

    try:

        logger.info("=" * 80)
        logger.info("🚀 Application Startup Initiated")
        logger.info("=" * 80)

        # =====================================================
        # INITIAL OHLC CAPTURE (LEGACY - KEEP IF NEEDED)
        # =====================================================

        try:
            logger.info("📊 Running startup OHLC capture...")
            save_all_indices(source="startup")
            logger.info("✅ Startup OHLC capture completed")

        except Exception as e:
            logger.exception(f"❌ Startup OHLC capture failed: {e}")

        # =====================================================
        # NEW: STRATEGY-BASED SUBSCRIPTION (CORE LOGIC)
        # =====================================================

        try:

            logger.info("🎯 Running Strategy-Based Subscription (Startup)...")

            for index in [
                {
                    "security_id": inst["security_id"],
                    "index_name": inst["index_name"],
                }
                for inst in settings.INSTRUMENTS
                if inst.get("automation", False)
            ]:

                run_level_based_subscription(
                    index=index,
                    source="startup"
                )

            logger.info("✅ Startup strategy execution completed")

        except Exception as e:
            logger.exception(f"❌ Startup strategy execution failed: {e}")

        # =====================================================
        # START SCHEDULER
        # =====================================================

        try:

            logger.info("⏰ Starting daily scheduler...")

            start_scheduler()

            logger.info("✅ Scheduler started successfully")

        except Exception as e:

            logger.exception(f"❌ Scheduler startup failed: {e}")

        logger.info("✅ Application startup completed")

        yield

    except Exception as e:

        logger.exception(f"❌ Fatal lifespan startup error: {e}")
        raise

    finally:

        try:

            logger.info("=" * 80)
            logger.info("🛑 Application Shutdown Initiated")
            logger.info("=" * 80)

            logger.info("✅ Application shutdown completed")

        except Exception as e:
            logger.exception(f"❌ Shutdown error: {e}")


# =====================================================
# FASTAPI APP
# =====================================================

app = FastAPI(
    title="TSystem Moving Point",
    lifespan=lifespan,
)