from pymongo import MongoClient

from config import settings

client = MongoClient(settings.MONGO_URL)

# OHLC
db = client[settings.MONGO_INDEX_LEVELS_DB]

collection = db[settings.MONGO_INDEX_LEVELS_COLLECTION]

# OPTION CHAIN
option_db = client[settings.MONGO_OPTION_CHAIN_DB]

option_collection = option_db[settings.MONGO_OPTION_COLLECTION]
