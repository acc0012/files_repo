import requests

from datetime import datetime

from config import settings
from database import collection
from logger import get_logger

logger = get_logger("index_levels")


def save_index_ohlc(
    index,
    source="unknown",
):

    try:

        security_id = index["security_id"]
        index_name = index["index_name"]

        logger.info(
            f"📥 Fetching OHLC | "
            f"Index={index_name} | "
            f"SecurityID={security_id} | "
            f"Source={source}"
        )

        url = (
            f"{settings.BASE_URL}"
            f"/dhan/ohlc/"
            f"?security_id={security_id}"
            f"&exchange_segment=IDX_I"
        )

        logger.info(f"🌐 Request URL => {url}")

        # =====================================================
        # API CALL
        # =====================================================

        response = requests.get(
            url,
            timeout=settings.REQUEST_TIMEOUT,
        )

        response.raise_for_status()

        logger.info(f"✅ API Success | " f"StatusCode={response.status_code}")

        # =====================================================
        # JSON PARSE
        # =====================================================

        try:

            data = response.json()

        except Exception as e:

            logger.exception(f"❌ Invalid JSON Response | " f"Index={index_name}")

            raise ValueError(f"Invalid JSON response: {e}")

        # =====================================================
        # VALIDATION
        # =====================================================

        try:

            idx_data = data["data"]["data"]["data"]["IDX_I"][str(security_id)]

        except Exception:

            logger.error(
                f"❌ Unexpected API Structure | "
                f"Index={index_name} | "
                f"Response={data}"
            )

            raise ValueError("Unable to locate IDX_I data")

        ohlc = idx_data.get("ohlc")

        if not ohlc:

            raise ValueError(f"OHLC data missing for {index_name}")

        # =====================================================
        # DOCUMENT
        # =====================================================

        document = {
            "_id": f"{index_name}_{datetime.now().date()}",
            "security_id": security_id,
            "index_name": index_name,
            "open": ohlc.get("open"),
            "high": ohlc.get("high"),
            "low": ohlc.get("low"),
            "close": ohlc.get("close"),
            "last_price": idx_data.get("last_price"),
            "capture_source": source,
            "capture_time": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
        }

        logger.info(f"💾 Saving Mongo | " f"DocID={document['_id']}")

        # =====================================================
        # SAVE MONGO
        # =====================================================

        result = collection.replace_one(
            {"_id": document["_id"]},
            document,
            upsert=True,
        )

        logger.info(
            f"✅ Mongo Saved | "
            f"Matched={result.matched_count} | "
            f"Modified={result.modified_count}"
        )

        logger.info(
            f"📊 {index_name} | "
            f"Open={document['open']} | "
            f"High={document['high']} | "
            f"Low={document['low']} | "
            f"Close={document['close']} | "
            f"LTP={document['last_price']}"
        )

        return document

    # =====================================================
    # REQUEST ERRORS
    # =====================================================

    except requests.Timeout:

        logger.exception(f"⏰ Request Timeout | " f"Index={index.get('index_name')}")

        raise

    except requests.ConnectionError:

        logger.exception(f"🔌 Connection Error | " f"Index={index.get('index_name')}")

        raise

    except requests.HTTPError as e:

        logger.exception(
            f"🚨 HTTP Error | " f"Index={index.get('index_name')} | " f"Error={e}"
        )

        raise

    # =====================================================
    # GENERAL ERROR
    # =====================================================

    except Exception as e:

        logger.exception(
            f"❌ save_index_ohlc Failed | "
            f"Index={index.get('index_name')} | "
            f"Source={source} | "
            f"Error={str(e)}"
        )

        raise
