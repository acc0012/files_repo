import os

from dotenv import load_dotenv

load_dotenv()


class Settings:

    # =====================================================
    # GENERAL
    # =====================================================

    HEART_BEAT_INTERVAL = int(os.getenv("HEART_BEAT_INTERVAL", "300"))

    # =====================================================
    # MONGODB
    # =====================================================

    MONGO_URL = os.getenv("MONGO_URL")
    MONGO_DB = os.getenv("MONGO_DB")
    MONGO_COLLECTION = os.getenv("MONGO_COLLECTION")

    # =====================================================
    # OPTION CHAIN CACHE (LEGACY / OPTIONAL)
    # =====================================================

    MONGO_OPTION_CHAIN_DB = os.getenv("MONGO_OPTION_CHAIN_DB")
    MONGO_OPTION_COLLECTION = os.getenv("MONGO_OPTION_COLLECTION")

    # =====================================================
    # INDEX LEVEL STORAGE (NEW STRATEGY DB)
    # =====================================================

    MONGO_INDEX_LEVELS_DB = os.getenv(
        "MONGO_INDEX_LEVELS_DB",
        "market_data"
    )

    MONGO_INDEX_LEVELS_COLLECTION = os.getenv(
        "MONGO_INDEX_LEVELS_COLLECTION",
        "daily_index_levels"
    )

    # =====================================================
    # EXTERNAL API
    # =====================================================

    BASE_URL = os.getenv("BASE_URL", "").strip()

    if not BASE_URL:
        raise ValueError("❌ BASE_URL is required in environment variables")

    BASE_WS_URL = BASE_URL.replace("https://", "wss://").replace("http://", "ws://")

    REQUEST_TIMEOUT = int(os.getenv("REQUEST_TIMEOUT", "30"))

    # ✅ SSL control
    VERIFY_SSL = os.getenv("VERIFY_SSL", "true").lower() == "true"

    # =====================================================
    # ✅ EMA / INTRADAY API CONFIG (NEW)
    # =====================================================

    INDEX_EXCHANGE_SEGMENT = os.getenv(
        "INDEX_EXCHANGE_SEGMENT",
        "IDX_I"
    )

    INDEX_INSTRUMENT_TYPE = os.getenv(
        "INDEX_INSTRUMENT_TYPE",
        "INDEX"
    )

    # =====================================================
    # INSTRUMENT CONFIG
    # =====================================================

    INSTRUMENTS = [
        {
            "security_id": 13,
            "index_name": "NIFTY",
            "automation": True,
            "timeframe": 1,
        },
        {
            "security_id": 21,
            "index_name": "INDIA-VIX",
            "automation": False,
        },
        {
            "security_id": 51,
            "index_name": "SENSEX",
            "automation": False,
        },
    ]

    INDEX_MAP = {
        item["index_name"].upper(): item["security_id"]
        for item in INSTRUMENTS
    }

    # =====================================================
    # STRATEGY CONFIG
    # =====================================================

    STRIKE_STEP_1 = int(os.getenv("STRIKE_STEP_1", "50"))
    STRIKE_STEP_2 = int(os.getenv("STRIKE_STEP_2", "100"))

    SUBSCRIPTION_RETRY = int(os.getenv("SUBSCRIPTION_RETRY", "3"))
    SUBSCRIPTION_RETRY_DELAY = int(os.getenv("SUBSCRIPTION_RETRY_DELAY", "2"))

    ENABLE_STARTUP_STRATEGY = os.getenv("ENABLE_STARTUP_STRATEGY", "true").lower() == "true"
    ENABLE_DAILY_STRATEGY = os.getenv("ENABLE_DAILY_STRATEGY", "true").lower() == "true"

    # =====================================================
    # VALIDATION CONFIG
    # =====================================================

    REQUIRED_FIELDS = [
        "TYPE",
        "HIGH",
        "LOW",
        "AVG",
        "RESISTANCE2",
        "SUPPORT2",
        "RESISTANCE3",
        "SUPPORT3",
    ]

    # =====================================================
    # LOGGING / DEBUG
    # =====================================================

    TEST_LOG_FILES = os.getenv("TEST_LOG_FILES", "false").lower() == "true"
    LOG_FOLDER = os.getenv("LOG_FOLDER", "test_logs")

    DEBUG = os.getenv("DEBUG", "false").lower() == "true"


# =====================================================
# LOAD SETTINGS
# =====================================================

settings = Settings()