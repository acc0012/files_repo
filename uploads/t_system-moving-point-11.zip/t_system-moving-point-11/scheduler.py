import threading
import time

from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from config import settings
from services import save_all_indices

from strategy_runner import run_level_based_subscription

from logger import get_logger

logger = get_logger("scheduler")

IST = ZoneInfo("Asia/Kolkata")


# =====================================================
# NEXT MARKET OPEN CALCULATOR
# =====================================================

def get_next_market_open(now):

    market_open_hour = 9
    market_open_minute = 16

    next_open = now.replace(
        hour=market_open_hour,
        minute=market_open_minute,
        second=0,
        microsecond=0,
    )

    # BEFORE MARKET OPEN TODAY
    if now < next_open and now.weekday() < 5:
        return next_open

    # NEXT BUSINESS DAY
    next_open += timedelta(days=1)

    while next_open.weekday() >= 5:
        next_open += timedelta(days=1)

    return next_open


# =====================================================
# SCHEDULER START
# =====================================================

def start_scheduler():

    try:
        logger.info("⏰ Initializing Scheduler...")

        def runner():

            logger.info("🚀 Scheduler thread started")

            ohlc_run_date = None
            strategy_run_date = None

            while True:

                try:
                    now = datetime.now(IST)
                    today = now.strftime("%Y-%m-%d")

                    # =====================================
                    # MARKET SESSION CHECK
                    # =====================================

                    market_open = now.replace(
                        hour=9,
                        minute=16,
                        second=0,
                        microsecond=0,
                    )

                    market_close = now.replace(
                        hour=16,
                        minute=40,
                        second=0,
                        microsecond=0,
                    )

                    market_active = (
                        now.weekday() < 5 and market_open <= now <= market_close
                    )

                    if not market_active:

                        next_open = get_next_market_open(now)

                        wait_seconds = int((next_open - now).total_seconds())
                        wait_hours = round(wait_seconds / 3600, 2)

                        logger.info("=" * 80)
                        logger.info("⏸ MARKET CLOSED")
                        logger.info(f"🕒 Current={now.strftime('%Y-%m-%d %H:%M:%S')}")
                        logger.info(f"🚀 Next Open={next_open.strftime('%Y-%m-%d %H:%M:%S')}")
                        logger.info(f"⏳ Wait={wait_hours} Hours")
                        logger.info("=" * 80)

                        sleep_time = min(wait_seconds, 300)
                        time.sleep(max(sleep_time, 60))
                        continue

                    # =====================================
                    # STRATEGY RUN (09:16)
                    # =====================================

                    if (
                        settings.ENABLE_DAILY_STRATEGY
                        and now.hour == 9
                        and now.minute >= 16
                        and strategy_run_date != today
                    ):

                        logger.info(
                            f"🎯 Scheduled Strategy Run Triggered | Date={today}"
                        )

                        try:

                            for inst in settings.INSTRUMENTS:
                                if not inst.get("automation", False):
                                    continue

                                run_level_based_subscription(
                                    index={
                                        "security_id": inst["security_id"],
                                        "index_name": inst["index_name"],
                                    },
                                    source="daily_0916",
                                )

                            strategy_run_date = today

                            logger.info(
                                f"✅ Strategy Execution Completed | Date={today}"
                            )

                        except Exception as e:
                            logger.exception(
                                f"❌ Strategy Execution Failed | Date={today} | Error={str(e)}"
                            )

                    # =====================================
                    # DAILY OHLC CAPTURE
                    # =====================================

                    if (
                        now.hour == 9
                        and now.minute >= 16
                        and ohlc_run_date != today
                    ):

                        logger.info(
                            f"📊 Scheduled OHLC Capture Triggered | Date={today}"
                        )

                        try:

                            save_all_indices(source="daily_0916")
                            ohlc_run_date = today

                            logger.info(
                                f"✅ Daily OHLC Capture Completed | Date={today}"
                            )

                        except Exception as e:
                            logger.exception(
                                f"❌ Daily OHLC Capture Failed | "
                                f"Date={today} | Error={str(e)}"
                            )

                    # =====================================
                    # HEARTBEAT
                    # =====================================

                    if now.minute % 16 == 0 and now.second < 30:
                        logger.info(
                            f"💓 Scheduler Alive | Time={now.strftime('%H:%M:%S')}"
                        )

                    time.sleep(30)

                except Exception as e:
                    logger.exception(f"❌ Scheduler Loop Error | Error={str(e)}")
                    time.sleep(30)

        scheduler_thread = threading.Thread(
            target=runner,
            daemon=True,
            name="MainScheduler",
        )

        scheduler_thread.start()

        logger.info(
            f"✅ Scheduler Started Successfully | Thread={scheduler_thread.name}"
        )

        return scheduler_thread

    except Exception as e:
        logger.exception(f"❌ Scheduler Startup Failed | Error={str(e)}")
        raise