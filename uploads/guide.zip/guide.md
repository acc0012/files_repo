# TradingView → Dhan Webhook Automation (Multi‑Leg)

> **Purpose (Educational / Setup Guide):** This guide explains how to connect **TradingView strategy alerts** to **Dhan Webhooks** for **multi‑leg orders**, and how to implement a common management rule: **TP1 → book half → move SL to Break‑Even → TP2**.

⚠️ **Risk Disclaimer:** Automated order execution can misfire (wrong symbol/expiry, quantity mismatch, alert delays, slippage). Always start with **paper trading / very small quantity** and validate the full workflow end‑to‑end before live use.

---

## 1) Prerequisites

1. **Dhan Trading Account** (logged in on web).
2. **TradingView paid plan** (TradingView webhooks require paid subscription).
3. A **TradingView Strategy** (Pine Script `strategy()`), not just an indicator, so it can emit strategy order alerts.

---

## 2) Dhan Side — Create Webhook + Multi‑Leg JSON

### Step 2.1 — Generate your Webhook
1. Login to **Dhan Web**.
2. Open **Orders → Webhooks**.
3. Click **Generate Webhook** and set validity.
4. Copy and store safely:
   - **Webhook URL**
   - **Secret**

> Dhan’s webhook flow is: *Orders → Webhooks → Generate Webhook → Add Scrip → Generate JSON*.

### Step 2.2 — Add each leg (Add Scrip)
1. Inside **Webhooks**, click **Add Scrip**.
2. Add each instrument you want in your multi‑leg order (example: 2 legs for a spread/straddle, 4 legs for an iron condor).
3. Save.

### Step 2.3 — Generate JSON
1. Click **Generate JSON**.
2. Dhan generates a JSON payload with structure like:

```json
{
  "secret": "YOUR_SECRET",
  "alertType": "multi_leg_order",
  "order_legs": [
    {
      "transactionType": "B",
      "orderType": "MKT",
      "quantity": "1",
      "exchange": "NSE",
      "symbol": "(Dhan generated symbol)",
      "instrument": "(FUT/OPT etc.)",
      "productType": "M",
      "sort_order": "1",
      "price": "0"
    }
  ]
}
```

> **Important:** Use the **exact symbol/instrument identifiers that Dhan generates** for each leg; do not guess.

### Step 2.4 — Make the JSON dynamic (for Buy/Sell and Quantity)
To reuse the same webhook message for entry + partial exit + full exit, replace:
- `transactionType` with `{{strategy.order.alert_message}}`
- `quantity` with `{{strategy.order.contracts}}`

Example (single leg shown — do the same for each leg):

```json
{
  "secret": "YOUR_SECRET",
  "alertType": "multi_leg_order",
  "order_legs": [
    {
      "transactionType": "{{strategy.order.alert_message}}",
      "orderType": "MKT",
      "quantity": "{{strategy.order.contracts}}",
      "exchange": "NSE",
      "symbol": "(Dhan generated symbol)",
      "instrument": "(Dhan generated instrument)",
      "productType": "M",
      "sort_order": "1",
      "price": "0"
    }
  ]
}
```

**Multi‑leg:** Just add more objects in `order_legs` and keep `sort_order` as `1,2,3,4…`.

---

## 3) TradingView Side — Strategy + Webhook Alert

### Step 3.1 — Add the Strategy on chart
1. Open TradingView (your account).
2. Open Pine Editor → paste the strategy template (see `pinescript_template.pine`).
3. Click **Add to chart**.

### Step 3.2 — Create Strategy Alert (Webhook)
1. Click **Alerts → Create Alert**.
2. **Condition:** Select your strategy name (not an indicator).
3. Choose the strategy event like **Order fills / Strategy order** (wording varies).
4. In **Notifications**, enable **Webhook URL** and paste your **Dhan webhook URL**.
5. In **Message**, paste your **dynamic multi‑leg JSON** from Step 2.4.
6. Create the alert.

> After this, whenever your strategy sends orders (entry/partial exit/exit), TradingView will call the webhook and Dhan will place the multi‑leg orders accordingly.

---

## 4) Strategy Logic — TP1 (partial) → Move SL to BE → TP2

### What we implement
- Enter position with `lots`
- **TP1 hit:** exit `50%`
- After TP1, **SL becomes Break‑Even** (entry price)
- **TP2 hit:** exit remaining

### Notes (very important)
- Multi‑leg option strategies are executed by Dhan using the **legs in the JSON**.
- Your TradingView strategy runs on the **chart symbol** (often NIFTY spot/futures). Decide whether your TP/SL is based on:
  - underlying points (simpler), or
  - combined premium (harder; requires synthetic series).
- Start with **small quantity** and verify order quantities match lots.

---

## 5) Testing Checklist (Must follow)

1. **Paper/Forward test** your TradingView strategy first.
2. Validate the webhook path with **1 lot**:
   - Entry order reaches Dhan
   - TP1 sends partial exit
   - SL changes behavior (BE after TP1)
   - TP2 exits remaining
3. Check **expiry/strike**: Dhan JSON legs are often fixed to what you added. Update legs when expiry changes.
4. Prefer **limit orders** for illiquid options if slippage is high; market orders can be costly.
5. If any alert fails, stop automation immediately and trade manually until fixed.

---

## 6) Troubleshooting

- **Alert fires but no order in Dhan:**
  - Webhook URL wrong, secret wrong, or message JSON invalid.
- **Quantity mismatch:**
  - TradingView sends `contracts`; ensure your mapping equals lots/quantity expected by Dhan.
- **Wrong instrument:**
  - Always use Dhan‑generated symbols in JSON.
- **Partial exit not working:**
  - Your strategy must generate a separate exit order with reduced qty/qty_percent.

---

## 7) Next customization you may want

- TP1 percent configurable (e.g., 40% exit)
- SL after TP1 = entry + buffer (e.g., +1 point)
- Trailing SL after TP1
- Time based exit (intraday square‑off)

---

### Files in this ZIP
- `guide.md` (this guide)
- `pinescript_template.pine` (strategy template with TP1/BE/TP2 logic)

