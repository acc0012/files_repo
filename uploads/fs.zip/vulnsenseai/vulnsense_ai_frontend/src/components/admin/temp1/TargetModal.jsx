import { useEffect, useState, useRef } from 'react';
import { FaWindowClose } from "react-icons/fa";
import { useLoader } from '../../loader/Loadercontext';
import { useFuzzLoader } from '../FuzzLoaderContext';
import { showToast } from '../../common/Toast';
import { get, post, del } from '../../auth/api';

const TargetModal = ({ isOpen, onClose, onSubmit, testType = 'fuzz' }) => {
  const [targets, setTargets] = useState([]);
  const [selectedTargets, setSelectedTargets] = useState([]);
  const [loading, setLoading] = useState(false);
  const { showLoader, hideLoader } = useLoader();
  const { setFuzzLoading } = useFuzzLoader();
  const isMounted = useRef(false); // Prevent multiple fetches

  useEffect(() => {
    if (!isOpen || isMounted.current) return;
    isMounted.current = true;
    // console.log(`[TargetModal] Opening modal for testType: ${testType}`); // Debug log
    const fetchTargets = async () => {
      showLoader();
      setLoading(true);
      try {
        const data = await get('/api/models/');
        // console.log(`[TargetModal] Fetched targets for ${testType}:`, data); // Debug log
        if (!Array.isArray(data)) {
          throw new Error('API response is not an array');
        }
        if (data.length === 0) {
          showToast(`No targets available for ${testType} testing`, 'warning');
        }
        setTargets(data.filter(target => target.id && target.model_name)); // Validate data
      } catch (error) {
        console.error(`[TargetModal] Error fetching targets for ${testType}:`, error);
        showToast(`Failed to fetch targets for ${testType} testing: ${error.message}`, 'error');
      } finally {
        hideLoader();
        setLoading(false);
      }
    };
    fetchTargets();

    return () => {
      isMounted.current = false; // Cleanup on unmount
      // console.log(`[TargetModal] Cleanup for testType: ${testType}`); // Debug log
    };
  }, [isOpen, testType, showLoader, hideLoader]);

  const handleSelectTarget = (targetId) => {
    setSelectedTargets(prev => {
      const newSelection = prev.includes(targetId)
        ? prev.filter(id => id !== targetId)
        : [...prev, targetId];
      // console.log(`[TargetModal] Updated selected targets for ${testType}:`, newSelection); // Debug log
      return newSelection;
    });
  };

  const handleSubmit = async () => {
    // console.log(`[TargetModal] Submitting targets for ${testType}:`, selectedTargets); // Debug log
    setFuzzLoading(true);
    if (!selectedTargets.length) {
      showToast('No targets selected', 'warning');
      setFuzzLoading(false);
      return;
    }
    try {
      const endpoint = testType === 'fuzz' ? '/api/fuzztest/' : '/api/loadtest/';
      // console.log(`[TargetModal] Sending POST to ${endpoint}`); // Debug log
      const promises = selectedTargets.map(id =>
        post(endpoint, { target: id })
      );
      const responses = await Promise.all(promises);
      // console.log(`[TargetModal] Test initiation responses for ${testType}:`, responses); // Debug log
      showToast(`${testType.charAt(0).toUpperCase() + testType.slice(1)} tests started successfully`, 'success');
      if (onSubmit) onSubmit(selectedTargets);
      setSelectedTargets([]); // Reset selection
    } catch (err) {
      console.error(`[TargetModal] Error starting ${testType} tests:`, err);
      showToast(`Failed to start ${testType} tests: ${err.message}`, 'error');
    } finally {
      setFuzzLoading(false);
    }
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className='target-modal-overlay'>
      <div className='target-modal'>
        <div className='target-modal-header'>
          <h1>Select Target for {testType.charAt(0).toUpperCase() + testType.slice(1)} Testing</h1>
          <button className='close-btn' onClick={onClose}><FaWindowClose /></button>
        </div>
        <div className='modal-body'>
          {loading ? (
            <p>Loading targets...</p>
          ) : targets.length === 0 ? (
            <p>No targets available for {testType} testing.</p>
          ) : (
            <div className='targets-list'>
              {targets.map(target => {
                const checked = selectedTargets.includes(target.id);
                return (
                  <div key={target.id} className={`target-card ${checked ? 'selected' : ''}`}>
                    <div className="target-content" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div className="target-info" style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                        <h4>{target.model_name || 'Unnamed Target'}</h4>
                        <p>{target.endpoint_url || '-'}</p>
                      </div>
                      <div className="target-checkbox">
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={() => handleSelectTarget(target.id)}
                          style={{ width: '24px', height: '24px', cursor: 'pointer' }}
                        />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
          <button className="btn btn-primary btn-full mt-2" onClick={handleSubmit} style={{ marginTop: '15px' }} disabled={loading}>
            Submit Selected Targets
          </button>
        </div>
      </div>
    </div>
  );
};

export default TargetModal;
