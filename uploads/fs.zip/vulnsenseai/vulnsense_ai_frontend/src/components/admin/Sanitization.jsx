import { useEffect, useState } from 'react';
import { CheckCircle, XCircle, Loader, Eye } from 'lucide-react';
import { get, post } from '../auth/api';
import DataTable from "react-data-table-component";
import { showToast } from '../common/Toast';
import { useLoader } from '../loader/Loadercontext';
import { useLlmLoader } from './LlmLoaderContext';

export default function Sanitization() {
  const { showLoader, hideLoader } = useLoader();

  // Dummy data for the existing data table
  const data = [
    { id: 1, Target: "http://www.google.com", Prompt: "algorithm for writing a fibonacci series", Type: "auto_sanitization" },
    { id: 2, Target: "http://www.google.com", Prompt: "prepare a cup of tea", Type: "manual_sanitization" },
    { id: 3, Target: "http://www.google.com", Prompt: "int main() { printf('Hello, World!'); return 0; }", Type: "auto_generate" },
    { id: 4, Target: "http://www.google.com", Prompt: "how to write a odd or even program", Type: "auto_sanitization" },
  ];

  // States for input, errors, responses
  const [prompt, setPrompt] = useState('');
  const [responsePrompt, setResponsePrompt] = useState('');
  const [originalprompt, setOriginalprompt] = useState('');
  const [error, setError] = useState('');
  const [generatePromptInput, setGeneratePromptInput] = useState('');
  const [generatedResponse, setGeneratedResponse] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [promptType, setPromptType] = useState('reasoning');
  const { setLlmLoading } = useLlmLoader();
  const [sanitizationData, setSanitizationData] = useState([]);
  const [generatedPrompts, setGeneratedPrompts] = useState([]);
  const [hoveredPromptId, setHoveredPromptId] = useState(null);

  const handlePromptChange = (e) => setPrompt(e.target.value);
  const handleGeneratePromptChange = (e) => setGeneratePromptInput(e.target.value);
  const handlePromptTypeChange = (e) => setPromptType(e.target.value);

  useEffect(() => {
    const fetchSanitizationData = async () => {
      try {
        const [sanitizationResponse, generatedPromptsResponse] = await Promise.all([
          get('api/list-sanitizations/'),
          get('api/list-generated-prompts/')
        ]);
              console.log(sanitizationResponse)
        setSanitizationData(sanitizationResponse.data || sanitizationResponse || []);
        setGeneratedPrompts(generatedPromptsResponse.data || generatedPromptsResponse || []);
      } catch (error) {
        console.error('Error fetching data:', error);
        setError('Failed to fetch prompts');
      }
    };
    fetchSanitizationData();
  }, []);

  const combinedData = [
    ...(sanitizationData.map(s => ({
      id: s.id,
      Target: "N/A",
      Prompt: s.prompt,
      Type: 'sanitization',
      responsePrompt: s?.response_prompt?.sanitized_prompt,
    }))),
    ...(generatedPrompts.map(gp => {
      let expandedPrompt = '';
      try {
        expandedPrompt = JSON.parse(gp.generated_response)?.expanded_prompt || '';
      } catch (err) {
        console.warn("Invalid JSON in generated_response:", gp.generated_response);
      }
      return {
        id: gp.id + 1000,
        Target: 'N/A',
        Prompt: gp.input_prompt,
        Type: 'generated',
        AdditionalInfo: expandedPrompt
      };
    }))
  ];

  const columns = [
    { name: "ID", selector: row => row.id, sortable: true },
    { name: "Target", selector: row => row.Target, sortable: true },
    { 
      name: "Prompt", 
      selector: row => row.Prompt, 
      sortable: true,
      cell: row => (
        <span>{row.Prompt.length > 30 ? `${row.Prompt.substring(0, 30)}...` : row.Prompt}</span>
      )
    },
    {
      name: "View",
      cell: row => (
        <div className="prompt-view-cell">
          <Eye 
            className="eye-icon" 
            size={18} 
            onMouseEnter={() => setHoveredPromptId(row.id)} 
            onMouseLeave={() => setHoveredPromptId(null)}
          />
          {hoveredPromptId === row.id && (
            <div className="prompt-hover-card">
              <h4>Prompt Details</h4>
              <p>{row.responsePrompt}</p>
            </div>
          )}
        </div>
      ),
      sortable: false,
      width: '80px'
    },
    { name: "Type", selector: row => row.Type, sortable: false },
  ];

  const handleSendPrompt = async () => {
    setLlmLoading(true);
    setError('');
    setResponsePrompt('');
    if (!prompt.trim()) {
      setError('Prompt cannot be empty.');
      return;
    }

    try {
      const apiEndpoint = 'api/sanitization/';
      const payload = { prompt: prompt };
      const response = await post(apiEndpoint, payload);

      setResponsePrompt(response.response_prompt.sanitized_prompt);
      setOriginalprompt(response.response_prompt.original_prompt);
      setPrompt('');
    } catch (err) {
      setError(`Error sending prompt: ${err.message}`);
      console.error('Error details:', err);
    } finally {
      setLlmLoading(false);
    }
  };

  const handleCopy = async (textToCopy) => {
    try {
      if (!textToCopy) {
        showToast('No text to copy', 'error');
        return;
      }
      await navigator.clipboard.writeText(textToCopy || 'No Response');
      showToast('Text copied to clipboard!', 'info');
    } catch (error) {
      showToast('Error copying text', 'error');
    }
  };

  const handleGeneratePrompt = async () => {
    setLlmLoading(true);
    setError('');
    setGeneratedResponse('');

    try {
      const apiEndpoint = 'api/generate-prompt/';
      const payload = { input_prompt: generatePromptInput };
      const response = await post(apiEndpoint, payload);
      setGeneratedResponse(response.generated_response.expanded_prompt);
      setGeneratePromptInput('');
      showToast("Prompt generated successfully!", "success");
    } catch (err) {
      setError(`Error sending prompt: ${err.message}`);
      console.error('Error details:', err);
    } finally {
      setLlmLoading(false);
    }
  };

  return (
    <div className="admin-content">
      <div className="section-header">
        <h2>Prompt Sanitization</h2>
        <p>Review all prompts sanitized by AIs</p>
      </div>

      <div className="sanitization-card">
        <div className="card-header">
          <h3>Manual Sanitization</h3>
          <textarea
            className="user-prompt"
            placeholder="Enter your prompt here to sanitize"
            value={prompt}
            onChange={handlePromptChange}
          />
          <div className="form-buttons">
            <button className="btn btn-primary" onClick={handleSendPrompt}>Sanitize</button>
            <button className="btn btn-outline">Cancel</button>
            <button className="btn btn-primary" onClick={() => handleCopy(responsePrompt)}>
              Copy
            </button>
          </div>

          {responsePrompt && (
            <div className="sout">
              <h4 style={{ marginTop: '15px' }}><strong>Sanitized Response:</strong></h4>
              <div className="output-box">{responsePrompt}</div>
            </div>
          )}
        </div>
      </div>

      <div className="sanitization-card">
        <div className="card-header">
          <div className="pg-dropdown">
            <h3>Prompt Generator</h3>
            <div style={{ margin: "10px 0" }}>
              <label>Type: </label>
              <select value={promptType} onChange={handlePromptTypeChange}>
                <option value="reasoning">Reasoning</option>
                <option value="photo">Photo</option>
                <option value="creative">Creative</option>
                <option value="analytical">Analytical</option>
                <option value="code">Code</option>
              </select>
            </div>
          </div>

          <textarea
            className="user-prompt-generator"
            placeholder="Enter your text here to generate prompt"
            value={generatePromptInput}
            onChange={handleGeneratePromptChange}
          />

          <div className="form-buttons">
            <button className="btn btn-primary" onClick={handleGeneratePrompt}>Generate</button>
            <button className="btn btn-outline">Cancel</button>
            <button className="btn btn-primary" onClick={() => handleCopy(generatedResponse)}>
              Copy
            </button>
          </div>

          {isGenerating && (
            <div style={{ margin: "10px 0" }}>
              <span>Generating...</span>
              <Loader className="inline-loader" size={20} />
            </div>
          )}

          {generatedResponse && (
            <div className="sout">
              <h4 style={{ marginTop: '15px' }}><strong>Generated Prompt:</strong></h4>
              <div className="output-box">{generatedResponse}</div>
            </div>
          )}
        </div>
      </div>

      <div style={{ padding: "20px" }}>
        <DataTable
          title="Prompts Overview"
          columns={columns}
          data={combinedData}
          pagination
          highlightOnHover
          striped
        />
      </div>

      {error && <div className="error-message">{error}</div>}
    </div>
  );
}