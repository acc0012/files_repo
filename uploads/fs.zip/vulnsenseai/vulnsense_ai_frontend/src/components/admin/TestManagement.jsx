import { useEffect, useState } from 'react';
import { Zap, Activity } from 'lucide-react';
import { get } from '../auth/api';
import { showToast } from '../common/Toast';
import { useLoader } from '../loader/Loadercontext';
import SecurityScanCard from './SecurityScanCard';
import TargetModal from './TargetModal';

export default function TestManagement() {
  const [tests, setTests] = useState(0); // Initialize as number (count of active tests)
  const [modalOpen, setModalOpen] = useState(false);
  const { showLoader, hideLoader } = useLoader();
  const [type, setType] = useState("fuzz"); // Default to fuzz test
  const [loadTestData, setLoadTestData] = useState(null); // Single object for load test
  const [fuzzTestData, setFuzzTestData] = useState(null); // Single object for fuzz test
  const [activeReportType, setActiveReportType] = useState("fuzz"); // Toggle between fuzz and load reports

  const fetchData = async () => {
    showLoader();
    try {
      const response = await get('api/dashboard/');
      setTests(response.total_active_targets || 0); // Ensure tests is a number
    } catch (error) {
      console.error('Error fetching tests:', error);
      showToast('Failed to fetch data', 'error');
    } finally {
      hideLoader();
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Determine which data to display based on activeReportType
  const testData = activeReportType === "fuzz" ? fuzzTestData : loadTestData;
  const reportTitle = activeReportType === "fuzz" ? "Fuzz Test Reports" : "Load Test Reports";

  return (
    <div className="admin-content">
      <div className="section-header">
        <h2>Automated Security Testing</h2>
        <p>Fuzz testing and load testing performed automatically by AI agents</p>
      </div>

      {/* Testing Cards */}
      <div className="testing-grid">
        {/* Fuzz Testing Card */}
        <div className="testing-card testing-fuzz">
          <div className="card-header">
            <h3><Zap className="card-icon" /> Fuzz Testing</h3>
            <p>Automated input fuzzing for vulnerability discovery</p>
          </div>
          <button
            className="btn btn-warning btn-full"
            onClick={() => {
              setModalOpen(true);
              setType("fuzz");
            }}
          >
            <Zap className="btn-icon" /> Start Fuzz Test
          </button>
        </div>

        {/* Load Testing Card */}
        <div className="testing-card testing-load">
          <div className="card-header">
            <h3><Activity className="card-icon" /> Load Testing</h3>
            <p>Performance testing and stress testing automation</p>
          </div>
          <button
            className="btn btn-success btn-full"
            onClick={() => {
              setModalOpen(true);
              setType("load");
            }}
          >
            <Activity className="btn-icon" /> Start Load Test
          </button>
        </div>

        {/* Security Scan Card */}
        <SecurityScanCard />
      </div>

      {/* Active Tests */}
      <div className="tests-card">
        <div className="card-header">
          <h3>Active Tests</h3>
          <p>Currently running automated security tests</p>
        </div>
        <div className="tests-list">
          <p><strong>Total Active Tests:</strong> {tests}</p>
        </div>
      </div>

      {/* Test Reports */}
      <div className="tests-card">
        <div className="card-header">
          <h3>{reportTitle}</h3>
          <p>Summary of completed {activeReportType} testing results</p>
          {/* Toggle between Fuzz and Load Test Reports */}
          <div className="report-toggle">
            <button
              className={`btn btn-outline ${activeReportType === "fuzz" ? "btn-active" : ""}`}
              onClick={() => setActiveReportType("fuzz")}
            >
              Fuzz Test
            </button>
            <button
              className={`btn btn-outline ${activeReportType === "load" ? "btn-active" : ""}`}
              onClick={() => setActiveReportType("load")}
            >
              Load Test
            </button>
          </div>
        </div>
        <div className="tests-list">
          {!testData ? (
            <p>No {activeReportType} test reports available.</p>
          ) : (
            <table className="test-results-table">
              <thead>
                <tr>
                  <th>Load Score</th>
                  <th>Load Weight</th>
                  <th>Accuracy Score</th>
                  <th>Summary</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>{testData.load_score || '-'}</td>
                  <td>{testData.load_weight || '-'}</td>
                  <td
                    style={{
                      color: testData.accuracy_score === '-' ? 'black' : testData.accuracy_score > 50 ? 'green' : 'red',
                    }}
                  >
                    {testData.accuracy_score ? `${testData.accuracy_score}%` : '-'}
                  </td>
                  <td>{testData.summary || 'No summary available'}</td>
                </tr>
              </tbody>
            </table>
          )}
        </div>
      </div>

      <TargetModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        type={type}
        setFuzzTestData={setFuzzTestData}
        setLoadTestData={setLoadTestData}
        onSubmit={fetchData} // Refresh tests count after submission
      />
    </div>
  );
}