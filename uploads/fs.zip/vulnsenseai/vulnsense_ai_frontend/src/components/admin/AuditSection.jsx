import { useEffect, useState } from 'react';
import { FileText, Trash2, FileCode, RefreshCw, Search, Download, BarChart3, CheckCircle, AlertTriangle } from 'lucide-react';
import { get, del } from '../auth/api';
import { useLoader } from '../loader/Loadercontext';

// ---------------- Dummy data for generated reports ----------------
const DUMMY_REPORTS = {
  fuzz: [
    { id: 1, target: "Model A", testcases: 100, passed: 95, issues: 5 },
    { id: 2, target: "Model B", testcases: 80, passed: 72, issues: 8 },
  ],
  load: [
    { id: 1, target: "Model A", requests: 1000, errors: 12, avgLatency: "230ms" },
    { id: 2, target: "Model B", requests: 1200, errors: 5, avgLatency: "180ms" },
  ],
  security: [
    { id: 1, target: "Model A", vulnerabilities: 7, high: 2, medium: 3, low: 2 },
    { id: 2, target: "Model B", vulnerabilities: 4, high: 1, medium: 2, low: 1 },
  ]
};

export default function AuditSection() {
  const [audits, setAudits] = useState([]);
  const [loading, setLoading] = useState(true);
  const { showLoader, hideLoader } = useLoader();
  const [targets, setTargets] = useState([]);
  const [reportType, setReportType] = useState("fuzz");
  const [generatedReports, setGeneratedReports] = useState([]);

  // Fetch targets (dummy API)
  useEffect(() => {
    const fetchTargets = async () => {
      showLoader();
      try {
        const data = await get('/api/models/');
        setTargets(data);
      } catch (error) {
        console.error('Error fetching targets:', error);
      } finally {
        hideLoader();
      }
    };
    fetchTargets();
  }, []);

  const generateReport = () => {
    // Just use dummy data based on selected report type
    setGeneratedReports(DUMMY_REPORTS[reportType] || []);
  };

  return (
    <div className="admin-content">
      <div className="section-header">
        <h2>Security Auditing & Reports</h2>
        <p>AI-generated security analysis and downloadable PDF reports</p>
      </div>

      {/* Generate Report Section */}
      <div className="audit-card">
        <div className="card-header">
          <h3><FileCode className="card-icon" /> Generate New Audit Report</h3>
          <p>Create comprehensive security audit for your targets</p>
        </div>
        <div className="audit-form">
          <div className="form-grid">
            <div className="form-group">
              <label htmlFor="target-select">Select Target</label>
              <select id="target-select" className="form-select">
                <option value="">Choose a target...</option>
                {targets.map((target) => (
                  <option key={target.id} value={target.id}>{target.model_name}</option>
                ))}
              </select>
            </div>
            <div className="form-group">
              <label htmlFor="report-type">Report Type</label>
              <select
                id="report-type"
                className="form-select"
                value={reportType}
                onChange={(e) => setReportType(e.target.value)}
              >
                <option value="fuzz">Fuzz Testing</option>
                <option value="load">Load Testing</option>
                <option value="security">Security Testing</option>
              </select>
            </div>
          </div>
          <button className="btn btn-purple" onClick={generateReport}>
            <RefreshCw className="btn-icon" /> Generate Audit Report
          </button>
        </div>
      </div>

      {/* Generated Reports Table */}
      <div className="reports-card">
        <div className="card-header">
          <h3>Generated Reports</h3>
          <p>Your security audit reports and analysis</p>
        </div>

        {generatedReports.length === 0 ? (
          <p>No reports generated yet.</p>
        ) : (
          <table className="report-table">
            <thead>
              <tr>
                <th>Target</th>
                {reportType === "fuzz" && <>
                  <th>Total Test Cases</th>
                  <th>Passed</th>
                  <th>Issues</th>
                </>}
                {reportType === "load" && <>
                  <th>Total Requests</th>
                  <th>Errors</th>
                  <th>Avg Latency</th>
                </>}
                {reportType === "security" && <>
                  <th>Total Vulnerabilities</th>
                  <th>High</th>
                  <th>Medium</th>
                  <th>Low</th>
                </>}
              </tr>
            </thead>
            <tbody>
              {generatedReports.map(report => (
                <tr key={report.id}>
                  <td>{report.target}</td>
                  {reportType === "fuzz" && <>
                    <td>{report.testcases}</td>
                    <td>{report.passed}</td>
                    <td>{report.issues}</td>
                  </>}
                  {reportType === "load" && <>
                    <td>{report.requests}</td>
                    <td>{report.errors}</td>
                    <td>{report.avgLatency}</td>
                  </>}
                  {reportType === "security" && <>
                    <td>{report.vulnerabilities}</td>
                    <td>{report.high}</td>
                    <td>{report.medium}</td>
                    <td>{report.low}</td>
                  </>}
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Analytics Cards (unchanged) */}
      <div className="analytics-grid">
        <div className="analytics-card">
          <div className="card-header">
            <h3><AlertTriangle className="card-icon" /> Vulnerability Trends</h3>
          </div>
          <div className="analytics-content">
            <div className="trend-item"><span>Critical</span><span className="trend-count trend-critical">2</span></div>
            <div className="trend-item"><span>High</span><span className="trend-count trend-high">5</span></div>
            <div className="trend-item"><span>Medium</span><span className="trend-count trend-medium">12</span></div>
            <div className="trend-item"><span>Low</span><span className="trend-count trend-low">8</span></div>
          </div>
        </div>
        <div className="analytics-card">
          <div className="card-header">
            <h3><BarChart3 className="card-icon" /> Risk Scores</h3>
          </div>
          <div className="analytics-center">
            <div className="metric-large">7.2</div>
            <p>Average Risk Score</p>
            <span>Across all targets</span>
          </div>
        </div>
        <div className="analytics-card">
          <div className="card-header">
            <h3><CheckCircle className="card-icon" /> Remediation</h3>
          </div>
          <div className="analytics-center">
            <div className="metric-large">73%</div>
            <p>Auto-Resolved</p>
            <span>Issues fixed by AI</span>
          </div>
        </div>
      </div>
    </div>
  );
}
