import { useEffect, useState } from 'react';
import { Globe, Activity, FileCode, Shield, Bot, CheckCircle } from 'lucide-react';
import { get } from '../auth/api';

export default function DashboardHome() {
  const [targets, setTargets] = useState([]);
  const [testResults, setTestResults] = useState([]);
  const [auditReports, setAuditReports] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
  
        const targetsData = await get('api/models/');
        setTargets(targetsData);

        const activityData = await get('api/activity/')
        // setActivity(activityData)
        setTestResults(activityData)

        // const testResultsData = [...activeTestsData, ...completedTestsData];
        // setTestResults(testResultsData);

        const auditsData = await get('api/test/report/');
        setAuditReports(auditsData);

      } catch (error) {
        console.error('Error fetching dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const response = await get('api/dashboard/');
        setStats(response);
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  if (loading) return <p>Loading dashboard...</p>;
  if (!stats) return <p>No data available</p>;

  return (
    <div className="admin-content">
      <div className="welcome-card">
        <p>
          Ready to secure your applications? You have {stats.total_active_targets} active targets,{' '}
          {stats.total_running_tests} tests currently running, and {stats.total_generated_reports} reports generated.
        </p>
      </div>

      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-header">
            <span className="stat-title">Active Targets</span>
            <Globe className="stat-icon" />
          </div>
          <div className="stat-content">
            <div className="stat-number">{stats.total_active_targets}</div>
            <p className="stat-description">Total active targets</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-header">
            <span className="stat-title">Running Tests</span>
            <Activity className="stat-icon" />
          </div>
          <div className="stat-content">
            <div className="stat-number">{stats.total_running_tests}</div>
            <p className="stat-description">Currently running fuzz tests</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-header">
            <span className="stat-title">Generated Reports</span>
            <FileCode className="stat-icon" />
          </div>
          <div className="stat-content">
            <div className="stat-number">{stats.total_generated_reports}</div>
            <p className="stat-description">Security audit reports ready</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-header">
            <span className="stat-title">Auto Sanitization</span>
            <Shield className="stat-icon" />
          </div>
          <div className="stat-content">
            <div className="stat-number">{stats.total_auto_sanitised}</div>
            <p className="stat-description">Targets with auto-sanitization enabled</p>
          </div>
        </div>
      </div>
      <div className="activity-card">
        <div className="card-header">
          <h3>Recent AI Actions</h3>
          <p>Latest automated security actions performed by the AI agent</p>
        </div>
        <div className="activity-list">
          {console.log(testResults)}
          {testResults.map(test => {
              const target = targets.find(t => t.id === test.target);
              return (
                <div key={test.id} className="activity-item activity-success">
                  <Bot className="activity-icon" />
                  <div className="activity-content">
                    {console.log(test.action)}
                    <p>Completed {test.action} test on {test.target.model_name}</p>
                    <span className="activity-time">{new Date(test.start_time).toLocaleString()} • {test.findings} findings</span>
                  </div>
                  <CheckCircle className="activity-status" />
                </div>
              );
            })}
        </div>
      </div>
    </div>
  );
}
