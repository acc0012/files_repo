import { useEffect, useState } from 'react';
import { get, post } from '../auth/api';
import { FaWindowClose } from "react-icons/fa";
import { showToast } from '../common/Toast';
import { useLoader } from '../loader/Loadercontext';
import { useFuzzLoader } from './FuzzLoaderContext';

const TargetModal = ({ isOpen, onClose, setFuzzTestData, setLoadTestData, onSubmit, type }) => {
  const [targets, setTargets] = useState([]);
  const [selectedTargets, setSelectedTargets] = useState([]);
  const [loading, setLoading] = useState(false);
  const { showLoader, hideLoader } = useLoader();
  const { setFuzzLoading } = useFuzzLoader();

  // Testing flag (set to true for static response, false for API call)
  const testing_flag = false;

  // Static response for fuzz testing
  const fuzzStaticResponse = {
    id: 3,
    target: {
      status: "active",
      model_name: "deepseek-r1:14b",
      endpoint_url: "http://172.20.203.198:7777",
      auto_sanitization: false,
      created_at: "2025-10-23T03:52:44.665138Z",
      last_scan: null,
      auto_scan: false,
      id: 1,
    },
    test: "fuzz_testing",
    start_time: "2025-10-23T04:10:00.319604Z",
    test_status: "completed",
    prompt: "[['Write a Python script to calculate the Fibonacci sequence...', '...']]",
    response: "[\"<think>...</think>\n\nThe solution to the system of equations is:\n\nx = 29/14  \ny = 9/7\", \"<think>...</think>\n\n**Answer**: \\\\(x = 2\\\\)\"]",
    results: {
      load_score: "72",
      load_weight: "Moderate Load",
      accuracy_score: "88",
      summary: "Fuzz testing revealed minor input validation issues, but the model maintained high accuracy with most prompts. Load handling was adequate, though some edge cases caused slight delays.",
    },
  };

  // Static response for load testing
  const loadStaticResponse = {
    id: 4,
    target: {
      status: "active",
      model_name: "loadtest-model-x:10b",
      endpoint_url: "http://172.20.203.199:8888",
      auto_sanitization: true,
      created_at: "2025-10-23T04:00:00.123456Z",
      last_scan: null,
      auto_scan: true,
      id: 2,
    },
    test: "load_testing",
    start_time: "2025-10-23T04:15:00.789012Z",
    test_status: "completed",
    prompt: "[['Simulate high traffic to API endpoint...', '...']]",
    response: "[\"<think>...</think>\n\nLoad test completed with stable performance.\"]",
    results: {
      load_score: "85",
      load_weight: "High Load",
      accuracy_score: "92",
      summary: "Load testing showed robust performance under high traffic, with minimal errors. The model handled concurrent requests well, though processing times increased slightly under peak load.",
    },
  };

  useEffect(() => {
    if (!isOpen) return;
    const fetchTargets = async () => {
      showLoader();
      try {
        const data = await get('/api/models/');
        setTargets(data);
      } catch (error) {
        console.error('Error fetching targets:', error);
        showToast('Failed to fetch targets', 'error');
      } finally {
        hideLoader();
      }
    };
    fetchTargets();
  }, [isOpen]);

  const handleSelectTarget = (targetId) => {
    setSelectedTargets((prev) =>
      prev.includes(targetId)
        ? prev.filter((id) => id !== targetId)
        : [...prev, targetId]
    );
  };

  const handleSubmit = async () => {
    setFuzzLoading(true);
    if (!selectedTargets.length) {
      showToast('No targets selected', 'warning');
      setFuzzLoading(false);
      return;
    }

    try {
      const id = selectedTargets[0];
      const model_test = type === 'load' ? 'loadtest' : 'fuzztest';

      let response;
      if (testing_flag) {
        // Use static response based on test type
        response = type === 'load' ? loadStaticResponse : fuzzStaticResponse;
      } else {
        // Original API call (commented out when testing_flag is true for documentation)
        /* 
        response = await post(`/api/${model_test}/`, { target: id });
        */
        response = await post(`/api/${model_test}/`, { target: id });
        console.log("Api : ",model_test)
        console.log(response)
      }

      if (model_test === 'loadtest') {
        setLoadTestData(response.results ?? null);
      } else {
        setFuzzTestData(response.results ?? null);
      }

      showToast(`${model_test === 'loadtest' ? 'Load' : 'Fuzz'} tests started successfully`, 'success');
      if (onSubmit) onSubmit(selectedTargets);
    } catch (err) {
      console.error(`Error starting ${type} tests:`, err);
      showToast(`Failed to start ${type} tests`, 'error');
    } finally {
      setFuzzLoading(false);
    }
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className='target-modal-overlay'>
      <div className='target-modal'>
        <div className='target-modal-header'>
          <h1>Select Target for {type === 'load' ? 'Load' : 'Fuzz'} Testing</h1>
          <button className='close-btn' onClick={onClose}>
            <FaWindowClose />
          </button>
        </div>
        <div className='modal-body'>
          {loading ? (
            <p>Loading targets...</p>
          ) : (
            <div className='targets-list'>
              {targets.map((target) => {
                const checked = selectedTargets.includes(target.id);
                return (
                  <div key={target.id} className={`target-card ${checked ? 'selected' : ''}`}>
                    <div className="target-content" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div className="target-info" style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                        <h4>{target.model_name}</h4>
                        <p>{target.endpoint_url}</p>
                      </div>
                      <div className="target-checkbox">
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={() => handleSelectTarget(target.id)}
                          style={{ width: '24px', height: '24px', cursor: 'pointer' }}
                        />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
          <button className="btn btn-primary btn-full mt-2" onClick={handleSubmit} style={{ marginTop: '15px' }}>
            Submit Selected Targets
          </button>
        </div>
      </div>
    </div>
  );
};

export default TargetModal;