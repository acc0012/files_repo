from django.urls import path
from .views import *

urlpatterns = [
    path("models/", TargetModelListCreateDeleteView.as_view(), name="model-list-create"),
    #path("sanitization/manual/", ManualPromptGetAPI.as_view(),name="manual-sanitization"),
    path("sanitization/", ManualSanitizationView.as_view(), name="manual-sanitization-post"),
    path('list-sanitizations/', SanitizationAPIView.as_view(), name='sanitization-list'),
    path('list-generated-prompts/', GeneratedPromptAPIView.as_view(), name='generated-prompt-list'),
    path('generate-prompt/', PromptGenerate.as_view(), name='generate_prompt'),
    path("dashboard/",AdminOverviewStatsView.as_view(),name="dashboard"),
    path('target/status/<int:pk>/',TargetStatusView.as_view(),name="targetstatus"),
    path('target/delete/<int:pk>/', TargetModelListCreateDeleteView.as_view(), name="targetdelete"),
    path("test/active/",ActiveReportView.as_view(),name="testreport"),
    path("test/completed/",CompletedReportView.as_view(),name="testcomplete"),
    path('test/report/',GeneratedReportView.as_view(),name="audit_report"),
    path('logout/',LogoutView.as_view(),name="logout"),
    path('activity/',SystemActivityView.as_view(),name="system_activity"),
    path('fuzztest/',FuzzTestingView.as_view(),name='fuzztesting'),
    # path('scan/Unbounded_consumption/',Unbounded_consumption.as_view(),name='scan-Unbounded-consumption'),
    path('fuzzresult/',FuzzTestResults.as_view(),name="fuzz_reports"),
    path('loadtest/',LoadTestView.as_view(),name="load_testing"),
    path('reports/',TestResultsView.as_view(),name="test_results")
]




