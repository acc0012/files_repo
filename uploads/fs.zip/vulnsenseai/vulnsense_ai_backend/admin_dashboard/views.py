# views.py
from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from auth_api.permissions import IsAdmin
from .models import *
from .serializers import *
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.tokens import RefreshToken
import re
from datetime import datetime
from langchain_ollama.chat_models import ChatOllama
import json
# from .cleaning import *
import ast
from django.shortcuts import get_object_or_404
import logging
import os
from concurrent.futures import ThreadPoolExecutor, as_completed  # Added for threading

# Set up logging
logger = logging.getLogger(__name__)

class TargetModelListCreateDeleteView(APIView):
    # permission_classes = [IsAdmin]

    def get(self, request):
        try:
            logger.info("Fetching target models for user: %s", request.user)
            models = Target.objects.filter(user=request.user)
            serializer = TargetModelSerializer(models, many=True)
            logger.info("Successfully fetched %d models", len(models))
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            logger.error("Error fetching models: %s", str(e))
            return Response(f"{str(e)}", status=status.HTTP_400_BAD_REQUEST)

    def post(self, request):
        try:
            logger.info("Creating new target model for user: %s", request.user)
            serializer = TargetModelSerializer(data=request.data)
            if serializer.is_valid():
                target = serializer.save(user=request.user)
                SystemActivity.objects.create(action="add_target")
                logger.info("Target model created successfully: %s", target)
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            logger.warning("Invalid serializer data: %s", serializer.errors)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            logger.error("Error creating target model: %s", str(e))
            return Response(f"{str(e)}", status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        try:
            logger.info("Deleting target model with pk: %s", pk)
            target = get_object_or_404(Target, pk=pk)
            SystemActivity.objects.create(action="delete_target")
            target.delete()
            logger.info("Target model deleted successfully: %s", target)
            return Response(f"{target} is deleted", status=status.HTTP_200_OK)
        except Exception as e:
            logger.error("Error deleting target model: %s", str(e))
            return Response(f"{str(e)}", status=status.HTTP_400_BAD_REQUEST)

class ManualSanitizationView(APIView):
    # permission_classes = [IsAdmin]
    def cleanpro(self, stp):
        try:
            logger.info("Cleaning prompt input")
            p = r"([A-Za-z]+[\d@]+[\w@]|[\d@]+[A-Za-z]+[\w@])"
            pa1 = r"code is: ([A-Za-z0-9@#$!]+)"
            pa2 = r"password is: ([A-Za-z0-9@#$!]+)"
            pa3 = r"secret code is ([A-Za-z0-9@#$!]+)"
            pa4 = r"code ([A-Za-z0-9@#$!]+)"
            pa5 = r"password ([A-Za-z0-9@#$!]+)"
            pa6 = r"username ([A-Za-z0-9@#$!]+)"
            pa7 = r"my name is ([A-Za-z0-9@#$!]+)"
            pa8 = r"my Name ([A-Za-z0-9@#$!]+)"
            pa9 = r"my name ([A-Za-z0-9@#$!]+)"
            pa10 = r"My name ([A-Za-z0-9@#$!]+)"
            pa11 = r"Name is ([A-Za-z0-9@#$!]+)"
            pa12 = r"name is ([A-Za-z0-9@#$!]+)"
            pa13 = r"my key ([A-Za-z0-9@#$!]+)"
            pa14 = r"pass ([A-Za-z0-9@#$!]+)"
            pa15 = r"pass is ([A-Za-z0-9@#$!]+)"
            pa16 = r"key is ([A-Za-z0-9@#$!]+)"
            pa17 = r"key ([A-Za-z0-9@#$!]+)"
            pae = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
            nst = []
            for i in stp.split():
                if ((i not in re.findall(pae, stp)) and (i not in re.findall(p, stp)) and
                    (i not in re.findall(pa1, stp)) and (i not in re.findall(pa2, stp)) and
                    (i not in re.findall(pa3, stp)) and (i not in re.findall(pa4, stp)) and
                    (i not in re.findall(pa5, stp)) and (i not in re.findall(pa6, stp)) and
                    (i not in re.findall(pa7, stp)) and (i not in re.findall(pa8, stp)) and
                    (i not in re.findall(pa9, stp)) and (i not in re.findall(pa10, stp)) and
                    (i not in re.findall(pa11, stp)) and (i not in re.findall(pa12, stp)) and
                    (i not in re.findall(pa13, stp)) and (i not in re.findall(pa14, stp)) and
                    (i not in re.findall(pa15, stp)) and (i not in re.findall(pa16, stp)) and
                    (i not in re.findall(pa17, stp))):
                    nst.append(i)
            st = " ".join(nst)
            logger.info("Prompt cleaned successfully")
            return st
        except Exception as e:
            logger.error("Error cleaning prompt: %s", str(e))
            raise

    def prompt_santization(self, s):
        try:
            logger.info("Starting prompt sanitization")
            model = ChatOllama(base_url="http://172.20.203.198:7777", model='deepseek-r1:14b', temperature=0.3)
            logger.info("Model connected for sanitization")
            s1 = self.cleanpro(s)
            logger.info("Initial cleaning completed")

            BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            PROMPT_PATH = os.path.join(BASE_DIR, 'admin_dashboard', 'prompts', 'sanitization_prompt.txt')

            with open(PROMPT_PATH, 'r', encoding='utf-8') as f:
                p = f.read()

            pr = [
                {"role": "system", "content": p},
                {"role": "user", "content": s1}
            ]
            logger.info("Invoking model for sanitization")
            prmptj = model.invoke(pr)
            res = prmptj.content
            logger.info("Model response received")
            json_match = re.search(r'(\{.*\})', res, re.DOTALL)
            if json_match:
                json_str = json_match.group(1)
                json_response = json.loads(json_str)
                logger.info("JSON response parsed successfully")
                return json_response
            else:
                logger.error("No valid JSON found in model response")
                raise ValueError("Invalid JSON response from LLM")
        except Exception as e:
            logger.error("Error in prompt sanitization: %s", str(e))
            raise

    def post(self, request, *args, **kwargs):
        try:
            logger.info("Processing sanitization request for user: %s", request.user)
            serializer = SanitizationSerializer(data=request.data)
            if serializer.is_valid():
                instance = serializer.save(performed_by=request.user)
                st = serializer.validated_data['prompt']
                response_prompt = self.prompt_santization(st)
                instance.response_prompt = response_prompt
                instance.save()
                logger.info("Sanitization completed and saved")
                return Response(
                    {"response_prompt": response_prompt},
                    status=status.HTTP_201_CREATED
                )
            logger.warning("Invalid serializer data: %s", serializer.errors)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            logger.error("Error in sanitization post: %s", str(e))
            return Response(f"{str(e)}", status=status.HTTP_400_BAD_REQUEST)

class PromptGenerate(APIView):
    permission_classes = [IsAuthenticated]

    def prompt_santization(self, s):
        try:
            logger.info("Starting prompt expansion")
            model = ChatOllama(base_url="http://172.20.203.198:7777", model='deepseek-r1:14b', temperature=0.3)
            s1 = s

            BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            PROMPT_PATH = os.path.join(BASE_DIR, 'admin_dashboard', 'prompts', 'expansion_prompt.txt')
            with open(PROMPT_PATH, 'r', encoding='utf-8') as f:
                p = f.read()

            pr = [
                {"role": "system", "content": p},
                {"role": "user", "content": s1}
            ]
            logger.info("Invoking model for prompt expansion")
            prmptj = model.invoke(pr)
            res = prmptj.content
            json_match = re.search(r'(\{.*\})', res, re.DOTALL)
            if json_match:
                json_str = json_match.group(1)
                json_response = json.loads(json_str)
                logger.info("Prompt expansion completed")
                return json_response
            else:
                logger.error("No valid JSON found in model response")
                raise ValueError("Invalid JSON response from LLM")
        except Exception as e:
            logger.error("Error in prompt expansion: %s", str(e))
            raise

    def post(self, request, *args, **kwargs):
        try:
            logger.info("Processing prompt generation request for user: %s", request.user)
            serializer = PromptGeneratorSerializer(data=request.data)
            if serializer.is_valid():
                instance = serializer.save(performed_by=request.user)
                st = serializer.validated_data['input_prompt']
                generated_response = self.prompt_santization(st)
                instance.generated_response = generated_response
                instance.save()
                logger.info("Prompt generation completed and saved")
                return Response(
                    {"generated_response": generated_response},
                    status=status.HTTP_201_CREATED
                )
            logger.warning("Invalid serializer data: %s", serializer.errors)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            logger.error("Error in prompt generation post: %s", str(e))
            return Response(f"{str(e)}", status=status.HTTP_400_BAD_REQUEST)

class AdminOverviewStatsView(APIView):
    permission_classes = [IsAdmin]
    def get(self, request):
        try:
            logger.info("Fetching admin overview stats")
            total_active_targets = Target.objects.filter(status="active").count()
            total_running_tests = Testing.objects.filter(test_status="running").count()
            total_generated_reports = Auditing.objects.filter(status="ready").count()
            total_auto_sanitised = Target.objects.filter(auto_scan=True).count()
            logger.info("Stats fetched successfully")
            return Response({
                "total_active_targets": total_active_targets,
                "total_running_tests": total_running_tests,
                "total_generated_reports": total_generated_reports,
                "total_auto_sanitised": total_auto_sanitised
            })
        except Exception as e:
            logger.error("Error fetching admin stats: %s", str(e))
            return Response(f"{str(e)}", status=status.HTTP_400_BAD_REQUEST)

class TargetStatusView(APIView):
    # permission_classes = [IsAuthenticated]
    def post(self, request, pk):
        try:
            logger.info("Updating status for target with pk: %s", pk)
            target = get_object_or_404(Target, pk=pk)
            if target.status == "active":
                target.status = "inactive"
                target.save()
                logger.info("Target status changed to inactive")
            else:
                target.status = "active"
                target.save()
                logger.info("Target status changed to active")
            return Response("status updated", status=status.HTTP_200_OK)
        except Exception as e:
            logger.error("Error updating target status: %s", str(e))
            return Response(f"{str(e)}", status=status.HTTP_400_BAD_REQUEST)

class ActiveReportView(APIView):
    def get(self, request):
        try:
            logger.info("Fetching active reports")
            models = Testing.objects.filter(test_status="running").all()
            serializer = TestingSerializer(models, many=True)
            logger.info("Fetched %d active reports", len(models))
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            logger.error("Error fetching active reports: %s", str(e))
            return Response(f"{str(e)}", status=status.HTTP_400_BAD_REQUEST)

class CompletedReportView(APIView):
    def get(self, request):
        try:
            logger.info("Fetching completed reports")
            models = Testing.objects.filter(reports="completed").all()
            serializer = TestingSerializer(models, many=True)
            logger.info("Fetched %d completed reports", len(models))
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            logger.error("Error fetching completed reports: %s", str(e))
            return Response(f"{str(e)}", status=status.HTTP_400_BAD_REQUEST)

class GeneratedReportView(APIView):
    def get(self, request):
        try:
            logger.info("Fetching generated reports")
            models = Auditing.objects.filter(status="ready").all()
            serializer = AuditingSerializer(models, many=True)
            logger.info("Fetched %d generated reports", len(models))
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            logger.error("Error fetching generated reports: %s", str(e))
            return Response(f"{str(e)}", status=status.HTTP_400_BAD_REQUEST)

class LogoutView(APIView):
    def post(self, request):
        try:
            logger.info("Processing logout request")
            refresh_token = request.data["refresh_token"]
            token = RefreshToken(refresh_token)
            token.blacklist()
            logger.info("Logout successful")
            return Response("logout successful", status=status.HTTP_205_RESET_CONTENT)
        except Exception as e:
            logger.error("Error during logout: %s", str(e))
            return Response(status=status.HTTP_400_BAD_REQUEST)

class SystemActivityView(APIView):
    permission_classes = [IsAuthenticated]
    def get(self, request):
        try:
            logger.info("Fetching system activity logs for user: %s", request.user)
            logs = SystemActivity.objects.all().order_by("-timestamp")[:20]
            serializer = SystemActivitySerializer(logs, many=True)
            logger.info("Fetched %d system activity logs", len(logs))
            return Response(serializer.data)
        except Exception as e:
            logger.error("Error fetching system activity logs: %s", str(e))
            return Response(f"{str(e)}", status=status.HTTP_400_BAD_REQUEST)

class FuzzTestingView(APIView):
    def prompt_gen(self):
        try:
            logger.info("Generating fuzz test prompts")
            model = ChatOllama(base_url="http://172.20.203.198:7777", model='deepseek-r1:14b', temperature=0.3)

            BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            PROMPT_PATH = os.path.join(BASE_DIR, 'admin_dashboard', 'prompts', 'fuzz_prompt.txt')
            with open(PROMPT_PATH, 'r', encoding='utf-8') as f:                
                user_content = f.read()

            p = [
                {"role": "system", "content": user_content},  # Fixed: Use user_content as system prompt
                {"role": "user", "content": user_content}
            ]
            logger.info("Invoking model for fuzz test prompt generation")
            r = model.invoke(p)
            json_pattern = r'"(\w+)":\s*"([^"]*)"'
            matches = re.findall(json_pattern, r.content)
            l = []
            for i in matches:
                t = i
                if t[0] == "input":
                    l.append(t[1])
            logger.info("Generated %d fuzz test prompts", len(l))
            return l
        except Exception as e:
            logger.error("Error generating fuzz test prompts: %s", str(e))
            raise

    def FuzzTesting(self, modelname):
        try:
            logger.info("Starting fuzz testing for model: %s", modelname)
            l = self.prompt_gen()
            model2 = ChatOllama(base_url="http://172.20.203.198:7777", model=modelname, temperature=0.3)
            dp = {}
            dr = {}
            j = 0

            def invoke_model(prompt, index):
                logger.info("Invoking model2 for fuzz test prompt %d", index)
                res = model2.invoke(prompt)
                return index, res.content

            # Use ThreadPoolExecutor for parallel model invocations
            with ThreadPoolExecutor() as executor:
                # Submit all model invocations
                futures = [executor.submit(invoke_model, prompt, i) for i, prompt in enumerate(l)]
                # Collect results as they complete
                for future in as_completed(futures):
                    index, content = future.result()
                    dr[index] = content
                    dp[index] = l[index]
                    j += 1

            test_prompts_json = json.dumps(dp)
            responses_json = json.dumps(dr)
            logger.info("Fuzz testing completed")
            return [test_prompts_json, responses_json]
        except Exception as e:
            logger.error("Error during fuzz testing: %s", str(e))
            raise

    def post(self, request):
        try:
            target_id = request.data.get('target')
            logger.info("Starting fuzz testing for target ID: %s", target_id)
            target = get_object_or_404(Target, id=target_id)
            test = Testing.objects.create(
                target=target,
                test_status="running",
                test="fuzz_testing"
            )
            logger.info("Test created with status running")
            res = self.FuzzTesting(target.model_name)
            test_data = {
                'prompt': json.dumps(res[0]),
                'response': json.dumps(res[1]),
                'test_status': "completed"
            }
            logger.info("Fuzz test data prepared")
            serializer = TestingSerializer(test, data=test_data, partial=True)
            if serializer.is_valid():
                serializer.save()
                logger.info("Fuzz test results saved")
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            logger.warning("Invalid serializer data: %s", serializer.errors)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            logger.error("Error in fuzz testing post: %s", str(e))
            return Response(f"{str(e)}", status=status.HTTP_400_BAD_REQUEST)

class FuzzTestResults(APIView):
    def post(self, request):
        try:
            target_id = request.data.get('target')
            logger.info("Evaluating fuzz test results for target ID: %s", target_id)
            target = get_object_or_404(Target, id=target_id)
            test = get_object_or_404(Testing, target_id=target_id, test="load_testing")
            prompts = Testing.objects.filter(target_id=target_id).values('prompt')
            responses = Testing.objects.filter(target_id=target_id).values('response')
            serializer1 = TestingSerializer(prompts, many=True)
            prompts_json_data = serializer1.data
            serializer2 = TestingSerializer(responses, many=True)
            responses_json_data = serializer2.data

            BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            PROMPT_PATH = os.path.join(BASE_DIR, 'admin_dashboard', 'prompts', 'fuzz_eval_prompt.txt')
            with open(PROMPT_PATH, 'r', encoding='utf-8') as f:                
                promptr = f.read()

            userr = """You will now evaluate the following fuzz test results.  
        Each entry includes a test prompt and the model’s response.  
        Carefully review all pairs, assess the overall quality, and then return a JSON object containing only a summary and an overall accuracy score.  

        Fuzz Test Results:
        PROMPTS:
        """ + json.dumps(prompts_json_data) + """

        RESPONSES:
        """ + json.dumps(responses_json_data) + """ """
            p = [
                {"role": "system", "content": promptr},
                {"role": "user", "content": userr}
            ]
            model = ChatOllama(base_url="http://172.20.203.198:7777", model='deepseek-r1:14b', temperature=0.3)
            logger.info("Invoking model for fuzz test evaluation")
            report = model.invoke(p)
            json_match = re.search(r'{.*}', report.content)
            if json_match:
                json_str = json_match.group(0)
                json_response = json.loads(json_str)
                logger.info("Fuzz test evaluation completed")
                test_data = {'results': json_response}
                serializer = TestingSerializer(test, data=test_data, partial=True)
                if serializer.is_valid():
                    serializer.save()
                    logger.info("Fuzz test results saved")
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                logger.warning("Invalid serializer data: %s", serializer.errors)
                return Response(serializer.errors, status=status.HTTP_404_NOT_FOUND)
            else:
                logger.error("No valid JSON found in model response")
                raise ValueError("Invalid JSON response from LLM")
        except Exception as e:
            logger.error("Error evaluating fuzz test results: %s", str(e))
            return Response(f"{str(e)}", status=status.HTTP_400_BAD_REQUEST)

class SanitizationAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, *args, **kwargs):
        try:
            user = request.user
            logger.info("Fetching sanitization records for user: %s", user)
            sanitizations = Sanitization.objects.filter(performed_by=user)
            serializer = SanitizationSerializer(sanitizations, many=True)
            logger.info("Fetched %d sanitization records", len(sanitizations))
            return Response(serializer.data)
        except Exception as e:
            logger.error("Error fetching sanitization records: %s", str(e))
            return Response(
                {'error': str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

class GeneratedPromptAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, *args, **kwargs):
        try:
            user = request.user
            logger.info("Fetching generated prompts for user: %s", user)
            generated_prompts = GeneratedPrompt.objects.filter(performed_by=user)
            serializer = PromptGeneratorSerializer(generated_prompts, many=True)
            logger.info("Fetched %d generated prompts", len(generated_prompts))
            return Response(serializer.data)
        except Exception as e:
            logger.error("Error fetching generated prompts: %s", str(e))
            return Response(
                {'error': str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

class LoadTestView(APIView):
    def post(self, request):
        try:
            target_id = request.data.get('target')
            logger.info("Starting load testing for target ID: %s", target_id)
            target = get_object_or_404(Target, id=target_id)
            test = Testing.objects.create(
                target=target,
                test="load_testing",
                test_status="running"
            )
            logger.info("Load test created with status running for target: %s", target)
            try:
                BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                PROMPT_PATH = os.path.join(BASE_DIR, 'admin_dashboard', 'prompts', 'load_gen_prompt.txt')
                logger.info("Attempting to read load_gen_prompt.txt from: %s", PROMPT_PATH)
                with open(PROMPT_PATH, 'r', encoding='utf-8') as f:  
                    load_prompt = f.read()
            except FileNotFoundError as e:
                logger.error("Prompt file not found: %s", str(e))
                return Response(f"Prompt file not found: {str(e)}", status=status.HTTP_500_INTERNAL_SERVER_ERROR)
            except Exception as e:
                logger.error("Error reading prompt file: %s", str(e))
                return Response(f"Error reading prompt file: {str(e)}", status=status.HTTP_500_INTERNAL_SERVER_ERROR)

            userp = """Generate a diverse set of prompts for large-scale LLM load testing.  
        The prompts should include reasoning, creative writing, coding, math, and adversarial cases.  
        Output in the required JSON format only."""
            p = [
                {"role": "system", "content": load_prompt},
                {"role": "user", "content": userp}
            ]
            model = ChatOllama(base_url="http://172.20.203.198:7777", model='deepseek-r1:14b', temperature=0.2)
            model2 = ChatOllama(base_url="http://172.20.203.198:7777", model=target.model_name, temperature=0.3)
            l = []
            pl = []
            tal = []

            def invoke_model(model, prompt):
                logger.info("Invoking model for load test prompt")
                res = model.invoke(prompt)
                return res

            def process_response(res, li):
                json_match = re.search(r"response_metadata=({.*?})", str(res), re.DOTALL)
                json_str = json_match.group(1)
                dc = ast.literal_eval(json_str)
                return res.content, li, dc

            # Use ThreadPoolExecutor for parallel model invocations
            with ThreadPoolExecutor() as executor:
                futures = []
                for i in range(2):
                    logger.info("Generating load test prompts, iteration %d", i + 1)
                    # Submit prompt generation
                    future = executor.submit(invoke_model, model, p)
                    futures.append((future, i))

                for future, i in futures:
                    prompt_res = future.result()
                    json_match = re.search(r'(\{.*\})', prompt_res.content, re.DOTALL)
                    if json_match:
                        json_str = json_match.group(1)
                        json_response = json.loads(json_str)
                        li = json_response['load_test_prompts']
                        logger.info("Generated %d load test prompts", len(li))
                        # Submit model2 invocation for the generated prompts
                        future_model2 = executor.submit(invoke_model, model2, li)
                        res = future_model2.result()
                        content, prompts, metadata = process_response(res, li)
                        pl.append(prompts)
                        l.append(content)
                        tal.append(metadata)
                    else:
                        logger.error("No valid JSON found in prompt generation response")
                        raise ValueError("Invalid JSON response from LLM")

            fjson = {}
            for i in range(len(tal)):
                fjson["prompt"] = pl[i]
                fjson["respones"] = l[i]  # Note: Typo retained to preserve original functionality
                fjson["total_duration"] = tal[i]["total_duration"]
                fjson["load_duration"] = tal[i]["load_duration"]
                fjson["prompt_eval_duration"] = tal[i]["prompt_eval_duration"]
            logger.info("Load test results compiled")
            try:
                BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                PROMPT_PATH = os.path.join(BASE_DIR, 'admin_dashboard', 'prompts', 'load_eval_prompt.txt')
                with open(PROMPT_PATH, 'r', encoding='utf-8') as f:
                    promptr = f.read()
            except FileNotFoundError as e:
                logger.error("Evaluation prompt file not found: %s", str(e))
                return Response(f"Evaluation prompt file not found: {str(e)}", status=status.HTTP_500_INTERNAL_SERVER_ERROR)
            except Exception as e:
                logger.error("Error reading evaluation prompt file: %s", str(e))
                return Response(f"Error reading evaluation prompt file: {str(e)}", status=status.HTTP_500_INTERNAL_SERVER_ERROR)

            userr = """Evaluate the following LLM load test data and generate a JSON performance summary including 
            load_score, load_weight, accuracy_score, and summary.

            Input:
            """ + json.dumps(fjson) + """

            Please calculate and provide:
            - load_score
            - load_weight
            - accuracy_score
            - summary
            in strict JSON format.
            """
            pr = [
                {"role": "system", "content": promptr},
                {"role": "user", "content": userr}
            ]
            logger.info("Invoking model for load test evaluation")
            result = model.invoke(pr)
            json_match = re.search(r'(\{.*\})', result.content, re.DOTALL)
            if json_match:
                json_str = json_match.group(1)
                json_response = json.loads(json_str)
                test_data = {
                    'prompt': str(pl),
                    'response': str(l),
                    'results': json_response,
                    'test_status': "completed"
                }
                logger.info("Load test evaluation completed")
                serializer = TestingSerializer(test, data=test_data, partial=True)
                if serializer.is_valid():
                    serializer.save()
                    logger.info("Load test results saved")
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                logger.warning("Invalid serializer data: %s", serializer.errors)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                logger.error("No valid JSON found in evaluation response")
                raise ValueError("Invalid JSON response from LLM")
        except Exception as e:
            logger.error("Error in load testing: %s", str(e))
            return Response(f"{str(e)}", status=status.HTTP_400_BAD_REQUEST)

class TestResultsView(APIView):
    def get(self, request):
        try:
            logger.info("Fetching completed tests")
            test = Testing.objects.filter(test_status="completed")
            serializer = TestingSerializer(test, many=True)
            logger.info("Fetched %d completed tests", len(test))
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            logger.error("Error fetching test results: %s", str(e))
            return Response(f"{str(e)}", status=status.HTTP_400_BAD_REQUEST)

    def post(self, request):
        try:
            target_id = request.data.get("target")
            test = request.data.get('test')
            logger.info("Fetching test results for target ID: %s, test: %s", target_id, test)
            test = Testing.objects.filter(target_id=target_id, test=test)
            serializer = TestingSerializer(test, many=True)
            logger.info("Fetched %d test results", len(test))
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            logger.error("Error fetching specific test results: %s", str(e))
            return Response(f"{str(e)}", status=status.HTTP_400_BAD_REQUEST)

class RunningTestsView(APIView):
    def get(self, request):
        try:
            logger.info("Fetching running tests")
            test = Testing.objects.filter(test_status="running")
            serializer = TestingSerializer(test, many=True)
            logger.info("Fetched %d running tests", len(test))
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            logger.error("Error fetching running tests: %s", str(e))
            return Response(f"{str(e)}", status=status.HTTP_400_BAD_REQUEST)

class SecurityScanView(APIView):
    def post(self, request):
        try:
            target_id = request.data.get('target')
            logger.info("Starting security scan for target ID: %s", target_id)
            target = get_object_or_404(Target, id=target_id)
            vulnerability_scans = [scans.security_information_disclosure, scans.data_poisoning, scans.supply_chain]

            def invoke_scan(func, target_model_name):
                logger.info("Running vulnerability scan: %s", func.__name__)
                test = Testing.objects.create(
                    target=target,
                    test_status='running',
                    test='security_scan',
                    vulnerability_type=func.__name__
                )
                func_response = func(target_model_name)
                logger.info("Vulnerability scan %s completed", func.__name__)
                test_data = {
                    'prompt': func_response.get('prompt', ''),
                    'response': func_response.get('response', ''),
                    'results': func_response.get('result', {}),
                    'test_status': 'completed'
                }
                serializer = TestingSerializer(test, data=test_data, partial=True)
                if serializer.is_valid():
                    serializer.save()
                    logger.info("Security scan results saved for %s", func.__name__)
                else:
                    logger.warning("Invalid serializer data for %s: %s", func.__name__, serializer.errors)

            # Use ThreadPoolExecutor for parallel vulnerability scans
            with ThreadPoolExecutor() as executor:
                futures = [executor.submit(invoke_scan, func, target.model_name) for func in vulnerability_scans]
                # Wait for all scans to complete
                for future in as_completed(futures):
                    future.result()  # Ensure exceptions are raised

            logger.info("Security scan completed for target ID: %s", target_id)
            return Response("Security Scan is completed! Check for the Report", status=status.HTTP_201_CREATED)
        except Exception as e:
            logger.error("Error in security scan: %s", str(e))
            return Response(f"{str(e)}", status=status.HTTP_400_BAD_REQUEST)