import asyncio
import uvicorn
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger

from core import config
from core.logger import get_logger

from services.option_service import options_cache
from services.token_service import token_service
from services.upstox_websocket import upstox_streamer
from services.telegram_service import telegram_service
from services.opening_range_service import calculate_opening_range_for_all_subscribed
from services.market_refresh_service import run_market_hard_refresh

from token_tasks.token_monitor import (
    check_upstox_token_validity,
    get_token_monitor_interval_minutes,
)
from token_tasks.telegram_token_bot import telegram_token_bot

from api.home_routes import router as home_router
from api.health_routes import router as health_router
from api.debug_routes import router as debug_router
from api.refresh_routes import router as refresh_router
from api.history_routes import router as history_router
from api.opening_range_routes import router as opening_range_router
from api.ws_docs_routes import router as ws_docs_router

from ws_feed.websocket_routes import router as websocket_router

logger = get_logger(__file__)

DASHBOARD_TEMPLATE_PATH = Path("templates/isolated_ema_dashboard.html")


# ============================================================
# Live EMA Mode Helper
# ============================================================


def get_live_ema_calculation_mode_text() -> str:
    """
    Returns configured live EMA calculation mode.

    LIVE_EMA_CALCULATION_MODE = False
        completed candle close based EMA calculation.

    LIVE_EMA_CALCULATION_MODE = True
        live tick/LTP based EMA calculation.
    """

    return (
        "tick_ltp"
        if bool(getattr(config, "LIVE_EMA_CALCULATION_MODE", False))
        else "candle_close"
    )


def get_live_ema_calculation_mode_description() -> str:
    """
    Returns readable live EMA mode description.
    """

    if bool(getattr(config, "LIVE_EMA_CALCULATION_MODE", False)):
        return "live tick/LTP based EMA calculation"

    return "completed candle close based EMA calculation"


def get_ema_order_side_rule_text() -> str:
    """
    Returns readable EMA Telegram order-side rule.

    Current rule:
        bullish_cross -> same side as isolated instrument
        bearish_cross -> opposite side of isolated instrument
    """

    return (
        "EMA Order Side Rule: bullish_cross uses the same option side as the "
        "isolated instrument; bearish_cross uses the opposite option side of "
        "the isolated instrument."
    )


# ============================================================
# Startup Token Gate
# ============================================================


def validate_startup_token_or_wait() -> dict:
    """
    Validates whether application can start market-dependent flow.

    If token is missing or invalid:
        - app should stay alive
        - Telegram token bot should remain active
        - scheduler/token monitor should continue
        - option loading, historical EMA, and streamer start should be skipped

    Returns:
        {
            "can_start_market_flow": bool,
            "status": "...",
            "message": "...",
            "token_available": bool,
            "token_valid": bool
        }
    """

    logger.info("Running startup token gate validation...")

    token_loaded = token_service.refresh_tokens()
    current_token = token_service.get_access_token()
    token_doc = token_service.get_token_document()

    if not token_loaded or not current_token:
        message = (
            "No usable Upstox access token found in MongoDB. "
            "Market flow is paused. Please use Telegram /save-token or "
            "/save_token command to save a valid token."
        )

        logger.warning(message)

        telegram_service.send_token_refresh_message(
            success=False,
            error=message,
        )

        telegram_service.send_startup_message(
            status="waiting for token",
            details=(
                f"{message}\n\n"
                "App is running in degraded mode.\n"
                "Telegram token bot and token monitor are active.\n"
                "After a valid token is saved, automatic market hard refresh "
                "will start from token bot.\n\n"
                f"Live EMA Calculation Mode: {get_live_ema_calculation_mode_text()}\n"
                f"Live EMA Mode Description: {get_live_ema_calculation_mode_description()}\n"
                f"{get_ema_order_side_rule_text()}"
            ),
        )

        return {
            "can_start_market_flow": False,
            "status": "waiting_for_token",
            "message": message,
            "token_available": False,
            "token_valid": False,
            "token_updated_at": token_doc.get("updated_at") if token_doc else None,
        }

    logger.info(
        "Startup token document exists. Validating token with Upstox profile API..."
    )

    validation_result = check_upstox_token_validity(
        send_success_message=False,
    )

    token_valid = bool(validation_result.get("valid"))

    if not token_valid:
        message = (
            "Upstox access token is present but validation failed. "
            "Market flow is paused. Please use Telegram /save-token or "
            "/save_token command to save a fresh valid token."
        )

        logger.warning(
            f"{message} validation_status={validation_result.get('status')}, "
            f"error={validation_result.get('error')}"
        )

        telegram_service.send_startup_message(
            status="waiting for valid token",
            details=(
                f"{message}\n\n"
                f"Validation Status: {validation_result.get('status')}\n"
                f"Validation Error: {validation_result.get('error')}\n\n"
                "App is running in degraded mode.\n"
                "Telegram token bot and token monitor are active.\n"
                "After a valid token is saved, automatic market hard refresh "
                "will start from token bot.\n\n"
                f"Live EMA Calculation Mode: {get_live_ema_calculation_mode_text()}\n"
                f"Live EMA Mode Description: {get_live_ema_calculation_mode_description()}\n"
                f"{get_ema_order_side_rule_text()}"
            ),
        )

        return {
            "can_start_market_flow": False,
            "status": "waiting_for_valid_token",
            "message": message,
            "token_available": True,
            "token_valid": False,
            "token_updated_at": token_doc.get("updated_at") if token_doc else None,
            "validation_result": validation_result,
        }

    logger.info("Startup token validation successful.")

    telegram_service.send_token_refresh_message(
        success=True,
        updated_at=token_doc.get("updated_at") if token_doc else "N/A",
    )

    return {
        "can_start_market_flow": True,
        "status": "token_valid",
        "message": "Token exists and validation succeeded.",
        "token_available": True,
        "token_valid": True,
        "token_updated_at": token_doc.get("updated_at") if token_doc else None,
        "validation_result": validation_result,
    }


# ============================================================
# Startup Market Flow
# ============================================================


def run_initial_startup() -> dict:
    """
    Initial synchronous load when application starts.

    New behavior:
    - If token is missing or invalid, do not run market flow.
    - Keep app alive in waiting/degraded mode.
    - Telegram token bot and token monitor will allow recovery.
    - After user saves valid token, market_refresh_service will run hard refresh.

    If token is valid:
    - Refresh token cache
    - Fetch option contracts
    - Fetch historical EMA
    - Initialize live EMA
    - Do not start streamer here. Lifespan starts it after this returns success.
    """

    logger.info("Initializing application startup sequence...")

    telegram_service.send_startup_message(
        status="started",
        details=(
            "Initial startup sequence started. "
            "Checking token validity before starting market flow.\n\n"
            f"Live EMA Calculation Mode: {get_live_ema_calculation_mode_text()}\n"
            f"Live EMA Mode Description: {get_live_ema_calculation_mode_description()}\n"
            f"{get_ema_order_side_rule_text()}"
        ),
    )

    try:
        token_gate = validate_startup_token_or_wait()

        if not token_gate.get("can_start_market_flow"):
            logger.warning(
                f"Startup market flow paused. "
                f"status={token_gate.get('status')}, "
                f"message={token_gate.get('message')}"
            )

            return {
                "status": token_gate.get("status"),
                "market_flow_started": False,
                "streamer_should_start": False,
                "message": token_gate.get("message"),
                "token_gate": token_gate,
            }

        logger.info("Token gate passed. Running startup market hard refresh...")

        refresh_result = run_market_hard_refresh(
            source="startup",
            restart_streamer=False,
            send_telegram_messages=True,
        )

        subscribed_keys = options_cache.get("subscribed_keys", [])

        market_flow_started = (
            refresh_result.get("status") in ["success", "partial_success"]
            and len(subscribed_keys) > 0
        )

        websocket_mode = (
            "EMA WebSocket events will include Opening Range levels when available."
            if getattr(config, "EMA_CROSS_INCLUDE_OPENING_RANGE_LEVELS", True)
            else "EMA WebSocket events will be sent without Opening Range level enrichment."
        )

        isolated_flow = (
            "Enabled. After Opening Range levels are ready, the system monitors "
            "eligible R2/R3/S2/S3 touches and isolates one instrument for EMA Telegram alerts."
            if getattr(config, "OPENING_RANGE_ISOLATED_INSTRUMENT_ENABLED", True)
            else "Disabled."
        )

        startup_details = (
            f"Startup Refresh Status: {refresh_result.get('status')}\n"
            f"Message: {refresh_result.get('message')}\n"
            f"Nearest Expiry: {options_cache.get('nearest_expiry')}\n"
            f"Total Contracts: {options_cache.get('total_contracts')}\n"
            f"Subscribed Instruments: {len(subscribed_keys)}\n"
            f"Historical EMA Status: {refresh_result.get('historical_ema_status')}\n"
            f"Live EMA Initialized: {refresh_result.get('live_ema_initialized')}\n"
            f"EMA Result File: {refresh_result.get('ema_results_file_path')}\n"
            f"Live EMA Calculation Mode: {get_live_ema_calculation_mode_text()}\n"
            f"Live EMA Mode Description: {get_live_ema_calculation_mode_description()}\n"
            f"EMA WebSocket Mode: {websocket_mode}\n"
            f"Opening Range Isolated Instrument Flow: {isolated_flow}\n"
            f"EMA Telegram Alert Scope: isolated instrument only\n"
            f"{get_ema_order_side_rule_text()}\n"
            f"Isolated EMA Dashboard: /isolated-dashboard"
        )

        if market_flow_started:
            telegram_service.send_startup_message(
                status="completed successfully",
                details=startup_details,
            )
        else:
            telegram_service.send_startup_message(
                status="completed with warnings",
                details=startup_details,
            )

        return {
            "status": refresh_result.get("status"),
            "market_flow_started": market_flow_started,
            "streamer_should_start": market_flow_started,
            "message": refresh_result.get("message"),
            "refresh_result": refresh_result,
        }

    except Exception as ex:
        logger.error(f"Initial startup sequence failed: {type(ex).__name__}: {ex}")

        telegram_service.send_exception_message(
            title="Initial Startup Failed",
            exception=ex,
            context="run_initial_startup",
        )

        raise


# ============================================================
# Daily Opening Range Flow
# ============================================================


def run_daily_opening_range_fetch():
    """
    Scheduled opening range workflow.

    If token/instruments are not ready, this job safely skips.
    """

    logger.info("================ DAILY OPENING RANGE FETCH STARTED ================")

    subscribed_keys = options_cache.get("subscribed_keys", [])

    if not subscribed_keys:
        warning_message = (
            "Opening range fetch skipped. No subscribed instruments found. "
            "This usually means token is missing/invalid or market refresh has not completed."
        )

        logger.warning(warning_message)

        telegram_service.send_message(
            title="Opening Range Fetch Skipped",
            message=warning_message,
            level="WARNING",
        )

        logger.info(
            "================ DAILY OPENING RANGE FETCH COMPLETED ================"
        )

        return None

    telegram_service.send_message(
        title="Daily Opening Range Fetch Started",
        message=(
            "Opening range fetch started.\n\n"
            "Actions:\n"
            "1. Read subscribed instruments\n"
            "2. Fetch today's intraday candles\n"
            "3. Select opening range candles from market open\n"
            "4. Calculate open, high, low, close, average\n"
            "5. Calculate R1/S1, R2/S2, R3/S3 and thresholds\n"
            "6. Backfill scan for R2/R3/S2/S3 touches before fetch time\n"
            "7. Isolate one instrument if eligible touch exists\n"
            "8. Save opening range results locally\n"
            "9. Update in-memory opening range cache for EMA WebSocket enrichment\n\n"
            "Isolation Rule:\n"
            "- Use Opening Range average +/- configured window\n"
            "- Clamp inside configured strike range\n"
            "- R3/S3 priority before R2/S2\n"
            "- If multiple qualify, choose nearest strike to average\n"
            "- EMA Telegram alerts only for isolated instrument\n"
            "- bullish_cross uses same side as isolated instrument\n"
            "- bearish_cross uses opposite side of isolated instrument\n\n"
            f"Live EMA Calculation Mode: {get_live_ema_calculation_mode_text()}\n"
            f"Live EMA Mode Description: {get_live_ema_calculation_mode_description()}\n"
            f"{get_ema_order_side_rule_text()}"
        ),
        level="REFRESH",
    )

    try:
        opening_range_summary = calculate_opening_range_for_all_subscribed(
            candle_count=getattr(config, "OPENING_RANGE_CANDLE_COUNT", 1),
            save_data=getattr(config, "OPENING_RANGE_SAVE_FILE", True),
            max_workers=getattr(config, "OPENING_RANGE_MAX_WORKERS", 5),
        )

        isolated_state = opening_range_summary.get("isolated_instrument") or {}
        isolated_selected = bool(isolated_state.get("selected"))

        logger.info(
            f"Daily opening range fetch completed. "
            f"status={opening_range_summary.get('status')}, "
            f"total_instruments={opening_range_summary.get('total_instruments')}, "
            f"success={opening_range_summary.get('success_count')}, "
            f"empty={opening_range_summary.get('empty_count')}, "
            f"insufficient_data={opening_range_summary.get('insufficient_data_count')}, "
            f"failed={opening_range_summary.get('failed_count')}, "
            f"backfill_touch_events={opening_range_summary.get('backfill_touch_events_count', 0)}, "
            f"latest_main_index_ltp={opening_range_summary.get('latest_main_index_ltp')}, "
            f"isolated_selected={isolated_selected}, "
            f"isolated_instrument_key={isolated_state.get('instrument_key')}, "
            f"isolated_level={isolated_state.get('selected_level')}, "
            f"live_ema_calculation_mode={get_live_ema_calculation_mode_text()}, "
            f"ema_order_side_rule=dynamic_isolated_instrument_side, "
            f"output_file={opening_range_summary.get('output_file_path', 'not_saved')}"
        )

        telegram_service.send_message(
            title="Daily Opening Range Fetch Completed",
            message=(
                f"Status: {opening_range_summary.get('status')}\n"
                f"Date: {opening_range_summary.get('date')}\n"
                f"Source: {opening_range_summary.get('source')}\n"
                f"Interval: {opening_range_summary.get('interval')}\n"
                f"Intraday Unit: {opening_range_summary.get('unit')}\n"
                f"Intraday Interval: {opening_range_summary.get('intraday_interval')}\n"
                f"Opening Range Candles: {opening_range_summary.get('opening_range_candle_count')}\n"
                f"Market Open Time: {opening_range_summary.get('market_open_time')}\n"
                f"Opening Range End Time: {opening_range_summary.get('opening_range_end_time')}\n"
                f"Scheduled Fetch Time: {opening_range_summary.get('scheduled_fetch_time')}\n"
                f"Total Instruments: {opening_range_summary.get('total_instruments')}\n"
                f"Success: {opening_range_summary.get('success_count')}\n"
                f"Empty: {opening_range_summary.get('empty_count')}\n"
                f"Insufficient Data: {opening_range_summary.get('insufficient_data_count')}\n"
                f"Failed: {opening_range_summary.get('failed_count')}\n"
                f"Backfill Touch Events: {opening_range_summary.get('backfill_touch_events_count', 0)}\n"
                f"Latest NIFTY LTP: {opening_range_summary.get('latest_main_index_ltp')}\n"
                f"Isolated Instrument Selected: {isolated_selected}\n"
                f"Isolated Instrument Key: {isolated_state.get('instrument_key') if isolated_selected else 'not_selected'}\n"
                f"Isolated Level: {isolated_state.get('selected_level') if isolated_selected else 'not_available'}\n"
                f"Isolated EMA Alerts Count: {opening_range_summary.get('isolated_ema_alerts_count', 0)}\n"
                f"Live EMA Calculation Mode: {get_live_ema_calculation_mode_text()}\n"
                f"Live EMA Mode Description: {get_live_ema_calculation_mode_description()}\n"
                f"{get_ema_order_side_rule_text()}\n"
                f"Output File: {opening_range_summary.get('output_file_path', 'not_saved')}"
            ),
            level="REFRESH",
        )

        return opening_range_summary

    except Exception as ex:
        logger.error(f"Daily opening range fetch failed: {type(ex).__name__}: {ex}")

        telegram_service.send_exception_message(
            title="Daily Opening Range Fetch Failed",
            exception=ex,
            context="run_daily_opening_range_fetch",
        )

        return None

    finally:
        logger.info(
            "================ DAILY OPENING RANGE FETCH COMPLETED ================"
        )


# ============================================================
# Daily Market Hard Refresh Flow
# ============================================================


def run_daily_market_hard_refresh():
    """
    Daily hard refresh workflow.

    This now uses shared market_refresh_service so the same logic is used by:
    - daily scheduler
    - Telegram post-token-save recovery
    - any future internal refresh caller
    """

    logger.info("================ DAILY MARKET HARD REFRESH STARTED ================")

    try:
        result = run_market_hard_refresh(
            source="daily_scheduler_09_00",
            restart_streamer=True,
            send_telegram_messages=True,
        )

        logger.info(
            f"Daily market hard refresh completed through shared service. "
            f"status={result.get('status')}, "
            f"message={result.get('message')}, "
            f"subscribed_instruments={result.get('subscribed_instruments')}, "
            f"nearest_expiry={result.get('nearest_expiry')}, "
            f"historical_ema_status={result.get('historical_ema_status')}, "
            f"live_ema_initialized={result.get('live_ema_initialized')}"
        )

        return result

    except Exception as ex:
        logger.error(f"Daily market hard refresh failed: {type(ex).__name__}: {ex}")

        telegram_service.send_exception_message(
            title="Daily Market Hard Refresh Failed",
            exception=ex,
            context="run_daily_market_hard_refresh",
        )

        telegram_service.send_daily_refresh_message(
            success=False,
            error=f"{type(ex).__name__}: {ex}",
        )

        return None

    finally:
        logger.info(
            "================ DAILY MARKET HARD REFRESH COMPLETED ================"
        )


# ============================================================
# Scheduler
# ============================================================


def start_scheduler() -> BackgroundScheduler:
    """
    Configures and starts background cron/interval tasks.
    """

    scheduler = BackgroundScheduler()

    scheduler.add_job(
        func=token_service.refresh_tokens,
        trigger="interval",
        minutes=config.REFRESH_INTERVAL_MINUTES,
        id="token_refresh_job",
        replace_existing=True,
    )

    scheduler.add_job(
        func=check_upstox_token_validity,
        trigger="interval",
        minutes=get_token_monitor_interval_minutes(),
        id="upstox_token_validity_check_job",
        replace_existing=True,
    )

    scheduler.add_job(
        func=run_daily_market_hard_refresh,
        trigger=CronTrigger(
            day_of_week="mon-fri",
            hour=9,
            minute=0,
            timezone=getattr(config, "MARKET_TIMEZONE", "Asia/Kolkata"),
        ),
        id="daily_market_hard_refresh_job",
        replace_existing=True,
    )

    scheduler.add_job(
        func=run_daily_opening_range_fetch,
        trigger=CronTrigger(
            day_of_week="mon-fri",
            hour=getattr(config, "OPENING_RANGE_FETCH_HOUR", 9),
            minute=getattr(config, "OPENING_RANGE_FETCH_MINUTE", 18),
            timezone=getattr(config, "MARKET_TIMEZONE", "Asia/Kolkata"),
        ),
        id="daily_opening_range_fetch_job",
        replace_existing=True,
    )

    scheduler.start()

    scheduler_message = (
        f"Scheduler active.\n\n"
        f"Token refresh interval: every {config.REFRESH_INTERVAL_MINUTES} minutes\n"
        f"Upstox token validity check: every "
        f"{get_token_monitor_interval_minutes()} minutes\n"
        f"Telegram token commands enabled: "
        f"{getattr(config, 'TELEGRAM_TOKEN_BOT_ENABLED', True)}\n"
        f"Daily hard refresh: Mon-Fri at 09:00 AM "
        f"{getattr(config, 'MARKET_TIMEZONE', 'Asia/Kolkata')}\n"
        f"Opening range fetch: Mon-Fri at "
        f"{getattr(config, 'OPENING_RANGE_FETCH_HOUR', 9):02d}:"
        f"{getattr(config, 'OPENING_RANGE_FETCH_MINUTE', 18):02d} "
        f"{getattr(config, 'MARKET_TIMEZONE', 'Asia/Kolkata')}\n"
        f"EMA WebSocket OR enrichment: "
        f"{getattr(config, 'EMA_CROSS_INCLUDE_OPENING_RANGE_LEVELS', True)}\n"
        f"Opening Range isolated instrument flow: "
        f"{getattr(config, 'OPENING_RANGE_ISOLATED_INSTRUMENT_ENABLED', True)}\n"
        f"Isolated EMA Telegram alerts: "
        f"{getattr(config, 'EMA_ISOLATED_INSTRUMENT_TELEGRAM_ENABLED', True)}\n"
        f"Live EMA Calculation Mode: {get_live_ema_calculation_mode_text()}\n"
        f"Live EMA Mode Description: {get_live_ema_calculation_mode_description()}\n"
        f"{get_ema_order_side_rule_text()}\n"
        f"Isolated EMA Dashboard: /isolated-dashboard"
    )

    logger.info(
        f"Scheduler active: Token refresh every {config.REFRESH_INTERVAL_MINUTES} mins | "
        f"Upstox token validity check every {get_token_monitor_interval_minutes()} mins | "
        f"Telegram token commands="
        f"{getattr(config, 'TELEGRAM_TOKEN_BOT_ENABLED', True)} | "
        f"Daily market hard refresh scheduled for Mon-Fri at 09:00 AM "
        f"{getattr(config, 'MARKET_TIMEZONE', 'Asia/Kolkata')} | "
        f"Opening range fetch scheduled for Mon-Fri at "
        f"{getattr(config, 'OPENING_RANGE_FETCH_HOUR', 9):02d}:"
        f"{getattr(config, 'OPENING_RANGE_FETCH_MINUTE', 18):02d} "
        f"{getattr(config, 'MARKET_TIMEZONE', 'Asia/Kolkata')} | "
        f"EMA WebSocket OR enrichment="
        f"{getattr(config, 'EMA_CROSS_INCLUDE_OPENING_RANGE_LEVELS', True)} | "
        f"Opening Range isolation="
        f"{getattr(config, 'OPENING_RANGE_ISOLATED_INSTRUMENT_ENABLED', True)} | "
        f"Isolated EMA Telegram="
        f"{getattr(config, 'EMA_ISOLATED_INSTRUMENT_TELEGRAM_ENABLED', True)} | "
        f"Live EMA mode={get_live_ema_calculation_mode_text()} | "
        f"EMA order side rule=dynamic_isolated_instrument_side."
    )

    telegram_service.send_message(
        title="Scheduler Started",
        message=scheduler_message,
        level="INFO",
    )

    return scheduler


# ============================================================
# Route Logging
# ============================================================


def log_registered_routes(fastapi_app: FastAPI):
    """
    Logs all registered HTTP and WebSocket routes in the application.
    """

    logger.info("=== Registered Application Routes ===")

    for route in fastapi_app.routes:
        path = getattr(route, "path", None)

        if not path:
            continue

        methods = getattr(route, "methods", None)

        if methods:
            methods_text = ",".join(sorted(methods))
            logger.info(f"  HTTP {methods_text} -> {path}")
        else:
            logger.info(f"  WS -> {path}")

    logger.info("=====================================")


# ============================================================
# FastAPI Lifespan
# ============================================================


@asynccontextmanager
async def app_lifespan(app: FastAPI):
    """
    Handles async lifecycle startup/shutdown events for FastAPI.

    New behavior:
    - Scheduler starts even when token is missing.
    - Telegram token bot starts even when token is missing.
    - Upstox streamer starts only when startup market flow completed.
    - upstox_streamer.loop is assigned even in waiting mode so token-save
      hard refresh can later schedule streamer restart/start.
    """

    logger.info("Executing lifespan startup sequence...")

    log_registered_routes(app)

    scheduler = None
    streamer_started = False

    try:
        loop = asyncio.get_running_loop()

        # Important:
        # Assign loop early so Telegram token bot background thread can later
        # schedule streamer restart after valid token save.
        upstox_streamer.loop = loop

        scheduler = start_scheduler()

        telegram_token_bot.start()

        startup_result = await loop.run_in_executor(None, run_initial_startup)

        if startup_result.get("streamer_should_start"):
            subscribed_keys = options_cache.get("subscribed_keys", [])

            if subscribed_keys:
                await upstox_streamer.start()
                streamer_started = True

                telegram_service.send_subscription_message(
                    success=True,
                    subscribed_keys_count=len(subscribed_keys),
                    feed_mode=getattr(config, "WEBSOCKET_FEED_MODE", "full"),
                )

                logger.info(
                    "Application startup completed successfully with market flow active."
                )

            else:
                warning_message = (
                    "Startup refresh completed but subscribed_keys is empty. "
                    "Upstox streamer was not started."
                )

                logger.warning(warning_message)

                telegram_service.send_message(
                    title="Startup Streamer Skipped",
                    message=warning_message,
                    level="WARNING",
                )

        else:
            logger.warning(
                "Application started in waiting/degraded mode. "
                "Market flow and Upstox streamer are paused until a valid token is saved."
            )

            telegram_service.send_message(
                title="Application Waiting For Valid Token",
                message=(
                    "FastAPI application is running, but market flow is paused.\n\n"
                    "Reason:\n"
                    f"{startup_result.get('message')}\n\n"
                    "Active services:\n"
                    "- HTTP APIs\n"
                    "- WebSocket routes\n"
                    "- Scheduler\n"
                    "- Token monitor\n"
                    "- Telegram token bot\n\n"
                    "Next step:\n"
                    "Use Telegram /save-token or /save_token to save a valid Upstox token. "
                    "After token save, automatic market hard refresh will start."
                ),
                level="WARNING",
            )

        yield

    except Exception as ex:
        logger.error(f"Application startup/runtime failure: {type(ex).__name__}: {ex}")

        telegram_service.send_exception_message(
            title="Application Startup Runtime Failure",
            exception=ex,
            context="app_lifespan",
        )

        raise

    finally:
        logger.info("Executing lifespan shutdown sequence...")

        telegram_service.send_shutdown_message(
            details="Application shutdown sequence started."
        )

        try:
            telegram_token_bot.stop()

            if streamer_started or getattr(upstox_streamer, "is_running", False):
                await upstox_streamer.stop()
            else:
                logger.info("Upstox streamer was not running. Stop skipped.")

            if scheduler and scheduler.running:
                logger.info("Shutting down background scheduler...")
                scheduler.shutdown()

            telegram_service.send_shutdown_message(
                details="Application shutdown completed successfully."
            )

        except Exception as ex:
            logger.error(f"Application shutdown error: {type(ex).__name__}: {ex}")

            telegram_service.send_exception_message(
                title="Application Shutdown Error",
                exception=ex,
                context="app_lifespan shutdown",
            )


# ============================================================
# FastAPI App
# ============================================================

app = FastAPI(title="Option Feed Engine", lifespan=app_lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============================================================
# HTML Dashboard Routes
# ============================================================


@app.get("/isolated-dashboard", include_in_schema=False)
async def isolated_dashboard():
    """
    Serves the isolated EMA dashboard HTML page.

    File:
        templates/isolated_ema_dashboard.html
    """

    if not DASHBOARD_TEMPLATE_PATH.exists():
        raise HTTPException(
            status_code=404,
            detail=(
                "Dashboard template not found. Expected file: "
                "templates/isolated_ema_dashboard.html"
            ),
        )

    return FileResponse(
        path=DASHBOARD_TEMPLATE_PATH,
        media_type="text/html",
    )


@app.get("/isolated-ema-dashboard", include_in_schema=False)
async def isolated_ema_dashboard_alias():
    """
    Alias route for isolated EMA dashboard.
    """

    return await isolated_dashboard()


# ============================================================
# Register HTTP and WebSocket Routes
# ============================================================

app.include_router(home_router)
app.include_router(health_router)
app.include_router(debug_router)
app.include_router(refresh_router)
app.include_router(history_router)
app.include_router(opening_range_router)
app.include_router(websocket_router)
app.include_router(ws_docs_router)


# ============================================================
# Local Runner
# ============================================================

if __name__ == "__main__":
    logger.info("Starting FastAPI server with WebSockets on http://0.0.0.0:8000 ...")
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")
