from threading import Lock

from pymongo import MongoClient

from core import config
from core.logger import get_logger

logger = get_logger(__file__)


class TokenService:
    """
    Thread-safe in-memory token service.

    Responsibilities:
    - Reads Upstox access token document from MongoDB.
    - Keeps latest token document in memory.
    - Provides access_token for services like:
        - option_service
        - upstox_websocket
        - history/opening range API calls

    Expected MongoDB document:

        {
            "_id": "upstox_access_token",
            "access_token": "...",
            "created_at": "...",
            "updated_at": "..."
        }

    Important:
    - Only access_token is mandatory for market flow.
    - created_at / updated_at are optional display fields.
    - Validation fields are optional and are managed by token_store/token_monitor.
    """

    def __init__(self):
        self.mongo_uri = getattr(config, "MONGO_URI", None)
        self.mongo_db = getattr(config, "MONGO_DB", None)
        self.collection_name = getattr(config, "TOKENS_COLLECTION", None)

        self.token_doc_id = getattr(
            config,
            "UPSTOX_TOKEN_DOC_ID",
            "upstox_access_token",
        )

        if not self.mongo_uri:
            raise RuntimeError("MONGO_URI / MONGO_URL is not configured.")

        if not self.mongo_db:
            raise RuntimeError("MONGO_DB is not configured.")

        if not self.collection_name:
            raise RuntimeError("TOKENS_COLLECTION is not configured.")

        self._client = MongoClient(self.mongo_uri)
        self._db = self._client[self.mongo_db]
        self._collection = self._db[self.collection_name]

        # Thread-safe in-memory cache.
        self._cache = {}
        self._lock = Lock()

        logger.info(
            f"TokenService initialized. "
            f"mongo_db={self.mongo_db}, "
            f"collection={self.collection_name}, "
            f"token_doc_id={self.token_doc_id}"
        )

    def refresh_tokens(self) -> bool:
        """
        Fetches token document from MongoDB and updates in-memory cache.

        Returns:
            True  -> token document exists and contains non-empty access_token.
            False -> document missing, access_token missing, or MongoDB read failed.
        """

        try:
            logger.info(
                f"Fetching token document from MongoDB. "
                f"token_doc_id={self.token_doc_id}"
            )

            doc = self._collection.find_one(
                {
                    "_id": self.token_doc_id,
                }
            )

            if not doc:
                with self._lock:
                    self._cache = {}

                logger.warning(
                    f"Token document not found in MongoDB. "
                    f"token_doc_id={self.token_doc_id}"
                )

                return False

            access_token = str(doc.get("access_token") or "").strip()

            with self._lock:
                self._cache = doc

            if not access_token:
                logger.warning(
                    f"Token document found, but access_token is missing or empty. "
                    f"token_doc_id={self.token_doc_id}"
                )

                return False

            logger.info(
                f"Token cache refreshed successfully. "
                f"token_doc_id={self.token_doc_id}, "
                f"updated_at={doc.get('updated_at', 'N/A')}"
            )

            return True

        except Exception as ex:
            logger.error(
                f"Error refreshing token document from MongoDB: "
                f"{type(ex).__name__}: {ex}"
            )

            return False

    def get_access_token(self) -> str | None:
        """
        Returns current access token from in-memory cache.

        Returns None if:
        - token cache is empty
        - access_token field is missing
        - access_token is empty string
        """

        with self._lock:
            token = self._cache.get("access_token")

        token_text = str(token or "").strip()

        if not token_text:
            return None

        return token_text

    def get_token_document(self) -> dict:
        """
        Returns full cached token document.

        Raw access_token is included because internal services may need it.
        Do not log or expose this response directly to UI/Telegram.
        """

        with self._lock:
            return self._cache.copy()

    def has_access_token(self) -> bool:
        """
        Returns True if a non-empty access token is currently available in memory.
        """

        return bool(self.get_access_token())

    def clear_cache(self) -> None:
        """
        Clears in-memory token cache.

        Useful when MongoDB document is missing or token needs to be reset.
        """

        with self._lock:
            self._cache = {}

        logger.warning("TokenService in-memory token cache cleared.")

    def get_status(self) -> dict:
        """
        Returns safe token service status without exposing raw access token.
        """

        with self._lock:
            doc = self._cache.copy()

        token = str(doc.get("access_token") or "").strip()

        return {
            "token_doc_id": self.token_doc_id,
            "token_available": bool(token),
            "created_at": doc.get("created_at"),
            "updated_at": doc.get("updated_at"),
            "source": doc.get("source"),
            "last_validation_status": doc.get("last_validation_status"),
            "last_validation_status_text": doc.get("last_validation_status_text"),
            "last_validated_at": doc.get("last_validated_at"),
            "last_validation_error": doc.get("last_validation_error"),
        }


# Singleton instance to be shared across the application.
token_service = TokenService()
