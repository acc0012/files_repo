import asyncio
from datetime import datetime, timezone
from threading import Lock

from core import config
from core.logger import get_logger
from services.option_service import get_options_contracts, options_cache
from services.token_service import token_service
from services.history_service import fetch_historical_candles_for_all_subscribed
from services.telegram_service import telegram_service
from services.upstox_websocket import upstox_streamer

logger = get_logger(__file__)

_market_hard_refresh_lock = Lock()

_last_market_hard_refresh_result = {
    "status": "not_started",
    "source": None,
    "started_at": None,
    "completed_at": None,
    "message": "Market hard refresh has not been triggered yet.",
    "nearest_expiry": None,
    "subscribed_instruments": 0,
    "historical_ema_status": None,
    "live_ema_initialized": None,
    "error": None,
}


# ============================================================
# Basic Helpers
# ============================================================


def _utc_now_iso() -> str:
    """Returns current UTC datetime as ISO string."""

    return datetime.now(timezone.utc).isoformat()


def get_last_market_hard_refresh_result() -> dict:
    """
    Returns latest market hard refresh result.

    This can be used later by routes/debug endpoints if required.
    """

    return dict(_last_market_hard_refresh_result)


def get_live_ema_calculation_mode_text() -> str:
    """
    Returns configured live EMA calculation mode.

    LIVE_EMA_CALCULATION_MODE=False:
        completed candle close based EMA calculation.

    LIVE_EMA_CALCULATION_MODE=True:
        live tick/LTP based EMA calculation.
    """

    return (
        "tick_ltp"
        if bool(getattr(config, "LIVE_EMA_CALCULATION_MODE", False))
        else "candle_close"
    )


def _build_failure_result(
    source: str,
    started_at: str,
    message: str,
    error: str | None = None,
    historical_summary: dict | None = None,
) -> dict:
    """
    Builds a standard failed refresh result.
    """

    completed_at = _utc_now_iso()

    return {
        "status": "failed",
        "source": source,
        "started_at": started_at,
        "completed_at": completed_at,
        "message": message,
        "nearest_expiry": options_cache.get("nearest_expiry"),
        "total_contracts": options_cache.get("total_contracts", 0),
        "subscribed_instruments": len(options_cache.get("subscribed_keys", [])),
        "historical_ema_status": (
            historical_summary.get("status") if historical_summary else None
        ),
        "live_ema_initialized": (
            historical_summary.get("live_ema_initialized")
            if historical_summary
            else None
        ),
        "error": error or message,
    }


def _build_success_result(
    source: str,
    started_at: str,
    message: str,
    historical_summary: dict | None = None,
    streamer_restart_scheduled: bool = False,
    streamer_restart_completed: bool | None = None,
) -> dict:
    """
    Builds a standard successful refresh result.
    """

    completed_at = _utc_now_iso()

    return {
        "status": "success",
        "source": source,
        "started_at": started_at,
        "completed_at": completed_at,
        "message": message,
        "nearest_expiry": options_cache.get("nearest_expiry"),
        "total_contracts": options_cache.get("total_contracts", 0),
        "subscribed_instruments": len(options_cache.get("subscribed_keys", [])),
        "historical_ema_status": (
            historical_summary.get("status") if historical_summary else None
        ),
        "live_ema_initialized": (
            historical_summary.get("live_ema_initialized")
            if historical_summary
            else None
        ),
        "ema_results_file_path": (
            historical_summary.get("ema_results_file_path", "not_saved")
            if historical_summary
            else "not_available"
        ),
        "streamer_restart_scheduled": streamer_restart_scheduled,
        "streamer_restart_completed": streamer_restart_completed,
        "feed_mode": getattr(config, "WEBSOCKET_FEED_MODE", "full"),
        "live_ema_calculation_mode": get_live_ema_calculation_mode_text(),
        "error": None,
    }


def _store_last_result(result: dict) -> dict:
    """
    Stores and returns latest market hard refresh result.
    """

    global _last_market_hard_refresh_result

    _last_market_hard_refresh_result = dict(result)

    return result


# ============================================================
# Streamer Restart Helper
# ============================================================


def _restart_or_start_streamer_from_sync_context(
    source: str,
    subscribed_keys_count: int,
) -> tuple[bool, bool | None, str | None]:
    """
    Starts/restarts Upstox streamer from a synchronous context.

    This function is designed for use from:
    - Telegram token bot background thread
    - APScheduler background thread
    - normal synchronous service calls

    Returns:
        (
            restart_scheduled,
            restart_completed,
            error_message
        )

    Notes:
    - If FastAPI event loop is running, restart is scheduled safely using
      asyncio.run_coroutine_threadsafe().
    - If no event loop exists, streamer cannot be started from this thread.
      In that case, refresh still succeeds up to token/options/EMA, but streamer
      start/restart is skipped.
    """

    loop = getattr(upstox_streamer, "loop", None)

    if loop and loop.is_running():
        try:
            logger.info(
                f"Scheduling Upstox streamer restart. "
                f"source={source}, subscribed_keys_count={subscribed_keys_count}"
            )

            future = asyncio.run_coroutine_threadsafe(
                upstox_streamer.restart(),
                loop,
            )

            def restart_done_callback(done_future):
                try:
                    done_future.result()

                    logger.info(
                        f"Upstox streamer restart completed after market hard refresh. "
                        f"source={source}"
                    )

                    telegram_service.send_subscription_message(
                        success=True,
                        subscribed_keys_count=len(
                            options_cache.get("subscribed_keys", [])
                        ),
                        feed_mode=getattr(config, "WEBSOCKET_FEED_MODE", "full"),
                    )

                    telegram_service.send_message(
                        title="Streamer Restart Completed",
                        message=(
                            "Upstox streamer restarted successfully after "
                            "market hard refresh.\n\n"
                            f"Source: {source}\n"
                            f"Subscribed Instruments: "
                            f"{len(options_cache.get('subscribed_keys', []))}\n"
                            f"Feed Mode: {getattr(config, 'WEBSOCKET_FEED_MODE', 'full')}\n"
                            f"Live EMA Calculation Mode: "
                            f"{get_live_ema_calculation_mode_text()}"
                        ),
                        level="SUBSCRIPTION",
                    )

                except Exception as ex:
                    error_message = f"{type(ex).__name__}: {ex}"

                    logger.error(
                        f"Upstox streamer restart failed after market hard refresh. "
                        f"source={source}, error={error_message}"
                    )

                    telegram_service.send_exception_message(
                        title="Streamer Restart Failed After Market Refresh",
                        exception=ex,
                        context=(
                            "market_refresh_service."
                            "_restart_or_start_streamer_from_sync_context"
                        ),
                    )

            future.add_done_callback(restart_done_callback)

            return True, None, None

        except Exception as ex:
            error_message = f"{type(ex).__name__}: {ex}"

            logger.error(
                f"Failed scheduling Upstox streamer restart. "
                f"source={source}, error={error_message}"
            )

            return False, False, error_message

    warning_message = (
        "Upstox streamer event loop is not available or not running. "
        "Token, instruments, historical EMA, and live EMA state were refreshed, "
        "but streamer restart was skipped. The streamer will start only when "
        "FastAPI event loop is available."
    )

    logger.warning(
        f"{warning_message} source={source}, "
        f"subscribed_keys_count={subscribed_keys_count}"
    )

    telegram_service.send_message(
        title="Streamer Restart Skipped",
        message=(
            f"{warning_message}\n\n"
            f"Source: {source}\n"
            f"Subscribed Instruments: {subscribed_keys_count}"
        ),
        level="WARNING",
    )

    return False, False, warning_message


# ============================================================
# Main Shared Market Hard Refresh
# ============================================================


def run_market_hard_refresh(
    source: str = "shared_service",
    restart_streamer: bool = True,
    send_telegram_messages: bool = True,
) -> dict:
    """
    Shared synchronous market hard refresh workflow.

    This is the common refresh flow used after a valid token is saved.

    Steps:
        1. Refresh token document from MongoDB into token_service memory cache.
        2. Validate that access_token exists in memory.
        3. Fetch latest option contracts.
        4. Update options_cache and subscribed_keys.
        5. Fetch historical candles for all subscribed instruments.
        6. Calculate historical EMA summary.
        7. Initialize live EMA state from historical summary.
        8. Restart Upstox streamer if FastAPI event loop is available.

    This function intentionally does not import main.py to avoid circular imports.
    """

    source = str(source or "shared_service")
    started_at = _utc_now_iso()
    historical_summary = None

    if not _market_hard_refresh_lock.acquire(blocking=False):
        message = (
            "Market hard refresh is already running. "
            "Duplicate refresh request skipped."
        )

        logger.warning(f"{message} source={source}")

        result = {
            "status": "already_running",
            "source": source,
            "started_at": started_at,
            "completed_at": _utc_now_iso(),
            "message": message,
            "nearest_expiry": options_cache.get("nearest_expiry"),
            "total_contracts": options_cache.get("total_contracts", 0),
            "subscribed_instruments": len(options_cache.get("subscribed_keys", [])),
            "historical_ema_status": None,
            "live_ema_initialized": None,
            "error": None,
        }

        return _store_last_result(result)

    try:
        logger.info(
            "================ SHARED MARKET HARD REFRESH STARTED ================"
        )

        logger.info(
            f"Market hard refresh started. "
            f"source={source}, "
            f"restart_streamer={restart_streamer}, "
            f"live_ema_calculation_mode={get_live_ema_calculation_mode_text()}"
        )

        if send_telegram_messages:
            telegram_service.send_message(
                title="Market Hard Refresh Started",
                message=(
                    "Market hard refresh started.\n\n"
                    f"Source: {source}\n"
                    "Actions:\n"
                    "1. Refresh token from MongoDB\n"
                    "2. Fetch latest option instruments\n"
                    "3. Update subscription cache\n"
                    "4. Fetch historical candles and calculate EMA\n"
                    "5. Initialize live EMA state\n"
                    "6. Restart Upstox streamer if event loop is available\n\n"
                    f"Live EMA Calculation Mode: {get_live_ema_calculation_mode_text()}"
                ),
                level="REFRESH",
            )

        # ====================================================
        # 1. Refresh token from MongoDB into memory
        # ====================================================

        token_loaded = token_service.refresh_tokens()
        current_token = token_service.get_access_token()
        token_doc = token_service.get_token_document()

        if not token_loaded or not current_token:
            error_message = (
                "Market hard refresh stopped because no usable Upstox access token "
                "is available in token_service memory cache."
            )

            logger.error(error_message)

            if send_telegram_messages:
                telegram_service.send_token_refresh_message(
                    success=False,
                    error=error_message,
                )

            return _store_last_result(
                _build_failure_result(
                    source=source,
                    started_at=started_at,
                    message=error_message,
                    error=error_message,
                )
            )

        logger.info("Token refreshed into memory successfully.")

        if send_telegram_messages:
            telegram_service.send_token_refresh_message(
                success=True,
                updated_at=token_doc.get("updated_at") if token_doc else "N/A",
            )

        # ====================================================
        # 2. Fetch latest option contracts and update cache
        # ====================================================

        logger.info("Fetching latest option contracts and rebuilding cache.")

        contracts_result = get_options_contracts(
            save_data=True,
        )

        if not contracts_result:
            error_message = (
                "Market hard refresh failed because option contract fetch returned "
                "no result."
            )

            logger.error(error_message)

            if send_telegram_messages:
                telegram_service.send_instruments_fetched_message(
                    success=False,
                    error=error_message,
                )

            return _store_last_result(
                _build_failure_result(
                    source=source,
                    started_at=started_at,
                    message=error_message,
                    error=error_message,
                )
            )

        subscribed_keys = options_cache.get("subscribed_keys", [])

        if not subscribed_keys:
            error_message = (
                "Market hard refresh failed because no subscribed instrument keys "
                "were found after option contract reload."
            )

            logger.error(error_message)

            if send_telegram_messages:
                telegram_service.send_instruments_fetched_message(
                    success=False,
                    error=error_message,
                )

            return _store_last_result(
                _build_failure_result(
                    source=source,
                    started_at=started_at,
                    message=error_message,
                    error=error_message,
                )
            )

        logger.info(
            f"Option contracts refreshed successfully. "
            f"nearest_expiry={options_cache.get('nearest_expiry')}, "
            f"total_contracts={options_cache.get('total_contracts')}, "
            f"subscribed_keys_count={len(subscribed_keys)}"
        )

        if send_telegram_messages:
            telegram_service.send_instruments_fetched_message(
                success=True,
                nearest_expiry=options_cache.get("nearest_expiry"),
                total_contracts=options_cache.get("total_contracts", 0),
                subscribed_keys_count=len(subscribed_keys),
                strike_from=getattr(config, "STRIKE_FROM", "N/A"),
                strike_to=getattr(config, "STRIKE_TO", "N/A"),
            )

        # ====================================================
        # 3. Fetch historical EMA and initialize live EMA state
        # ====================================================

        logger.info("Fetching historical candles and initializing live EMA state.")

        historical_summary = fetch_historical_candles_for_all_subscribed(
            interval=getattr(config, "HISTORICAL_CANDLE_INTERVAL", "1minute"),
            history_days=getattr(config, "HISTORICAL_CANDLE_DAYS", 10),
            save_data=True,
            max_workers=getattr(config, "HISTORICAL_CANDLE_MAX_WORKERS", 5),
        )

        logger.info(
            f"Historical EMA refresh completed. "
            f"status={historical_summary.get('status')}, "
            f"total_instruments={historical_summary.get('total_instruments')}, "
            f"success={historical_summary.get('success_count')}, "
            f"empty={historical_summary.get('empty_count')}, "
            f"insufficient_data={historical_summary.get('insufficient_data_count')}, "
            f"failed={historical_summary.get('failed_count')}, "
            f"total_candles={historical_summary.get('total_candles')}, "
            f"live_ema_initialized={historical_summary.get('live_ema_initialized')}, "
            f"live_ema_calculation_mode={get_live_ema_calculation_mode_text()}"
        )

        if send_telegram_messages:
            telegram_service.send_message(
                title="Historical EMA Refresh Completed",
                message=(
                    f"Source: {source}\n"
                    f"Status: {historical_summary.get('status')}\n"
                    f"From Date: {historical_summary.get('from_date')}\n"
                    f"To Date: {historical_summary.get('to_date')}\n"
                    f"Interval: {historical_summary.get('interval')}\n"
                    f"Total Instruments: {historical_summary.get('total_instruments')}\n"
                    f"Success: {historical_summary.get('success_count')}\n"
                    f"Empty: {historical_summary.get('empty_count')}\n"
                    f"Insufficient Data: "
                    f"{historical_summary.get('insufficient_data_count')}\n"
                    f"Failed: {historical_summary.get('failed_count')}\n"
                    f"Total Candles: {historical_summary.get('total_candles')}\n"
                    f"EMA Fast Period: {historical_summary.get('ema_fast_period')}\n"
                    f"EMA Slow Period: {historical_summary.get('ema_slow_period')}\n"
                    f"EMA Result File: "
                    f"{historical_summary.get('ema_results_file_path', 'not_saved')}\n"
                    f"Live EMA Initialized: "
                    f"{historical_summary.get('live_ema_initialized')}\n"
                    f"Live EMA Calculation Mode: "
                    f"{get_live_ema_calculation_mode_text()}\n"
                    f"Telegram EMA Alert Scope: isolated instrument only"
                ),
                level="REFRESH",
            )

        # ====================================================
        # 4. Restart Upstox streamer
        # ====================================================

        streamer_restart_scheduled = False
        streamer_restart_completed = None
        streamer_restart_error = None

        if restart_streamer:
            (
                streamer_restart_scheduled,
                streamer_restart_completed,
                streamer_restart_error,
            ) = _restart_or_start_streamer_from_sync_context(
                source=source,
                subscribed_keys_count=len(subscribed_keys),
            )

        if streamer_restart_error:
            result = _build_success_result(
                source=source,
                started_at=started_at,
                message=(
                    "Market hard refresh completed, but streamer restart was "
                    "not completed."
                ),
                historical_summary=historical_summary,
                streamer_restart_scheduled=streamer_restart_scheduled,
                streamer_restart_completed=streamer_restart_completed,
            )

            result["status"] = "partial_success"
            result["error"] = streamer_restart_error

            if send_telegram_messages:
                telegram_service.send_message(
                    title="Market Hard Refresh Partial Success",
                    message=(
                        "Market hard refresh completed, but streamer restart "
                        "had an issue.\n\n"
                        f"Source: {source}\n"
                        f"Error: {streamer_restart_error}\n"
                        f"Subscribed Instruments: {len(subscribed_keys)}\n"
                        f"Nearest Expiry: {options_cache.get('nearest_expiry')}"
                    ),
                    level="WARNING",
                )

            return _store_last_result(result)

        success_result = _build_success_result(
            source=source,
            started_at=started_at,
            message="Market hard refresh completed successfully.",
            historical_summary=historical_summary,
            streamer_restart_scheduled=streamer_restart_scheduled,
            streamer_restart_completed=streamer_restart_completed,
        )

        if send_telegram_messages:
            telegram_service.send_daily_refresh_message(
                success=True,
                subscribed_keys_count=len(subscribed_keys),
                nearest_expiry=options_cache.get("nearest_expiry"),
            )

        logger.info(
            f"Market hard refresh completed successfully. "
            f"source={source}, "
            f"subscribed_instruments={len(subscribed_keys)}, "
            f"nearest_expiry={options_cache.get('nearest_expiry')}, "
            f"streamer_restart_scheduled={streamer_restart_scheduled}"
        )

        return _store_last_result(success_result)

    except Exception as ex:
        error_message = f"{type(ex).__name__}: {ex}"

        logger.error(
            f"Market hard refresh failed. " f"source={source}, error={error_message}"
        )

        if send_telegram_messages:
            telegram_service.send_exception_message(
                title="Market Hard Refresh Failed",
                exception=ex,
                context=f"market_refresh_service.run_market_hard_refresh source={source}",
            )

            telegram_service.send_daily_refresh_message(
                success=False,
                error=error_message,
            )

        return _store_last_result(
            _build_failure_result(
                source=source,
                started_at=started_at,
                message="Market hard refresh failed.",
                error=error_message,
                historical_summary=historical_summary,
            )
        )

    finally:
        _market_hard_refresh_lock.release()

        logger.info(
            "================ SHARED MARKET HARD REFRESH COMPLETED ================"
        )


# ============================================================
# Specific Entrypoint For Telegram Token Save
# ============================================================


def run_market_hard_refresh_after_token_save(
    source: str = "telegram_token_saved",
) -> dict:
    """
    Runs market hard refresh after Telegram bot saves a valid token.

    This is the function called by:

        token_tasks/telegram_token_bot.py

    Behavior:
        - Assumes token was already validated before saving.
        - Refreshes token_service memory cache again for safety.
        - Loads instruments.
        - Initializes historical/live EMA.
        - Restarts streamer if FastAPI event loop is available.
    """

    return run_market_hard_refresh(
        source=source,
        restart_streamer=True,
        send_telegram_messages=True,
    )


# ============================================================
# Optional Entrypoint For Other Internal Calls
# ============================================================


def run_market_hard_refresh_without_streamer_restart(
    source: str = "internal_no_streamer_restart",
) -> dict:
    """
    Runs market hard refresh without restarting streamer.

    This is useful only if another caller wants to refresh token/cache/EMA
    but intentionally skip streamer restart.
    """

    return run_market_hard_refresh(
        source=source,
        restart_streamer=False,
        send_telegram_messages=True,
    )
