import {
  Shield,
  Activity,
  Crown,
  UserPlus,
  UserMinus,
  CheckCircle,
  XCircle
} from 'lucide-react';

function Overview({ stats, activities }) {
  const safeActivities = Array.isArray(activities) ? activities : [];

  return (
    <div className="admin-content">
      <div className="section-header">
        <div>
          <h2>System Overview</h2>
          <p>Monitor administrators and system-wide security operations</p>
        </div>
      </div>

      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-header">
            <span className="stat-title">Total Admins</span>
            <Shield className="stat-icon" />
          </div>
          <div className="stat-content">
            <div className="stat-number">{stats.totalAdmins}</div>
            <p className="stat-description">+12 from last month</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-header">
            <span className="stat-title">Active Admins</span>
            <Activity className="stat-icon" />
          </div>
          <div className="stat-content">
            <div className="stat-number">{stats.activeAdmins}</div>
            <p className="stat-description">
              {stats.totalAdmins > 0
                ? Math.round((stats.activeAdmins / stats.totalAdmins) * 100) + "% active rate"
                : "No data yet"}
            </p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-header">
            <span className="stat-title">Super Admins</span>
            <Crown className="stat-icon" />
          </div>
          <div className="stat-content">
            <div className="stat-number">{stats.superAdmins}</div>
            <p className="stat-description">System administrators</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-header">
            <span className="stat-title">Today's Scans</span>
            <Activity className="stat-icon" />
          </div>
          <div className="stat-content">
            <div className="stat-number">{stats.todayScans}</div>
            <p className="stat-description">
              Total: {stats.totalScans ? stats.totalScans.toLocaleString() : 0}
            </p>
          </div>
        </div>
      </div>

      <div className="activity-card">
        <div className="card-header">
          <h3>Recent System Activity</h3>
          <p>Latest administrative actions and system events</p>
        </div>

        <div className="activity-list">
          {safeActivities.length === 0 ? (
            <p>No recent activity found</p>
          ) : (
            safeActivities.map((act) => (
              <div key={act.id} className={`activity-item activity-${act.action}`}>
                {act.action === "add_user" && <UserPlus className="activity-icon" />}
                {act.action === "delete_user" && <UserMinus className="activity-icon" />}
                {act.action === "activate_user" && <CheckCircle className="activity-icon" />}
                {act.action === "deactivate_user" && <XCircle className="activity-icon" />}
                <div className="activity-content">
                  <p>
                    {act.action.replace(/_/g, " ")}: {act.target_user}
                  </p>
                  <span className="activity-time">
                    {new Date(act.timestamp).toLocaleString()}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

export default Overview;
