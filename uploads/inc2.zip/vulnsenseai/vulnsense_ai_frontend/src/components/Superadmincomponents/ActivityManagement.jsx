import React from 'react'
import {
    Shield,
    Users,
    UserPlus,
    UserMinus,
    Activity,
    LogOut,
    Crown,
    CheckCircle,
    XCircle,
    Trash2,
    Home,
    BarChart3,
    User
  } from 'lucide-react';
  import { toast } from 'sonner';
const ActivityManagement = ({stats,activities}) => {
  return (
    <div className="admin-content">
    <div className="section-header">
      <div>
        <h2>System Activity Monitor</h2>
        <p>Real-time monitoring of system-wide activities and performance</p>
      </div>
    </div>

    <div className="activity-monitor-card">
      <div className="card-header">
        <h3>System Activity Monitor</h3>
        <p>Real-time monitoring of system-wide activities</p>
      </div>
      <div className="monitor-content">
        <div className="monitor-stats">
          <div className="monitor-stat monitor-stat-blue">
            <div className="monitor-number">{stats.todayScans}</div>
            <div className="monitor-label">Scans Today</div>
          </div>
          <div className="monitor-stat monitor-stat-green">
            <div className="monitor-number">{stats.activeAdmins}</div>
            <div className="monitor-label">Active Admins</div>
          </div>
          <div className="monitor-stat monitor-stat-purple">
            <div className="monitor-number">{stats.superAdmins}</div>
            <div className="monitor-label">Super Admins</div>
          </div>
        </div>

        <div className="activity-list">
          {activities.map((act) => (
            <div key={act.id} className={`activity-item`}>
              {act.action === "add_user" && <UserPlus className="activity-icon" />}
              {act.action === "delete_user" && <UserMinus className="activity-danger" />}
              {act.action === "activate_user" && <CheckCircle className="activity-icon" />}
              {act.action === "deactivate_user" && <XCircle className="activity-danger" />}
              <div className="activity-content">
                <p>
                  {act.action.replace("_", " ")}: {act.target_user}
                </p>
                <span className="activity-time">
                  {new Date(act.timestamp).toLocaleString()}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  </div>
  )
}

export default ActivityManagement
