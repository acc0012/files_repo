import { useEffect, useState } from 'react';
import { FileText, Trash2, FileCode, RefreshCw, Search, Download, BarChart3, CheckCircle, AlertTriangle } from 'lucide-react';
import { get, del } from '../auth/api';
import { useLoader } from '../loader/Loadercontext';

export default function AuditSection() {
  const [audits, setAudits] = useState([]);
  const [loading, setLoading] = useState(true);
  const { showLoader, hideLoader } = useLoader()
  const [targets, setTargets] = useState([]);

  useEffect(() => {
    const fetchAudits = async () => {
      showLoader()
      try {
        const data = await get('/api/test/report/');
        setAudits(data);
      } catch (error) {
        console.error('Error fetching audits:', error);
      } finally {
        hideLoader()
        setLoading(false);

      }
    };
    fetchAudits();
  }, []);

  useEffect(() => {
    showLoader()
    const fetchTargets = async () => {
      try {
        const data = await get('/api/models/');
        setTargets(data);
      } catch (error) {
        console.error('Error fetching targets:', error);
      }
      finally {
        hideLoader()
      }
    };
    fetchTargets();
  }, []);

  const fetchTargets = async () => {
    try {
      const data = await get('/api/models/');
      setTargets(data);
    } catch (error) {
      console.error('Error fetching targets:', error);
    }
  };

  const deleteAudit = async (auditId) => {
    try {
      await del(`/auth/audits/${auditId}/`);
      setAudits(audits.filter(a => a.id !== auditId));
    } catch (error) {
      console.error('Error deleting audit:', error);
    }
  };

  if (loading) return <p>Loading audits...</p>;

  return (
    <div className="admin-content">
      <div className="section-header">
        <h2>Security Auditing & Reports</h2>
        <p>AI-generated security analysis and downloadable PDF reports</p>
      </div>
      {/* new components */}
      {/* <div className="audit-list">
        {audits.map(audit => (
          <div key={audit.id} className="audit-card">
            <div className="audit-info">
              <FileText className="icon" />
              <div>
                <h4>{audit.name}</h4>
                <p>Target: {audit.target_name}</p>
                <p>Generated: {new Date(audit.generated_at).toLocaleString()}</p>
              </div>
            </div>
            <div className="audit-actions">
              <button className="btn btn-outline btn-danger btn-sm" onClick={() => deleteAudit(audit.id)}>
                <Trash2 className="btn-icon" /> Delete
              </button>
            </div>
          </div>
        ))}
      </div> */}
      <div className="audit-card">
        <div className="card-header">
          <h3>
            <FileCode className="card-icon" />
            Generate New Audit Report
          </h3>
          <p>Create comprehensive security audit for your targets</p>
        </div>
        <div className="audit-form">
          <div className="form-grid">
            <div className="form-group">
              <label htmlFor="target-select">Select Target</label>
              <select id="target-select" className="form-select">
                <option value="">Choose a target...</option>
                {targets.map((target) => (
                  <option key={target.id} value={target.id}>{target.model_name}</option>
                ))}
              </select>
            </div>
            <div className="form-group">
              <label htmlFor="report-type">Report Type</label>
              <select id="report-type" className="form-select">
                <option value="comprehensive">Fuzz Testing</option>
                <option value="vulnerability">Load Testing</option>
                <option value="compliance">Security Testing</option>
              </select>
            </div>
          </div>
          <button className="btn btn-purple">
            <RefreshCw className="btn-icon" />
            Generate Audit Report
          </button>
        </div>
      </div>
      <div className="reports-card">
        <div className="card-header">
          <h3>Generated Reports</h3>
          <p>Your security audit reports and analysis</p>
        </div>
        <div className="reports-list">
          {/* {auditReports.map((report) => {
            const target = targets.find(t => t.id === report.targetId);
            return (
              <div key={report.id} className="report-item">
                <div className="report-info">
                  <div className="report-icon">
                    <FileCode className="icon" />
                  </div>
                  <div className="report-details">
                    <p>Security Audit - {target?.name}</p>
                    <span>
                      Generated {new Date(report.generatedAt).toLocaleDateString()} • 
                      {report.vulnerabilities} vulnerabilities • 
                      Risk Score: {report.riskScore}/10
                    </span>
                    <div className="report-badges">
                      <span className="badge badge-purple">{report.recommendations} Recommendations</span>
                      {report.riskScore >= 7 && <span className="badge badge-danger">High Risk</span>}
                      {report.riskScore >= 4 && report.riskScore < 7 && <span className="badge badge-warning">Medium Risk</span>}
                      {report.riskScore < 4 && <span className="badge badge-success">Low Risk</span>}
                    </div>
                  </div>
                </div>
                <div className="report-actions">
                  <span className={`badge ${report.status === 'completed' ? 'badge-success' : 'badge-primary'}`}>
                    {report.status === 'completed' ? 'Ready' : 'Generating'}
                  </span>
                  {report.status === 'completed' && (
                    <>
                      <button className="btn btn-outline btn-sm">
                        <Search className="btn-icon" />
                        View
                      </button>
                      <button className="btn btn-outline btn-sm">
                        <Download className="btn-icon" />
                        Download PDF
                      </button>
                    </>
                  )}
                </div>
              </div>
            );
          })} */}
        </div>
      </div>
      <div className="analytics-grid">
        <div className="analytics-card">
          <div className="card-header">
            <h3>
              <AlertTriangle className="card-icon" />
              Vulnerability Trends
            </h3>
          </div>
          <div className="analytics-content">
            <div className="trend-item">
              <span>Critical</span>
              <span className="trend-count trend-critical">2</span>
            </div>
            <div className="trend-item">
              <span>High</span>
              <span className="trend-count trend-high">5</span>
            </div>
            <div className="trend-item">
              <span>Medium</span>
              <span className="trend-count trend-medium">12</span>
            </div>
            <div className="trend-item">
              <span>Low</span>
              <span className="trend-count trend-low">8</span>
            </div>
          </div>
        </div>
        <div className="analytics-card">
          <div className="card-header">
            <h3>
              <BarChart3 className="card-icon" />
              Risk Scores
            </h3>
          </div>
          <div className="analytics-center">
            <div className="metric-large">7.2</div>
            <p>Average Risk Score</p>
            <span>Across all targets</span>
          </div>
        </div>
        <div className="analytics-card">
          <div className="card-header">
            <h3>
              <CheckCircle className="card-icon" />
              Remediation
            </h3>
          </div>
          <div className="analytics-center">
            <div className="metric-large">73%</div>
            <p>Auto-Resolved</p>
            <span>Issues fixed by AI</span>
          </div>
        </div>
      </div>
    </div>
  );
}
