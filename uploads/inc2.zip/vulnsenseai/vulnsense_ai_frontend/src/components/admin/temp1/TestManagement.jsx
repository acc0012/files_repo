import { useEffect, useState } from 'react';
import { Play, StopCircle, Trash2, Zap, Activity } from 'lucide-react';
import { get, post, del } from '../../auth/api';
import { showToast } from '../../common/Toast';
import { useLoader } from '../../loader/Loadercontext';
import SecurityScanCard from '../SecurityScanCard';
import TargetModal from './TargetModal';

export default function TestManagement() {
  const [tests, setTests] = useState([]);
  const [targets, setTargets] = useState([]);
  const [fuzzReports, setFuzzReports] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [testType, setTestType] = useState(null);
  const { showLoader, hideLoader } = useLoader();

  const fetchData = async () => {
    showLoader();
    try {
      // Fetch active tests
      const testsData = await get('/api/test/active/');
      console.log('[TestManagement] Fetched active tests:', testsData);
      setTests(testsData.map(test => ({
        ...test,
        testType: test.testType || (test.endpoint?.includes('fuzz') ? 'fuzz' : test.endpoint?.includes('load') ? 'load' : 'unknown')
      })));

      // Fetch completed tests (targets)
      const targetsData = await get('/api/test/completed/');
      console.log('[TestManagement] Fetched completed tests:', targetsData);
      setTargets(targetsData);

      // Fetch fuzz test reports for each target
      await fetchFuzzReports(targetsData);
    } catch (error) {
      console.error('[TestManagement] Error fetching tests or targets:', error);
      showToast(`Failed to fetch data: ${error.message}`, 'error');
    } finally {
      hideLoader();
    }
  };

  const fetchFuzzReports = async (targets) => {
    try {
      const reports = [];
      // Assuming targets is an array of target objects with 'id' and 'name'
      for (const target of targets) {
        const response = await post('/api/fuzzresult/', { target: target.id });
        console.log('[TestManagement] Fetched fuzz report for target:', target.id, response);
        if (response.results) {
          reports.push({
            id: target.id,
            target: { name: target.model_name || 'Unknown Target' },
            total_testcases: response.results.total_testcases || '-',
            testcases_passed: response.results.Test_case_passed || '-',
            accuracy_score: response.results.accuracy_score ? response.results.accuracy_score / 100 : '-',
            summary: response.results.summary || 'No summary available'
          });
        }
      }
      setFuzzReports(reports);
    } catch (error) {
      console.error('[TestManagement] Error fetching fuzz reports:', error);
      showToast('Failed to fetch fuzz test reports', 'error');
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    console.log('[TestManagement] Current tests state:', tests);
    console.log('[TestManagement] Current fuzz reports state:', fuzzReports);
  }, [tests, fuzzReports]);

  const startTest = async (testId) => {
    console.log(`[TestManagement] Starting test with ID: ${testId}`);
    try {
      await post(`/auth/tests/${testId}/start/`);
      showToast('Test started successfully', 'success');
      fetchData();
    } catch (error) {
      console.error('[TestManagement] Error starting test:', error);
      showToast('Failed to start test', 'error');
    }
  };

  const stopTest = async (testId) => {
    console.log(`[TestManagement] Stopping test with ID: ${testId}`);
    try {
      await post(`/auth/tests/${testId}/stop/`);
      showToast('Test stopped', 'info');
      fetchData();
    } catch (error) {
      console.error('[TestManagement] Error stopping test:', error);
      showToast('Failed to stop test', 'error');
    }
  };

  const deleteTest = async (testId) => {
    console.log(`[TestManagement] Deleting test with ID: ${testId}`);
    try {
      await del(`/auth/tests/${testId}/`);
      showToast('Test deleted', 'success');
      setTests(prev => prev.filter(t => t.id !== testId));
    } catch (error) {
      console.error('[TestManagement] Error deleting test:', error);
      showToast('Failed to delete test', 'error');
    }
  };

  const openModal = (type) => {
    console.log(`[TestManagement] Opening modal for testType: ${type}`);
    setTestType(type);
    setModalOpen(true);
  };

  return (
    <div className="admin-content">
      <div className="section-header">
        <h2>Automated Security Testing</h2>
        <p>Fuzz testing and load testing performed automatically by AI agents</p>
      </div>

      {/* Testing Cards */}
      <div className="testing-grid">
        <div className="testing-card testing-fuzz">
          <div className="card-header">
            <h3><Zap className="card-icon" /> Fuzz Testing</h3>
            <p>Automated input fuzzing for vulnerability discovery</p>
          </div>
          <button className="btn btn-warning btn-full" onClick={() => openModal('fuzz')}>
            <Play className="btn-icon" /> Start Fuzz Test
          </button>
        </div>

        <div className="testing-card testing-load">
          <div className="card-header">
            <h3><Activity className="card-icon" /> Load Testing</h3>
            <p>Performance testing and stress testing automation</p>
          </div>
          <button className="btn btn-success btn-full" onClick={() => openModal('load')}>
            <Play className="btn-icon" /> Start Load Test
          </button>
        </div>

        <SecurityScanCard />
      </div>

      {/* Active Tests */}
      <div className="tests-card">
        <div className="card-header">
          <h3>Active Tests</h3>
          <p>Currently running automated security tests</p>
        </div>
        <div className="tests-list">
          {tests.length === 0 ? (
            <p>No active tests available.</p>
          ) : (
            tests.map(test => (
              <div key={test.id} className="test-card">
                <h4>{test.target?.model_name || 'Unknown Target'}</h4>
                <p><strong>Target:</strong> {test.target?.endpoint_url || '-'}</p>
                <p><strong>Test Type:</strong> {test.testType || '-'}</p>
                <p>
                  <strong>Status:</strong> <span className={`badge ${test.target?.status || test.status}`}>{test.target?.status || test.status || 'Unknown'}</span>
                </p>
                <div className="test-actions">
                  {test.status === 'pending' && (
                    <button className="btn btn-outline btn-sm" onClick={() => startTest(test.id)}>
                      <Play className="btn-icon" /> Start
                    </button>
                  )}
                  {test.status === 'running' && (
                    <button className="btn btn-outline btn-warning btn-sm" onClick={() => stopTest(test.id)}>
                      <StopCircle className="btn-icon" /> Stop
                    </button>
                  )}
                  <button className="btn btn-outline btn-danger btn-sm" onClick={() => deleteTest(test.id)}>
                    <Trash2 className="btn-icon" /> Delete
                    </button>
                  )
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Fuzz Test Reports */}
      <div className="tests-card">
        <div className="card-header">
          <h3>Fuzz Test Reports</h3>
          <p>Summary of completed fuzz testing results</p>
        </div>
        <div className="tests-list">
          {fuzzReports.length === 0 ? (
            <p>No fuzz test reports available.</p>
          ) : (
            fuzzReports.map(report => (
              <div key={report.id} className="test-card">
                <h4>{report.target?.name || 'Unknown Target'}</h4>
                <p><strong>Total Test Cases:</strong> {report.total_testcases || '-'}</p>
                <p><strong>Test Cases Passed:</strong> {report.testcases_passed || '-'}</p>
                <p style={{color: report.accuracy_score === '-' ? 'black' : report.accuracy_score > 0.5 ? 'green' : 'red',}}>
                  <strong style={{color:'rgb(31, 41, 55)'}}>Accuracy Score:</strong> {report.accuracy_score ? `${(report.accuracy_score * 100).toFixed(2)}%` : '-'}
                </p>
                <p><strong>Summary:</strong> {report.summary || 'No summary available'}</p>
              </div>
            ))
          )}
        </div>
      </div>

      <TargetModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        onSubmit={fetchData}
        testType={testType}
      />
    </div>
  );
}