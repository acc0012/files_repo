
import { useEffect, useState } from 'react';
import { get, post, del } from '../auth/api';
import { FaWindowClose } from "react-icons/fa";
import { showToast } from '../common/Toast';
import { useLoader } from '../loader/Loadercontext';
import { useFuzzLoader } from './FuzzLoaderContext';
const TargetModal = ({ isOpen, onClose, onSubmit,type}) => {
  const [targets, setTargets] = useState([]);
  const [selectedTargets, setSelectedTargets] = useState([]);
  const [loading, setLoading] = useState(false);
  const { showLoader, hideLoader } = useLoader();
  const { setFuzzLoading } = useFuzzLoader();
  useEffect(() => {
    if (!isOpen) return;
    const fetchTargets = async () => {
      showLoader();
      try {
        console.log(type);
        const data = await get('/api/models/');
        setTargets(data);
      } catch (error) {
        console.error('Error fetching targets:', error);
        showToast('Failed to fetch targets', 'error');
      } finally {
        hideLoader();
      }
    };
    fetchTargets();
  }, [isOpen]);

  const handleSelectTarget = (targetId) => {
    setSelectedTargets(prev =>
      prev.includes(targetId)
        ? prev.filter(id => id !== targetId)
        : [...prev, targetId]
    );
  };

  const handleSubmit = async () => {
    setFuzzLoading(true);
    if (!selectedTargets.length) {
      showToast('No targets selected', 'warning');
      return;
    }
    try {
      const id = selectedTargets[0];
      const response = await post('/api/fuzztest/', { target: id });
      showToast('Fuzz tests started successfully', 'success');
      if (onSubmit) onSubmit(selectedTargets);
    } catch (err) {
      console.error('Error starting fuzz tests:', err);
      showToast('Failed to start fuzz tests', 'error');
    } finally {
      setFuzzLoading(false);
    }
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className='target-modal-overlay'>
      <div className='target-modal'>
        <div className='target-modal-header'>
          <h1>Select Target for Fuzz Testing</h1>
          <button className='close-btn' onClick={onClose}><FaWindowClose /></button>
        </div>
        <div className='modal-body'>
          {loading ? (
            <p>Loading targets...</p>
          ) : (
            <div className='targets-list'>
              {targets.map(target => {
                const checked = selectedTargets.includes(target.id);
                return (
                  <div key={target.id} className={`target-card ${checked ? 'selected' : ''}`}>
                    <div className="target-content" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div className="target-info" style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                        <h4>{target.model_name}</h4>
                        <p>{target.endpoint_url}</p>
                      </div>
                      <div className="target-checkbox">
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={() => handleSelectTarget(target.id)}
                          style={{ width: '24px', height: '24px', cursor: 'pointer' }}
                        />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
          <button className="btn btn-primary btn-full mt-2" onClick={handleSubmit} style={{ marginTop: '15px' }}>
            Submit Selected Targets
          </button>
        </div>
      </div>
    </div>
  );
};
export default TargetModal;