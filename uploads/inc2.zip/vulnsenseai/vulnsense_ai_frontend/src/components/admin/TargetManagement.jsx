import { useEffect, useState } from 'react';
import {
  Shield,
  Users,
  UserPlus,
  UserMinus,
  Activity,
  LogOut,
  Crown,
  CheckCircle,
  XCircle,
  Trash2,
  Home,
  BarChart3,
  User
} from 'lucide-react';  
import { Globe, Plus, Minus, Play, Settings } from 'lucide-react';
import { del, get, post } from '../auth/api'
import axios  from 'axios';
import { useLoader } from '../loader/Loadercontext';
export default function TargetManagement() {
  const [targets, setTargets] = useState([]);
  const [targetForms, setTargetForms] = useState([ {  model_name: '', endpoint_url: '', auto_sanitization: false }]);
  const [showAddTarget, setShowAddTarget] = useState(false);
  const [status,setStatus]=useState("inactive");
  const { showLoader, hideLoader } = useLoader()

  useEffect(() => {
    showLoader()
    const fetchTargets = async () => {
      try {
        const data = await get('api/models/');
        setTargets(data);
      } catch (error) {
        console.error('Error fetching targets:', error);
      }
      finally{
        hideLoader()
      }
    };
    fetchTargets();
  }, []);

  const fetchTargets = async () => {
    try {
      const data = await get('api/models/');
      setTargets(data);
    } catch (error) {
      console.error('Error fetching targets:', error);
    }
  };

  const targetStatus=async(id)=> {
    try{
      
      const response = await post(`api/target/status/${id}/`)
      await fetchTargets()

    }
    catch(e){
      console.log(e);
    }
  }

  const addTargetForm = () => setTargetForms([...targetForms, {  model_name: '', endpoint_url: '', auto_sanitization: false }]);
  const removeTargetForm = index => setTargetForms(targetForms.filter((_, i) => i !== index));
  const updateTargetForm = (index, field, value) => {
    const updated = [...targetForms];
    updated[index][field] = value;
    setTargetForms(updated);
  };

  const targetDelete = async(id) => {
    try {
      const response = await del(`api/target/delete/${id}/`)
      await fetchTargets()
    } catch (error) {
      console.error(error)
    }
  }

  const submitTargets = async () => {
    try {
      await Promise.all(targetForms.map(form => post('api/models/', form)));
      const data = await get('api/models/');
      setTargets(data);
      setTargetForms([{  model_name: '', endpoint_url: '', auto_sanitization: false }]);
      setShowAddTarget(false);
    } catch (error) {
      console.error('Error submitting targets:', error);
    }
  };

  return (
    <div className="admin-content">
      <div className="section-header">
        <div>
          <h2>Target Management</h2>
          <p>Configure AI models and applications for security testing</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowAddTarget(!showAddTarget)}>
          <Plus className="btn-icon" />
          Add Target
        </button>
      </div>
      {showAddTarget && (
        <div className="add-target-card">
          <div className="card-header">
            <h3>Add New Target</h3>
            <p>Configure models or applications for AI-powered security testing</p>
          </div>
          <div className="target-forms">
            {targetForms.map((form, index) => (
              <div key={index} className="target-form">
                <div className="form-header">
                  <h4>Target {index + 1}</h4>
                  {targetForms.length > 1 && (
                    <button className="btn btn-outline btn-danger" onClick={() => removeTargetForm(index)}>
                      <Minus className="btn-icon" />
                    </button>
                  )}
                </div>
                <div className="form-grid">
                  <div className="form-group">
                    <label>URL of Model/Application</label>
                    <input
                      type="text"
                      value={form.endpoint_url}
                      onChange={e => updateTargetForm(index, 'endpoint_url', e.target.value)}
                      placeholder="https://api.example.com"
                      className="form-input"
                    />
                  </div>
                  <div className="form-group">
                    <label>Name of Model/Application</label>
                    <input
                      type="text"
                      value={form.model_name}
                      onChange={e => updateTargetForm(index, 'model_name', e.target.value)}
                      placeholder="Production API"
                      className="form-input"
                    />
                  </div>
                </div>
                <div className="checkbox-group">
                  <input
                    type="checkbox"
                    checked={form.auto_sanitization}
                    onChange={e => updateTargetForm(index, 'auto_sanitization', e.target.checked)}
                  />
                  <label>Enable automatic prompt sanitization</label>
                </div>
              </div>
            ))}
            <div className="form-actions">
              <button className="btn btn-outline btn-primary" onClick={addTargetForm}>
                <Plus className="btn-icon" />
                Add Another Target
              </button>
              <div className="form-buttons">
                <button className="btn btn-outline" onClick={() => setShowAddTarget(false)}>Cancel</button>
                <button className="btn btn-primary" onClick={submitTargets}>Submit Targets</button>
              </div>
            </div>
          </div>
        </div>
      )}
      <div className="targets-list">
        {targets.map(target => (
          <div key={target.id} className="target-card">
            <div className="target-content">
              <div className="target-info">
                <div className="target-icon"><Globe className="icon" /></div>
                <div className="target-details">
                  <h4>{target.model_name}</h4>
                  <p>{target.endpoint_url}</p>
                  <div className="target-badges">
                    <span className={`badge ${target.status === 'active' ? 'badge-success' : 'badge-secondary'}`}>{target.status}</span>
                    {target.auto_sanitization && <span className="badge badge-primary">Auto-Sanitization</span>}
                  </div>
                </div>
              </div>
              <div className="target-actions">
                <button className="btn btn-outline btn-sm"><Play className="btn-icon" /> Start Test</button>
                <button className={`btn ${target.status==='active'? "btn-deactivate" :"btn-activate"}`}  onClick={() => targetStatus(target.id)}>{target.status==='active' ? (
                    <>
                      <XCircle />
                      Deactivate
                    </>
                  ) : (
                    <>
                      <CheckCircle  />
                      Activate
                    </>
                  )}</button>
                  <button className='btn btn-outline btn-sm btn-danger' onClick={() => targetDelete(target.id)}>
                     <Trash2 className="btn-icon" />
                        Delete
                  </button>
              </div>
            </div>
          </div>
        ))} 
      </div>
    </div>
  );
}
