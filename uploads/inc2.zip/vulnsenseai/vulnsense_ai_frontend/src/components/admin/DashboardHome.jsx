import { useEffect, useState } from 'react';
import { Globe, Activity, FileCode, Shield, Bot, CheckCircle, CloudCog } from 'lucide-react';
import { get } from '../auth/api';

export default function DashboardHome() {
  const [targets, setTargets] = useState([]);
  const [testResults, setTestResults] = useState([]);
  const [auditReports, setAuditReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activity, setActivity] = useState([])

  useEffect(() => {
    const fetchData = async () => {
      try {
        // 1. Get all targets
        // API: GET /models/
        // Request: No body needed
        // Response: Array of target objects, e.g. [{id, name, status, auto_sanitization}, ...]
        const targetsData = await get('api/models/');
        setTargets(targetsData);

        // 2. Get active tests
        // API: GET /test/active/
        // Request: No body needed
        // Response: Array of active test objects, e.g. [{id, target, type, status, start_time, findings}, ...]
        const activeTestsData = await get('api/test/active/');
        const activityData = await get('api/activity/')
        setActivity(activityData)
        // 3. Get completed tests
        // API: GET /test/completed/
        // Request: No body needed
        // Response: Array of completed test objects, same format as active tests
        const completedTestsData = await get('api/test/completed/');

        // Combine active + completed tests for dashboard
        const testResultsData = [...activeTestsData, ...completedTestsData];
        setTestResults(testResultsData);

        // 4. Get audit reports
        // API: GET /test/report/
        // Request: No body needed
        // Response: Array of audit report objects, e.g. [{id, target, generated_at, findings_summary}, ...]
        const auditsData = await get('api/test/report/');
        setAuditReports(auditsData);

      } catch (error) {
        console.error('Error fetching dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);


  if (loading) return <p>Loading dashboard...</p>;

  return (
    <div className="admin-content">
      <div className="welcome-card">
        <p>
          Ready to secure your applications? You have {targets.length} targets configured and{' '}
          {testResults.filter(r => r.status === 'running').length} tests currently running.
        </p>
      </div>
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-header">
            <span className="stat-title">Active Targets</span>
            <Globe className="stat-icon" />
          </div>
          <div className="stat-content">
            <div className="stat-number">{targets.filter(t => t.status === 'active').length}</div>
            <p className="stat-description">Out of {targets.length} total</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-header">
            <span className="stat-title">Running Tests</span>
            <Activity className="stat-icon" />
          </div>
          <div className="stat-content">
            <div className="stat-number">{testResults.filter(r => r.status === 'running').length}</div>
            <p className="stat-description">Active security tests</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-header">
            <span className="stat-title">Generated Reports</span>
            <FileCode className="stat-icon" />
          </div>
          <div className="stat-content">
            <div className="stat-number">{auditReports.length}</div>
            <p className="stat-description">Security audit reports</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-header">
            <span className="stat-title">Auto Sanitization</span>
            <Shield className="stat-icon" />
          </div>
          <div className="stat-content">
            <div className="stat-number">{targets.filter(t => t.auto_sanitization).length}</div>
            <p className="stat-description">Targets with auto-sanitization</p>
          </div>
        </div>
      </div>
      <div className="activity-card">
        <div className="card-header">
          <h3>Recent AI Actions</h3>
          <p>Latest automated security actions performed by the AI agent</p>
        </div>
        <div className="activity-list">
          {activity.map(t => {
              const target = targets.find(t => t.id === t.target);
              return (
                <div key={t.id} className="activity-item activity-success">
                  <Bot className="activity-icon" />
                  <div className="activity-content">
                    <p>Completed {t.action} test on {t.target?.model_name}</p>
                    <span className="activity-time">{new Date(t.timestamp).toLocaleString()} • {t.target?.status} Status</span>
                  </div>
                  <CheckCircle className="activity-status" />
                </div>
              );
            })}
        </div>
      </div>
    </div>
  );
}