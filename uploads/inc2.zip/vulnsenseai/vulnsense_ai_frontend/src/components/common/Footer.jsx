import { Shield } from 'lucide-react';

export function Footer() {
  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-grid">
          


        <div className="footer-bottom">
          <p>© 2025 TCS. All rights reserved.</p>
        </div>
      </div>
      </div>
    </footer>
  );
}
