from __future__ import annotations
from dataclasses import dataclass
from datetime import date, timedelta
import time

from src.data.candles import fetch_intraday_candles
from src.strategy.tw_all_in_one import compute
from src.execution.option_picker import pick_option
from src.execution.engine import ExecutionEngine, ExitRules
from src.dhan.instruments import InstrumentStore


@dataclass
class UnderlyingConfig:
    name: str
    under_exchange_segment: str
    opt_exchange_segment: str
    opt_instrument_type: str


class LivePollRunner:
    def __init__(self, dhan_api, cfg: dict, logger):
        self.dhan = dhan_api
        self.cfg = cfg
        self.log = logger
        self.store = InstrumentStore()
        self.master = self.store.load_master(refresh=False)
        self.engine = ExecutionEngine(self.dhan, self.log)

    def _exit_rules(self) -> ExitRules:
        t = self.cfg['trade']
        e = t['exits']
        p = t['partial_exits']
        r = t['risk']
        return ExitRules(
            partial_enabled=bool(p['enabled']),
            t1_pct=int(p['t1_pct']),
            t2_pct=int(p['t2_pct']),
            use_targets=bool(e['use_targets']),
            use_trailing_sl=bool(e['use_trailing_sl']),
            trailing_sl_pct=float(e['trailing_sl_pct']),
            exit_on_opposite_signal=bool(e['exit_on_opposite_signal']),
            hard_stop_enabled=bool(e['hard_stop_enabled']),
            max_loss_rupees=float(r['max_loss_rupees']),
        )

    def run_forever(self):
        tf = int(self.cfg['market']['timeframe_min'])
        poll = int(self.cfg['market']['poll_seconds'])
        under_list = [UnderlyingConfig(**u) for u in self.cfg['watchlist']]

        self.log.info(f"LivePollRunner started: timeframe={tf}m poll={poll}s")

        while True:
            for ucfg in under_list:
                try:
                    self._process_one(ucfg)
                except Exception as ex:
                    self.log.info(f"Error for {ucfg.name}: {ex}")
            time.sleep(poll)

    def _process_one(self, ucfg: UnderlyingConfig):
        # resolve underlying
        urow = self.store.resolve_underlying(self.master, ucfg.name)
        under_security_id = int(urow.get('SECURITY_ID') or urow.get('SEM_SMST_SECURITY_ID') or urow.get('SecurityId') or urow.get('SECURITYID'))

        # fetch candles
        to_date = date.today().isoformat()
        from_date = (date.today() - timedelta(days=7)).isoformat()
        tf = int(self.cfg['market']['timeframe_min'])

        df = fetch_intraday_candles(
            dhan_api=self.dhan,
            security_id=str(under_security_id),
            exchange_segment=ucfg.under_exchange_segment,
            instrument_type='INDEX',
            from_date=from_date,
            to_date=to_date,
            interval=tf,
        )
        if len(df) < 50:
            return

        res = compute(df, self.cfg)

        # If we have an open position, manage using option LTP
        if self.engine.has_position():
            pos = self.engine.pos
            try:
                q = self.dhan.quote_data([{'exchangeSegment': pos.exchange_segment, 'securityId': pos.security_id}])
                ltp = float(q['data'][0].get('lastTradedPrice') or q['data'][0].get('ltp') or q['data'][0].get('LTP'))
            except Exception:
                ltp = pos.entry_price
            self.engine.manage(ltp=ltp, signal=res.signal, rules=self._exit_rules())
            return

        # No position: enter on signal
        if res.signal in ('BUY', 'SELL'):
            opt_type = self.cfg['options']['side_mapping'][res.signal]
            pick = pick_option(
                dhan_api=self.dhan,
                under_security_id=under_security_id,
                under_exchange_segment=ucfg.under_exchange_segment,
                opt_type=opt_type,
                moneyness=self.cfg['options']['moneyness'],
                strike_steps=int(self.cfg['options'].get('strike_steps', 1)),
            )

            # Resolve option contract
            orow = self.store.resolve_option_contract(
                self.master,
                under_security_id=under_security_id,
                expiry=pick.expiry,
                strike=pick.strike,
                opt_type=pick.opt_type,
                opt_exchange_segment=ucfg.opt_exchange_segment,
            )
            opt_security_id = str(orow.get('SECURITY_ID') or orow.get('SEM_SMST_SECURITY_ID') or orow.get('SecurityId') or orow.get('SECURITYID'))
            lot = int(orow.get('LOT_SIZE') or orow.get('SEM_LOT_UNITS') or 1)
            qty = int(self.cfg['trade']['lots']) * lot

            # Option LTP
            q = self.dhan.quote_data([{'exchangeSegment': ucfg.opt_exchange_segment, 'securityId': opt_security_id}])
            opt_ltp = float(q['data'][0].get('lastTradedPrice') or q['data'][0].get('ltp') or q['data'][0].get('LTP'))

            # Initial risk model: option-premium based
            stop = opt_ltp * 0.70
            targets = [opt_ltp * 1.30, opt_ltp * 1.60]

            symbol = f"{ucfg.name} {pick.expiry} {pick.strike:.0f}{pick.opt_type}"
            self.log.info(f"{ucfg.name} signal={res.signal} -> BUY {symbol} secid={opt_security_id} qty={qty} optLTP={opt_ltp:.2f}")
            self.engine.enter_option_buy(symbol, opt_security_id, ucfg.opt_exchange_segment, qty, opt_ltp, stop, targets)
