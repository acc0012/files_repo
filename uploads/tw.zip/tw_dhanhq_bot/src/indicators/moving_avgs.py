from __future__ import annotations
import numpy as np
import pandas as pd


def ema(series: pd.Series, length: int) -> pd.Series:
    return series.ewm(span=int(length), adjust=False).mean()


def wma(series: pd.Series, length: int) -> pd.Series:
    length = int(length)
    if length <= 1:
        return series
    weights = np.arange(1, length + 1)
    return series.rolling(length).apply(lambda x: np.dot(x, weights) / weights.sum(), raw=True)


def hma(src: pd.Series, length: int) -> pd.Series:
    length = int(length)
    half = int(length / 2)
    sqrt_len = int(round(np.sqrt(length)))
    return wma(2 * wma(src, half) - wma(src, length), sqrt_len)


def ehma(src: pd.Series, length: int) -> pd.Series:
    length = int(length)
    sqrt_len = int(round(np.sqrt(length)))
    return ema(2 * ema(src, length) - ema(src, length), sqrt_len)


def thma(src: pd.Series, length: int) -> pd.Series:
    length = int(length)
    one_third = int(length / 3)
    half = int(length / 2)
    return wma(wma(src, one_third) * 3 - wma(src, half) - wma(src, length), length)
