from __future__ import annotations
import numpy as np
import pandas as pd


def pivot_high(series: pd.Series, left: int, right: int) -> pd.Series:
    n = len(series)
    out = np.zeros(n, dtype=bool)
    v = series.values
    for i in range(left, n - right):
        window = v[i - left:i + right + 1]
        c = v[i]
        if np.isfinite(c) and c == np.nanmax(window):
            out[i] = True
    return pd.Series(out, index=series.index)


def pivot_low(series: pd.Series, left: int, right: int) -> pd.Series:
    n = len(series)
    out = np.zeros(n, dtype=bool)
    v = series.values
    for i in range(left, n - right):
        window = v[i - left:i + right + 1]
        c = v[i]
        if np.isfinite(c) and c == np.nanmin(window):
            out[i] = True
    return pd.Series(out, index=series.index)


def valuewhen(condition: pd.Series, source: pd.Series, occurrence: int = 0) -> pd.Series:
    idx = condition[condition].index
    vals = source.loc[idx]
    out = []
    for t in condition.index:
        past = vals.loc[:t]
        if len(past) <= occurrence:
            out.append(np.nan)
        else:
            out.append(past.iloc[-1 - occurrence])
    return pd.Series(out, index=condition.index)
