from __future__ import annotations

from src.core.config import Settings
from src.core.logger import get_logger
from src.dhan.client import DhanClient
from src.live.runner import LivePollRunner


def main():
    cfg = Settings.load('config/settings.yaml').raw
    log = get_logger(level=cfg.get('logging', {}).get('level', 'INFO'))

    dhan = DhanClient.from_env().api()

    mode = cfg.get('mode', 'live_poll')
    if mode == 'live_poll':
        LivePollRunner(dhan, cfg, log).run_forever()
    else:
        log.info('Backtest mode not enabled in this pack. Use live_poll.')


if __name__ == '__main__':
    main()
