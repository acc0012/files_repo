from __future__ import annotations
from dataclasses import dataclass

from src.dhan.optionchain import expiry_list, option_chain_df


@dataclass
class PickedOption:
    expiry: str
    strike: float
    opt_type: str
    under_ltp: float


def pick_option(dhan_api, under_security_id: int, under_exchange_segment: str, opt_type: str,
                moneyness: str = 'ATM', strike_steps: int = 1) -> PickedOption:
    expiries = expiry_list(dhan_api, under_security_id, under_exchange_segment)
    expiry = expiries[0]

    under_ltp, df = option_chain_df(dhan_api, under_security_id, under_exchange_segment, expiry)
    df = df[df['type'] == opt_type].copy()

    strikes = sorted(df['strike'].unique())
    atm = min(strikes, key=lambda s: abs(s - under_ltp))

    if moneyness.upper() == 'ATM':
        strike = atm
    elif moneyness.upper() == 'ITM':
        if opt_type == 'CE':
            strike = max([s for s in strikes if s <= atm], default=atm)
            for _ in range(strike_steps - 1):
                strike = max([s for s in strikes if s < strike], default=strike)
        else:
            strike = min([s for s in strikes if s >= atm], default=atm)
            for _ in range(strike_steps - 1):
                strike = min([s for s in strikes if s > strike], default=strike)
    else:
        if opt_type == 'CE':
            strike = min([s for s in strikes if s >= atm], default=atm)
            for _ in range(strike_steps - 1):
                strike = min([s for s in strikes if s > strike], default=strike)
        else:
            strike = max([s for s in strikes if s <= atm], default=atm)
            for _ in range(strike_steps - 1):
                strike = max([s for s in strikes if s < strike], default=strike)

    return PickedOption(expiry=expiry, strike=float(strike), opt_type=opt_type, under_ltp=float(under_ltp))
