from __future__ import annotations
from dataclasses import dataclass


@dataclass
class ManagedPosition:
    symbol: str
    security_id: str
    exchange_segment: str
    qty: int
    entry_price: float
    stop: float | None
    t1: float | None
    t2: float | None
    t1_done: bool = False
    max_fav: float = 0.0


def update_trailing_sl(pos: ManagedPosition, ltp: float, trailing_sl_pct: float):
    fav = max(0.0, ltp - pos.entry_price)
    pos.max_fav = max(pos.max_fav, fav)
    if pos.stop is None:
        return
    trail = pos.entry_price + pos.max_fav * (1 - trailing_sl_pct / 100.0)
    if trail > pos.stop:
        pos.stop = trail


def should_exit_hard_loss(pos: ManagedPosition, ltp: float, max_loss_rupees: float) -> bool:
    pnl = (ltp - pos.entry_price) * pos.qty
    return pnl <= -abs(max_loss_rupees)
