from __future__ import annotations
from dataclasses import dataclass
from src.execution.position_manager import ManagedPosition, update_trailing_sl, should_exit_hard_loss
from src.execution.orders import place_market_buy, place_market_sell


@dataclass
class ExitRules:
    partial_enabled: bool
    t1_pct: int
    t2_pct: int
    use_targets: bool
    use_trailing_sl: bool
    trailing_sl_pct: float
    exit_on_opposite_signal: bool
    hard_stop_enabled: bool
    max_loss_rupees: float


class ExecutionEngine:
    def __init__(self, dhan_api, logger):
        self.dhan = dhan_api
        self.log = logger
        self.pos: ManagedPosition | None = None

    def has_position(self) -> bool:
        return self.pos is not None

    def enter_option_buy(self, symbol: str, security_id: str, exchange_segment: str, qty: int, entry_ltp: float, stop: float | None, targets: list[float]):
        resp = place_market_buy(self.dhan, security_id, exchange_segment, qty)
        self.log.info(f"BUY order response: {resp}")
        t1 = targets[0] if len(targets) > 0 else None
        t2 = targets[1] if len(targets) > 1 else None
        self.pos = ManagedPosition(symbol=symbol, security_id=security_id, exchange_segment=exchange_segment,
                                   qty=qty, entry_price=entry_ltp, stop=stop, t1=t1, t2=t2)

    def manage(self, ltp: float, signal: str | None, rules: ExitRules):
        if not self.pos:
            return
        pos = self.pos

        if rules.hard_stop_enabled and should_exit_hard_loss(pos, ltp, rules.max_loss_rupees):
            self.log.info('Hard loss threshold hit. Exiting full position.')
            self.exit_full()
            return

        if rules.use_trailing_sl:
            update_trailing_sl(pos, ltp, rules.trailing_sl_pct)

        if pos.stop is not None and ltp <= pos.stop:
            self.log.info(f"Stoploss hit at LTP={ltp:.2f} (SL={pos.stop:.2f}). Exiting full.")
            self.exit_full()
            return

        if rules.use_targets and pos.t1 is not None and (not pos.t1_done) and ltp >= pos.t1:
            if rules.partial_enabled:
                q_exit = max(1, int(pos.qty * rules.t1_pct / 100))
                self.log.info(f"Target1 hit. Exiting {q_exit}/{pos.qty}")
                self.exit_qty(q_exit)
                pos.qty -= q_exit
                pos.t1_done = True
                if pos.stop is not None:
                    pos.stop = max(pos.stop, pos.entry_price)
            else:
                self.log.info('Target1 hit. Exiting full.')
                self.exit_full()
                return

        if rules.use_targets and pos.t2 is not None and ltp >= pos.t2:
            self.log.info('Target2 hit. Exiting remaining.')
            self.exit_full()
            return

        if rules.exit_on_opposite_signal and signal is not None:
            if ('CE' in pos.symbol and signal == 'SELL') or ('PE' in pos.symbol and signal == 'BUY'):
                self.log.info(f"Opposite signal {signal}. Exiting full.")
                self.exit_full()
                return

    def exit_qty(self, qty: int):
        if not self.pos:
            return
        resp = place_market_sell(self.dhan, self.pos.security_id, self.pos.exchange_segment, qty)
        self.log.info(f"SELL (partial) response: {resp}")

    def exit_full(self):
        if not self.pos:
            return
        resp = place_market_sell(self.dhan, self.pos.security_id, self.pos.exchange_segment, self.pos.qty)
        self.log.info(f"SELL (full) response: {resp}")
        self.pos = None
