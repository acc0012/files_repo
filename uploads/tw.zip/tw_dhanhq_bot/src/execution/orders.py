from __future__ import annotations

# Basic wrappers. Depending on your dhanhq package version, constants may be enums.
# If this fails, check DhanHQ-py docs for place_order signature.


def place_market_buy(dhan_api, security_id: str, exchange_segment: str, quantity: int):
    return dhan_api.place_order(
        security_id=security_id,
        exchange_segment=exchange_segment,
        transaction_type='BUY',
        quantity=quantity,
        order_type='MARKET',
        product_type='INTRADAY',
        price=0,
        trigger_price=0,
        validity='DAY',
        disclosed_quantity=0
    )


def place_market_sell(dhan_api, security_id: str, exchange_segment: str, quantity: int):
    return dhan_api.place_order(
        security_id=security_id,
        exchange_segment=exchange_segment,
        transaction_type='SELL',
        quantity=quantity,
        order_type='MARKET',
        product_type='INTRADAY',
        price=0,
        trigger_price=0,
        validity='DAY',
        disclosed_quantity=0
    )
