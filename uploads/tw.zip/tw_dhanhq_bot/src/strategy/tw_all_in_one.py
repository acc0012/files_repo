from __future__ import annotations
from dataclasses import dataclass
import numpy as np
import pandas as pd

from src.indicators.moving_avgs import ema, hma, ehma, thma
from src.indicators.pivots import pivot_high, pivot_low, valuewhen


@dataclass
class StrategyOutput:
    df: pd.DataFrame
    signal: str | None
    levels: dict
    plan: dict


def crossover(a: pd.Series, b: pd.Series) -> pd.Series:
    return (a.shift(1) <= b.shift(1)) & (a > b)


def crossunder(a: pd.Series, b: pd.Series) -> pd.Series:
    return (a.shift(1) >= b.shift(1)) & (a < b)


def compute(df: pd.DataFrame, cfg: dict) -> StrategyOutput:
    s_cfg = cfg['strategy']
    length = int(s_cfg['length'])
    ema_len = int(s_cfg['ema_length'])
    ma_mode = str(s_cfg['ma_mode']).upper()

    out = df.copy()
    src = out['close']

    if ma_mode == 'HMA':
        hull = hma(src, length)
    elif ma_mode == 'EHMA':
        hull = ehma(src, length)
    elif ma_mode == 'THMA':
        hull = thma(src, int(length / 2))
    else:
        raise ValueError(f'Unknown ma_mode: {ma_mode}')

    out['HULL'] = hull
    out['MHULL'] = out['HULL']
    out['SHULL'] = out['HULL'].shift(2)
    out['EMA100'] = ema(src, ema_len)

    out['SELL_SIG'] = crossover(out['SHULL'], out['MHULL'])
    out['BUY_SIG'] = crossunder(out['SHULL'], out['MHULL'])

    signal = None
    if bool(out['SELL_SIG'].iloc[-1]):
        signal = 'SELL'
    elif bool(out['BUY_SIG'].iloc[-1]):
        signal = 'BUY'

    p = s_cfg['pivots']
    left = int(p['left'])
    right = int(p['right'])
    quick_right = int(p['quick_right'])
    src_mode = str(p.get('src', 'close')).lower()

    if src_mode == 'close':
        hi_src = out['close']
        lo_src = out['close']
        hi_val = out['close']
        lo_val = out['close']
    else:
        hi_src = out['high']
        lo_src = out['low']
        hi_val = out['high']
        lo_val = out['low']

    ph = pivot_high(hi_src, left, right)
    pl = pivot_low(lo_src, left, right)

    qph = pivot_high(hi_src, left, quick_right)
    qpl = pivot_low(lo_src, left, quick_right)

    lvl = {
        'level1': valuewhen(qph, hi_val.shift(quick_right), 0),
        'level2': valuewhen(qpl, lo_val.shift(quick_right), 0),
        'level3': valuewhen(ph, hi_val.shift(right), 0),
        'level4': valuewhen(pl, lo_val.shift(right), 0),
        'level5': valuewhen(ph, hi_val.shift(right), 1),
        'level6': valuewhen(pl, lo_val.shift(right), 1),
        'level7': valuewhen(ph, hi_val.shift(right), 2),
        'level8': valuewhen(pl, lo_val.shift(right), 2),
        'level9': valuewhen(pl, lo_val.shift(right), 3),
        'level10': valuewhen(pl, lo_val.shift(right), 3),
        'level11': valuewhen(ph, hi_val.shift(right), 4),
        'level12': valuewhen(pl, lo_val.shift(right), 4),
        'level13': valuewhen(pl, lo_val.shift(right), 5),
        'level14': valuewhen(pl, lo_val.shift(right), 5),
    }

    levels = {k: (float(v.iloc[-1]) if np.isfinite(v.iloc[-1]) else None) for k, v in lvl.items()}
    plan = build_trade_plan(float(out['close'].iloc[-1]), signal, levels)
    return StrategyOutput(df=out, signal=signal, levels=levels, plan=plan)


def build_trade_plan(entry: float, signal: str | None, levels: dict) -> dict:
    valid = sorted([v for v in levels.values() if isinstance(v, (int, float))])
    below = [x for x in valid if x < entry]
    above = [x for x in valid if x > entry]

    if signal == 'BUY':
        stop = max(below) if below else None
        targets = above[:2]
    elif signal == 'SELL':
        stop = min(above) if above else None
        targets = list(reversed(below[-2:]))
    else:
        stop, targets = None, []

    return {'entry': entry, 'stop': stop, 'targets': targets}
