from __future__ import annotations
import pandas as pd


def fetch_intraday_candles(dhan_api, security_id: str, exchange_segment: str, instrument_type: str,
                          from_date: str, to_date: str, interval: int) -> pd.DataFrame:
    resp = dhan_api.intraday_minute_data(
        security_id=security_id,
        exchange_segment=exchange_segment,
        instrument_type=instrument_type,
        from_date=from_date,
        to_date=to_date,
        interval=interval
    )

    if resp.get('status') != 'success':
        raise RuntimeError(f'intraday_minute_data failed: {resp}')

    data = resp.get('data', resp)
    df = pd.DataFrame({
        'time': data.get('start_Time'),
        'open': data.get('open'),
        'high': data.get('high'),
        'low': data.get('low'),
        'close': data.get('close'),
        'volume': data.get('volume'),
    })
    df['time'] = pd.to_datetime(df['time'], unit='s', utc=True)
    df = df.dropna().sort_values('time').reset_index(drop=True)
    return df
