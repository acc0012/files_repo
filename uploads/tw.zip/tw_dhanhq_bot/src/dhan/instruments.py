from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import pandas as pd

SCRIP_MASTER_DETAILED = 'https://images.dhan.co/api-data/api-scrip-master-detailed.csv'


@dataclass
class InstrumentStore:
    cache_dir: Path = Path('data_cache')

    def __post_init__(self):
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def load_master(self, refresh: bool = False) -> pd.DataFrame:
        cache = self.cache_dir / 'scrip_master_detailed.parquet'
        if cache.exists() and not refresh:
            return pd.read_parquet(cache)
        df = pd.read_csv(SCRIP_MASTER_DETAILED)
        df.to_parquet(cache, index=False)
        return df

    @staticmethod
    def _pick_col(df: pd.DataFrame, candidates: list[str]) -> str:
        for c in candidates:
            if c in df.columns:
                return c
        up = {c.upper(): c for c in df.columns}
        for c in candidates:
            if c.upper() in up:
                return up[c.upper()]
        raise KeyError(f'None of columns found: {candidates}')

    def resolve_underlying(self, master: pd.DataFrame, name: str) -> dict:
        name_col = self._pick_col(master, ['DISPLAY_NAME', 'SEM_CUSTOM_SYMBOL', 'SEM_TRADING_SYMBOL', 'TRADING_SYMBOL'])
        hit = master[master[name_col].astype(str).str.upper() == name.upper()]
        if hit.empty:
            hit = master[master[name_col].astype(str).str.upper().str.contains(name.upper(), na=False)]
        if hit.empty:
            raise ValueError(f'Underlying not found in master: {name}')
        return hit.iloc[0].to_dict()

    def resolve_option_contract(self, master: pd.DataFrame, under_security_id: int, expiry: str, strike: float, opt_type: str, opt_exchange_segment: str) -> dict:
        # Resolve option contract SECURITY_ID from master using underlying + expiry + strike + option type.
        # Master (Dhan detailed) includes columns such as UNDERLYING_SECURITY_ID, SM_EXPIRY_DATE, STRIKE_PRICE, OPTION_TYPE.
        col_under = self._pick_col(master, ['UNDERLYING_SECURITY_ID'])
        col_exp = self._pick_col(master, ['SM_EXPIRY_DATE', 'EXPIRY_DATE'])
        col_strike = self._pick_col(master, ['STRIKE_PRICE', 'SEM_STRIKE_PRICE'])
        col_opt = self._pick_col(master, ['OPTION_TYPE', 'SEM_OPTION_TYPE'])
        col_exchseg = self._pick_col(master, ['EXCH_SEGMENT', 'EXCHANGE_SEGMENT', 'SEGMENT', 'SEM_SEGMENT'])

        df = master.copy()
        df[col_exp] = df[col_exp].astype(str)
        df[col_opt] = df[col_opt].astype(str).str.upper()

        f = df[(df[col_under].astype(str) == str(under_security_id)) &
               (df[col_exp] == str(expiry)) &
               (df[col_opt] == opt_type.upper())]

        f2 = f[f[col_exchseg].astype(str).str.contains(opt_exchange_segment.split('_')[0], na=False)]
        if not f2.empty:
            f = f2

        strikes = f[col_strike].astype(float)
        target = float(strike)
        tol = 0.51
        f = f[(strikes - target).abs() <= tol]

        if f.empty:
            raise ValueError(f'Option contract not found for under={under_security_id}, exp={expiry}, strike={strike}, type={opt_type}, seg={opt_exchange_segment}')

        return f.iloc[0].to_dict()
