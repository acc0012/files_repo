from dataclasses import dataclass
from dotenv import load_dotenv
import os

from dhanhq import DhanContext, dhanhq

load_dotenv()


@dataclass
class DhanClient:
    client_id: str
    access_token: str

    @staticmethod
    def from_env() -> 'DhanClient':
        cid = os.getenv('DHAN_CLIENT_ID', '')
        tok = os.getenv('DHAN_ACCESS_TOKEN', '')
        if not cid or not tok:
            raise RuntimeError('Missing DHAN_CLIENT_ID / DHAN_ACCESS_TOKEN in environment (.env).')
        return DhanClient(cid, tok)

    def api(self):
        ctx = DhanContext(self.client_id, self.access_token)
        return dhanhq(ctx)
