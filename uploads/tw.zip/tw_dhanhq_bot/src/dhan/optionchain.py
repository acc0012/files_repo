from __future__ import annotations
import pandas as pd


def expiry_list(dhan_api, under_security_id: int, under_exchange_segment: str) -> list[str]:
    resp = dhan_api.expiry_list(under_security_id, under_exchange_segment)
    if resp.get('status') != 'success':
        raise RuntimeError(f'expiry_list failed: {resp}')
    return resp['data']


def option_chain_df(dhan_api, under_security_id: int, under_exchange_segment: str, expiry: str) -> tuple[float, pd.DataFrame]:
    resp = dhan_api.option_chain(under_security_id, under_exchange_segment, expiry)
    if resp.get('status') != 'success':
        raise RuntimeError(f'option_chain failed: {resp}')

    under_ltp = float(resp['data']['last_price'])
    oc = resp['data']['oc']

    rows = []
    for strike_str, node in oc.items():
        strike = float(strike_str)
        for k, t in (('ce', 'CE'), ('pe', 'PE')):
            if k not in node:
                continue
            d = node[k]
            g = d.get('greeks', {})
            rows.append({
                'strike': strike,
                'type': t,
                'ltp': d.get('last_price'),
                'bid': d.get('top_bid_price'),
                'ask': d.get('top_ask_price'),
                'oi': d.get('oi'),
                'iv': d.get('implied_volatility'),
                'delta': g.get('delta'),
                'gamma': g.get('gamma'),
                'theta': g.get('theta'),
                'vega': g.get('vega'),
                'volume': d.get('volume')
            })

    return under_ltp, pd.DataFrame(rows)
