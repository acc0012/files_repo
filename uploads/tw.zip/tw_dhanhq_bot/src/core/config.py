from dataclasses import dataclass
from pathlib import Path
import yaml


@dataclass
class Settings:
    raw: dict

    @staticmethod
    def load(path: str | Path) -> 'Settings':
        path = Path(path)
        with path.open('r', encoding='utf-8') as f:
            raw = yaml.safe_load(f)
        return Settings(raw=raw)
