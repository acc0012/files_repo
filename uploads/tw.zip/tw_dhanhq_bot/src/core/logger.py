from rich.logging import RichHandler
import logging


def get_logger(name: str = 'twbot', level: str = 'INFO') -> logging.Logger:
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger
    logger.setLevel(getattr(logging, level.upper(), logging.INFO))
    handler = RichHandler(rich_tracebacks=True)
    fmt = logging.Formatter('%(message)s')
    handler.setFormatter(fmt)
    logger.addHandler(handler)
    return logger
