# TW All-in-One (Pine) → DhanHQ Options Bot (Python)

This project ports your TradingView PineScript logic to Python and connects it to **DhanHQ**.

## What you get (ready-to-run)
- **Signal**: SHULL vs MHULL crossover/crossunder (same as Pine)
- **Trend lines**: EHMA/HMA/THMA hull + EMA100
- **Levels**: Pivot-based levels (left/right + quick pivots)
- **Options-only execution**: BUY → Buy CE, SELL → Buy PE
- **Exits**: Target1/Target2 partial exits + Trailing SL + Opposite-signal exit
- **Watchlist**: NIFTY, BANKNIFTY, FINNIFTY, SENSEX (configurable)

## DhanHQ APIs used
- Instrument master CSV provides Security IDs and derivative metadata (Underlying Security ID, Expiry, Strike, Option Type, Lot Size). https://dhanhq.co/docs/v2/instruments/
- Intraday candles (1/5/15/25/60) via intraday_minute_data (last ~5 trading days). https://deepwiki.com/dhan-oss/DhanHQ-py/5.4-historical-data
- Option Chain API provides strike-wise LTP/OI/Greeks/bid-ask; can be called once every 3 seconds. https://dhanhq.co/docs/v2/option-chain/

## Quick start
```bash
pip install -r requirements.txt
cp .env.example .env
# fill DHAN_CLIENT_ID and DHAN_ACCESS_TOKEN
python -m src.main
```

**Disclaimer:** Trading is risky. Start small/paper.
