import pandas as pd
from src.indicators.pivots import pivot_high, pivot_low


def test_pivots_basic():
    s = pd.Series([1,2,3,2,1,2,5,4,3,2,3,2,1])
    assert pivot_high(s, 1, 1).sum() >= 1
    assert pivot_low(s, 1, 1).sum() >= 1
