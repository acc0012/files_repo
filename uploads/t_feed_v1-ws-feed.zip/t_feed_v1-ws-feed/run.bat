cls

python main.py