"""Static configuration for TCS Proxy Health Check."""

# SSIDs treated as organisation Wi-Fi.
# Keep the exact SSID names as shown by Windows/netsh.
#
# Important:
# If Windows shows the SSID as !dw$_Tb_o@&
# then keep it as !dw$_Tb_o@&
# Do not use HTML value &amp; inside Python config.
ORGANISATION_SSID_LIST = [
    "!dw$_Tb_o@&",
    "C0rpW!5!@Of!(3",
]

TCS_PROXY_SERVER = "proxy.tcs.com:8080"

DEFAULT_PROXY_EXCEPTIONS = (
    "172.*;"
    "*.ultimatix.*;"
    "*INM*.TCS.COM;"
    "*IND*.TCS.COM;"
    "*INC*.TCS.COM;"
    "*INH*.TCS.COM;"
    "*INB*.TCS.COM;"
    "*INK*.tcs.com;"
    "buzz.tcs.com;"
    "voip.tcs.com;"
    "*.eurja*;"
    "*supportcentral.tcs.com;"
    "news.tcs.com;"
    "sg*.tcs.com;"
    "us*.tcs.com;"
    "uk*.tcs.com;"
    "*recruitment*;"
    "*careers*;"
    "157.*;"
    "sps*;"
    "ftc*;"
    "tw.tcs.com;"
    "edge.tcs.com;"
    "inchnveloa.tcs.com;"
    "*.india.tcs.com;"
    "ideastorm.tcs.com;"
    "securityportal.tcs.com;"
    "isisd.tcs.com;"
    "meeting.tcs.com;"
    "*video.tcs.com;"
    "mscommunityportal.tcs.com;"
    "search.tdcustagweb.tcs.com;"
    "Web2labs.tcs.com;"
    "academia.tcs.com;"
    "photo.tcs.com;"
    "*tcs-helpdesk*;"
    "ilpcms.tcs.com;"
    "campustaprocess.tcs.com;"
    "*tcsbas.tcsbpo*;"
    "globalmeet.tcs.com;"
    "bpoonline.tcs.com;"
    "*hrservicesonline.com*;"
    "*customersurvey.tcs.com*;"
    "mstream*;"
    "vstream.tcs.com;"
    "tcsmapagile.tcs.com;"
    "custportaluat.tcs.*;"
    "nextstep.tcs.com;"
    "knowfs.tcs.com;"
    "conference.tcs.com;"
    "*finterestgroup.com;"
    "customerportal.tcs.*;"
    "*alumniportal.tcs.com*;"
    "outlook.tcs.com;"
    "mail.tcs.com;"
    "Autodiscover.tcs.com;"
    "inmumexc01.tcs.com;"
    "inmumexc02.tcs.com;"
    "inmumzm01.tcs.com;"
    "inmumzm02.tcs.com;"
    "ecd.tcs.com;"
    "cas.tcs.com;"
    "gbamsuat.tcs.com;"
    "gbams.tcs.com;"
    "vmsprocurement.tcs.com;"
    "vms.tcs.com;"
    "boduat.tcs.com;"
    "*.BPO.TCS.COM*;"
    "i-asuhplabvm18.tcsasuhplab.com;"
    "avchat.tcs.com;"
    "meetingav.tcs.com;"
    "conference1.tcs.com;"
    "colosseum.tcs.com;"
    "lifeline.tcs.com;"
    "fit4life.tcs.com;"
    "tqas.tcs.com;"
    "irm.tcs.com;"
    "irmdr.tcs.com;"
    "dominoconnect.tcs.com;"
    "isprojects.tcs.com;"
    "secureerase.tcs.com;"
    "webmail.tcs.com;"
    "vlabsmumbai.tcs.com;"
    "is-connect.tcs.com;"
    "bodapp.tcs.com;"
    "bod.tcs.com;"
    "tob.boadapp.tcs.com;"
    "grodev.tcs.com;"
    "IS-Backup.tcs.com;"
    "*.itfrontier.co.jp;"
    "vlabschennai.tcs.com;"
    "mchat.tcs.com;"
    "10.*;"
    "*.tcsion.com;"
    "*.digialm.com;"
    "*.workspace.tcs.com;"
    "events.tcs.com;"
    "eventsdemo.tcs.com;"
    "bmsportal.tcs.com;"
    "optselfservice.tcs.com;"
    "meghaas-access.tcs.com;"
    "eventsuat.tcs.com;"
    "*.tcsionhub.in;"
    "*.tcsionhub.uk;"
    "163.122.229.*;"
    "*cloudvistara*;"
    "securepam.tcs.com;"
    "*.tcsgsp.in;"
    "*.Fresco.me;"
    "excellence.tcs.com;"
    "*hcp.*;"
    "cto-cybersecurityresearch.tcs.com*;"
    "occasions.tcs.com;"
    "*.iur.ls;"
    "*.cloudnext.tcs.com;"
    "*.fs.tcs.com;"
    "otpselfservice.tcs.com;"
    "*.tcsghdpcce.*;"
    "*.mdm.tcs.com;"
    "cdct2fa1.india.tcs.com;"
)

# Windows proxy registry path
PROXY_REG_PATH = r"Software\Microsoft\Windows\CurrentVersion\Internet Settings"

# Desktop shortcut name
# User double-clicks this icon to start live mode.
# User double-clicks again to stop live mode.
DESKTOP_SHORTCUT_NAME = "Check Proxy.lnk"

SHORTCUT_DESCRIPTION = "TCS Proxy Health Check - Start or Stop Live Mode"
SHORTCUT_HOTKEY = "CTRL+SHIFT+M"

# Icon file names inside icons folder
ENABLED_ICON_NAME = "enabled.ico"
DISABLED_ICON_NAME = "disabled.ico"

# Live mode polling interval in seconds
POLL_INTERVAL_SECONDS = 5

# Show popup when live mode starts
SHOW_STARTUP_POPUP = True

# Runtime files used for start/stop toggle mode
APP_RUNTIME_DIR_NAME = "runtime"
PID_FILE_NAME = "proxy_health_check.pid"
STOP_FILE_NAME = "proxy_health_check.stop"