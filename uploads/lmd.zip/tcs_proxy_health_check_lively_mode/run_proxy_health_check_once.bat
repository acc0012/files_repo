@echo off
setlocal

set "PROJECT_PATH=%~dp0"
cd /d "%PROJECT_PATH%"

where python >nul 2>&1
if errorlevel 1 (
    echo Python is not installed or not available in PATH.
    echo Please install Python 3.x and try again.
    pause
    exit /b 1
)

if not exist logs mkdir logs
python "%PROJECT_PATH%main.py"

endlocal
