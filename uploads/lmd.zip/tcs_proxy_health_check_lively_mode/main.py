from __future__ import annotations

import argparse
import os
import time
from dataclasses import dataclass
from pathlib import Path

from config.settings import (
    APP_RUNTIME_DIR_NAME,
    ORGANISATION_SSID_LIST,
    PID_FILE_NAME,
    POLL_INTERVAL_SECONDS,
    SHOW_STARTUP_POPUP,
    STOP_FILE_NAME,
    TCS_PROXY_SERVER,
)
from core.logger_setup import get_logger
from services.proxy_service import (
    disable_tcs_proxy,
    enable_tcs_proxy,
    get_proxy_status,
    get_proxy_status_text,
)
from services.shortcut_service import update_shortcut_icon
from services.wifi_service import get_current_ssid, is_organisation_ssid
from utils.message_utils import info, warning

logger = get_logger(__file__)


@dataclass(frozen=True)
class State:
    ssid: str
    is_org: bool
    proxy_enabled: int
    proxy_server: str


def _connected_network_text(ssid: str) -> str:
    if ssid.strip():
        return f"Connected SSID : {ssid}"
    return "Connected SSID : Not connected / Not detected"


def _runtime_dir() -> Path:
    path = Path(__file__).resolve().parent / APP_RUNTIME_DIR_NAME
    path.mkdir(exist_ok=True)
    return path


def _pid_file() -> Path:
    return _runtime_dir() / PID_FILE_NAME


def _stop_file() -> Path:
    return _runtime_dir() / STOP_FILE_NAME


def _write_pid_file() -> None:
    _pid_file().write_text(str(os.getpid()), encoding="utf-8")
    logger.info("PID file created. PID=%s", os.getpid())


def _stop_requested() -> bool:
    return _stop_file().exists()


def _cleanup_runtime_files() -> None:
    for path in (_pid_file(), _stop_file()):
        try:
            if path.exists():
                path.unlink()
                logger.info("Runtime file removed: %s", path)
        except Exception as exc:
            logger.exception("Failed to remove runtime file %s: %s", path, exc)


def detect_state() -> State:
    ssid = get_current_ssid()
    proxy = get_proxy_status()

    return State(
        ssid=ssid,
        is_org=is_organisation_ssid(ssid, ORGANISATION_SSID_LIST),
        proxy_enabled=proxy.enabled,
        proxy_server=proxy.server,
    )


def enforce_policy(state: State, reason: str = "Current status checked") -> None:
    """
    Mandatory proxy policy action.

    Organisation Wi-Fi:
        Proxy must be enabled.

    Personal or other Wi-Fi:
        Proxy must be disabled.
    """

    connected_text = _connected_network_text(state.ssid)

    logger.info(
        "Policy check started. Reason=%s | SSID=%s | Org=%s | ProxyEnabled=%s | Server=%s",
        reason,
        state.ssid,
        state.is_org,
        state.proxy_enabled,
        state.proxy_server,
    )

    if state.is_org:
        if state.proxy_enabled == 1 and state.proxy_server == TCS_PROXY_SERVER:
            update_shortcut_icon("enabled")
            logger.info("Organisation Wi-Fi detected. Proxy already enabled.")

            if reason == "startup" and SHOW_STARTUP_POPUP:
                info(
                    "Organisation network detected.\n\n"
                    f"{connected_text}\n"
                    "Current Proxy  : Enabled\n"
                    f"Proxy Server   : {state.proxy_server}\n\n"
                    "Proxy is already enabled as per Organisation policy.",
                    "TCS Proxy Health Check",
                )

            return

        warning(
            "Organisation network detected.\n\n"
            f"{connected_text}\n"
            f"Current Proxy  : {get_proxy_status_text(state.proxy_enabled)}\n"
            f"Current Server : {state.proxy_server or 'Not set'}\n\n"
            "Proxy is mandatory on Organisation Wi-Fi.\n"
            "TCS proxy and exception entries will be enabled now.\n\n"
            "Click OK to continue.",
            "TCS Proxy Mandatory Action",
        )

        enable_tcs_proxy()
        update_shortcut_icon("enabled")

        logger.info("TCS proxy enabled for Organisation Wi-Fi.")

        info(
            "TCS proxy has been enabled successfully.\n\n"
            f"{connected_text}\n"
            "Current Proxy  : Enabled\n"
            f"Proxy Server   : {TCS_PROXY_SERVER}\n"
            "Proxy exceptions have been updated.",
            "TCS Proxy Enabled",
        )

        return

    if state.proxy_enabled != 1:
        update_shortcut_icon("disabled")
        logger.info("Personal or non-Organisation Wi-Fi detected. Proxy already disabled.")

        if reason == "startup" and SHOW_STARTUP_POPUP:
            info(
                "Personal or non-Organisation network detected.\n\n"
                f"{connected_text}\n"
                "Current Proxy  : Disabled\n\n"
                "Proxy is already disabled.\n"
                "Please authenticate using Zscaler/VPN as per Organisation policy before accessing Organisation resources.",
                "TCS Proxy Health Check",
            )

        return

    warning(
        "Network change detected.\n\n"
        "You are connected to a personal or non-Organisation network.\n\n"
        f"{connected_text}\n"
        "Current Proxy  : Enabled\n"
        f"Proxy Server   : {state.proxy_server}\n\n"
        "TCS proxy must not remain enabled on personal or non-Organisation Wi-Fi.\n"
        "Proxy will be disabled now.\n\n"
        "Click OK to continue.",
        "TCS Proxy Mandatory Action",
    )

    disable_tcs_proxy()
    update_shortcut_icon("disabled")

    logger.info("Proxy disabled for personal or non-Organisation Wi-Fi.")

    info(
        "Proxy has been disabled successfully.\n\n"
        f"{connected_text}\n"
        "Current Proxy  : Disabled\n\n"
        "Please authenticate using Zscaler/VPN as per Organisation policy before accessing Organisation resources.",
        "Zscaler Authentication Required",
    )


def run_once() -> None:
    logger.info("TCS Proxy Health Check one-time mode started")
    enforce_policy(detect_state(), reason="startup")
    logger.info("TCS Proxy Health Check one-time mode completed")


def run_watch(interval: int = POLL_INTERVAL_SECONDS) -> None:
    logger.info("TCS Proxy Health Check live mode started. Interval=%s seconds", interval)

    print("TCS Proxy Health Check live mode running")
    print(f"Polling interval: {interval} seconds")
    print("Double-click Check Proxy again to stop.\n")

    _write_pid_file()

    previous_state: State | None = None

    try:
        while True:
            try:
                if _stop_requested():
                    logger.info("Stop request detected. Live mode stopping.")
                    print("\nStop request detected. Exiting live mode.")
                    break

                current_state = detect_state()

                print(
                    f"SSID={current_state.ssid or 'Not detected'} | "
                    f"Network={'Organisation' if current_state.is_org else 'Personal/Other'} | "
                    f"Proxy={get_proxy_status_text(current_state.proxy_enabled)} | "
                    f"Server={current_state.proxy_server or 'Not set'}"
                )

                if previous_state is None:
                    enforce_policy(current_state, reason="startup")

                elif current_state != previous_state:
                    logger.info(
                        "Network or proxy change detected. Old=%s | New=%s",
                        previous_state,
                        current_state,
                    )
                    enforce_policy(current_state, reason="network/proxy change detected")

                else:
                    if current_state.is_org and (
                        current_state.proxy_enabled != 1
                        or current_state.proxy_server != TCS_PROXY_SERVER
                    ):
                        enforce_policy(
                            current_state,
                            reason="non-compliant Organisation proxy state",
                        )

                    elif not current_state.is_org and current_state.proxy_enabled == 1:
                        enforce_policy(
                            current_state,
                            reason="non-compliant personal network proxy state",
                        )

                previous_state = detect_state()
                time.sleep(interval)

            except KeyboardInterrupt:
                logger.info("Live mode stopped by keyboard interrupt.")
                print("\nStopped by user.")
                break

            except Exception as exc:
                logger.exception("Unhandled live mode error: %s", exc)

                warning(
                    f"Unexpected error occurred:\n\n{exc}\n\n"
                    "Please check logs folder for details.",
                    "TCS Proxy Health Check",
                )

                time.sleep(interval)

    finally:
        _cleanup_runtime_files()
        logger.info("TCS Proxy Health Check live mode exited.")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="TCS Proxy Health Check")

    parser.add_argument(
        "--watch",
        action="store_true",
        help="Run continuously and detect Wi-Fi/proxy changes.",
    )

    parser.add_argument(
        "--interval",
        type=int,
        default=POLL_INTERVAL_SECONDS,
        help="Polling interval in seconds for watch mode.",
    )

    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()

    if args.watch:
        run_watch(max(1, args.interval))
    else:
        run_once()