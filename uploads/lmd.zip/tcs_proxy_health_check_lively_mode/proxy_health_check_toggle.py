from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from config.settings import (
    APP_RUNTIME_DIR_NAME,
    PID_FILE_NAME,
    STOP_FILE_NAME,
)
from core.logger_setup import get_project_root, get_logger
from utils.message_utils import info, warning

logger = get_logger(__file__)


def runtime_dir() -> Path:
    path = get_project_root() / APP_RUNTIME_DIR_NAME
    path.mkdir(exist_ok=True)
    return path


def pid_file() -> Path:
    return runtime_dir() / PID_FILE_NAME


def stop_file() -> Path:
    return runtime_dir() / STOP_FILE_NAME


def is_process_running(pid: int) -> bool:
    """
    Check whether given PID is still running.
    """

    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def get_existing_pid() -> int | None:
    """
    Read PID from runtime PID file.
    """

    path = pid_file()

    if not path.exists():
        return None

    try:
        pid_text = path.read_text(encoding="utf-8").strip()

        if not pid_text:
            return None

        return int(pid_text)

    except Exception as exc:
        logger.warning("Unable to read PID file: %s", exc)
        return None


def cleanup_stale_runtime_files() -> None:
    """
    Remove old PID/STOP files if live mode is not running.
    """

    for path in (pid_file(), stop_file()):
        try:
            if path.exists():
                path.unlink()
                logger.info("Removed stale runtime file: %s", path)
        except Exception as exc:
            logger.warning("Unable to remove runtime file %s: %s", path, exc)


def start_live_mode() -> None:
    """
    Start main.py in live watch mode.
    """

    project_root = get_project_root()
    main_py = project_root / "main.py"

    if stop_file().exists():
        stop_file().unlink()

    subprocess.Popen(
        [
            sys.executable,
            str(main_py),
            "--watch",
            "--interval",
            "5",
        ],
        cwd=str(project_root),
        creationflags=subprocess.CREATE_NEW_CONSOLE,
    )

    logger.info("TCS Proxy Health Check live mode start requested.")

    info(
        "TCS Proxy Health Check live mode has been started.\n\n"
        "The tool will continuously monitor Wi-Fi and proxy status.\n\n"
        "Double-click Check Proxy again to stop live mode.",
        "TCS Proxy Health Check Started",
    )


def stop_live_mode(pid: int) -> None:
    """
    Ask running live mode to stop.
    """

    stop_file().write_text("stop", encoding="utf-8")

    logger.info("Stop request created for live mode PID: %s", pid)

    info(
        "Stop request sent to TCS Proxy Health Check live mode.\n\n"
        "The background monitor will stop shortly.",
        "TCS Proxy Health Check Stop Requested",
    )


def main() -> None:
    """
    Toggle behavior:

    First double-click:
        Start live mode.

    Second double-click:
        Stop live mode.
    """

    existing_pid = get_existing_pid()

    if existing_pid and is_process_running(existing_pid):
        stop_live_mode(existing_pid)
        return

    cleanup_stale_runtime_files()
    start_live_mode()


if __name__ == "__main__":
    try:
        main()

    except Exception as exc:
        logger.exception("Toggle launcher failed: %s", exc)

        warning(
            "Unable to start or stop TCS Proxy Health Check.\n\n"
            f"Error details:\n{exc}\n\n"
            "Please check logs folder for details.",
            "TCS Proxy Health Check",
        )