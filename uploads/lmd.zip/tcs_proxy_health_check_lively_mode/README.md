# TCS Proxy Health Check - Lively Mode

This project runs a Windows proxy health check and can continuously monitor Wi-Fi changes.

## What changed from the previous version

- Removed Yes/No optional prompts.
- Added mandatory OK-only popups.
- Added lively/background mode with continuous polling.
- Automatically enables TCS proxy on Organisation Wi-Fi.
- Automatically disables proxy on personal/non-Organisation Wi-Fi.
- Reminds user to authenticate through Zscaler/VPN on personal/non-Organisation Wi-Fi.

## Run one-time check

```bat
run_proxy_health_check_once.bat
```

## Run lively/background mode for testing

```bat
run_proxy_health_check_lively.bat
```

Or:

```bat
python main.py --watch --interval 5
```

Press `Ctrl+C` in the command window to stop lively mode.

## Configure Organisation Wi-Fi

Edit:

```text
config/settings.py
```

Update:

```python
ORGANISATION_SSID_LIST = [
    "!dw$_Tb_o@&",
    "C0rpW!5!@Of!(3",
]
```

Important: `&amp;` from HTML/document text has been corrected to the real SSID character `&`.

## Install dependency

```bat
pip install -r requirements.txt
```

`pywin32` is only needed for shortcut icon update. Proxy registry update and popup messages work with built-in Windows modules.

## Logs

Logs are written to:

```text
logs\main.log
logs\proxy_service.log
logs\shortcut_service.log
```
