"""Popup message helpers.

Only OK popups are used for policy notifications. There are no Yes/No prompts.
"""

from __future__ import annotations

import ctypes

MB_OK = 0x00000000
MB_ICONINFORMATION = 0x00000040
MB_ICONWARNING = 0x00000030
MB_TOPMOST = 0x00040000


def info(message: str, title: str = "TCS Proxy Health Check") -> None:
    ctypes.windll.user32.MessageBoxW(None, message, title, MB_OK | MB_ICONINFORMATION | MB_TOPMOST)


def warning(message: str, title: str = "TCS Proxy Health Check") -> None:
    ctypes.windll.user32.MessageBoxW(None, message, title, MB_OK | MB_ICONWARNING | MB_TOPMOST)
