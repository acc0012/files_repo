# TCS Proxy Health Check - Lively Mode Flow

## Policy

```text
Organisation Wi-Fi:
    Proxy must be ON.
    Proxy server must be proxy.tcs.com:8080.
    Proxy exception entries must be set.
    User gets OK-only notification, no optional Yes/No choice.

Personal / Other Wi-Fi:
    Proxy must be OFF.
    User gets OK-only notification.
    Tool disables proxy and reminds user to authenticate via Zscaler/VPN.
```

## Lively Mode

Run:

```bat
run_proxy_health_check_lively.bat
```

Or:

```bat
python main.py --watch --interval 5
```

The tool keeps running, checks SSID/proxy status every few seconds, and acts when a Wi-Fi or proxy status change is detected.

## Flow

```mermaid
flowchart TD
    A[Start lively/background mode] --> B[Detect current Wi-Fi SSID]
    B --> C[Read Windows proxy status]
    C --> D{Organisation Wi-Fi?}

    D -->|Yes| E{Proxy enabled and server correct?}
    E -->|Yes| F[No change required, green icon]
    E -->|No| G[Show OK popup: proxy mandatory]
    G --> H[Enable TCS proxy]
    H --> I[Set proxy exceptions]
    I --> J[Show OK popup: proxy enabled]
    J --> K[Green icon]

    D -->|No| L{Proxy enabled?}
    L -->|No| M[No change required, red icon]
    L -->|Yes| N[Show OK popup: personal network detected]
    N --> O[Disable proxy]
    O --> P[Show OK popup: authenticate using Zscaler/VPN]
    P --> Q[Red icon]

    F --> R[Wait interval]
    K --> R
    M --> R
    Q --> R
    R --> B
```
