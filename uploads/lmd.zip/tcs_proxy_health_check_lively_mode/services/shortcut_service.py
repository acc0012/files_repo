"""Desktop shortcut icon updater.

This file creates/updates the desktop shortcut.

Shortcut behavior:
    Double-click Check Proxy first time  -> start live mode
    Double-click Check Proxy second time -> stop live mode
"""

from __future__ import annotations

from pathlib import Path

from config.settings import (
    DESKTOP_SHORTCUT_NAME,
    DISABLED_ICON_NAME,
    ENABLED_ICON_NAME,
    SHORTCUT_DESCRIPTION,
    SHORTCUT_HOTKEY,
)
from core.logger_setup import get_project_root, get_logger

logger = get_logger(__file__)


def _desktop_path() -> Path:
    return Path.home() / "Desktop"


def _get_icon_path(state: str) -> Path:
    project_root = get_project_root()

    if state == "enabled":
        icon_name = ENABLED_ICON_NAME
    else:
        icon_name = DISABLED_ICON_NAME

    return project_root / "icons" / icon_name


def create_or_update_shortcut(state: str = "disabled") -> None:
    """
    Create or update the Check Proxy desktop shortcut.

    The shortcut points to:
        run_proxy_health_check_lively.bat

    That BAT file will call:
        proxy_health_check_toggle.py
    """

    try:
        import win32com.client  # type: ignore
    except Exception as exc:
        logger.warning("pywin32 is not available. Shortcut update skipped: %s", exc)
        return

    project_root = get_project_root()

    shortcut_path = _desktop_path() / DESKTOP_SHORTCUT_NAME
    target_path = project_root / "run_proxy_health_check_lively.bat"
    icon_path = _get_icon_path(state)

    try:
        shell = win32com.client.Dispatch("WScript.Shell")
        shortcut = shell.CreateShortcut(str(shortcut_path))

        shortcut.TargetPath = str(target_path)
        shortcut.WorkingDirectory = str(project_root)
        shortcut.Description = SHORTCUT_DESCRIPTION
        shortcut.Hotkey = SHORTCUT_HOTKEY

        if icon_path.exists():
            shortcut.IconLocation = str(icon_path)
        else:
            logger.warning("Icon file not found: %s", icon_path)

        shortcut.Save()

        logger.info("Desktop shortcut created/updated: %s", shortcut_path)

    except Exception as exc:
        logger.exception("Shortcut create/update failed: %s", exc)


def update_shortcut_icon(state: str) -> None:
    """
    Update Check Proxy shortcut icon.

    state values:
        enabled  -> green/enabled icon
        disabled -> red/disabled icon
    """

    if state not in ("enabled", "disabled"):
        logger.warning("Invalid shortcut icon state received: %s", state)
        state = "disabled"

    create_or_update_shortcut(state)