"""Wi-Fi SSID detection using Windows netsh."""

from __future__ import annotations

import subprocess
from typing import Iterable


def _run_netsh() -> str:
    completed = subprocess.run(
        ["netsh", "wlan", "show", "interfaces"],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="ignore",
        shell=False,
    )
    return completed.stdout or ""


def get_current_ssid() -> str:
    output = _run_netsh()
    for raw_line in output.splitlines():
        line = raw_line.strip()
        if line.lower().startswith("ssid") and "bssid" not in line.lower():
            parts = line.split(":", 1)
            if len(parts) == 2:
                return parts[1].strip()
    return ""


def normalize_ssid(value: str) -> str:
    return (value or "").strip().casefold()


def is_organisation_ssid(ssid: str, organisation_ssids: Iterable[str]) -> bool:
    current = normalize_ssid(ssid)
    return bool(current) and current in {normalize_ssid(item) for item in organisation_ssids}

# Backward-compatible alias for existing imports/code style.
is_Organisation_ssid = is_organisation_ssid
