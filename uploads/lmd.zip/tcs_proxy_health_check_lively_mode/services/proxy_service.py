"""Windows proxy registry functions."""

from __future__ import annotations

from dataclasses import dataclass
import winreg
import ctypes

from config.settings import DEFAULT_PROXY_EXCEPTIONS, PROXY_REG_PATH, TCS_PROXY_SERVER

INTERNET_OPTION_SETTINGS_CHANGED = 39
INTERNET_OPTION_REFRESH = 37


@dataclass(frozen=True)
class ProxyStatus:
    enabled: int
    server: str
    exceptions: str


def _read_value(name: str, default):
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, PROXY_REG_PATH, 0, winreg.KEY_READ) as key:
            value, _ = winreg.QueryValueEx(key, name)
            return value
    except FileNotFoundError:
        return default
    except OSError:
        return default


def _set_value(name: str, reg_type: int, value) -> None:
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, PROXY_REG_PATH, 0, winreg.KEY_SET_VALUE) as key:
        winreg.SetValueEx(key, name, 0, reg_type, value)


def _notify_windows_proxy_changed() -> None:
    ctypes.windll.Wininet.InternetSetOptionW(0, INTERNET_OPTION_SETTINGS_CHANGED, 0, 0)
    ctypes.windll.Wininet.InternetSetOptionW(0, INTERNET_OPTION_REFRESH, 0, 0)


def get_proxy_status() -> ProxyStatus:
    return ProxyStatus(
        enabled=int(_read_value("ProxyEnable", 0) or 0),
        server=str(_read_value("ProxyServer", "") or ""),
        exceptions=str(_read_value("ProxyOverride", "") or ""),
    )


def get_proxy_status_text(enabled: int) -> str:
    return "Enabled" if int(enabled) == 1 else "Disabled"


def enable_tcs_proxy() -> None:
    _set_value("ProxyEnable", winreg.REG_DWORD, 1)
    _set_value("ProxyServer", winreg.REG_SZ, TCS_PROXY_SERVER)
    _set_value("ProxyOverride", winreg.REG_SZ, DEFAULT_PROXY_EXCEPTIONS)
    _notify_windows_proxy_changed()


def disable_tcs_proxy() -> None:
    _set_value("ProxyEnable", winreg.REG_DWORD, 0)
    _notify_windows_proxy_changed()
