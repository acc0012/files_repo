# main.py

import logging
import threading
import time

from historical.history_loader import load_history
from strategies.ema_cross_strategy import EmaCrossStrategy
from websocket_feed.market_feed import MarketFeed

# ----------------------------------------------------------
# Logging
# ----------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format=("%(asctime)s | " "%(levelname)s | " "%(name)s | " "%(message)s"),
    handlers=[logging.FileHandler("nifty_ema_strategy.log"), logging.StreamHandler()],
)

logger = logging.getLogger("nifty-ema-main")


# ----------------------------------------------------------
# Globals
# ----------------------------------------------------------
strategy = None
market_feed = None


# ----------------------------------------------------------
# Health Monitor
# ----------------------------------------------------------
def health_check():

    global strategy
    global market_feed

    while True:

        time.sleep(60)

        try:

            if market_feed is None:
                continue

            ltp = market_feed.latest_ltp

            if ltp is None:

                logger.warning("[HEALTH] " "Waiting for market feed...")

                continue

            state = strategy.get_state()

            logger.info(
                "[HEALTH] "
                f"LTP={ltp} | "
                f"EMA9={state['ema9']} | "
                f"EMA21={state['ema21']}"
            )

        except Exception as ex:

            logger.exception("Health Check Failed: %s", ex)


# ----------------------------------------------------------
# Candle Close Event
# ----------------------------------------------------------
def on_candle_close(candle):

    global strategy

    try:

        result = strategy.process_candle(candle)

        logger.info(
            "[CANDLE] "
            f"{result['timestamp']} | "
            f"CLOSE={result['close']} | "
            f"EMA9={result['ema9']} | "
            f"EMA21={result['ema21']} | "
            f"SIGNAL={result['signal']}"
        )

    except Exception as ex:

        logger.exception("Error Processing Candle: %s", ex)


# ----------------------------------------------------------
# Main
# ----------------------------------------------------------
def main():

    global strategy
    global market_feed

    try:

        logger.info("=" * 60)

        logger.info("STEP 1 : Loading Historical Data")

        # --------------------------------------
        # Load Last N Days History
        # --------------------------------------
        ema_state = load_history(
            instrument_key="NSE_INDEX|Nifty 50", interval="1minute", days=3
        )

        logger.info("Historical Load Complete")

        logger.info(f"Latest EMA State: " f"{ema_state}")

        # --------------------------------------
        # Create Strategy
        # --------------------------------------
        logger.info("STEP 2 : Initializing Strategy")

        strategy = EmaCrossStrategy(ema_state=ema_state)

        # --------------------------------------
        # Create WebSocket Feed
        # --------------------------------------
        logger.info("STEP 3 : Initializing Market Feed")

        market_feed = MarketFeed(instrument_key="NSE_INDEX|Nifty 50")

        market_feed.set_candle_callback(on_candle_close)

        # --------------------------------------
        # Health Monitor
        # --------------------------------------
        logger.info("STEP 4 : Starting Health Monitor")

        threading.Thread(target=health_check, daemon=True).start()

        # --------------------------------------
        # Connect Feed
        # --------------------------------------
        logger.info("STEP 5 : Connecting WebSocket")

        market_feed.connect()

        # --------------------------------------
        # Keep Main Alive
        # --------------------------------------
        while True:

            time.sleep(1)

    except KeyboardInterrupt:

        logger.info("Application Stopped")

    except Exception as ex:

        logger.exception("Application Failed: %s", ex)


# ----------------------------------------------------------
# Entry Point
# ----------------------------------------------------------
if __name__ == "__main__":

    main()
