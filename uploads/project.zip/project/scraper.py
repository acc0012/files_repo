import requests
from bs4 import BeautifulSoup
import json, re

BASE_LISTING_URL = ""
BASE_VIDEO_URL = ""
BASE_SEARCH_URL = ""
BASE_TAG_URL = ""
BASE_AUTOCOMPLETE_URL = ""

def scrape_listing_page(page):
    url = BASE_LISTING_URL.format(page)
    html = requests.get(url).text
    soup = BeautifulSoup(html, "html.parser")
    cards = []
    items = soup.find_all("div", class_="item")

    for item in items:
        a = item.find("a")
        if not a:
            continue
        cards.append({
            "title": item.find("div", class_="title").get_text(strip=True),
            "image": item.find("img").get("data-src") or item.find("img").get("src"),
            "duration": item.find("div", class_="m_time").get_text(strip=True),
            "views": item.find("div", class_="m_views").get_text(strip=True),
            "url": a.get("href")
        })
    return {"cards": cards}

def scrape_video_page(video_id):
    url = BASE_VIDEO_URL.format(video_id)
    html = requests.get(url).text
    m = re.search(r"window\.playlist\s*=\s*(\{.*?\});", html, re.S)
    playlist = json.loads(m.group(1)) if m else {"sources": []}
    video_360 = next((s["file"] for s in playlist["sources"] if s.get("label") == "360"), None)
    return {
        "video_url": video_360,
        "image": playlist.get("image"),
        "title": "Video Title (set real title via scraper)"
    }

def scrape_search_page(query):
    return {"cards": scrape_listing_page(1)["cards"]}

def scrape_tag_page(tag):
    return {"cards": scrape_listing_page(1)["cards"]}

def fetch_autocomplete(query):
    if not query:
        return {"results": []}
    url = BASE_AUTOCOMPLETE_URL.format(query)
    return requests.get(url).json()
