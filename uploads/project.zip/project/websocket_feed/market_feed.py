# websocket/market_feed.py

import logging
from datetime import datetime

import upstox_client

from upstox_connection import api_client

logger = logging.getLogger(__name__)


class MarketFeed:

    def __init__(self, instrument_key="NSE_INDEX|Nifty 50"):

        self.instrument_key = instrument_key

        self.streamer = upstox_client.MarketDataStreamerV3(api_client)

        # --------------------------------------
        # Candle Builder
        # --------------------------------------
        self.current_minute = None

        self.open_price = None
        self.high_price = None
        self.low_price = None
        self.close_price = None

        # --------------------------------------
        # Latest Market Data
        # --------------------------------------
        self.latest_ltp = None
        self.latest_cp = None

        # --------------------------------------
        # Callback
        # --------------------------------------
        self.on_candle_close_callback = None

    # ----------------------------------------------------------
    # Callback Registration
    # ----------------------------------------------------------
    def set_candle_callback(self, callback):
        """
        main.py registers callback

        callback(candle)
        """
        self.on_candle_close_callback = callback

    # ----------------------------------------------------------
    # Epoch To Minute
    # ----------------------------------------------------------
    @staticmethod
    def epoch_to_minute(epoch_ms):

        dt = datetime.fromtimestamp(int(epoch_ms) / 1000)

        return dt.strftime("%Y-%m-%d %H:%M")

    # ----------------------------------------------------------
    # Epoch To Readable
    # ----------------------------------------------------------
    @staticmethod
    def epoch_to_readable(epoch_ms):

        dt = datetime.fromtimestamp(int(epoch_ms) / 1000)

        return dt.strftime("%d-%b-%Y %I:%M %p")

    # ----------------------------------------------------------
    # Process Tick
    # ----------------------------------------------------------
    def process_tick(self, ltp, ltt):

        candle_minute = self.epoch_to_minute(ltt)

        # ----------------------------------
        # First Tick
        # ----------------------------------
        if self.current_minute is None:

            self.current_minute = candle_minute

            self.open_price = ltp
            self.high_price = ltp
            self.low_price = ltp
            self.close_price = ltp

            return

        # ----------------------------------
        # Same Minute
        # ----------------------------------
        if candle_minute == self.current_minute:

            self.high_price = max(self.high_price, ltp)

            self.low_price = min(self.low_price, ltp)

            self.close_price = ltp

            return

        # ----------------------------------
        # Minute Completed
        # ----------------------------------
        completed_candle = {
            "timestamp": self.current_minute,
            "timestamp_readable": self.epoch_to_readable(ltt),
            "open": round(self.open_price, 2),
            "high": round(self.high_price, 2),
            "low": round(self.low_price, 2),
            "close": round(self.close_price, 2),
        }

        logger.info(f"Candle Closed: " f"{completed_candle}")

        if self.on_candle_close_callback is not None:
            self.on_candle_close_callback(completed_candle)

        # ----------------------------------
        # Start New Candle
        # ----------------------------------
        self.current_minute = candle_minute

        self.open_price = ltp
        self.high_price = ltp
        self.low_price = ltp
        self.close_price = ltp

    # ----------------------------------------------------------
    # On Open
    # ----------------------------------------------------------
    def on_open(self):

        logger.info("WebSocket connected")

        self.streamer.subscribe([self.instrument_key], "full")

        logger.info(f"Subscribed: " f"{self.instrument_key}")

    # ----------------------------------------------------------
    # On Message
    # ----------------------------------------------------------
    def on_message(self, message):

        try:

            feeds = message.get("feeds", {})

            nifty_feed = feeds.get(self.instrument_key)

            if not nifty_feed:
                return

            ltpc = nifty_feed.get("fullFeed", {}).get("indexFF", {}).get("ltpc", {})

            ltp = ltpc.get("ltp")
            ltt = ltpc.get("ltt")
            cp = ltpc.get("cp")

            if ltp is None or ltt is None:
                return

            self.latest_ltp = ltp
            self.latest_cp = cp

            self.process_tick(ltp, ltt)

        except Exception as ex:

            logger.exception("Feed Error: %s", ex)

    # ----------------------------------------------------------
    # On Error
    # ----------------------------------------------------------
    def on_error(self, error):

        logger.error("WebSocket Error: %s", error)

    # ----------------------------------------------------------
    # On Close
    # ----------------------------------------------------------
    def on_close(self):

        logger.warning("WebSocket Closed")

    # ----------------------------------------------------------
    # Connect
    # ----------------------------------------------------------
    def connect(self):

        self.streamer.on("open", self.on_open)

        self.streamer.on("message", self.on_message)

        self.streamer.on("error", self.on_error)

        self.streamer.on("close", self.on_close)

        logger.info("Connecting to " "Upstox Market Feed...")

        self.streamer.connect()
