const box = document.getElementById('search-box');
const list = document.getElementById('autocomplete-box');

box.addEventListener('input', async () => {
    let q = box.value.trim();
    if (!q) { list.innerHTML = ''; return; }

    let r = await fetch('/autocomplete?q=' + encodeURIComponent(q));
    let data = await r.json();

    list.innerHTML = '';
    data.results.forEach(item => {
        let li = document.createElement('li');
        li.className = 'list-group-item';
        li.textContent = item;
        li.onclick = () => window.location.href = '/search/' + encodeURIComponent(item);
        list.appendChild(li);
    });
});
