# indicators/ema.py

import json
import logging

logger = logging.getLogger(__name__)


# ----------------------------------------------------------
# EMA Calculator
# ----------------------------------------------------------
def calculate_ema(prices, period):

    if not prices:
        return []

    multiplier = 2 / (period + 1)

    ema_values = []

    ema = prices[0]
    ema_values.append(ema)

    for price in prices[1:]:

        ema = ((price - ema) * multiplier) + ema

        ema_values.append(ema)

    return ema_values


# ----------------------------------------------------------
# Single EMA Update
# ----------------------------------------------------------
def update_ema(previous_ema, close_price, period):
    """
    Incremental EMA Calculation

    EMA = ((Close - PrevEMA) * Multiplier)
          + PrevEMA
    """

    multiplier = 2 / (period + 1)

    ema = ((close_price - previous_ema) * multiplier) + previous_ema

    return round(ema, 2)


# ----------------------------------------------------------
# EMA Cross Detection
# ----------------------------------------------------------
def detect_cross(previous_ema9, previous_ema21, current_ema9, current_ema21):

    bullish_cross = previous_ema9 <= previous_ema21 and current_ema9 > current_ema21

    bearish_cross = previous_ema9 >= previous_ema21 and current_ema9 < current_ema21

    if bullish_cross:
        return "BULLISH"

    if bearish_cross:
        return "BEARISH"

    return "NONE"


# ----------------------------------------------------------
# Process New Candle
# ----------------------------------------------------------
def process_candle(close_price, timestamp, previous_ema9, previous_ema21):

    current_ema9 = update_ema(previous_ema9, close_price, 9)

    current_ema21 = update_ema(previous_ema21, close_price, 21)

    signal = detect_cross(previous_ema9, previous_ema21, current_ema9, current_ema21)

    result = {
        "timestamp": timestamp,
        "close": round(close_price, 2),
        "ema9": round(current_ema9, 2),
        "ema21": round(current_ema21, 2),
        "signal": signal,
    }

    return result


# ----------------------------------------------------------
# Load EMA State
# ----------------------------------------------------------
def load_ema_state(file_name="ema_state.json"):

    with open(file_name, "r", encoding="utf-8") as f:

        return json.load(f)


# ----------------------------------------------------------
# Save EMA State
# ----------------------------------------------------------
def save_ema_state(state, file_name="ema_state.json"):

    with open(file_name, "w", encoding="utf-8") as f:

        json.dump(state, f, indent=4)


# ----------------------------------------------------------
# Update EMA State
# ----------------------------------------------------------
def update_ema_state(timestamp, close_price, state):

    result = process_candle(
        close_price=close_price,
        timestamp=timestamp,
        previous_ema9=state["ema9"],
        previous_ema21=state["ema21"],
    )

    updated_state = {
        "instrument_key": state.get("instrument_key"),
        "last_timestamp": timestamp,
        "last_close": round(close_price, 2),
        "ema9": result["ema9"],
        "ema21": result["ema21"],
    }

    save_ema_state(updated_state)

    return result, updated_state
