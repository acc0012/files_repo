@echo off
start "Upstox Nifty Feed" cmd /k python main.py