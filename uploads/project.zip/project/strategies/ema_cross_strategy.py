# strategies/ema_cross_strategy.py

import json
import logging
import os

from indicators.ema import update_ema_state

logger = logging.getLogger(__name__)


class EmaCrossStrategy:

    def __init__(self, ema_state):

        self.ema_state = ema_state

        self.signal_file = "live_ema_crosses.json"

        self.signals = self.load_existing_signals()

    # ----------------------------------------------------------
    # Load Existing Signals
    # ----------------------------------------------------------
    def load_existing_signals(self):

        if not os.path.exists(self.signal_file):
            return []

        try:

            with open(self.signal_file, "r", encoding="utf-8") as f:

                data = json.load(f)

                return data.get("signals", [])

        except Exception:

            return []

    # ----------------------------------------------------------
    # Save Signals
    # ----------------------------------------------------------
    def save_signals(self):

        output = {
            "instrument_key": self.ema_state.get("instrument_key"),
            "total_signals": len(self.signals),
            "signals": self.signals,
        }

        with open(self.signal_file, "w", encoding="utf-8") as f:

            json.dump(output, f, indent=4)

    # ----------------------------------------------------------
    # Process Completed Candle
    # ----------------------------------------------------------
    def process_candle(self, candle):

        result, self.ema_state = update_ema_state(
            timestamp=candle["timestamp_readable"],
            close_price=candle["close"],
            state=self.ema_state,
        )

        logger.info(
            f"Close={result['close']} "
            f"EMA9={result['ema9']} "
            f"EMA21={result['ema21']} "
            f"Signal={result['signal']}"
        )

        # --------------------------------------
        # Save Crossovers Only
        # --------------------------------------
        if result["signal"] != "NONE":

            signal_record = {
                "timestamp": result["timestamp"],
                "signal": result["signal"],
                "close": result["close"],
                "ema9": result["ema9"],
                "ema21": result["ema21"],
            }

            logger.info("=" * 60)

            logger.info(f"{result['signal']} " f"CROSS DETECTED")

            logger.info(signal_record)

            logger.info("=" * 60)

            # Latest first
            self.signals.insert(0, signal_record)

            self.save_signals()

        return result

    # ----------------------------------------------------------
    # Get Current EMA State
    # ----------------------------------------------------------
    def get_state(self):

        return self.ema_state
