import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()
# ==========================================
# Upstox API Configuration
# ==========================================

ACCESS_TOKEN = os.getenv("ACCESS_TOKEN")
# ==========================================
# Instrument Configuration
# ==========================================

# Example:
# NSE_EQ|INE002A01018 = Reliance
# NSE_INDEX|Nifty 50 = Nifty Index

INSTRUMENT_KEY = "NSE_INDEX|Nifty 50"

# ==========================================
# Historical Data
# ==========================================

INTERVAL = "1minute"
HISTORICAL_DAYS = 7

# ==========================================
# EMA Settings
# ==========================================

FAST_EMA = 9
SLOW_EMA = 21

# ==========================================
# Data Files
# ==========================================

BASE_DIR = Path(__file__).resolve().parent

EMA_DATA_FILE = BASE_DIR / "data" / "ema_data.json"
EMA_SIGNAL_FILE = BASE_DIR / "data" / "ema_cross_signals.json"
LIVE_CROSS_FILE = BASE_DIR / "data" / "live_ema_crosses.json"

# ==========================================
# WebSocket
# ==========================================

AUTO_RECONNECT = True
LOG_LEVEL = "INFO"