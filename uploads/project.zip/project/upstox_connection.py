import upstox_client

from config import ACCESS_TOKEN


configuration = upstox_client.Configuration()
configuration.access_token = ACCESS_TOKEN

api_client = upstox_client.ApiClient(configuration)

API_VERSION = "2.0"

history_api = upstox_client.HistoryApi(api_client)
market_quote_api = upstox_client.MarketQuoteApi(api_client)
order_api = upstox_client.OrderApi(api_client)
portfolio_api = upstox_client.PortfolioApi(api_client)
user_api = upstox_client.UserApi(api_client)