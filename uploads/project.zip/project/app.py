from flask import Flask, render_template, request, jsonify
from scraper import (
    scrape_listing_page,
    scrape_video_page,
    scrape_search_page,
    scrape_tag_page,
    fetch_autocomplete
)

app = Flask(__name__)

@app.route("/")
def home():
    page = request.args.get("page", 1, type=int)
    data = scrape_listing_page(page)
    return render_template("home.html", cards=data["cards"], page=page)

@app.route("/watch/<video_id>")
def watch(video_id):
    video = scrape_video_page(video_id)
    return render_template("watch.html", video=video)

@app.route("/search/<query>")
def search(query):
    data = scrape_search_page(query)
    return render_template("search.html", query=query, cards=data["cards"])

@app.route("/tag/<tag>")
def tag_page(tag):
    data = scrape_tag_page(tag)
    return render_template("tag.html", tag=tag, cards=data["cards"])

@app.route("/autocomplete")
def autocomplete():
    q = request.args.get("q", "")
    results = fetch_autocomplete(q)
    return jsonify(results)

if __name__ == "__main__":
    app.run(debug=True)
