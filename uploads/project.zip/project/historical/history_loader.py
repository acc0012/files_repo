# historical/history_loader.py

import json
import logging
from datetime import datetime, timedelta

from upstox_connection import history_api, API_VERSION

logger = logging.getLogger(__name__)


# ----------------------------------------------------------
# Timestamp Formatter
# ----------------------------------------------------------
def format_timestamp(timestamp_str):

    dt = datetime.fromisoformat(timestamp_str)

    return dt.strftime("%d-%b-%Y %I:%M %p")


# ----------------------------------------------------------
# EMA Calculator
# ----------------------------------------------------------
def calculate_ema(prices, period):

    if not prices:
        return []

    multiplier = 2 / (period + 1)

    ema_values = []

    ema = prices[0]
    ema_values.append(ema)

    for price in prices[1:]:

        ema = ((price - ema) * multiplier) + ema

        ema_values.append(ema)

    return ema_values


# ----------------------------------------------------------
# Load Historical Data
# ----------------------------------------------------------
def load_history(instrument_key="NSE_INDEX|Nifty 50", interval="1minute", days=3):

    today = datetime.now().date()

    from_date = today - timedelta(days=days - 1)

    logger.info(f"Fetching history " f"{from_date} -> {today}")

    response = history_api.get_historical_candle_data1(
        instrument_key,
        interval,
        today.strftime("%Y-%m-%d"),
        from_date.strftime("%Y-%m-%d"),
        API_VERSION,
    )

    response_data = response.to_dict()

    candles = response_data.get("data", {}).get("candles", [])

    logger.info(f"Total candles fetched: {len(candles)}")

    # ------------------------------------------------------
    # Save Raw Historical Data
    # ------------------------------------------------------
    history_output = {
        "instrument_key": instrument_key,
        "interval": interval,
        "from_date": from_date.strftime("%Y-%m-%d"),
        "to_date": today.strftime("%Y-%m-%d"),
        "days_requested": days,
        "total_candles": len(candles),
        "candles": candles,
    }

    with open("nifty_history.json", "w", encoding="utf-8") as f:

        json.dump(history_output, f, indent=4)

    # ------------------------------------------------------
    # EMA calculation requires oldest -> newest
    # ------------------------------------------------------
    candles = list(reversed(candles))

    closes = []
    timestamps_raw = []
    timestamps = []

    for candle in candles:

        timestamps_raw.append(candle[0])

        timestamps.append(format_timestamp(candle[0]))

        closes.append(float(candle[4]))

    ema9 = calculate_ema(closes, 9)

    ema21 = calculate_ema(closes, 21)

    signals = []
    ema_data = []

    for i in range(len(closes)):

        signal = "NONE"

        if i > 0:

            bullish_cross = ema9[i - 1] <= ema21[i - 1] and ema9[i] > ema21[i]

            bearish_cross = ema9[i - 1] >= ema21[i - 1] and ema9[i] < ema21[i]

            if bullish_cross:
                signal = "BULLISH"

            elif bearish_cross:
                signal = "BEARISH"

            if signal != "NONE":

                signals.append(
                    {
                        "timestamp_raw": timestamps_raw[i],
                        "timestamp": timestamps[i],
                        "signal": signal,
                        "close": round(closes[i], 2),
                        "ema9": round(ema9[i], 2),
                        "ema21": round(ema21[i], 2),
                    }
                )

        ema_data.append(
            {
                "timestamp_raw": timestamps_raw[i],
                "timestamp": timestamps[i],
                "close": round(closes[i], 2),
                "ema9": round(ema9[i], 2),
                "ema21": round(ema21[i], 2),
                "signal": signal,
            }
        )

    # ------------------------------------------------------
    # Latest first
    # ------------------------------------------------------
    ema_data.reverse()
    signals.reverse()

    # ------------------------------------------------------
    # Save EMA Data
    # ------------------------------------------------------
    with open("ema_data.json", "w", encoding="utf-8") as f:

        json.dump(
            {
                "instrument_key": instrument_key,
                "interval": interval,
                "total_records": len(ema_data),
                "data": ema_data,
            },
            f,
            indent=4,
        )

    # ------------------------------------------------------
    # Save Historical Signals
    # ------------------------------------------------------
    with open("ema_cross_signals.json", "w", encoding="utf-8") as f:

        json.dump(
            {
                "instrument_key": instrument_key,
                "interval": interval,
                "total_signals": len(signals),
                "signals": signals,
            },
            f,
            indent=4,
        )

    latest_ema_state = {
        "instrument_key": instrument_key,
        "last_timestamp_raw": timestamps_raw[-1],
        "last_timestamp": timestamps[-1],
        "last_close": closes[-1],
        "ema9": round(ema9[-1], 2),
        "ema21": round(ema21[-1], 2),
    }

    with open("ema_state.json", "w", encoding="utf-8") as f:

        json.dump(latest_ema_state, f, indent=4)

    logger.info(f"Latest EMA State: " f"{latest_ema_state}")

    return latest_ema_state
