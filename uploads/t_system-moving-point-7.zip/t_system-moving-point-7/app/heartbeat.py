import asyncio

from app.logger import logger
from app.config import HEARTBEAT_INTERVAL

async def start_heartbeat(client):

    while True:

        # Wait 5 minutes
        await asyncio.sleep(HEARTBEAT_INTERVAL)

        logger.info("======================================")
        logger.info(f"{HEARTBEAT_INTERVAL} SECONDS HEARTBEAT")

        await client.heartbeat()

        logger.info("======================================")