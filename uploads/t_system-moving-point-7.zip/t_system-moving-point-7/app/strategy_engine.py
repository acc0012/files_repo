def process_tick(state, data):

    # ======================================================
    # EXTRACT CANDLE DATA
    # ======================================================
    ltp = float(data.get("LTP", 0))
    open_price = float(data.get("open", ltp))
    high = float(data.get("high", ltp))
    low = float(data.get("low", ltp))
    close_price = float(data.get("close", ltp))

    # ======================================================
    # UPDATE RANGE (OPENING RANGE LOGIC)
    # ======================================================
    state["rangeHigh"] = max(state["rangeHigh"], high)
    state["rangeLow"] = min(state["rangeLow"], low)

    # ======================================================
    # CALCULATE AVERAGE
    # ======================================================
    avg = (state["rangeHigh"] + state["rangeLow"]) / 2
    state["rangeAvg"] = avg

    # ======================================================
    # CALCULATE ENTRY LEVELS
    # ======================================================
    high_diff = abs(state["rangeHigh"] - avg)
    low_diff = abs(avg - state["rangeLow"])

    ce_entry = state["rangeHigh"] + high_diff
    pe_entry = state["rangeLow"] - low_diff

    # ======================================================
    # CANDLE COLOR
    # ======================================================
    is_green = close_price > open_price
    is_red = close_price < open_price

    candle_color = "GREEN" if is_green else "RED"

    # ======================================================
    # SIGNAL CONDITIONS (PINE LOGIC)
    # ======================================================
    signal = None
    signal_type = None

    if not state["signalSent"]:

        # ✅ VALID BUY CE
        if open_price < avg and is_green:
            signal = "BUY_CE"
            signal_type = "VALID"
            state["signalSent"] = True

        # ✅ VALID BUY PE
        elif open_price > avg and is_red:
            signal = "BUY_PE"
            signal_type = "VALID"
            state["signalSent"] = True

        # ❌ INVALID BELOW AVG
        elif open_price < avg and is_red:
            signal = "INVALID_BELOW"
            signal_type = "NON_VALID"
            state["signalSent"] = True

        # ❌ INVALID ABOVE AVG
        elif open_price > avg and is_green:
            signal = "INVALID_ABOVE"
            signal_type = "NON_VALID"
            state["signalSent"] = True

    # ======================================================
    # CREATE ALERT JSON (LIKE TRADINGVIEW)
    # ======================================================
    alert = None

    if signal == "BUY_CE":
        alert = {
            "TYPE": "BUY_CE",
            "STATUS": "VALID",
            "TIME": data.get("LTT"),
            "AVG": avg,
            "OPEN": open_price,
            "CLOSE": close_price,
            "CANDLE_COLOR": candle_color,
        }

    elif signal == "BUY_PE":
        alert = {
            "TYPE": "BUY_PE",
            "STATUS": "VALID",
            "TIME": data.get("LTT"),
            "AVG": avg,
            "OPEN": open_price,
            "CLOSE": close_price,
            "CANDLE_COLOR": candle_color,
        }

    elif signal == "INVALID_BELOW":
        alert = {
            "TYPE": "NON_VALID",
            "REASON": "OPEN_BELOW_AVG_RED",
            "TIME": data.get("LTT"),
            "AVG": avg,
            "OPEN": open_price,
            "CLOSE": close_price,
            "CANDLE_COLOR": candle_color,
        }

    elif signal == "INVALID_ABOVE":
        alert = {
            "TYPE": "NON_VALID",
            "REASON": "OPEN_ABOVE_AVG_GREEN",
            "TIME": data.get("LTT"),
            "AVG": avg,
            "OPEN": open_price,
            "CLOSE": close_price,
            "CANDLE_COLOR": candle_color,
        }

    # ======================================================
    # FINAL OUTPUT
    # ======================================================
    return {
        "ltp": ltp,
        "high": state["rangeHigh"],
        "low": state["rangeLow"],
        "avg": avg,
        "ce_entry": ce_entry,
        "pe_entry": pe_entry,
        "signal": signal,
        "signal_type": signal_type,
        "alert": alert,
        "time": data.get("LTT"),
    }
