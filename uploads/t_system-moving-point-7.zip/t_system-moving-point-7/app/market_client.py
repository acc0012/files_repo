import asyncio
import json

import httpx
import websockets
import certifi

from app.logger import logger
from app.config import BASE_URL, INSTRUMENTS
from app.ohlc_service import fetch_ohlc
from app.mongo_service import get_collection, save_tick
from app.strategy_engine import process_tick
from app.candle_engine import get_last_closed_candle


class MarketClient:

    def __init__(self):
        self.latest_ticks = {}
        self.instruments = {}
        self.state = {}

    # =========================================================
    # LOAD INSTRUMENTS (SSL FIX + DEBUG + FALLBACK)
    # =========================================================
    async def load_default_instruments(self):

        try:
            logger.info("🔄 FETCHING INSTRUMENTS FROM API...")

            async with httpx.AsyncClient(
                timeout=20,
                verify=certifi.where()   # ✅ SSL FIX
            ) as client:
                response = await client.get(BASE_URL)

            logger.info(f"✅ STATUS: {response.status_code}")

            response.raise_for_status()

            data = response.json()
            logger.info(f"📊 API RESPONSE: {data}")

            default_instruments = data.get("default_instruments")

            self.instruments = {}

            # ✅ FALLBACK if API fails
            if not default_instruments:
                logger.warning("⚠️ API FAILED → USING LOCAL CONFIG")

                for name, info in INSTRUMENTS.items():
                    self.instruments[name] = {
                        "exchange_segment": 0,
                        "security_id": str(info["security_id"]),
                        "mode": 17,
                    }

                logger.info(f"✅ LOCAL INSTRUMENTS: {self.instruments}")
                return

            # ✅ API SUCCESS
            for instrument in default_instruments:
                exchange_segment = instrument[0]
                security_id = str(instrument[1])
                mode = instrument[2]

                self.instruments[f"SECURITY_{security_id}"] = {
                    "exchange_segment": exchange_segment,
                    "security_id": security_id,
                    "mode": mode,
                }

            logger.info(f"✅ MARKET FEED INITIALIZED: {self.instruments}")

        except Exception as e:
            logger.error(f"❌ INSTRUMENT LOAD FAILED: {str(e)}")

            # ✅ HARD FALLBACK
            self.instruments = {
                "NIFTY": {
                    "exchange_segment": 0,
                    "security_id": "13",
                    "mode": 17,
                }
            }

            logger.warning(f"⚠️ USING FALLBACK: {self.instruments}")

    # =========================================================
    # CONNECT WEBSOCKET
    # =========================================================
    async def connect_instrument(self, name, security_id):

        url = f"wss://marketfeed101.up.railway.app/ws/market/{security_id}/"

        while True:
            try:
                logger.info(f"🔌 CONNECTING {name} → {url}")

                async with websockets.connect(
                    url,
                    ping_interval=20,
                    ping_timeout=20,
                ) as ws:

                    logger.info(f"✅ {name} CONNECTED")

                    first_tick = True

                    async for message in ws:
                        try:
                            data = json.loads(message)

                            # ✅ store tick
                            self.latest_ticks[name] = data

                            state = self.state.get(name)
                            if not state:
                                continue

                            # ✅ Candle build
                            candle = get_last_closed_candle(name, data)

                            if not candle:
                                logger.debug(f"{name} ⏳ Candle forming...")
                                continue

                            logger.info(f"{name} ✅ Candle closed: {candle}")

                            candle_data = {
                                "LTP": candle["close"],
                                "open": candle["open"],
                                "high": candle["high"],
                                "low": candle["low"],
                                "close": candle["close"],
                                "LTT": str(candle["time"]),
                            }

                            result = process_tick(state, candle_data)

                            # ✅ Mongo save
                            collection = get_collection(name)
                            save_tick(collection, {
                                "instrument": name,
                                **result
                            })

                            logger.info(f"{name} 📊 SIGNAL: {result.get('signal')}")

                            if first_tick:
                                logger.info(
                                    f"{name} INITIAL LTP={data.get('LTP')} TIME={data.get('LTT')}"
                                )
                                first_tick = False

                        except Exception as e:
                            logger.error(f"{name} PARSE ERROR: {str(e)}")

            except Exception as e:
                logger.error(f"{name} DISCONNECTED: {str(e)}")

                await asyncio.sleep(5)

    # =========================================================
    # START FEEDS
    # =========================================================
    async def start_feeds(self):

        logger.info("🚀 STARTING SYSTEM...")

        await self.load_default_instruments()

        if not self.instruments:
            logger.error("❌ NO INSTRUMENTS FOUND — EXITING")
            return

        logger.info(f"✅ LOADED INSTRUMENTS: {self.instruments}")

        logger.info("======================================")
        logger.info("INITIALIZING OHLC + STATE")
        logger.info("======================================")

        # ✅ INIT STATE FROM OHLC
        for name, instrument in self.instruments.items():

            security_id = instrument["security_id"]

            logger.info(f"📡 FETCHING OHLC → {name}")

            ohlc = await fetch_ohlc(security_id)

            if ohlc:
                self.state[name] = {
                    "rangeHigh": float(ohlc["high"]),
                    "rangeLow": float(ohlc["low"]),
                    "rangeAvg": None,
                    "signalSent": False,
                }

                logger.info(
                    f"✅ {name} OHLC → HIGH={ohlc['high']} LOW={ohlc['low']}"
                )
            else:
                logger.error(f"❌ {name} OHLC FAILED")

        # ✅ START WS TASKS
        tasks = [
            asyncio.create_task(
                self.connect_instrument(name, inst["security_id"])
            )
            for name, inst in self.instruments.items()
        ]

        await asyncio.gather(*tasks)

    # =========================================================
    # HEARTBEAT
    # =========================================================
    async def heartbeat(self):

        logger.info("======================================")
        logger.info("HEARTBEAT STATUS")

        for name in self.instruments.keys():

            tick = self.latest_ticks.get(name)
            state = self.state.get(name)

            if not tick:
                logger.info(f"{name} → NO DATA")
                continue

            logger.info(
                f"{name} | LTP={tick.get('LTP')} | TIME={tick.get('LTT')} | "
                f"HIGH={state.get('rangeHigh') if state else None} | "
                f"LOW={state.get('rangeLow') if state else None} | "
                f"AVG={state.get('rangeAvg') if state else None}"
            )

        logger.info("======================================")
        