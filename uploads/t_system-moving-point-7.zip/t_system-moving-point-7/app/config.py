import os
from dotenv import load_dotenv

load_dotenv()

BASE_URL = "https://marketfeed101.up.railway.app"

OHLC_URL = f"{BASE_URL}/dhan/ohlc/"

MONGO_URI = os.getenv("MONGO_URI")
DB_NAME = os.getenv("DB_NAME", "market_db")

INSTRUMENTS = {
    "SENSEX": {"security_id": 51},
    "NIFTY": {"security_id": 13},
    "INDIA_VIX": {"security_id": 21},
}

HEARTBEAT_INTERVAL = 30
