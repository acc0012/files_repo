from contextlib import asynccontextmanager
import asyncio

from fastapi import FastAPI

from app.market_client import MarketClient
from app.heartbeat import start_heartbeat

market_client = MarketClient()


# =========================================================
# LIFESPAN (START SERVICES)
# =========================================================
@asynccontextmanager
async def lifespan(app: FastAPI):

    # ✅ Start websocket feeds + strategy engine
    feed_task = asyncio.create_task(market_client.start_feeds())

    # ✅ Start heartbeat logger
    heartbeat_task = asyncio.create_task(start_heartbeat(market_client))

    try:
        yield

    finally:
        feed_task.cancel()
        heartbeat_task.cancel()


# =========================================================
# FASTAPI APP
# =========================================================
app = FastAPI(
    title="Market Level Engine (Pine Backend)",
    lifespan=lifespan
)


# =========================================================
# ROOT
# =========================================================
@app.get("/")
async def root():

    return {
        "status": "running",
        "service": "market-level-engine",
        "mode": "PINE_ENGINE",
        "connected_instruments": list(market_client.instruments.keys()),
    }


# =========================================================
# HEALTH
# =========================================================
@app.get("/health")
async def health():

    return {
        "healthy": True,
        "active_connections": len(market_client.latest_ticks),
        "state_initialized": len(market_client.state),
    }


# =========================================================
# RAW LIVE TICKS
# =========================================================
@app.get("/ticks")
async def ticks():

    return market_client.latest_ticks


# =========================================================
# ✅ STRATEGY STATE (OPENING RANGE VALUES)
# =========================================================
@app.get("/state")
async def state():

    return market_client.state


# =========================================================
# ✅ LEVELS (CLEAN VIEW)
# =========================================================
@app.get("/levels")
async def levels():

    output = {}

    for name, state in market_client.state.items():

        output[name] = {
            "HIGH": state.get("rangeHigh"),
            "LOW": state.get("rangeLow"),
            "AVG": state.get("rangeAvg"),
        }

    return output


# =========================================================
# ✅ SIGNALS (MOST IMPORTANT API)
# =========================================================
@app.get("/signals")
async def signals():

    output = {}

    for name, tick in market_client.latest_ticks.items():

        state = market_client.state.get(name)

        if not state or state.get("rangeAvg") is None:
            continue

        avg = state["rangeAvg"]

        open_price = float(tick.get("open", 0))
        close_price = float(tick.get("close", 0))

        is_green = close_price > open_price
        is_red = close_price < open_price

        signal = None

        if open_price < avg and is_green:
            signal = "BUY_CE"

        elif open_price > avg and is_red:
            signal = "BUY_PE"

        elif open_price < avg and is_red:
            signal = "INVALID_BELOW"

        elif open_price > avg and is_green:
            signal = "INVALID_ABOVE"

        output[name] = {
            "signal": signal,
            "LTP": tick.get("LTP"),
            "TIME": tick.get("LTT"),
            "AVG": avg,
        }

    return output


# =========================================================
# ✅ FULL ENGINE OUTPUT (LIKE TRADINGVIEW)
# =========================================================
@app.get("/engine")
async def engine():

    result = {}

    for name, tick in market_client.latest_ticks.items():

        state = market_client.state.get(name)

        if not state or state.get("rangeAvg") is None:
            continue

        high = state["rangeHigh"]
        low = state["rangeLow"]
        avg = state["rangeAvg"]

        high_diff = abs(high - avg)
        low_diff = abs(avg - low)

        ce_entry = high + high_diff
        pe_entry = low - low_diff

        result[name] = {
            "HIGH": high,
            "LOW": low,
            "AVG": avg,
            "CE_ENTRY": ce_entry,
            "PE_ENTRY": pe_entry,
            "LTP": tick.get("LTP"),
            "TIME": tick.get("LTT"),
        }

    return result