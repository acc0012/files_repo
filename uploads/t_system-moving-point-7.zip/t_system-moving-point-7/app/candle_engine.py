from datetime import datetime

candles = {}

def update_candle(instrument, data):

    now = datetime.now().replace(second=0, microsecond=0)

    ltp = float(data.get("LTP", 0))

    if instrument not in candles:
        candles[instrument] = {}

    current = candles[instrument].get("current")

    # NEW CANDLE
    if not current or current["time"] != now:
        candles[instrument]["current"] = {
            "time": now,
            "open": ltp,
            "high": ltp,
            "low": ltp,
            "close": ltp
        }
        return None  # 아직 candle complete 안됨

    # UPDATE CURRENT
    current["high"] = max(current["high"], ltp)
    current["low"] = min(current["low"], ltp)
    current["close"] = ltp

    return None


def get_last_closed_candle(instrument, data):

    now = datetime.now().replace(second=0, microsecond=0)

    ltp = float(data.get("LTP", 0))

    if instrument not in candles:
        candles[instrument] = {}

    current = candles[instrument].get("current")

    # New minute started
    if current and current["time"] != now:

        closed = current.copy()

        # start new candle
        candles[instrument]["current"] = {
            "time": now,
            "open": ltp,
            "high": ltp,
            "low": ltp,
            "close": ltp
        }

        return closed

    # continue building candle
    if current:
        current["high"] = max(current["high"], ltp)
        current["low"] = min(current["low"], ltp)
        current["close"] = ltp

    else:
        candles[instrument]["current"] = {
            "time": now,
            "open": ltp,
            "high": ltp,
            "low": ltp,
            "close": ltp
        }

    return None
