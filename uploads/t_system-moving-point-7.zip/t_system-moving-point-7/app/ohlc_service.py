import httpx
import certifi

from app.config import OHLC_URL
from app.logger import logger


async def fetch_ohlc(security_id):

    params = {
        "security_id": security_id,
        "exchange_segment": "IDX_I"
    }

    try:
        logger.info(f"📡 FETCHING OHLC FOR {security_id}")

        async with httpx.AsyncClient(
            timeout=10,
            verify=certifi.where()   # ✅ proper SSL fix
        ) as client:

            response = await client.get(OHLC_URL, params=params)

        logger.info(f"✅ OHLC STATUS: {response.status_code}")
        logger.info(f"📊 RAW OHLC RESPONSE: {response.text}")

        response.raise_for_status()

        data = response.json()

        # ✅ Safe parsing
        ohlc = data.get("data", {}) \
                   .get("data", {}) \
                   .get("data", {}) \
                   .get("IDX_I", {}) \
                   .get(str(security_id), {}) \
                   .get("ohlc", {})

        if not ohlc:
            logger.error(f"❌ OHLC NOT FOUND FOR {security_id}")
            return None

        result = {
            "open": float(ohlc.get("open", 0)),
            "high": float(ohlc.get("high", 0)),
            "low": float(ohlc.get("low", 0)),
            "close": float(ohlc.get("close", 0)),
        }

        logger.info(f"✅ PARSED OHLC → {result}")

        return result

    except Exception as e:

        logger.error(f"❌ OHLC FETCH ERROR {security_id}: {str(e)}")
        return None
