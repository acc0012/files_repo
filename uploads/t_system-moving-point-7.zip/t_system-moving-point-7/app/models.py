from pydantic import BaseModel


class FeedStatus(BaseModel):
    status: str
    feed_initialized: bool
    subscribed_security_ids: int