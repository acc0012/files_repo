@echo off
cls

echo ======================================================
echo T_SYSTEM ALERT ENGINE STARTING
echo DATE : %date%
echo TIME : %time%
echo ======================================================

call myenv\Scripts\activate

uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload

pause