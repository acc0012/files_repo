import os

from dotenv import load_dotenv

load_dotenv()

# ==========================================================
# APPLICATION
# ==========================================================

APP_NAME = os.getenv(
    "APP_NAME",
    "T_SYSTEM_ALERT_ENGINE"
)

LOG_LEVEL = os.getenv(
    "LOG_LEVEL",
    "INFO"
)

# ==========================================================
# MONGODB
# ==========================================================

MONGO_URL = os.getenv(
    "MONGO_URL"
)

MONGO_DB = os.getenv(
    "MONGO_DB"
)

# ==========================================================
# COLLECTIONS
# ==========================================================

WEBHOOK_COLLECTION = os.getenv(
    "WEBHOOK_COLLECTION"
)

OPENING_RANGE_COLLECTION = os.getenv(
    "OPENING_RANGE_COLLECTION"
)

INDEX_SIGNAL_COLLECTION = os.getenv(
    "INDEX_SIGNAL_COLLECTION"
)

OPTION_SIGNAL_COLLECTION = os.getenv(
    "OPTION_SIGNAL_COLLECTION"
)

UPSTOX_TOKEN_COLLECTION = os.getenv(
    "UPSTOX_TOKEN_COLLECTION",
    "upstox_tokens"
)

# ==========================================================
# UPSTOX
# ==========================================================

# Bootstrap token from ENV.
# After first successful validation,
# application will primarily use token
# stored in MongoDB.

UPSTOX_ACCESS_TOKEN = os.getenv(
    "UPSTOX_ACCESS_TOKEN"
)

UPSTOX_API_SECRET = os.getenv(
    "UPSTOX_API_SECRET"
)

UPSTOX_API_KEY = os.getenv(
    "UPSTOX_API_KEY"
)

# ==========================================================
# UPSTOX API URLS
# ==========================================================

UPSTOX_FUNDS_API = (
    "https://api.upstox.com/v2/user/get-funds-and-margin"
)

# ==========================================================
# TOKEN SETTINGS
# ==========================================================

UPSTOX_TOKEN_STATUS_ACTIVE = "ACTIVE"

UPSTOX_TOKEN_STATUS_EXPIRED = "EXPIRED"

UPSTOX_TOKEN_STATUS_INACTIVE = "INACTIVE"

UPSTOX_TOKEN_STATUS_MISSING = "MISSING"

MONITOR_INTERVAL_MINUTES = 30
