from pymongo import MongoClient

from app.config import (
    MONGO_URL,
    MONGO_DB,
    WEBHOOK_COLLECTION,
    OPENING_RANGE_COLLECTION,
    INDEX_SIGNAL_COLLECTION,
    OPTION_SIGNAL_COLLECTION,
    UPSTOX_TOKEN_COLLECTION,
)

from app.logger import get_logger

logger = get_logger()

try:

    logger.info("Connecting to MongoDB")

    client = MongoClient(
        MONGO_URL,
        serverSelectionTimeoutMS=5000,
    )

    # ==================================================
    # CONNECTION TEST
    # ==================================================

    client.admin.command("ping")

    db = client[MONGO_DB]

    logger.info(f"MongoDB connected successfully " f"database={MONGO_DB}")

    # ==================================================
    # WEBHOOK COLLECTION
    # ==================================================

    webhook_collection = db[WEBHOOK_COLLECTION]

    # ==================================================
    # OPENING RANGE COLLECTION
    # ==================================================

    opening_range_collection = db[OPENING_RANGE_COLLECTION]

    # ==================================================
    # INDEX SIGNAL COLLECTION
    # ==================================================

    index_signal_collection = db[INDEX_SIGNAL_COLLECTION]

    # ==================================================
    # OPTION SIGNAL COLLECTION
    # ==================================================

    option_signal_collection = db[OPTION_SIGNAL_COLLECTION]

    # ==================================================
    # UPSTOX TOKEN COLLECTION
    # ==================================================

    upstox_token_collection = db[UPSTOX_TOKEN_COLLECTION]

    # ==================================================
    # INDEXES
    # ==================================================

    try:

        webhook_collection.create_index(
            "trace_id",
            unique=True,
        )

    except Exception:

        pass

    try:

        opening_range_collection.create_index("created_at")

    except Exception:

        pass

    try:

        index_signal_collection.create_index("created_at")

    except Exception:

        pass

    try:

        option_signal_collection.create_index("created_at")

    except Exception:

        pass

    try:

        upstox_token_collection.create_index(
            [
                ("status", 1),
                ("validated_at", -1),
            ]
        )

    except Exception:

        pass

    logger.info("MongoDB collections initialized successfully")

except Exception:

    logger.exception(f"MongoDB connection failed " f"url={MONGO_URL}")

    raise
