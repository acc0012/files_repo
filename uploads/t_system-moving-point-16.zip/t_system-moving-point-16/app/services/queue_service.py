from queue import Queue

WEBHOOK_QUEUE = Queue()