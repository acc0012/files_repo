import threading

from app.logger import get_logger

from app.services.queue_service import WEBHOOK_QUEUE

from app.services.mongo_service import webhook_collection

from app.services.opening_range_service import process_opening_range

from app.services.signal_service import process_signal

logger = get_logger()


def process_worker():

    logger.info("Webhook worker started")

    while True:

        trace_id = None

        try:

            item = WEBHOOK_QUEUE.get()

            trace_id = item["trace_id"]

            payload = item["payload"]

            logger.info(f"Worker processing " f"trace_id={trace_id}")

            if payload.get("TYPE") == "OPENING_RANGE":

                logger.info(f"Opening Range detected " f"trace_id={trace_id}")

                process_opening_range(trace_id, payload)

            else:

                logger.info(
                    f"Signal detected "
                    f"trace_id={trace_id} "
                    f"type={payload.get('TYPE')}"
                )

                process_signal(trace_id, payload)

            webhook_collection.update_one(
                {"trace_id": trace_id}, {"$set": {"processed": True}}
            )

            logger.info(f"Worker completed " f"trace_id={trace_id}")

        except Exception as ex:

            logger.exception(f"Worker processing failed " f"trace_id={trace_id}")

            try:

                if trace_id:

                    webhook_collection.update_one(
                        {"trace_id": trace_id},
                        {"$set": {"processed": False, "error": str(ex)}},
                    )

                    logger.warning(f"Webhook marked failed " f"trace_id={trace_id}")

            except Exception:

                logger.exception(
                    f"Failed updating " f"error status " f"trace_id={trace_id}"
                )

        finally:

            try:

                WEBHOOK_QUEUE.task_done()

            except Exception:

                pass


def start_worker():

    try:

        logger.info("Starting webhook worker thread")

        thread = threading.Thread(
            target=process_worker, daemon=True, name="WebhookWorker"
        )

        thread.start()

        logger.info(f"Worker thread started " f"name={thread.name}")

    except Exception:

        logger.exception("Failed to start worker thread")

        raise
