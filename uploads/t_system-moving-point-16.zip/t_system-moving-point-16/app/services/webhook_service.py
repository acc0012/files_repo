import uuid

from app.logger import get_logger

logger = get_logger()


def generate_trace_id() -> str:

    try:

        trace_id = str(uuid.uuid4())

        logger.info(f"Generated trace_id={trace_id}")

        return trace_id

    except Exception:

        logger.exception("Failed to generate trace ID")

        raise
