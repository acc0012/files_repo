from datetime import datetime
from zoneinfo import ZoneInfo

# ==========================================================
# TIMEZONE
# ==========================================================

IST = ZoneInfo("Asia/Kolkata")

# ==========================================================
# IST NOW
# ==========================================================


def ist_now():
    """
    Returns current India Standard Time
    as timezone-aware datetime.
    """

    return datetime.now(IST)


# ==========================================================
# IST STRING
# ==========================================================


def ist_now_str(fmt="%d-%m-%Y %H:%M:%S"):
    """
    Returns formatted IST timestamp.
    """

    return ist_now().strftime(fmt)
