// ======================================================
// GLOBALS
// ======================================================

const accessTokenInput = document.getElementById("accessToken");

const validateBtn = document.getElementById("validateBtn");

const saveBtn = document.getElementById("saveBtn");

const resultContainer = document.getElementById("resultContainer");

// ======================================================
// INIT
// ======================================================

document.addEventListener("DOMContentLoaded", async () => {
  await loadStatus();

  bindEvents();
});

// ======================================================
// EVENTS
// ======================================================

function bindEvents() {
  validateBtn.addEventListener("click", validateToken);

  saveBtn.addEventListener("click", saveToken);
}

// ======================================================
// LOAD STATUS
// ======================================================

async function loadStatus() {
  try {
    const response = await fetch("/api/login/status");

    const result = await response.json();

    if (!result.success) {
      return;
    }

    const data = result.data;

    updateStatusUI(data);
  } catch (error) {
    console.error("Status Load Error", error);
  }
}

// ======================================================
// VALIDATE TOKEN
// ======================================================

async function validateToken() {
  try {
    const accessToken = accessTokenInput.value.trim();

    if (!accessToken) {
      showError("Please enter an access token.");

      return;
    }

    setButtonsDisabled(true);

    showInfo("Validating token...");

    const response = await fetch("/api/login/validate", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        access_token: accessToken,
      }),
    });

    const result = await response.json();

    if (!response.ok || !result.success) {
      showError(result.message || "Token validation failed.");

      return;
    }

    showSuccess(
      `Token Valid. Available Margin: ₹${formatAmount(result.balance)}`,
    );

    document.getElementById("tokenBalance").innerText =
      `₹ ${formatAmount(result.balance)}`;
  } catch (error) {
    console.error("Validate Token Error", error);

    showError("Validation failed.");
  } finally {
    setButtonsDisabled(false);
  }
}

// ======================================================
// SAVE TOKEN
// ======================================================

async function saveToken() {
  try {
    const accessToken = accessTokenInput.value.trim();

    if (!accessToken) {
      showError("Please enter an access token.");

      return;
    }

    setButtonsDisabled(true);

    showInfo("Validating and saving token...");

    const response = await fetch("/api/login/token", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        access_token: accessToken,
      }),
    });

    const result = await response.json();

    if (!response.ok || !result.success) {
      showError(result.message || "Failed to save token.");

      return;
    }

    showSuccess(
      `Token Saved Successfully. Available Margin: ₹${formatAmount(result.balance)}`,
    );

    await loadStatus();
  } catch (error) {
    console.error("Save Token Error", error);

    showError("Failed to save token.");
  } finally {
    setButtonsDisabled(false);
  }
}

// ======================================================
// UPDATE STATUS UI
// ======================================================

function updateStatusUI(data) {
  const statusContainer = document.getElementById("statusContainer");

  const tokenStatus = document.getElementById("tokenStatus");

  const tokenBalance = document.getElementById("tokenBalance");

  const availableBalance = document.getElementById("availableBalance");

  if (data.token_valid) {
    statusContainer.innerHTML = `
      <div class="alert alert-success">
        <strong>Status:</strong> ACTIVE
      </div>
    `;

    tokenStatus.innerText = "ACTIVE";
  } else {
    statusContainer.innerHTML = `
      <div class="alert alert-danger">
        <strong>Status:</strong>
        TOKEN EXPIRED / NOT CONFIGURED
      </div>
    `;

    tokenStatus.innerText = "EXPIRED";
  }

  const balance = formatAmount(data.balance || 0);

  tokenBalance.innerText = `₹ ${balance}`;

  availableBalance.innerText = `₹ ${balance}`;
}

// ======================================================
// UI HELPERS
// ======================================================

function showSuccess(message) {
  resultContainer.innerHTML = `
    <div class="alert alert-success">
      ${message}
    </div>
  `;
}

function showError(message) {
  resultContainer.innerHTML = `
    <div class="alert alert-danger">
      ${message}
    </div>
  `;
}

function showInfo(message) {
  resultContainer.innerHTML = `
    <div class="alert alert-info">
      ${message}
    </div>
  `;
}

// ======================================================
// BUTTON CONTROL
// ======================================================

function setButtonsDisabled(disabled) {
  validateBtn.disabled = disabled;

  saveBtn.disabled = disabled;
}

// ======================================================
// FORMATTERS
// ======================================================

function formatAmount(value) {
  try {
    return Number(value || 0).toLocaleString("en-IN", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  } catch {
    return value;
  }
}
