from fastapi import APIRouter
from fastapi import Request

from app.utils.datetime_helper import (
    ist_now,
)

from app.services.queue_service import (
    WEBHOOK_QUEUE,
)

from app.services.webhook_service import (
    generate_trace_id,
)

from app.services.mongo_service import (
    webhook_collection,
)

router = APIRouter()

# ==========================================================
# WEBHOOK
# ==========================================================


@router.post("/webhook")
async def receive_webhook(
    request: Request,
):

    payload = await request.json()

    trace_id = generate_trace_id()

    webhook_collection.insert_one(
        {
            "trace_id": trace_id,
            "received_at": ist_now(),
            "processed": False,
            "payload": payload,
        }
    )

    WEBHOOK_QUEUE.put(
        {
            "trace_id": trace_id,
            "payload": payload,
        }
    )

    return {
        "success": True,
        "trace_id": trace_id,
    }
