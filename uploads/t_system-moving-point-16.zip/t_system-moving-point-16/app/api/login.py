from fastapi import APIRouter
from fastapi import Request

from fastapi.responses import HTMLResponse
from fastapi.responses import JSONResponse

from fastapi.templating import Jinja2Templates

from pydantic import BaseModel

from app.logger import get_logger

from app.services.upstox_service import (
    save_manual_token,
    get_upstox_status,
)

logger = get_logger()

router = APIRouter()

templates = Jinja2Templates(directory="app/templates")

# ==========================================================
# REQUEST MODEL
# ==========================================================


class TokenRequest(BaseModel):
    access_token: str


# ==========================================================
# LOGIN PAGE
# ==========================================================


@router.get("/login", response_class=HTMLResponse)
async def login_page(
    request: Request,
):

    try:

        status = get_upstox_status()

        return templates.TemplateResponse(
            request=request,
            name="login.html",
            context={"status": status},
        )

    except Exception:

        logger.exception("Failed loading login page")

        return templates.TemplateResponse(
            request=request,
            name="login.html",
            context={
                "status": {"token_valid": False, "balance": 0, "message": "ERROR"}
            },
        )


# ==========================================================
# GET TOKEN STATUS
# ==========================================================


@router.get("/api/login/status")
async def login_status():

    try:

        return {"success": True, "data": get_upstox_status()}

    except Exception as ex:

        logger.exception("Failed fetching login status")

        return {"success": False, "message": str(ex)}


# ==========================================================
# SAVE TOKEN
# ==========================================================


@router.post("/api/login/token")
async def save_token_api(request: TokenRequest):

    try:

        access_token = request.access_token.strip()

        result = save_manual_token(access_token)

        if not result.get("success"):

            return JSONResponse(
                status_code=400,
                content={
                    "success": False,
                    "message": result.get("message", "Token validation failed"),
                },
            )

        logger.info("Manual Upstox token saved successfully")

        return {
            "success": True,
            "balance": result.get("balance", 0),
            "message": result.get("message", "Token saved successfully"),
        }

    except Exception as ex:

        logger.exception("Failed saving manual token")

        return JSONResponse(
            status_code=500,
            content={
                "success": False,
                "message": str(ex),
            },
        )


# ==========================================================
# VALIDATE TOKEN ONLY
# ==========================================================


@router.post("/api/login/validate")
async def validate_token_api(request: TokenRequest):

    try:

        from app.services.upstox_service import validate_token

        access_token = request.access_token.strip()

        result = validate_token(access_token)

        if not result.get("success"):

            return JSONResponse(
                status_code=400,
                content={
                    "success": False,
                    "message": result.get("message", "Invalid token"),
                },
            )

        return {
            "success": True,
            "balance": result.get("balance", 0),
            "message": "Token is valid",
        }

    except Exception as ex:

        logger.exception("Token validation API failed")

        return JSONResponse(
            status_code=500,
            content={
                "success": False,
                "message": str(ex),
            },
        )
