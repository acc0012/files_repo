from fastapi import APIRouter

from app.logger import get_logger

from app.utils.datetime_helper import (
    ist_now,
)

logger = get_logger()

router = APIRouter()

# ==========================================================
# STATUS
# ==========================================================


@router.get("/status")
async def get_status():

    try:

        return {
            "success": True,
            "application": "T_SYSTEM_ALERT_ENGINE",
            "status": "RUNNING",
            "timestamp": ist_now(),
        }

    except Exception:

        logger.exception("Status endpoint failed")

        return {
            "success": False,
            "status": "ERROR",
        }


# ==========================================================
# HEALTH
# ==========================================================


@router.get("/health")
async def health_check():

    try:

        return {
            "success": True,
            "status": "UP",
            "timestamp": ist_now(),
        }

    except Exception:

        logger.exception("Health endpoint failed")

        return {
            "success": False,
            "status": "DOWN",
        }
