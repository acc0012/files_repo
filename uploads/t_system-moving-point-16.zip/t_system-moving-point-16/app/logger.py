import os
import logging

from datetime import datetime
from logging.handlers import RotatingFileHandler

from app.config import LOG_LEVEL

# ==================================================
# LOG DIRECTORY
# ==================================================

LOG_DIR = "logs"

os.makedirs(LOG_DIR, exist_ok=True)

# ==================================================
# PROJECT NAME
# ==================================================

LOGGER_NAME = "t_system_alert_engine"

# ==================================================
# STARTUP TIMESTAMP
# ==================================================

STARTUP_TIME = datetime.now().strftime(
    "%Y%m%d_%H%M%S"
)

LOG_FILE = os.path.join(
    LOG_DIR,
    f"{LOGGER_NAME}_{STARTUP_TIME}.log"
)

# ==================================================
# LOGGER INSTANCE
# ==================================================

logger = logging.getLogger(LOGGER_NAME)

if not logger.handlers:

    logger.setLevel(LOG_LEVEL)

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
    )

    # Console
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)

    # File
    file_handler = RotatingFileHandler(
        LOG_FILE,
        maxBytes=10 * 1024 * 1024,
        backupCount=10,
        encoding="utf-8"
    )

    file_handler.setFormatter(formatter)

    logger.addHandler(console_handler)
    logger.addHandler(file_handler)

    logger.propagate = False

    logger.info("=" * 80)
    logger.info(f"LOG FILE CREATED : {LOG_FILE}")
    logger.info("=" * 80)


def get_logger():
    return logger