from datetime import datetime, time as dt_time
from zoneinfo import ZoneInfo
from concurrent.futures import ThreadPoolExecutor, as_completed
import upstox_client
from upstox_client.rest import ApiException

from config.settings import Settings
from core.logger import get_logger
from db.repositories import UpstoxRepository
from indicators.ema import EMAIndicator
from models.strike_state import StrikeState

logger = get_logger(__name__)


class PreloadService:
    """
    Loads all strike documents and builds
    runtime EMA state before market open.
    """

    RUNTIME_STATE = {}

    @classmethod
    def load_access_token(cls):
        """
        Load latest Upstox access token.
        """
        try:
            token = UpstoxRepository.get_access_token()
            logger.info("Access token loaded successfully.")
            return token
        except Exception as ex:
            logger.exception(f"Failed loading access token: {ex}")
            raise

    @classmethod
    def get_today(cls):
        """
        Current trading date.
        """
        return datetime.now().strftime("%Y-%m-%d")

    @classmethod
    def reset(cls):
        """
        Clear runtime cache.
        Called every market close.
        """
        try:
            count = len(cls.RUNTIME_STATE)
            cls.RUNTIME_STATE.clear()
            logger.info(f"Runtime cache cleared. Removed {count} instruments.")
        except Exception as ex:
            logger.exception(f"Failed clearing runtime cache: {ex}")

    @classmethod
    def _load_ema_state(cls, strike_doc: dict):
        """
        Load latest EMA state.

        Priority:
        1. Late-start resolution: Fetch missed intraday gap candles if past 9:15 AM.
        2. Daily stored EMA
        3. Recalculate from base candles
        """
        try:
            instrument_key = strike_doc.get("instrument_key")
            candles = strike_doc.get("candles", [])

            # ----------------------------------------------------
            # Handle late startup gaps (e.g. starting at 10:30 AM)
            # ----------------------------------------------------
            tz = ZoneInfo(Settings.TIMEZONE)
            now_time = datetime.now(tz).time()
            market_start = dt_time(9, 15)

            if now_time > market_start and instrument_key:
                logger.info(
                    f"Late startup detected ({now_time}). Fetching morning gap candles for {instrument_key}..."
                )

                try:
                    # Authenticate and set up the Upstox API history client
                    token = UpstoxRepository.get_access_token()
                    configuration = upstox_client.Configuration()
                    configuration.access_token = token

                    api_instance = upstox_client.HistoryApi(
                        upstox_client.ApiClient(configuration)
                    )

                    api_version = getattr(Settings, "API_VERSION", "2.0")

                    api_response = api_instance.get_intra_day_candle_data(
                        instrument_key=instrument_key,
                        interval=Settings.CANDLE_INTERVAL,
                        api_version=api_version,
                    )

                    # FIXED: Changed from dictionary `.get()` / `[...]` to object property dot notation
                    if (
                        api_response
                        and hasattr(api_response, "data")
                        and hasattr(api_response.data, "candles")
                        and api_response.data.candles
                    ):
                        raw_candles = api_response.data.candles

                        # Upstox gives newest candles first; reverse it to maintain forward chronological order
                        raw_candles.reverse()

                        gap_candles = []
                        for c in raw_candles:
                            gap_candles.append(
                                {
                                    "timestamp": c[0],
                                    "open": float(c[1]),
                                    "high": float(c[2]),
                                    "low": float(c[3]),
                                    "close": float(c[4]),
                                    "volume": int(c[5]),
                                }
                            )

                        # Stitch historical database context with today's API-sourced gap context
                        candles = candles + gap_candles
                        logger.info(
                            f"Successfully stitched {len(gap_candles)} intraday gap candles for {instrument_key}."
                        )

                except ApiException as api_ex:
                    logger.error(
                        f"Upstox API exception while checking intraday gap for {instrument_key}: {api_ex}"
                    )
                except Exception as gap_ex:
                    logger.error(
                        f"General failure fetching intraday gap for {instrument_key}: {gap_ex}"
                    )

            # ----------------------------------------------------
            # Process stitched candle history for EMA calculation
            # ----------------------------------------------------
            daily = strike_doc.get("daily", {})

            if daily and now_time <= market_start:
                latest_date = sorted(daily.keys())[-1]
                latest_daily = daily.get(latest_date, {})

                ema_short = latest_daily.get("ema_short")
                ema_long = latest_daily.get("ema_long")
                last_price = latest_daily.get("last_price")

                if (
                    ema_short is not None
                    and ema_long is not None
                    and last_price is not None
                ):
                    relation = "ABOVE" if ema_short > ema_long else "BELOW"

                    logger.debug(
                        f"Using stored EMA | {strike_doc.get('instrument_key')}"
                    )

                    return {
                        "ema_short": float(ema_short),
                        "ema_long": float(ema_long),
                        "last_close": float(last_price),
                        "relation": relation,
                    }

            return EMAIndicator.get_latest_state(
                candles=candles,
                short_period=Settings.EMA_SHORT_PERIOD,
                long_period=Settings.EMA_LONG_PERIOD,
            )

        except Exception as ex:
            logger.exception(f"Failed loading EMA state: {ex}")
            raise

    @classmethod
    def _process_single_strike(cls, strike_doc: dict, today: str):
        """
        Helper method to isolate processing for a single strike.
        Enables clean multi-threaded execution.
        """
        instrument_key = strike_doc.get("instrument_key")
        if not instrument_key:
            logger.warning("Instrument key missing.")
            return None, "skipped"

        candles = strike_doc.get("candles", [])
        if not candles:
            logger.warning(f"Skipping {instrument_key} because candles are empty.")
            return None, "skipped"

        # Ensure daily document tracking exists in MongoDB
        UpstoxRepository.ensure_daily_document(instrument_key, today)

        # Triggers gap candle API fetching and calculates EMA
        ema_state = cls._load_ema_state(strike_doc)
        strike_state = StrikeState.from_preload(strike_doc, ema_state)

        return (instrument_key, strike_state), "loaded"

    @classmethod
    def initialize_runtime_state(cls):
        """
        Load all strike documents and build runtime cache in parallel.
        """
        try:
            cls.reset()
            strikes = UpstoxRepository.get_all_strikes()

            total_loaded = 0
            total_skipped = 0
            today = cls.get_today()

            logger.info(f"Initializing runtime state for {len(strikes)} strikes.")

            # SPEED UP: Use a ThreadPoolExecutor to run API queries concurrently
            # 10 workers is a safe sweet spot for API limits vs throughput
            max_workers = 10

            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                # Submit all operations to the background thread pool
                futures = {
                    executor.submit(cls._process_single_strike, strike, today): strike
                    for strike in strikes
                }

                # Consume the threads as they complete execution
                for future in as_completed(futures):
                    try:
                        result, status = future.result()
                        if status == "loaded" and result:
                            inst_key, strike_state = result
                            cls.RUNTIME_STATE[inst_key] = strike_state
                            total_loaded += 1
                        else:
                            total_skipped += 1
                    except Exception as strike_ex:
                        total_skipped += 1
                        strike_doc = futures[future]
                        logger.exception(
                            f"Failed loading {strike_doc.get('instrument_key')}: {strike_ex}"
                        )

            logger.info(
                f"Runtime initialized | Loaded={total_loaded} | Skipped={total_skipped}"
            )
            return cls.RUNTIME_STATE

        except Exception as ex:
            logger.exception(f"Runtime initialization failed: {ex}")
            raise

    @classmethod
    def get_runtime_state(cls):
        """Return complete runtime cache."""
        return cls.RUNTIME_STATE

    @classmethod
    def get_runtime_by_key(cls, instrument_key: str):
        """Return one instrument runtime state."""
        return cls.RUNTIME_STATE.get(instrument_key)

    @classmethod
    def update_runtime_state(cls, instrument_key: str, updates: dict):
        """Update StrikeState object."""
        try:
            state = cls.RUNTIME_STATE.get(instrument_key)
            if not state:
                logger.warning(f"Runtime state missing for {instrument_key}")
                return

            if "ema_short" in updates:
                state.update_ema(
                    ema_short=updates.get("ema_short", state.ema_short),
                    ema_long=updates.get("ema_long", state.ema_long),
                    last_close=updates.get("last_close", state.last_close),
                    relation=updates.get("relation", state.relation),
                )
        except Exception as ex:
            logger.exception(f"Runtime update failed {instrument_key}: {ex}")

    @classmethod
    def get_instrument_keys(cls):
        """Used for Upstox subscriptions."""
        try:
            keys = list(cls.RUNTIME_STATE.keys())
            return keys
        except Exception as ex:
            logger.exception(f"Failed loading instrument keys: {ex}")
            raise

    @classmethod
    def get_subscription_batches(cls, batch_size=None):
        """Split instruments into batches."""
        try:
            if batch_size is None:
                batch_size = Settings.SUBSCRIBE_BATCH_SIZE
            keys = cls.get_instrument_keys()
            return [keys[i : i + batch_size] for i in range(0, len(keys), batch_size)]
        except Exception as ex:
            logger.exception(f"Failed creating batches: {ex}")
            raise

    @classmethod
    def get_total_instruments(cls):
        return len(cls.RUNTIME_STATE)

    @classmethod
    def print_startup_summary(cls):
        """Startup summary."""
        try:
            total = cls.get_total_instruments()
            logger.info("=" * 70)
            logger.info(Settings.APP_NAME)
            logger.info(f"EMA SHORT : {Settings.EMA_SHORT_PERIOD}")
            logger.info(f"EMA LONG : {Settings.EMA_LONG_PERIOD}")
            logger.info(f"INSTRUMENTS : {total}")
            logger.info("=" * 70)
        except Exception as ex:
            logger.exception(f"Failed startup summary: {ex}")
