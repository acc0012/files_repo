import signal
import sys

from core.logger import get_logger

from db.mongo_app import MongoApp

from services.market_scheduler import MarketScheduler

from services.crossover_engine import CrossoverEngine

from services.preload_service import PreloadService

from services.candle_builder import CandleBuilder

logger = get_logger(__name__)


class Application:

    def __init__(self):

        self.scheduler = MarketScheduler()

    def register_shutdown(self):
        """
        Graceful shutdown handling.
        """

        def shutdown_handler(signum, frame):

            try:

                logger.info("=" * 80)

                logger.info("Shutdown signal received.")

                # -------------------------
                # Flush candles
                # -------------------------

                logger.info("Flushing remaining candles...")

                CrossoverEngine.flush_pending_candles()

                # -------------------------
                # Stop stream
                # -------------------------

                try:

                    if (
                        hasattr(self.scheduler, "stream_service")
                        and self.scheduler.stream_service
                    ):

                        self.scheduler.stream_service.stop()

                except Exception as ex:

                    logger.exception(f"Stream stop failed: {ex}")

                # -------------------------
                # Clear runtime
                # -------------------------

                try:

                    PreloadService.reset()
                except Exception:
                    pass

                try:

                    CandleBuilder.clear()
                except Exception:
                    pass

                # -------------------------
                # Close Mongo
                # -------------------------

                MongoApp.close()

                logger.info("Application shutdown completed.")

                logger.info("=" * 80)

                sys.exit(0)

            except Exception as ex:

                logger.exception(f"Shutdown failed: {ex}")

                sys.exit(1)

        signal.signal(signal.SIGINT, shutdown_handler)

        signal.signal(signal.SIGTERM, shutdown_handler)

    def start(self):
        """
        Application entry point.
        """

        try:

            logger.info("=" * 80)

            logger.info("UPSTOX EMA CROSSOVER ENGINE")

            logger.info("=" * 80)

            self.register_shutdown()

            MongoApp.connect()

            logger.info("MongoDB connection established.")

            self.scheduler.start()

        except Exception as ex:

            logger.exception(f"Application failed: {ex}")

            raise


def main():

    try:

        app = Application()

        app.start()

    except KeyboardInterrupt:

        logger.warning("Keyboard interrupt received.")

    except Exception as ex:

        logger.exception(f"Fatal application error: {ex}")

        sys.exit(1)


if __name__ == "__main__":

    main()
