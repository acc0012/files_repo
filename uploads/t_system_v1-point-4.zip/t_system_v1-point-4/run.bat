@echo off
cls
echo Starting FastAPI Application...

python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload

pause