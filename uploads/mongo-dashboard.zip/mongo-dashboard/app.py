
import os
import math
from datetime import datetime, date
from flask import Flask, jsonify, render_template, request
from pymongo import MongoClient
from bson import ObjectId
from dotenv import load_dotenv

# Load .env for local dev. In Vercel, env vars come from the dashboard.
load_dotenv()

MONGODB_URI = os.getenv("MONGODB_URI")
MONGODB_DB = os.getenv("MONGODB_DB")

if not MONGODB_URI or not MONGODB_DB:
    raise RuntimeError("MONGODB_URI and MONGODB_DB must be set as environment variables.")

# Create a single global client for connection reuse across invocations
client = MongoClient(MONGODB_URI, serverSelectionTimeoutMS=5000)
db = client[MONGODB_DB]

app = Flask(__name__)


def sanitize(value):
    """Recursively convert BSON/unsupported types to JSON-safe values."""
    if isinstance(value, ObjectId):
        return str(value)
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    if isinstance(value, list):
        return [sanitize(v) for v in value]
    if isinstance(value, dict):
        return {k: sanitize(v) for k, v in value.items()}
    return value


@app.route("/")
def home():
    # Server delivers the HTML shell; data is fetched via XHR
    return render_template("index.html")


@app.route("/api/collections", methods=["GET"]) 
def list_collections():
    try:
        names = sorted(db.list_collection_names())
        return jsonify({"collections": names})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/docs", methods=["GET"]) 
def get_docs():
    """
    Query params:
      - collection (required)
      - page (1-based; default 1)
      - limit (default 25, max 100)
    Returns:
      { docs: [...], page: 1, limit: 25, total_count: n, total_pages: m }
    """
    coll_name = request.args.get("collection")
    if not coll_name:
        return jsonify({"error": "Missing 'collection' parameter."}), 400

    try:
        # Validate collection exists
        if coll_name not in db.list_collection_names():
            return jsonify({"error": f"Collection '{coll_name}' not found."}), 404

        page = int(request.args.get("page", 1))
        limit = int(request.args.get("limit", 25))
        if page < 1:
            page = 1
        if limit < 1:
            limit = 25
        limit = min(limit, 100)  # safety cap

        skip = (page - 1) * limit
        coll = db[coll_name]

        # Count for pagination
        total_count = coll.count_documents({})
        total_pages = max(1, math.ceil(total_count / limit)) if total_count else 1

        # Fetch docs; default sort by _id ascending (roughly "first" docs)
        cursor = coll.find({}, skip=skip, limit=limit).sort([("_id", 1)])
        docs = [sanitize(d) for d in cursor]

        return jsonify({
            "docs": docs,
            "page": page,
            "limit": limit,
            "total_count": total_count,
            "total_pages": total_pages
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    port = int(os.getenv("PORT", "8000"))
    app.run(host="0.0.0.0", port=port)
