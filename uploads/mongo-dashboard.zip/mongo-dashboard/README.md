
# MongoDB Dashboard (Flask on Vercel)

A simple dashboard that lists MongoDB collections and shows the first N documents with pagination.

## Features
- Read MongoDB Atlas URI and DB name from environment variables (`.env` locally)
- List collections
- View documents (25/50/100 per page) with Prev/Next pagination
- Clean Bootstrap UI

## Local Development

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scriptsctivate
pip install -r requirements.txt
cp .env.example .env  # edit with your values
python app.py  # visit http://localhost:8000
```

## Deploy to Vercel
1. Install Vercel CLI: `npm i -g vercel`
2. `vercel login` and then `vercel`
3. Add env vars in Project Settings: `MONGODB_URI`, `MONGODB_DB`
4. Deploy: `vercel --prod`

## Environment Variables
- `MONGODB_URI` – your MongoDB Atlas connection string
- `MONGODB_DB` – database name to use
- `PORT` (optional) – local port, default 8000

## Notes
- Pagination uses `_id` ascending order
- Limit is capped at 100 per page
- For very large collections, consider estimated counts or server-side filtering
