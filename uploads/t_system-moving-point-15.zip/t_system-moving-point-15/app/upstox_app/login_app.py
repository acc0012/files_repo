import upstox_client 


upstox_app = upstox_client()

