from datetime import datetime

from fastapi import APIRouter

from app.logger import get_logger

logger = get_logger()

router = APIRouter()


@router.get("/status")
async def get_status():

    try:

        return {
            "success": True,
            "application": "T_SYSTEM_ALERT_ENGINE",
            "status": "RUNNING",
            "timestamp": datetime.utcnow(),
        }

    except Exception:

        logger.exception("Status endpoint failed")

        return {
            "success": False,
            "status": "ERROR"
        }


@router.get("/health")
async def health_check():

    try:

        return {
            "success": True,
            "status": "UP",
            "timestamp": datetime.utcnow(),
        }

    except Exception:

        logger.exception("Health endpoint failed")

        return {
            "success": False,
            "status": "DOWN"
        }