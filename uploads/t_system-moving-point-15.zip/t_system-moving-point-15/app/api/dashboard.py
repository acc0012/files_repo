from fastapi import APIRouter
from fastapi import Query
from fastapi import Request

from fastapi.responses import HTMLResponse

from fastapi.templating import Jinja2Templates

from app.logger import get_logger

from app.services.dashboard_service import (
    get_dashboard_summary,
    get_opening_range_alerts,
    get_index_alerts,
    get_option_alerts,
)

from app.services.upstox_service import (
    get_upstox_status,
)

from app.services.upstox_monitor_service import (
    get_monitor_status,
)

logger = get_logger()

router = APIRouter()

templates = Jinja2Templates(directory="app/templates")

# ============================================================
# DASHBOARD HOME PAGE
# ============================================================


@router.get("/", response_class=HTMLResponse)
async def dashboard_home(request: Request):

    try:

        upstox_status = get_upstox_status()

        return templates.TemplateResponse(
            request=request,
            name="dashboard.html",
            context={"upstox_status": upstox_status},
        )

    except Exception:

        logger.exception("Failed loading dashboard")

        return templates.TemplateResponse(
            request=request,
            name="dashboard.html",
            context={
                "upstox_status": {
                    "token_valid": False,
                    "balance": 0,
                    "message": "ERROR",
                }
            },
        )


# ============================================================
# DASHBOARD SUMMARY
# ============================================================


@router.get("/api/dashboard/summary")
async def dashboard_summary(date: str = Query(...)):

    try:

        return {
            "success": True,
            "data": get_dashboard_summary(date),
        }

    except Exception as ex:

        logger.exception(f"Dashboard summary failed " f"date={date}")

        return {
            "success": False,
            "message": str(ex),
        }


# ============================================================
# OPENING RANGE API
# ============================================================


@router.get("/api/dashboard/opening-range")
async def opening_range_data(date: str = Query(...)):

    try:

        return {
            "success": True,
            "data": get_opening_range_alerts(date),
        }

    except Exception as ex:

        logger.exception(f"Opening range fetch failed " f"date={date}")

        return {
            "success": False,
            "message": str(ex),
        }


# ============================================================
# INDEX ALERTS API
# ============================================================


@router.get("/api/dashboard/index-alerts")
async def index_alerts(date: str = Query(...)):

    try:

        return {
            "success": True,
            "data": get_index_alerts(date),
        }

    except Exception as ex:

        logger.exception(f"Index alerts fetch failed " f"date={date}")

        return {
            "success": False,
            "message": str(ex),
        }


# ============================================================
# OPTION ALERTS API
# ============================================================


@router.get("/api/dashboard/option-alerts")
async def option_alerts(date: str = Query(...)):

    try:

        return {
            "success": True,
            "data": get_option_alerts(date),
        }

    except Exception as ex:

        logger.exception(f"Option alerts fetch failed " f"date={date}")

        return {
            "success": False,
            "message": str(ex),
        }


# ============================================================
# UPSTOX STATUS API
# ============================================================


@router.get("/api/upstox/status")
async def upstox_status():

    try:

        return {
            "success": True,
            "data": get_upstox_status(),
        }

    except Exception as ex:

        logger.exception("Failed fetching Upstox status")

        return {
            "success": False,
            "message": str(ex),
        }


# ============================================================
# UPSTOX MONITOR STATUS API
# ============================================================


@router.get("/api/upstox/monitor-status")
async def upstox_monitor_status():

    try:

        return {
            "success": True,
            "data": get_monitor_status(),
        }

    except Exception as ex:

        logger.exception("Failed fetching Upstox monitor status")

        return {
            "success": False,
            "message": str(ex),
        }
