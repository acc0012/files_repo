from fastapi import APIRouter, Query, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

from app.logger import get_logger

from app.services.dashboard_service import (
    get_dashboard_summary,
    get_opening_range_alerts,
    get_index_alerts,
    get_option_alerts,
)

logger = get_logger()

router = APIRouter()

templates = Jinja2Templates(directory="app/templates")


# ============================================================
# DASHBOARD HOME PAGE
# ============================================================


@router.get("/", response_class=HTMLResponse)
async def dashboard_home(request: Request):

    return templates.TemplateResponse(request=request, name="dashboard.html")


# ============================================================
# SUMMARY API
# ============================================================


@router.get("/api/dashboard/summary")
async def dashboard_summary(date: str = Query(...)):

    try:

        return {"success": True, "data": get_dashboard_summary(date)}

    except Exception as ex:

        logger.exception(f"Dashboard summary failed date={date}")

        return {"success": False, "message": str(ex)}


# ============================================================
# OPENING RANGE API
# ============================================================


@router.get("/api/dashboard/opening-range")
async def opening_range_data(date: str = Query(...)):

    try:

        return {"success": True, "data": get_opening_range_alerts(date)}

    except Exception as ex:

        logger.exception(f"Opening range fetch failed date={date}")

        return {"success": False, "message": str(ex)}


# ============================================================
# INDEX ALERTS API
# ============================================================


@router.get("/api/dashboard/index-alerts")
async def index_alerts(date: str = Query(...)):

    try:

        return {"success": True, "data": get_index_alerts(date)}

    except Exception as ex:

        logger.exception(f"Index alerts fetch failed date={date}")

        return {"success": False, "message": str(ex)}


# ============================================================
# OPTION ALERTS API
# ============================================================


@router.get("/api/dashboard/option-alerts")
async def option_alerts(date: str = Query(...)):

    try:

        return {"success": True, "data": get_option_alerts(date)}

    except Exception as ex:

        logger.exception(f"Option alerts fetch failed date={date}")

        return {"success": False, "message": str(ex)}
