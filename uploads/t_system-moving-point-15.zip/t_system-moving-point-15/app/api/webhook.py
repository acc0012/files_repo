from datetime import datetime

from fastapi import APIRouter, Request

from app.services.queue_service import WEBHOOK_QUEUE

from app.services.webhook_service import (
    generate_trace_id
)

from app.services.mongo_service import (
    webhook_collection
)

router = APIRouter()

@router.post("/webhook")
async def receive_webhook(request: Request):

    payload = await request.json()

    trace_id = generate_trace_id()

    webhook_collection.insert_one({

        "trace_id": trace_id,

        "received_at": datetime.utcnow(),

        "processed": False,

        "payload": payload
    })

    WEBHOOK_QUEUE.put({

        "trace_id": trace_id,

        "payload": payload
    })

    return {

        "success": True,

        "trace_id": trace_id
    }