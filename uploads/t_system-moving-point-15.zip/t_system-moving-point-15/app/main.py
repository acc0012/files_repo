from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from app.logger import get_logger

from app.api.webhook import router as webhook_router
from app.api.status import router as status_router
from app.api.dashboard import router as dashboard_router

from app.services.worker_service import start_worker

logger = get_logger()


@asynccontextmanager
async def lifespan(app: FastAPI):

    try:

        logger.info("=" * 80)
        logger.info("T_SYSTEM ALERT ENGINE STARTING")
        logger.info("=" * 80)

        logger.info("Initializing worker service")

        start_worker()

        logger.info("Worker service initialized")

        logger.info("Application startup completed")

        yield

    except Exception:

        logger.exception("Application startup failed")

        raise

    finally:

        logger.info("Application shutdown initiated")

        logger.info("Application shutdown completed")


try:

    app = FastAPI(title="T_SYSTEM_ALERT_ENGINE", lifespan=lifespan)

    # ==================================================
    # STATIC FILES
    # ==================================================

    app.mount("/static", StaticFiles(directory="app/static"), name="static")

    # ==================================================
    # ROUTERS
    # ==================================================

    app.include_router(webhook_router)

    app.include_router(status_router)

    app.include_router(dashboard_router)

    logger.info("Routers registered successfully")

except Exception:

    logger.exception("FastAPI application initialization failed")

    raise
