from app.logger import get_logger

from app.utils.datetime_helper import (
    ist_now,
)

from app.services.mongo_service import (
    opening_range_collection,
)

logger = get_logger()

# ==========================================================
# PROCESS OPENING RANGE
# ==========================================================


def process_opening_range(
    trace_id: str,
    payload: dict,
):

    try:

        logger.info(
            f"Processing Opening Range "
            f"trace_id={trace_id} "
            f"symbol={payload.get('SYMBOL')}"
        )

        doc = {
            "trace_id": trace_id,
            "type": payload.get("TYPE"),
            "ticker": payload.get("TICKER"),
            "symbol": payload.get("SYMBOL"),
            "high": float(payload.get("HIGH", 0) or 0),
            "low": float(payload.get("LOW", 0) or 0),
            "avg": float(payload.get("AVG", 0) or 0),
            "sub_resistance": float(payload.get("SUB_RESISTANCE", 0) or 0),
            "sub_support": float(payload.get("SUB_SUPPORT", 0) or 0),
            "resistance2": float(payload.get("RESISTANCE2", 0) or 0),
            "support2": float(payload.get("SUPPORT2", 0) or 0),
            "resistance3": float(payload.get("RESISTANCE3", 0) or 0),
            "support3": float(payload.get("SUPPORT3", 0) or 0),
            # ==================================================
            # NEW FIELDS FROM LATEST PAYLOAD FORMAT
            # ==================================================
            "resistance3_ce_strike": payload.get("RESISTANCE3_CE_STRIKE"),
            "resistance3_pe_strike": payload.get("RESISTANCE3_PE_STRIKE"),
            "support3_ce_strike": payload.get("SUPPORT3_CE_STRIKE"),
            "support3_pe_strike": payload.get("SUPPORT3_PE_STRIKE"),
            "buy_ce": payload.get("BUY_CE"),
            "buy_pe": payload.get("BUY_PE"),
            "created_at": ist_now(),
        }

        result = opening_range_collection.insert_one(doc)

        logger.info(
            f"Opening Range saved "
            f"trace_id={trace_id} "
            f"symbol={payload.get('SYMBOL')} "
            f"mongo_id={result.inserted_id}"
        )

        return result.inserted_id

    except Exception:

        logger.exception(
            f"Opening Range processing failed "
            f"trace_id={trace_id} "
            f"symbol={payload.get('SYMBOL')}"
        )

        raise
