from pymongo import MongoClient

from app.config import (
    MONGO_URL,
    MONGO_DB,
    WEBHOOK_COLLECTION,
    OPENING_RANGE_COLLECTION,
    INDEX_SIGNAL_COLLECTION,
    OPTION_SIGNAL_COLLECTION,
    UPSTOX_TOKEN_COLLECTION,
)

from app.logger import get_logger

logger = get_logger()

try:

    logger.info("Connecting to MongoDB")

    client = MongoClient(MONGO_URL, serverSelectionTimeoutMS=5000)

    # Force connection check
    client.admin.command("ping")

    db = client[MONGO_DB]

    webhook_collection = db[WEBHOOK_COLLECTION]

    opening_range_collection = db[OPENING_RANGE_COLLECTION]

    index_signal_collection = db[INDEX_SIGNAL_COLLECTION]

    option_signal_collection = db[OPTION_SIGNAL_COLLECTION]

    upstox_token_collection = db[UPSTOX_TOKEN_COLLECTION]

    logger.info(f"MongoDB connected successfully " f"database={MONGO_DB}")

except Exception:

    logger.exception(f"MongoDB connection failed " f"url={MONGO_URL}")

    raise
