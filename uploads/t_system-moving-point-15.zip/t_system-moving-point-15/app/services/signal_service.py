from datetime import datetime

from app.logger import get_logger

from app.services.mongo_service import (
    index_signal_collection,
    option_signal_collection,
)

logger = get_logger()


def process_signal(trace_id: str, payload: dict):

    try:

        source = payload.get("ALERT_SOURCE")

        logger.info(
            f"Processing Signal "
            f"trace_id={trace_id} "
            f"source={source} "
            f"type={payload.get('TYPE')} "
            f"symbol={payload.get('SYMBOL')}"
        )

        doc = {
            "trace_id": trace_id,

            "alert_source": source,
            "alert_category": payload.get("ALERT_CATEGORY"),

            "type": payload.get("TYPE"),

            "ticker": payload.get("TICKER"),
            "symbol": payload.get("SYMBOL"),

            "date": payload.get("DATE"),
            "time": payload.get("TIME"),
            "timeframe": payload.get("TF"),

            "price": float(payload.get("PRICE", 0) or 0),

            "ema9": float(payload.get("EMA9", 0) or 0),
            "ema21": float(payload.get("EMA21", 0) or 0),

            "diff": float(payload.get("DIFF", 0) or 0),

            "ema_level_info": payload.get(
                "EMA_LEVEL_INFO",
                {}
            ),

            "created_at": datetime.utcnow(),
        }

        # ==================================================
        # INDEX SIGNAL
        # ==================================================
        if source == "INDEX":

            doc["opening_range"] = payload.get(
                "OPENING_RANGE",
                {}
            )

            result = index_signal_collection.insert_one(doc)

            logger.info(
                f"Index Signal saved "
                f"trace_id={trace_id} "
                f"type={payload.get('TYPE')} "
                f"symbol={payload.get('SYMBOL')} "
                f"mongo_id={result.inserted_id}"
            )

            return result.inserted_id

        # ==================================================
        # OPTION SIGNAL
        # ==================================================
        elif source == "OPTION":

            doc["option_opening_range"] = payload.get(
                "OPTION_OPENING_RANGE",
                {}
            )

            result = option_signal_collection.insert_one(doc)

            logger.info(
                f"Option Signal saved "
                f"trace_id={trace_id} "
                f"type={payload.get('TYPE')} "
                f"ticker={payload.get('TICKER')} "
                f"mongo_id={result.inserted_id}"
            )

            return result.inserted_id

        # ==================================================
        # UNKNOWN SOURCE
        # ==================================================
        else:

            logger.warning(
                f"Unknown alert source "
                f"trace_id={trace_id} "
                f"source={source}"
            )

            raise ValueError(
                f"Unknown ALERT_SOURCE: {source}"
            )

    except Exception:

        logger.exception(
            f"Signal processing failed "
            f"trace_id={trace_id} "
            f"source={payload.get('ALERT_SOURCE')} "
            f"type={payload.get('TYPE')}"
        )

        raise