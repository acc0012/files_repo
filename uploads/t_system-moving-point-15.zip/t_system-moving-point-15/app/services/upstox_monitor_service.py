import threading
import time

from datetime import timedelta

from app.logger import get_logger

from app.config import (
    MONITOR_INTERVAL_MINUTES,
)

from app.utils.datetime_helper import (
    ist_now,
)

from app.services.upstox_service import (
    refresh_active_token_status,
)

logger = get_logger()

# ==========================================================
# CONFIGURATION
# ==========================================================

MONITOR_INTERVAL_SECONDS = MONITOR_INTERVAL_MINUTES * 60

# ==========================================================
# GLOBAL STATE
# ==========================================================

MONITOR_STATE = {
    "running": False,
    "started_at": None,
    "last_run_at": None,
    "last_success_at": None,
    "next_run_at": None,
}

# ==========================================================
# UPDATE NEXT RUN
# ==========================================================


def update_next_run():

    try:

        MONITOR_STATE["next_run_at"] = ist_now() + timedelta(
            minutes=MONITOR_INTERVAL_MINUTES
        )

    except Exception:

        logger.exception("Failed updating next monitor run time")


# ==========================================================
# MONITOR WORKER
# ==========================================================


def monitor_worker():

    logger.info("=" * 80)

    logger.info("UPSTOX TOKEN MONITOR STARTED")

    logger.info(f"Monitor Interval=" f"{MONITOR_INTERVAL_MINUTES} Minutes")

    logger.info("=" * 80)

    while True:

        try:

            MONITOR_STATE["last_run_at"] = ist_now()

            update_next_run()

            logger.info("Running scheduled Upstox token validation")

            success = refresh_active_token_status()

            if success:

                MONITOR_STATE["last_success_at"] = ist_now()

                logger.info("Scheduled token validation successful")

            else:

                logger.warning("Scheduled token validation failed")

        except Exception:

            logger.exception("Upstox monitor cycle failed")

        finally:

            logger.info(
                f"Next token validation in " f"{MONITOR_INTERVAL_MINUTES} minutes"
            )

            time.sleep(MONITOR_INTERVAL_SECONDS)


# ==========================================================
# START MONITOR
# ==========================================================


def start_upstox_monitor():

    try:

        if MONITOR_STATE["running"]:

            logger.warning("Upstox monitor already running")

            return

        thread = threading.Thread(
            target=monitor_worker,
            daemon=True,
            name="UpstoxTokenMonitor",
        )

        thread.start()

        MONITOR_STATE["running"] = True

        MONITOR_STATE["started_at"] = ist_now()

        update_next_run()

        logger.info(f"Upstox monitor thread started " f"name={thread.name}")

    except Exception:

        logger.exception("Failed starting Upstox monitor")

        raise


# ==========================================================
# GET STATUS
# ==========================================================


def get_monitor_status():

    try:

        return {
            "running": MONITOR_STATE["running"],
            "started_at": MONITOR_STATE["started_at"],
            "last_run_at": MONITOR_STATE["last_run_at"],
            "last_success_at": MONITOR_STATE["last_success_at"],
            "next_run_at": MONITOR_STATE["next_run_at"],
            "interval_minutes": MONITOR_INTERVAL_MINUTES,
            "interval_seconds": MONITOR_INTERVAL_SECONDS,
        }

    except Exception:

        logger.exception("Failed getting monitor status")

        return {
            "running": False,
            "started_at": None,
            "last_run_at": None,
            "last_success_at": None,
            "next_run_at": None,
            "interval_minutes": MONITOR_INTERVAL_MINUTES,
            "interval_seconds": MONITOR_INTERVAL_SECONDS,
        }


# ==========================================================
# MANUAL EXECUTION
# ==========================================================


def run_monitor_now():

    try:

        logger.info("Manual token validation requested")

        success = refresh_active_token_status()

        MONITOR_STATE["last_run_at"] = ist_now()

        if success:

            MONITOR_STATE["last_success_at"] = ist_now()

        update_next_run()

        return success

    except Exception:

        logger.exception("Manual monitor execution failed")

        return False
