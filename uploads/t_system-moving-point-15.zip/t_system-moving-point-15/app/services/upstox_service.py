import requests


from app.logger import get_logger

from app.config import (
    UPSTOX_ACCESS_TOKEN,
    UPSTOX_API_KEY,
    UPSTOX_API_SECRET,
)

from app.utils.datetime_helper import (
    ist_now,
)

from app.services.mongo_service import (
    upstox_token_collection,
)

logger = get_logger()

# ==========================================================
# GLOBAL STATE
# ==========================================================

UPSTOX_STATE = {
    "token_valid": False,
    "balance": 0.0,
    "access_token": None,
    "message": "Token Not Available",
    "validated_at": None,
    "last_checked_at": None,
}

# ==========================================================
# UPSTOX API
# ==========================================================

UPSTOX_FUNDS_URL = "https://api.upstox.com/v2/user/get-funds-and-margin"

# ==========================================================
# GET FUNDS
# ==========================================================


def get_funds(
    access_token: str,
):

    response = requests.get(
        UPSTOX_FUNDS_URL,
        headers={
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": f"Bearer {access_token}",
        },
        timeout=20,
    )

    response.raise_for_status()

    return response.json()


# ==========================================================
# VALIDATE TOKEN
# ==========================================================


def validate_token(
    access_token: str,
):

    try:

        logger.info("Validating Upstox access token")

        response = get_funds(access_token)

        equity = response.get("data", {}).get("equity", {})

        balance = float(equity.get("available_margin", 0) or 0)

        logger.info(f"Upstox token validation successful " f"balance={balance}")

        return {
            "success": True,
            "balance": balance,
            "response": response,
        }

    except Exception as ex:

        logger.exception("Upstox token validation failed")

        return {
            "success": False,
            "balance": 0,
            "message": str(ex),
        }


# ==========================================================
# LOAD ACTIVE TOKEN
# ==========================================================


def get_active_token():

    try:

        return upstox_token_collection.find_one(
            {"status": "ACTIVE"}, sort=[("validated_at", -1)]
        )

    except Exception:

        logger.exception("Failed loading token from MongoDB")

        return None


# ==========================================================
# SAVE TOKEN
# ==========================================================


def save_token(
    access_token: str,
    balance: float,
):

    try:

        upstox_token_collection.update_many({}, {"$set": {"status": "INACTIVE"}})

        upstox_token_collection.insert_one(
            {
                "access_token": access_token,
                "api_key": UPSTOX_API_KEY,
                "api_secret": UPSTOX_API_SECRET,
                "balance": balance,
                "status": "ACTIVE",
                "validated_at": ist_now(),
                "created_at": ist_now(),
            }
        )

        logger.info(f"Upstox token saved balance={balance}")

    except Exception:

        logger.exception("Failed saving Upstox token")

        raise


# ==========================================================
# MARK TOKEN EXPIRED
# ==========================================================


def mark_token_expired():

    try:

        upstox_token_collection.update_many(
            {"status": "ACTIVE"}, {"$set": {"status": "EXPIRED"}}
        )

        logger.warning("Active token marked as EXPIRED")

    except Exception:

        logger.exception("Failed marking token expired")


# ==========================================================
# EXPIRE TOKEN + RESET CLIENT
# ==========================================================


def expire_token():

    try:

        logger.warning("Expiring active Upstox token")

        mark_token_expired()

        update_state(
            token_valid=False,
            balance=0,
            access_token=None,
            message="TOKEN_EXPIRED",
        )

        try:

            from app.services.upstox_client_service import (
                reset_upstox_client,
            )

            reset_upstox_client()

        except Exception:

            logger.exception("Failed resetting Upstox client")

    except Exception:

        logger.exception("Failed expiring token")


# ==========================================================
# LOAD ENV TOKEN
# ==========================================================


def load_env_token():

    try:

        if not UPSTOX_ACCESS_TOKEN:

            return None

        logger.info("Using access token from ENV")

        return UPSTOX_ACCESS_TOKEN

    except Exception:

        logger.exception("Failed loading ENV token")

        return None


# ==========================================================
# UPDATE STATE
# ==========================================================


def update_state(
    token_valid: bool,
    balance: float = 0.0,
    access_token: str = None,
    message: str = "",
):

    UPSTOX_STATE["token_valid"] = token_valid
    UPSTOX_STATE["balance"] = balance
    UPSTOX_STATE["access_token"] = access_token
    UPSTOX_STATE["message"] = message

    UPSTOX_STATE["validated_at"] = ist_now()

    UPSTOX_STATE["last_checked_at"] = ist_now()


# ==========================================================
# INITIALIZE TOKEN
# ==========================================================


def initialize_token():

    try:

        logger.info("=" * 80)
        logger.info("UPSTOX TOKEN INITIALIZATION STARTED")
        logger.info("=" * 80)

        token_doc = get_active_token()

        if token_doc:

            access_token = token_doc.get("access_token")

            result = validate_token(access_token)

            if result["success"]:

                update_state(
                    token_valid=True,
                    balance=result["balance"],
                    access_token=access_token,
                    message="ACTIVE",
                )

                logger.info("MongoDB token validated successfully")

                return

            mark_token_expired()

        access_token = load_env_token()

        if access_token:

            result = validate_token(access_token)

            if result["success"]:

                save_token(access_token, result["balance"])

                update_state(
                    token_valid=True,
                    balance=result["balance"],
                    access_token=access_token,
                    message="ACTIVE",
                )

                logger.info("ENV token validated successfully")

                return

        expire_token()

    except Exception:

        logger.exception("Upstox initialization failed")

        expire_token()


# ==========================================================
# REFRESH TOKEN STATUS
# ==========================================================


def refresh_active_token_status():

    try:

        logger.info("Running background token validation")

        token_doc = get_active_token()

        if not token_doc:

            expire_token()

            return False

        access_token = token_doc.get("access_token")

        result = validate_token(access_token)

        if not result["success"]:

            logger.warning("Background validation failed")

            expire_token()

            return False

        update_state(
            token_valid=True,
            balance=result["balance"],
            access_token=access_token,
            message="ACTIVE",
        )

        logger.info(f"Background validation success " f"balance={result['balance']}")

        return True

    except Exception:

        logger.exception("Background validation crashed")

        return False


# ==========================================================
# GET STATUS
# ==========================================================


def get_upstox_status():

    return {
        "token_valid": UPSTOX_STATE["token_valid"],
        "balance": UPSTOX_STATE["balance"],
        "message": UPSTOX_STATE["message"],
        "validated_at": UPSTOX_STATE["validated_at"],
        "last_checked_at": UPSTOX_STATE["last_checked_at"],
    }


# ==========================================================
# SAVE MANUAL TOKEN
# ==========================================================


def save_manual_token(
    access_token: str,
):

    try:

        validation = validate_token(access_token)

        if not validation["success"]:

            return validation

        balance = validation["balance"]

        save_token(
            access_token,
            balance,
        )

        update_state(
            token_valid=True,
            balance=balance,
            access_token=access_token,
            message="ACTIVE",
        )

        try:

            from app.services.upstox_client_service import (
                reload_upstox_client,
            )

            reload_upstox_client()

        except Exception:

            logger.exception("Failed reloading Upstox client")

        return {
            "success": True,
            "balance": balance,
            "message": "Token Saved Successfully",
        }

    except Exception:

        logger.exception("Manual token save failed")

        return {
            "success": False,
            "balance": 0,
            "message": "Failed saving token",
        }
