// ======================================================
// GLOBAL
// ======================================================

function getSelectedDate() {
  return document.getElementById("selectedDate").value;
}

function isTodaySelected() {

    const today = new Date()
        .toISOString()
        .split("T")[0];

    return getSelectedDate() === today;
}

function startAutoRefresh() {

    if (refreshInterval) {

        clearInterval(refreshInterval);
    }

    refreshInterval = setInterval(async () => {

        if (!isTodaySelected()) {

            return;
        }

        await loadDashboard();

    }, 5000);
}
// ======================================================
// LOAD DASHBOARD
// ======================================================

async function loadDashboard() {
  await loadSummary();

  await loadOpeningRange();

  await loadIndexAlerts();

  await loadOptionAlerts();

  document.getElementById("lastRefreshTime").innerText =
    new Date().toLocaleTimeString();
}


// ======================================================
// SUMMARY
// ======================================================

async function loadSummary() {
  try {
    const date = getSelectedDate();

    const response = await fetch(`/api/dashboard/summary?date=${date}`);

    const result = await response.json();

    if (!result.success) {
      return;
    }

    const data = result.data;

    document.getElementById("openingRangeCount").innerText =
      data.opening_range_count;

    document.getElementById("indexSignalCount").innerText =
      data.index_signal_count;

    document.getElementById("optionSignalCount").innerText =
      data.option_signal_count;

    document.getElementById("totalAlertCount").innerText = data.total_alerts;
  } catch (error) {
    console.error("Summary Load Error", error);
  }
}

// ======================================================
// OPENING RANGE
// ======================================================

async function loadOpeningRange() {
  try {
    const date = getSelectedDate();

    const response = await fetch(`/api/dashboard/opening-range?date=${date}`);

    const result = await response.json();

    const tbody = document.getElementById("openingRangeTableBody");

    tbody.innerHTML = "";

    if (!result.success || result.data.length === 0) {
      tbody.innerHTML = `
                <tr>
                    <td colspan="9" class="text-center">
                        No Opening Range Alerts Found
                    </td>
                </tr>
            `;

      return;
    }

    result.data.forEach((row) => {
      tbody.innerHTML += `
                <tr>
                    <td>${row.symbol ?? ""}</td>
                    <td>${row.high ?? ""}</td>
                    <td>${row.low ?? ""}</td>
                    <td>${row.avg ?? ""}</td>
                    <td>${row.resistance3 ?? ""}</td>
                    <td>${row.support3 ?? ""}</td>
                    <td>${row.buy_ce ?? ""}</td>
                    <td>${row.buy_pe ?? ""}</td>
                    <td>${formatDateTime(row.created_at)}</td>
                </tr>
            `;
    });
  } catch (error) {
    console.error("Opening Range Load Error", error);
  }
}

// ======================================================
// INDEX ALERTS
// ======================================================

async function loadIndexAlerts() {
  try {
    const date = getSelectedDate();

    const response = await fetch(`/api/dashboard/index-alerts?date=${date}`);

    const result = await response.json();

    const tbody = document.getElementById("indexAlertsTableBody");

    tbody.innerHTML = "";

    if (!result.success || result.data.length === 0) {
      tbody.innerHTML = `
                <tr>
                    <td colspan="8" class="text-center">
                        No Index Alerts Found
                    </td>
                </tr>
            `;

      return;
    }

    result.data.forEach((row) => {
      tbody.innerHTML += `
                <tr>
                    <td>${row.time ?? ""}</td>
                    <td>${getAlertTypeBadge(row.type)}</td>
                    <td>${row.symbol ?? ""}</td>
                    <td>${row.price ?? ""}</td>
                    <td>${row.ema9 ?? ""}</td>
                    <td>${row.ema21 ?? ""}</td>
                    <td>${row.diff ?? ""}</td>
                    <td>${row.alert_category ?? ""}</td>
                </tr>
            `;
    });
  } catch (error) {
    console.error("Index Alerts Load Error", error);
  }
}

// ======================================================
// OPTION ALERTS
// ======================================================

async function loadOptionAlerts() {
  try {
    const date = getSelectedDate();

    const response = await fetch(`/api/dashboard/option-alerts?date=${date}`);

    const result = await response.json();

    const tbody = document.getElementById("optionAlertsTableBody");

    tbody.innerHTML = "";

    if (!result.success || result.data.length === 0) {
      tbody.innerHTML = `
                <tr>
                    <td colspan="8" class="text-center">
                        No Option Alerts Found
                    </td>
                </tr>
            `;

      return;
    }

    result.data.forEach((row) => {
      tbody.innerHTML += `
                <tr>
                    <td>${row.time ?? ""}</td>
                    <td>${getCategoryBadge(row.alert_category)}</td>
                    <td>${getAlertTypeBadge(row.type)}</td>
                    <td>${row.ticker ?? ""}</td>
                    <td>${row.price ?? ""}</td>
                    <td>${row.ema9 ?? ""}</td>
                    <td>${row.ema21 ?? ""}</td>
                    <td>${row.diff ?? ""}</td>
                </tr>
            `;
    });
  } catch (error) {
    console.error("Option Alerts Load Error", error);
  }
}

// ======================================================
// ALERT TYPE BADGES
// ======================================================

function getAlertTypeBadge(type) {
  if (!type) {
    return "";
  }

  let cssClass = "";

  switch (type) {
    case "BUY_CE":
      cssClass = "buy-ce";
      break;

    case "SELL_CE":
      cssClass = "sell-ce";
      break;

    case "BUY_PE":
      cssClass = "buy-pe";
      break;

    case "SELL_PE":
      cssClass = "sell-pe";
      break;

    default:
      cssClass = "bg-secondary";
  }

  return `
        <span class="alert-type ${cssClass}">
            ${type}
        </span>
    `;
}

// ======================================================
// CATEGORY BADGES
// ======================================================

function getCategoryBadge(category) {
  if (!category) {
    return "";
  }

  let cssClass = "";

  switch (category) {
    case "R3_CE_OPTION":
      cssClass = "r3-ce";
      break;

    case "R3_PE_OPTION":
      cssClass = "r3-pe";
      break;

    case "S3_CE_OPTION":
      cssClass = "s3-ce";
      break;

    case "S3_PE_OPTION":
      cssClass = "s3-pe";
      break;

    default:
      cssClass = "";
  }

  return `
        <span class="category-badge ${cssClass}">
            ${category}
        </span>
    `;
}

// ======================================================
// DATETIME FORMATTER
// ======================================================

function formatDateTime(dateValue) {
  if (!dateValue) {
    return "";
  }

  try {
    const dt = new Date(dateValue);

    return dt.toLocaleString();
  } catch {
    return dateValue;
  }
}

// ======================================================
// AUTO REFRESH
// ======================================================

let refreshInterval = null;

function startAutoRefresh() {
  if (refreshInterval) {
    clearInterval(refreshInterval);
  }

  refreshInterval = setInterval(async () => {
    console.log("Dashboard Auto Refresh : ", new Date().toLocaleTimeString());

    await loadDashboard();
  }, 5000); // 5 seconds
}
