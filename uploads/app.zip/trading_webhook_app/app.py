from flask import Flask, request, jsonify, render_template
from db import orders_collection
from order_logic import parse_message, generate_order_id, current_ist_time, should_ignore
from config import Config

app = Flask(__name__)

@app.route("/webhook", methods=["POST"])
def webhook():
    data = request.json
    raw_message = data.get("message")
    if not raw_message:
        return jsonify({"error": "Invalid payload"}), 400

    metadata = parse_message(raw_message)
    trade_type = metadata.get("Type")

    last_order = orders_collection.find_one({"status": "PLACED"}, sort=[("created_at", -1)])
    ignored = should_ignore(last_order, trade_type)
    order_id = generate_order_id("IG" if ignored else "ORD")

    order_doc = {
        "order_id": order_id,
        "status": "IGNORED" if ignored else "PLACED",
        "trade_type": trade_type,
        "strike": metadata.get("Strike"),
        "strike_price": metadata.get("StrikeLivePrice"),
        "symbol": metadata.get("Symbol"),
        "alert_price": metadata.get("Price"),
        "created_at": current_ist_time(),
        "metadata": metadata
    }
    orders_collection.insert_one(order_doc)
    return jsonify(order_doc), 200

@app.route("/")
def index():
    orders=list(orders_collection.find().sort("created_at",-1))
    return render_template("index.html", orders=orders)

if __name__=='__main__':
    app.run(port=Config.FLASK_PORT, debug=True)
