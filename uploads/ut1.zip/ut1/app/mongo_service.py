from pymongo import MongoClient
from app.config import MONGO_URL, MONGO_DB, INSTRUMENTS_COLLECTION, TOKENS_COLLECTION
from app.logger import get_logger

logger = get_logger(__file__)

client = MongoClient(MONGO_URL)
db = client[MONGO_DB]


def get_access_token() -> str:
    logger.info("Fetching Upstox access token from MongoDB collection=%s", TOKENS_COLLECTION)
    doc = db[TOKENS_COLLECTION].find_one({"_id": "upstox_access_token"})

    if not doc or not doc.get("access_token"):
        logger.error("Access token not found in MongoDB")
        raise RuntimeError("Access token not found in MongoDB")

    logger.info("Access token loaded successfully from MongoDB")
    return doc["access_token"]


def get_latest_instruments_doc() -> dict:
    logger.info("Fetching latest instruments document from MongoDB collection=%s", INSTRUMENTS_COLLECTION)
    doc = db[INSTRUMENTS_COLLECTION].find_one()

    if not doc:
        logger.error("latest_instruments document not found in MongoDB")
        raise RuntimeError("latest_instruments document not found in MongoDB")

    logger.info(
        "Loaded instruments document _id=%s total_records=%s total_strikes=%s",
        doc.get("_id"),
        doc.get("total_records"),
        doc.get("total_strikes"),
    )
    return doc
