import json
from fastapi import WebSocket

from app.logger import get_logger

logger = get_logger(__file__)


class WebSocketManager:
    def __init__(self):
        # For single instrument websocket:
        # /ws?strike=23450&type=ce&interval=0
        #
        # interval=0  -> live ticks
        # interval>0  -> closed candles
        self.clients = []

        # For option chain dashboard websocket:
        # /ws-chain
        #
        # This receives all normalized live ticks.
        self.chain_clients = []

    async def connect(
        self,
        websocket: WebSocket,
        strike: int,
        option_type: str,
        interval: int
    ):
        """
        Connect a single-instrument websocket client.

        Example:
            /ws?strike=23450&type=ce&interval=0
            /ws?strike=23450&type=ce&interval=1
            /ws?strike=23450&type=pe&interval=5
        """

        await websocket.accept()

        self.clients.append(
            {
                "websocket": websocket,
                "strike": strike,
                "type": option_type.lower(),
                "interval": interval,
            }
        )

    def disconnect(
        self,
        websocket: WebSocket
    ):
        """
        Disconnect a single-instrument websocket client.
        """

        self.clients = [
            client
            for client in self.clients
            if client["websocket"] != websocket
        ]

    def get_client_count(self):
        """
        Number of connected single-instrument websocket clients.
        """

        return len(self.clients)

    async def connect_chain(
        self,
        websocket: WebSocket
    ):
        """
        Connect dashboard client for full option chain.

        Endpoint:
            /ws-chain

        This websocket receives all CE/PE live ticks.
        """

        await websocket.accept()

        self.chain_clients.append(
            {
                "websocket": websocket
            }
        )

    def disconnect_chain(
        self,
        websocket: WebSocket
    ):
        """
        Disconnect dashboard option-chain websocket client.
        """

        self.chain_clients = [
            client
            for client in self.chain_clients
            if client["websocket"] != websocket
        ]

    def get_chain_client_count(self):
        """
        Number of connected option-chain dashboard clients.
        """

        return len(self.chain_clients)

    def get_active_candle_intervals_for_tick(
        self,
        strike: int,
        option_type: str
    ):
        """
        Return candle intervals currently requested by clients
        for the given strike and option type.

        Example:
            If clients connected with:

                /ws?strike=23450&type=ce&interval=5
                /ws?strike=23450&type=ce&interval=15

            returns:

                [5, 15]
        """

        intervals = set()

        for client in self.clients:
            if (
                client["interval"] > 0
                and client["strike"] == strike
                and client["type"] == option_type.lower()
            ):
                intervals.add(
                    client["interval"]
                )

        return sorted(intervals)

    async def broadcast_tick(
        self,
        tick: dict
    ):
        """
        Broadcast live ticks only to single-instrument clients
        where interval=0.
        """

        disconnected = []

        for client in self.clients:

            if (
                client["interval"] == 0
                and client["strike"] == tick.get("strike")
                and client["type"] == tick.get("type")
            ):
                try:
                    await client["websocket"].send_text(
                        json.dumps(tick)
                    )

                except Exception:
                    disconnected.append(
                        client["websocket"]
                    )

        for ws in disconnected:
            self.disconnect(ws)

    async def broadcast_candle(
        self,
        candle: dict
    ):
        """
        Broadcast closed candle updates to single-instrument clients
        where interval matches.

        Example candle:
            {
                "event": "candle",
                "status": "closed",
                "strike": 23450,
                "type": "ce",
                "interval": "1min"
            }
        """

        if not candle:
            return

        disconnected = []

        interval = int(
            candle["interval"].replace(
                "min",
                ""
            )
        )

        for client in self.clients:

            if (
                client["interval"] == interval
                and client["strike"] == candle.get("strike")
                and client["type"] == candle.get("type")
            ):
                try:
                    await client["websocket"].send_text(
                        json.dumps(candle)
                    )

                except Exception:
                    disconnected.append(
                        client["websocket"]
                    )

        for ws in disconnected:
            self.disconnect(ws)

    async def broadcast_chain(
        self,
        tick: dict
    ):
        """
        Broadcast every normalized live tick to dashboard clients.

        Endpoint:
            /ws-chain

        Dashboard receives all CE and PE ticks and updates
        both CE/PE tables in index.html.
        """

        disconnected = []

        for client in self.chain_clients:
            try:
                await client["websocket"].send_text(
                    json.dumps(tick)
                )

            except Exception:
                disconnected.append(
                    client["websocket"]
                )

        for ws in disconnected:
            self.disconnect_chain(ws)


ws_manager = WebSocketManager()