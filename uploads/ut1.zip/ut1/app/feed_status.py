from threading import Lock
from datetime import datetime, timezone

from app.logger import get_logger

logger = get_logger(__file__)


class FeedStatus:
    def __init__(self):
        self._lock = Lock()

        # All instruments loaded from MongoDB
        # key: instrument_key
        # value: meta
        self.loaded_instruments = {}

        # Instruments that received at least one tick
        # key: instrument_key
        # value: latest tick
        self.received_ticks = {}

        self.total_ticks = 0
        self.last_tick_time = None
        self.last_tick_iso = None

        self.stream = {
            "connected": False,
            "message": "Not started",
            "updated_at": None,
        }

    def set_loaded_instruments(self, instruments: dict):
        """
        Register all instruments loaded from MongoDB.

        Expected input:
            instrument_registry.key_to_meta

        Example:
            {
                "NSE_FO|63913": {
                    "strike": 23450,
                    "type": "ce",
                    "instrument_key": "NSE_FO|63913",
                    "trading_symbol": "NIFTY 23450 CE 28 JUL 26"
                }
            }
        """

        with self._lock:
            self.loaded_instruments = dict(instruments)
            self.received_ticks = {}
            self.total_ticks = 0
            self.last_tick_time = None
            self.last_tick_iso = None

        logger.info(
            "Feed status initialized with %s instruments",
            len(instruments)
        )

    def set_stream_status(
        self,
        connected: bool,
        message: str
    ):
        """
        Update Upstox websocket connection status.
        """

        now_iso = datetime.now(
            timezone.utc
        ).isoformat()

        with self._lock:
            self.stream = {
                "connected": connected,
                "message": message,
                "updated_at": now_iso,
            }

    def record_tick(
        self,
        instrument_key: str,
        tick: dict
    ):
        """
        Record that an instrument has received a tick.
        """

        tick_time = (
            tick.get("ltt")
            or tick.get("currentTs")
        )

        with self._lock:
            self.received_ticks[instrument_key] = tick
            self.total_ticks += 1

            if tick_time:
                self.last_tick_time = int(tick_time)
                self.last_tick_iso = datetime.fromtimestamp(
                    int(tick_time) / 1000,
                    tz=timezone.utc
                ).isoformat()

    def get_summary(self):
        """
        Returns full feed summary.

        Used by:
            GET /feed-summary
            GET /health
            Dashboard UI
        """

        with self._lock:
            loaded = dict(self.loaded_instruments)
            received = dict(self.received_ticks)

            total_loaded = len(loaded)
            receiving_ticks = len(received)
            no_tick_yet = total_loaded - receiving_ticks

            loaded_keys = set(loaded.keys())
            received_keys = set(received.keys())
            not_received_keys = loaded_keys - received_keys

            ce_loaded = 0
            pe_loaded = 0
            ce_receiving = 0
            pe_receiving = 0

            not_received_instruments = []

            for instrument_key, meta in loaded.items():
                option_type = str(
                    meta.get("type", "")
                ).lower()

                if option_type == "ce":
                    ce_loaded += 1

                    if instrument_key in received:
                        ce_receiving += 1

                elif option_type == "pe":
                    pe_loaded += 1

                    if instrument_key in received:
                        pe_receiving += 1

            for instrument_key in sorted(not_received_keys):
                meta = loaded.get(
                    instrument_key,
                    {}
                )

                not_received_instruments.append(
                    {
                        "strike": meta.get("strike"),
                        "type": meta.get("type"),
                        "instrument_key": instrument_key,
                        "trading_symbol": meta.get("trading_symbol"),
                        "lot_size": meta.get("lot_size"),
                        "exchange_token": meta.get("exchange_token"),
                    }
                )

            ce_no_tick = ce_loaded - ce_receiving
            pe_no_tick = pe_loaded - pe_receiving

            return {
                "stream": self.stream,

                "total_loaded": total_loaded,
                "receiving_ticks": receiving_ticks,
                "no_tick_yet": no_tick_yet,

                "total_ticks": self.total_ticks,
                "last_tick_time": self.last_tick_time,
                "last_tick_iso": self.last_tick_iso,

                "ce": {
                    "loaded": ce_loaded,
                    "receiving": ce_receiving,
                    "no_tick_yet": ce_no_tick,
                },

                "pe": {
                    "loaded": pe_loaded,
                    "receiving": pe_receiving,
                    "no_tick_yet": pe_no_tick,
                },

                "not_received_instruments": not_received_instruments,
            }


feed_status = FeedStatus()