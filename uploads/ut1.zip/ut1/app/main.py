import asyncio
import threading
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, Dict

import uvicorn
from fastapi import (
    FastAPI,
    WebSocket,
    WebSocketDisconnect,
    Query,
    Request,
)
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field, ConfigDict

from app.upstox_streamer import upstox_feed_service
from app.websocket_manager import ws_manager
from app.instrument_service import instrument_registry
from app.config import (
    HOST,
    PORT,
    MIN_CANDLE_INTERVAL,
    MAX_CANDLE_INTERVAL,
)
from app.logger import get_logger
from app.feed_status import feed_status

logger = get_logger(__file__)

# --------------------------------------------------
# Directory Paths
#
# Current folder structure:
#
# app/
#   static/
#     css/app.css
#     js/index.js
#   templates/
#     base.html
#     index.html
# --------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
TEMPLATES_DIR = BASE_DIR / "templates"


# --------------------------------------------------
# Swagger Models
# --------------------------------------------------
class SingleInstrumentWebSocketReference(BaseModel):
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "title": "Single Instrument WebSocket Feed",
                "description": "Use this WebSocket to stream live ticks or closed candles for one strike and option type.",
                "endpoint": "/ws",
                "full_url_format": "ws://localhost:8000/ws?strike=23450&type=ce&interval=0",
                "query_parameters": {
                    "strike": {
                        "type": "integer",
                        "required": True,
                        "example": 23450,
                        "description": "Option strike price"
                    },
                    "type": {
                        "type": "string",
                        "required": True,
                        "allowed_values": ["ce", "pe"],
                        "example": "ce",
                        "description": "Option type"
                    },
                    "interval": {
                        "type": "integer",
                        "required": False,
                        "example": 0,
                        "description": "0 = live ticks, 1 to 60 = closed candle interval in minutes"
                    }
                },
                "examples": {
                    "live_ticks": "ws://localhost:8000/ws?strike=23450&type=ce&interval=0",
                    "one_minute_closed_candle": "ws://localhost:8000/ws?strike=23450&type=ce&interval=1",
                    "five_minute_closed_candle": "ws://localhost:8000/ws?strike=23450&type=ce&interval=5",
                    "fifteen_minute_closed_candle": "ws://localhost:8000/ws?strike=23450&type=pe&interval=15",
                    "sixty_minute_closed_candle": "ws://localhost:8000/ws?strike=23450&type=pe&interval=60"
                },
                "live_tick_response_sample": {
                    "event": "tick",
                    "strike": 23450,
                    "type": "ce",
                    "instrument_key": "NSE_FO|63913",
                    "trading_symbol": "NIFTY 23450 CE 28 JUL 26",
                    "ltp": 382.6,
                    "ltt": 1784878490447,
                    "ltq": 65,
                    "cp": 442.9,
                    "currentTs": 1784878490646
                },
                "closed_candle_response_sample": {
                    "event": "candle",
                    "status": "closed",
                    "strike": 23450,
                    "type": "ce",
                    "instrument_key": "NSE_FO|63913",
                    "interval": "1min",
                    "bucket": 1784878440000,
                    "bucket_time": "2026-07-24T07:14:00+00:00",
                    "open": 384.5,
                    "high": 386.0,
                    "low": 380.2,
                    "close": 382.6,
                    "volume": 845,
                    "last_trade_time": 1784878490447
                },
                "notes": {
                    "interval_0": "Sends live ticks immediately.",
                    "interval_1_to_60": "Sends only closed candles. Example: 12:46 candle is sent only when 12:47 starts.",
                    "swagger_limitation": "Swagger UI documents this WebSocket API but does not open WebSocket connections directly. Use browser JS, Postman, WebSocket King, or Python websocket client."
                }
            }
        }
    )

    title: str
    description: str
    endpoint: str
    full_url_format: str
    query_parameters: Dict[str, Any]
    examples: Dict[str, str]
    live_tick_response_sample: Dict[str, Any]
    closed_candle_response_sample: Dict[str, Any]
    notes: Dict[str, str]


@asynccontextmanager
async def lifespan(app: FastAPI):
    loop = asyncio.get_running_loop()

    thread = threading.Thread(
        target=upstox_feed_service.start,
        args=(loop,),
        daemon=True
    )

    thread.start()

    logger.info(
        "Started Upstox feed service background thread"
    )

    yield

    logger.info(
        "Application shutdown initiated"
    )


app = FastAPI(
    title="Upstox Options WebSocket Service",
    description="""
Upstox live options feed service.

Features:
- Live tick WebSocket
- Closed candle interval WebSocket
- Single instrument WebSocket reference
- Option chain dashboard
- MongoDB instrument loading
- MongoDB access token loading
- Feed summary for tick-receiving and no-tick instruments

Candle behavior:
- interval=0 means live ticks.
- interval=1 to 60 means closed candles.
- Example: 12:46 candle is sent only when 12:47 starts.
""",
    version="1.0.0",
    lifespan=lifespan
)


# --------------------------------------------------
# Static Files
#
# Browser URLs:
# /static/css/app.css
# /static/js/index.js
# --------------------------------------------------
app.mount(
    "/static",
    StaticFiles(directory=str(STATIC_DIR)),
    name="static"
)


# --------------------------------------------------
# Templates
#
# Loads:
# app/templates/base.html
# app/templates/index.html
# --------------------------------------------------
templates = Jinja2Templates(
    directory=str(TEMPLATES_DIR)
)


@app.get(
    "/",
    tags=["Dashboard"],
    summary="Option Chain Dashboard"
)
async def index(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={}
    )


@app.get(
    "/api/info",
    tags=["System"],
    summary="Service Information"
)
def api_info():
    return {
        "status": "running",
        "service": "Upstox Options WebSocket Service",
        "dashboard": "/",
        "docs": "/docs",
        "health": "/health",
        "feed_summary": "/feed-summary",
        "websocket_reference": "/ws/single-instrument/reference",
        "interval_support": {
            "0": "live ticks",
            "min_candle_interval": MIN_CANDLE_INTERVAL,
            "max_candle_interval": MAX_CANDLE_INTERVAL,
            "candle_type": "closed candle only"
        },
        "websocket_endpoints": {
            "single_instrument_live": "/ws?strike=23450&type=ce&interval=0",
            "single_instrument_candle": "/ws?strike=23450&type=ce&interval=1",
            "single_instrument_reference": "/ws/single-instrument/reference",
            "option_chain": "/ws-chain",
        }
    }


@app.get(
    "/health",
    tags=["System"],
    summary="Health Check"
)
def health():
    summary = feed_status.get_summary()

    return {
        "status": "ok",
        "stream": summary.get("stream"),
        "loaded_instruments": len(
            instrument_registry.all_instruments()
        ),
        "connected_clients": ws_manager.get_client_count(),
        "chain_clients": ws_manager.get_chain_client_count(),
        "feed_summary": {
            "total_loaded": summary.get("total_loaded"),
            "receiving_ticks": summary.get("receiving_ticks"),
            "no_tick_yet": summary.get("no_tick_yet"),
            "total_ticks": summary.get("total_ticks"),
            "last_tick_time": summary.get("last_tick_time"),
        },
        "interval_support": {
            "0": "live ticks",
            "min_candle_interval": MIN_CANDLE_INTERVAL,
            "max_candle_interval": MAX_CANDLE_INTERVAL,
            "candle_type": "closed candle only"
        },
    }


@app.get(
    "/feed-summary",
    tags=["System"],
    summary="Feed Summary",
    description="""
Shows loaded instruments, instruments receiving ticks, instruments not receiving ticks yet,
CE/PE split, last tick time, and no-tick instrument details.
"""
)
def feed_summary():
    return feed_status.get_summary()


@app.get(
    "/instruments",
    tags=["Instruments"],
    summary="Get All Loaded Instruments"
)
def instruments():
    return instrument_registry.all_instruments()


@app.get(
    "/instrument",
    tags=["Instruments"],
    summary="Get One Instrument By Strike And Type"
)
def get_instrument(
    strike: int = Query(
        ...,
        examples={
            "default": {
                "summary": "NIFTY strike example",
                "value": 23450
            }
        },
        description="Option strike price"
    ),
    type: str = Query(
        ...,
        examples={
            "ce": {
                "summary": "Call option",
                "value": "ce"
            },
            "pe": {
                "summary": "Put option",
                "value": "pe"
            }
        },
        description="Option type: ce or pe"
    )
):
    meta = instrument_registry.get_by_strike_type(
        strike,
        type
    )

    if not meta:
        return {
            "found": False,
            "message": "Instrument not found"
        }

    return {
        "found": True,
        "instrument": meta
    }


@app.get(
    "/ws/help",
    tags=["WebSocket"],
    summary="WebSocket Usage Guide"
)
def websocket_help():
    return {
        "single_instrument_websocket": {
            "endpoint": "/ws",
            "reference": "/ws/single-instrument/reference",
            "description": (
                "Use this to stream one selected strike and option type. "
                "interval=0 gives live ticks. interval=1 to 60 gives closed candles only."
            ),
            "query_params": {
                "strike": 23450,
                "type": "ce or pe",
                "interval": "0 for live ticks, 1-60 for closed candles"
            },
            "candle_behavior": {
                "type": "closed candle",
                "example": "12:46 candle is sent only when 12:47 starts"
            },
            "examples": {
                "live_ticks": "ws://localhost:8000/ws?strike=23450&type=ce&interval=0",
                "one_minute_closed_candle": "ws://localhost:8000/ws?strike=23450&type=ce&interval=1",
                "five_minute_closed_candle": "ws://localhost:8000/ws?strike=23450&type=ce&interval=5",
                "fifteen_minute_closed_candle": "ws://localhost:8000/ws?strike=23450&type=pe&interval=15",
                "sixty_minute_closed_candle": "ws://localhost:8000/ws?strike=23450&type=pe&interval=60"
            }
        },
        "option_chain_websocket": {
            "endpoint": "/ws-chain",
            "description": "Use this to stream all CE and PE live ticks into the option chain dashboard.",
            "example": "ws://localhost:8000/ws-chain"
        },
        "summary_api": {
            "endpoint": "/feed-summary",
            "description": "Shows instruments receiving ticks and no-tick-yet instruments."
        }
    }


@app.get(
    "/ws/single-instrument/reference",
    tags=["WebSocket"],
    summary="Single Instrument WebSocket Reference",
    description="""
Reference documentation for connecting to a single instrument WebSocket feed.

Use this WebSocket endpoint when you want data for one specific strike and option type.

Modes:
- interval=0 gives live ticks.
- interval=1 to 60 gives closed candles only.
""",
    response_model=SingleInstrumentWebSocketReference
)
def single_instrument_websocket_reference():
    return {
        "title": "Single Instrument WebSocket Feed",
        "description": (
            "Use this WebSocket to stream live ticks or closed candles "
            "for one strike and option type."
        ),
        "endpoint": "/ws",
        "full_url_format": "ws://localhost:8000/ws?strike=23450&type=ce&interval=0",
        "query_parameters": {
            "strike": {
                "type": "integer",
                "required": True,
                "example": 23450,
                "description": "Option strike price"
            },
            "type": {
                "type": "string",
                "required": True,
                "allowed_values": ["ce", "pe"],
                "example": "ce",
                "description": "Option type"
            },
            "interval": {
                "type": "integer",
                "required": False,
                "example": 0,
                "description": "0 = live ticks, 1 to 60 = closed candle interval in minutes"
            }
        },
        "examples": {
            "live_ticks": "ws://localhost:8000/ws?strike=23450&type=ce&interval=0",
            "one_minute_closed_candle": "ws://localhost:8000/ws?strike=23450&type=ce&interval=1",
            "five_minute_closed_candle": "ws://localhost:8000/ws?strike=23450&type=ce&interval=5",
            "fifteen_minute_closed_candle": "ws://localhost:8000/ws?strike=23450&type=pe&interval=15",
            "sixty_minute_closed_candle": "ws://localhost:8000/ws?strike=23450&type=pe&interval=60"
        },
        "live_tick_response_sample": {
            "event": "tick",
            "strike": 23450,
            "type": "ce",
            "instrument_key": "NSE_FO|63913",
            "trading_symbol": "NIFTY 23450 CE 28 JUL 26",
            "ltp": 382.6,
            "ltt": 1784878490447,
            "ltq": 65,
            "cp": 442.9,
            "currentTs": 1784878490646
        },
        "closed_candle_response_sample": {
            "event": "candle",
            "status": "closed",
            "strike": 23450,
            "type": "ce",
            "instrument_key": "NSE_FO|63913",
            "interval": "1min",
            "bucket": 1784878440000,
            "bucket_time": "2026-07-24T07:14:00+00:00",
            "open": 384.5,
            "high": 386.0,
            "low": 380.2,
            "close": 382.6,
            "volume": 845,
            "last_trade_time": 1784878490447
        },
        "notes": {
            "interval_0": "Sends live ticks immediately.",
            "interval_1_to_60": (
                "Sends only closed candles. Example: "
                "12:46 candle is sent only when 12:47 starts."
            ),
            "swagger_limitation": (
                "Swagger UI documents this WebSocket API but does not open "
                "WebSocket connections directly. Use browser JS, Postman, "
                "WebSocket King, or Python websocket client."
            )
        }
    }


@app.websocket("/ws")
async def websocket_endpoint(
    websocket: WebSocket,
    strike: int,
    type: str,
    interval: int = 0
):
    option_type = type.lower()

    if option_type not in ["ce", "pe"]:
        await websocket.close(code=1008)
        return

    # interval=0 means live ticks
    # interval=1 to 60 means closed candles
    if interval != 0 and not (
        MIN_CANDLE_INTERVAL <= interval <= MAX_CANDLE_INTERVAL
    ):
        await websocket.close(code=1008)
        return

    await ws_manager.connect(
        websocket=websocket,
        strike=strike,
        option_type=option_type,
        interval=interval
    )

    try:
        while True:
            await asyncio.sleep(1)

    except WebSocketDisconnect:
        ws_manager.disconnect(websocket)

    except Exception:
        logger.exception(
            "Unexpected websocket error"
        )
        ws_manager.disconnect(websocket)


@app.websocket("/ws-chain")
async def websocket_chain_endpoint(
    websocket: WebSocket
):
    await ws_manager.connect_chain(
        websocket=websocket
    )

    try:
        while True:
            await asyncio.sleep(1)

    except WebSocketDisconnect:
        ws_manager.disconnect_chain(websocket)

    except Exception:
        logger.exception(
            "Unexpected option chain websocket error"
        )
        ws_manager.disconnect_chain(websocket)


if __name__ == "__main__":

    logger.info(
        "Starting server host=%s port=%s",
        HOST,
        PORT
    )

    uvicorn.run(
        app,
        host=HOST,
        port=PORT,
        reload=False,
        access_log=False
    )