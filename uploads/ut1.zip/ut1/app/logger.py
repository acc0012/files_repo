import logging
import sys
from pathlib import Path
from app.config import LOG_DIR, LOG_LEVEL


def get_logger(filename: str) -> logging.Logger:
    """Create a logger for each source file.

    Logs are saved to logs/{filename}.log and also printed to console.
    Example: get_logger(__file__) inside app/main.py creates logs/main.log.
    """
    log_path = Path(LOG_DIR)
    log_path.mkdir(parents=True, exist_ok=True)

    file_stem = Path(filename).stem
    logger_name = file_stem
    logger = logging.getLogger(logger_name)

    if logger.handlers:
        return logger

    level = getattr(logging, str(LOG_LEVEL).upper(), logging.INFO)
    logger.setLevel(level)
    logger.propagate = False

    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)s | %(name)s | %(funcName)s:%(lineno)d | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    file_handler = logging.FileHandler(log_path / f"{file_stem}.log", encoding="utf-8")
    file_handler.setLevel(level)
    file_handler.setFormatter(formatter)

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    console_handler.setFormatter(formatter)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger
