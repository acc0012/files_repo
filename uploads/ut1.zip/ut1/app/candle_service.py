from datetime import datetime, timezone
from app.logger import get_logger

logger = get_logger(__file__)


def epoch_ms_to_bucket(epoch_ms: int, interval_minutes: int) -> int:
    interval_ms = interval_minutes * 60 * 1000
    return epoch_ms - (epoch_ms % interval_ms)


class CandleService:
    def __init__(self):
        # Stores only active/running candles
        #
        # Key:
        #   (strike, option_type, interval_minutes)
        #
        # Value:
        #   current running candle
        self.candles = {}

    def update_tick(
        self,
        strike: int,
        option_type: str,
        instrument_key: str,
        ltp: float,
        ltq: int,
        ltt: int,
        interval_minutes: int
    ):
        """
        Update running candle with latest tick.

        Returns:
            None:
                if candle is still running.

            closed_candle:
                only when a new interval bucket starts.

        Example:
            12:46:01 to 12:46:59
                builds 12:46 candle internally.

            12:47:00 first tick
                returns completed 12:46 candle.
        """

        option_type = option_type.lower()

        current_bucket = epoch_ms_to_bucket(
            ltt,
            interval_minutes
        )

        active_key = (
            strike,
            option_type,
            interval_minutes
        )

        existing_candle = self.candles.get(
            active_key
        )

        # --------------------------------------------------
        # First tick for this strike/type/interval
        # Start new candle, but do not return anything yet.
        # --------------------------------------------------
        if existing_candle is None:
            self.candles[active_key] = self._create_candle(
                strike=strike,
                option_type=option_type,
                instrument_key=instrument_key,
                ltp=ltp,
                ltq=ltq,
                ltt=ltt,
                interval_minutes=interval_minutes,
                bucket=current_bucket
            )

            return None

        existing_bucket = existing_candle["bucket"]

        # --------------------------------------------------
        # Same bucket means same candle is still running.
        # Update OHLCV, but do not broadcast yet.
        # --------------------------------------------------
        if current_bucket == existing_bucket:
            existing_candle["high"] = max(
                existing_candle["high"],
                ltp
            )

            existing_candle["low"] = min(
                existing_candle["low"],
                ltp
            )

            existing_candle["close"] = ltp
            existing_candle["volume"] += ltq
            existing_candle["last_trade_time"] = ltt

            return None

        # --------------------------------------------------
        # Older tick received after new bucket already started.
        # Ignore it to avoid corrupting closed candles.
        # --------------------------------------------------
        if current_bucket < existing_bucket:
            logger.debug(
                "Ignoring old tick strike=%s type=%s interval=%s tick_bucket=%s active_bucket=%s",
                strike,
                option_type,
                interval_minutes,
                current_bucket,
                existing_bucket
            )

            return None

        # --------------------------------------------------
        # New bucket started.
        # Close previous candle and start new candle.
        # Return previous candle for broadcasting.
        # --------------------------------------------------
        closed_candle = existing_candle.copy()

        self.candles[active_key] = self._create_candle(
            strike=strike,
            option_type=option_type,
            instrument_key=instrument_key,
            ltp=ltp,
            ltq=ltq,
            ltt=ltt,
            interval_minutes=interval_minutes,
            bucket=current_bucket
        )

        return closed_candle

    def _create_candle(
        self,
        strike: int,
        option_type: str,
        instrument_key: str,
        ltp: float,
        ltq: int,
        ltt: int,
        interval_minutes: int,
        bucket: int
    ):
        return {
            "event": "candle",
            "status": "closed",
            "strike": strike,
            "type": option_type.lower(),
            "instrument_key": instrument_key,
            "interval": f"{interval_minutes}min",
            "bucket": bucket,
            "bucket_time": datetime.fromtimestamp(
                bucket / 1000,
                tz=timezone.utc
            ).isoformat(),
            "open": ltp,
            "high": ltp,
            "low": ltp,
            "close": ltp,
            "volume": ltq,
            "last_trade_time": ltt,
        }


candle_service = CandleService()