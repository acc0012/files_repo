/* =========================================================
   Upstox Option Chain Dashboard JavaScript
   ========================================================= */

let socket = null;

const ceData = {};
const peData = {};

const previousPrices = {};

let totalMessages = 0;

/* =========================================================
   Helpers
   ========================================================= */

function getWebSocketUrl() {
  const protocol = window.location.protocol === "https:" ? "wss://" : "ws://";

  return `${protocol}${window.location.host}/ws-chain`;
}

function formatTime(epochMs) {
  if (!epochMs) {
    return "-";
  }

  const date = new Date(Number(epochMs));

  return date.toLocaleTimeString("en-IN", {
    hour12: true,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}

function formatDateTime(epochMs) {
  if (!epochMs) {
    return "-";
  }

  const date = new Date(Number(epochMs));

  return date.toLocaleString("en-IN", {
    hour12: true,
  });
}

function getNumberValue(id, defaultValue) {
  const element = document.getElementById(id);

  if (!element || element.value === "") {
    return defaultValue;
  }

  return Number(element.value);
}

function isStrikeVisible(strike) {
  const strikeFrom = getNumberValue("strikeFrom", 0);
  const strikeTo = getNumberValue("strikeTo", 999999);

  const searchStrikeElement = document.getElementById("searchStrike");
  const searchStrike = searchStrikeElement ? searchStrikeElement.value : "";

  if (searchStrike) {
    return Number(strike) === Number(searchStrike);
  }

  return Number(strike) >= strikeFrom && Number(strike) <= strikeTo;
}

function updateLastUpdate() {
  const lastUpdate = document.getElementById("lastUpdate");

  if (lastUpdate) {
    lastUpdate.innerText = new Date().toLocaleTimeString("en-IN", {
      hour12: true,
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
  }
}

function updateCounts() {
  const ceCount = Object.keys(ceData).length;
  const peCount = Object.keys(peData).length;

  const ceCountElement = document.getElementById("ceCount");
  const peCountElement = document.getElementById("peCount");
  const totalCountElement = document.getElementById("totalCount");

  if (ceCountElement) {
    ceCountElement.innerText = ceCount;
  }

  if (peCountElement) {
    peCountElement.innerText = peCount;
  }

  if (totalCountElement) {
    totalCountElement.innerText = ceCount + peCount;
  }
}

function updateFeedBox(feed) {
  const feedBox = document.getElementById("feedBox");

  if (!feedBox) {
    return;
  }

  feedBox.textContent = JSON.stringify(feed, null, 4);
}

/* =========================================================
   Feed Summary
   ========================================================= */

async function loadFeedSummary() {
  try {
    const response = await fetch("/feed-summary");

    if (!response.ok) {
      return;
    }

    const summary = await response.json();

    updateFeedSummaryUI(summary);
  } catch (error) {
    console.error("Failed to load feed summary", error);
  }
}

function updateFeedSummaryUI(summary) {
  if (!summary) {
    return;
  }

  setText("summaryLoaded", summary.total_loaded ?? 0);
  setText("summaryReceiving", summary.receiving_ticks ?? 0);
  setText("summaryNoTick", summary.no_tick_yet ?? 0);
  setText("summaryTotalTicks", summary.total_ticks ?? 0);

  setText("summaryCeLoaded", summary.ce?.loaded ?? 0);
  setText("summaryCeReceiving", summary.ce?.receiving ?? 0);
  setText("summaryCeNoTick", summary.ce?.no_tick_yet ?? 0);

  setText("summaryPeLoaded", summary.pe?.loaded ?? 0);
  setText("summaryPeReceiving", summary.pe?.receiving ?? 0);
  setText("summaryPeNoTick", summary.pe?.no_tick_yet ?? 0);

  setText(
    "summaryLastTick",
    summary.last_tick_time ? formatDateTime(summary.last_tick_time) : "-",
  );

  renderNoTickTable(summary.not_received_instruments || []);
}

function setText(id, value) {
  const element = document.getElementById(id);

  if (element) {
    element.innerText = value;
  }
}

function renderNoTickTable(items) {
  const tbody = document.getElementById("noTickTableBody");

  if (!tbody) {
    return;
  }

  if (!items || items.length === 0) {
    tbody.innerHTML = `
            <tr>
                <td colspan="4" class="text-center text-muted py-3">
                    All instruments have received ticks
                </td>
            </tr>
        `;
    return;
  }

  let html = "";

  for (const item of items) {
    html += `
            <tr>
                <td>${item.strike ?? "-"}</td>
                <td>${String(item.type ?? "-").toUpperCase()}</td>
                <td>${item.trading_symbol ?? "-"}</td>
                <td>${item.instrument_key ?? "-"}</td>
            </tr>
        `;
  }

  tbody.innerHTML = html;
}

/* =========================================================
   Initial Instruments
   ========================================================= */

async function loadInitialInstruments() {
  try {
    const response = await fetch("/instruments");

    if (!response.ok) {
      return;
    }

    const instruments = await response.json();

    for (const item of instruments) {
      const row = {
        event: "tick",
        strike: item.strike,
        type: item.type,
        instrument_key: item.instrument_key,
        trading_symbol: item.trading_symbol,
        ltp: null,
        ltq: null,
        ltt: null,
        cp: null,
        currentTs: null,
      };

      if (item.type === "ce") {
        ceData[item.strike] = row;
      }

      if (item.type === "pe") {
        peData[item.strike] = row;
      }
    }

    renderTables();
    updateCounts();
  } catch (error) {
    console.error("Failed to load initial instruments", error);
  }
}

/* =========================================================
   WebSocket
   ========================================================= */

function connectSocket() {
  disconnectSocket();

  if (typeof showLoading === "function") {
    showLoading();
  }

  const wsUrl = getWebSocketUrl();

  socket = new WebSocket(wsUrl);

  socket.onopen = function () {
    if (typeof hideLoading === "function") {
      hideLoading();
    }

    if (typeof updateConnectionStatus === "function") {
      updateConnectionStatus(true);
    }

    if (typeof showToast === "function") {
      showToast("Connected to live option chain feed");
    }

    console.log("Connected:", wsUrl);
  };

  socket.onmessage = function (event) {
    try {
      const feed = JSON.parse(event.data);

      totalMessages += 1;

      handleFeed(feed);
    } catch (error) {
      console.error("Invalid websocket message", error);
    }
  };

  socket.onerror = function (error) {
    if (typeof hideLoading === "function") {
      hideLoading();
    }

    if (typeof updateConnectionStatus === "function") {
      updateConnectionStatus(false);
    }

    console.error("WebSocket error", error);

    if (typeof showToast === "function") {
      showToast("WebSocket error occurred");
    }
  };

  socket.onclose = function () {
    if (typeof hideLoading === "function") {
      hideLoading();
    }

    if (typeof updateConnectionStatus === "function") {
      updateConnectionStatus(false);
    }

    socket = null;

    console.log("WebSocket closed");
  };
}

function disconnectSocket() {
  if (socket) {
    socket.close();
    socket = null;
  }

  if (typeof updateConnectionStatus === "function") {
    updateConnectionStatus(false);
  }
}

/* =========================================================
   Feed Handler
   ========================================================= */

function handleFeed(feed) {
  if (!feed) {
    return;
  }

  if (feed.event !== "tick") {
    return;
  }

  if (!feed.strike || !feed.type) {
    return;
  }

  const optionType = String(feed.type).toLowerCase();

  if (optionType === "ce") {
    ceData[feed.strike] = feed;
  }

  if (optionType === "pe") {
    peData[feed.strike] = feed;
  }

  updateFeedBox(feed);
  renderTables();
  updateCounts();
  updateLastUpdate();
}

/* =========================================================
   Table Rendering
   ========================================================= */

function renderTables() {
  renderTable("ceTableBody", ceData, "ce");
  renderTable("peTableBody", peData, "pe");
}

function renderTable(tableBodyId, dataStore, optionType) {
  const tableBody = document.getElementById(tableBodyId);

  if (!tableBody) {
    return;
  }

  const rows = Object.values(dataStore)
    .filter((row) => isStrikeVisible(row.strike))
    .sort((a, b) => Number(a.strike) - Number(b.strike));

  let html = "";

  for (const row of rows) {
    const priceClass = getPriceClass(row);
    const rowClass = optionType === "ce" ? "ce-row" : "pe-row";

    const ltpText =
      row.ltp === null || row.ltp === undefined
        ? "-"
        : Number(row.ltp).toFixed(2);

    html += `
            <tr class="${rowClass}">
                <td class="strike-cell">
                    ${row.strike}
                </td>

                <td class="${priceClass}">
                    ${ltpText}
                </td>

                <td>
                    ${row.ltq ?? "-"}
                </td>

                <td class="symbol-cell" title="${row.trading_symbol ?? "-"}">
                    ${row.trading_symbol ?? "-"}
                </td>

                <td>
                    ${formatTime(row.ltt)}
                </td>
            </tr>
        `;
  }

  if (html === "") {
    html = `
            <tr>
                <td colspan="5" class="text-center text-muted py-4">
                    Waiting for feed...
                </td>
            </tr>
        `;
  }

  tableBody.innerHTML = html;
}

function getPriceClass(row) {
  if (row.ltp === null || row.ltp === undefined) {
    return "price-neutral";
  }

  const key = `${row.type}_${row.strike}`;

  const currentPrice = Number(row.ltp);
  const previousPrice = previousPrices[key];

  previousPrices[key] = currentPrice;

  if (previousPrice === undefined || previousPrice === currentPrice) {
    return "price-neutral";
  }

  if (currentPrice > previousPrice) {
    return "price-up";
  }

  return "price-down";
}

/* =========================================================
   Actions
   ========================================================= */

function clearTables() {
  Object.keys(ceData).forEach((key) => delete ceData[key]);
  Object.keys(peData).forEach((key) => delete peData[key]);
  Object.keys(previousPrices).forEach((key) => delete previousPrices[key]);

  totalMessages = 0;

  renderTables();
  updateCounts();

  const feedBox = document.getElementById("feedBox");

  if (feedBox) {
    feedBox.textContent = "Waiting for feed...";
  }

  const lastUpdate = document.getElementById("lastUpdate");

  if (lastUpdate) {
    lastUpdate.innerText = "-";
  }

  loadInitialInstruments();
  loadFeedSummary();
}

/* =========================================================
   Filter Events
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {
  loadInitialInstruments();
  loadFeedSummary();

  const strikeFrom = document.getElementById("strikeFrom");
  const strikeTo = document.getElementById("strikeTo");
  const searchStrike = document.getElementById("searchStrike");

  if (strikeFrom) {
    strikeFrom.addEventListener("input", renderTables);
  }

  if (strikeTo) {
    strikeTo.addEventListener("input", renderTables);
  }

  if (searchStrike) {
    searchStrike.addEventListener("input", renderTables);
  }
});

/* =========================================================
   Periodic Status Refresh
   ========================================================= */

setInterval(function () {
  loadFeedSummary();

  if (socket && socket.readyState === WebSocket.CLOSED) {
    if (typeof updateConnectionStatus === "function") {
      updateConnectionStatus(false);
    }
  }
}, 60000);
