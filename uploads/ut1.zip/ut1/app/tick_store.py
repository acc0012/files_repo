import json
from pathlib import Path

from app.config import TICK_FILE
from app.logger import get_logger

logger = get_logger(__file__)

# Ensure data directory exists
Path(TICK_FILE).parent.mkdir(
    parents=True,
    exist_ok=True
)


def save_raw_tick(tick: dict):
    """
    Save each incoming tick as a JSON Lines record.

    Example:
    {"type":"live_feed", ...}
    {"type":"live_feed", ...}
    """

    try:
        with open(
            TICK_FILE,
            "a",
            encoding="utf-8"
        ) as f:
            json.dump(
                tick,
                f,
                ensure_ascii=False
            )

            # New line separator for JSONL format
            f.write("\n")

    except Exception:
        logger.exception(
            "Failed to save raw tick into %s",
            TICK_FILE
        )