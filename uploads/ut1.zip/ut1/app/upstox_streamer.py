import asyncio
import upstox_client

from app.mongo_service import get_access_token
from app.instrument_service import instrument_registry
from app.tick_store import save_raw_tick
from app.candle_service import candle_service
from app.websocket_manager import ws_manager
from app.config import UPSTOX_MODE
from app.logger import get_logger

# Feed status tracker
# This file should be created separately as:
# app/feed_status.py
from app.feed_status import feed_status

logger = get_logger(__file__)


class UpstoxFeedService:
    def __init__(self):
        self.streamer = None
        self.loop = None
        self.instrument_keys = []

    def start(self, loop):
        self.loop = loop

        access_token = get_access_token()

        self.instrument_keys = instrument_registry.load_from_mongo()

        if not self.instrument_keys:
            logger.error("No instruments found for selected strike range")
            raise RuntimeError(
                "No instruments found for selected strike range"
            )

        # --------------------------------------------------
        # Register all loaded instruments into feed status.
        # This allows us to know:
        # - total loaded
        # - receiving ticks
        # - no tick yet
        # --------------------------------------------------
        feed_status.set_loaded_instruments(
            instrument_registry.key_to_meta
        )

        logger.info(
            "Loaded %s instruments",
            len(self.instrument_keys)
        )

        configuration = upstox_client.Configuration()
        configuration.access_token = access_token

        self.streamer = upstox_client.MarketDataStreamerV3(
            upstox_client.ApiClient(configuration)
        )

        def on_open():
            logger.info(
                "Upstox socket opened. Subscribing instruments=%s mode=%s",
                len(self.instrument_keys),
                UPSTOX_MODE
            )

            feed_status.set_stream_status(
                connected=True,
                message="Upstox socket opened"
            )

            self.streamer.subscribe(
                self.instrument_keys,
                UPSTOX_MODE
            )

        def on_message(message):
            self.handle_message(message)

        def on_error(error):
            logger.error(
                "Upstox socket error: %s",
                error
            )

            feed_status.set_stream_status(
                connected=False,
                message=str(error)
            )

        def on_close(*args):
            logger.warning(
                "Upstox socket closed: %s",
                args
            )

            feed_status.set_stream_status(
                connected=False,
                message="Upstox socket closed"
            )

        self.streamer.on("open", on_open)
        self.streamer.on("message", on_message)
        self.streamer.on("error", on_error)
        self.streamer.on("close", on_close)

        logger.info("Connecting to Upstox streamer")

        feed_status.set_stream_status(
            connected=False,
            message="Connecting to Upstox streamer"
        )

        self.streamer.connect()

    def handle_message(self, message: dict):
        save_raw_tick(message)

        feeds = message.get("feeds", {})

        if not feeds:
            msg_type = message.get("type")

            if msg_type:
                logger.debug(
                    "Ignoring non-feed message type=%s",
                    msg_type
                )

            return

        current_ts = int(
            message.get("currentTs", 0) or 0
        )

        for instrument_key, feed_data in feeds.items():

            meta = instrument_registry.get_by_key(
                instrument_key
            )

            if not meta:
                logger.debug(
                    "Received feed for unknown instrument_key=%s",
                    instrument_key
                )
                continue

            ltpc = feed_data.get("ltpc", {})

            if not ltpc:
                continue

            ltp = ltpc.get("ltp")

            if ltp is None:
                continue

            ltt = int(
                ltpc.get("ltt", current_ts) or current_ts
            )

            ltq = int(
                ltpc.get("ltq", 0) or 0
            )

            cp = ltpc.get("cp")

            normalized_tick = {
                "event": "tick",
                "strike": meta["strike"],
                "type": meta["type"],
                "instrument_key": instrument_key,
                "trading_symbol": meta["trading_symbol"],
                "ltp": float(ltp),
                "ltt": ltt,
                "ltq": ltq,
                "cp": cp,
                "currentTs": current_ts,
            }

            # --------------------------------------------------
            # Record tick status.
            #
            # This updates:
            # - total tick count
            # - instruments receiving ticks
            # - last tick time
            # - CE/PE receiving status
            # --------------------------------------------------
            feed_status.record_tick(
                instrument_key=instrument_key,
                tick=normalized_tick
            )

            # --------------------------------------------------
            # 1. Broadcast to single-strike live tick clients
            #
            # Example:
            # /ws?strike=23450&type=ce&interval=0
            # --------------------------------------------------
            asyncio.run_coroutine_threadsafe(
                ws_manager.broadcast_tick(
                    normalized_tick
                ),
                self.loop
            )

            # --------------------------------------------------
            # 2. Broadcast to option-chain dashboard clients
            #
            # Endpoint:
            # /ws-chain
            #
            # This sends all CE and PE live ticks to index.html.
            # --------------------------------------------------
            asyncio.run_coroutine_threadsafe(
                ws_manager.broadcast_chain(
                    normalized_tick
                ),
                self.loop
            )

            # --------------------------------------------------
            # 3. Closed candle generation
            #
            # Example:
            # /ws?strike=23450&type=ce&interval=1
            #
            # Behavior:
            # 12:46 candle is sent only when 12:47 starts.
            # 12:47 candle is sent only when 12:48 starts.
            # --------------------------------------------------
            active_intervals = (
                ws_manager.get_active_candle_intervals_for_tick(
                    strike=meta["strike"],
                    option_type=meta["type"]
                )
            )

            if not active_intervals:
                continue

            for interval in active_intervals:

                closed_candle = candle_service.update_tick(
                    strike=meta["strike"],
                    option_type=meta["type"],
                    instrument_key=instrument_key,
                    ltp=float(ltp),
                    ltq=ltq,
                    ltt=ltt,
                    interval_minutes=interval,
                )

                # candle_service.update_tick() returns None
                # while candle is still running.
                #
                # It returns a candle only when the previous
                # interval is completed.
                if closed_candle is None:
                    continue

                asyncio.run_coroutine_threadsafe(
                    ws_manager.broadcast_candle(
                        closed_candle
                    ),
                    self.loop
                )


upstox_feed_service = UpstoxFeedService()