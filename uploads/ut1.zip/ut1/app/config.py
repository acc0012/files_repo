import os
from pathlib import Path
from dotenv import load_dotenv

# Load .env values
load_dotenv()

# --------------------------------------------------
# MongoDB
# --------------------------------------------------
MONGO_URL = os.getenv("MONGO_URL", "mongodb://localhost:27017")
MONGO_DB = os.getenv("MONGO_DB", "UPSTOX_APP")

INSTRUMENTS_COLLECTION = os.getenv(
    "INSTRUMENTS_COLLECTION",
    "latest_instruments"
)

TOKENS_COLLECTION = os.getenv(
    "TOKENS_COLLECTION",
    "upstox_tokens"
)

# --------------------------------------------------
# Instrument Filter
# --------------------------------------------------
STRIKE_FROM = int(os.getenv("STRIKE_FROM", "23000"))
STRIKE_TO = int(os.getenv("STRIKE_TO", "25000"))

# --------------------------------------------------
# Upstox
# --------------------------------------------------
UPSTOX_MODE = os.getenv("UPSTOX_MODE", "ltpc")

# --------------------------------------------------
# Tick Storage
# --------------------------------------------------
TICK_FILE = os.getenv(
    "TICK_FILE",
    "data/ticks.jsonl"
)

# --------------------------------------------------
# Logging
# --------------------------------------------------
LOG_DIR = os.getenv("LOG_DIR", "logs")

LOG_LEVEL = os.getenv(
    "LOG_LEVEL",
    "INFO"
).upper()

# --------------------------------------------------
# FastAPI Server
# --------------------------------------------------
HOST = os.getenv("HOST", "0.0.0.0")
PORT = int(os.getenv("PORT", "8000"))

# --------------------------------------------------
# Candle Configuration
#
# interval = 0 => Live Ticks
# interval = 1-60 => Candles
# --------------------------------------------------
MIN_CANDLE_INTERVAL = int(
    os.getenv("MIN_CANDLE_INTERVAL", "1")
)

MAX_CANDLE_INTERVAL = int(
    os.getenv("MAX_CANDLE_INTERVAL", "60")
)

# --------------------------------------------------
# Runtime Directories
# --------------------------------------------------
Path(LOG_DIR).mkdir(
    parents=True,
    exist_ok=True
)

Path(TICK_FILE).parent.mkdir(
    parents=True,
    exist_ok=True
)

# --------------------------------------------------
# Validation
# --------------------------------------------------
if MIN_CANDLE_INTERVAL < 1:
    raise ValueError(
        "MIN_CANDLE_INTERVAL must be >= 1"
    )

if MAX_CANDLE_INTERVAL > 60:
    raise ValueError(
        "MAX_CANDLE_INTERVAL must be <= 60"
    )

if MIN_CANDLE_INTERVAL > MAX_CANDLE_INTERVAL:
    raise ValueError(
        "MIN_CANDLE_INTERVAL cannot be greater than MAX_CANDLE_INTERVAL"
    )