from app.config import STRIKE_FROM, STRIKE_TO
from app.mongo_service import get_latest_instruments_doc
from app.logger import get_logger

logger = get_logger(__file__)


class InstrumentRegistry:
    def __init__(self):
        self.instrument_map = {}
        self.key_to_meta = {}

    def load_from_mongo(self):
        logger.info("Loading instruments for strike range %s to %s", STRIKE_FROM, STRIKE_TO)
        doc = get_latest_instruments_doc()
        data = doc.get("data", {})

        self.instrument_map.clear()
        self.key_to_meta.clear()

        selected_keys = []

        for strike_text, strike_data in data.items():
            try:
                strike = int(strike_text)
            except (TypeError, ValueError):
                logger.warning("Skipping invalid strike key=%s", strike_text)
                continue

            if not (STRIKE_FROM <= strike <= STRIKE_TO):
                continue

            for option_type in ["ce", "pe"]:
                option_meta = strike_data.get(option_type)
                if not option_meta:
                    continue

                instrument_key = option_meta.get("instrument_key")
                if not instrument_key:
                    logger.warning("Missing instrument_key for strike=%s type=%s", strike, option_type)
                    continue

                normalized_type = option_type.lower()
                meta = {
                    "strike": strike,
                    "type": normalized_type,
                    "instrument_key": instrument_key,
                    "trading_symbol": option_meta.get("trading_symbol"),
                    "lot_size": option_meta.get("lot_size"),
                    "exchange_token": option_meta.get("exchange_token"),
                    "expiry": option_meta.get("expiry"),
                    "segment": option_meta.get("segment"),
                    "name": option_meta.get("name"),
                    "strike_price": option_meta.get("strike_price"),
                }

                self.instrument_map[(strike, normalized_type)] = meta
                self.key_to_meta[instrument_key] = meta
                selected_keys.append(instrument_key)

        logger.info("Selected %s instruments for subscription", len(selected_keys))
        return selected_keys

    def get_by_key(self, instrument_key: str):
        return self.key_to_meta.get(instrument_key)

    def get_by_strike_type(self, strike: int, option_type: str):
        return self.instrument_map.get((strike, option_type.lower()))

    def all_instruments(self):
        return list(self.instrument_map.values())


instrument_registry = InstrumentRegistry()
