@echo off
title Upstox Options WebSocket Service
cls
echo ==========================================
echo Starting Upstox Options WebSocket Service
echo ==========================================
echo.


python -m app.main

pause