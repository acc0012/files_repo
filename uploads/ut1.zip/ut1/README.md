# Upstox Options WebSocket Project

This project:

- Loads secrets/config from `.env`
- Fetches the Upstox access token from MongoDB collection `UPSTOX_APP.upstox_tokens`
- Fetches the latest instruments document from MongoDB collection `UPSTOX_APP.latest_instruments`
- Filters strikes between `STRIKE_FROM` and `STRIKE_TO`
- Subscribes to both CE and PE instrument keys using Upstox `MarketDataStreamerV3`
- Saves every raw tick into `data/ticks.jsonl`
- Exposes your own FastAPI WebSocket endpoint for live ticks and candles
- Adds per-file logging into `logs/{filename}.log` and also prints logs on console

## 1. Setup

```bash
cd upstox_ws_project
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Edit `.env` and set your actual MongoDB URL.

## 2. Expected MongoDB collections

### Access token collection

Database: `UPSTOX_APP`  
Collection: `upstox_tokens`

```json
{
  "_id": "upstox_access_token",
  "access_token": "YOUR_ACCESS_TOKEN",
  "updated_at": "2026-07-24T08:59:06.205823+05:30"
}
```

### Instruments collection

Database: `UPSTOX_APP`  
Collection: `latest_instruments`

Only one document is expected. It should contain a `data` object where each strike has `ce` and `pe` objects.

## 3. Run

```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Or:

```bash
python -m app.main
```

## 4. WebSocket URLs

### Live ticks

```text
ws://localhost:8000/ws?strike=23450&type=ce&interval=0
```

### 1-minute candles

```text
ws://localhost:8000/ws?strike=23450&type=ce&interval=1
```

### 3-minute candles

```text
ws://localhost:8000/ws?strike=23450&type=pe&interval=3
```

### 5-minute candles

```text
ws://localhost:8000/ws?strike=23450&type=pe&interval=5
```

## 5. REST endpoints

```text
GET /
GET /health
GET /instruments
GET /instrument?strike=23450&type=ce
```

## 6. Logs

Each Python file creates its own log file in:

```text
logs/{filename}.log
```

Examples:

```text
logs/main.log
logs/upstox_streamer.log
logs/mongo_service.log
logs/instrument_service.log
```

The logger also prints to console, so all important events are visible in terminal and saved to files.

## 7. Tick storage

Raw feed messages are appended as JSON Lines to:

```text
data/ticks.jsonl
```

Each line is one complete JSON object.

## Notes

- `interval=0` means send every live tick.
- `interval=1`, `3`, or `5` means send running OHLC candle updates.
- The implementation ignores `market_info` messages for candle/tick processing and only processes messages containing `feeds`.
- Do not commit your real `.env` file or access token.
