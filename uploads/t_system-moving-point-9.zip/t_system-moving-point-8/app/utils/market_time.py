from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

IST = ZoneInfo("Asia/Kolkata")

MARKET_START = (9 * 60) + 15   # 9:15 AM
MARKET_END = (15 * 60) + 40    # 3:40 PM


def is_market_open():
    now = datetime.now(IST)
    minutes = now.hour * 60 + now.minute
    return MARKET_START <= minutes <= MARKET_END


def get_next_market_open():
    now = datetime.now(IST)

    today_open = now.replace(hour=9, minute=15, second=0, microsecond=0)

    # If before today open
    if now < today_open:
        return today_open

    # If after market close → next day
    tomorrow = now + timedelta(days=1)

    return tomorrow.replace(hour=9, minute=15, second=0, microsecond=0)


def get_wait_seconds():
    now = datetime.now(IST)
    next_open = get_next_market_open()

    return (next_open - now).total_seconds(), next_open
