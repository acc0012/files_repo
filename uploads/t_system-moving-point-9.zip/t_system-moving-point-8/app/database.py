from pymongo import MongoClient

from app.config import settings
from app.logger import logger


try:

    logger.info(
        "Initializing MongoDB connection"
    )

    if not settings.MONGO_URL:
        raise ValueError(
            "MongoDB URL is missing"
        )

    if not settings.MONGO_DB:
        raise ValueError(
            "MongoDB database name is missing"
        )

    if not settings.MONGO_COLLECTION:
        raise ValueError(
            "MongoDB collection name is missing"
        )

    client = MongoClient(
        settings.MONGO_URL,
        serverSelectionTimeoutMS=5000
    )

    client.admin.command("ping")

    logger.info(
        "MongoDB connection established successfully"
    )

    db = client[
        settings.MONGO_DB
    ]

    collection = db[
        settings.MONGO_COLLECTION
    ]

    logger.info(
        "MongoDB collection initialized successfully"
    )

except ValueError as e:

    logger.error(
        f"MongoDB configuration error: {str(e)}"
    )

    raise

except Exception as e:

    logger.exception(
        f"MongoDB initialization failed: {str(e)}"
    )

    raise