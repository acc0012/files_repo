from app.database import client
from app.config import settings
from app.cache import OPTION_CACHE
from app.logger import logger


def load_option_master():

    try:

        logger.info(
            "Option chain cache loading initiated"
        )

        if not settings.MONGO_OPTION_CHAIN_DB:

            raise ValueError(
                "MONGO_OPTION_CHAIN_DB is missing"
            )

        if not settings.MONGO_OPTION_COLLECTION:

            raise ValueError(
                "MONGO_OPTION_COLLECTION is missing"
            )

        logger.info(
            f"Connecting to database : "
            f"{settings.MONGO_OPTION_CHAIN_DB}"
        )

        db = client[
            settings.MONGO_OPTION_CHAIN_DB
        ]

        logger.info(
            f"Using collection : "
            f"{settings.MONGO_OPTION_COLLECTION}"
        )

        collection = db[
            settings.MONGO_OPTION_COLLECTION
        ]

        logger.info(
            "Fetching option chain documents"
        )

        docs = list(
            collection.find(
                {},
                {
                    "_id": 0
                }
            )
        )

        total_docs = len(docs)

        logger.info(
            f"Fetched {total_docs} option chain documents"
        )

        OPTION_CACHE.clear()

        logger.info(
            "Existing cache cleared"
        )

        loaded_count = 0
        skipped_count = 0

        for doc in docs:

            try:

                index_security_id = doc.get(
                    "index_security_id"
                )

                if index_security_id is None:

                    skipped_count += 1

                    logger.warning(
                        "Document skipped because "
                        "index_security_id is missing"
                    )

                    continue

                OPTION_CACHE[
                    int(index_security_id)
                ] = doc

                loaded_count += 1

            except Exception as e:

                skipped_count += 1

                logger.exception(
                    f"Failed processing option chain document : "
                    f"{str(e)}"
                )

        logger.info(
            f"Cache loading completed. "
            f"Loaded={loaded_count}, "
            f"Skipped={skipped_count}"
        )

        logger.info(
            f"Current cache size : "
            f"{len(OPTION_CACHE)}"
        )

        logger.info(
            f"Cached index ids : "
            f"{list(OPTION_CACHE.keys())}"
        )

        return loaded_count

    except ValueError as e:

        logger.error(
            f"Configuration error : {str(e)}"
        )

        raise

    except Exception as e:

        logger.exception(
            f"Option chain cache loading failed : {str(e)}"
        )

        raise

    finally:

        logger.info(
            "Option chain cache loading finished"
        )