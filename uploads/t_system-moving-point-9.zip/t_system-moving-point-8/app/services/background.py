from app.services.save_or import save_opening_range
from app.logger import logger


def process_opening_range(
    trace_id: str,
    payload: dict
):

    try:

        logger.info(
            f"[{trace_id}] Background processing started"
        )

        inserted_id = save_opening_range(
            trace_id,
            payload
        )

        logger.info(
            f"[{trace_id}] Background processing completed"
        )

        logger.info(
            f"[{trace_id}] Mongo document created"
        )

        return {
            "success": True,
            "trace_id": trace_id,
            "mongo_id": inserted_id
        }

    except Exception as e:

        logger.exception(
            f"[{trace_id}] Background processing failed : {str(e)}"
        )

        raise

    finally:

        logger.info(
            f"[{trace_id}] Background processing finished"
        )