from app.cache import OPTION_CACHE
from app.logger import logger


def get_security_id(
    index_security_id: int,
    strike: int,
    option_type: str
):

    try:

        logger.info(
            f"Lookup started "
            f"index_security_id={index_security_id}, "
            f"strike={strike}, "
            f"option_type={option_type}"
        )

        doc = OPTION_CACHE.get(
            int(index_security_id)
        )

        if not doc:

            raise ValueError(
                f"Index security id "
                f"{index_security_id} not found"
            )

        option_chain = (
            doc.get(
                "option_chain",
                {}
            )
        )

        oc = option_chain.get(
            "oc",
            {}
        )

        strike_key = (
            f"{float(strike):.6f}"
        )

        strike_data = oc.get(
            strike_key
        )

        if not strike_data:

            raise ValueError(
                f"Strike {strike} not found"
            )

        option_type = (
            option_type.lower()
        )

        if option_type not in [
            "ce",
            "pe"
        ]:

            raise ValueError(
                "option_type must be CE or PE"
            )

        option_data = strike_data.get(
            option_type
        )

        if not option_data:

            raise ValueError(
                f"{option_type.upper()} data not found"
            )

        security_id = option_data.get(
            "security_id"
        )

        if not security_id:

            raise ValueError(
                "security_id not found"
            )

        logger.info(
            f"Lookup successful. "
            f"security_id={security_id}"
        )

        return security_id

    except Exception as e:

        logger.exception(
            f"Security lookup failed : {str(e)}"
        )

        raise

    finally:

        logger.info(
            "Security lookup finished"
        )