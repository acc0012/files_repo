import asyncio
import json
from datetime import datetime
from zoneinfo import ZoneInfo

import websockets
import anyio

from app.logger import logger
from app.cache import OPTION_LIVE_CACHE
from app.config import settings
from app.utils.market_time import is_market_open, get_wait_seconds

IST = ZoneInfo("Asia/Kolkata")

# ==========================================================
# ACTIVE OPTION SOCKET TASKS
# ==========================================================

ACTIVE_OPTION_TASKS = {}

# ==========================================================
# OPTION MARKET WEBSOCKET LISTENER
# ==========================================================


async def listen_option_feed(security_id: int, symbol: str):

    url = f"{settings.BASE_WS_URL}/ws/market/{security_id}/"

    # ==========================================
    # MARKET HOURS CHECK (SKIP LOGIC)
    # ==========================================

    if not is_market_open():

        wait_seconds, next_open = get_wait_seconds()
        hours = round(wait_seconds / 3600, 2)

        logger.info(
            f"[OPTION SKIP] {symbol} | "
            f"market closed | "
            f"current_time={datetime.now(IST).strftime('%Y-%m-%d %H:%M:%S')} | "
            f"next_open={next_open.strftime('%Y-%m-%d %H:%M:%S')} | "
            f"wait_hours={hours}"
        )
        return

    last_heartbeat = 0

    while True:
        try:
            logger.info(f"Connecting option socket {symbol} -> {url}")

            async with websockets.connect(url, ping_interval=20, ping_timeout=20) as ws:

                logger.info(f"Option socket connected : {symbol}")

                async for message in ws:

                    if not is_market_open():
                        logger.info(f"{symbol} market closed during live feed")
                        return

                    try:
                        obj = json.loads(message)

                        now = asyncio.get_running_loop().time()

                        # ======================================
                        # HEARTBEAT
                        # ======================================
                        if now - last_heartbeat >= int(settings.HEART_BEAT_INTERVAL):
                            logger.info(
                                f"[OPTION HEARTBEAT] "
                                f"{symbol} | "
                                f"LTP={obj.get('LTP')} | "
                                f"LTT={obj.get('LTT')}"
                            )
                            last_heartbeat = now

                        # ======================================
                        # CACHE UPDATE
                        # ======================================
                        OPTION_LIVE_CACHE[security_id] = {
                            "symbol": symbol,
                            "security_id": security_id,
                            "feed_security_id": obj.get("security_id"),
                            "exchange_segment": obj.get("exchange_segment"),
                            "type": obj.get("type"),
                            "ltp": float(obj.get("LTP") or 0),
                            "ltq": int(obj.get("LTQ") or 0),
                            "ltt": obj.get("LTT"),
                            "open": float(obj.get("open") or 0),
                            "high": float(obj.get("high") or 0),
                            "low": float(obj.get("low") or 0),
                            "close": float(obj.get("close") or 0),
                            "avg_price": float(obj.get("avg_price") or 0),
                            "volume": int(obj.get("volume") or 0),
                            "total_buy_quantity": int(
                                obj.get("total_buy_quantity") or 0
                            ),
                            "total_sell_quantity": int(
                                obj.get("total_sell_quantity") or 0
                            ),
                            "updated_at": obj.get("LTT"),
                        }

                    except Exception as e:
                        logger.exception(f"{symbol} message parse failed : {str(e)}")

        except Exception as e:
            logger.exception(f"{symbol} websocket failed : {str(e)}")
            logger.info(f"Reconnecting option socket {symbol} in 5 seconds...")
            await asyncio.sleep(5)


# ==========================================================
# START OPTION SOCKET (THREAD‑SAFE ✅)
# ==========================================================


def start_option_listener(security_id: int, symbol: str):

    existing_task = ACTIVE_OPTION_TASKS.get(security_id)

    if existing_task:
        logger.info(f"Option socket already active : {symbol}")
        return

    try:
        # ✅ SAFE for BackgroundTasks / AnyIO thread
        result = anyio.from_thread.run(listen_option_feed, security_id, symbol)

        ACTIVE_OPTION_TASKS[security_id] = result

        logger.info(f"Option websocket task started (thread-safe) : {symbol}")

    except Exception as e:
        logger.exception(f"Failed starting option socket {symbol} : {str(e)}")


# ==========================================================
# STOP OPTION SOCKET
# ==========================================================


async def stop_option_listener(security_id: int):

    task = ACTIVE_OPTION_TASKS.get(security_id)

    if not task:
        return

    try:
        task.cancel()
    except Exception:
        pass

    ACTIVE_OPTION_TASKS.pop(security_id, None)
    OPTION_LIVE_CACHE.pop(security_id, None)

    logger.info(f"Option socket stopped security_id={security_id}")
