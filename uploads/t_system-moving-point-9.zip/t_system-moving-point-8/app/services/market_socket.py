import asyncio
import json
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from uuid import uuid4

import websockets

from app.logger import logger
from app.cache.live_market import LIVE_MARKET_CACHE
from app.cache import AUTOMATED_OR_STATUS
from app.config import settings
from app.utils.market_time import is_market_open, get_wait_seconds
from app.services.intraday_fetcher import fetch_intraday_data, calculate_levels
from app.services.background import process_opening_range

IST = ZoneInfo("Asia/Kolkata")

# =====================================================
# MARKET FEED WEBSOCKET LISTENER
# =====================================================


async def listen_market_feed(security_id: int, index_name: str):

    url = f"{settings.BASE_WS_URL}/ws/market/{security_id}/"
    last_heartbeat = 0

    # -------------------------------------------------
    # AUTOMATION CONFIG
    # -------------------------------------------------
    instrument_cfg = next(
        (i for i in settings.INSTRUMENTS if i["security_id"] == security_id),
        None,
    )

    automation_enabled = bool(instrument_cfg and instrument_cfg.get("automation"))
    timeframe_minutes = instrument_cfg.get("timeframe", 5) if instrument_cfg else None

    logger.info(
        f"{index_name} automation_enabled={automation_enabled} "
        f"timeframe={timeframe_minutes}"
    )

    while True:
        try:
            # ==========================================
            # MARKET HOURS CHECK
            # ==========================================
            if not is_market_open():
                wait_seconds, next_open = get_wait_seconds()

                logger.info(
                    f"{index_name} market closed | "
                    f"current_time={datetime.now(IST).strftime('%Y-%m-%d %H:%M:%S')} | "
                    f"next_open={next_open.strftime('%Y-%m-%d %H:%M:%S')}"
                )

                await asyncio.sleep(wait_seconds)
                continue

            # ==========================================
            # CONNECT SOCKET
            # ==========================================
            logger.info(f"Connecting {index_name} -> {url}")

            async with websockets.connect(url, ping_interval=20, ping_timeout=20) as ws:
                logger.info(f"{index_name} connected")

                async for message in ws:
                    try:
                        if not is_market_open():
                            logger.info(f"{index_name} market closed during live feed")
                            break

                        obj = json.loads(message)

                        now = datetime.now(IST)
                        today = now.strftime("%Y-%m-%d")

                        # ======================================
                        # HEARTBEAT
                        # ======================================
                        loop_time = asyncio.get_running_loop().time()
                        if loop_time - last_heartbeat >= int(
                            settings.HEART_BEAT_INTERVAL
                        ):
                            logger.info(
                                f"[HEARTBEAT] {index_name} | "
                                f"LTP={obj.get('LTP')} | "
                                f"LTT={obj.get('LTT')}"
                            )
                            last_heartbeat = loop_time

                        # ======================================
                        # CACHE UPDATE
                        # ======================================
                        LIVE_MARKET_CACHE[security_id] = {
                            "type": obj.get("type"),
                            "exchange_segment": obj.get("exchange_segment"),
                            "security_id": security_id,
                            "feed_security_id": obj.get("security_id"),
                            "index_name": index_name,
                            "ltp": float(obj.get("LTP") or 0),
                            "ltq": int(obj.get("LTQ") or 0),
                            "ltt": obj.get("LTT"),
                            "avg_price": float(obj.get("avg_price") or 0),
                            "open": float(obj.get("open") or 0),
                            "high": float(obj.get("high") or 0),
                            "low": float(obj.get("low") or 0),
                            "close": float(obj.get("close") or 0),
                            "volume": int(obj.get("volume") or 0),
                            "total_buy_quantity": int(
                                obj.get("total_buy_quantity") or 0
                            ),
                            "total_sell_quantity": int(
                                obj.get("total_sell_quantity") or 0
                            ),
                            "updated_at": obj.get("LTT"),
                        }

                        # ======================================
                        # ✅ AUTOMATED OPENING RANGE
                        # ======================================
                        if (
                            automation_enabled
                            and AUTOMATED_OR_STATUS.get(security_id) != today
                        ):
                            market_start = now.replace(
                                hour=9, minute=15, second=0, microsecond=0
                            )

                            trigger_time = market_start + timedelta(
                                minutes=timeframe_minutes
                            )

                            if now >= trigger_time:
                                trace_id = f"AUTO-{uuid4()}"

                                logger.info(
                                    f"[{trace_id}] Automated OR triggered | "
                                    f"{index_name} window=09:15→"
                                    f"{(market_start + timedelta(minutes=timeframe_minutes)).strftime('%H:%M')}"
                                )

                                intraday = fetch_intraday_data(
                                    security_id=security_id,
                                    exchange_segment=settings.INDEX_EXCHANGE_SEGMENT,
                                    instrument_type=settings.INDEX_INSTRUMENT_TYPE,
                                    from_date=today,
                                    to_date=today,
                                )

                                if not intraday.get("success"):
                                    logger.error(
                                        f"[{trace_id}] Intraday fetch failed "
                                        f"{index_name}"
                                    )
                                    AUTOMATED_OR_STATUS[security_id] = today
                                    continue

                                # ✅ DYNAMIC TIMEFRAME CALCULATION
                                raw = intraday.get("raw_market_data", {})
                                highs = raw.get("high", [])
                                lows = raw.get("low", [])

                                if len(highs) < timeframe_minutes:
                                    logger.warning(
                                        f"[{trace_id}] Not enough candles "
                                        f"{index_name} tf={timeframe_minutes}"
                                    )
                                    continue

                                or_high = max(highs[:timeframe_minutes])
                                or_low = min(lows[:timeframe_minutes])

                                first_tf = calculate_levels(or_high, or_low)

                                payload = {
                                    "TYPE": "OPENING_RANGE",
                                    "HIGH": first_tf["HIGH"],
                                    "LOW": first_tf["LOW"],
                                    "AVG": first_tf["AVG"],
                                    "RESISTANCE2": first_tf["RESISTANCE2"],
                                    "SUPPORT2": first_tf["SUPPORT2"],
                                    "RESISTANCE3": first_tf["RESISTANCE3"],
                                    "SUPPORT3": first_tf["SUPPORT3"],
                                    "FROM_DATE": today,
                                    "TO_DATE": today,
                                    "INDEX_SECURITY_ID": security_id,
                                }

                                # ✅ NON‑BLOCKING PIPELINE
                                asyncio.create_task(
                                    asyncio.to_thread(
                                        process_opening_range,
                                        trace_id,
                                        payload,
                                    )
                                )

                                AUTOMATED_OR_STATUS[security_id] = today

                                logger.info(
                                    f"[{trace_id}] Automated OR submitted "
                                    f"{index_name}"
                                )

                    except Exception as e:
                        logger.exception(f"{index_name} message processing error : {e}")

        except Exception as e:
            logger.exception(f"{index_name} socket error : {e}")
            logger.info(f"Reconnecting {index_name} in 5 seconds...")
            await asyncio.sleep(5)
