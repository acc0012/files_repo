from app.logger import logger

from app.services.security_lookup import get_security_id


def build_security_mapping(index_security_id: int, parsed: dict):

    try:

        logger.info(
            f"Strike mapping started " f"for index_security_id=" f"{index_security_id}"
        )

        mapping = {}

        for label, level_data in parsed.items():

            raw_value = level_data.get("raw_value")

            lower_strike = level_data.get("lower_strike")

            upper_strike = level_data.get("upper_strike")

            try:

                logger.info(
                    f"Processing {label} "
                    f"lower_strike={lower_strike}, "
                    f"upper_strike={upper_strike}"
                )

                # ==================================================
                # LOWER STRIKE
                # ==================================================

                lower_ce_security_id = get_security_id(
                    index_security_id, lower_strike, "CE"
                )

                lower_pe_security_id = get_security_id(
                    index_security_id, lower_strike, "PE"
                )

                # ==================================================
                # UPPER STRIKE
                # ==================================================

                upper_ce_security_id = get_security_id(
                    index_security_id, upper_strike, "CE"
                )

                upper_pe_security_id = get_security_id(
                    index_security_id, upper_strike, "PE"
                )

                # ==================================================
                # FINAL MAPPING
                # ==================================================

                mapping[label] = {
                    "raw_value": raw_value,
                    "lower_strike": lower_strike,
                    "upper_strike": upper_strike,
                    # ----------------------------------------------
                    # META DATA ONLY
                    # ----------------------------------------------
                    "lower_strike_data": {
                        "ce_security_id": lower_ce_security_id,
                        "pe_security_id": lower_pe_security_id,
                    },
                    "upper_strike_data": {
                        "ce_security_id": upper_ce_security_id,
                        "pe_security_id": upper_pe_security_id,
                    },
                }

                logger.info(
                    f"{label} mapped successfully. "
                    f"LOWER_CE={lower_ce_security_id}, "
                    f"LOWER_PE={lower_pe_security_id}, "
                    f"UPPER_CE={upper_ce_security_id}, "
                    f"UPPER_PE={upper_pe_security_id}"
                )

            except Exception as e:

                logger.exception(f"Failed mapping " f"{label} : " f"{str(e)}")

                mapping[label] = {
                    "raw_value": raw_value,
                    "lower_strike": lower_strike,
                    "upper_strike": upper_strike,
                    "lower_strike_data": {
                        "ce_security_id": None,
                        "pe_security_id": None,
                    },
                    "upper_strike_data": {
                        "ce_security_id": None,
                        "pe_security_id": None,
                    },
                    "error": str(e),
                }

        logger.info(f"Strike mapping completed. " f"Total mapped={len(mapping)}")

        return mapping

    except Exception as e:

        logger.exception(f"Strike mapping failed : " f"{str(e)}")

        raise

    finally:

        logger.info("Strike mapping finished")
