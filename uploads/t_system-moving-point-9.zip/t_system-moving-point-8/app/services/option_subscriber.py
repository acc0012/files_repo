import requests

from app.logger import logger
from app.config import settings


def subscribe_option_marketfeed(trace_id: str, security_mapping: dict):

    try:

        logger.info(f"[{trace_id}] Option subscription started")

        instruments = []
        added = set()

        # ==================================================
        # LOOP LEVELS
        # ==================================================

        for level_name, level_data in security_mapping.items():

            lower_data = level_data.get("lower_strike_data", {})
            upper_data = level_data.get("upper_strike_data", {})

            # Collect all security IDs
            all_security_ids = [
                lower_data.get("ce_security_id"),
                lower_data.get("pe_security_id"),
                upper_data.get("ce_security_id"),
                upper_data.get("pe_security_id"),
            ]

            # ==================================================
            # BUILD INSTRUMENT LIST
            # ==================================================

            for security_id in all_security_ids:

                if not security_id:
                    continue

                if security_id in added:
                    continue

                instruments.append(
                    {
                        "segment": settings.OPTION_EXCHANGE_SEGMENT,
                        "security_id": str(security_id),
                        "type": "Quote",
                    }
                )

                added.add(security_id)

        # ==================================================
        # NO INSTRUMENTS CASE
        # ==================================================

        if not instruments:

            logger.warning(f"[{trace_id}] No instruments found for subscription")

            return {
                "success": False,
                "message": "No instruments",
            }

        # ==================================================
        # API CALL
        # ==================================================

        url = f"{settings.BASE_URL}/marketfeed/subscribe/"

        payload = {"instruments": instruments}

        logger.info(f"[{trace_id}] Subscribing {len(instruments)} instruments")

        response = requests.post(url, json=payload, timeout=settings.REQUEST_TIMEOUT)

        logger.info(f"[{trace_id}] Subscription response status={response.status_code}")

        response.raise_for_status()

        response_json = response.json()

        logger.info(f"[{trace_id}] Subscription successful count={len(instruments)}")

        return {
            "success": True,
            "count": len(instruments),
            "response": response_json,
        }

    except Exception as e:

        logger.exception(f"[{trace_id}] Option subscription failed : {str(e)}")

        return {
            "success": False,
            "error": str(e),
        }

    finally:

        logger.info(f"[{trace_id}] Option subscription finished")
