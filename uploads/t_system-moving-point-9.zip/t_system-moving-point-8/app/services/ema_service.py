import asyncio
import json
from datetime import datetime
from zoneinfo import ZoneInfo
import anyio
import requests
import websockets

from app.cache import EMA_CACHE
from app.cache import EMA_SIGNALS
from app.cache import EMA_TASKS

from app.config import settings
from app.logger import logger
from app.database import collection

# ==========================================================
# EMA CONFIG
# ==========================================================

EMA_FAST = 9

EMA_SLOW = 21

IST = ZoneInfo("Asia/Kolkata")

# ==========================================================
# MARKET HOURS
# ==========================================================


def is_market_open():

    now = datetime.now(IST)

    current_minutes = (now.hour * 60) + now.minute

    market_start = (9 * 60) + 15

    market_end = (15 * 60) + 40

    return market_start <= current_minutes <= market_end


# ==========================================================
# EMA HELPERS
# ==========================================================


def calculate_ema_value(previous_ema: float, close_price: float, period: int):

    multiplier = 2 / (period + 1)

    return (close_price * multiplier) + (previous_ema * (1 - multiplier))


# ==========================================================
# LOAD INITIAL HISTORY
# ==========================================================


def load_historical_data(security_id: int):

    logger.info(f"EMA history loading started " f"security_id={security_id}")

    today = datetime.now(IST).strftime("%Y-%m-%d")

    url = f"{settings.BASE_URL}/dhan/intraday/"

    params = {
        "security_id": security_id,
        "exchange_segment": settings.INDEX_EXCHANGE_SEGMENT,
        "instrument_type": settings.INDEX_INSTRUMENT_TYPE,
        "from_date": today,
        "to_date": today,
    }

    response = requests.get(url, params=params, timeout=settings.REQUEST_TIMEOUT)

    response.raise_for_status()

    response_data = response.json()

    market_data = response_data.get("data", {}).get("data", {})

    closes = market_data.get("close", [])

    timestamps = market_data.get("timestamp", [])

    if not closes:

        raise ValueError(f"No close data found " f"security_id={security_id}")

    ema9 = closes[0]

    ema21 = closes[0]

    for price in closes[1:]:

        ema9 = calculate_ema_value(ema9, price, EMA_FAST)

        ema21 = calculate_ema_value(ema21, price, EMA_SLOW)

    logger.info(
        f"EMA history loaded successfully "
        f"security_id={security_id} "
        f"EMA9={round(ema9, 2)} "
        f"EMA21={round(ema21, 2)}"
    )

    return {
        "ema9": ema9,
        "ema21": ema21,
        "last_close": closes[-1],
        "timestamps": timestamps,
    }


# ==========================================================
# PROCESS CLOSED CANDLE
# ==========================================================


def process_closed_candle(
    mongo_id,
    level_name: str,
    strike_group: str,
    option_side: str,
    security_id: int,
    close_price: float,
    candle_timestamp: int,
):
    try:

        state = EMA_CACHE.get(security_id)

        if not state:

            logger.warning(f"EMA state missing " f"security_id={security_id}")

            return

        old_fast_above = state["ema9"] > state["ema21"]

        state["ema9"] = calculate_ema_value(
            previous_ema=state["ema9"], close_price=close_price, period=EMA_FAST
        )

        state["ema21"] = calculate_ema_value(
            previous_ema=state["ema21"], close_price=close_price, period=EMA_SLOW
        )

        new_fast_above = state["ema9"] > state["ema21"]

        signal = None

        if not old_fast_above and new_fast_above:

            signal = "BUY"

        elif old_fast_above and not new_fast_above:

            signal = "SELL"

        EMA_CACHE[security_id] = {
            "security_id": security_id,
            "ema9": round(state["ema9"], 2),
            "ema21": round(state["ema21"], 2),
            "last_close": round(close_price, 2),
            "updated_at": datetime.now(IST).strftime("%Y-%m-%d %H:%M:%S"),
        }

        logger.info(
            f"EMA updated "
            f"security_id={security_id} "
            f"close={close_price} "
            f"EMA9={round(state['ema9'], 2)} "
            f"EMA21={round(state['ema21'], 2)}"
        )

        if signal:

            signal_data = {
                "security_id": security_id,
                "signal": signal,
                "close_price": round(close_price, 2),
                "ema9": round(state["ema9"], 2),
                "ema21": round(state["ema21"], 2),
                "timestamp": candle_timestamp,
                "datetime": datetime.fromtimestamp(candle_timestamp, tz=IST).strftime(
                    "%Y-%m-%d %H:%M:%S"
                ),
            }

            EMA_SIGNALS.setdefault(security_id, []).append(signal_data)

            collection.update_one(
                {"_id": mongo_id},
                {
                    "$push": {
                        (
                            f"intraday_data."
                            f"{level_name}."
                            f"{strike_group}."
                            f"{option_side}."
                            f"ema_signals_1_minute"
                        ): signal_data
                    }
                },
            )

            logger.info(f"EMA SIGNAL GENERATED : " f"{json.dumps(signal_data)}")

    except Exception as e:

        logger.exception(
            f"EMA candle processing failed " f"security_id={security_id} : " f"{str(e)}"
        )


# ==========================================================
# EMA ENGINE
# ==========================================================


async def run_ema_engine(
    mongo_id, level_name: str, strike_group: str, option_side: str, security_id: int
):
    logger.info(f"EMA engine started " f"security_id={security_id}")

    current_candle = None

    try:

        history = load_historical_data(security_id)

        EMA_CACHE[security_id] = {
            "security_id": security_id,
            "ema9": round(history["ema9"], 2),
            "ema21": round(history["ema21"], 2),
            "last_close": round(history["last_close"], 2),
            "updated_at": datetime.now(IST).strftime("%Y-%m-%d %H:%M:%S"),
        }

        ws_url = f"{settings.BASE_WS_URL}" f"/ws/market/{security_id}/"

        logger.info(f"EMA websocket URL : " f"{ws_url}")

        while True:

            try:

                # ==========================================
                # MARKET CLOSED
                # ==========================================

                if not is_market_open():

                    logger.info(
                        f"Market closed. " f"EMA waiting " f"security_id={security_id}"
                    )

                    await asyncio.sleep(60)

                    continue

                # ==========================================
                # WEBSOCKET
                # ==========================================

                async with websockets.connect(
                    ws_url, ping_interval=20, ping_timeout=20
                ) as ws:

                    logger.info(
                        f"EMA websocket connected " f"security_id={security_id}"
                    )

                    async for message in ws:

                        try:

                            if not is_market_open():

                                logger.info(
                                    f"Market closed during feed "
                                    f"security_id={security_id}"
                                )

                                break

                            data = json.loads(message)

                            if "LTP" not in data:

                                continue

                            close_price = float(data.get("LTP") or 0)

                            now = datetime.now(IST)

                            minute_bucket = (now.hour * 60) + now.minute

                            if current_candle is None:

                                current_candle = {
                                    "minute": minute_bucket,
                                    "close": close_price,
                                }

                                continue

                            # ==================================
                            # NEW MINUTE
                            # ==================================

                            if minute_bucket != current_candle["minute"]:

                                process_closed_candle(
                                    mongo_id=mongo_id,
                                    level_name=level_name,
                                    strike_group=strike_group,
                                    option_side=option_side,
                                    security_id=security_id,
                                    close_price=current_candle["close"],
                                    candle_timestamp=(current_candle["minute"] * 60),
                                )

                                current_candle = {
                                    "minute": minute_bucket,
                                    "close": close_price,
                                }

                            else:

                                current_candle["close"] = close_price

                        except Exception as e:

                            logger.exception(
                                f"EMA message processing failed "
                                f"security_id={security_id} : "
                                f"{str(e)}"
                            )

            except Exception as e:

                logger.exception(
                    f"EMA websocket failed " f"security_id={security_id} : " f"{str(e)}"
                )

                logger.info(
                    f"EMA reconnecting in 5 seconds " f"security_id={security_id}"
                )

                await asyncio.sleep(5)

    except Exception as e:

        logger.exception(
            f"EMA engine failed " f"security_id={security_id} : " f"{str(e)}"
        )

    finally:

        EMA_TASKS.pop(security_id, None)

        logger.info(f"EMA engine stopped " f"security_id={security_id}")


# ==========================================================
# START EMA TASK
# ==========================================================


def start_ema_engine(
    mongo_id, level_name: str, strike_group: str, option_side: str, security_id: int
):
    try:

        existing_task = EMA_TASKS.get(security_id)

        if existing_task:
            logger.info(f"EMA already running security_id={security_id}")
            return

        # ✅ THREAD-SAFE: schedule on main event loop
        result = anyio.from_thread.run(
            run_ema_engine, mongo_id, level_name, strike_group, option_side, security_id
        )

        EMA_TASKS[security_id] = result

        logger.info(f"EMA engine started (thread-safe) security_id={security_id}")

    except Exception as e:

        logger.exception(
            f"Failed starting EMA engine security_id={security_id} : {str(e)}"
        )
