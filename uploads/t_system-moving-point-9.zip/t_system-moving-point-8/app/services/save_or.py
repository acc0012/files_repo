from datetime import datetime
from zoneinfo import ZoneInfo

from app.database import collection
from app.parser import parse_levels
from app.logger import logger
from concurrent.futures import ThreadPoolExecutor, as_completed

from app.config import settings

from app.services.strike_mapper import build_security_mapping

from app.services.intraday_fetcher import fetch_intraday_data

from app.services.option_subscriber import subscribe_option_marketfeed

from app.services.option_socket import start_option_listener
from app.services.ema_service import start_ema_engine

TARGET_LEVELS = ["R3_STRIKE", "S3_STRIKE"]


def save_opening_range(trace_id: str, payload: dict):

    try:

        logger.info(f"[{trace_id}] SAVE_OR started")

        ist_now = datetime.now(ZoneInfo("Asia/Kolkata"))

        index_security_id = payload.get("INDEX_SECURITY_ID")

        if index_security_id is None:

            raise ValueError("INDEX_SECURITY_ID is required")

        logger.info(f"[{trace_id}] Index Security ID : " f"{index_security_id}")

        # ==========================================
        # PARSE LEVELS
        # ==========================================

        logger.info(f"[{trace_id}] Parsing levels")

        parsed = parse_levels(trace_id, payload)

        logger.info(f"[{trace_id}] Levels parsed successfully")

        # ==========================================
        # BUILD SECURITY MAPPING
        # ==========================================

        logger.info(f"[{trace_id}] Building security mapping")

        security_mapping = build_security_mapping(int(index_security_id), parsed)

        logger.info(f"[{trace_id}] Security mapping built successfully")

        # ==========================================
        # OPTION SUBSCRIPTION
        # ==========================================

        logger.info(f"[{trace_id}] Option market subscription started")

        filtered_mapping = {
            k: v for k, v in security_mapping.items() if k in TARGET_LEVELS
        }

        subscription_result = subscribe_option_marketfeed(trace_id, filtered_mapping)

        logger.info(f"[{trace_id}] Option market subscription completed")

        # ==========================================
        # START OPTION LIVE SOCKETS
        # ==========================================

        logger.info(f"[{trace_id}] " f"Starting option websocket listeners")

        for level_name, level_data in filtered_mapping.items():

            try:

                lower_strike = level_data.get("lower_strike")

                upper_strike = level_data.get("upper_strike")

                lower_data = level_data.get("lower_strike_data", {})

                upper_data = level_data.get("upper_strike_data", {})

                # ==================================================
                # LOWER STRIKE SOCKETS
                # ==================================================

                lower_ce_security_id = lower_data.get("ce_security_id")

                lower_pe_security_id = lower_data.get("pe_security_id")

                if lower_ce_security_id:

                    start_option_listener(lower_ce_security_id, f"{lower_strike}_CE")

                if lower_pe_security_id:

                    start_option_listener(lower_pe_security_id, f"{lower_strike}_PE")

                # ==================================================
                # UPPER STRIKE SOCKETS
                # ==================================================

                upper_ce_security_id = upper_data.get("ce_security_id")

                upper_pe_security_id = upper_data.get("pe_security_id")

                if upper_ce_security_id:

                    start_option_listener(upper_ce_security_id, f"{upper_strike}_CE")

                if upper_pe_security_id:

                    start_option_listener(upper_pe_security_id, f"{upper_strike}_PE")

            except Exception as e:

                logger.exception(
                    f"[{trace_id}] Failed starting option sockets : {str(e)}"
                )
        logger.info(f"[{trace_id}] " f"Option websocket listeners started")

        # ==========================================
        # MULTITHREADED INTRADAY FETCH
        # ==========================================

        logger.info(f"[{trace_id}] Fetching intraday data")

        intraday_data = {}

        futures = {}

        with ThreadPoolExecutor(max_workers=settings.WORKERS_NUM) as executor:

            for level_name, level_data in filtered_mapping.items():
                intraday_data[level_name] = {
                    "raw_value": level_data.get("raw_value"),
                    "lower_strike": level_data.get("lower_strike"),
                    "upper_strike": level_data.get("upper_strike"),
                    "lower_strike_data": {},
                    "upper_strike_data": {},
                }
                lower_data = level_data.get("lower_strike_data", {})

                upper_data = level_data.get("upper_strike_data", {})

                lower_ce_security_id = lower_data.get("ce_security_id")

                lower_pe_security_id = lower_data.get("pe_security_id")

                if lower_ce_security_id:

                    futures[
                        executor.submit(
                            fetch_intraday_data,
                            security_id=lower_ce_security_id,
                            exchange_segment=settings.OPTION_EXCHANGE_SEGMENT,
                            instrument_type=settings.OPTION_INSTRUMENT_TYPE,
                            from_date=payload.get("FROM_DATE"),
                            to_date=payload.get("TO_DATE"),
                        )
                    ] = (level_name, "lower_strike_data", "ce_intraday")

                if lower_pe_security_id:

                    futures[
                        executor.submit(
                            fetch_intraday_data,
                            security_id=lower_pe_security_id,
                            exchange_segment=settings.OPTION_EXCHANGE_SEGMENT,
                            instrument_type=settings.OPTION_INSTRUMENT_TYPE,
                            from_date=payload.get("FROM_DATE"),
                            to_date=payload.get("TO_DATE"),
                        )
                    ] = (level_name, "lower_strike_data", "pe_intraday")
                upper_ce_security_id = upper_data.get("ce_security_id")

                upper_pe_security_id = upper_data.get("pe_security_id")

                if upper_ce_security_id:

                    futures[
                        executor.submit(
                            fetch_intraday_data,
                            security_id=upper_ce_security_id,
                            exchange_segment=settings.OPTION_EXCHANGE_SEGMENT,
                            instrument_type=settings.OPTION_INSTRUMENT_TYPE,
                            from_date=payload.get("FROM_DATE"),
                            to_date=payload.get("TO_DATE"),
                        )
                    ] = (level_name, "upper_strike_data", "ce_intraday")
                if upper_pe_security_id:

                    futures[
                        executor.submit(
                            fetch_intraday_data,
                            security_id=upper_pe_security_id,
                            exchange_segment=settings.OPTION_EXCHANGE_SEGMENT,
                            instrument_type=settings.OPTION_INSTRUMENT_TYPE,
                            from_date=payload.get("FROM_DATE"),
                            to_date=payload.get("TO_DATE"),
                        )
                    ] = (level_name, "upper_strike_data", "pe_intraday")

            # ======================================
            # PROCESS THREAD RESULTS
            # ======================================

            for future in as_completed(futures):

                level_name, strike_group, field_name = futures[future]
                try:

                    result = future.result()

                    intraday_data[level_name][strike_group][field_name] = result
                except Exception as e:

                    logger.exception(
                        f"[{trace_id}] "
                        f"Threaded intraday fetch failed : "
                        f"{str(e)}"
                    )

                    intraday_data[level_name][strike_group][field_name] = {
                        "success": False,
                        "error": str(e),
                    }

        logger.info(f"[{trace_id}] " f"Intraday data fetched successfully")

        # ==========================================
        # MONGO DOCUMENT
        # ==========================================

        doc = {
            "trace_id": trace_id,
            "status": "COMPLETED",
            "trade_date": ist_now.strftime("%Y-%m-%d"),
            "received_at": ist_now,
            "processed_at": datetime.now(ZoneInfo("Asia/Kolkata")),
            "index_security_id": int(index_security_id),
            "original": payload,
            "parsed": parsed,
            "security_mapping": security_mapping,
            "subscription_result": subscription_result,
            "intraday_data": intraday_data,
        }

        logger.info(f"[{trace_id}] Mongo insert started")

        result = collection.insert_one(doc)

        if not result.inserted_id:

            raise Exception("MongoDB insert failed")

        inserted_id = result.inserted_id
        
        # ==========================================
        # START EMA ENGINES FOR ALL OPTIONS
        # ==========================================

        for level_name, level_data in intraday_data.items():

            lower_data = level_data.get("lower_strike_data", {})
            upper_data = level_data.get("upper_strike_data", {})

            # ======================================
            # LOWER STRIKE - CE
            # ======================================

            lower_ce = lower_data.get("ce_intraday", {})

            if lower_ce.get("success"):

                start_ema_engine(
                    mongo_id=inserted_id,
                    level_name=level_name,
                    strike_group="lower_strike_data",
                    option_side="ce_intraday",
                    security_id=lower_ce.get("security_id")
                )

            # ======================================
            # LOWER STRIKE - PE
            # ======================================

            lower_pe = lower_data.get("pe_intraday", {})

            if lower_pe.get("success"):

                start_ema_engine(
                    mongo_id=inserted_id,
                    level_name=level_name,
                    strike_group="lower_strike_data",
                    option_side="pe_intraday",
                    security_id=lower_pe.get("security_id")
                )

            # ======================================
            # UPPER STRIKE - CE
            # ======================================

            upper_ce = upper_data.get("ce_intraday", {})

            if upper_ce.get("success"):

                start_ema_engine(
                    mongo_id=inserted_id,
                    level_name=level_name,
                    strike_group="upper_strike_data",
                    option_side="ce_intraday",
                    security_id=upper_ce.get("security_id")
                )

            # ======================================
            # UPPER STRIKE - PE
            # ======================================

            upper_pe = upper_data.get("pe_intraday", {})

            if upper_pe.get("success"):

                start_ema_engine(
                    mongo_id=inserted_id,
                    level_name=level_name,
                    strike_group="upper_strike_data",
                    option_side="pe_intraday",
                    security_id=upper_pe.get("security_id")
                )

        # # ==========================================
        # # START EMA ENGINE
        # # ==========================================

        # start_ema_engine(
        #     mongo_id=result.inserted_id,
        #     level_name=level_name,
        #     strike_group="lower_strike_data",
        #     option_side="ce_intraday",
        #     security_id=lower_ce_security_id
        # )

        logger.info(f"[{trace_id}] Mongo insert completed")

        logger.info(f"[{trace_id}] Document created successfully")

        return inserted_id

    except Exception as e:

        logger.exception(f"[{trace_id}] SAVE_OR failed : " f"{str(e)}")

        raise

    finally:

        logger.info(f"[{trace_id}] SAVE_OR finished")
