from uuid import uuid4

from fastapi import APIRouter
from fastapi import Request
from fastapi import HTTPException

from app.logger import logger
from app.services.security_lookup import (
    get_security_id
)

router = APIRouter()


@router.post("/option-chain/security-id")
async def security_lookup(
    request: Request
):

    trace_id = str(
        uuid4()
    )

    try:

        payload = await request.json()

        logger.info(
            f"[{trace_id}] Security lookup request received"
        )

        index_security_id = payload.get(
            "index_security_id"
        )

        strike = payload.get(
            "strike"
        )

        option_type = payload.get(
            "option_type"
        )

        if index_security_id is None:

            logger.warning(
                f"[{trace_id}] Missing index_security_id"
            )

            raise HTTPException(
                status_code=400,
                detail="index_security_id is required"
            )

        if strike is None:

            logger.warning(
                f"[{trace_id}] Missing strike"
            )

            raise HTTPException(
                status_code=400,
                detail="strike is required"
            )

        if not option_type:

            logger.warning(
                f"[{trace_id}] Missing option_type"
            )

            raise HTTPException(
                status_code=400,
                detail="option_type is required"
            )

        security_id = get_security_id(
            int(index_security_id),
            int(strike),
            str(option_type)
        )

        logger.info(
            f"[{trace_id}] Lookup successful "
            f"security_id={security_id}"
        )

        return {
            "success": True,
            "trace_id": trace_id,
            "index_security_id": index_security_id,
            "strike": strike,
            "option_type": option_type.upper(),
            "security_id": security_id
        }

    except HTTPException:

        raise

    except ValueError as e:

        logger.error(
            f"[{trace_id}] Validation failed : {str(e)}"
        )

        raise HTTPException(
            status_code=404,
            detail=str(e)
        )

    except Exception as e:

        logger.exception(
            f"[{trace_id}] Security lookup failed : {str(e)}"
        )

        raise HTTPException(
            status_code=500,
            detail="Internal Server Error"
        )

    finally:

        logger.info(
            f"[{trace_id}] Security lookup finished"
        )