from uuid import uuid4

from fastapi import APIRouter
from fastapi import Request
from fastapi import HTTPException
from fastapi import BackgroundTasks

from app.config import settings
from app.logger import logger
from app.services.background import process_opening_range

router = APIRouter()


@router.post("/webhook/opening-range/{index_security_id}")
async def opening_range_webhook(
    index_security_id: int,
    request: Request,
    background_tasks: BackgroundTasks
):

    trace_id = str(
        uuid4()
    )

    try:

        payload = await request.json()

        logger.info(
            f"[{trace_id}] OPENING_RANGE request received"
        )

        logger.info(
            f"[{trace_id}] Index Security ID : "
            f"{index_security_id}"
        )

        missing = [
            field
            for field in settings.REQUIRED_FIELDS
            if field not in payload
        ]

        if missing:

            logger.warning(
                f"[{trace_id}] Missing fields : "
                f"{missing}"
            )

            raise HTTPException(
                status_code=400,
                detail=f"Missing fields: {', '.join(missing)}"
            )

        payload[
            "INDEX_SECURITY_ID"
        ] = index_security_id

        logger.info(
            f"[{trace_id}] Payload validated successfully"
        )

        background_tasks.add_task(
            process_opening_range,
            trace_id,
            payload
        )

        logger.info(
            f"[{trace_id}] Request accepted "
            f"for background processing"
        )

        return {
            "status": "accepted",
            "trace_id": trace_id,
            "index_security_id":
                index_security_id
        }

    except HTTPException:

        raise

    except Exception as e:

        logger.exception(
            f"[{trace_id}] OPENING_RANGE "
            f"processing failed : {str(e)}"
        )

        raise HTTPException(
            status_code=500,
            detail="Internal Server Error"
        )

    finally:

        logger.info(
            f"[{trace_id}] OPENING_RANGE "
            f"request finished"
        )