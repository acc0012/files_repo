from fastapi import APIRouter

from app.cache.live_market import LIVE_MARKET_CACHE
from app.config import settings
from fastapi import WebSocket
from fastapi import WebSocketDisconnect
import asyncio

router = APIRouter(tags=["Live Market"])


@router.get("/market/live")
async def market_live():

    return {
        "success": True,
        "count": len(LIVE_MARKET_CACHE),
        "data": list(LIVE_MARKET_CACHE.values()),
    }



@router.websocket("/ws/live-market")
async def live_market_ws(websocket: WebSocket):

    await websocket.accept()

    try:

        while True:

            await websocket.send_json({
                "success": True,
                "count": len(LIVE_MARKET_CACHE),
                "data": list(LIVE_MARKET_CACHE.values())
            })

            await asyncio.sleep(1)

    except WebSocketDisconnect:

        pass
    
@router.get("/market/live/{index_name}")
async def market_by_name(index_name: str):

    security_id = settings.INDEX_MAP.get(index_name.upper())

    if not security_id:

        return {"success": False, "message": "Index not found"}

    return {"success": True, "data": LIVE_MARKET_CACHE.get(security_id, {})}
