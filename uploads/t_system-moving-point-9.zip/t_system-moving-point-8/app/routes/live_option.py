from fastapi import APIRouter
from fastapi import WebSocket
from fastapi import WebSocketDisconnect

import asyncio

from app.cache import OPTION_LIVE_CACHE
from app.logger import logger

router = APIRouter(tags=["Live Option Market"])

# ==========================================================
# GET ALL LIVE OPTION DATA
# ==========================================================


@router.get("/option/live")
async def option_live():

    try:

        logger.info("Live option market API requested")

        return {
            "success": True,
            "count": len(OPTION_LIVE_CACHE),
            "data": list(OPTION_LIVE_CACHE.values()),
        }

    except Exception as e:

        logger.exception(f"Live option API failed : " f"{str(e)}")

        return {"success": False, "message": "Internal Server Error"}


# ==========================================================
# GET SINGLE OPTION LIVE DATA
# ==========================================================


@router.get("/option/live/{security_id}")
async def option_live_by_security_id(security_id: int):

    try:

        logger.info(f"Single option live API requested " f"security_id={security_id}")

        data = OPTION_LIVE_CACHE.get(security_id)

        if not data:

            return {"success": False, "message": "Option data not found"}

        return {"success": True, "data": data}

    except Exception as e:

        logger.exception(f"Single option API failed : " f"{str(e)}")

        return {"success": False, "message": "Internal Server Error"}


# ==========================================================
# OPTION LIVE WEBSOCKET
# ==========================================================


@router.websocket("/ws/option-live")
async def option_live_ws(websocket: WebSocket):

    await websocket.accept()

    logger.info("Option live websocket connected")

    try:

        while True:

            await websocket.send_json(
                {
                    "success": True,
                    "count": len(OPTION_LIVE_CACHE),
                    "data": list(OPTION_LIVE_CACHE.values()),
                }
            )

            await asyncio.sleep(1)

    except WebSocketDisconnect:

        logger.info("Option live websocket disconnected")

    except Exception as e:

        logger.exception(f"Option live websocket failed : " f"{str(e)}")
