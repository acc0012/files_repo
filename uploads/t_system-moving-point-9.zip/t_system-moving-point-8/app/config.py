import os

from dotenv import load_dotenv

load_dotenv()


class Settings:

    HEART_BEAT_INTERVAL = 300
    # =====================================================
    # MONGODB
    # =====================================================

    MONGO_URL = os.getenv("MONGO_URL")

    MONGO_DB = os.getenv("MONGO_DB")

    MONGO_COLLECTION = os.getenv("MONGO_COLLECTION")

    # =====================================================
    # OPTION CHAIN CACHE
    # =====================================================

    MONGO_OPTION_CHAIN_DB = os.getenv("MONGO_OPTION_CHAIN_DB")

    MONGO_OPTION_COLLECTION = os.getenv("MONGO_OPTION_COLLECTION")

    # =====================================================
    # EXTERNAL API
    # =====================================================
    BASE_URL = os.getenv("BASE_URL")

    BASE_WS_URL = BASE_URL.replace("https://", "wss://").replace("http://", "ws://")
    REQUEST_TIMEOUT = int(os.getenv("REQUEST_TIMEOUT", "30"))

    # =====================================================
    # INTRADAY DEFAULTS
    # =====================================================

    OPTION_EXCHANGE_SEGMENT = os.getenv("OPTION_EXCHANGE_SEGMENT", "NSE_FNO")

    OPTION_INSTRUMENT_TYPE = os.getenv("OPTION_INSTRUMENT_TYPE", "OPTIDX")

    INDEX_EXCHANGE_SEGMENT = os.getenv("INDEX_EXCHANGE_SEGMENT", "IDX_I")

    INDEX_INSTRUMENT_TYPE = os.getenv("INDEX_INSTRUMENT_TYPE", "INDEX")

    # =====================================================
    # WEBHOOK VALIDATION
    # =====================================================

    WORKERS_NUM = 3
    TEST_LOG_FILES = os.getenv("TEST_LOG_FILES", "false").lower() == "true"

    LOG_FOLDER = os.getenv("LOG_FOLDER", "test_logs")

    INSTRUMENTS = [
        {
            "security_id": 13,
            "index_name": "NIFTY",
            "automation": True,
            "timeframe": 1,
        },
        {
            "security_id": 21,
            "index_name": "INDIA-VIX",
            "automation": False,
        },
        {
            "security_id": 51,
            "index_name": "SENSEX",
            "automation": False,
        },
    ]

    INDEX_MAP = {
        item["index_name"].upper(): item["security_id"] for item in INSTRUMENTS
    }

    REQUIRED_FIELDS = [
        "TYPE",
        "HIGH",
        "LOW",
        "AVG",
        "RESISTANCE2",
        "SUPPORT2",
        "RESISTANCE3",
        "SUPPORT3",
    ]


settings = Settings()
