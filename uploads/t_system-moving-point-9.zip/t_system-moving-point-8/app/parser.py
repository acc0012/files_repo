import math

from app.logger import logger


def round_up(value):

    return math.ceil(float(value) / 50) * 50


def round_down(value):

    return math.floor(float(value) / 50) * 50


def parse_levels(trace_id: str, data: dict):

    try:

        logger.info(f"[{trace_id}] Level parsing started")

        required_fields = [
            "HIGH",
            "LOW",
            "AVG",
            "RESISTANCE2",
            "SUPPORT2",
            "RESISTANCE3",
            "SUPPORT3",
        ]

        missing = [field for field in required_fields if field not in data]

        if missing:

            logger.error(f"[{trace_id}] Missing fields : {missing}")

            raise ValueError(f"Missing fields: {', '.join(missing)}")

        high = float(data["HIGH"])

        low = float(data["LOW"])

        avg = float(data["AVG"])

        r2 = float(data["RESISTANCE2"])

        s2 = float(data["SUPPORT2"])

        r3 = float(data["RESISTANCE3"])

        s3 = float(data["SUPPORT3"])

        parsed = {

            "R3_STRIKE": {

                "raw_value": r3,

                "lower_strike": round_down(r3),

                "upper_strike": round_up(r3)
            },

            "S3_STRIKE": {

                "raw_value": s3,

                "lower_strike": round_down(s3),

                "upper_strike": round_up(s3)
            }
        }

        logger.info(f"[{trace_id}] Level parsing completed successfully")

        return parsed

    except ValueError as e:

        logger.error(f"[{trace_id}] Validation failed : {str(e)}")

        raise

    except Exception as e:

        logger.exception(f"[{trace_id}] Level parsing failed : {str(e)}")

        raise

    finally:

        logger.info(f"[{trace_id}] Level parsing finished")
