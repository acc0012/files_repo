from contextlib import asynccontextmanager
import asyncio
from datetime import datetime
from zoneinfo import ZoneInfo

from fastapi import FastAPI
from fastapi import Request
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from app.routes.webhook import router as webhook_router
from app.routes.live_option import router as live_option_router

from app.routes.option_chain import router as option_chain_router

from app.routes.dashboard import router as dashboard_router

from app.logger import logger

from app.services.master_loader import load_option_master

from app.services.market_socket import listen_market_feed
from app.config import settings

from app.routes.live_market import router as live_market_router

# ==========================================================
# DAILY CACHE REFRESH TASK
# ==========================================================


async def daily_cache_refresh():

    logger.info("Daily cache refresh task started")

    last_refresh_date = None

    while True:

        try:

            now = datetime.now(ZoneInfo("Asia/Kolkata"))

            current_date = now.strftime("%Y-%m-%d")

            # ==========================================
            # REFRESH CACHE DAILY AT 08:55 AM IST
            # ==========================================

            if now.hour == 8 and now.minute == 55 and last_refresh_date != current_date:

                logger.info("Daily cache refresh initiated")

                count = load_option_master()

                last_refresh_date = current_date

                logger.info(
                    f"Daily cache refresh completed. " f"Loaded {count} records"
                )

        except Exception as e:

            logger.exception(f"Daily cache refresh failed : {str(e)}")

        await asyncio.sleep(60)


# ==========================================================
# APPLICATION LIFESPAN
# ==========================================================
@asynccontextmanager
async def lifespan(app: FastAPI):

    refresh_task = None
    market_tasks = []

    try:

        logger.info("Application startup initiated")

        # ==========================================
        # LOAD OPTION MASTER CACHE
        # ==========================================

        logger.info("Loading option chain cache")

        count = load_option_master()

        logger.info(
            f"Option chain cache loaded successfully. " f"Records loaded : {count}"
        )

        # ==========================================
        # DAILY REFRESH TASK
        # ==========================================

        refresh_task = asyncio.create_task(daily_cache_refresh())

        logger.info("Background cache refresh task started")

        # ==========================================
        # MARKET FEED SOCKETS
        # ==========================================

        for instrument in settings.INSTRUMENTS:

            security_id = instrument["security_id"]
            index_name = instrument["index_name"]

            task = asyncio.create_task(
                listen_market_feed(security_id, index_name), name=f"market-{index_name}"
            )

            market_tasks.append(task)

            logger.info(f"Market socket started " f"{index_name} ({security_id})")

        logger.info(f"{len(market_tasks)} market sockets started")

        logger.info("Opening Range API started successfully")

        yield

    except Exception as e:

        logger.exception(f"Startup failed : {str(e)}")

        raise

    finally:

        logger.info("Application shutdown initiated")

        try:

            # ======================================
            # STOP REFRESH TASK
            # ======================================

            if refresh_task:

                refresh_task.cancel()

                try:

                    await refresh_task

                except asyncio.CancelledError:

                    logger.info("Background refresh task cancelled")

            # ======================================
            # STOP MARKET SOCKET TASKS
            # ======================================

            for task in market_tasks:

                task.cancel()

            for task in market_tasks:

                try:

                    await task

                except asyncio.CancelledError:

                    pass

            logger.info("All market socket tasks cancelled")

        except Exception as e:

            logger.exception(f"Shutdown cleanup failed : {str(e)}")

        logger.info("Opening Range API stopped")


# ==========================================================
# FASTAPI APP
# ==========================================================

app = FastAPI(title="Opening Range Dashboard API", version="1.0.0", lifespan=lifespan)

# ==========================================================
# GLOBAL EXCEPTION HANDLER
# ==========================================================


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):

    logger.exception(f"Unhandled exception : {str(exc)}")

    return JSONResponse(
        status_code=500, content={"status": "error", "message": "Internal Server Error"}
    )


# ==========================================================
# HEALTH CHECK ROUTE
# ==========================================================


@app.get("/health")
async def health_check():

    logger.info("Health check requested")

    return {"status": "healthy"}




app.mount(
    "/static",
    StaticFiles(directory="app/static"),
    name="static"
)

# ==========================================================
# ROUTERS
# ==========================================================

app.include_router(live_market_router)

logger.info("Live market routes registered successfully")

app.include_router(live_option_router)

logger.info("Live option routes registered successfully")

# ------------------------------------------
# WEBHOOK ROUTES
# ------------------------------------------

app.include_router(webhook_router)

logger.info("Webhook routes registered successfully")

# ------------------------------------------
# OPTION CHAIN ROUTES
# ------------------------------------------

app.include_router(option_chain_router)

logger.info("Option chain routes registered successfully")

# ------------------------------------------
# DASHBOARD ROUTES
# ------------------------------------------

app.include_router(dashboard_router)

logger.info("Dashboard routes registered successfully")

# ==========================================================
# APPLICATION READY
# ==========================================================

logger.info("Application startup configuration completed")
