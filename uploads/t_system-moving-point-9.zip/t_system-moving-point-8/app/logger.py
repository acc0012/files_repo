import logging
import os


try:

    os.makedirs(
        "logs",
        exist_ok=True
    )

    logger = logging.getLogger(
        "or_api"
    )

    logger.setLevel(
        logging.INFO
    )

    logger.propagate = False

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(message)s"
    )

    if not logger.handlers:

        file_handler = logging.FileHandler(
            "logs/app.log",
            encoding="utf-8"
        )

        file_handler.setLevel(
            logging.INFO
        )

        file_handler.setFormatter(
            formatter
        )

        console_handler = logging.StreamHandler()

        console_handler.setLevel(
            logging.INFO
        )

        console_handler.setFormatter(
            formatter
        )

        logger.addHandler(
            file_handler
        )

        logger.addHandler(
            console_handler
        )

    logger.info(
        "Logger initialized successfully"
    )

except Exception as e:

    logging.basicConfig(
        level=logging.INFO
    )

    logger = logging.getLogger(
        "fallback_logger"
    )

    logger.exception(
        f"Logger initialization failed : {str(e)}"
    )