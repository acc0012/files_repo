let socket = null;

let optionSocket = null;

// ======================================================
// MAIN INDEX MARKET SOCKET
// ======================================================

function connectMarketSocket() {
  const protocol = window.location.protocol === "https:" ? "wss" : "ws";

  const wsUrl = `${protocol}://${window.location.host}/ws/live-market`;

  socket = new WebSocket(wsUrl);

  // --------------------------------------------------
  // CONNECTED
  // --------------------------------------------------

  socket.onopen = () => {
    console.log("Market websocket connected");
  };

  // --------------------------------------------------
  // MESSAGE
  // --------------------------------------------------

  socket.onmessage = (event) => {
    const result = JSON.parse(event.data);

    if (!result.success) {
      return;
    }

    result.data.forEach((item) => {
      // ==========================================
      // NIFTY
      // ==========================================

      if (item.index_name === "NIFTY") {
        const niftyLtp = document.getElementById("nifty-ltp");

        const niftyTime = document.getElementById("nifty-time");

        if (niftyLtp) {
          niftyLtp.innerText = Number(item.ltp || 0).toFixed(2);
        }

        if (niftyTime) {
          niftyTime.innerText = item.updated_at || "--";
        }
      }

      // ==========================================
      // SENSEX
      // ==========================================

      if (item.index_name === "SENSEX") {
        const sensexLtp = document.getElementById("sensex-ltp");

        const sensexTime = document.getElementById("sensex-time");

        if (sensexLtp) {
          sensexLtp.innerText = Number(item.ltp || 0).toFixed(2);
        }

        if (sensexTime) {
          sensexTime.innerText = item.updated_at || "--";
        }
      }

      // ==========================================
      // INDIA VIX
      // ==========================================

      if (item.index_name === "INDIA-VIX") {
        const vixLtp = document.getElementById("vix-ltp");

        const vixTime = document.getElementById("vix-time");

        if (vixLtp) {
          vixLtp.innerText = Number(item.ltp || 0).toFixed(2);
        }

        if (vixTime) {
          vixTime.innerText = item.updated_at || "--";
        }
      }
    });
  };

  // --------------------------------------------------
  // ERROR
  // --------------------------------------------------

  socket.onerror = (error) => {
    console.error("Market websocket error", error);
  };

  // --------------------------------------------------
  // CLOSE
  // --------------------------------------------------

  socket.onclose = () => {
    console.log("Market websocket disconnected");

    setTimeout(connectMarketSocket, 5000);
  };
}

// ======================================================
// OPTION LIVE SOCKET
// ======================================================

function connectOptionSocket() {
  const protocol = window.location.protocol === "https:" ? "wss" : "ws";

  const wsUrl = `${protocol}://${window.location.host}/ws/option-live`;

  optionSocket = new WebSocket(wsUrl);

  // --------------------------------------------------
  // CONNECTED
  // --------------------------------------------------

  optionSocket.onopen = () => {
    console.log("Option websocket connected");
  };

  // --------------------------------------------------
  // MESSAGE
  // --------------------------------------------------

  optionSocket.onmessage = (event) => {
    const result = JSON.parse(event.data);

    if (!result.success) {
      return;
    }

    result.data.forEach((item) => {
      /*
                Example Tick

                {
                    security_id: 12345,
                    symbol: "24500_CE",
                    ltp: 120.50,
                    updated_at: "10:22:10"
                }
            */

      console.log("Live Option Tick", item);

      const securityId = item.security_id;

      const ltp = Number(item.ltp || 0).toFixed(2);

      const updatedAt = item.updated_at || "--";

      // ==========================================
      // CE LIVE UPDATE
      // ==========================================

      const ceLtp = document.getElementById(`ce-ltp-${securityId}`);

      const ceTime = document.getElementById(`ce-time-${securityId}`);

      if (ceLtp) {
        ceLtp.innerText = ltp;
      }

      if (ceTime) {
        ceTime.innerText = updatedAt;
      }

      // ==========================================
      // PE LIVE UPDATE
      // ==========================================

      const peLtp = document.getElementById(`pe-ltp-${securityId}`);

      const peTime = document.getElementById(`pe-time-${securityId}`);

      if (peLtp) {
        peLtp.innerText = ltp;
      }

      if (peTime) {
        peTime.innerText = updatedAt;
      }
    });
  };

  // --------------------------------------------------
  // ERROR
  // --------------------------------------------------

  optionSocket.onerror = (error) => {
    console.error("Option websocket error", error);
  };

  // --------------------------------------------------
  // CLOSE
  // --------------------------------------------------

  optionSocket.onclose = () => {
    console.log("Option websocket disconnected");

    setTimeout(connectOptionSocket, 5000);
  };
}

// ======================================================
// SOCKET STATUS CHECK
// ======================================================

function logSocketStatus() {
  console.log({
    marketSocket: socket ? socket.readyState : "NOT_CONNECTED",

    optionSocket: optionSocket ? optionSocket.readyState : "NOT_CONNECTED",
  });
}

// ======================================================
// START SOCKETS
// ======================================================

connectMarketSocket();

connectOptionSocket();

// ======================================================
// OPTIONAL DEBUG LOGGER
// ======================================================

setInterval(logSocketStatus, 30000);
