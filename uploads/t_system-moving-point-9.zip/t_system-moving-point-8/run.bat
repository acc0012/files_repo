@echo off
cls

REM Activate virtual environment
call myenv\Scripts\activate

REM Run Uvicorn
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload