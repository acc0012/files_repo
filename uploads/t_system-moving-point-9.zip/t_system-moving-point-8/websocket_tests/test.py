import asyncio
import websockets

URLS = [
    "wss://marketfeed101.up.railway.app/ws/market/13/",
]


async def test_socket(url):

    print("=" * 80)
    print(f"Connecting -> {url}")

    try:

        async with websockets.connect(url, ping_interval=20, ping_timeout=20) as ws:

            print(f"CONNECTED -> {url}")

            count = 0

            async for message in ws:

                count += 1

                print("-" * 80)
                print(f"Message #{count}")
                print(message)

    except Exception as e:

        print(f"ERROR -> {url}")
        print(type(e).__name__)
        print(str(e))


async def main():

    tasks = [asyncio.create_task(test_socket(url)) for url in URLS]

    await asyncio.gather(*tasks)


if __name__ == "__main__":

    asyncio.run(main())
