import json
import logging

from channels.generic.websocket import AsyncWebsocketConsumer

logger = logging.getLogger(__name__)


class MarketFeedConsumer(AsyncWebsocketConsumer):

    # -------------------------------------------------
    # CONNECT
    # -------------------------------------------------

    async def connect(self):
        try:
            # Global group (can be changed later to user-specific)
            self.group_name = "market_feed"

            await self.channel_layer.group_add(
                self.group_name,
                self.channel_name
            )

            await self.accept()

            logger.info(f"[WS CONNECTED] Channel: {self.channel_name}")

        except Exception as e:
            logger.error(f"[WS CONNECT ERROR] {e}")
            await self.close()

    # -------------------------------------------------
    # DISCONNECT
    # -------------------------------------------------

    async def disconnect(self, close_code):
        try:
            await self.channel_layer.group_discard(
                self.group_name,
                self.channel_name
            )

            logger.info(
                f"[WS DISCONNECTED] Channel: {self.channel_name}, Code: {close_code}"
            )

        except Exception as e:
            logger.error(f"[WS DISCONNECT ERROR] {e}")

    # -------------------------------------------------
    # RECEIVE (CLIENT -> SERVER)
    # -------------------------------------------------

    async def receive(self, text_data=None, bytes_data=None):
        """
        Optional: Handle messages from client
        """
        try:
            if text_data:
                data = json.loads(text_data)

                logger.info(f"[WS RECEIVE] {data}")

                # You can extend this later:
                # e.g., dynamic subscribe/unsubscribe via websocket

                await self.send(text_data=json.dumps({
                    "status": "received",
                    "data": data
                }))

        except Exception as e:
            logger.error(f"[WS RECEIVE ERROR] {e}")

    # -------------------------------------------------
    # SEND MARKET DATA (SERVER -> CLIENT)
    # -------------------------------------------------

    async def send_market_data(self, event):
        try:
            message = event.get("data", {})

            # Ensure it's JSON serializable
            if not isinstance(message, (dict, list)):
                message = {"data": str(message)}

            await self.send(text_data=json.dumps(message))

        except Exception as e:
            logger.error(f"[WS SEND ERROR] {e}")

            # Optional: close broken connection
            await self.close()