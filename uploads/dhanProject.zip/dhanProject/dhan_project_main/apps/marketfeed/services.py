import os
import threading

from dhanhq.marketfeed import MarketFeed
from dhanhq.dhan_context import DhanContext
from dotenv import load_dotenv

# =====================================================
# LOAD ENV VARIABLES
# =====================================================

load_dotenv()

CLIENT_ID = os.getenv("DHAN_ID")
ACCESS_TOKEN = os.getenv("ACCESS_TOKEN")

if not CLIENT_ID or not ACCESS_TOKEN:
    raise Exception("DHAN credentials missing in .env")

# =====================================================
# DHAN CONTEXT (GLOBAL)
# =====================================================

dhan_context = DhanContext(CLIENT_ID, ACCESS_TOKEN)

# =====================================================
# THREAD LOCK (FOR SAFETY)
# =====================================================

lock = threading.Lock()

# =====================================================
# MARKET FEED SERVICE
# =====================================================

class MarketFeedService:

    def __init__(self):
        self.feed = None
        self.is_running = False

    # -------------------------------------------------
    # START FEED
    # -------------------------------------------------

    def start_feed(self, instruments, callbacks):
        with lock:
            if self.is_running:
                print("[INFO] Feed already running")
                return self.feed

            try:
                print("[INFO] Starting market feed...")

                self.feed = MarketFeed(
                    dhan_context=dhan_context,
                    instruments=instruments,
                    version="v2",
                    **callbacks
                )

                self.feed.start()

                self.is_running = True

                print("[INFO] Market feed started successfully")

                return self.feed

            except Exception as e:
                print(f"[ERROR] Failed to start feed: {e}")
                self.is_running = False
                raise

    # -------------------------------------------------
    # SUBSCRIBE SYMBOLS
    # -------------------------------------------------

    def subscribe(self, instruments):
        if not self.feed:
            raise Exception("Feed is not started")

        try:
            with lock:
                print(f"[INFO] Subscribing: {instruments}")
                self.feed.subscribe_symbols(instruments)

        except Exception as e:
            print(f"[ERROR] Subscribe failed: {e}")
            raise

    # -------------------------------------------------
    # UNSUBSCRIBE SYMBOLS
    # -------------------------------------------------

    def unsubscribe(self, instruments):
        if not self.feed:
            raise Exception("Feed is not started")

        try:
            with lock:
                print(f"[INFO] Unsubscribing: {instruments}")
                self.feed.unsubscribe_symbols(instruments)

        except Exception as e:
            print(f"[ERROR] Unsubscribe failed: {e}")
            raise

    # -------------------------------------------------
    # STOP FEED (OPTIONAL BUT IMPORTANT)
    # -------------------------------------------------

    def stop_feed(self):
        if self.feed:
            try:
                print("[INFO] Closing market feed...")
                self.feed.close_connection()
                self.feed = None
                self.is_running = False
                print("[INFO] Feed stopped successfully")
            except Exception as e:
                print(f"[ERROR] Failed to stop feed: {e}")