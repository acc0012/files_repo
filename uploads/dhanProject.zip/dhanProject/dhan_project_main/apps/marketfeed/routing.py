from django.urls import path
from .consumers import MarketFeedConsumer

websocket_urlpatterns = [
    path('ws/market/', MarketFeedConsumer.as_asgi()),
]