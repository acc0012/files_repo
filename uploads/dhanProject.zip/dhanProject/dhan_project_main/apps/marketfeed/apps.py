from django.apps import AppConfig


class MarketfeedConfig(AppConfig):
    name = "apps.marketfeed"