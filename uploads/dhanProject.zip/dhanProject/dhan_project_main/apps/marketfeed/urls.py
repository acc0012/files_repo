from django.urls import path
from . import views

urlpatterns = [
    path('start/', views.start_feed),
    path('subscribe/', views.subscribe),
    path('unsubscribe/', views.unsubscribe),
    path('stop/', views.stop_feed),   # ✅ ADD THIS
]