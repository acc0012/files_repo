from rest_framework.decorators import api_view
from rest_framework.response import Response

from channels.layers import get_channel_layer

import asyncio

from dhanhq.marketfeed import MarketFeed
from apps.marketfeed.services import MarketFeedService


# =====================================================
# SINGLETON SERVICE
# =====================================================

feed_service = None

def get_feed_service():
    global feed_service
    if feed_service is None:
        feed_service = MarketFeedService()
    return feed_service


# =====================================================
# WEBSOCKET CHANNEL LAYER
# =====================================================

channel_layer = get_channel_layer()


# =====================================================
# CONSTANT MAPS (FOR CLEAN INPUT FORMAT)
# =====================================================

SEGMENT_MAP = {
    "IDX": MarketFeed.IDX,
    "NSE_FNO": MarketFeed.NSE_FNO,
}

TYPE_MAP = {
    "Quote": MarketFeed.Quote,
    "Full": MarketFeed.Full,
}


# =====================================================
# INSTRUMENT FORMAT CONVERTER
# =====================================================

def convert_to_tuple_format(instruments):
    result = []

    for inst in instruments:
        try:
            if isinstance(inst, dict):
                segment = SEGMENT_MAP[inst["segment"]]
                security_id = str(inst["security_id"])
                sub_type = TYPE_MAP[inst["type"]]

                result.append((segment, security_id, sub_type))

            elif isinstance(inst, list):
                result.append(tuple(inst))

            elif isinstance(inst, tuple):
                result.append(inst)

        except Exception as e:
            print(f"[ERROR] Invalid instrument: {inst} => {e}")

    print(f"[DEBUG] Converted instruments: {result}")
    return result


# =====================================================
# CALLBACKS (FINAL FIXED + DEBUG)
# =====================================================

def on_message(instance, message):
    try:
        if not channel_layer:
            print("[ERROR] Channel layer not initialized")
            return

        async def send():
            await channel_layer.group_send(
                "market_feed",
                {
                    "type": "send_market_data",
                    "data": message
                }
            )

        try:
            loop = asyncio.get_running_loop()
            loop.create_task(send())
        except RuntimeError:
            asyncio.run(send())

        # # ✅ CLEAN LOG ONLY (NO RAW DATA)
        # print("[INFO] WebSocket data pushed successfully")

    except Exception as e:
        print(f"[ERROR] WebSocket send failed: {e}")

# =====================================================
# START FEED
# =====================================================

@api_view(['POST'])
def start_feed(request):
    try:
        instruments = request.data.get("instruments", [])

        if not instruments:
            return Response(
                {"error": "instruments required"},
                status=400
            )

        service = get_feed_service()

        if service.is_running:
            return Response({
                "status": "already_running",
                "websocket_url": "ws://127.0.0.1:8000/ws/market/"
            })

        callbacks = {
            "on_message": on_message
        }

        parsed = convert_to_tuple_format(instruments)

        service.start_feed(parsed, callbacks)

        return Response({
            "status": "feed_started",
            "parsed": parsed,
            "websocket_url": "ws://127.0.0.1:8000/ws/market/"
        })

    except Exception as e:
        return Response({
            "error": f"Failed to start feed: {str(e)}"
        }, status=500)


# =====================================================
# SUBSCRIBE
# =====================================================

@api_view(['POST'])
def subscribe(request):
    try:
        instruments = request.data.get("instruments", [])

        if not instruments:
            return Response(
                {"error": "instruments required"},
                status=400
            )

        service = get_feed_service()

        if not service.is_running:
            return Response(
                {"error": "feed not started"},
                status=400
            )

        parsed = convert_to_tuple_format(instruments)

        service.subscribe(parsed)

        return Response({
            "status": "subscribed",
            "parsed": parsed
        })

    except Exception as e:
        return Response({
            "error": f"Subscribe failed: {str(e)}"
        }, status=500)


# =====================================================
# UNSUBSCRIBE
# =====================================================

@api_view(['POST'])
def unsubscribe(request):
    try:
        instruments = request.data.get("instruments", [])

        if not instruments:
            return Response(
                {"error": "instruments required"},
                status=400
            )

        service = get_feed_service()

        if not service.is_running:
            return Response(
                {"error": "feed not started"},
                status=400
            )

        parsed = convert_to_tuple_format(instruments)

        service.unsubscribe(parsed)

        return Response({
            "status": "unsubscribed",
            "parsed": parsed
        })

    except Exception as e:
        return Response({
            "error": f"Unsubscribe failed: {str(e)}"
        }, status=500)


# =====================================================
# STOP FEED
# =====================================================

@api_view(['POST'])
def stop_feed(request):
    try:
        service = get_feed_service()

        if not service.is_running:
            return Response({"status": "already_stopped"})

        service.stop_feed()

        return Response({"status": "feed_stopped"})

    except Exception as e:
        return Response({
            "error": f"Stop failed: {str(e)}"
        }, status=500)
