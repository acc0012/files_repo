from rest_framework.viewsets import ModelViewSet
from .models import Instrument
from .serializers import InstrumentSerializer

class InstrumentViewSet(ModelViewSet):
    queryset = Instrument.objects.all()
    serializer_class = InstrumentSerializer