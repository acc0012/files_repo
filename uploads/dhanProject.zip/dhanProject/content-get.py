import html
import os
import pyperclip


def should_ignore_dir(dirname, ignore_dirs):
    return dirname.lower() in [d.lower() for d in ignore_dirs]


def should_ignore_file(filename, ignore_files):
    filename = filename.lower()

    for item in ignore_files:
        item = item.lower()

        # extension ignore
        if item.startswith(".") and filename.endswith(item):
            return True

        # exact filename ignore
        if filename == item:
            return True

    return False


def is_large_file(file_path, max_lines=1500):
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            for i, _ in enumerate(f):
                if i > max_lines:
                    return True
        return False
    except Exception:
        return True


def clean_content(content):
    """Remove extra spaces, blank lines, and fix HTML escaped chars."""

    content = html.unescape(content)

    lines = content.splitlines()

    cleaned_lines = []
    prev_blank = False

    for line in lines:
        stripped = line.rstrip()

        if stripped == "":
            if not prev_blank:
                cleaned_lines.append("")
            prev_blank = True
        else:
            cleaned_lines.append(stripped)
            prev_blank = False

    return "\n".join(cleaned_lines).strip()


def collect_files_content(root_folder, output_file):

    ignore_dirs = [
        "__pycache__",
        ".git",
        ".idea",
        "node_modules",
        "venv",
        "env",
        "temp",
        "samples",
        "migrations",
        "test",
        "tests",
        "files",
        "output"
    ]

    ignore_files = [
        ".env",
        ".pyc",
        ".log",
        "db.sqlite3",
        "content-get.py"
    ]

    detected_files = []

    with open(output_file, 'w', encoding='utf-8') as outfile:

        print("\n📂 Detecting files...\n")

        for root, dirs, files in os.walk(root_folder):

            # Ignore folders properly
            dirs[:] = [
                d for d in dirs
                if not should_ignore_dir(d, ignore_dirs)
            ]

            for file in files:

                # Ignore files properly
                if should_ignore_file(file, ignore_files):
                    continue

                file_path = os.path.join(root, file)

                try:
                    if os.path.getsize(file_path) == 0:
                        continue
                except:
                    continue

                if is_large_file(file_path):
                    print(f"⚠️ Skipping large file: {file_path}")
                    continue

                detected_files.append(file_path)

        # =========================
        # PRINT DETECTED FILES
        # =========================

        print("\n" + "=" * 80)
        print("✅ DETECTED FILES LIST")
        print("=" * 80)

        for index, file_path in enumerate(detected_files, start=1):
            print(f"{index}. {file_path}")

        print("=" * 80)
        print(f"📁 Total files detected: {len(detected_files)}")
        print("=" * 80 + "\n")

        # =========================
        # WRITE FILE CONTENTS
        # =========================

        for index, file_path in enumerate(detected_files, start=1):

            print(
                f"📄 Processing file {index}/{len(detected_files)} "
                f"=> {file_path}"
            )

            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()

                cleaned = clean_content(content)

                if not cleaned:
                    continue

                outfile.write("\n" + "=" * 80 + "\n")
                outfile.write(f"FILE: {file_path}\n")
                outfile.write("=" * 80 + "\n\n")
                outfile.write(cleaned)
                outfile.write("\n\n")

            except Exception as e:
                print(f"❌ Error reading {file_path}: {e}")


def main():

    folder_path = input("Enter folder path: ").strip()
    output_file = "combined_output.txt"

    if not os.path.exists(folder_path):
        print("❌ Invalid folder path")
        return

    collect_files_content(folder_path, output_file)

    print(f"\n✅ Clean content saved to: {output_file}")

    try:
        with open(output_file, 'r', encoding='utf-8') as f:
            final_content = f.read()

        pyperclip.copy(final_content)

        print("📋 Content copied to clipboard successfully!")

    except Exception as e:
        print(f"❌ Failed to copy to clipboard: {e}")


if __name__ == "__main__":
    main()