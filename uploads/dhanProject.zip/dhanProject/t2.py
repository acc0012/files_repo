from dhanhq import marketfeed
import os,json
from dotenv import load_dotenv

load_dotenv()


# Add your Dhan Client ID and Access Token
client_id = os.getenv("DHAN_ID")
access_token = os.getenv("ACCESS_TOKEN")

# Structure for subscribing is (exchange_segment, "security_id", subscription_type)

instruments = [(marketfeed.IDX, "13", marketfeed.Ticker),   # Ticker - Ticker Data
   ]

version = "v2"          # Mention Version and set to latest version 'v2'

# In case subscription_type is left as blank, by default Ticker mode will be subscribed.

try:
    data = marketfeed.DhanFeed(client_id, access_token, instruments, version)
    while True:
        data.run_forever()
        response = data.get_data()
        print(response)

except Exception as e:
    print(e)

# Close Connection