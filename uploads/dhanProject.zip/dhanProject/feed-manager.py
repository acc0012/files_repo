import os
import time
import logging
from datetime import datetime

from dotenv import load_dotenv

from dhanhq.marketfeed import MarketFeed
from dhanhq.dhan_context import DhanContext

# =====================================================
# LOGGING SETUP
# =====================================================

LOG_DIR = "logs"

os.makedirs(LOG_DIR, exist_ok=True)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

LOG_FILE = os.path.join(LOG_DIR, f"market_feed_{timestamp}.log")

logger = logging.getLogger("MarketFeedLogger")

logger.setLevel(logging.INFO)

logger.handlers.clear()

formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")

# -----------------------------------------------------
# FILE LOGGER
# -----------------------------------------------------

file_handler = logging.FileHandler(LOG_FILE, encoding="utf-8")

file_handler.setFormatter(formatter)

logger.addHandler(file_handler)

# -----------------------------------------------------
# CONSOLE LOGGER
# -----------------------------------------------------

console_handler = logging.StreamHandler()

console_handler.setFormatter(formatter)

logger.addHandler(console_handler)


# =====================================================
# LOG HELPER
# =====================================================


def log(message, level="info"):

    print(message)

    if level == "info":

        logger.info(message)

    elif level == "warning":

        logger.warning(message)

    elif level == "error":

        logger.error(message)

    else:

        logger.info(message)


# =====================================================
# LOAD ENV
# =====================================================

load_dotenv()

CLIENT_ID = os.getenv("DHAN_ID")

ACCESS_TOKEN = os.getenv("ACCESS_TOKEN")

if not CLIENT_ID:

    raise Exception("DHAN_ID missing in .env")

if not ACCESS_TOKEN:

    raise Exception("ACCESS_TOKEN missing in .env")


# =====================================================
# DHAN CONTEXT
# =====================================================

dhan_context = DhanContext(CLIENT_ID, ACCESS_TOKEN)


# =====================================================
# CALLBACKS
# =====================================================


def on_connect(instance):

    log("=" * 100)

    log("WEBSOCKET CONNECTED SUCCESSFULLY")

    log("=" * 100)


def on_message(instance, message):

    log("-" * 100)

    log(f"LIVE DATA => {message}")

    log("-" * 100)


def on_close(instance):

    log("=" * 100)

    log("WEBSOCKET CONNECTION CLOSED", "warning")

    log("=" * 100)


def on_error(instance, error):

    log("=" * 100)

    log(f"WEBSOCKET ERROR => {error}", "error")

    log("=" * 100)


# =====================================================
# INSTRUMENTS
# =====================================================

instruments = [
    (MarketFeed.IDX, "13", MarketFeed.Quote),
    (MarketFeed.IDX, "51", MarketFeed.Quote),
    # OPTIONS
    # (
    #     MarketFeed.NSE_FNO,
    #     "41726",
    #     MarketFeed.Quote
    # ),
]


# =====================================================
# VERSION
# =====================================================

version = "v2"


# =====================================================
# MAIN
# =====================================================

feed = None

try:

    log("=" * 100)

    log("INITIALIZING MARKET FEED")

    log("=" * 100)

    # -------------------------------------------------
    # CREATE FEED
    # -------------------------------------------------

    feed = MarketFeed(
        dhan_context=dhan_context,
        instruments=instruments,
        version=version,
        on_connect=on_connect,
        on_message=on_message,
        on_close=on_close,
        on_error=on_error,
    )

    log("MARKET FEED INITIALIZED")

    log(f"TOTAL INSTRUMENTS => " f"{len(instruments)}")

    # -------------------------------------------------
    # START FEED THREAD
    # -------------------------------------------------

    log("=" * 100)

    log("STARTING WEBSOCKET THREAD")

    log("=" * 100)

    feed_thread = feed.start()

    log("WEBSOCKET THREAD STARTED")

    # -------------------------------------------------
    # WAIT FOR CONNECTION
    # -------------------------------------------------

    time.sleep(10)

    # -------------------------------------------------
    # UNSUBSCRIBE TEST
    # -------------------------------------------------

    log("=" * 100)

    log("STARTING UNSUBSCRIBE TEST")

    log("=" * 100)

    unsub_instruments = [(MarketFeed.IDX, "13", MarketFeed.Quote)]

    feed.unsubscribe_symbols(unsub_instruments)

    log("UNSUBSCRIBE COMPLETED")

    log(f"UNSUBSCRIBED => " f"{unsub_instruments}")

    # -------------------------------------------------
    # WAIT
    # -------------------------------------------------

    time.sleep(10)

    # -------------------------------------------------
    # RESUBSCRIBE TEST
    # -------------------------------------------------

    log("=" * 100)

    log("STARTING RESUBSCRIBE TEST")

    log("=" * 100)

    sub_instruments = [(MarketFeed.IDX, "13", MarketFeed.Quote)]

    feed.subscribe_symbols(sub_instruments)

    log("RESUBSCRIBE COMPLETED")

    log(f"SUBSCRIBED => " f"{sub_instruments}")

    # -------------------------------------------------
    # KEEP RUNNING
    # -------------------------------------------------

    while True:

        time.sleep(1)

except KeyboardInterrupt:

    log("KEYBOARD INTERRUPT RECEIVED", "warning")

except Exception as e:

    log(f"MAIN ERROR => {e}", "error")

finally:

    try:

        if feed:

            log("=" * 100)

            log("DISCONNECTING WEBSOCKET")

            log("=" * 100)

            feed.close_connection()

            log("WEBSOCKET DISCONNECTED")

            log(f"LOG FILE SAVED => " f"{LOG_FILE}")

    except Exception as e:

        log(f"DISCONNECT ERROR => {e}", "error")
