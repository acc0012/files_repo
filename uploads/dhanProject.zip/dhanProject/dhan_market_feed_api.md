# 📡 DHAN MARKET FEED API DOCUMENTATION

## ✅ Base URL
```
http://127.0.0.1:8000
```

---

# 📊 INSTRUMENT APIs

## 1. Get All Instruments
```
GET /api/instruments/
```

### Response
```json
[
  {
    "id": 1,
    "exchange_segment": 0,
    "security_id": "13",
    "subscription_type": 17
  }
]
```

---

## 2. Create Instrument
```
POST /api/instruments/
```

### Body
```json
{
  "exchange_segment": 0,
  "security_id": "13",
  "subscription_type": 17
}
```

---

# 🚀 MARKET FEED APIs

---

## 1. Start Feed
```
POST /api/feed/start/
```

### Description
- Starts Dhan WebSocket connection
- Must be called first

### Body
```json
{
  "instruments": [
    [0, "13", 17]
  ]
}
```

### Response
```json
{
  "status": "feed_started",
  "parsed": [[0, "13", 17]],
  "websocket_url": "ws://127.0.0.1:8000/ws/market/"
}
```

---

## 2. Subscribe Instruments
```
POST /api/feed/subscribe/
```

### Description
- Add instruments to running feed

### Body
```json
{
  "instruments": [
    [0, "51", 17]
  ]
}
```

### Response
```json
{
  "status": "subscribed",
  "parsed": [[0, "51", 17]]
}
```

---

## 3. Unsubscribe Instruments
```
POST /api/feed/unsubscribe/
```

### Description
- Remove instruments from feed

### Body
```json
{
  "instruments": [
    [0, "13", 17]
  ]
}
```

---

## 4. Stop Feed
```
POST /api/feed/stop/
```

### Description
- Stops Dhan WebSocket connection

### Response
```json
{
  "status": "feed_stopped"
}
```

---

# 🔌 WEBSOCKET API

## Connect Endpoint
```
ws://127.0.0.1:8000/ws/market/
```

### JavaScript Example
```javascript
const ws = new WebSocket("ws://127.0.0.1:8000/ws/market/");

ws.onmessage = (event) => {
    console.log(JSON.parse(event.data));
};
```

---

# ✅ DATA FORMAT

### Incoming Market Data Example
```json
{
  "type": "Quote Data",
  "exchange_segment": 0,
  "security_id": 13,
  "LTP": "23423.40"
}
```

---

# ⚠️ IMPORTANT NOTES

- Call `/start/` only once
- Use `/subscribe/` to add more instruments
- WebSocket must be connected to receive data
- Feed must be running before subscribe/unsubscribe

---

# ✅ FLOW

1. Start Feed
2. Subscribe Instruments
3. Connect WebSocket
4. Receive Live Data

---

# 🎯 STATUS

✅ Fully working real-time system
✅ Supports dynamic subscriptions
✅ WebSocket streaming enabled
