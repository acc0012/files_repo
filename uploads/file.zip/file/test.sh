cd NodeJS/
rm -rf ./test-report.xml && CI=true ./node_modules/.bin/jest --runInBand --testResultsProcessor ./node_modules/jest-junit-reporter --forceExit;
cd ../ReactJS/
rm -rf ./junit.xml && CI=true ./node_modules/.bin/react-scripts test src/tests/App.test.js --testResultsProcessor=\"jest-junit\" --watchAll=false