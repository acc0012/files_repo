import React, { useEffect, useState } from "react";
import axios from "axios";
import "./App.css";

function Home() {
  const [data, setData] = useState([]);
  const [rating, setRating] = useState(1);
  const [refresh, setrefresh] = useState(1);

  const handleApply = async (id) => {
    // Write your code here
  };

  const handleRating = () => {
    // Write your code here
  };

  const handleAddRating = async (id) => {
    // Write your code here
  };

  const handleDrop = async (id) => {
    // Write your code here
  };
  return (
    <div className="home">
      <header>
        <h2>ABC Learning</h2>
      </header>
      {/* write your code here */}
      <div className="cardContainer">
        
        <div className="card">
          <ul>
            <div className="header">
              {/* course name */}
              <li data-testid="course-name"></li>
              {/* course dept */}
              <li data-testid="course-dept"></li>
              {/* course description */}
              <li data-testid="course-description"></li>
              <li>
                <>
                  Rate:
                  <select
                    className="rating"
                    name="rating"
                    data-testid="select-box"
                  >
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                    <option>5</option>
                  </select>
                  <button className="rate" data-testid="add-rate">
                    Add
                  </button>
                </>

                <button className="drop" data-testid="drop">
                  Drop Course
                </button>
              </li>
              <li>
                <button className="btn" data-testid="apply">
                  Apply
                </button>
              </li>
            </div>
            <div className="footer">
              {/* footer contents */}
              <li data-testid="footer"></li>
            </div>
          </ul>
        </div>

      </div>
    </div>
  );
}

export default Home;
