export const mockdata1 = [
    {
      _id: "5ff5706baf74d71378df935f",
      courseName: "Node.js",
      courseDept: "WD",
      description: "Node.js is used to create back-end services",
      duration: 10,
      isRated: false,
      isApplied: true,
      noOfRatings: 15,
      rating: 4.5,
    },
    {
      _id: "5ff5706baf74d71378df9360",
      courseName: "React.js",
      courseDept: "WD",
      description: "React.js is used to create front-end services",
      duration: 14,
      isRated: true,
      isApplied: true,
      noOfRatings: 145,
      rating: 4.3,
    },
    {
      _id: "5ff5706baf74d71378df9361",
      courseName: "Angular",
      courseDept: "WD",
      description: "Angular is used to create front-end services",
      duration: 18,
      isRated: true,
      isApplied: false,
      noOfRatings: 10,
      rating: 4.1,
    },
  ];

export const applySuccessMsg = "You have successfully enrolled for this course"