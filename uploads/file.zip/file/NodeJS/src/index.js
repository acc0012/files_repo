const app = require("./app");

//making app to listen on port 8001
app.listen(8001, () => {
    console.log("App is running on port 8001");
});