const mongoose = require("mongoose");

// Simplified schema that aligns with the test data and avoids over-restrictive validators
const courseSchema = new mongoose.Schema(
  {
    courseName: {
      type: String,
      required: true,
      trim: true,
    },
    courseDept: {
      type: String,
      required: true,
      trim: true, // tests use values like "WD", "AI"
    },
    description: {
      type: String,
      required: true,
      trim: true,
    },
    duration: {
      type: Number,
      required: true,
      min: 0, // allow all positive durations used in tests
    },
    isRated: {
      type: Boolean,
      default: false,
    },
    isApplied: {
      type: Boolean,
      default: false,
    },
    noOfRatings: {
      type: Number,
      default: 0,
    },
    rating: {
      type: Number,
      default: 0.0, // average rating
    },
  },
  {
    timestamps: true,
    versionKey: false, // keep responses clean for tests
  }
);

// (Optional) The virtual is not needed for the tests; keep it only if used elsewhere
// courseSchema.virtual("courseId", {
//   ref: "AppliedCourses",
//   localField: "_id",
//   foreignField: "courseID",
// });

const Course = mongoose.model("Course", courseSchema);

module.exports = Course;
