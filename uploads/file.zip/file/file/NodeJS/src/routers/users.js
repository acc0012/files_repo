const express = require("express");
const Course = require("../mongoose/models/courses");

const router = express.Router();

// GET /courses/get
router.get("/get", async (req, res) => {
  try {
    const courses = await Course.find({}).sort({ _id: 1 });
    res.status(200).send(courses);
  } catch (e) {
    res.status(500).send();
  }
});

// POST /courses/enroll/:id
router.post("/enroll/:id", async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    if (!course) return res.sendStatus(404);
    if (course.isApplied) return res.sendStatus(403);

    course.isApplied = true;
    await course.save();
    res.sendStatus(200);
  } catch (e) {
    res.status(500).send();
  }
});

// DELETE /courses/drop/:id
router.delete("/drop/:id", async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    if (!course) return res.sendStatus(404);
    if (!course.isApplied) return res.sendStatus(403);

    course.isApplied = false;
    await course.save();
    res.sendStatus(200);
  } catch (e) {
    res.status(500).send();
  }
});

// PATCH /courses/rating/:id
router.patch("/rating/:id", async (req, res) => {
  try {
    const { rating } = req.body;
    const course = await Course.findById(req.params.id);

    if (!course) return res.sendStatus(404);
    if (!course.isApplied) return res.sendStatus(403); // must be enrolled
    if (course.isRated) return res.sendStatus(403);    // can't rate twice

    if (typeof rating !== "number" || rating < 0 || rating > 5) {
      return res.sendStatus(400);
    }

    const total = course.rating * course.noOfRatings + rating;
    const newCount = course.noOfRatings + 1;
    const avg = total / newCount;

    course.noOfRatings = newCount;
    course.rating = Math.round(avg * 10) / 10; // one decimal place
    course.isRated = true;

    await course.save();
    res.sendStatus(200);
  } catch (e) {
    res.status(500).send();
  }
});

module.exports = router;