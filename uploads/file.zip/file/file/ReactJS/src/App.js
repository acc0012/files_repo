import React, { useEffect, useState } from "react";
import axios from "axios";
import "./App.css";

function Home() {
  const [data, setData] = useState([]);
  const [rating, setRating] = useState(1);
  const [refresh, setRefresh] = useState(1);

  // Fetch data
  useEffect(() => {
    axios
      .get("http://localhost:8001/courses/get")
      .then((response) => {
        setData(response.data);
      })
      .catch((err) => console.log(err));
  }, [refresh]);

  // Apply Course
  const handleApply = async (id) => {
    const res = await axios.post(
      `http://localhost:8001/courses/enroll/${id}`
    );
    window.alert(res.message || res.data.message);
    setRefresh(refresh + 1);
  };

  // Track rating selection
  const handleRating = (e) => {
    setRating(Number(e.target.value));
  };

  // Add Rating
  const handleAddRating = async (id) => {
    await axios.patch(
      `http://localhost:8001/courses/rating/${id}`,
      { rating }
    );
    setRefresh(refresh + 1);
  };

  // Drop Course
  const handleDrop = async (id) => {
    await axios.delete(
      `http://localhost:8001/courses/drop/${id}`
    );
    setRefresh(refresh + 1);
  };

  return (
    <div className="home">
      <header>
        <h2>ABC Learning</h2>
      </header>

      <div className="cardContainer">
        {data.map((course) => (
          <div className="card" key={course._id}>
            <ul>
              <div className="header">
                {/* Course Name */}
                <li data-testid="course-name">{course.courseName}</li>

                {/* Course Dept */}
                <li data-testid="course-dept">{course.courseDept}</li>

                {/* Course Description */}
                <li data-testid="course-description">
                  {course.description}
                </li>

                {/* Rating Section */}
                <li>
                  <>
                    Rate:
                    <select
                      className="rating"
                      name="rating"
                      data-testid="select-box"
                      onChange={handleRating}
                    >
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>

                    <button
                      className="rate"
                      data-testid="add-rate"
                      onClick={() => handleAddRating(course._id)}
                    >
                      Add
                    </button>
                  </>

                  <button
                    className="drop"
                    data-testid="drop"
                    onClick={() => handleDrop(course._id)}
                  >
                    Drop Course
                  </button>
                </li>

                <li>
                  <button
                    className="btn"
                    data-testid="apply"
                    onClick={() => handleApply(course._id)}
                  >
                    Apply
                  </button>
                </li>
              </div>

              <div className="footer">
                <li data-testid="footer"></li>
              </div>
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Home;