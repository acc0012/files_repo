# inventoryapi/urls.py
from django.urls import re_path as url
from django.contrib import admin
from inventoryapp import views

urlpatterns = [
    url(r'^admin/', admin.site.urls),

    url(r'^inventory/items/$', views.InventoryItems.as_view()),
    url(r'^inventory/items/(?P<id>\d+)/$', views.InventoryItemDetail.as_view()),

    url(r'^items/sort/$', views.SortItems.as_view()),
    url(r'^items/query/(?P<category>[^/]+)/$', views.QueryCategory.as_view()),
]