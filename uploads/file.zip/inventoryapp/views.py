# inventoryapp/views.py
from django.db import IntegrityError
from django.http import Http404
from rest_framework.views import APIView
from rest_framework.response import Response
from .models import InventoryItem
from .serializer import InventorySerializer

class InventoryItems(APIView):
    def get(self, request):
        items = InventoryItem.objects.all().values()
        return Response(list(items), status=200)

    def post(self, request):
        serializer = InventorySerializer(data=request.data)
        if serializer.is_valid():
            try:
                item = serializer.save()
                data = {
                    "id": item.id,
                    "name": item.name,
                    "category": item.category,
                    "price": item.price,
                    "discount": item.discount,
                    "quantity": item.quantity,
                    "barcode": item.barcode,
                }
                return Response(data, status=201)
            except IntegrityError:
                return Response(
                    {"error": "inventory with this barcode already exists"},
                    status=400
                )
        return Response(serializer.errors, status=400)


class InventoryItemDetail(APIView):
    def delete(self, request, id):
        try:
            item = InventoryItem.objects.get(id=id)
        except InventoryItem.DoesNotExist:
            raise Http404
        item.delete()
        return Response(status=204)


class SortItems(APIView):
    def get(self, request):
        items = InventoryItem.objects.order_by('-price').values()
        return Response(list(items), status=200)


class QueryCategory(APIView):
    def get(self, request, category):
        items = InventoryItem.objects.filter(category=category).order_by('id').values()
        return Response(list(items), status=200)