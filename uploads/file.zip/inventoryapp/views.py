from rest_framework import viewsets, status
from rest_framework.views import APIView
from rest_framework.response import Response
from inventoryapp.models import Inventory
from inventoryapp.serializer import InventorySerializer
from django.db.models import Q

class InventoryViewSet(viewsets.ModelViewSet):
    queryset = Inventory.objects.all()
    serializer_class = InventorySerializer

class ItemSortView(APIView):
    def get(self, request):
        items = Inventory.objects.all().order_by('-price')
        serializer = InventorySerializer(items, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

class ItemQueryView(APIView):
    def get(self, request, category):
        items = Inventory.objects.filter(category=category)
        serializer = InventorySerializer(items, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)