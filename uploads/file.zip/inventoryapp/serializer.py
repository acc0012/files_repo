# inventoryapp/serializer.py
from rest_framework import serializers
from .models import InventoryItem

class InventorySerializer(serializers.ModelSerializer):
    class Meta:
        model = InventoryItem
        fields = "__all__"
        # Remove default UniqueValidator so we can return the exact custom error message from the view
        extra_kwargs = {
            'barcode': {'validators': []}
        }