from django.db import models

# Create your models here.
class Inventory(models.Model):
    name = models.CharField(max_length=255)
    category = models.CharField(max_length=255)
    price = models.IntegerField()
    discount = models.IntegerField()
    quantity = models.IntegerField()
    barcode = models.IntegerField(unique=True)
    
    class Meta:
        db_table = 'inventory'