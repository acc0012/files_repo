# inventoryapp/models.py
from django.db import models

class InventoryItem(models.Model):
    name = models.CharField(max_length=100)
    category = models.CharField(max_length=100)
    price = models.IntegerField()
    discount = models.IntegerField()
    quantity = models.IntegerField()
    barcode = models.CharField(max_length=50, unique=True)

    def __str__(self):
        return self.name
``