import os
import asyncio
from telethon import TelegramClient
from dotenv import load_dotenv

load_dotenv()

API_ID = int(os.getenv('TG_API_ID', '0'))
API_HASH = os.getenv('TG_API_HASH', '')
SESSION_PATH = os.getenv('TG_SESSION_PATH', './data/telethon.session')
PHONE = os.getenv('TG_PHONE')


async def main():
    os.makedirs('./data', exist_ok=True)
    client = TelegramClient(SESSION_PATH, API_ID, API_HASH)
    await client.start(phone=PHONE)  # prompts on first run
    me = await client.get_me()
    print('Logged in as:', me.username or me.first_name)
    print('Session saved at:', SESSION_PATH)
    await client.disconnect()


if __name__ == '__main__':
    asyncio.run(main())
