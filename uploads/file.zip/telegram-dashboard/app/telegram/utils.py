from telethon.tl.types import Channel, Chat, User


def classify_entity(entity) -> str:
    if isinstance(entity, Channel):
        return 'channel' if getattr(entity, 'broadcast', False) else 'supergroup'
    if isinstance(entity, Chat):
        return 'group'
    if isinstance(entity, User):
        return 'bot' if getattr(entity, 'bot', False) else 'user'
    return 'unknown'
