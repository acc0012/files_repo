import os
from telethon import TelegramClient
from app.core.config import settings

_client: TelegramClient | None = None


def ensure_data_dir():
    os.makedirs('./data', exist_ok=True)


async def start_client() -> TelegramClient:
    global _client
    if _client:
        return _client

    ensure_data_dir()
    _client = TelegramClient(settings.tg_session_path, settings.tg_api_id, settings.tg_api_hash)

    # Uses session if present; otherwise will prompt in terminal.
    await _client.start(phone=settings.tg_phone)
    return _client


async def stop_client():
    global _client
    if _client:
        await _client.disconnect()
        _client = None
