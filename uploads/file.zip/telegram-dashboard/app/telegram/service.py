from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timedelta

from telethon import events
from telethon.errors import FloodWaitError

from app.core.config import settings
from app.db.database import db_factory
from app.db.crud import upsert_dialog, inc_daily_message
from app.telegram.client import start_client
from app.telegram.utils import classify_entity

log = logging.getLogger('tg_service')


class TelegramService:
    """Runs Telethon client + background sync + realtime events."""

    def __init__(self, ws_manager):
        self.ws_manager = ws_manager
        self._task_sync: asyncio.Task | None = None
        self._client = None

    async def start(self):
        self._client = await start_client()

        # Wire up realtime handlers
        self._client.add_event_handler(self.on_new_message, events.NewMessage)

        # Kick off sync loop
        self._task_sync = asyncio.create_task(self.sync_loop())
        log.info('TelegramService started')

    async def stop(self):
        try:
            if self._client:
                self._client.remove_event_handler(self.on_new_message, events.NewMessage)
        except Exception:
            pass

        if self._task_sync:
            self._task_sync.cancel()
        log.info('TelegramService stopped')

    async def sync_loop(self):
        """Periodic sync of dialogs -> DB. Initial fetch is quick; then refresh periodically."""
        while True:
            try:
                await self.sync_dialogs_once(initial_only=True)
                # After initial, do a full refresh periodically
                await asyncio.sleep(settings.refresh_interval_seconds)
                await self.sync_dialogs_once(initial_only=False)
            except asyncio.CancelledError:
                raise
            except FloodWaitError as e:
                log.warning('FloodWaitError: sleeping %s seconds', e.seconds)
                await asyncio.sleep(e.seconds)
            except Exception as e:
                log.exception('sync_loop error: %s', e)
                await asyncio.sleep(10)

    async def sync_dialogs_once(self, initial_only: bool = True):
        """Sync dialogs; if initial_only True, sync only the first N quickly."""
        client = self._client
        if not client:
            return

        limit = settings.initial_dialog_sync if initial_only else None
        synced = 0

        async with db_factory() as db:
            async for d in client.iter_dialogs():
                entity = d.entity
                kind = classify_entity(entity)
                payload = {
                    'id': int(getattr(entity, 'id')),
                    'access_hash': int(getattr(entity, 'access_hash', 0) or 0) if getattr(entity, 'access_hash', None) else None,
                    'title': getattr(entity, 'title', '') or getattr(entity, 'first_name', '') or '',
                    'username': getattr(entity, 'username', None),
                    'kind': kind,
                    'unread_count': int(getattr(d, 'unread_count', 0) or 0),
                    'participants_count': getattr(entity, 'participants_count', None),
                    'last_message_at': getattr(d, 'date', None),
                }
                await upsert_dialog(db, payload)
                synced += 1

                if initial_only and limit and synced >= limit:
                    break

            await db.commit()

        # Notify clients (lightweight)
        await self.ws_manager.broadcast_json({'type': 'sync', 'synced': synced, 'initial_only': initial_only})
        log.info('Synced dialogs=%s initial_only=%s', synced, initial_only)

    async def on_new_message(self, event: events.NewMessage.Event):
        """Realtime message handler: update DB + broadcast update."""
        try:
            msg = event.message
            if not msg:
                return

            chat = await event.get_chat()
            kind = classify_entity(chat)
            dialog_id = int(getattr(chat, 'id'))

            payload = {
                'id': dialog_id,
                'access_hash': int(getattr(chat, 'access_hash', 0) or 0) if getattr(chat, 'access_hash', None) else None,
                'title': getattr(chat, 'title', '') or getattr(chat, 'first_name', '') or '',
                'username': getattr(chat, 'username', None),
                'kind': kind,
                # unread_count is not always available instantly; keep as-is if unknown
                'unread_count': 0,
                'participants_count': getattr(chat, 'participants_count', None),
                'last_message_at': msg.date,
            }

            async with db_factory() as db:
                # Keep existing unread_count if we set 0 here
                from app.db.models import Dialog
                existing = await db.get(Dialog, dialog_id)
                if existing:
                    payload['unread_count'] = existing.unread_count

                await upsert_dialog(db, payload)

                # Update daily stat (message count); unique senders tracking is omitted for realtime
                await inc_daily_message(db, dialog_id=dialog_id, day=msg.date.date(), sender_new=False)
                await db.commit()

            # Push to websocket clients
            await self.ws_manager.broadcast_json({
                'type': 'new_message',
                'dialog': {
                    'id': dialog_id,
                    'title': payload['title'],
                    'kind': kind,
                    'username': payload['username'],
                    'last_message_at': msg.date.isoformat() if msg.date else None,
                },
                'text_preview': (msg.message or '')[:140],
            })
        except Exception as e:
            log.warning('on_new_message failed: %s', e)
