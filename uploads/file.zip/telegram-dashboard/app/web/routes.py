from __future__ import annotations

from fastapi import APIRouter, Depends, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from app.core.config import settings
from app.db.database import get_db
from app.db.models import Dialog, DailyStat
from app.web.ws import ConnectionManager

router = APIRouter()


def _dialog_to_dict(d: Dialog) -> dict:
    return {
        'id': int(d.id),
        'title': d.title,
        'username': d.username,
        'kind': d.kind,
        'unread_count': int(d.unread_count),
        'participants_count': d.participants_count,
        'last_message_at': d.last_message_at.isoformat() if d.last_message_at else None,
        'updated_at': d.updated_at.isoformat() if d.updated_at else None,
    }


@router.get('/', response_class=HTMLResponse)
async def dashboard(request: Request, db: AsyncSession = Depends(get_db)):
    total = (await db.execute(select(func.count(Dialog.id)))).scalar_one()
    unread_total = (await db.execute(select(func.sum(Dialog.unread_count)))).scalar() or 0
    by_kind = (await db.execute(
        select(Dialog.kind, func.count(Dialog.id)).group_by(Dialog.kind)
    )).all()

    # top chats by messages (rolling window)
    top = (await db.execute(
        select(Dialog.title, func.sum(DailyStat.message_count).label('msgs'))
        .join(DailyStat, DailyStat.dialog_id == Dialog.id)
        .group_by(Dialog.id)
        .order_by(func.sum(DailyStat.message_count).desc())
        .limit(10)
    )).all()

    return request.app.state.templates.TemplateResponse(
        name='dashboard.html',
        context={
            'request': request,
            'title': settings.app_title,
            'total': int(total),
            'unread_total': int(unread_total),
            'kind_map': {k: int(v) for k, v in by_kind},
            'top': [{'title': t, 'msgs': int(m or 0)} for t, m in top],
        }
    )


@router.get('/dialogs', response_class=HTMLResponse)
async def dialogs_page(request: Request):
    # HTML shell; data comes via /api/dialogs in pages
    return request.app.state.templates.TemplateResponse(
        name='dialogs.html',
        context={'request': request, 'page_size': settings.dialogs_page_size}
    )


@router.get('/api/dialogs')
async def api_dialogs(
    offset: int = 0,
    limit: int = 50,
    kind: str | None = None,
    q: str | None = None,
    db: AsyncSession = Depends(get_db),
):
    limit = min(max(limit, 1), 200)

    stmt = select(Dialog)
    if kind:
        stmt = stmt.where(Dialog.kind == kind)
    if q:
        like = f"%{q.strip()}%"
        stmt = stmt.where(Dialog.title.ilike(like))

    stmt = stmt.order_by(Dialog.updated_at.desc()).offset(offset).limit(limit)
    rows = (await db.execute(stmt)).scalars().all()
    return {
        'offset': offset,
        'limit': limit,
        'items': [_dialog_to_dict(r) for r in rows],
        'next_offset': offset + len(rows),
        'has_more': len(rows) == limit,
    }


@router.get('/api/messages/daily')
async def api_daily_messages(kind: str | None = None, db: AsyncSession = Depends(get_db)):
    stmt = (
        select(DailyStat.day, func.sum(DailyStat.message_count))
        .join(Dialog, Dialog.id == DailyStat.dialog_id)
        .group_by(DailyStat.day)
        .order_by(DailyStat.day.asc())
    )
    if kind:
        stmt = stmt.where(Dialog.kind == kind)

    data = (await db.execute(stmt)).all()
    return {
        'labels': [str(d) for d, _ in data],
        'values': [int(v or 0) for _, v in data],
    }


@router.websocket('/ws')
async def websocket_endpoint(ws: WebSocket):
    manager: ConnectionManager = ws.app.state.ws_manager
    await manager.connect(ws)
    try:
        await ws.send_json({'type': 'hello', 'message': 'connected'})
        while True:
            # keepalive / receive client messages if needed
            _ = await ws.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(ws)
    except Exception:
        manager.disconnect(ws)
