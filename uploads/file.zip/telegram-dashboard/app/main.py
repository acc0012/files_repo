import asyncio
import os

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from app.core.config import settings
from app.core.logging import setup_logging
from app.db.database import engine
from app.db.models import Base
from app.web.routes import router as web_router
from app.web.ws import ConnectionManager
from app.telegram.service import TelegramService
from app.telegram.client import stop_client


async def init_db():
    os.makedirs('./data', exist_ok=True)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


def create_app() -> FastAPI:
    setup_logging()

    app = FastAPI(title=settings.app_title)
    app.mount('/static', StaticFiles(directory='app/static'), name='static')

    app.state.templates = Jinja2Templates(directory='app/templates')
    app.state.ws_manager = ConnectionManager()

    app.include_router(web_router)

    @app.on_event('startup')
    async def on_startup():
        await init_db()
        # start telegram service
        app.state.tg_service = TelegramService(app.state.ws_manager)
        await app.state.tg_service.start()

    @app.on_event('shutdown')
    async def on_shutdown():
        svc = getattr(app.state, 'tg_service', None)
        if svc:
            await svc.stop()
        await stop_client()

    return app


app = create_app()
