from __future__ import annotations

from datetime import datetime, date
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import Dialog, DailyStat


async def upsert_dialog(db: AsyncSession, payload: dict) -> Dialog:
    obj = await db.get(Dialog, payload['id'])
    if not obj:
        obj = Dialog(id=payload['id'])
        db.add(obj)

    for k, v in payload.items():
        setattr(obj, k, v)

    obj.updated_at = datetime.utcnow()
    return obj


async def inc_daily_message(db: AsyncSession, dialog_id: int, day: date, sender_new: bool = False):
    row = (await db.execute(
        select(DailyStat).where(DailyStat.dialog_id == dialog_id, DailyStat.day == day)
    )).scalar_one_or_none()

    if not row:
        row = DailyStat(dialog_id=dialog_id, day=day, message_count=0, unique_senders=0)
        db.add(row)

    row.message_count += 1
    if sender_new:
        row.unique_senders += 1


async def dashboard_counts(db: AsyncSession):
    total = (await db.execute(select(func.count(Dialog.id)))).scalar_one()
    unread_total = (await db.execute(select(func.sum(Dialog.unread_count)))).scalar() or 0
    by_kind = (await db.execute(
        select(Dialog.kind, func.count(Dialog.id)).group_by(Dialog.kind)
    )).all()

    return total, unread_total, {k: int(v) for k, v in by_kind}
