from __future__ import annotations

from datetime import datetime, date
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy import String, Integer, BigInteger, DateTime, Date, UniqueConstraint


class Base(DeclarativeBase):
    pass


class Dialog(Base):
    __tablename__ = 'dialogs'

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    access_hash: Mapped[int | None] = mapped_column(BigInteger, nullable=True)

    title: Mapped[str] = mapped_column(String(255), default='')
    username: Mapped[str | None] = mapped_column(String(255), nullable=True)

    # channel | group | supergroup | user | bot | unknown
    kind: Mapped[str] = mapped_column(String(32), index=True, default='unknown')

    unread_count: Mapped[int] = mapped_column(Integer, default=0)
    participants_count: Mapped[int | None] = mapped_column(Integer, nullable=True)

    last_message_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)


class DailyStat(Base):
    __tablename__ = 'daily_stats'
    __table_args__ = (UniqueConstraint('dialog_id', 'day', name='uq_dialog_day'),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    dialog_id: Mapped[int] = mapped_column(BigInteger, index=True)
    day: Mapped[date] = mapped_column(Date, index=True)

    message_count: Mapped[int] = mapped_column(Integer, default=0)
    unique_senders: Mapped[int] = mapped_column(Integer, default=0)
