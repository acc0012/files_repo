const tbody = document.getElementById('dialogsBody');
const hint = document.getElementById('loadingHint');
const sentinel = document.getElementById('sentinel');
const kindFilter = document.getElementById('kindFilter');
const searchBox = document.getElementById('searchBox');

let offset = 0;
let loading = false;
let done = false;
let currentKind = '';
let currentQuery = '';

function rowHtml(item) {
  return `
    <tr data-id="${item.id}">
      <td class="fw-semibold">${escapeHtml(item.title || '')}</td>
      <td><span class="badge text-bg-dark">${escapeHtml(item.kind)}</span></td>
      <td class="text-muted">${escapeHtml(item.username || '-') }</td>
      <td class="text-end">${item.unread_count ?? 0}</td>
      <td class="text-end">${item.participants_count ?? '-'}</td>
      <td class="text-muted">${escapeHtml(item.last_message_at || '-')}</td>
      <td class="text-muted">${escapeHtml(item.updated_at || '-') }</td>
    </tr>
  `;
}

function escapeHtml(s) {
  return String(s)
    .replaceAll('&','&amp;')
    .replaceAll('<','&lt;')
    .replaceAll('>','&gt;')
    .replaceAll('"','&quot;')
    .replaceAll("'",'&#039;');
}

async function loadMore() {
  if (loading || done) return;
  loading = true;
  hint.textContent = 'Loading…';

  const limit = window.__PAGE_SIZE__ || 50;
  const params = new URLSearchParams({ offset: String(offset), limit: String(limit) });
  if (currentKind) params.set('kind', currentKind);
  if (currentQuery) params.set('q', currentQuery);

  const res = await fetch(`/api/dialogs?${params.toString()}`);
  const data = await res.json();

  data.items.forEach(item => {
    tbody.insertAdjacentHTML('beforeend', rowHtml(item));
  });

  offset = data.next_offset;
  done = !data.has_more;
  loading = false;

  hint.textContent = done ? 'No more dialogs.' : 'Scroll to load more…';
}

function resetAndReload() {
  offset = 0;
  done = false;
  tbody.innerHTML = '';
  loadMore();
}

// Infinite scroll via IntersectionObserver
const io = new IntersectionObserver((entries) => {
  if (entries.some(e => e.isIntersecting)) {
    loadMore();
  }
});
io.observe(sentinel);

kindFilter.addEventListener('change', () => {
  currentKind = kindFilter.value;
  resetAndReload();
});

let searchTimer;
searchBox.addEventListener('input', () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => {
    currentQuery = searchBox.value.trim();
    resetAndReload();
  }, 300);
});

// Real-time updates: move updated dialog row to top + update last message time
function setupRealtime() {
  window.WS.onMessage((msg) => {
    if (msg.type !== 'new_message') return;

    const d = msg.dialog;
    const row = tbody.querySelector(`tr[data-id="${d.id}"]`);

    if (row) {
      // update last message
      const tds = row.querySelectorAll('td');
      if (tds && tds.length >= 6) {
        tds[5].textContent = d.last_message_at || '-';
      }
      // move to top
      tbody.removeChild(row);
      tbody.insertAdjacentElement('afterbegin', row);
    } else {
      // If row isn't loaded yet (not in current page), do nothing.
    }
  });
}

document.addEventListener('DOMContentLoaded', () => {
  loadMore();
  setupRealtime();
});
