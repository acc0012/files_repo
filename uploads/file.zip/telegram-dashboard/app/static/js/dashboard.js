let dailyChart;

async function renderDailyChart() {
  const res = await fetch('/api/messages/daily');
  const data = await res.json();

  const ctx = document.getElementById('dailyMessagesChart');
  if (!ctx) return;

  if (dailyChart) {
    dailyChart.data.labels = data.labels;
    dailyChart.data.datasets[0].data = data.values;
    dailyChart.update();
    return;
  }

  dailyChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: data.labels,
      datasets: [{
        label: 'Messages',
        data: data.values,
        borderColor: 'rgb(75, 192, 192)',
        tension: 0.2,
        fill: false
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: true } }
    }
  });
}

function setupRealtime() {
  const status = document.getElementById('rtStatus');
  window.WS.onStatus((st) => {
    if (status) status.textContent = `Real-time: ${st}`;
  });

  window.WS.onMessage(async (msg) => {
    if (msg.type === 'new_message') {
      // simplest: refresh chart; for huge loads, increment chart client-side
      await renderDailyChart();
    }
  });
}

document.addEventListener('DOMContentLoaded', async () => {
  await renderDailyChart();
  setupRealtime();
});
