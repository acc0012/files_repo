// Shared WebSocket helper (auto reconnect)

window.WS = (() => {
  let ws;
  let handlers = [];
  let statusHandlers = [];

  function notifyStatus(state) {
    statusHandlers.forEach(h => h(state));
  }

  function connect() {
    const proto = location.protocol === 'https:' ? 'wss' : 'ws';
    ws = new WebSocket(`${proto}://${location.host}/ws`);

    ws.onopen = () => {
      notifyStatus('open');
      // Keepalive ping every 20s
      ws._ping = setInterval(() => {
        try { ws.send('ping'); } catch (e) {}
      }, 20000);
    };

    ws.onmessage = (ev) => {
      try {
        const msg = JSON.parse(ev.data);
        handlers.forEach(h => h(msg));
      } catch (e) {
        // ignore
      }
    };

    ws.onclose = () => {
      notifyStatus('closed');
      if (ws && ws._ping) clearInterval(ws._ping);
      setTimeout(connect, 1500);
    };

    ws.onerror = () => {
      notifyStatus('error');
      try { ws.close(); } catch (e) {}
    };
  }

  function onMessage(handler) { handlers.push(handler); }
  function onStatus(handler) { statusHandlers.push(handler); }

  connect();

  return { onMessage, onStatus };
})();
