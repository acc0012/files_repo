from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file='.env', extra='ignore')

    tg_api_id: int = Field(alias='TG_API_ID')
    tg_api_hash: str = Field(alias='TG_API_HASH')
    tg_session_path: str = Field(default='./data/telethon.session', alias='TG_SESSION_PATH')
    tg_phone: str | None = Field(default=None, alias='TG_PHONE')

    app_title: str = Field(default='Telegram Dashboard', alias='APP_TITLE')
    refresh_interval_seconds: int = Field(default=120, alias='REFRESH_INTERVAL_SECONDS')
    days_of_stats: int = Field(default=14, alias='DAYS_OF_STATS')

    initial_dialog_sync: int = Field(default=200, alias='INITIAL_DIALOG_SYNC')
    dialogs_page_size: int = Field(default=50, alias='DIALOGS_PAGE_SIZE')

    database_url: str = Field(default='sqlite+aiosqlite:///./data/dashboard.db', alias='DATABASE_URL')


settings = Settings()
