# Telegram Dashboard (Telethon user session) — Infinite Scroll + Real-time (WebSockets)

This project builds a **Telegram analytics/dashboard** using:

- **Telethon (user session, not bot)**
- **FastAPI** + **Jinja2** templates for HTML
- **Chart.js** for charts
- **WebSockets** for real-time UI updates
- **SQLite** (async SQLAlchemy) as a cache to support pagination / fast loads

## 1) Setup

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scriptsctivate
pip install -r requirements.txt

cp .env.example .env
# Fill TG_API_ID, TG_API_HASH
```

## 2) Create Telethon session (one-time)

```bash
python scripts/init_session.py
```

It creates `./data/telethon.session`.

## 3) Run

```bash
uvicorn app.main:app --reload
```

Open:
- Dashboard: http://127.0.0.1:8000/
- Dialog list: http://127.0.0.1:8000/dialogs

## Notes
- The server runs a background Telethon client and:
  - does an initial dialog sync (first `INITIAL_DIALOG_SYNC`),
  - continues syncing remaining dialogs in the background,
  - listens to **NewMessage** events and broadcasts updates via WebSocket.
- Dialog list uses **infinite scroll**: initial page loads first batch, then loads more as you scroll.
