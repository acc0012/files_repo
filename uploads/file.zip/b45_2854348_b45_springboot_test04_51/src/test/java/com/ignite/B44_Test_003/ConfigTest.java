package com.ignite.B44_Test_003;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ignite.B44_Test_003.dto.AuthReqDto;
import com.ignite.B44_Test_003.dto.UserReqDto;
import com.ignite.B44_Test_003.model.User;
import com.ignite.B44_Test_003.repo.UserRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;


import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class ConfigTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @BeforeEach
    void setUp(){
        userRepo.deleteAll();

        userRepo.save(
                User.builder()
                        .userName("stranger@tcs.com")
                        .password(passwordEncoder.encode("Tcs#12345"))
                        .role("ADMIN")
                        .build()
        );

        userRepo.save(
                User.builder()
                        .userName("logesh@tcs.com")
                        .password(passwordEncoder.encode("Tcs#54321"))
                        .role("USER")
                        .build()
        );

    }

    @Test
    void testRegistrationWithAdminToken() throws Exception {
        MvcResult loginResult =mockMvc.perform(
                post("/api/v1/user/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(
                                objectMapper.writeValueAsString(
                                        AuthReqDto.builder()
                                                .userName("stranger@tcs.com")
                                                .password("Tcs#12345")
                                                .build()
                                )
                        )
        )
                .andExpect(status().isOk())
                .andReturn();


        /**
         *  Extracting jwt token from the response body with key authToken
         */
        String token=objectMapper.readTree(loginResult.getResponse().getContentAsString())
                .get("authToken").asText();

                mockMvc.perform(
                        post("/api/v1/user/register")
                                .header("Authorization","Bearer "+token)
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(
                                        objectMapper.writeValueAsString(
                                                UserReqDto.builder()
                                                        .userName("2718141@tcs.com")
                                                        .password("Tcs#12345")
                                                        .role("USER")
                                                        .build()
                                        )
                                )
                )
                .andExpect(status().isCreated());


    }

    @Test
    void testRegistrationWithUserToken() throws Exception {
        MvcResult loginResult =mockMvc.perform(
                        post("/api/v1/user/login")
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(
                                        objectMapper.writeValueAsString(
                                                AuthReqDto.builder()
                                                        .userName("logesh@tcs.com")
                                                        .password("Tcs#54321")
                                                        .build()
                                        )
                                )
                )
                .andExpect(status().isOk())
                .andReturn();


        /**
         *  Extracting jwt token from the response body with key authToken
         */
        String token=objectMapper.readTree(loginResult.getResponse().getContentAsString())
                .get("authToken").asText();

        MvcResult registerResult =mockMvc.perform(
                        post("/api/v1/user/register")
                                .header("Authorization","Bearer "+token)
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(
                                        objectMapper.writeValueAsString(
                                                UserReqDto.builder()
                                                        .userName("2718141@tcs.com")
                                                        .password("Tcs#12345")
                                                        .role("USER")
                                                        .build()
                                        )
                                )
                )
                .andExpect(status().isForbidden())
                .andReturn();
    }

    @Test
    void testRegistrationWithoutToken() throws Exception {
        MvcResult registerResult =mockMvc.perform(
                        post("/api/v1/user/register")
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(
                                        objectMapper.writeValueAsString(
                                                UserReqDto.builder()
                                                        .userName("2718141@tcs.com")
                                                        .password("Tcs#12345")
                                                        .role("USER")
                                                        .build()
                                        )
                                )
                )
                .andExpect(status().isUnauthorized())
                .andReturn();
    }


    @Test
    void testLoginWithWrongCredentials() throws Exception {
        mockMvc.perform(
                        post("/api/v1/user/login")
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(
                                        objectMapper.writeValueAsString(
                                                AuthReqDto.builder()
                                                        .userName("str@tcs.com")
                                                        .password("Tcs#12345")
                                                        .build()
                                        )
                                )
                )
                .andExpect(status().isUnauthorized());

    }

    @Test
    void testInvalidJwt() throws Exception {
        mockMvc.perform(
                        get("/api/v1/user/retrieveAll")
                                .header("Authorization","Bearer I am the Danger....")
                                .contentType(MediaType.APPLICATION_JSON)
                )
                .andExpect(status().isUnauthorized());
    }

    @Test
    void testRetrieveAllWithAdminToken() throws Exception {

        MvcResult loginResult =mockMvc.perform(
                        post("/api/v1/user/login")
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(
                                        objectMapper.writeValueAsString(
                                                AuthReqDto.builder()
                                                        .userName("stranger@tcs.com")
                                                        .password("Tcs#12345")
                                                        .build()
                                        )
                                )
                )
                .andExpect(status().isOk())
                .andReturn();

        /**
         *  Extracting jwt token from the response body with key authToken
         */
        String token=objectMapper.readTree(loginResult.getResponse().getContentAsString())
                .get("authToken").asText();

        mockMvc.perform(
                        get("/api/v1/user/retrieveAll")
                                .header("Authorization","Bearer "+token)
                                .contentType(MediaType.APPLICATION_JSON)
                )
                .andExpect(status().isOk());
    }

    @Test
    void testRetrieveAllWithUserToken() throws Exception {

        MvcResult loginResult =mockMvc.perform(
                        post("/api/v1/user/login")
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(
                                        objectMapper.writeValueAsString(
                                                AuthReqDto.builder()
                                                        .userName("logesh@tcs.com")
                                                        .password("Tcs#54321")
                                                        .build()
                                        )
                                )
                )
                .andExpect(status().isOk())
                .andReturn();

        /**
         *  Extracting jwt token from the response body with key authToken
         */
        String token=objectMapper.readTree(loginResult.getResponse().getContentAsString())
                .get("authToken").asText();

        mockMvc.perform(
                        get("/api/v1/user/retrieveAll")
                                .header("Authorization","Bearer "+token)
                                .contentType(MediaType.APPLICATION_JSON)
                )
                .andExpect(status().isForbidden());
    }


}
