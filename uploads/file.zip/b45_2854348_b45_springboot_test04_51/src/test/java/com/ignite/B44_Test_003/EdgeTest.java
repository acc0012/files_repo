package com.ignite.B44_Test_003;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ignite.B44_Test_003.dto.AuthReqDto;
import com.ignite.B44_Test_003.dto.UserReqDto;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class EdgeTest {

    @Autowired
    MockMvc mockMvc;

    @Autowired
    ObjectMapper objectMapper;

    @Test
    public void WrongUserName() throws Exception {
        mockMvc.perform(
                        post("/api/v1/user/login")
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(
                                        objectMapper.writeValueAsString(
                                                AuthReqDto.builder()
                                                        .userName("neverEverGiveUp")
                                                        .password("Tcs#54321")
                                                        .build()
                                        )
                                )
                )
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.message").value("Bad credentials"));
    }

    @Test
    public void noUserName() throws Exception {
        mockMvc.perform(
                        post("/api/v1/user/login")
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(
                                        objectMapper.writeValueAsString(
                                                AuthReqDto.builder()
                                                        .password("Tcs#54321")
                                                        .build()
                                        )
                                )
                )
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("userName: userName cannot be null"))
                .andExpect(jsonPath("$.status").value(400));
    }

    @Test
    public void noPassword() throws Exception {
        mockMvc.perform(
                        post("/api/v1/user/login")
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(
                                        objectMapper.writeValueAsString(
                                                AuthReqDto.builder()
                                                        .userName("lala lala")
                                                        .build()
                                        )
                                )
                )
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("password: password cannot be null"))
                .andExpect(jsonPath("$.status").value(400));
    }


    @Test
    public void checkValidationAdminToken() throws Exception {
        MvcResult loginResult =mockMvc.perform(
                        post("/api/v1/user/login")
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(
                                        objectMapper.writeValueAsString(
                                                AuthReqDto.builder()
                                                        .userName("stranger@tcs.com")
                                                        .password("Tcs#12345")
                                                        .build()
                                        )
                                )
                )
                .andExpect(status().isOk())
                .andReturn();


        /**
         *  Extracting jwt token from the response body with key authToken
         */
        String token=objectMapper.readTree(loginResult.getResponse().getContentAsString())
                .get("authToken").asText();

        mockMvc.perform(
                        post("/api/v1/user/register")
                                .header("Authorization","Bearer "+token)
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(
                                        objectMapper.writeValueAsString(
                                                UserReqDto.builder()
                                                        .password("Tcs#12345")
                                                        .role("USER")
                                                        .build()
                                        )
                                )
                )
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("userName: userName cannot be null"))
                .andExpect(jsonPath("$.status").value(400));
    }


    @Test
    public void checkValidationAdminTokenUserName() throws Exception {
        MvcResult loginResult =mockMvc.perform(
                        post("/api/v1/user/login")
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(
                                        objectMapper.writeValueAsString(
                                                AuthReqDto.builder()
                                                        .userName("stranger@tcs.com")
                                                        .password("Tcs#12345")
                                                        .build()
                                        )
                                )
                )
                .andExpect(status().isOk())
                .andReturn();


        /**
         *  Extracting jwt token from the response body with key authToken
         */
        String token=objectMapper.readTree(loginResult.getResponse().getContentAsString())
                .get("authToken").asText();

        mockMvc.perform(
                        post("/api/v1/user/register")
                                .header("Authorization","Bearer "+token)
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(
                                        objectMapper.writeValueAsString(
                                                UserReqDto.builder()
                                                        .password("Tcs#12345")
                                                        .role("USER")
                                                        .build()
                                        )
                                )
                )
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("userName: userName cannot be null"))
                .andExpect(jsonPath("$.status").value(400));
    }

    @Test
    public void checkValidationAdminTokenPassword() throws Exception {
        MvcResult loginResult =mockMvc.perform(
                        post("/api/v1/user/login")
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(
                                        objectMapper.writeValueAsString(
                                                AuthReqDto.builder()
                                                        .userName("stranger@tcs.com")
                                                        .password("Tcs#12345")
                                                        .build()
                                        )
                                )
                )
                .andExpect(status().isOk())
                .andReturn();


        /**
         *  Extracting jwt token from the response body with key authToken
         */
        String token=objectMapper.readTree(loginResult.getResponse().getContentAsString())
                .get("authToken").asText();

        mockMvc.perform(
                        post("/api/v1/user/register")
                                .header("Authorization","Bearer "+token)
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(
                                        objectMapper.writeValueAsString(
                                                UserReqDto.builder()
                                                        .userName("leo")
                                                        .role("USER")
                                                        .build()
                                        )
                                )
                )
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("password: password cannot be null"))
                .andExpect(jsonPath("$.status").value(400));
    }

    @Test
    public void checkValidationAdminTokenRole() throws Exception {
        MvcResult loginResult =mockMvc.perform(
                        post("/api/v1/user/login")
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(
                                        objectMapper.writeValueAsString(
                                                AuthReqDto.builder()
                                                        .userName("stranger@tcs.com")
                                                        .password("Tcs#12345")
                                                        .build()
                                        )
                                )
                )
                .andExpect(status().isOk())
                .andReturn();


        /**
         *  Extracting jwt token from the response body with key authToken
         */
        String token=objectMapper.readTree(loginResult.getResponse().getContentAsString())
                .get("authToken").asText();

        mockMvc.perform(
                        post("/api/v1/user/register")
                                .header("Authorization","Bearer "+token)
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(
                                        objectMapper.writeValueAsString(
                                                UserReqDto.builder()
                                                        .userName("leo")
                                                        .password("Tcs#!23456")
                                                        .build()
                                        )
                                )
                )
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("role: role cannot be null"))
                .andExpect(jsonPath("$.status").value(400));
    }
}
