package com.ignite.B44_Test_003.controller;
import com.ignite.B44_Test_003.config.JwtUtilService;
import com.ignite.B44_Test_003.dto.AuthResDto;
import com.ignite.B44_Test_003.dto.UserReqDto;
import com.ignite.B44_Test_003.dto.AuthReqDto;
import com.ignite.B44_Test_003.dto.UserResDto;
import com.ignite.B44_Test_003.repo.UserRepo;
import com.ignite.B44_Test_003.service.UserService;
import jakarta.persistence.EntityNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Use Required annotations to make this class as a controller
 * create a request mapping with "/api/v1/user"
 */

@RestController
@RequestMapping("/api/v1/user")
public class UserController {

    private static final Logger log = LoggerFactory.getLogger(UserController.class);

    /**
     * User Required annotations for dependency injection of beans
     */

    @Autowired
    AuthenticationManager authenticationManager;


    @Autowired
    JwtUtilService jwtUtil;

//    @Autowired
//    UserDetails userDetails;

    @Autowired
    UserService userService;


    @Autowired
    UserRepo userRepo;

    /*Protected API , should be accessible only by Authorized Admin Credentials*/

    /**
     * This method should be a post api with endpoint "/register"
     * Use @Validated annotation to validate the input and complete the tasks in DTO
     *
     *
     * @param userReqDto -> This is a json passed through request body
     * @return -> created as a status code
     */

    @PostMapping("/register")
    public ResponseEntity<UserResDto> create(@Validated @RequestBody  UserReqDto userReqDto){
        /**
         * Complete the registration logic in UserServiceImpl
         * Send 201 response code and send UserResDto as a response
         */
        log.info(userReqDto.getPassword());
        return ResponseEntity.status(201).body(userService.create(userReqDto));
    }


    /*Open API any one can access*/
    @PostMapping("/login")
    public ResponseEntity<?> login(@Validated  @RequestBody  AuthReqDto authReqDto) {
        log.info(authReqDto.getUserName());
        log.info(authReqDto.getPassword());

        /**
         * Complete the login logic using AuthenticationManager's authenticate()
         * Note that authenticate function takes Authentication object as input
         * post successful login generate jwt token using generateToken() which will return jwt string
         */

        Authentication auth=new UsernamePasswordAuthenticationToken(
                authReqDto.getUserName(),
                authReqDto.getPassword()
        );

        authenticationManager.authenticate(auth);
        try {
            authenticationManager.authenticate(auth);
            return ResponseEntity.ok(
                    AuthResDto.builder().authToken(
                            jwtUtil.generateToken(
                                    userRepo.findByUserName(authReqDto.getUserName()).orElseThrow(()-> new EntityNotFoundException("not found")),
                                    authReqDto.getUserName()
                            )).build());
        }
        catch (Exception e){
            return  ResponseEntity.status(401).body("invalid cred");

        }
        /**
         *  Response: example
         *   {
         *   	"authToken": "eyJhbGciOiJIUzM4NCJ9.eyJpc3MiOiJUQ1MiLCJzdWIiOiJzdHJhbmdlckB0Y3MuY29tIiwiaWF0IjoxNzU3MjYzMDEzLCJleHAiOjE3NTcyNjMxMDMsImF1dGhvcml0aWVzIjpbeyJhdXRob3JpdHkiOiJBRE1JTiJ9XX0.RZdhgTldmafdQAJ48tuG-khZBr6fXwDLfSLEpbpyAzsnBSMHp0iKCmYjNE-Sea6n",
         * 	    "userName": "stranger@tcs.com"
         *   }
         */



    }

    /*Only Admin should See*/
    @GetMapping("/retrieveAll")
    public ResponseEntity<List<UserResDto>> getAllData(){

        /**
         * Logic is already completed make sure you protect this end point security in authRegistry of SecurityFilterChain
         */

        return ResponseEntity.ok(
                userRepo.findAll().stream().map(
                        (e)->UserResDto.builder()
                                .userName(e.getUsername())
                                .password(e.getPassword())
                                .role(e.getRole())
                                .build()
                ).toList()
        );
    }

}























