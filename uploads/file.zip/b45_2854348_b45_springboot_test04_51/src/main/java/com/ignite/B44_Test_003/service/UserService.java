package com.ignite.B44_Test_003.service;

import com.ignite.B44_Test_003.dto.UserReqDto;
import com.ignite.B44_Test_003.dto.UserResDto;

public interface UserService {
    UserResDto create(UserReqDto userReqDto);
}
