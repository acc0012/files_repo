package com.ignite.B44_Test_003.config;

import com.ignite.B44_Test_003.repo.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * Use Required annotations , to make this class as a Bean containing class which has to be kept
 * in applicationContext @Configuration
 */

@Configuration
public class ApplicationConfig {


    @Autowired
    UserRepo userRepo;

    /**
     * Create a bean for UserDetailsService
     * return the implementation for loadUserByUsername(String userName)
     * implementation is retrieving user objects from db
     */

    @Bean
    UserDetailsService userDetailsService(){
        return username -> userRepo.findByUserName(username).orElseThrow(()-> new UsernameNotFoundException("User not found"));

    }

    /**
     * return AuthenticationManager bean using AuthenticationConfiguration object
     */
    @Bean
    AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    /**
     * Create a bean for Authentication Provider
     * Initialize AuthenticationProvider bean look for a class which has implemented it
     * set up userDetailsService() and PasswordEncoder() in your AuthenticationProvider bean
     */
    @Bean
    AuthenticationProvider authenticationProvider(){

        DaoAuthenticationProvider dao=new DaoAuthenticationProvider();
        dao.setUserDetailsService(userDetailsService());
        dao.setPasswordEncoder(passwordEncoder());
        return dao;
    }


    /**
     * Use BCryptPasswordEncoder Bean
     */
    @Bean
    PasswordEncoder passwordEncoder(){
        return new BCryptPasswordEncoder(10);
    }

}
