package com.ignite.B44_Test_003;

import com.ignite.B44_Test_003.model.User;
import com.ignite.B44_Test_003.repo.UserRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.crypto.password.PasswordEncoder;

@SpringBootApplication
public class B44Test003Application implements CommandLineRunner {

	private static final Logger log = LoggerFactory.getLogger(B44Test003Application.class);
	@Autowired
	UserRepo userRepo;

	@Autowired
	PasswordEncoder passwordEncoder;

	public static void main(String[] args) {
		SpringApplication.run(B44Test003Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		log.info("User saved with \nUserName: {},\nPassword: {},\nRole: {} ","stranger@tcs.com","Tcs#12345","ADMIN");
		userRepo.save(
				User.builder()
						.userName("stranger@tcs.com")
						.password(passwordEncoder.encode("Tcs#12345"))
						.role("ADMIN")
						.build()
		);
	}
}
