package com.ignite.B44_Test_003.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.NoHandlerFoundException;
import java.util.stream.Collectors;

/**
 * This file is the Global Exception Handler , which will catch the exception thrown by application and
 * sends the response.
 * Need not touch this file fully configured
 */
@RestControllerAdvice
public class GlobalExceptionalHandler {

    Logger logger = LoggerFactory.getLogger(GlobalExceptionalHandler.class);

    @ExceptionHandler(NoHandlerFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ResponseEntity<ErrorResDto> handleNotFound(NoHandlerFoundException ex) {
        logger.error("URL not found : {}", ex.getMessage());
        ErrorResDto errorResponse = new ErrorResDto(
                "URL not found",
                HttpStatus.NOT_FOUND.value()
        );
        return ResponseEntity.status(404).body(errorResponse);
    }

    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<ErrorResDto> handleGenericException(Exception ex) {
        logger.error("An error occurred : {}" ,ex.getLocalizedMessage());
        ErrorResDto errorResponse = new ErrorResDto(
                "An error occurred :" + ex.getMessage(),
                HttpStatus.INTERNAL_SERVER_ERROR.value()
        );
        return ResponseEntity.status(500).body(errorResponse);
    }

    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<ErrorResDto> handleIllegalArgumentException(IllegalArgumentException ex) {
        ErrorResDto errorResponse = new ErrorResDto(
                "Invalid argument: " + ex.getMessage(),
                HttpStatus.BAD_REQUEST.value()
        );
        return ResponseEntity.status(400).body(errorResponse);
    }

    @ExceptionHandler(org.springframework.security.core.userdetails.UsernameNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ResponseEntity<ErrorResDto> handleUsernameNotFoundException(org.springframework.security.core.userdetails.UsernameNotFoundException ex) {
        ErrorResDto errorResponse = new ErrorResDto(
                "Username not found: " + ex.getMessage(),
                HttpStatus.NOT_FOUND.value()
        );
        return ResponseEntity.status(404).body(errorResponse);
    }

    @ExceptionHandler(org.springframework.security.authentication.BadCredentialsException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public ResponseEntity<ErrorResDto> handleBadCredentialsException(org.springframework.security.authentication.BadCredentialsException ex) {
        ErrorResDto errorResponse = new ErrorResDto(
                ex.getMessage(),
                HttpStatus.UNAUTHORIZED.value()
        );
        return ResponseEntity.status(401).body(errorResponse);
    }

    @ExceptionHandler(org.springframework.security.authorization.AuthorizationDeniedException.class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public ResponseEntity<ErrorResDto> handleAuthorizationDeniedException(org.springframework.security.authorization.AuthorizationDeniedException ex) {
        ErrorResDto errorResponse = new ErrorResDto(
                "Authorization denied: " + ex.getMessage(),
                HttpStatus.FORBIDDEN.value()
        );
        return ResponseEntity.status(403).body(errorResponse);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<ErrorResDto> handleMethodArgumentNotValidException(MethodArgumentNotValidException ex) {
        String errorMessage = ex.getBindingResult().getFieldErrors().stream()
                .map(fieldError -> fieldError.getField() + ": " + fieldError.getDefaultMessage())
                .collect(Collectors.joining(", "));
        ErrorResDto errorResponse = new ErrorResDto(
                errorMessage,
                HttpStatus.BAD_REQUEST.value()
        );
        return ResponseEntity.status(400).body(errorResponse);
    }

}
