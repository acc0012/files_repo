package com.ignite.B44_Test_003.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.NonNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

/**
 * Complete the JwtAuthFilter logic Use required annotations to create bean for this filter
 */
@Component
public class JwtAuthFilter extends OncePerRequestFilter {



    @Autowired
    JwtUtilService jwtUtil;



    @Autowired
    UserDetailsService userDetailsService;


    @Override
    protected void doFilterInternal(
            @NonNull HttpServletRequest request,
            @NonNull HttpServletResponse response,
            @NonNull FilterChain filterChain) throws ServletException, IOException {

        /**
         * 1) Check if header is present or not
         */

        String authHead= request.getHeader("Authorization");

        try {

            /**
             *2) Verify whether it follows proper format or not "Bearer "
             */
            if (authHead != null && authHead.startsWith("Bearer ")) {


                /**
                 *3) Take the substring, to get only jwt token
                 */

                String authToken = authHead.substring(7);

                /**
                 *4) Check if Authentication Object is present in Context of Security Context Holder
                 */

                if (SecurityContextHolder.getContext().getAuthentication() == null) {
                    /**
                     *5) extract UserName from the token
                     */
                    String userName = jwtUtil.extractUserName(authToken);

                    /**
                     *6) find the UserDetails object of the user with username using UserDetailsService bean's
                     *   loadUserByUsername()
                     */
                    UserDetails userDetails = userDetailsService.loadUserByUsername(userName);

                    /**
                     *7) Check if the token is valid or not
                     */
                    if (userDetails != null && jwtUtil.validateToken(authToken, userDetails)) {


                        /**
                         *8) Create UsernamePasswordAuthenticationToken object to keep inside the
                         * Security Context Holder so that , whenever request comes with valid JWT token ,
                         *   it can Bypass UserNamePasswordAuthentication filter
                         */
                        Authentication authentication=new UsernamePasswordAuthenticationToken(userDetails.getUsername(),null,userDetails.getAuthorities());
                        SecurityContextHolder.getContext().setAuthentication(authentication);
                        /**
                         *9) Finally keep the Authentication object in the Security Context Holder
                         */

                    }

                }

            }


        }catch (Exception e){
            logger.info(e.getMessage());
        }


        /**
         * pass this request, response to the other filters, using doFilter() method in FilterChain
         */

        filterChain.doFilter(request,response);
    }
}





