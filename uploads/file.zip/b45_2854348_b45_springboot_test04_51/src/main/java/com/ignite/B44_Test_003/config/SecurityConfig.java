



package com.ignite.B44_Test_003.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

/**
 * Use Required annotations to create bean for this class
 * use @EnableWebSecurity , @EnableMethodSecurity(prePostEnabled=true) to enable method level security
 * Note -> UserDetailsService, AuthenticationProvider, PasswordEncoder  beans are in ApplicationConfig file,
 *         don't create here ...
 */

@Configuration
public class SecurityConfig {


    @Autowired
    JwtAuthFilter jwtAuthFilter;


    @Bean
    SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {

        /**
         * 1) disable csrf
         * 2) configure
         * 3) protect the following end points
         *     "/api/v1/user/register" -> only ADMIN
         *     "/api/v1/user/retrieveAll" -> only ADMIN
         *      any other request -> permitAll
         * 4) sessionManagement stateless -> using sessionCreationPolicy(SessionCreationPolicy.STATELESS)
         * 5) add JwtAuthFilter before UsernamePasswordAuthenticationFilter
         */

        return httpSecurity
                .csrf(AbstractHttpConfigurer::disable)
                .headers(
                        (header)->header.frameOptions(HeadersConfigurer.FrameOptionsConfig::disable)
                )
                .httpBasic(Customizer.withDefaults())
                .cors(Customizer.withDefaults())
                .authorizeHttpRequests((auth)->auth.requestMatchers("/api/v1/user/register").hasAuthority("ADMIN")
                        .requestMatchers( "/api/v1/user/retrieveAll").hasAuthority("ADMIN")
                        .anyRequest().permitAll()
                )
                .sessionManagement(
                        (session)->session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                )
                .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class)
                .build();
    }
}


