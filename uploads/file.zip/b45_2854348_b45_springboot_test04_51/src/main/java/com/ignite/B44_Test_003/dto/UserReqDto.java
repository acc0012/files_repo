package com.ignite.B44_Test_003.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
public class UserReqDto {

    /**
     * Use @NotNull annotation to add validation to userName field,
     *     pass message "userName cannot be null" in the annotation as the default error message
     *     this notnull constraint will trigger 400 BadRequest automatically
     */
    @NotNull(message = "userName cannot be null")
    private String userName;

    /**
     * Use @NotNull annotation to add validation to userName field,
     *     pass message "password cannot be null" in the annotation as the default error message
     *     this notnull constraint will trigger 400 BadRequest automatically
     */
    @NotNull(message = "password cannot be null")
    private String password;

    /**
     * Use @NotNull annotation to add validation to userName field,
     *     pass message "role cannot be null" in the annotation as the default error message
     *     this notnull constraint will trigger 400 BadRequest automatically
     */
    @NotNull(message = "role cannot be null")
    private String role;
}
