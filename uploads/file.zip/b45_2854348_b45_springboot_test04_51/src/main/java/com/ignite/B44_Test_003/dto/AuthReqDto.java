package com.ignite.B44_Test_003.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;


@Builder
@AllArgsConstructor
@Data
public class AuthReqDto {

    /**
     * Use @NotNull annotation to add validation to userName field,
     *     pass message "userName cannot be null" in the annotation as the default error message
     *     this notnull constraint will trigger 400 BadRequest automatically
     */

    @NotNull(message = "userName cannot be null")
    private String userName;

    /**
     * Use @NotNull annotation to add validation to password field,
     *     pass message "password cannot be null" in the annotation as the default error message
     *     this notnull constraint will trigger 400 BadRequest automatically
     */
    @NotNull(message = "password cannot be null")
    private String password;

}

