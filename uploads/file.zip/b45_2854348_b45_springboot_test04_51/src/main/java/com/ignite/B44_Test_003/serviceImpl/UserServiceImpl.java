package com.ignite.B44_Test_003.serviceImpl;

import com.ignite.B44_Test_003.dto.UserReqDto;
import com.ignite.B44_Test_003.dto.UserResDto;
import com.ignite.B44_Test_003.model.User;
import com.ignite.B44_Test_003.repo.UserRepo;
import com.ignite.B44_Test_003.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

/**
 * Use Required annotations to make this class as a Service Layer
 */
@Service
public class UserServiceImpl implements UserService  {
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired

    private UserRepo userRepo;

    private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

    /**
     * Implement the logic for saving user , make sure you encode the password before saving it
     * @param userReqDto
     * @return
     */
    @Override
    public UserResDto create(UserReqDto userReqDto) {
        log.info(passwordEncoder.encode(userReqDto.getPassword()));

        User user = User.builder()
                .userName(userReqDto.getUserName())
                .password(passwordEncoder.encode(userReqDto.getPassword()))
                .role(userReqDto.getRole()).build();

//        userReqDto.setPassword(passwordEncoder.encode(userReqDto.getPassword()));

        User saved =  userRepo.save(user);
        return UserResDto.builder().userName(saved.getUsername()).role(saved.getRole())
                .password(saved.getPassword()).build();
    }
}
