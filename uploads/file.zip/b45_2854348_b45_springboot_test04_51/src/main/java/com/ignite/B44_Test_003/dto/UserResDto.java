package com.ignite.B44_Test_003.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
@Builder
public class UserResDto {
    private String userName;
    private String password;
    private String role;
}
