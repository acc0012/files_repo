package com.ignite.B44_Test_003.config;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.util.Date;
import java.util.HashMap;
import java.util.function.Function;

/**
 * This JwtUtilService is already completed don't touch
 * But understand this code also
 */
@Service
public class JwtUtilService {
    /* Encoded Secret for your application with which you will sign your jwt token*/
    private String JWT_SECRET="wqsedrftyuhijmowertyuiuytkomijnhubgyvcxzwexrctvybguhnnhbgvfcdxsezwaexsrcdtfvygbhbgvfc";

    /**
     * This function will be used for generating token , which should usable by other classes
     *
     * @param userDetails
     * @param userName
     * @return jwtToken
     */
    public String generateToken(UserDetails userDetails,String userName){

        /**
         *     Create a Hashmap to store all Authorities of the user
         */
        HashMap<String,Object> claims=new HashMap<>();

        /*Adding user authorities in the json*/
        claims.put("authorities",userDetails.getAuthorities());

        /*call the actual function which generates token*/
        return createToken(userName,claims);
    }

    /**
     * Use Jwts class to create a jwt token
     *
     * @param userName
     * @param claims
     * @return
     */
    private String createToken(String userName, HashMap<String,Object> claims){
        return Jwts.builder()                                            /*Creating builder object through which you can create token*/
                .issuer("TCS")                                        /*Set the issuer name can be organization or application name*/
                .subject(userName)                                       /*Set the subject for your JWT token , usually username*/
                .issuedAt(new Date(System.currentTimeMillis()))          /*Set the time when this token is being issued (ie) now */
                .expiration(new Date(System.currentTimeMillis()+90000))  /*Set when this token should expire new Date(seconds in milli seconds) */
                .signWith(getSignatureKey())                             /*Set the Sign key*/
                .claims(claims)                                          /*Set the user claims (ie) What roles he is claiming to be*/
                .compact();                                              /*Use compact() to make this jwt object(json) as a string*/
    }

    private SecretKey getSignatureKey(){                                 /*Key interface is extended by SecretKey interface so we can return a object of type Secret Key also*/
        byte[] secret= Decoders.BASE64.decode(JWT_SECRET);                /*Decode the encoded JWT Secret */
        return Keys.hmacShaKeyFor(secret);                               /*use hmacShaKeyFor() to verify length of the encoded secret key*/
    }


    public String extractUserName(String authToken) {
        return extractClaim(authToken, Claims::getSubject);               /*extract username from token*/
    }

    private <T> T extractClaim(String authToken, Function<Claims,T> claimsResolver) {
        Claims claims=extractAllClaims(authToken);                      /*extract all claims */

        return claimsResolver.apply(claims);                            /*from claims object which function call has to be made*/
    }

    public boolean validateToken(String authToken, UserDetails userDetails) {
        /**
         * Check if username from token and username from UserDetails are matching and
         *  Check if current Date is after expiration Date
         */
        return  extractUserName(authToken).equals(userDetails.getUsername())
                && new Date(System.currentTimeMillis()).before(extractClaim(authToken,Claims::getExpiration));
    }

    private Claims extractAllClaims(String token){
        /**
         *  use Jwts parser to parse the jwt token
         *  set the sign key in verifyWith function
         *  then after builder parser object ,
         *    call parseSignedClaims() -> which will return claims Jwts<Claims>
         *        use getPayLoad() to get the Claims object out of it
         */
        return Jwts.parser()
                .verifyWith(getSignatureKey())
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

}
