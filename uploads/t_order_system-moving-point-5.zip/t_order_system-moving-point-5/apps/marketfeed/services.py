import threading
import time
from dhanhq.marketfeed import MarketFeed
from dhanhq.dhan_context import DhanContext
from django.conf import settings
from core.dhan_token import load_valid_dhan_credentials
from core.logger import get_logger
from core.subscription_store import get_collection,load_full_subscriptions
# from datetime import timezone as dt_timezone
from datetime import datetime, timezone
from django.utils import timezone as django_timezone

# ✅ PERSISTENCE LAYER
from core.subscription_store import (
    # save_subscriptions,
    load_subscriptions,
    clear_subscriptions,
)

# =====================================================
# LOGGER
# =====================================================

logger = get_logger("marketfeed_service")

# =====================================================
# LOAD DHAN CREDENTIALS
# =====================================================

creds = load_valid_dhan_credentials()

if not creds:
    logger.error("❌ No valid Dhan credentials found")
    raise Exception("No valid Dhan credentials found")

CLIENT_ID = creds["client_id"]
ACCESS_TOKEN = creds["access_token"]

logger.info("✅ Dhan credentials loaded successfully")

# =====================================================
# DHAN CONTEXT
# =====================================================

try:
    dhan_context = DhanContext(
        CLIENT_ID,
        ACCESS_TOKEN,
    )
    logger.info("✅ DhanContext initialized successfully")

except Exception as e:
    logger.exception(f"❌ Failed to initialize DhanContext: {e}")
    raise

# =====================================================
# THREAD LOCK
# =====================================================

lock = threading.RLock()

# =====================================================
# MAX CACHE SIZE
# =====================================================

MAX_TICK_CACHE = 5000


def is_market_open():
    now = django_timezone.localtime()

    weekday = now.weekday()
    if weekday >= 5:
        return False

    start = now.replace(hour=9, minute=15, second=0, microsecond=0)
    end   = now.replace(hour=15, minute=30, second=0, microsecond=0)

    return start <= now <= end

# =====================================================
# MARKET FEED SERVICE
# =====================================================


class MarketFeedService:
    def __init__(self):

        # ---------------------------------------------
        # FEED STATE
        # ---------------------------------------------
        self._reconnecting = False
        self.feed = None
        self.is_running = False
        
        # ---------------------------------------------
        # TRACKING
        # ---------------------------------------------
        self.last_connect_time = None
        self.subscribed_instruments = set()  # ✅ store tuple directly
        self.latest_ticks = {}
        self.total_messages = 0
        self.started_at = None
        self.last_message_time = None
        
        # ✅ HEARTBEAT SETTINGS
        self.heartbeat_timeout = 15   # seconds (no tick → dead)
        self.monitor_interval = 5     # check every 5 sec
        self._monitor_thread = None
        self._stop_monitor = False
        # ✅ LOAD FROM MONGO
        try:
            self.persisted_instruments = load_subscriptions()
            logger.info(
                f"📦 Loaded persisted instruments: {self.persisted_instruments}"
            )
        except Exception as e:
            logger.exception(f"❌ Failed loading persisted subscriptions: {e}")
            self.persisted_instruments = []

        logger.info("🚀 MarketFeedService initialized")


    # =================================================
    # ✅ AUTO RECONNECT HANDLER
    # =================================================
    def _handle_reconnect(self):

        # ✅ prevent duplicate reconnect
        if self._reconnecting:
            logger.warning("⚠️ Reconnect already in progress, skipping...")
            return

        self._reconnecting = True

        logger.warning("🔄 Attempting auto-reconnect...")

        try:
            instruments = list(self.subscribed_instruments)

            # ✅ stop safely
            try:
                if self.feed:
                    self.feed.close_connection()
            except Exception as e:
                logger.warning(f"Force closing feed failed: {e}")

            self.feed = None
            self.is_running = False

            time.sleep(5)
            self.last_message_time = None
            self.started_at = None
            # ✅ restart
            from apps.marketfeed.views import on_message  # ✅ lazy import

            self.start_feed(
                instruments=instruments,
                callbacks={"on_message": on_message}
            )

            logger.info("✅ Auto-reconnect success")

        except Exception as e:
            logger.exception(f"❌ Auto-reconnect failed: {e}")

        finally:
            # ✅ ALWAYS RESET FLAG
            self._reconnecting = False


    def _on_message_wrapper(self, instance, message):
        self.update_tick(message)
        
    # =================================================
    # ✅ HEARTBEAT MONITOR + AUTO RECONNECT
    # =================================================
    def _start_monitor(self):

        if self._monitor_thread:
            return

        def monitor():

            logger.info("🧠 Feed monitor started")

            last_reconnect_time = 0  # ✅ prevent reconnect storm

            while not self._stop_monitor:

                try:
                    time.sleep(self.monitor_interval)

                    trigger_reconnect = False
                    diff = 0

                    # ✅ ONLY READ STATE INSIDE LOCK
                    with lock:
                        if not self.is_running:
                            continue
                        
                        if not self.last_message_time:

                            # ✅ check if feed never produced data
                            if self.started_at:
                                diff_start = (datetime.now(timezone.utc) - self.started_at).total_seconds()
                                if diff_start > self.heartbeat_timeout:

                                    trigger_reconnect = True

                            continue

                        diff = (datetime.now(timezone.utc) - self.last_message_time).total_seconds()
                        
                        if diff > self.heartbeat_timeout:
                            trigger_reconnect = True

                    # ✅ OUTSIDE LOCK → SAFE RECONNECT
                    if trigger_reconnect:

                        # ✅ ✅ CRITICAL FIX: Skip reconnect outside market hours
                        if not is_market_open():
                            logger.info("🕒 Market closed → skipping reconnect")
                            continue

                        now_ts = time.time()

                        # ✅ THROTTLE RECONNECT (VERY IMPORTANT)
                        if now_ts - last_reconnect_time < 10:
                            continue

                        last_reconnect_time = now_ts

                        reason = "no_data_since_start" if not self.last_message_time else "stale_ticks"

                        logger.warning(
                            f"💔 Feed issue | reason={reason} | delay={diff}s"
                        )

                        self._handle_reconnect()
                        
                except Exception as e:
                    logger.exception(f"❌ Monitor error: {e}")


        self._stop_monitor = False
        self._monitor_thread = threading.Thread(target=monitor, daemon=True)
        self._monitor_thread.start()

    # =================================================
    # CLEANUP EXPIRED SUBSCRIPTIONS ✅
    # =================================================

    def cleanup_expired_subscriptions(self):

        try:
            logger.info("🧹 Checking expired subscriptions...")

            collection = get_collection()

            instruments = load_full_subscriptions()


            today = datetime.now(timezone.utc).date()

            expired_items = []
            active_items = []

            for item in instruments:

                # ✅ Skip legacy tuple/list format (no metadata)
                if isinstance(item, (list, tuple)):
                    active_items.append(item)
                    continue

                if not isinstance(item, dict):
                    continue

                metadata = item.get("metadata", {})
                expiry = metadata.get("expiry")

                if not expiry:
                    active_items.append(item)
                    continue

                try:
                    expiry_date = datetime.strptime(expiry, "%Y-%m-%d").date()
                except Exception:
                    active_items.append(item)
                    continue

                if expiry_date <= today:
                    expired_items.append(item)
                else:
                    active_items.append(item)


            # -----------------------------------------
            # ✅ UNSUBSCRIBE
            # -----------------------------------------

            tuples_to_unsub = []

            for item in expired_items:
                tuples_to_unsub.append(
                    tuple(item.get("tuple"))
                )

            if tuples_to_unsub:
                logger.info(f"🧹 Unsubscribing {len(tuples_to_unsub)} expired")

                try:
                    self.unsubscribe(tuples_to_unsub)
                except Exception as e:
                    logger.exception(f"⚠️ Unsubscribe failed: {e}")

            # -----------------------------------------
            # ✅ SAVE ACTIVE BACK
            # -----------------------------------------

            collection.update_one(
                {"_id": "active_subscriptions"},
                {
                    "$set": {
                        "instruments": active_items,
                        "updated_at": datetime.now(timezone.utc),
                    }
                },
            )

            # -----------------------------------------
            # ✅ MOVE EXPIRED
            # -----------------------------------------

            if expired_items:
                expired_collection = collection.database["expired_subscriptions"]

                # ✅ add metadata
                for item in expired_items:
                    item["expired_at"] = datetime.now(timezone.utc)
                    item["reason"] = "expiry_passed"


            try:

                if expired_items:
                    try:
                        expired_collection.insert_many(expired_items, ordered=False)
                    except Exception:
                        pass

            except Exception:
                pass
            
            logger.info(
                f"✅ Cleanup complete | expired={len(expired_items)} | active={len(active_items)}"
            )

        except Exception as e:
            logger.exception(f"❌ Expiry cleanup failed: {e}")

    # =================================================
    # START FEED
    # =================================================

    def start_feed(self, instruments=None, callbacks=None):

        with lock:
            if self.is_running:
                logger.warning("⚠️ Feed already running")
                return self.feed

            try:
                # ✅ Use persisted if not provided
                if not instruments:
                    instruments = self.persisted_instruments or []

                # ✅ Ensure default instruments always included
                instrument_set = set(tuple(i) for i in instruments)
                instrument_set.update(settings.DEFAULT_INSTRUMENTS)

                instruments = list(instrument_set)

                if not instruments:
                    raise ValueError("No instruments provided or persisted")

                logger.info("🚀 Starting market feed...")
                logger.info(f"📡 Instruments Count: {len(instruments)}")
                logger.info(f"📡 Instruments: {instruments}")

                # ✅ Track subscriptions
                for item in instruments:
                    self.subscribed_instruments.add(tuple(item))

                # ✅ Create feed
                self.feed = MarketFeed(
                    dhan_context=dhan_context,
                    instruments=instruments,
                    version="v2",
                    **(callbacks or {}),
                )

                logger.info("⏳ Connecting to Dhan WebSocket...")

                # =================================================
                # ✅ ENHANCED RATE LIMIT PROTECTION (CRITICAL FIX)
                # =================================================

                now = datetime.now(timezone.utc)

                # ✅ FIRST CONNECTION → ADD DELAY
                if not self.last_connect_time:
                    logger.warning("⏳ First-time connection delay (anti-429 protection)")
                    time.sleep(5)

                else:
                    diff = (now - self.last_connect_time).total_seconds()

                    if diff < 5:
                        logger.warning("⏳ Preventing rapid reconnect (rate limit protection)")
                        time.sleep(5)

                # ✅ Always update timestamp
                self.last_connect_time = datetime.now(timezone.utc)

                # =================================================
                # ✅ SAFE START WITH RETRY (BEST PRACTICE)
                # =================================================
                attempt = 0
                max_retries = 3

                while attempt < max_retries:
                    try:
                        self.feed.start()
                        break  # ✅ success → exit loop

                    except Exception as e:

                        error_str = str(e)

                        # ✅ HANDLE 429 RATE LIMIT
                        if "429" in error_str:
                            wait_time = 30
                            logger.warning(f"🚫 Rate limited by Dhan → cooldown {wait_time}s")

                        else:
                            wait_time = min(60, (2 ** (attempt + 1)) * 5)

                        attempt += 1

                        logger.warning(
                            f"⚠️ Feed start failed (attempt {attempt}) → retrying in {wait_time}s | {e}"
                        )

                        time.sleep(wait_time)

                # ❌ FAIL AFTER MAX RETRIES
                if attempt == max_retries:
                    raise Exception("❌ Failed to connect to Dhan after retries")

                # =================================================
                # ✅ SUCCESS STATE
                # =================================================
                self.started_at = datetime.now(timezone.utc)
                self.is_running = True

                # ✅ START MONITOR (AUTO HEAL)
                self._start_monitor()

                logger.info("✅ Market feed started successfully")

                return self.feed

            except Exception as e:
                # ✅ CLEAN FAILURE STATE
                self.feed = None
                self._stop_monitor = True
                self._monitor_thread = None
                self.is_running = False
                self.started_at = None

                logger.exception(f"❌ Failed to start market feed: {e}")
                raise

   
    # =================================================
    # SUBSCRIBE
    # =================================================

    def subscribe(self, instruments):

        if not self.feed:
            logger.error("❌ Cannot subscribe. Feed not started")
            raise Exception("Feed is not started")

        try:
            with lock:
                logger.info(f"📥 Subscribing instruments: {instruments}")

                filtered = []

                for item in instruments:
                    key = tuple(item)

                    if key in self.subscribed_instruments:
                        continue

                    filtered.append(item)

                if not filtered:
                    logger.warning("⚠️ All instruments already subscribed")
                    return

                # ✅ Subscribe
                self.feed.subscribe_symbols(filtered)

                # ✅ Track
                for item in filtered:
                    self.subscribed_instruments.add(tuple(item))

                # ✅ Persist
                # save_subscriptions(list(self.subscribed_instruments))

                logger.info(
                    f"✅ Subscription successful | Total: {len(self.subscribed_instruments)}"
                )

        except Exception as e:
            logger.exception(f"❌ Subscribe failed: {e}")
            raise

    # =================================================
    # UNSUBSCRIBE
    # =================================================

    def unsubscribe(self, instruments):

        if not self.feed:
            logger.error("❌ Cannot unsubscribe. Feed not started")
            raise Exception("Feed is not started")

        try:
            with lock:
                logger.info(f"📤 Unsubscribing instruments: {instruments}")

                filtered = []
                blocked = []

                for item in instruments:
                    key = tuple(item)

                    if key in settings.DEFAULT_INSTRUMENTS:
                        blocked.append(item)
                    else:
                        filtered.append(item)

                # ✅ Log blocked attempts
                if blocked:
                    logger.warning(f"🚫 Cannot unsubscribe core instruments: {blocked}")

                if not filtered:
                    return


                # ✅ Unsubscribe from Dhan
                self.feed.unsubscribe_symbols(filtered)

                # ✅ Remove from memory
                for item in filtered:
                    key = tuple(item)
                    self.subscribed_instruments.discard(key)

                    try:
                        security_id = str(item[1])
                        self.latest_ticks.pop(security_id, None)
                    except Exception:
                        pass

                # ✅ ✅ REMOVE FROM MONGO (CRITICAL FIX)
                collection = get_collection()

                for item in filtered:
                    try:
                        collection.update_one(
                            {"_id": "active_subscriptions"},
                            {
                                "$pull": {
                                    "instruments": {
                                        "tuple": tuple(item)
                                    }
                                },
                                "$set": {
                                    "updated_at": datetime.now(timezone.utc)
                                }
                            }
                        )
                    except Exception as e:
                        logger.warning(f"⚠️ Mongo unsubscribe cleanup failed: {e}")

                logger.info(
                    f"✅ Unsubscribe successful | Remaining: {len(self.subscribed_instruments)}"
                )

        except Exception as e:
            logger.exception(f"❌ Unsubscribe failed: {e}")
            raise

    # =================================================
    # UPDATE TICK CACHE
    # =================================================

    def update_tick(self, message):

        try:
            security_id = str(message.get("security_id", "UNKNOWN"))

            with lock:
                if len(self.latest_ticks) >= MAX_TICK_CACHE:
                    oldest_key = next(iter(self.latest_ticks))
                    self.latest_ticks.pop(oldest_key, None)

                self.latest_ticks[security_id] = message
                self.total_messages += 1
                self.last_message_time = datetime.now(timezone.utc)

        except Exception as e:
            logger.exception(f"❌ Failed to update tick cache: {e}")

    # =================================================
    # STOP FEED
    # =================================================

    def stop_feed(self):

        with lock:
            if not self.feed:
                logger.warning("⚠️ Feed already stopped")
                return

            try:
                logger.info("🛑 Closing market feed connection...")

                try:
                    self.feed.close_connection()
                except Exception as close_error:
                    logger.warning(f"⚠️ Close connection issue: {close_error}")

                # ✅ Clear Mongo
                clear_subscriptions()

                # ✅ STOP MONITOR THREAD
                self._stop_monitor = True
                self._monitor_thread = None
                
                # ✅ Reset state
                self.feed = None
                self.is_running = False
                self.subscribed_instruments.clear()
                self.latest_ticks.clear()
                self.total_messages = 0
                self.started_at = None
                self.last_message_time = None

                logger.info("✅ Market feed stopped successfully")

            except Exception as e:
                logger.exception(f"❌ Failed to stop feed: {e}")

    # =================================================
    # GET STATUS
    # =================================================

    def get_status(self):

        try:
            uptime_seconds = 0

            if self.started_at:
                uptime_seconds = int((datetime.now(timezone.utc) - self.started_at).total_seconds())

            with lock:
                return {
                    "is_running": self.is_running,
                    "feed_initialized": self.feed is not None,
                    "subscribed_count": len(self.subscribed_instruments),
                    "subscribed_instruments": list(self.subscribed_instruments),
                    "cached_ticks": len(self.latest_ticks),
                    "total_messages": self.total_messages,
                    "started_at": str(self.started_at) if self.started_at else None,
                    "last_message_time": (
                        str(self.last_message_time) if self.last_message_time else None
                    ),
                    "uptime_seconds": uptime_seconds,
                }

        except Exception as e:
            logger.exception(f"❌ Failed to get status: {e}")
            return {"error": str(e)}

    # =================================================
    # DASHBOARD DATA
    # =================================================

    def get_dashboard_data(self):

        try:
            with lock:
                return {
                    "status": self.get_status(),
                    "latest_ticks": dict(self.latest_ticks),
                }

        except Exception as e:
            logger.exception(f"❌ Failed dashboard data: {e}")
            return {"error": str(e)}
