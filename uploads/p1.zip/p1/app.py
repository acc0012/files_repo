from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from contextlib import asynccontextmanager
import asyncio

from feed_manager import (
    ALLOWED_SECURITIES,
    SUBSCRIBERS,
    start_feed_thread,
)

templates = Jinja2Templates(directory="templates")


@asynccontextmanager
async def lifespan(app: FastAPI):
    start_feed_thread()
    yield


app = FastAPI(
    title="Dhan Market Dashboard",
    lifespan=lifespan,
)

# -------------------------------------------------
# DASHBOARD (HTML) – FIXED
# -------------------------------------------------
@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request):
    template = templates.get_template("dashboard.html")
    html_content = template.render(
        request=request,
        securities=list(ALLOWED_SECURITIES.keys())
    )
    return HTMLResponse(content=html_content)


# -------------------------------------------------
# INFO (API)
# -------------------------------------------------
@app.get("/info")
def info():
    return {
        "available_securities": list(ALLOWED_SECURITIES.keys()),
        "available_websockets": [
            f"/ws/{sid}/{mode}"
            for sid in ALLOWED_SECURITIES
            for mode in ("ticker", "quote")
        ],
    }


# -------------------------------------------------
# WEBSOCKET HANDLER
# -------------------------------------------------
@app.websocket("/ws/{security_id}/{mode}")
async def websocket_handler(ws: WebSocket, security_id: str, mode: str):
    if security_id not in ALLOWED_SECURITIES or mode not in ("ticker", "quote"):
        await ws.close(code=1008)
        return

    await ws.accept()

    loop = asyncio.get_running_loop()

    def sender(message):
        asyncio.run_coroutine_threadsafe(
            ws.send_json(message),
            loop,
        )

    key = (security_id, mode)
    SUBSCRIBERS[key].add(sender)

    try:
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        SUBSCRIBERS[key].remove(sender)