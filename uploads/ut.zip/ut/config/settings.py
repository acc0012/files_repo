# config/settings.py

from dotenv import load_dotenv
import os

load_dotenv()

# ==========================================
# MongoDB Configuration
# ==========================================

MONGO_URL = os.getenv("MONGO_URL")

UPSTOX_DB = os.getenv("UPSTOX_DB", "UPSTOX_APP")

UPSTOX_STRIKES_COLL = os.getenv("UPSTOX_STRIKES_COLL", "market_analysis")

UPSTOX_EMA_COLL = os.getenv("UPSTOX_EMA_COLL", "live_ema_analysis")

UPSTOX_TOKEN_COLL = os.getenv("UPSTOX_TOKEN_COLL", "upstox_tokens")

ACCESS_TOKEN_DOCUMENT_ID = os.getenv("ACCESS_TOKEN_DOCUMENT_ID", "upstox_access_token")

# ==========================================
# Upstox Configuration
# ==========================================

UPSTOX_API_VERSION = os.getenv("UPSTOX_API_VERSION", "2.0")

UPSTOX_FEED_MODE = os.getenv("UPSTOX_FEED_MODE", "ltpc")

UPSTOX_ACCESS_TOKEN = os.getenv("UPSTOX_ACCESS_TOKEN")

# ==========================================
# EMA Configuration
# ==========================================

SHORT_EMA = int(os.getenv("SHORT_EMA", 9))

LONG_EMA = int(os.getenv("LONG_EMA", 21))

# ==========================================
# Thread Configuration
# ==========================================

MAX_WORKERS = int(os.getenv("MAX_WORKERS", 10))

# ==========================================
# Market Timings (IST)
# ==========================================

MARKET_START_HOUR = 9
MARKET_START_MINUTE = 15

MARKET_END_HOUR = 15
MARKET_END_MINUTE = 30

# ==========================================
# Scheduler
# ==========================================

CACHE_REFRESH_HOUR = 9
CACHE_REFRESH_MINUTE = 0

PROCESS_INTERVAL_SECONDS = 60

# ==========================================
# Logging
# ==========================================

LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")

LOG_FOLDER = os.getenv("LOG_FOLDER", "logs")

# ==========================================
# Application Settings
# ==========================================

TIMEZONE = "Asia/Kolkata"

ENABLE_LIVE_EMA = True

ENABLE_PREMARKET_REFRESH = True
