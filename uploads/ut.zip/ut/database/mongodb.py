# database/mongodb.py

from pymongo import MongoClient

from config.settings import (
    MONGO_URL,
    UPSTOX_DB,
    UPSTOX_EMA_COLL,
    UPSTOX_STRIKES_COLL,
    UPSTOX_TOKEN_COLL,
)

from common.logger import get_logger

logger = get_logger("mongodb")

_client = None


def get_client():
    """
    Singleton MongoDB client.
    """

    global _client

    try:

        if _client is None:

            logger.info("Creating MongoDB client connection")

            _client = MongoClient(
                MONGO_URL,
                maxPoolSize=50,
                connectTimeoutMS=10000,
                serverSelectionTimeoutMS=10000,
            )

            _client.admin.command("ping")

            logger.info("MongoDB connection established successfully")

        return _client

    except Exception as ex:

        logger.exception(f"Failed to connect MongoDB: {ex}")

        raise


def get_db():
    """
    Returns configured database.
    """

    try:

        db = get_client()[UPSTOX_DB]

        return db

    except Exception as ex:

        logger.exception(f"Error getting database: {ex}")

        raise


def get_collection(collection_name):
    """
    Generic collection getter.
    """

    try:

        return get_db()[collection_name]

    except Exception as ex:

        logger.exception(f"Error getting collection {collection_name}: {ex}")

        raise


def get_market_analysis_collection():
    """
    market_analysis collection
    """

    return get_collection(UPSTOX_STRIKES_COLL)


def get_live_ema_collection():
    """
    live_ema_analysis collection
    """

    return get_collection(UPSTOX_EMA_COLL)


def get_token_collection():
    """
    upstox_tokens collection
    """

    return get_collection(UPSTOX_TOKEN_COLL)


def ping_database():
    """
    Verify MongoDB connectivity.
    """

    try:

        get_client().admin.command("ping")

        logger.info("MongoDB ping successful")

        return True

    except Exception as ex:

        logger.exception(f"MongoDB ping failed: {ex}")

        return False


def close_connection():
    """
    Close MongoDB client.
    """

    global _client

    try:

        if _client:

            logger.info("Closing MongoDB connection")

            _client.close()

            _client = None

            logger.info("MongoDB connection closed")

    except Exception as ex:

        logger.exception(f"Error closing MongoDB connection: {ex}")
