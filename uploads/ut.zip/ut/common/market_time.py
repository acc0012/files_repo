from datetime import datetime

def market_is_open():
    now=datetime.now().time()
    return (now.hour>9 or (now.hour==9 and now.minute>=15)) and (now.hour<15 or (now.hour==15 and now.minute<=30))
