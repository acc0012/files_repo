# common/date_util.py

from datetime import datetime

from zoneinfo import ZoneInfo

from common.logger import get_logger

logger = get_logger("date_util")

IST = ZoneInfo("Asia/Kolkata")


def get_ist_now():
    """
    Current IST datetime.

    Example:
        2026-07-23 02:15:30 PM
    """

    try:

        return datetime.now(IST)

    except Exception as ex:

        logger.exception(f"Failed getting IST datetime: {ex}")

        return datetime.now()


def today_str():
    """
    Trading date.

    Example:
        2026-07-23
    """

    return get_ist_now().strftime("%Y-%m-%d")


def current_time_str():
    """
    12-hour readable time.

    Example:
        02:15:30 PM
    """

    return get_ist_now().strftime("%I:%M:%S %p")


def current_datetime_str():
    """
    12-hour readable datetime.

    Example:
        2026-07-23 02:15:30 PM
    """

    return get_ist_now().strftime("%Y-%m-%d %I:%M:%S %p")


def current_timestamp():
    """
    ISO timestamp.

    Example:
        2026-07-23T14:15:30+05:30
    """

    return get_ist_now().isoformat()


def current_hour():
    return get_ist_now().hour


def current_minute():
    return get_ist_now().minute


def is_today(date_str: str):
    """
    Check if date belongs to today.

    Example:
        2026-07-23
    """

    return date_str == today_str()


def get_trading_day_key():
    """
    MongoDB daily key.

    Example:
        daily.2026-07-23
    """

    return today_str()


def get_log_time():
    """
    Readable log time.

    Example:
        23-Jul-2026 02:15:30 PM
    """

    return get_ist_now().strftime("%d-%b-%Y %I:%M:%S %p")
