# common/scheduler.py

import time

from datetime import datetime, timedelta

from common.logger import get_logger

logger = get_logger("scheduler")


def wait_until_next_minute():
    """
    Wait until the start of the next minute.

    Example:

        Current Time:
            10:15:22

        Wait:
            38 seconds

        Resume:
            10:16:00
    """

    try:

        now = datetime.now()

        next_minute = now.replace(second=0, microsecond=0) + timedelta(minutes=1)

        sleep_seconds = (next_minute - now).total_seconds()

        logger.info(
            f"Waiting until next minute | "
            f"Current={now.strftime('%H:%M:%S')} | "
            f"Sleep={round(sleep_seconds, 2)} sec"
        )

        time.sleep(max(1, sleep_seconds))

        logger.info(f"Scheduler resumed at " f"{datetime.now().strftime('%H:%M:%S')}")

    except Exception as ex:

        logger.exception(f"wait_until_next_minute failed: {ex}")

        time.sleep(5)


def sleep_seconds(seconds: int):
    """
    Sleep helper with logging.
    """

    try:

        logger.info(f"Sleeping for {seconds} seconds")

        time.sleep(seconds)

    except Exception as ex:

        logger.exception(f"sleep_seconds failed: {ex}")


def get_seconds_until_next_minute():
    """
    Returns remaining seconds
    until next minute.
    """

    try:

        now = datetime.now()

        return 60 - now.second

    except Exception as ex:

        logger.exception(f"Failed getting remaining seconds: {ex}")

        return 60


def log_cycle_start():
    """
    Log cycle start.
    """

    logger.info("=========================================")

    logger.info(
        f"Processing Cycle Started | " f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    )


def log_cycle_end():
    """
    Log cycle completion.
    """

    logger.info(
        f"Processing Cycle Completed | "
        f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    )

    logger.info("=========================================")
