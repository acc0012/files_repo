import logging
from pathlib import Path


class ConsoleFilter(logging.Filter):
    """
    Filter noisy logs from console output.
    Logs will still be written to log files.
    """

    IGNORE_TEXTS = [
        "No crossover detected",
        "No crossover found",
        "Completed Processing",
        "Candles Loaded",
        "Candle cache updated",
        "Downloaded",
        "Completed:",
    ]

    def filter(self, record):
        message = record.getMessage()

        return not any(text in message for text in self.IGNORE_TEXTS)


def get_logger(name):
    Path("logs").mkdir(exist_ok=True)

    logger = logging.getLogger(name)

    if logger.handlers:
        return logger

    logger.setLevel(logging.INFO)

    formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")

    # Reset file every application start
    fh = logging.FileHandler(f"logs/{name}.log", mode="w", encoding="utf-8")
    fh.setLevel(logging.INFO)
    fh.setFormatter(formatter)

    sh = logging.StreamHandler()
    sh.setLevel(logging.INFO)
    sh.setFormatter(formatter)
    sh.addFilter(ConsoleFilter())

    logger.addHandler(fh)
    logger.addHandler(sh)

    return logger
