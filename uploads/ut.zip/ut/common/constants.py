# common/constants.py

"""
Application Constants
=====================

Central location for:

- EMA Settings
- Thread Settings
- API Settings
- Cache Settings
- Signal Constants
"""

# ==================================================
# EMA SETTINGS
# ==================================================

SHORT_EMA = 9

LONG_EMA = 21

MIN_CANDLES_REQUIRED = LONG_EMA + 2


# ==================================================
# THREAD SETTINGS
# ==================================================

MAX_WORKERS = 10

THREAD_NAME_PREFIX = "EMAWorker"


# ==================================================
# MARKET SETTINGS
# ==================================================

MARKET_START_HOUR = 9
MARKET_START_MINUTE = 15

MARKET_END_HOUR = 15
MARKET_END_MINUTE = 30


# ==================================================
# PROCESSING SETTINGS
# ==================================================

PROCESS_INTERVAL_SECONDS = 60

PREMARKET_REFRESH_HOUR = 9
PREMARKET_REFRESH_MINUTE = 0


# ==================================================
# SIGNAL CONSTANTS
# ==================================================

BULLISH = "BULLISH"

BEARISH = "BEARISH"

NO_CROSSOVER = "NO_CROSSOVER"


# ==================================================
# CANDLE SETTINGS
# ==================================================

CANDLE_UNIT = "minutes"

CANDLE_INTERVAL = "1"

CANDLE_CLOSE_INDEX = 4


# ==================================================
# CACHE SETTINGS
# ==================================================

EMPTY_LIST = []

EMPTY_DICT = {}


# ==================================================
# LOGGING
# ==================================================

DEFAULT_LOG_LEVEL = "INFO"


# ==================================================
# MONGODB KEYS
# ==================================================

INSTRUMENT_KEY = "instrument_key"

TRADING_SYMBOL = "trading_symbol"

STRIKE = "strike"

OPTION_TYPE = "type"

DAILY = "daily"

CROSSES = "crosses"

TOTAL_CROSSES = "total_crosses"

STATUS = "status"

LAST_UPDATED = "last_updated"

LAST_UPDATED_DATE = "last_updated_date"


# ==================================================
# DOCUMENT STATUS VALUES
# ==================================================

STATUS_BULLISH = "BULLISH"

STATUS_BEARISH = "BEARISH"

STATUS_NO_CROSSOVER = "NO_CROSSOVER"
