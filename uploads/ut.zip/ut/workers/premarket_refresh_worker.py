# workers/premarket_refresh_worker.py

from cache.market_analysis_cache import load_market_analysis_cache, get_instrument_keys

from cache.candle_cache import INTRADAY_CANDLE_CACHE

from cache.signal_cache import LAST_SIGNAL_CACHE, LAST_CANDLE_TIMESTAMP

from common.logger import get_logger

logger = get_logger("premarket_refresh_worker")


def clear_caches():
    """
    Clear runtime caches before market opens.
    """

    try:

        INTRADAY_CANDLE_CACHE.clear()

        LAST_SIGNAL_CACHE.clear()

        LAST_CANDLE_TIMESTAMP.clear()

        logger.info("All runtime caches cleared")

    except Exception as ex:

        logger.exception(f"Failed clearing caches: {ex}")


def refresh_before_market():
    """
    Daily pre-market refresh.

    Recommended Schedule:
        09:00 AM IST

    Flow:
        Clear caches
            ↓
        Reload market_analysis
            ↓
        Build instrument cache
    """

    try:

        logger.info("========================================")

        logger.info("Starting Pre-Market Refresh")

        logger.info("Clearing runtime caches")

        clear_caches()

        logger.info("Reloading market analysis cache")

        load_market_analysis_cache()

        instrument_count = len(get_instrument_keys())

        logger.info(f"Loaded {instrument_count} " f"instruments into cache")

        logger.info("Pre-Market Refresh Completed")

        logger.info("========================================")

        return True

    except Exception as ex:

        logger.exception(f"Pre-market refresh failed: {ex}")

        return False
