# workers/live_ema_worker.py

from concurrent.futures import ThreadPoolExecutor, as_completed

from config.settings import MAX_WORKERS

from cache.market_analysis_cache import get_instrument_keys

from services.instrument_processor import process_instrument

from common.logger import get_logger

logger = get_logger("live_ema_worker")


def run_live_cycle():
    """
    Execute one live processing cycle.

    Flow:
        Fetch all instrument keys
        ->
        Process in parallel
        ->
        Wait for completion
    """

    try:

        instrument_keys = get_instrument_keys()

        instrument_count = len(instrument_keys)

        logger.info(f"Starting live cycle for " f"{instrument_count} instruments")

        if instrument_count == 0:

            logger.warning("No instruments found in cache")

            return

        completed_count = 0
        failed_count = 0

        with ThreadPoolExecutor(
            max_workers=MAX_WORKERS, thread_name_prefix="EMAWorker"
        ) as executor:

            futures = {
                executor.submit(process_instrument, instrument_key): instrument_key
                for instrument_key in instrument_keys
            }

            for future in as_completed(futures):

                instrument_key = futures[future]

                try:

                    future.result()

                    completed_count += 1

                    logger.info(f"Completed: " f"{instrument_key}")

                except Exception as ex:

                    failed_count += 1

                    logger.exception(f"Failed processing " f"{instrument_key}: {ex}")

        logger.info(
            f"Live cycle completed | "
            f"Success={completed_count} | "
            f"Failed={failed_count}"
        )

    except Exception as ex:

        logger.exception(f"Live cycle failed: {ex}")
