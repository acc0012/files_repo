from threading import Lock
from database.mongodb import get_market_analysis_collection

MARKET_ANALYSIS_CACHE={}
lock=Lock()

def load_market_analysis_cache():
    docs=list(get_market_analysis_collection().find({}))
    with lock:
        MARKET_ANALYSIS_CACHE.clear()
        for doc in docs:
            key=doc.get('instrument_key')
            if key:
                MARKET_ANALYSIS_CACHE[key]=doc
    return MARKET_ANALYSIS_CACHE

def get_instrument_keys():
    return list(MARKET_ANALYSIS_CACHE.keys())

def get_instrument_doc(key):
    return MARKET_ANALYSIS_CACHE.get(key)
