# cache/signal_cache.py

from threading import Lock

from common.logger import get_logger

logger = get_logger("signal_cache")

# --------------------------------------------------
# Last Saved Signal Cache
#
# Example:
#
# LAST_SIGNAL_CACHE = {
#     "NSE_FO|63959": "BULLISH",
#     "NSE_FO|57360": "BEARISH"
# }
#
# Prevents duplicate Mongo inserts.
# --------------------------------------------------

LAST_SIGNAL_CACHE = {}

# --------------------------------------------------
# Last Processed Candle Timestamp Cache
#
# Example:
#
# LAST_CANDLE_TIMESTAMP = {
#     "NSE_FO|63959":
#         "2026-07-23T10:15:00+05:30"
# }
#
# Prevents processing same candle twice.
# --------------------------------------------------

LAST_CANDLE_TIMESTAMP = {}

cache_lock = Lock()


# ==================================================
# SIGNAL CACHE
# ==================================================


def get_last_signal(instrument_key: str):
    """
    Get last saved signal.
    """

    try:

        with cache_lock:

            return LAST_SIGNAL_CACHE.get(instrument_key)

    except Exception as ex:

        logger.exception(f"Failed getting signal for " f"{instrument_key}: {ex}")

        return None


def set_last_signal(instrument_key: str, signal: str):
    """
    Save latest signal.
    """

    try:

        with cache_lock:

            LAST_SIGNAL_CACHE[instrument_key] = signal

        logger.info(
            f"Signal Updated | " f"Instrument={instrument_key} | " f"Signal={signal}"
        )

    except Exception as ex:

        logger.exception(f"Failed saving signal for " f"{instrument_key}: {ex}")


def is_duplicate_signal(instrument_key: str, signal: str):
    """
    Check if signal already processed.
    """

    try:

        previous_signal = get_last_signal(instrument_key)

        duplicate = previous_signal == signal

        if duplicate:

            logger.info(
                f"Duplicate Signal Ignored | "
                f"Instrument={instrument_key} | "
                f"Signal={signal}"
            )

        return duplicate

    except Exception as ex:

        logger.exception(f"Signal validation failed " f"for {instrument_key}: {ex}")

        return False


# ==================================================
# TIMESTAMP CACHE
# ==================================================


def get_last_timestamp(instrument_key: str):
    """
    Get last processed candle timestamp.
    """

    try:

        with cache_lock:

            return LAST_CANDLE_TIMESTAMP.get(instrument_key)

    except Exception as ex:

        logger.exception(f"Failed getting timestamp for " f"{instrument_key}: {ex}")

        return None


def set_last_timestamp(instrument_key: str, timestamp: str):
    """
    Save latest processed candle timestamp.
    """

    try:

        with cache_lock:

            LAST_CANDLE_TIMESTAMP[instrument_key] = timestamp

        logger.info(
            f"Timestamp Updated | "
            f"Instrument={instrument_key} | "
            f"Timestamp={timestamp}"
        )

    except Exception as ex:

        logger.exception(f"Failed saving timestamp for " f"{instrument_key}: {ex}")


def is_duplicate_candle(instrument_key: str, timestamp: str):
    """
    Check whether candle was
    already processed.
    """

    try:

        last_timestamp = get_last_timestamp(instrument_key)

        duplicate = last_timestamp == timestamp

        if duplicate:

            logger.info(
                f"Duplicate Candle Ignored | "
                f"Instrument={instrument_key} | "
                f"Timestamp={timestamp}"
            )

        return duplicate

    except Exception as ex:

        logger.exception(f"Timestamp validation failed " f"for {instrument_key}: {ex}")

        return False


# ==================================================
# CACHE MANAGEMENT
# ==================================================


def clear_signal_cache():
    """
    Clear all runtime signal caches.
    """

    try:

        with cache_lock:

            signal_count = len(LAST_SIGNAL_CACHE)

            timestamp_count = len(LAST_CANDLE_TIMESTAMP)

            LAST_SIGNAL_CACHE.clear()

            LAST_CANDLE_TIMESTAMP.clear()

        logger.info(
            f"Signal Cache Cleared | "
            f"Signals={signal_count} | "
            f"Timestamps={timestamp_count}"
        )

    except Exception as ex:

        logger.exception(f"Failed clearing " f"signal cache: {ex}")


def get_signal_cache_size():
    """
    Return signal cache size.
    """

    try:

        with cache_lock:

            return len(LAST_SIGNAL_CACHE)

    except Exception:

        return 0


def get_timestamp_cache_size():
    """
    Return timestamp cache size.
    """

    try:

        with cache_lock:

            return len(LAST_CANDLE_TIMESTAMP)

    except Exception:

        return 0
