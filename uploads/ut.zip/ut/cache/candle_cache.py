# cache/candle_cache.py

from threading import Lock

from common.logger import get_logger

logger = get_logger("candle_cache")

# -------------------------------------------------
# Runtime Candle Cache
#
# Structure:
#
# {
#     "NSE_FO|63959": response,
#     "NSE_FO|57360": response
# }
# -------------------------------------------------

INTRADAY_CANDLE_CACHE = {}

cache_lock = Lock()


def set_candles(instrument_key: str, candle_data):
    """
    Store candles in cache.
    """

    try:

        with cache_lock:

            INTRADAY_CANDLE_CACHE[instrument_key] = candle_data

        candle_count = 0

        try:

            candle_count = len(candle_data.data.candles)

        except Exception:
            pass

        logger.info(
            f"Candle cache updated | "
            f"Instrument={instrument_key} | "
            f"Candles={candle_count}"
        )

    except Exception as ex:

        logger.exception(f"Failed storing candles for " f"{instrument_key}: {ex}")


def get_candles(instrument_key: str):
    """
    Get candles from cache.
    """

    try:

        with cache_lock:

            return INTRADAY_CANDLE_CACHE.get(instrument_key)

    except Exception as ex:

        logger.exception(f"Failed getting candles for " f"{instrument_key}: {ex}")

        return None


def has_candles(instrument_key: str):
    """
    Check if instrument exists in cache.
    """

    try:

        with cache_lock:

            return instrument_key in INTRADAY_CANDLE_CACHE

    except Exception as ex:

        logger.exception(f"Error checking cache for " f"{instrument_key}: {ex}")

        return False


def remove_candles(instrument_key: str):
    """
    Remove instrument candles from cache.
    """

    try:

        with cache_lock:

            if instrument_key in INTRADAY_CANDLE_CACHE:

                del INTRADAY_CANDLE_CACHE[instrument_key]

                logger.info(f"Removed candle cache: " f"{instrument_key}")

    except Exception as ex:

        logger.exception(f"Failed removing cache for " f"{instrument_key}: {ex}")


def clear_cache():
    """
    Clear entire candle cache.
    """

    try:

        with cache_lock:

            count = len(INTRADAY_CANDLE_CACHE)

            INTRADAY_CANDLE_CACHE.clear()

        logger.info(f"Candle cache cleared | " f"Removed={count}")

    except Exception as ex:

        logger.exception(f"Failed clearing candle cache: {ex}")


def get_cache_size():
    """
    Number of instruments cached.
    """

    try:

        with cache_lock:

            return len(INTRADAY_CANDLE_CACHE)

    except Exception:

        return 0


def get_cached_instruments():
    """
    Return all cached instrument keys.
    """

    try:

        with cache_lock:

            return list(INTRADAY_CANDLE_CACHE.keys())

    except Exception as ex:

        logger.exception(f"Failed getting cached " f"instruments: {ex}")

        return []


def get_latest_candle(instrument_key: str):
    """
    Return latest candle from cache.
    """

    try:

        response = get_candles(instrument_key)

        if not response:
            return None

        candles = response.data.candles

        if not candles:
            return None

        return candles[-1]

    except Exception as ex:

        logger.exception(f"Failed getting latest candle " f"for {instrument_key}: {ex}")

        return None
