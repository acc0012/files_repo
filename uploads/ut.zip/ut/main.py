# main.py

import time
import threading
import uvicorn

from pathlib import Path
from fastapi import FastAPI

from cache.market_analysis_cache import (
    load_market_analysis_cache,
    get_instrument_keys,
)

from database.mongodb import get_live_ema_collection

from common.date_util import today_str
from common.market_time import market_is_open
from common.scheduler import wait_until_next_minute
from common.logger import get_logger

from workers.live_ema_worker import run_live_cycle
from workers.premarket_refresh_worker import refresh_before_market

logger = get_logger("main")

# ==================================================
# FAST API
# ==================================================

app = FastAPI(title="Live EMA Monitor API", version="1.0.0")

LOG_DIR = Path("logs")


# ==================================================
# HEALTH
# ==================================================


@app.get("/")
def health():

    return {"status": "running", "service": "live-ema-monitor"}


# ==================================================
# LOG APIS
# ==================================================


@app.get("/logs")
def get_log_files():

    if not LOG_DIR.exists():
        return {"count": 0, "files": []}

    files = sorted([file.name for file in LOG_DIR.glob("*.log")])

    return {"count": len(files), "files": files}


@app.get("/logs/{file_name}")
def get_log_content(file_name: str):

    log_file = LOG_DIR / file_name

    if not log_file.exists():

        return {"success": False, "message": f"Log file not found: {file_name}"}

    try:

        content = log_file.read_text(encoding="utf-8", errors="ignore")

        return {"success": True, "file": file_name, "content": content}

    except Exception as ex:

        return {"success": False, "message": str(ex)}


# ==================================================
# CROSSOVER APIS
# ==================================================


@app.get("/crossovers/latest")
def latest_crossovers():

    collection = get_live_ema_collection()

    trading_date = today_str()

    documents = collection.find({f"daily.{trading_date}.total_crosses": {"$gt": 0}})

    results = []

    for doc in documents:

        daily = doc.get("daily", {}).get(trading_date, {})

        crosses = daily.get("crosses", [])

        if not crosses:
            continue

        latest = crosses[-1]

        results.append(
            {
                "instrument_key": doc.get("instrument_key"),
                "trading_symbol": doc.get("trading_symbol"),
                "status": daily.get("status"),
                "total_crosses": daily.get("total_crosses", 0),
                "latest_signal": latest.get("signal"),
                "latest_price": latest.get("price"),
                "latest_timestamp": latest.get("timestamp"),
            }
        )

    return {"count": len(results), "data": results}


@app.get("/crossovers/today")
def today_crossovers():

    collection = get_live_ema_collection()

    trading_date = today_str()

    data = list(
        collection.find({f"daily.{trading_date}.total_crosses": {"$gt": 0}}, {"_id": 0})
    )

    return {"count": len(data), "data": data}


@app.get("/crossovers/{instrument_key}")
def instrument_crossovers(instrument_key: str):

    collection = get_live_ema_collection()

    document = collection.find_one({"instrument_key": instrument_key}, {"_id": 0})

    if not document:

        return {
            "success": False,
            "message": f"Instrument not found: " f"{instrument_key}",
        }

    return document


# ==================================================
# DASHBOARD API
# ==================================================


@app.get("/dashboard")
def dashboard():

    collection = get_live_ema_collection()

    trading_date = today_str()

    bullish = 0
    bearish = 0

    latest_signals = []

    docs = collection.find({f"daily.{trading_date}.total_crosses": {"$gt": 0}})

    for doc in docs:

        daily = doc.get("daily", {}).get(trading_date, {})

        status = daily.get("status")

        if status == "BULLISH":
            bullish += 1

        elif status == "BEARISH":
            bearish += 1

        crosses = daily.get("crosses", [])

        if crosses:

            latest = crosses[-1]

            latest_signals.append(
                {
                    "instrument_key": doc.get("instrument_key"),
                    "trading_symbol": doc.get("trading_symbol"),
                    "signal": latest.get("signal"),
                    "price": latest.get("price"),
                    "timestamp": latest.get("timestamp"),
                }
            )

    return {
        "market_open": market_is_open(),
        "loaded_instruments": len(get_instrument_keys()),
        "bullish_count": bullish,
        "bearish_count": bearish,
        "total_crossovers": len(latest_signals),
        "latest_signals": latest_signals,
    }


# ==================================================
# API SERVER
# ==================================================


def start_api_server():

    logger.info("Starting API Server " "on http://localhost:8000")

    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        log_level="warning",
    )


# ==================================================
# INITIALIZATION
# ==================================================


def initialize():

    logger.info("========== APPLICATION STARTED ==========")

    refresh_before_market()

    load_market_analysis_cache()

    instrument_count = len(get_instrument_keys())

    logger.info(f"Loaded Instruments: " f"{instrument_count}")

    print(f"\nLoaded Instruments: " f"{instrument_count}")

    print("\nAvailable APIs")

    print("Health      : " "http://localhost:8000/")

    print("Logs        : " "http://localhost:8000/logs")

    print("Dashboard   : " "http://localhost:8000/dashboard")

    print("Latest Cross: " "http://localhost:8000/crossovers/latest")

    print("Today's Data: " "http://localhost:8000/crossovers/today")

    print("Swagger UI  : " "http://localhost:8000/docs")


# ==================================================
# MARKET LOOP
# ==================================================


def run_market_loop():

    logger.info("Starting live EMA monitoring loop")

    while True:

        try:

            if market_is_open():

                logger.info("Market Open - " "Starting processing cycle")

                run_live_cycle()

                logger.info("Processing cycle completed")

                wait_until_next_minute()

            else:

                logger.info("Market Closed - Waiting...")

                time.sleep(30)

        except Exception as ex:

            logger.exception(f"Error in market loop: {ex}")

            time.sleep(10)


# ==================================================
# MAIN
# ==================================================


def main():

    try:

        api_thread = threading.Thread(target=start_api_server, daemon=True)

        api_thread.start()

        initialize()

        run_market_loop()

    except KeyboardInterrupt:

        logger.info("Application stopped by user")

        print("\nApplication stopped.")

    except Exception as ex:

        logger.exception(f"Fatal Application Error: {ex}")

        raise


if __name__ == "__main__":
    main()
