# api/logs_api.py

from pathlib import Path

from fastapi import APIRouter, HTTPException

router = APIRouter(prefix="/logs", tags=["Logs"])

LOG_DIR = Path("logs")


@router.get("")
def get_log_files():

    if not LOG_DIR.exists():
        return {"count": 0, "files": []}

    files = sorted([file.name for file in LOG_DIR.glob("*.log")])

    return {"count": len(files), "files": files}


@router.get("/{file_name}")
def get_log_content(file_name: str):

    log_file = LOG_DIR / file_name

    if not log_file.exists():
        raise HTTPException(status_code=404, detail=f"Log file not found: {file_name}")

    try:
        content = log_file.read_text(encoding="utf-8", errors="ignore")

        return {"file": file_name, "content": content}

    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))
