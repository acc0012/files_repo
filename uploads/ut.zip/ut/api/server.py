from pathlib import Path

from fastapi import FastAPI, HTTPException

from database.mongodb import get_live_ema_collection
from common.date_util import today_str

app = FastAPI(title="Live EMA Monitor API", version="1.0.0")

# ==================================================
# LOG APIS
# ==================================================

LOG_DIR = Path("logs")


@app.get("/")
def health():
    return {"status": "running"}


@app.get("/logs")
def get_logs():

    if not LOG_DIR.exists():
        return {"count": 0, "files": []}

    files = sorted([file.name for file in LOG_DIR.glob("*.log")])

    return {"count": len(files), "files": files}


@app.get("/logs/{file_name}")
def get_log_content(file_name: str):

    log_file = LOG_DIR / file_name

    if not log_file.exists():
        raise HTTPException(status_code=404, detail=f"{file_name} not found")

    return {
        "file": file_name,
        "content": log_file.read_text(encoding="utf-8", errors="ignore"),
    }


# ==================================================
# CROSSOVER APIS
# ==================================================


@app.get("/crossovers/latest")
def get_latest_crossovers():

    collection = get_live_ema_collection()

    trading_date = today_str()

    results = []

    documents = list(
        collection.find({f"daily.{trading_date}.total_crosses": {"$gt": 0}})
    )

    for doc in documents:

        daily_data = doc.get("daily", {}).get(trading_date, {})

        crosses = daily_data.get("crosses", [])

        if not crosses:
            continue

        latest = crosses[-1]

        results.append(
            {
                "instrument_key": doc.get("instrument_key"),
                "trading_symbol": doc.get("trading_symbol"),
                "status": daily_data.get("status"),
                "latest_signal": latest.get("signal"),
                "latest_price": latest.get("price"),
                "latest_timestamp": latest.get("timestamp"),
                "total_crosses": daily_data.get("total_crosses", 0),
            }
        )

    return {"count": len(results), "data": results}


@app.get("/crossovers/{instrument_key}")
def get_instrument_crossovers(instrument_key: str):

    collection = get_live_ema_collection()

    doc = collection.find_one({"instrument_key": instrument_key}, {"_id": 0})

    if not doc:
        raise HTTPException(status_code=404, detail=f"{instrument_key} not found")

    return doc


@app.get("/crossovers/today")
def get_today_crossovers():

    collection = get_live_ema_collection()

    trading_date = today_str()

    docs = list(
        collection.find({f"daily.{trading_date}.total_crosses": {"$gt": 0}}, {"_id": 0})
    )

    return {"count": len(docs), "data": docs}


@app.get("/dashboard")
def dashboard():

    collection = get_live_ema_collection()

    trading_date = today_str()

    bullish = 0
    bearish = 0

    latest_signals = []

    docs = list(collection.find({f"daily.{trading_date}.total_crosses": {"$gt": 0}}))

    for doc in docs:

        daily_data = doc.get("daily", {}).get(trading_date, {})

        status = daily_data.get("status")

        if status == "BULLISH":
            bullish += 1

        elif status == "BEARISH":
            bearish += 1

        crosses = daily_data.get("crosses", [])

        if crosses:

            latest = crosses[-1]

            latest_signals.append(
                {
                    "instrument_key": doc.get("instrument_key"),
                    "trading_symbol": doc.get("trading_symbol"),
                    "signal": latest.get("signal"),
                    "price": latest.get("price"),
                    "timestamp": latest.get("timestamp"),
                }
            )

    return {
        "today": trading_date,
        "bullish_count": bullish,
        "bearish_count": bearish,
        "total_crossovers": len(latest_signals),
        "latest_signals": latest_signals,
    }


@app.get("/help")
def api_help():

    return {
        "service": "Live EMA Monitor API",
        "apis": [
            {
                "name": "Health Check",
                "method": "GET",
                "url": "/",
                "sample_request": "http://localhost:8000/",
                "description": "Returns API status",
            },
            {
                "name": "Get Log Files",
                "method": "GET",
                "url": "/logs",
                "sample_request": "http://localhost:8000/logs",
                "description": "Returns available log files",
            },
            {
                "name": "Get Log Content",
                "method": "GET",
                "url": "/logs/{file_name}",
                "sample_request": "http://localhost:8000/logs/main.log",
                "description": "Returns full log content",
            },
            {
                "name": "Latest Crossovers",
                "method": "GET",
                "url": "/crossovers/latest",
                "sample_request": "http://localhost:8000/crossovers/latest",
                "description": "Returns latest crossover for every instrument",
            },
            {
                "name": "Today's Crossovers",
                "method": "GET",
                "url": "/crossovers/today",
                "sample_request": "http://localhost:8000/crossovers/today",
                "description": "Returns today's crossover documents",
            },
            {
                "name": "Instrument Crossovers",
                "method": "GET",
                "url": "/crossovers/{instrument_key}",
                "sample_request": "http://localhost:8000/crossovers/NSE_FO|63945",
                "description": "Returns all crossover history for an instrument",
            },
            {
                "name": "Dashboard",
                "method": "GET",
                "url": "/dashboard",
                "sample_request": "http://localhost:8000/dashboard",
                "description": "Returns dashboard statistics",
            },
        ],
    }
