# services/live_ema_repository.py

from datetime import datetime

from database.mongodb import get_live_ema_collection

from common.date_util import today_str

from common.logger import get_logger

logger = get_logger("live_ema_repository")


def save_cross_signal(details: dict, signal: str, price: float, timestamp: str):
    """
    Save EMA crossover signal into
    live_ema_analysis collection.

    Example Document:

    {
        "instrument_key": "NSE_FO|63959",
        "trading_symbol": "...",
        "strike": "24500",
        "type": "CE",

        "daily": {
            "2026-07-23": {
                "status": "BEARISH",
                "total_crosses": 4,
                "crosses": [
                    ...
                ]
            }
        },

        "last_updated_date": "2026-07-23",
        "last_updated": ISODate(...)
    }
    """

    try:

        collection = get_live_ema_collection()

        trading_date = today_str()

        crossover_data = {
            "timestamp": timestamp,
            "signal": signal,
            "price": round(float(price), 2),
        }

        logger.info(
            f"Saving crossover | "
            f"Instrument={details.get('instrument_key')} | "
            f"Signal={signal} | "
            f"Price={price}"
        )

        result = collection.update_one(
            {"instrument_key": details["instrument_key"]},
            {
                "$set": {
                    "instrument_key": details["instrument_key"],
                    "trading_symbol": details.get("trading_symbol"),
                    "strike": details.get("strike"),
                    "type": details.get("type"),
                    "last_updated_date": trading_date,
                    "last_updated": datetime.utcnow(),
                    f"daily.{trading_date}.status": signal,
                },
                "$push": {f"daily.{trading_date}.crosses": crossover_data},
                "$inc": {f"daily.{trading_date}.total_crosses": 1},
            },
            upsert=True,
        )

        logger.info(
            f"Mongo Upsert Completed | "
            f"Instrument={details['instrument_key']} | "
            f"Matched={result.matched_count} | "
            f"Modified={result.modified_count} | "
            f"Upserted={result.upserted_id}"
        )

        return True

    except Exception as ex:

        logger.exception(
            f"Failed saving crossover | "
            f"Instrument={details.get('instrument_key')} | "
            f"Error={ex}"
        )

        return False


def get_live_ema_document(instrument_key: str):
    """
    Fetch complete EMA document.
    """

    try:

        collection = get_live_ema_collection()

        document = collection.find_one({"instrument_key": instrument_key})

        logger.info(f"EMA document fetched | " f"Instrument={instrument_key}")

        return document

    except Exception as ex:

        logger.exception(
            f"Failed fetching EMA document | "
            f"Instrument={instrument_key} | "
            f"Error={ex}"
        )

        return None


def get_today_crosses(instrument_key: str):
    """
    Fetch today's crossover list.
    """

    try:

        trading_date = today_str()

        document = get_live_ema_document(instrument_key)

        if not document:
            return []

        daily_data = document.get("daily", {})

        today_data = daily_data.get(trading_date, {})

        return today_data.get("crosses", [])

    except Exception as ex:

        logger.exception(
            f"Failed fetching today's crosses | "
            f"Instrument={instrument_key} | "
            f"Error={ex}"
        )

        return []


def get_today_cross_count(instrument_key: str):
    """
    Return today's total crossover count.
    """

    try:

        trading_date = today_str()

        document = get_live_ema_document(instrument_key)

        if not document:
            return 0

        daily_data = document.get("daily", {})

        today_data = daily_data.get(trading_date, {})

        return today_data.get("total_crosses", 0)

    except Exception as ex:

        logger.exception(
            f"Failed fetching crossover count | "
            f"Instrument={instrument_key} | "
            f"Error={ex}"
        )

        return 0


def update_day_status(instrument_key: str, status: str):
    """
    Update trading day status.

    Examples:
        BULLISH
        BEARISH
        NO_CROSSOVER
    """

    try:

        trading_date = today_str()

        collection = get_live_ema_collection()

        collection.update_one(
            {"instrument_key": instrument_key},
            {
                "$set": {
                    f"daily.{trading_date}.status": status,
                    "last_updated": datetime.utcnow(),
                    "last_updated_date": trading_date,
                }
            },
            upsert=True,
        )

        logger.info(
            f"Status Updated | " f"Instrument={instrument_key} | " f"Status={status}"
        )

        return True

    except Exception as ex:

        logger.exception(
            f"Failed updating status | " f"Instrument={instrument_key} | " f"Error={ex}"
        )

        return False


def delete_today_crosses(instrument_key: str):
    """
    Utility method for testing/debugging.
    Clears today's crossover history.
    """

    try:

        trading_date = today_str()

        collection = get_live_ema_collection()

        collection.update_one(
            {"instrument_key": instrument_key},
            {
                "$set": {
                    f"daily.{trading_date}.crosses": [],
                    f"daily.{trading_date}.total_crosses": 0,
                    f"daily.{trading_date}.status": "NO_CROSSOVER",
                }
            },
        )

        logger.info(f"Today's crosses cleared | " f"Instrument={instrument_key}")

        return True

    except Exception as ex:

        logger.exception(
            f"Failed clearing crosses | "
            f"Instrument={instrument_key} | "
            f"Error={ex}"
        )

        return False
