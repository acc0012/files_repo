# services/intraday_candle_service.py

import upstox_client

from cache.candle_cache import set_candles, get_candles

from common.logger import get_logger

from config.settings import UPSTOX_ACCESS_TOKEN

logger = get_logger("intraday_candle_service")


def _get_history_api():
    """
    Create authenticated Upstox HistoryV3 API instance.
    """

    try:

        configuration = upstox_client.Configuration()

        configuration.access_token = UPSTOX_ACCESS_TOKEN

        api_client = upstox_client.ApiClient(configuration)

        return upstox_client.HistoryV3Api(api_client)

    except Exception as ex:

        logger.exception(f"Failed to create Upstox API client: {ex}")

        raise


def load_intraday_candles(instrument_key: str, interval: str = "1"):
    """
    Fetch latest intraday candles and save to cache.

    Returns:
        API Response object
    """

    try:

        logger.info(f"Fetching intraday candles for " f"{instrument_key}")

        api = _get_history_api()

        response = api.get_intra_day_candle_data(instrument_key, "minutes", interval)

        set_candles(instrument_key, response)

        try:

            candle_count = len(response.data.candles)

        except Exception:

            candle_count = 0

        logger.info(f"{instrument_key} -> " f"Downloaded {candle_count} candles")

        return response

    except Exception as ex:

        logger.exception(f"Failed fetching candles for " f"{instrument_key}: {ex}")

        return None


def refresh_intraday_candles(instrument_key: str):
    """
    Refresh candle cache for instrument.
    """

    logger.info(f"Refreshing candles " f"for {instrument_key}")

    return load_intraday_candles(instrument_key)


def get_latest_candle(instrument_key: str):
    """
    Get latest candle from cache.
    """

    try:

        response = get_candles(instrument_key)

        if not response:
            return None

        candles = response.data.candles

        if not candles:
            return None

        return candles[-1]

    except Exception as ex:

        logger.exception(f"Error getting latest candle " f"for {instrument_key}: {ex}")

        return None


def get_latest_price(instrument_key: str):
    """
    Get latest close price from cache.
    """

    try:

        candle = get_latest_candle(instrument_key)

        if not candle:
            return None

        # Upstox candle format:
        # [timestamp, open, high, low, close, volume]

        if len(candle) < 5:
            return None

        return float(candle[4])

    except Exception as ex:

        logger.exception(f"Failed getting latest " f"price for {instrument_key}: {ex}")

        return None


def get_candle_count(instrument_key: str):
    """
    Return candle count currently
    stored in cache.
    """

    try:

        response = get_candles(instrument_key)

        if not response:
            return 0

        return len(response.data.candles)

    except Exception:

        return 0
