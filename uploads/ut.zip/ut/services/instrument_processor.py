# services/instrument_processor.py

from services.intraday_candle_service import load_intraday_candles

from services.ema_service import process_ema

from common.logger import get_logger

logger = get_logger("instrument_processor")


def process_instrument(instrument_key: str):
    """
    Process a single instrument.

    Flow:
        1. Fetch latest intraday candles
        2. Store candles in cache
        3. Calculate EMA9/EMA21
        4. Detect crossover
        5. Save signal into live_ema_analysis

    This function is designed to run
    inside ThreadPoolExecutor workers.
    """

    try:

        logger.info(f"Started Processing | " f"Instrument={instrument_key}")

        # ---------------------------------
        # Fetch latest candles
        # ---------------------------------

        candle_response = load_intraday_candles(instrument_key)

        if not candle_response:

            logger.warning(f"Candle Fetch Failed | " f"Instrument={instrument_key}")

            return False

        try:

            candle_count = len(candle_response.data.candles)

        except Exception:

            candle_count = 0

        logger.info(
            f"Candles Loaded | "
            f"Instrument={instrument_key} | "
            f"Count={candle_count}"
        )

        # ---------------------------------
        # Process EMA & Save Crossover
        # ---------------------------------

        process_ema(instrument_key)

        logger.info(f"Completed Processing | " f"Instrument={instrument_key}")

        return True

    except Exception as ex:

        logger.exception(
            f"Instrument Processing Failed | "
            f"Instrument={instrument_key} | "
            f"Error={ex}"
        )

        return False
