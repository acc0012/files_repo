# services/crossover_detector.py

import pandas as pd

from common.constants import SHORT_EMA, LONG_EMA

from common.logger import get_logger

logger = get_logger("crossover_detector")


def calculate_short_ema(prices):
    """
    Calculate short EMA.

    Default:
        EMA 9
    """

    try:

        series = pd.Series(prices)

        return series.ewm(span=SHORT_EMA, adjust=False).mean()

    except Exception as ex:

        logger.exception(f"Short EMA calculation failed: {ex}")

        return None


def calculate_long_ema(prices):
    """
    Calculate long EMA.

    Default:
        EMA 21
    """

    try:

        series = pd.Series(prices)

        return series.ewm(span=LONG_EMA, adjust=False).mean()

    except Exception as ex:

        logger.exception(f"Long EMA calculation failed: {ex}")

        return None


def get_latest_ema_values(prices):
    """
    Return latest EMA9 and EMA21 values.
    """

    try:

        ema_short = calculate_short_ema(prices)

        ema_long = calculate_long_ema(prices)

        if ema_short is None or ema_long is None:
            return None

        return {
            "short_ema": round(float(ema_short.iloc[-1]), 4),
            "long_ema": round(float(ema_long.iloc[-1]), 4),
        }

    except Exception as ex:

        logger.exception(f"Failed retrieving EMA values: {ex}")

        return None


def is_bullish_crossover(ema_short, ema_long):
    """
    Bullish Crossover:

    EMA9 crosses above EMA21
    """

    try:

        return (
            ema_short.iloc[-2] < ema_long.iloc[-2]
            and ema_short.iloc[-1] > ema_long.iloc[-1]
        )

    except Exception:

        return False


def is_bearish_crossover(ema_short, ema_long):
    """
    Bearish Crossover:

    EMA9 crosses below EMA21
    """

    try:

        return (
            ema_short.iloc[-2] > ema_long.iloc[-2]
            and ema_short.iloc[-1] < ema_long.iloc[-1]
        )

    except Exception:

        return False


def detect_crossover(prices):
    """
    Detect EMA9 / EMA21 crossover.

    Returns:
        BULLISH
        BEARISH
        None
    """

    try:

        if not prices:

            logger.warning("Empty price list received")

            return None

        minimum_required = LONG_EMA + 2

        if len(prices) < minimum_required:

            logger.warning(
                f"Not enough candles. "
                f"Required={minimum_required}, "
                f"Available={len(prices)}"
            )

            return None

        ema_short = calculate_short_ema(prices)

        ema_long = calculate_long_ema(prices)

        if ema_short is None or ema_long is None:
            return None

        latest_short = round(float(ema_short.iloc[-1]), 4)

        latest_long = round(float(ema_long.iloc[-1]), 4)

        logger.info(
            f"EMA Values | "
            f"EMA{SHORT_EMA}={latest_short} | "
            f"EMA{LONG_EMA}={latest_long}"
        )

        if is_bullish_crossover(ema_short, ema_long):

            logger.info("BULLISH crossover detected")

            return "BULLISH"

        if is_bearish_crossover(ema_short, ema_long):

            logger.info("BEARISH crossover detected")

            return "BEARISH"

        logger.debug("No crossover detected")

        return None

    except Exception as ex:

        logger.exception(f"Crossover detection failed: {ex}")

        return None
