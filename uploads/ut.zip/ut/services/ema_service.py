# services/ema_service.py

from cache.candle_cache import get_candles

from cache.signal_cache import LAST_SIGNAL_CACHE, LAST_CANDLE_TIMESTAMP

from cache.market_analysis_cache import get_instrument_doc

from services.crossover_detector import detect_crossover

from services.live_ema_repository import save_cross_signal

from common.logger import get_logger

logger = get_logger("ema_service")


def process_ema(instrument_key: str):
    """
    Process EMA crossover for a single instrument.

    Flow:
        1. Read candles from cache
        2. Calculate EMA crossover
        3. Prevent duplicate signals
        4. Save crossover to MongoDB
    """

    try:

        candles_response = get_candles(instrument_key)

        if not candles_response:

            logger.warning(f"No candle data found for " f"{instrument_key}")

            return

        try:

            candle_data = candles_response.data.candles

        except Exception as ex:

            logger.error(f"Invalid candle response for " f"{instrument_key}: {ex}")

            return

        if not candle_data:

            logger.warning(f"Empty candle data for " f"{instrument_key}")

            return

        prices = [float(candle[4]) for candle in candle_data if len(candle) > 4]

        if not prices:

            logger.warning(f"No valid prices found for " f"{instrument_key}")

            return

        signal = detect_crossover(prices)

        if not signal:

            logger.info(f"{instrument_key} " f"No crossover found")

            return

        latest_candle = candle_data[-1]

        candle_timestamp = str(latest_candle[0])

        latest_price = float(latest_candle[4])

        # ---------------------------------
        # Prevent duplicate candle processing
        # ---------------------------------

        last_processed_timestamp = LAST_CANDLE_TIMESTAMP.get(instrument_key)

        if last_processed_timestamp == candle_timestamp:

            logger.info(
                f"{instrument_key} "
                f"already processed for "
                f"timestamp "
                f"{candle_timestamp}"
            )

            return

        # ---------------------------------
        # Prevent duplicate signals
        # ---------------------------------

        previous_signal = LAST_SIGNAL_CACHE.get(instrument_key)

        if previous_signal == signal:

            logger.info(f"{instrument_key} " f"duplicate signal ignored: " f"{signal}")

            LAST_CANDLE_TIMESTAMP[instrument_key] = candle_timestamp

            return

        instrument_doc = get_instrument_doc(instrument_key)

        if not instrument_doc:

            logger.warning(
                f"Instrument metadata " f"not found for " f"{instrument_key}"
            )

            return

        save_cross_signal(
            details=instrument_doc,
            signal=signal,
            price=latest_price,
            timestamp=candle_timestamp,
        )

        LAST_SIGNAL_CACHE[instrument_key] = signal

        LAST_CANDLE_TIMESTAMP[instrument_key] = candle_timestamp

        logger.info(
            f"{instrument_key} "
            f"Crossover Saved | "
            f"Signal={signal} | "
            f"Price={latest_price} | "
            f"Timestamp={candle_timestamp}"
        )

    except Exception as ex:

        logger.exception(f"EMA processing failed for " f"{instrument_key}: {ex}")
