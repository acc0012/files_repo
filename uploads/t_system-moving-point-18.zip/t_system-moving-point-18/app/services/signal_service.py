from app.logger import get_logger

from app.utils.datetime_helper import (
    ist_now,
)

from app.services.mongo_service import (
    index_signal_collection,
    option_signal_collection,
)

logger = get_logger()

# ==========================================================
# PROCESS SIGNAL
# ==========================================================


def process_signal(trace_id: str, payload: dict):

    try:
        source = payload.get("ALERT_SOURCE")

        logger.info(
            f"Processing Signal "
            f"trace_id={trace_id} "
            f"source={source} "
            f"type={payload.get('TYPE')} "
            f"symbol={payload.get('SYMBOL')}"
        )

        signal_type = payload.get("TYPE")

        live_ce_strike = payload.get("LIVE_CE_STRIKE")
        live_pe_strike = payload.get("LIVE_PE_STRIKE")

        # ✅ FIX: Handle OBJECT strike from Pine
        suggested_strike_raw = payload.get("SUGGESTED_STRIKE", {})

        strike_50 = None
        strike_100 = None
        recommended_strike = ""

        if isinstance(suggested_strike_raw, dict):
            strike_50 = suggested_strike_raw.get("STRIKE_50")
            strike_100 = suggested_strike_raw.get("STRIKE_100")
            recommended_strike = strike_50 or strike_100 or ""
        else:
            recommended_strike = suggested_strike_raw or ""

        signal_direction = ""
        signal_title = ""
        signal_message = ""

        # ==================================================
        # ✅ SIGNAL LOGIC (CLEAN + SAFE)
        # ==================================================

        if signal_type == "BUY_CE":

            signal_direction = "BUY"
            signal_title = "MARKET RISING"

            if not recommended_strike:
                recommended_strike = f"{live_ce_strike} CE"

            if isinstance(suggested_strike_raw, dict):
                signal_message = (
                    "Market is showing bullish momentum. "
                    f"ATM: {strike_50 or '-'} | Safe: {strike_100 or '-'}"
                )
            else:
                signal_message = (
                    f"Market is showing bullish momentum. "
                    f"Take CALL Option {recommended_strike}"
                )

        elif signal_type == "SELL_CE":

            signal_direction = "SELL"
            signal_title = "EXIT CALL POSITION"

            if not recommended_strike:
                recommended_strike = f"{live_ce_strike} CE"

            if isinstance(suggested_strike_raw, dict):
                signal_message = (
                    "Bullish momentum is weakening. "
                    f"ATM: {strike_50 or '-'} | Safe: {strike_100 or '-'}"
                )
            else:
                signal_message = (
                    f"Bullish momentum is weakening. "
                    f"Exit CALL Option {recommended_strike}"
                )

        elif signal_type == "BUY_PE":

            signal_direction = "BUY"
            signal_title = "MARKET FALLING"

            if not recommended_strike:
                recommended_strike = f"{live_pe_strike} PE"

            if isinstance(suggested_strike_raw, dict):
                signal_message = (
                    "Market is showing bearish momentum. "
                    f"ATM: {strike_50 or '-'} | Safe: {strike_100 or '-'}"
                )
            else:
                signal_message = (
                    f"Market is showing bearish momentum. "
                    f"Take PUT Option {recommended_strike}"
                )

        elif signal_type == "SELL_PE":

            signal_direction = "SELL"
            signal_title = "EXIT PUT POSITION"

            if not recommended_strike:
                recommended_strike = f"{live_pe_strike} PE"

            if isinstance(suggested_strike_raw, dict):
                signal_message = (
                    "Bearish momentum is weakening. "
                    f"ATM: {strike_50 or '-'} | Safe: {strike_100 or '-'}"
                )
            else:
                signal_message = (
                    f"Bearish momentum is weakening. "
                    f"Exit PUT Option {recommended_strike}"
                )

        # ==================================================
        # ✅ DOCUMENT (FIXED)
        # ==================================================

        doc = {
            "trace_id": trace_id,
            "alert_source": source,
            "alert_category": payload.get("ALERT_CATEGORY"),
            "type": signal_type,
            "ticker": payload.get("TICKER"),
            "symbol": payload.get("SYMBOL"),
            "date": payload.get("DATE"),
            "time": payload.get("TIME"),
            "timeframe": payload.get("TF"),

            # ✅ UI fields
            "signal_direction": signal_direction,
            "signal_title": signal_title,
            "signal_message": signal_message,

            # ✅ FIXED STRIKE STORAGE
            "recommended_strike": recommended_strike,
            "suggested_strike_50": strike_50,
            "suggested_strike_100": strike_100,
            "strike_meta": suggested_strike_raw,
            "ema_cross_history": payload.get("EMA_CROSS_HISTORY"),

            # Core data
            "price": float(payload.get("PRICE", 0) or 0),
            "ema9": float(payload.get("EMA9", 0) or 0),
            "ema21": float(payload.get("EMA21", 0) or 0),
            "diff": float(payload.get("DIFF", 0) or 0),

            "live_main_ltp": float(payload.get("LIVE_MAIN_LTP", 0) or 0),
            "live_ce_strike": live_ce_strike,
            "live_pe_strike": live_pe_strike,

            "high": float(payload.get("HIGH", 0) or 0),
            "low": float(payload.get("LOW", 0) or 0),
            "avg": float(payload.get("AVG", 0) or 0),

            "ema_level_info": payload.get("EMA_LEVEL_INFO", {}),
            "created_at": ist_now(),
        }

        # ==================================================
        # SAVE
        # ==================================================

        if source == "INDEX":

            result = index_signal_collection.insert_one(doc)
            return result.inserted_id

        elif source == "OPTION":

            option_or_payload = payload.get("OPTION_OPENING_RANGE", {})

            doc["option_opening_range"] = option_or_payload

            result = option_signal_collection.insert_one(doc)
            return result.inserted_id

        else:
            raise ValueError(f"Unknown ALERT_SOURCE: {source}")

    except Exception:
        logger.exception(
            f"Signal processing failed trace_id={trace_id}"
        )
        raise
