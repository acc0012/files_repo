from datetime import datetime
from zoneinfo import ZoneInfo
import json
import os
import time
import requests

from app.config import settings
from app.logger import logger


def calculate_levels(high, low):

    avg = round((high + low) / 2, 2)

    range_value = high - low

    high_avg_diff = abs(high - avg)
    low_avg_diff = abs(avg - low)

    resistance1 = avg + (high_avg_diff / 2)
    support1 = avg - (low_avg_diff / 2)

    resistance2 = high + high_avg_diff
    support2 = low - low_avg_diff

    resistance3 = resistance2 + high_avg_diff
    support3 = support2 - low_avg_diff

    return {
        "HIGH": round(high, 2),
        "LOW": round(low, 2),
        "RANGE": round(range_value, 2),
        "AVG": round(avg, 2),

        # Pine Sub Resistance / Sub Support
        "RESISTANCE1": round(resistance1, 2),
        "SUPPORT1": round(support1, 2),

        # Pine Resistance2 / Support2
        "RESISTANCE2": round(resistance2, 2),
        "SUPPORT2": round(support2, 2),

        # Pine Resistance3 / Support3
        "RESISTANCE3": round(resistance3, 2),
        "SUPPORT3": round(support3, 2),
    }


def fetch_intraday_data(
    security_id: int,
    exchange_segment: str,
    instrument_type: str,
    from_date: str = None,
    to_date: str = None,
):
    try:
        logger.info(f"Intraday fetch started security_id={security_id}")

        if not settings.BASE_URL:
            raise ValueError("BASE_URL is missing")

        if not from_date:
            from_date = datetime.now(ZoneInfo("Asia/Kolkata")).strftime("%Y-%m-%d")

        if not to_date:
            to_date = from_date

        url = f"{settings.BASE_URL}/dhan/intraday/"
        params = {
            "security_id": security_id,
            "exchange_segment": exchange_segment,
            "instrument_type": instrument_type,
            "from_date": from_date,
            "to_date": to_date,
        }

        logger.info(f"Calling URL : {url}")

        # ====================================
        # RETRY BLOCK
        # ====================================
        response = None
        last_error = None

        for attempt in range(1, 4):
            try:
                logger.info(
                    f"Intraday attempt {attempt}/3 security_id={security_id}"
                )
                response = requests.get(
                    url, params=params, timeout=settings.REQUEST_TIMEOUT
                )
                logger.info(f"Response Status : {response.status_code}")
                response.raise_for_status()
                break
            except (
                requests.exceptions.Timeout,
                requests.exceptions.ConnectionError,
                requests.exceptions.ChunkedEncodingError,
            ) as e:
                last_error = e
                logger.warning(
                    f"Attempt {attempt}/3 failed "
                    f"security_id={security_id} "
                    f"error={str(e)}"
                )
                if attempt < 3:
                    time.sleep(2)
                else:
                    raise

        response_data = response.json()

        # ====================================
        # OPTIONAL TEST FILE LOGGING
        # ====================================
        if settings.TEST_LOG_FILES:
            try:
                os.makedirs(settings.LOG_FOLDER, exist_ok=True)
                file_name = f"{security_id}_{exchange_segment}_{instrument_type}.json"
                file_path = os.path.join(settings.LOG_FOLDER, file_name)
                with open(file_path, "w", encoding="utf-8") as f:
                    json.dump(response_data, f, indent=4)
                logger.info(f"Response saved : {file_path}")
            except Exception as e:
                logger.exception(f"Failed saving response file : {str(e)}")

        outer_data = response_data.get("data", {})
        if not isinstance(outer_data, dict):
            raise ValueError(f"Unexpected outer data type : {type(outer_data)}")

        market_data = outer_data.get("data", {})
        if not isinstance(market_data, dict):
            raise ValueError(f"Unexpected market data type : {type(market_data)}")

        highs = market_data.get("high", [])
        lows = market_data.get("low", [])

        if not highs:
            raise ValueError("High candles missing")
        if not lows:
            raise ValueError("Low candles missing")

        # ====================================
        # FIRST CANDLE LEVELS
        # ====================================
        first_candle = calculate_levels(highs[0], lows[0])

        # ====================================
        # FIRST 5 CANDLE LEVELS
        # ====================================
        or_high = max(highs[:5])
        or_low = min(lows[:5])
        first_5_candles = calculate_levels(or_high, or_low)

        logger.info(f"Intraday fetch successful security_id={security_id}")

        return {
            "success": True,
            "security_id": security_id,
            "exchange_segment": exchange_segment,
            "instrument_type": instrument_type,
            "from_date": from_date,
            "to_date": to_date,
            "first_candle": first_candle,
            "first_5_candles": first_5_candles,
        }

    except requests.exceptions.Timeout:
        logger.exception(f"Timeout fetching intraday security_id={security_id}")
        return {
            "success": False,
            "security_id": security_id,
            "error": "Request Timeout",
        }

    except requests.exceptions.ConnectionError:
        logger.exception(f"Connection failed security_id={security_id}")
        return {
            "success": False,
            "security_id": security_id,
            "error": "Connection Error",
        }

    except requests.exceptions.ChunkedEncodingError:
        logger.exception(f"Chunked response failed security_id={security_id}")
        return {
            "success": False,
            "security_id": security_id,
            "error": "Response ended prematurely",
        }

    except requests.exceptions.HTTPError as e:
        logger.exception(f"HTTP error security_id={security_id}")
        return {"success": False, "security_id": security_id, "error": str(e)}

    except Exception as e:
        logger.exception(f"Intraday fetch failed : {str(e)}")
        return {"success": False, "security_id": security_id, "error": str(e)}

    finally:
        logger.info(f"Intraday fetch finished security_id={security_id}")