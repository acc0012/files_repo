import asyncio
import json
import websockets

from app.logger import logger
from app.cache.live_market import LIVE_MARKET_CACHE
from app.config import settings

# =====================================================
# MARKET FEED WEBSOCKET LISTENER
# =====================================================



async def listen_market_feed(security_id: int, index_name: str):

    url = f"{settings.BASE_WS_URL}" f"/ws/market/{security_id}/"
    last_heartbeat = 0
    message_count = 0
    while True:

        try:

            logger.info(f"Connecting {index_name} -> {url}")

            async with websockets.connect(url, ping_interval=20, ping_timeout=20) as ws:

                logger.info(f"{index_name} connected")

                async for message in ws:

                    try:

                        obj = json.loads(message)


                        current_time = asyncio.get_running_loop().time()

                        if current_time - last_heartbeat >= int(settings.HEART_BEAT_INTERVAL):

                            logger.info(
                                f"[HEARTBEAT] "
                                f"{index_name} | "
                                f"LTP={obj.get('LTP')} | "
                                f"LTT={obj.get('LTT')} "
                            )

                            last_heartbeat = current_time

                        LIVE_MARKET_CACHE[security_id] = {
                            "type": obj.get("type"),
                            "exchange_segment": obj.get("exchange_segment"),
                            # Instrument Info
                            "security_id": security_id,
                            "feed_security_id": obj.get("security_id"),
                            "index_name": index_name,
                            # Last Traded Data
                            "ltp": float(obj.get("LTP") or 0),
                            "ltq": int(obj.get("LTQ") or 0),
                            "ltt": obj.get("LTT"),
                            # Price Stats
                            "avg_price": float(obj.get("avg_price") or 0),
                            "open": float(obj.get("open") or 0),
                            "high": float(obj.get("high") or 0),
                            "low": float(obj.get("low") or 0),
                            "close": float(obj.get("close") or 0),
                            # Volume Data
                            "volume": int(obj.get("volume") or 0),
                            "total_buy_quantity": int(
                                obj.get("total_buy_quantity") or 0
                            ),
                            "total_sell_quantity": int(
                                obj.get("total_sell_quantity") or 0
                            ),
                            # Timestamp
                            "updated_at": obj.get("LTT"),
                        }

                    except Exception as e:

                        logger.exception(f"{index_name} message parse error : {e}")

        except Exception as e:

            logger.exception(f"{index_name} socket error : {e}")

            logger.info(f"Reconnecting {index_name} in 5 seconds...")

            await asyncio.sleep(5)
