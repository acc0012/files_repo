import asyncio
import json
import websockets

from app.logger import logger
from app.cache import OPTION_LIVE_CACHE
from app.config import settings

# ==========================================================
# ACTIVE OPTION SOCKET TASKS
# ==========================================================

ACTIVE_OPTION_TASKS = {}

# ==========================================================
# OPTION MARKET WEBSOCKET LISTENER
# ==========================================================

async def listen_option_feed(
    security_id: int,
    symbol: str
):

    url = (
        f"{settings.BASE_WS_URL}"
        f"/ws/market/{security_id}/"
    )

    last_heartbeat = 0

    while True:

        try:

            logger.info(
                f"Connecting option socket "
                f"{symbol} -> {url}"
            )

            async with websockets.connect(
                url,
                ping_interval=20,
                ping_timeout=20
            ) as ws:

                logger.info(
                    f"Option socket connected : "
                    f"{symbol}"
                )

                async for message in ws:

                    try:

                        obj = json.loads(message)

                        current_time = (
                            asyncio.get_running_loop().time()
                        )

                        # ======================================
                        # HEARTBEAT LOG
                        # ======================================

                        if (
                            current_time - last_heartbeat
                            >= int(settings.HEART_BEAT_INTERVAL)
                        ):

                            logger.info(
                                f"[OPTION HEARTBEAT] "
                                f"{symbol} | "
                                f"LTP={obj.get('LTP')} | "
                                f"LTT={obj.get('LTT')}"
                            )

                            last_heartbeat = current_time

                        # ======================================
                        # CACHE UPDATE
                        # ======================================

                        OPTION_LIVE_CACHE[security_id] = {

                            # ----------------------------------
                            # IDENTIFICATION
                            # ----------------------------------

                            "symbol":
                                symbol,

                            "security_id":
                                security_id,

                            "feed_security_id":
                                obj.get("security_id"),

                            "exchange_segment":
                                obj.get("exchange_segment"),

                            "type":
                                obj.get("type"),

                            # ----------------------------------
                            # TRADE DATA
                            # ----------------------------------

                            "ltp":
                                float(obj.get("LTP") or 0),

                            "ltq":
                                int(obj.get("LTQ") or 0),

                            "ltt":
                                obj.get("LTT"),

                            # ----------------------------------
                            # MARKET DATA
                            # ----------------------------------

                            "open":
                                float(obj.get("open") or 0),

                            "high":
                                float(obj.get("high") or 0),

                            "low":
                                float(obj.get("low") or 0),

                            "close":
                                float(obj.get("close") or 0),

                            "avg_price":
                                float(obj.get("avg_price") or 0),

                            # ----------------------------------
                            # VOLUME DATA
                            # ----------------------------------

                            "volume":
                                int(obj.get("volume") or 0),

                            "total_buy_quantity":
                                int(
                                    obj.get(
                                        "total_buy_quantity"
                                    ) or 0
                                ),

                            "total_sell_quantity":
                                int(
                                    obj.get(
                                        "total_sell_quantity"
                                    ) or 0
                                ),

                            # ----------------------------------
                            # TIMESTAMP
                            # ----------------------------------

                            "updated_at":
                                obj.get("LTT"),
                        }

                    except Exception as e:

                        logger.exception(
                            f"{symbol} message parse failed : "
                            f"{str(e)}"
                        )

        except Exception as e:

            logger.exception(
                f"{symbol} websocket failed : "
                f"{str(e)}"
            )

            logger.info(
                f"Reconnecting option socket "
                f"{symbol} in 5 seconds..."
            )

            await asyncio.sleep(5)

# ==========================================================
# START OPTION SOCKET
# ==========================================================

def start_option_listener(
    security_id: int,
    symbol: str
):

    try:

        # ==============================================
        # AVOID DUPLICATE SOCKETS
        # ==============================================

        existing_task = ACTIVE_OPTION_TASKS.get(
            security_id
        )

        if existing_task:

            if not existing_task.done():

                logger.info(
                    f"Option socket already active : "
                    f"{symbol}"
                )

                return

        # ==============================================
        # CREATE NEW TASK
        # ==============================================

        task = asyncio.create_task(
            listen_option_feed(
                security_id,
                symbol
            ),
            name=f"option-{symbol}"
        )

        ACTIVE_OPTION_TASKS[
            security_id
        ] = task

        logger.info(
            f"Option websocket task started : "
            f"{symbol}"
        )

    except Exception as e:

        logger.exception(
            f"Failed starting option socket "
            f"{symbol} : {str(e)}"
        )

# ==========================================================
# STOP OPTION SOCKET
# ==========================================================

async def stop_option_listener(
    security_id: int
):

    try:

        task = ACTIVE_OPTION_TASKS.get(
            security_id
        )

        if not task:

            return

        task.cancel()

        try:

            await task

        except asyncio.CancelledError:

            pass

        ACTIVE_OPTION_TASKS.pop(
            security_id,
            None
        )

        OPTION_LIVE_CACHE.pop(
            security_id,
            None
        )

        logger.info(
            f"Option socket stopped "
            f"security_id={security_id}"
        )

    except Exception as e:

        logger.exception(
            f"Failed stopping option socket : "
            f"{str(e)}"
        )