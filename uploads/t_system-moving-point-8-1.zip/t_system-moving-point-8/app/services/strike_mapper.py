from app.logger import logger

from app.services.security_lookup import (
    get_security_id
)


def build_security_mapping(
    index_security_id: int,
    parsed: dict
):

    try:

        logger.info(
            f"Strike mapping started "
            f"for index_security_id="
            f"{index_security_id}"
        )

        mapping = {}

        for label, strike in parsed.items():

            try:

                logger.info(
                    f"Processing {label} "
                    f"strike={strike}"
                )

                ce_security_id = (
                    get_security_id(
                        index_security_id,
                        strike,
                        "CE"
                    )
                )

                pe_security_id = (
                    get_security_id(
                        index_security_id,
                        strike,
                        "PE"
                    )
                )

                mapping[label] = {

                    "strike":
                        strike,

                    "ce_security_id":
                        ce_security_id,

                    "pe_security_id":
                        pe_security_id
                }

                logger.info(
                    f"{label} mapped successfully. "
                    f"CE={ce_security_id}, "
                    f"PE={pe_security_id}"
                )

            except Exception as e:

                logger.exception(
                    f"Failed mapping "
                    f"{label} strike={strike} : "
                    f"{str(e)}"
                )

                mapping[label] = {

                    "strike":
                        strike,

                    "ce_security_id":
                        None,

                    "pe_security_id":
                        None,

                    "error":
                        str(e)
                }

        logger.info(
            f"Strike mapping completed. "
            f"Total mapped={len(mapping)}"
        )

        return mapping

    except Exception as e:

        logger.exception(
            f"Strike mapping failed : "
            f"{str(e)}"
        )

        raise

    finally:

        logger.info(
            "Strike mapping finished"
        )