import requests

from app.logger import logger
from app.config import settings


def subscribe_option_marketfeed(trace_id: str, security_mapping: dict):

    try:

        logger.info(f"[{trace_id}] Option subscription started")

        instruments = []

        added = set()

        for level_name, level_data in security_mapping.items():

            ce_security_id = level_data.get("ce_security_id")

            pe_security_id = level_data.get("pe_security_id")

            if ce_security_id and ce_security_id not in added:

                instruments.append(
                    {
                        "segment": settings.OPTION_EXCHANGE_SEGMENT,
                        "security_id": str(ce_security_id),
                        "type": "Quote",
                    }
                )

                added.add(ce_security_id)

            if pe_security_id and pe_security_id not in added:

                instruments.append(
                    {
                        "segment": settings.OPTION_EXCHANGE_SEGMENT,
                        "security_id": str(pe_security_id),
                        "type": "Quote",
                    }
                )

                added.add(pe_security_id)

        if not instruments:

            logger.warning(f"[{trace_id}] No instruments found for subscription")

            return {"success": False, "message": "No instruments"}

        url = f"{settings.BASE_URL}/marketfeed/subscribe/"

        payload = {"instruments": instruments}

        logger.info(f"[{trace_id}] Calling subscription API")

        response = requests.post(url, json=payload, timeout=settings.REQUEST_TIMEOUT)

        logger.info(
            f"[{trace_id}] Subscription response " f"status={response.status_code}"
        )

        response.raise_for_status()

        return {"success": True, "count": len(instruments), "response": response.json()}

    except Exception as e:

        logger.exception(f"[{trace_id}] Option subscription failed : {str(e)}")

        return {"success": False, "error": str(e)}

    finally:

        logger.info(f"[{trace_id}] Option subscription finished")
