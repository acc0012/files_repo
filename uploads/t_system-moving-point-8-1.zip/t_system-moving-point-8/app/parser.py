import math

from app.logger import logger


def round_support(value):

    return math.ceil(float(value) / 50) * 50


def round_resistance(value):

    return math.floor(float(value) / 50) * 50


def parse_levels(trace_id: str, data: dict):

    try:

        logger.info(f"[{trace_id}] Level parsing started")

        required_fields = [
            "HIGH",
            "LOW",
            "AVG",
            "RESISTANCE2",
            "SUPPORT2",
            "RESISTANCE3",
            "SUPPORT3",
        ]

        missing = [field for field in required_fields if field not in data]

        if missing:

            logger.error(f"[{trace_id}] Missing fields : {missing}")

            raise ValueError(f"Missing fields: {', '.join(missing)}")

        high = float(data["HIGH"])

        low = float(data["LOW"])

        avg = float(data["AVG"])

        r2 = float(data["RESISTANCE2"])

        s2 = float(data["SUPPORT2"])

        r3 = float(data["RESISTANCE3"])

        s3 = float(data["SUPPORT3"])

        parsed = {
            "HIGH_STRIKE": round_resistance(high),
            "LOW_STRIKE": round_support(low),
            "AVG_UP_STRIKE": round_support(avg),
            "AVG_DOWN_STRIKE": round_resistance(avg),
            "R2_STRIKE": round_resistance(r2),
            "S2_STRIKE": round_support(s2),
            "R3_STRIKE": round_resistance(r3),
            "S3_STRIKE": round_support(s3),
        }

        logger.info(f"[{trace_id}] Level parsing completed successfully")

        return parsed

    except ValueError as e:

        logger.error(f"[{trace_id}] Validation failed : {str(e)}")

        raise

    except Exception as e:

        logger.exception(f"[{trace_id}] Level parsing failed : {str(e)}")

        raise

    finally:

        logger.info(f"[{trace_id}] Level parsing finished")
