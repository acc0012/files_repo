@echo off
setlocal

REM ================================================================
REM TCS Proxy Health Check Launcher
REM ------------------------------------------------
REM Purpose:
REM   - User double-clicks this BAT file
REM   - It runs Check_TCS_Proxy.ps1 one time
REM   - PowerShell window/CMD window opens
REM   - Network detection and proxy enable/disable action happens
REM   - PowerShell script writes logs to logs\proxy_health_check.log
REM ================================================================

title TCS Proxy Health Check

REM Use the folder where this BAT file is located.
set "SCRIPT_DIR=%~dp0"
set "PS_SCRIPT=%SCRIPT_DIR%Check_TCS_Proxy.ps1"
set "LOG_DIR=%SCRIPT_DIR%logs"

cd /d "%SCRIPT_DIR%"

echo ================================================================
echo TCS Proxy Health Check
echo ================================================================
echo.
echo Project folder:
echo %SCRIPT_DIR%
echo.

REM Create logs folder if missing.
if not exist "%LOG_DIR%" (
    mkdir "%LOG_DIR%"
)

REM Check whether PowerShell is available.
where powershell.exe >nul 2>&1
if errorlevel 1 (
    echo ERROR: PowerShell is not available on this system.
    echo.
    echo Please contact support.
    echo.
    pause
    exit /b 1
)

REM Check whether the PowerShell script exists.
if not exist "%PS_SCRIPT%" (
    echo ERROR: Required PowerShell script not found.
    echo.
    echo Missing file:
    echo %PS_SCRIPT%
    echo.
    echo Please make sure Check_TCS_Proxy.ps1 is in the same folder as this BAT file.
    echo.
    pause
    exit /b 1
)

echo Starting TCS Proxy Health Check...
echo.
echo Please wait while network and proxy status are checked.
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS_SCRIPT%"

set "EXIT_CODE=%ERRORLEVEL%"

echo.
echo ================================================================
echo TCS Proxy Health Check finished.
echo ================================================================
echo.

if not "%EXIT_CODE%"=="0" (
    echo WARNING: Script completed with exit code %EXIT_CODE%.
    echo.
    echo Please check the log file:
    echo %LOG_DIR%\proxy_health_check.log
    echo.
    pause
    exit /b %EXIT_CODE%
)

echo Log file:
echo %LOG_DIR%\proxy_health_check.log
echo.

endlocal
exit /b 0