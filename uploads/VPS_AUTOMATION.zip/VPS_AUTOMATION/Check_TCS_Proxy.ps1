# ================================================================
# TCS Proxy Health Check - One Time Mode
# ================================================================
# - Runs only when user double-clicks Run_Check_TCS_Proxy.bat
# - Detects primary active network
# - Enables proxy on Organisation network
# - Disables proxy on Personal/Other network
# - Writes log file with only latest 1000 lines
# ================================================================

$ErrorActionPreference = "Continue"

# ================================================================
# Paths and Logging
# ================================================================

$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

if ([string]::IsNullOrWhiteSpace($ScriptRoot)) {
    $ScriptRoot = Get-Location
}

$LogDir = Join-Path $ScriptRoot "logs"
$LogFile = Join-Path $LogDir "proxy_health_check.log"
$MaxLogLines = 1000

if (-not (Test-Path $LogDir)) {
    New-Item -Path $LogDir -ItemType Directory -Force | Out-Null
}

function Trim-LogFile {
    try {
        if (Test-Path $LogFile) {
            $lines = Get-Content -Path $LogFile -ErrorAction SilentlyContinue

            if ($null -ne $lines -and $lines.Count -gt $MaxLogLines) {
                $lastLines = $lines | Select-Object -Last $MaxLogLines
                Set-Content -Path $LogFile -Value $lastLines -Encoding UTF8
            }
        }
    }
    catch {
        # Ignore log trim failure.
    }
}

function Write-Log {
    param(
        [string]$Level = "INFO",
        [string]$Message
    )

    try {
        $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        $line = "$timestamp | $Level | $Message"
        Add-Content -Path $LogFile -Value $line -Encoding UTF8
        Trim-LogFile
    }
    catch {
        # Ignore logging failure.
    }
}

# ================================================================
# Configuration
# ================================================================

$OrganisationSSIDs = @(
    '!dw$_Tb_o@&',
    'C0rpW!5!@Of!(3'
)

$OrganisationLanSubnets = @(
    "172.20.48.0/20",
    "172.20.144.0/22",
    "10.23.4.0/22",
    "10.23.150.0/23",
    "10.146.144.0/23",
    "172.20.138.0/24"
)

$OrganisationDnsSuffixes = @(
    "india.tcs.com",
    "tcs.com"
)

$TcsProxyServer = "proxy.tcs.com:8080"

$DefaultProxyExceptions = "172.*;*.ultimatix.*;*INM*.TCS.COM;*IND*.TCS.COM;*INC*.TCS.COM;*INH*.TCS.COM;*INB*.TCS.COM;*INK*.tcs.com;buzz.tcs.com;voip.tcs.com;*.eurja*;*supportcentral.tcs.com;news.tcs.com;sg*.tcs.com;us*.tcs.com;uk*.tcs.com;*recruitment*;*careers*;157.*;sps*;ftc*;tw.tcs.com;edge.tcs.com;inchnveloa.tcs.com;*.india.tcs.com;ideastorm.tcs.com;securityportal.tcs.com;isisd.tcs.com;meeting.tcs.com;*video.tcs.com;mscommunityportal.tcs.com;search.tdcustagweb.tcs.com;Web2labs.tcs.com;academia.tcs.com;photo.tcs.com;*tcs-helpdesk*;ilpcms.tcs.com;campustaprocess.tcs.com;*tcsbas.tcsbpo*;globalmeet.tcs.com;bpoonline.tcs.com;*hrservicesonline.com*;*customersurvey.tcs.com*;mstream*;vstream.tcs.com;tcsmapagile.tcs.com;custportaluat.tcs.*;nextstep.tcs.com;knowfs.tcs.com;conference.tcs.com;*finterestgroup.com;customerportal.tcs.*;*alumniportal.tcs.com*;outlook.tcs.com;mail.tcs.com;Autodiscover.tcs.com;inmumexc01.tcs.com;inmumexc02.tcs.com;inmumzm01.tcs.com;inmumzm02.tcs.com;ecd.tcs.com;cas.tcs.com;gbamsuat.tcs.com;gbams.tcs.com;vmsprocurement.tcs.com;vms.tcs.com;boduat.tcs.com;*.BPO.TCS.COM*;i-asuhplabvm18.tcsasuhplab.com;avchat.tcs.com;meetingav.tcs.com;conference1.tcs.com;colosseum.tcs.com;lifeline.tcs.com;fit4life.tcs.com;tqas.tcs.com;irm.tcs.com;irmdr.tcs.com;dominoconnect.tcs.com;isprojects.tcs.com;secureerase.tcs.com;webmail.tcs.com;vlabsmumbai.tcs.com;is-connect.tcs.com;bodapp.tcs.com;bod.tcs.com;tob.boadapp.tcs.com;grodev.tcs.com;IS-Backup.tcs.com;*.itfrontier.co.jp;vlabschennai.tcs.com;mchat.tcs.com;10.*;*.tcsion.com;*.digialm.com;*.workspace.tcs.com;events.tcs.com;eventsdemo.tcs.com;bmsportal.tcs.com;optselfservice.tcs.com;meghaas-access.tcs.com;eventsuat.tcs.com;*.tcsionhub.in;*.tcsionhub.uk;163.122.229.*;*cloudvistara*;securepam.tcs.com;*.tcsgsp.in;*.Fresco.me;excellence.tcs.com;*hcp.*;cto-cybersecurityresearch.tcs.com*;occasions.tcs.com;*.iur.ls;*.cloudnext.tcs.com;*.fs.tcs.com;otpselfservice.tcs.com;*.tcsghdpcce.*;*.mdm.tcs.com;cdct2fa1.india.tcs.com;"

$ProxyRegPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings"

# ================================================================
# Popup Functions
# ================================================================

function Show-Info {
    param(
        [string]$Message,
        [string]$Title = "TCS Proxy Health Check"
    )

    try {
        Add-Type -AssemblyName PresentationFramework -ErrorAction SilentlyContinue
        [System.Windows.MessageBox]::Show(
            $Message,
            $Title,
            [System.Windows.MessageBoxButton]::OK,
            [System.Windows.MessageBoxImage]::Information
        ) | Out-Null

        Write-Log "INFO" "Info popup shown. Title=$Title"
    }
    catch {
        Write-Log "WARNING" "Unable to show info popup. Error=$($_.Exception.Message)"
        Write-Host $Title
        Write-Host $Message
    }
}

function Show-Warning {
    param(
        [string]$Message,
        [string]$Title = "TCS Proxy Health Check"
    )

    try {
        Add-Type -AssemblyName PresentationFramework -ErrorAction SilentlyContinue
        [System.Windows.MessageBox]::Show(
            $Message,
            $Title,
            [System.Windows.MessageBoxButton]::OK,
            [System.Windows.MessageBoxImage]::Warning
        ) | Out-Null

        Write-Log "INFO" "Warning popup shown. Title=$Title"
    }
    catch {
        Write-Log "WARNING" "Unable to show warning popup. Error=$($_.Exception.Message)"
        Write-Host $Title
        Write-Host $Message
    }
}

# ================================================================
# IP and Subnet Functions
# ================================================================

function ConvertTo-UInt32Ip {
    param(
        [string]$IpAddress
    )

    $bytes = [System.Net.IPAddress]::Parse($IpAddress).GetAddressBytes()

    return (
        ([uint32]$bytes[0] -shl 24) -bor
        ([uint32]$bytes[1] -shl 16) -bor
        ([uint32]$bytes[2] -shl 8) -bor
        ([uint32]$bytes[3])
    )
}

function Test-IpInSubnet {
    param(
        [string]$IpAddress,
        [string]$Cidr
    )

    try {
        if ([string]::IsNullOrWhiteSpace($IpAddress)) {
            return $false
        }

        if ([string]::IsNullOrWhiteSpace($Cidr)) {
            return $false
        }

        $parts = $Cidr.Split("/")

        if ($parts.Count -ne 2) {
            return $false
        }

        $networkIp = $parts[0]
        $prefixLength = [int]$parts[1]

        if ($prefixLength -lt 0 -or $prefixLength -gt 32) {
            return $false
        }

        $ipInt = ConvertTo-UInt32Ip -IpAddress $IpAddress
        $networkInt = ConvertTo-UInt32Ip -IpAddress $networkIp

        if ($prefixLength -eq 0) {
            $mask = [uint32]0
        }
        else {
            $mask = ([uint64]0xffffffff -shl (32 - $prefixLength) -band [uint64]0xffffffff)
        }

        return (($ipInt -band $mask) -eq ($networkInt -band $mask))
    }
    catch {
        Write-Log "WARNING" "Subnet check failed. IP=$IpAddress | CIDR=$Cidr | Error=$($_.Exception.Message)"
        return $false
    }
}

function Test-OrganisationSubnet {
    param(
        [string]$IpAddress
    )

    if ([string]::IsNullOrWhiteSpace($IpAddress)) {
        Write-Log "INFO" "Organisation subnet check skipped because IP address is empty."
        return $false
    }

    foreach ($subnet in $OrganisationLanSubnets) {
        if (Test-IpInSubnet -IpAddress $IpAddress -Cidr $subnet) {
            Write-Log "INFO" "Organisation subnet matched. IP=$IpAddress | Subnet=$subnet"
            return $true
        }
    }

    Write-Log "INFO" "Organisation subnet did not match. IP=$IpAddress"
    return $false
}

function Test-OrganisationDnsSuffix {
    param(
        [string]$DnsSuffix
    )

    if ([string]::IsNullOrWhiteSpace($DnsSuffix)) {
        Write-Log "INFO" "DNS suffix is empty. Organisation DNS suffix check skipped."
        return $false
    }

    $current = $DnsSuffix.Trim().ToLower()

    foreach ($suffix in $OrganisationDnsSuffixes) {
        $expected = $suffix.Trim().ToLower()

        if ($current -eq $expected -or $current.EndsWith("." + $expected)) {
            Write-Log "INFO" "Organisation DNS suffix matched. Current=$DnsSuffix | Expected=$suffix"
            return $true
        }
    }

    Write-Log "INFO" "Organisation DNS suffix did not match. Current=$DnsSuffix"
    return $false
}

# ================================================================
# Wi-Fi Functions
# ================================================================

function Get-CurrentWifiSSID {
    try {
        $output = netsh wlan show interfaces 2>$null

        foreach ($line in $output) {
            $trimmed = $line.Trim()
            $lower = $trimmed.ToLower()

            if ($lower.StartsWith("ssid") -and -not $lower.StartsWith("bssid")) {
                $parts = $trimmed -split ":", 2

                if ($parts.Count -eq 2) {
                    $ssid = $parts[1].Trim()

                    if (-not [string]::IsNullOrWhiteSpace($ssid)) {
                        Write-Log "INFO" "Current Wi-Fi SSID detected. SSID=$ssid"
                        return $ssid
                    }
                }
            }
        }

        Write-Log "WARNING" "No connected Wi-Fi SSID found in netsh output."
        return ""
    }
    catch {
        Write-Log "WARNING" "Failed to detect Wi-Fi SSID. Error=$($_.Exception.Message)"
        return ""
    }
}

function Test-OrganisationSSID {
    param(
        [string]$SSID
    )

    if ([string]::IsNullOrWhiteSpace($SSID)) {
        return $false
    }

    $current = $SSID.Trim().ToLower()

    foreach ($orgSsid in $OrganisationSSIDs) {
        if ($current -eq $orgSsid.Trim().ToLower()) {
            Write-Log "INFO" "Organisation SSID matched. SSID=$SSID"
            return $true
        }
    }

    Write-Log "INFO" "Organisation SSID did not match. SSID=$SSID"
    return $false
}

# ================================================================
# Network Detection
# ================================================================

function Get-PrimaryNetwork {
    Write-Log "INFO" "Primary active network detection started."

    try {
        $routes = Get-NetRoute -DestinationPrefix "0.0.0.0/0" -AddressFamily IPv4 -ErrorAction SilentlyContinue |
            Where-Object {
                $_.NextHop -ne "0.0.0.0" -and
                $_.NextHop -ne "" -and
                $_.State -eq "Alive"
            }

        $validRoutes = foreach ($route in $routes) {
            $adapter = Get-NetAdapter -InterfaceIndex $route.InterfaceIndex -ErrorAction SilentlyContinue
            $config = Get-NetIPConfiguration -InterfaceIndex $route.InterfaceIndex -ErrorAction SilentlyContinue

            if ($null -eq $adapter -or $null -eq $config) {
                continue
            }

            $ipv4Address = ""
            $gateway = ""
            $mediaState = "Unknown"

            if ($null -ne $config.IPv4Address) {
                $ipv4Address = (@($config.IPv4Address) | Select-Object -First 1).IPAddress
            }

            if ($null -ne $config.IPv4DefaultGateway) {
                $gateway = (@($config.IPv4DefaultGateway) | Select-Object -First 1).NextHop
            }

            if ($adapter.PSObject.Properties.Name -contains "MediaConnectionState") {
                $mediaState = [string]$adapter.MediaConnectionState
            }

            if (
                $adapter.Status -eq "Up" -and
                ($mediaState -eq "Connected" -or $mediaState -eq "Unknown") -and
                -not [string]::IsNullOrWhiteSpace($ipv4Address) -and
                -not [string]::IsNullOrWhiteSpace($gateway)
            ) {
                [PSCustomObject]@{
                    InterfaceIndex = $route.InterfaceIndex
                    InterfaceAlias = $route.InterfaceAlias
                    NextHop = $route.NextHop
                    RouteMetric = $route.RouteMetric
                    InterfaceMetric = $route.InterfaceMetric
                    TotalMetric = $route.RouteMetric + $route.InterfaceMetric
                }
            }
        }

        $primary = $validRoutes |
            Sort-Object TotalMetric, RouteMetric, InterfaceMetric |
            Select-Object -First 1

        if ($null -eq $primary) {
            Write-Log "WARNING" "No connected primary IPv4 default route detected."

            return [PSCustomObject]@{
                DisplayName = "Not Connected"
                ConnectionType = "None"
                IsOrganisation = $false
                IpAddress = ""
                InterfaceAlias = ""
                Gateway = ""
                Reason = "No connected IPv4 default route detected."
            }
        }

        $details = Get-NetIPConfiguration -InterfaceIndex $primary.InterfaceIndex -ErrorAction SilentlyContinue
        $adapter = Get-NetAdapter -InterfaceIndex $primary.InterfaceIndex -ErrorAction SilentlyContinue

        if ($null -eq $details -or $null -eq $adapter) {
            Write-Log "WARNING" "Primary interface details unavailable. InterfaceIndex=$($primary.InterfaceIndex)"

            return [PSCustomObject]@{
                DisplayName = "Not Connected"
                ConnectionType = "None"
                IsOrganisation = $false
                IpAddress = ""
                InterfaceAlias = $primary.InterfaceAlias
                Gateway = $primary.NextHop
                Reason = "Primary route detected but interface details were unavailable."
            }
        }

        $interfaceAlias = [string]$details.InterfaceAlias
        $interfaceDescription = [string]$details.InterfaceDescription
        $ipAddress = ""
        $gateway = ""
        $dnsSuffix = ""

        if ($null -ne $details.IPv4Address) {
            $ipAddress = (@($details.IPv4Address) | Select-Object -First 1).IPAddress
        }

        if ($null -ne $details.IPv4DefaultGateway) {
            $gateway = (@($details.IPv4DefaultGateway) | Select-Object -First 1).NextHop
        }

        if ($details.PSObject.Properties.Name -contains "DNSSuffix") {
            $dnsSuffix = [string]$details.DNSSuffix
        }

        $adapterStatus = [string]$adapter.Status
        $mediaState = "Unknown"

        if ($adapter.PSObject.Properties.Name -contains "MediaConnectionState") {
            $mediaState = [string]$adapter.MediaConnectionState
        }

        if ($adapterStatus -ne "Up" -or ($mediaState -ne "Connected" -and $mediaState -ne "Unknown")) {
            Write-Log "WARNING" "Primary adapter is not connected. Alias=$interfaceAlias | Status=$adapterStatus | MediaState=$mediaState"

            return [PSCustomObject]@{
                DisplayName = "Not Connected"
                ConnectionType = "None"
                IsOrganisation = $false
                IpAddress = ""
                InterfaceAlias = $interfaceAlias
                Gateway = $gateway
                Reason = "Primary adapter is not connected."
            }
        }

        if ([string]::IsNullOrWhiteSpace($ipAddress)) {
            Write-Log "WARNING" "Primary interface has no IPv4 address. Alias=$interfaceAlias"

            return [PSCustomObject]@{
                DisplayName = "Not Connected"
                ConnectionType = "None"
                IsOrganisation = $false
                IpAddress = ""
                InterfaceAlias = $interfaceAlias
                Gateway = $gateway
                Reason = "Primary interface has no IPv4 address."
            }
        }

        $aliasLower = $interfaceAlias.Trim().ToLower()
        $descriptionLower = $interfaceDescription.Trim().ToLower()

        $isWifi = (
            $aliasLower.Contains("wi-fi") -or
            $aliasLower.Contains("wifi") -or
            $aliasLower.Contains("wireless") -or
            $aliasLower.Contains("wlan") -or
            $descriptionLower.Contains("wi-fi") -or
            $descriptionLower.Contains("wifi") -or
            $descriptionLower.Contains("wireless") -or
            $descriptionLower.Contains("wlan") -or
            $descriptionLower.Contains("802.11")
        )

        $isLan = (
            $aliasLower.Contains("ethernet") -or
            $aliasLower.Contains("lan") -or
            $descriptionLower.Contains("ethernet") -or
            $descriptionLower.Contains("realtek") -or
            $descriptionLower.Contains("intel") -or
            $descriptionLower.Contains("usb ethernet") -or
            $descriptionLower.Contains("docking")
        )

        $isIgnoredAdapter = (
            $aliasLower.Contains("zscaler") -or
            $aliasLower.Contains("vpn") -or
            $aliasLower.Contains("virtual") -or
            $aliasLower.Contains("hyper-v") -or
            $aliasLower.Contains("vmware") -or
            $aliasLower.Contains("virtualbox") -or
            $aliasLower.Contains("loopback") -or
            $aliasLower.Contains("bluetooth") -or
            $aliasLower.Contains("wi-fi direct") -or
            $aliasLower.Contains("wsl") -or
            $aliasLower.Contains("teredo") -or
            $aliasLower.Contains("pseudo") -or
            $aliasLower.Contains("tap") -or
            $aliasLower.Contains("tunnel") -or
            $descriptionLower.Contains("zscaler") -or
            $descriptionLower.Contains("vpn") -or
            $descriptionLower.Contains("virtual") -or
            $descriptionLower.Contains("hyper-v") -or
            $descriptionLower.Contains("vmware") -or
            $descriptionLower.Contains("virtualbox") -or
            $descriptionLower.Contains("loopback") -or
            $descriptionLower.Contains("bluetooth") -or
            $descriptionLower.Contains("wi-fi direct") -or
            $descriptionLower.Contains("wsl") -or
            $descriptionLower.Contains("teredo") -or
            $descriptionLower.Contains("pseudo") -or
            $descriptionLower.Contains("tap") -or
            $descriptionLower.Contains("tunnel")
        )

        $subnetMatch = Test-OrganisationSubnet -IpAddress $ipAddress
        $dnsMatch = Test-OrganisationDnsSuffix -DnsSuffix $dnsSuffix

        Write-Log "INFO" "Primary interface detected. Alias=$interfaceAlias | Description=$interfaceDescription | IP=$ipAddress | Gateway=$gateway | DNSSuffix=$dnsSuffix | IsWiFi=$isWifi | IsLAN=$isLan | IsIgnored=$isIgnoredAdapter"

        if ($isWifi) {
            $ssid = Get-CurrentWifiSSID
            $ssidMatch = Test-OrganisationSSID -SSID $ssid

            if ($ssidMatch -or $subnetMatch -or $dnsMatch) {
                Write-Log "INFO" "Primary network classified as Organisation Wi-Fi. SSID=$ssid | IP=$ipAddress"

                return [PSCustomObject]@{
                    DisplayName = $ssid
                    ConnectionType = "WiFi"
                    IsOrganisation = $true
                    IpAddress = $ipAddress
                    InterfaceAlias = $interfaceAlias
                    Gateway = $gateway
                    Reason = "Primary Wi-Fi matched Organisation SSID, subnet, or DNS suffix."
                }
            }

            if ([string]::IsNullOrWhiteSpace($ssid)) {
                $ssid = "Personal Wi-Fi"
            }

            Write-Log "INFO" "Primary network classified as Personal/Other Wi-Fi. SSID=$ssid | IP=$ipAddress"

            return [PSCustomObject]@{
                DisplayName = $ssid
                ConnectionType = "WiFi"
                IsOrganisation = $false
                IpAddress = $ipAddress
                InterfaceAlias = $interfaceAlias
                Gateway = $gateway
                Reason = "Primary Wi-Fi did not match Organisation SSID, subnet, or DNS suffix."
            }
        }

        if ($isIgnoredAdapter) {
            Write-Log "INFO" "Primary adapter is ignored virtual/VPN/tunnel adapter. Alias=$interfaceAlias | IP=$ipAddress"

            return [PSCustomObject]@{
                DisplayName = "Personal Network"
                ConnectionType = "Unknown"
                IsOrganisation = $false
                IpAddress = $ipAddress
                InterfaceAlias = $interfaceAlias
                Gateway = $gateway
                Reason = "Primary adapter is virtual/VPN/tunnel and is not treated as Organisation LAN."
            }
        }

        if ($isLan) {
            if ($subnetMatch -or $dnsMatch) {
                Write-Log "INFO" "Primary network classified as Organisation LAN. IP=$ipAddress | SubnetMatch=$subnetMatch | DnsMatch=$dnsMatch"

                return [PSCustomObject]@{
                    DisplayName = "Organisation LAN"
                    ConnectionType = "LAN"
                    IsOrganisation = $true
                    IpAddress = $ipAddress
                    InterfaceAlias = $interfaceAlias
                    Gateway = $gateway
                    Reason = "Primary LAN matched Organisation subnet or DNS suffix."
                }
            }

            Write-Log "INFO" "Primary network classified as Personal/Other LAN. IP=$ipAddress"

            return [PSCustomObject]@{
                DisplayName = "Personal LAN"
                ConnectionType = "LAN"
                IsOrganisation = $false
                IpAddress = $ipAddress
                InterfaceAlias = $interfaceAlias
                Gateway = $gateway
                Reason = "Primary LAN did not match Organisation subnet or DNS suffix."
            }
        }

        if ($subnetMatch -or $dnsMatch) {
            Write-Log "INFO" "Primary network classified as Organisation Network by IP/DNS. IP=$ipAddress"

            return [PSCustomObject]@{
                DisplayName = "Organisation Network"
                ConnectionType = "Unknown"
                IsOrganisation = $true
                IpAddress = $ipAddress
                InterfaceAlias = $interfaceAlias
                Gateway = $gateway
                Reason = "Primary unknown adapter matched Organisation subnet or DNS suffix."
            }
        }

        Write-Log "INFO" "Primary network classified as Personal/Other Network. Alias=$interfaceAlias | IP=$ipAddress"

        return [PSCustomObject]@{
            DisplayName = "Personal Network"
            ConnectionType = "Unknown"
            IsOrganisation = $false
            IpAddress = $ipAddress
            InterfaceAlias = $interfaceAlias
            Gateway = $gateway
            Reason = "Primary adapter did not match Organisation Wi-Fi, subnet, or DNS suffix."
        }
    }
    catch {
        Write-Log "ERROR" "Primary network detection failed. Error=$($_.Exception.Message)"

        return [PSCustomObject]@{
            DisplayName = "Not Connected"
            ConnectionType = "None"
            IsOrganisation = $false
            IpAddress = ""
            InterfaceAlias = ""
            Gateway = ""
            Reason = "Network detection failed."
        }
    }
}

# ================================================================
# Proxy Functions
# ================================================================

function Get-ProxyStatus {
    $proxyEnable = 0
    $proxyServer = ""
    $proxyOverride = ""

    try {
        $props = Get-ItemProperty -Path $ProxyRegPath -ErrorAction SilentlyContinue

        if ($null -ne $props.ProxyEnable) {
            $proxyEnable = [int]$props.ProxyEnable
        }

        if ($null -ne $props.ProxyServer) {
            $proxyServer = [string]$props.ProxyServer
        }

        if ($null -ne $props.ProxyOverride) {
            $proxyOverride = [string]$props.ProxyOverride
        }
    }
    catch {
        Write-Log "WARNING" "Unable to read proxy registry. Error=$($_.Exception.Message)"
    }

    Write-Log "INFO" "Current proxy status detected. Enabled=$proxyEnable | Server=$proxyServer | ExceptionsLength=$($proxyOverride.Length)"

    return [PSCustomObject]@{
        Enabled = $proxyEnable
        Server = $proxyServer
        Exceptions = $proxyOverride
    }
}

function Notify-ProxyChanged {
    $signature = @"
using System;
using System.Runtime.InteropServices;

public class WinInetNotify {
    [DllImport("wininet.dll", SetLastError=true)]
    public static extern bool InternetSetOption(IntPtr hInternet, int dwOption, IntPtr lpBuffer, int dwBufferLength);
}
"@

    try {
        Add-Type -TypeDefinition $signature -ErrorAction SilentlyContinue

        [WinInetNotify]::InternetSetOption([IntPtr]::Zero, 39, [IntPtr]::Zero, 0) | Out-Null
        [WinInetNotify]::InternetSetOption([IntPtr]::Zero, 37, [IntPtr]::Zero, 0) | Out-Null

        Write-Log "INFO" "Windows proxy refresh notification completed."
    }
    catch {
        Write-Log "WARNING" "Windows proxy refresh notification failed. Error=$($_.Exception.Message)"
    }
}

function Enable-TcsProxy {
    Write-Log "INFO" "Proxy action started: enable TCS proxy."

    try {
        if (-not (Test-Path $ProxyRegPath)) {
            New-Item -Path $ProxyRegPath -Force | Out-Null
        }

        Set-ItemProperty -Path $ProxyRegPath -Name ProxyEnable -Type DWord -Value 1
        Set-ItemProperty -Path $ProxyRegPath -Name ProxyServer -Type String -Value $TcsProxyServer
        Set-ItemProperty -Path $ProxyRegPath -Name ProxyOverride -Type String -Value $DefaultProxyExceptions

        Notify-ProxyChanged

        Write-Log "INFO" "Proxy action completed: TCS proxy enabled successfully. Server=$TcsProxyServer"
    }
    catch {
        Write-Log "ERROR" "Proxy action failed: unable to enable TCS proxy. Error=$($_.Exception.Message)"
        throw
    }
}

function Disable-TcsProxy {
    Write-Log "INFO" "Proxy action started: disable proxy."

    try {
        if (-not (Test-Path $ProxyRegPath)) {
            New-Item -Path $ProxyRegPath -Force | Out-Null
        }

        Set-ItemProperty -Path $ProxyRegPath -Name ProxyEnable -Type DWord -Value 0

        Notify-ProxyChanged

        Write-Log "INFO" "Proxy action completed: proxy disabled successfully."
    }
    catch {
        Write-Log "ERROR" "Proxy action failed: unable to disable proxy. Error=$($_.Exception.Message)"
        throw
    }
}

# ================================================================
# Message Helper
# ================================================================

function Get-ConnectedNetworkText {
    param(
        $Network
    )

    if ($Network.DisplayName -eq "Not Connected") {
        return "Connected Network : Not Connected"
    }

    if ($Network.ConnectionType -eq "WiFi") {
        return @"
Connected SSID   : $($Network.DisplayName)
Connection Type  : $($Network.ConnectionType)
IP Address       : $($Network.IpAddress)
Interface        : $($Network.InterfaceAlias)
Gateway          : $($Network.Gateway)
"@
    }

    return @"
Connected Network : $($Network.DisplayName)
Connection Type   : $($Network.ConnectionType)
IP Address        : $($Network.IpAddress)
Interface         : $($Network.InterfaceAlias)
Gateway           : $($Network.Gateway)
"@
}

# ================================================================
# Main Execution
# ================================================================

try {
    Clear-Host

    Write-Log "INFO" "============================================================"
    Write-Log "INFO" "TCS Proxy Health Check started. Mode=OneTime"

    Write-Host "============================================================"
    Write-Host "TCS Proxy Health Check"
    Write-Host "One-time detection mode"
    Write-Host "============================================================"
    Write-Host ""

    $network = Get-PrimaryNetwork
    $proxy = Get-ProxyStatus

    $proxyStatusText = if ($proxy.Enabled -eq 1) { "Enabled" } else { "Disabled" }
    $networkTypeText = if ($network.IsOrganisation) { "Organisation" } else { "Personal / Other" }

    Write-Host "Detection Time : $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
    Write-Host "Network Name   : $($network.DisplayName)"
    Write-Host "Network Type   : $networkTypeText"
    Write-Host "Connection     : $($network.ConnectionType)"
    Write-Host "IP Address     : $($network.IpAddress)"
    Write-Host "Interface      : $($network.InterfaceAlias)"
    Write-Host "Gateway        : $($network.Gateway)"
    Write-Host "Reason         : $($network.Reason)"
    Write-Host ""
    Write-Host "Proxy Status   : $proxyStatusText"
    Write-Host "Proxy Server   : $($proxy.Server)"
    Write-Host ""

    Write-Log "INFO" "Detection summary. Network=$($network.DisplayName) | NetworkType=$networkTypeText | ConnectionType=$($network.ConnectionType) | IP=$($network.IpAddress) | Interface=$($network.InterfaceAlias) | Gateway=$($network.Gateway) | ProxyStatus=$proxyStatusText | ProxyServer=$($proxy.Server)"

    $connectedText = Get-ConnectedNetworkText -Network $network

    if ($network.IsOrganisation) {
        Write-Host "Policy: Organisation network detected. Proxy must be enabled."
        Write-Log "INFO" "Policy decision: Organisation network detected. Proxy must be enabled."

        if ($proxy.Enabled -eq 1 -and $proxy.Server -eq $TcsProxyServer) {
            Write-Log "INFO" "Policy result: Compliant. Organisation network with proxy already enabled."

            Show-Info -Title "TCS Proxy Health Check" -Message @"
Organisation network detected.

$connectedText

Current Proxy  : Enabled
Proxy Server   : $($proxy.Server)

Proxy is already enabled as per Organisation policy.
"@
        }
        else {
            Write-Log "WARNING" "Policy result: Non-compliant. Organisation network detected but proxy is not correctly enabled. CurrentProxy=$proxyStatusText | CurrentServer=$($proxy.Server) | ExpectedServer=$TcsProxyServer"

            Show-Warning -Title "TCS Proxy Mandatory Action" -Message @"
Organisation network detected.

$connectedText

Current Proxy  : $proxyStatusText
Current Server : $($proxy.Server)

Proxy is mandatory on Organisation network.
TCS proxy and exception entries will be enabled now.
"@

            try {
                Enable-TcsProxy
                $finalProxy = Get-ProxyStatus
                Write-Log "INFO" "Final proxy status after enable. Enabled=$($finalProxy.Enabled) | Server=$($finalProxy.Server)"

                Show-Info -Title "TCS Proxy Enabled" -Message @"
TCS proxy has been enabled successfully.

$connectedText

Current Proxy  : Enabled
Proxy Server   : $TcsProxyServer
Proxy exceptions have been updated.
"@
            }
            catch {
                Show-Warning -Title "TCS Proxy Health Check" -Message @"
Failed to enable TCS proxy.

Error details:
$($_.Exception.Message)

Please contact support or check log file:
$LogFile
"@
            }
        }
    }
    else {
        Write-Host "Policy: Personal/Other network detected. Proxy must be disabled."
        Write-Log "INFO" "Policy decision: Personal/Other network detected. Proxy must be disabled."

        if ($proxy.Enabled -ne 1) {
            Write-Log "INFO" "Policy result: Compliant. Personal/Other network with proxy already disabled."

            Show-Info -Title "TCS Proxy Health Check" -Message @"
Personal or non-Organisation network detected.

$connectedText

Current Proxy  : Disabled

Proxy is already disabled.
Please authenticate using Zscaler/VPN as per Organisation policy before accessing Organisation resources.
"@
        }
        else {
            Write-Log "WARNING" "Policy result: Non-compliant. Personal/Other network detected but proxy is enabled. CurrentServer=$($proxy.Server)"

            Show-Warning -Title "TCS Proxy Mandatory Action" -Message @"
Personal or non-Organisation network detected.

$connectedText

Current Proxy  : Enabled
Proxy Server   : $($proxy.Server)

TCS proxy must not remain enabled on personal or non-Organisation network.
Proxy will be disabled now.
"@

            try {
                Disable-TcsProxy
                $finalProxy = Get-ProxyStatus
                Write-Log "INFO" "Final proxy status after disable. Enabled=$($finalProxy.Enabled) | Server=$($finalProxy.Server)"

                Show-Info -Title "Zscaler Authentication Required" -Message @"
Proxy has been disabled successfully.

$connectedText

Current Proxy  : Disabled

Please authenticate using Zscaler/VPN as per Organisation policy before accessing Organisation resources.
"@
            }
            catch {
                Show-Warning -Title "TCS Proxy Health Check" -Message @"
Failed to disable proxy.

Error details:
$($_.Exception.Message)

Please contact support or check log file:
$LogFile
"@
            }
        }
    }

    Write-Host ""
    Write-Host "Completed."
    Write-Host "Log file: $LogFile"

    Write-Log "INFO" "TCS Proxy Health Check completed."
}
catch {
    Write-Log "ERROR" "Unhandled script error. Error=$($_.Exception.Message)"

    Show-Warning -Title "TCS Proxy Health Check" -Message @"
Unexpected error occurred.

Error details:
$($_.Exception.Message)

Please check log file:
$LogFile
"@
}
finally {
    Trim-LogFile

    Write-Host ""
    Write-Host "This window will close after 5 seconds..."
    Start-Sleep -Seconds 5
}