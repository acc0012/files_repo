from django.urls import path
from .views import (
    LoginView,
    AddUserView,
    UploadAddExcelView,
    UserListView,
    EditUserView,
    DeleteUserView,
    ToggleUserStatusView,
    ResetPasswordView,
    UploadBulkDeleteUsersView,
    UploadBulkActivateUsersView,
    UploadBulkDeactivateUsersView
    

)

urlpatterns = [

    # 🔐 Auth
    path('login/', LoginView.as_view(), name='login'),

    # 👤 User Management
    path('users/add/', AddUserView.as_view(), name='add-user'),
    path('users/upload-excel/', UploadAddExcelView.as_view(), name='upload-users-excel'),
    path('users/', UserListView.as_view(), name='list-users'),
     path("users/bulk-delete-upload/", UploadBulkDeleteUsersView.as_view()),
    path("users/bulk-activate-upload/", UploadBulkActivateUsersView.as_view()),
    path("users/bulk-deactivate-upload/", UploadBulkDeactivateUsersView.as_view()),
    # ✏️ Edit / Delete
    path('users/<int:user_id>/edit/', EditUserView.as_view(), name='edit-user'),
    path('users/<int:user_id>/delete/', DeleteUserView.as_view(), name='delete-user'),

    # 🔁 Activate / Deactivate
    path('users/<int:user_id>/toggle-status/', ToggleUserStatusView.as_view(), name='toggle-user-status'),

    # 🔐 Password Reset
    path('users/<int:user_id>/reset-password/', ResetPasswordView.as_view(), name='reset-password'),
]
