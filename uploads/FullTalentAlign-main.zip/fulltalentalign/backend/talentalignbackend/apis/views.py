import pandas as pd
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.contrib.auth import get_user_model

from rest_framework_simplejwt.views import TokenObtainPairView
from .tokens import CustomTokenObtainPairSerializer

from .serializers import (
    UserSerializer,
    AddUserSerializer,
    EditUserSerializer,
    ResetPasswordSerializer,
)

User = get_user_model()


# 🔐 LOGIN
class LoginView(TokenObtainPairView):
    serializer_class = CustomTokenObtainPairSerializer


# 👤 ADD SINGLE USER
class AddUserView(APIView):
    # permission_classes = [IsAuthenticated]

    def post(self, request):
        # if request.user.role != 'admin':
        #     return Response({"error": "Permission denied"}, status=403)

        serializer = AddUserSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({"message": "User created"}, status=201)

        return Response(serializer.errors, status=400)


# 📁 BULK EXCEL UPLOAD
class UploadAddExcelView(APIView):
    # permission_classes = [IsAuthenticated]

    def post(self, request):
        # if request.user.role != 'admin':
        #     return Response({"error": "Only admin allowed"}, status=403)

        file = request.FILES.get("file")
        if not file:
            return Response({"error": "No file uploaded"}, status=400)

        df = pd.read_excel(file)
        created_users = []

        for _, row in df.iterrows():
            if User.objects.filter(username=row['username']).exists():
                continue

            User.objects.create_user(
                username=row['username'],
                email=row['email'],
                password=row['password'],
                role=row['role'],
                is_active=True
            )
            created_users.append(row['username'])

        return Response({"created_users": created_users}, status=201)


# 👁️ LIST USERS
class UserListView(APIView):
    # permission_classes = [IsAuthenticated]

    def get(self, request):
        users = User.objects.all()
        serializer = UserSerializer(users, many=True)
        return Response(serializer.data)


# ✏️ EDIT USER
class EditUserView(APIView):
    # permission_classes = [IsAuthenticated]

    def put(self, request, user_id):
        user = User.objects.get(id=user_id)
        serializer = EditUserSerializer(user, data=request.data, partial=True)

        if serializer.is_valid():
            serializer.save()
            return Response({"message": "User updated"})

        return Response(serializer.errors, status=400)


# 🔁 ACTIVATE / DEACTIVATE USER
class ToggleUserStatusView(APIView):
    # permission_classes = [IsAuthenticated]

    def patch(self, request, user_id):
        user = User.objects.get(id=user_id)
        user.is_active = not user.is_active
        user.save()
        return Response({"status": "updated"})


# ❌ DELETE USER
class DeleteUserView(APIView):
    # permission_classes = [IsAuthenticated]

    def delete(self, request, user_id):
        User.objects.filter(id=user_id).delete()
        return Response({"message": "User deleted"})


# 🔐 RESET PASSWORD
class ResetPasswordView(APIView):
    # permission_classes = [IsAuthenticated]

    def post(self, request, user_id):
        serializer = ResetPasswordSerializer(data=request.data)

        if serializer.is_valid():
            user = User.objects.get(id=user_id)
            user.set_password(serializer.validated_data['password'])
            user.save()
            return Response({"message": "Password reset successful"})

        return Response(serializer.errors, status=400)



class UploadBulkDeleteUsersView(APIView):
    # permission_classes = [IsAuthenticated]

    def post(self, request):
        file = request.FILES.get("file")
        if not file:
            return Response({"error": "No file uploaded"}, status=400)

        df = pd.read_excel(file)

        deleted_users = []

        for _, row in df.iterrows():
            try:
                user = User.objects.get(username=row["username"])
                user.delete()
                deleted_users.append(row["username"])
            except User.DoesNotExist:
                continue

        return Response({
            "deleted_users": deleted_users
        }, status=200)



class UploadBulkActivateUsersView(APIView):
    # permission_classes = [IsAuthenticated]

    def post(self, request):
        file = request.FILES.get("file")
        if not file:
            return Response({"error": "No file uploaded"}, status=400)

        df = pd.read_excel(file)

        activated_users = []

        for _, row in df.iterrows():
            try:
                user = User.objects.get(username=row["username"])
                user.is_active = True
                user.save()
                activated_users.append(row["username"])
            except User.DoesNotExist:
                continue

        return Response({
            "activated_users": activated_users
        }, status=200)



class UploadBulkDeactivateUsersView(APIView):
    # permission_classes = [IsAuthenticated]

    def post(self, request):
        file = request.FILES.get("file")
        if not file:
            return Response({"error": "No file uploaded"}, status=400)

        df = pd.read_excel(file)

        deactivated_users = []

        for _, row in df.iterrows():
            try:
                user = User.objects.get(username=row["username"])
                user.is_active = False
                user.save()
                deactivated_users.append(row["username"])
            except User.DoesNotExist:
                continue

        return Response({
            "deactivated_users": deactivated_users
        }, status=200)
