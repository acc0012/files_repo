
import React, { useState, useEffect } from "react";
import api from "../api/axios";
import "./styles/AdminDashboard.css";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import {
  Users,
  BarChart3,
  GraduationCap,
  UserCog,
  Briefcase,
  UserRound,
  Crown,
  FileSpreadsheet,
  FileText,
  KeyRound,
  Trash2,
  CheckCircle2,
  PauseCircle,
  PlayCircle,
} from "lucide-react";

function AdminDashboard({ userData, onLogout, onBack }) {
  const [activeTab, setActiveTab] = useState("users");
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  // Activity log
  const [activities, setActivities] = useState([]);

  // Modals
  const [showAddUserModal, setShowAddUserModal] = useState(false);
  const [showBulkUploadModal, setShowBulkUploadModal] = useState(false);
  const [showResetPasswordModal, setShowResetPasswordModal] = useState(false);

  // Edit/reset states
  const [editingUser, setEditingUser] = useState(null);
  const [resettingUser, setResettingUser] = useState(null);

  // Search
  const [searchTerm, setSearchTerm] = useState("");

  // Bulk upload
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);

  // Add/Edit user form
  const [newUser, setNewUser] = useState({
    username: "",
    // first_name: "",
    // last_name: "",
    email: "",
    password: "",
    confirmPassword: "",
    role: "trainee",
  });

  // Reset password form
  const [passwordReset, setPasswordReset] = useState({
    newPassword: "",
    confirmPassword: "",
  });

  const [errors, setErrors] = useState({});
  const [passwordErrors, setPasswordErrors] = useState({});
  const [passwordStrength, setPasswordStrength] = useState(0);

  const [stats, setStats] = useState({
    totalUsers: 0,
    activeUsers: 0,
    inactiveUsers: 0,
    roles: [],
  });

  const rolesDef = [
    { value: "trainee", label: "Trainee", icon: <GraduationCap size={16} /> },
    { value: "ta", label: "TL", icon: <UserCog size={16} /> },
    { value: "manager", label: "Manager", icon: <Briefcase size={16} /> },
    { value: "hr", label: "HR", icon: <UserRound size={16} /> },
    { value: "admin", label: "Admin", icon: <Crown size={16} /> },
  ];

  // --- Activity Log ---
  const logAction = (action, username, details = "") => {
    const newActivity = {
      id: Date.now(),
      action,
      user: username,
      time: "Just now",
      details,
    };
    setActivities(prev => [newActivity, ...prev].slice(0, 20));
  };

  // Initial load
  useEffect(() => {
    fetchUsers(true);
  }, []);

  const fetchUsers = async (isInitialLoad = false) => {
    try {
      setLoading(true);
      const response = await api.get("/users/");
      const usersWithFormattedData = response.data.map(user => ({
        ...user,
        // name: `${user.first_name} ${user.last_name}`,
        status: user.is_active ? "active" : "inactive",
        joinDate: user.date_joined ? user.date_joined.split("T")[0] : "N/A",
      }));
      setUsers(usersWithFormattedData);

      // Seed activities on first load
      if (isInitialLoad && usersWithFormattedData.length > 0) {
        const sortedUsers = [...usersWithFormattedData].sort(
          (a, b) => new Date(b.date_joined || 0) - new Date(a.date_joined || 0)
        );
        const initialActivities = sortedUsers.slice(0, 10).map((u, index) => ({
          id: `init-${index}`,
          action: "User Joined",
          user: u.username,
          time: u.joinDate,
        }));
        setActivities(initialActivities);
      }
    } catch (err) {
      console.error("Failed to fetch users:", err);
      toast.error("Failed to fetch users");
    } finally {
      setLoading(false);
    }
  };

  // Stats
  useEffect(() => {
    if (users.length > 0) {
      const totalUsers = users.length;
      const activeUsers = users.filter(u => u.is_active).length;
      const inactiveUsers = users.filter(u => !u.is_active).length;
      const roleStats = rolesDef.map(role => ({
        ...role,
        count: users.filter(u => u.role === role.value).length,
      }));
      setStats({
        totalUsers,
        activeUsers,
        inactiveUsers,
        roles: roleStats,
      });
    } else {
      setStats({
        totalUsers: 0,
        activeUsers: 0,
        inactiveUsers: 0,
        roles: rolesDef.map(role => ({ ...role, count: 0 })),
      });
    }
  }, [users]);

  // --- Validation ---
  const validatePassword = (password) => {
    const errors = [];
    let strength = 0;
    if (password.length >= 8) strength += 1;
    if (/[A-Z]/.test(password)) strength += 1;
    if (/[a-z]/.test(password)) strength += 1;
    if (/[0-9]/.test(password)) strength += 1;
    if (/[^A-Za-z0-9]/.test(password)) strength += 1;

    if (password.length < 8) errors.push("At least 8 characters");
    if (!/[A-Z]/.test(password)) errors.push("At least one uppercase letter");
    if (!/[a-z]/.test(password)) errors.push("At least one lowercase letter");
    if (!/[0-9]/.test(password)) errors.push("At least one number");
    if (!/[^A-Za-z0-9]/.test(password))
      errors.push("At least one special character");

    return { strength, errors };
  };

  const validateForm = () => {
    const newErrors = {};
    if (!newUser.username.trim()) newErrors.username = "Username is required";
    // if (!newUser.first_name.trim()) newErrors.first_name = "First name is required";
    // if (!newUser.last_name.trim()) newErrors.last_name = "Last name is required";
    if (!newUser.email.trim()) newErrors.email = "Email is required";

    if (!editingUser) {
      if (!newUser.password) newErrors.password = "Password is required";
      else if (validatePassword(newUser.password).errors.length > 0)
        newErrors.password = "Weak password";
      if (newUser.password !== newUser.confirmPassword)
        newErrors.confirmPassword = "Passwords do not match";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validatePasswordReset = () => {
    const newErrors = {};
    if (!passwordReset.newPassword) newErrors.newPassword = "Password is required";
    else if (validatePassword(passwordReset.newPassword).errors.length > 0)
      newErrors.newPassword = "Weak password";
    if (passwordReset.newPassword !== passwordReset.confirmPassword)
      newErrors.confirmPassword = "Passwords do not match";
    setPasswordErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // --- Handlers ---
  const handleAddUser = async () => {
    if (!validateForm()) return;
    try {
      if (editingUser) {
        await api.put(`/users/${editingUser.id}/edit/`, {
          // first_name: newUser.first_name,
          // last_name: newUser.last_name,
          email: newUser.email,
          role: newUser.role,
        });
        toast.success("User updated successfully!");
        logAction("User Updated", newUser.username);
      } else {
        await api.post("/users/add/", {
          username: newUser.username,
          // first_name: newUser.first_name,
          // last_name: newUser.last_name,
          email: newUser.email,
          password: newUser.password,
          role: newUser.role,
        });
        toast.success("User added successfully!");
        logAction("User Created", newUser.username);
      }
      fetchUsers();
      setShowAddUserModal(false);
      setNewUser({
        username: "",
        // first_name: "",
        // last_name: "",
        email: "",
        password: "",
        confirmPassword: "",
        role: "trainee",
      });
      setEditingUser(null);
      setPasswordStrength(0);
    } catch (err) {
      console.error(err);
      toast.error(err.response?.data?.message || "Operation failed");
    }
  };

  const handleResetPassword = async () => {
    if (!validatePasswordReset()) return;
    try {
      await api.post(`/users/${resettingUser.id}/reset-password/`, {
        password: passwordReset.newPassword,
      });
      toast.success("Password reset successfully!");
      logAction("Password Reset", resettingUser.username);
      setShowResetPasswordModal(false);
      setPasswordReset({ newPassword: "", confirmPassword: "" });
      setResettingUser(null);
    } catch (err) {
      toast.error("Failed to reset password");
    }
  };

  const handleDeleteUser = async (userId) => {
    const userToDelete = users.find(u => u.id === userId);
    if (window.confirm("Are you sure you want to delete this user?")) {
      try {
        await api.delete(`/users/${userId}/delete/`);
        toast.success("User deleted successfully!");
        logAction("User Deleted", userToDelete?.username || "Unknown User");
        fetchUsers();
      } catch (err) {
        toast.error("Failed to delete user");
      }
    }
  };

  const handleEditUser = (user) => {
    setEditingUser(user);
    setNewUser({
      username: user.username || "",
      // first_name: user.first_name || "",
      // last_name: user.last_name || "",
      email: user.email || "",
      role: user.role || "trainee",
      password: "",
      confirmPassword: "",
    });
    setShowAddUserModal(true);
  };

  const handleResetPasswordClick = (user) => {
    setResettingUser(user);
    setPasswordReset({ newPassword: "", confirmPassword: "" });
    setShowResetPasswordModal(true);
  };

  const handleToggleStatus = async (userId) => {
    try {
      const user = users.find(u => u.id === userId);
      const newStatus = !user.is_active;
      await api.patch(`/users/${userId}/toggle-status/`, {
        is_active: newStatus,
      });
      toast.info(`User ${newStatus ? "activated" : "deactivated"} successfully!`);
      logAction(newStatus ? "User Activated" : "User Deactivated", user.username);
      fetchUsers();
    } catch (err) {
      toast.error("Failed to update user status");
    }
  };

  // Bulk upload
  const handleFileChange = (e) => {
    const uploadedFile = e.target.files[0];
    if (uploadedFile) {
      setFile(uploadedFile);
      toast.success(`${uploadedFile.name} ready for upload`);
    }
  };

  const handleExcelUpload = async (endpoint) => {
    if (!file) {
      toast.warning("Please select a file first");
      return;
    }
    const formData = new FormData();
    formData.append("file", file);
    try {
      setUploading(true);
      const response = await api.post(endpoint, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      toast.success(response.data.message || "Operation successful!");
      logAction("Bulk Upload", "System", "Excel/CSV file processed");
      fetchUsers();
      setFile(null);
      setShowBulkUploadModal(false);
    } catch (err) {
      toast.error("Upload failed!");
    } finally {
      setUploading(false);
    }
  };

  // Filtered users
  const filteredUsers = users.filter(user =>
    user.username?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.role?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // --- Render Tabs ---
  const renderUsersTab = () => (
    <div className="users-tab">
      <div className="section-header">
        <h2>User Management</h2>
        <div className="user-actions">
          <input
            type="text"
            placeholder="Search users..."
            className="search-input"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <button
            className="btn-secondary"
            onClick={() => setShowBulkUploadModal(true)}
          >
            <FileSpreadsheet
              size={16}
              style={{ verticalAlign: "text-bottom", marginRight: 6 }}
            />{" "}
            Excel Upload
          </button>
          <button
            className="btn-primary"
            onClick={() => {
              setEditingUser(null);
              setNewUser({
                username: "",
                // first_name: "",
                // last_name: "",
                email: "",
                password: "",
                confirmPassword: "",
                role: "trainee",
              });
              setShowAddUserModal(true);
            }}
          >
            <Users size={16} style={{ verticalAlign: "text-bottom", marginRight: 6 }} />{" "}
            Add User
          </button>
        </div>
      </div>

      <div className="users-table-container">
        {loading ? (
          <div className="loading-spinner">Loading users...</div>
        ) : (
          <table className="users-table">
            <thead>
              <tr>
                <th>Username</th>
                <th>Email</th>
                <th>Role</th>
                <th>Status</th>
                <th>Join Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map((user) => (
                <tr key={user.id}>
                  <td>
                    <div className="user-info">
                      <div className="user-avatar">
                        {user.username?.charAt(0)}
                      </div>
                      <div>
                        <div className="user-name">{user.username}</div>
                        <div className="user-id">ID: {user.id}</div>
                      </div>
                    </div>
                  </td>
                  <td>{user.email}</td>
                  <td>
                    <span className={`role-badge role-${user.role}`}>
                      {rolesDef.find((r) => r.value === user.role)?.icon}{" "}
                      {rolesDef.find((r) => r.value === user.role)?.label}
                    </span>
                  </td>
                  <td>
                    <span
                      className={`status-badge status-${
                        user.is_active ? "active" : "inactive"
                      }`}
                    >
                      {user.is_active ? "Active" : "Inactive"}
                    </span>
                  </td>
                  <td>{user.joinDate}</td>
                  <td>
                    <div className="action-buttons">
                      <button
                        className="btn-edit"
                        onClick={() => handleEditUser(user)}
                      >
                        <UserCog size={16} style={{ marginRight: 4 }} /> Edit
                      </button>
                      <button
                        className="btn-reset"
                        onClick={() => handleResetPasswordClick(user)}
                      >
                        <KeyRound size={16} style={{ marginRight: 4 }} /> Reset
                      </button>
                      <button
                        className={`btn-status ${
                          user.is_active ? "btn-deactivate" : "btn-activate"
                        }`}
                        onClick={() => handleToggleStatus(user.id)}
                        title={user.is_active ? "Deactivate" : "Activate"}
                      >
                        {user.is_active ? (
                          <PauseCircle size={16} />
                        ) : (
                          <PlayCircle size={16} />
                        )}
                      </button>
                      <button
                        className="btn-delete"
                        onClick={() => handleDeleteUser(user.id)}
                        title="Delete user"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );

  const renderStatisticsTab = () => (
    <div className="statistics-tab">
      <div className="section-header">
        <h2>System Statistics</h2>
      </div>

      <div className="stats-grid">
        <div className="stat-card primary">
          <div className="stat-icon">
            <Users size={24} />
          </div>
          <div className="stat-content">
            <h3>Total Users</h3>
            <div className="stat-value">{stats.totalUsers}</div>
          </div>
        </div>
        <div className="stat-card success">
          <div className="stat-icon">
            <CheckCircle2 size={24} />
          </div>
          <div className="stat-content">
            <h3>Active Users</h3>
            <div className="stat-value">{stats.activeUsers}</div>
          </div>
        </div>
        <div className="stat-card warning">
          <div className="stat-icon">
            <PauseCircle size={24} />
          </div>
          <div className="stat-content">
            <h3>Inactive Users</h3>
            <div className="stat-value">{stats.inactiveUsers}</div>
          </div>
        </div>
      </div>

      <div className="charts-grid">
        <div className="chart-card">
          <h3>User Distribution by Role</h3>
          <div className="role-distribution">
            {stats.roles.map((role) => (
              <div key={role.value} className="role-dist-item">
                <div className="role-info">
                  <span className="role-icon-small">{role.icon}</span>
                  <span className="role-name">{role.label}</span>
                </div>
                <div className="role-stats">
                  <div className="role-count">{role.count}</div>
                  <div className="role-percentage">
                    {stats.totalUsers > 0
                      ? ((role.count / stats.totalUsers) * 100).toFixed(1)
                      : 0}
                    %
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="chart-card">
          <h3>Recent Activity</h3>
          <div className="activity-feed">
            {activities.length > 0 ? (
              activities.map((activity) => (
                <div key={activity.id} className="activity-item">
                  <div className="activity-icon">
                    <FileText size={20} />
                  </div>
                  <div className="activity-content">
                    <div className="activity-action">{activity.action}</div>
                    <div className="activity-details">
                      <span className="activity-user">{activity.user}</span>
                      <span className="activity-time">{activity.time}</span>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="activity-item">No recent activity</div>
            )}
          </div>
        </div>
      </div>

      <div className="detailed-stats">
        <h3>Detailed User Statistics</h3>
        <div className="detailed-grid">
          <div className="detailed-card">
            <h4>Role Distribution</h4>
            <div className="distribution-chart">
              {stats.roles.map((role) => (
                <div key={role.value} className="distribution-item">
                  <div className="dist-label">
                    <span className="dist-icon">{role.icon}</span>
                    <span>{role.label}</span>
                  </div>
                  <div className="dist-bar">
                    <div
                      className="dist-fill"
                      style={{
                        width: `${
                          stats.totalUsers > 0
                            ? (role.count / stats.totalUsers) * 100
                            : 0
                        }%`,
                      }}
                    />
                  </div>
                  <div className="dist-value">{role.count} users</div>
                </div>
              ))}
            </div>
          </div>

          <div className="detailed-card">
            <h4>User Status Overview</h4>
            <div className="status-overview">
              <div className="status-item">
                <div className="status-label active">Active Users</div>
                <div className="status-count">{stats.activeUsers}</div>
              </div>
              <div className="status-item">
                <div className="status-label inactive">Inactive Users</div>
                <div className="status-count">{stats.inactiveUsers}</div>
              </div>
              <div className="status-item">
                <div className="status-label total">Total Users</div>
                <div className="status-count">{stats.totalUsers}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  // --- Modals ---
  const renderAddUserModal = () => (
    <div className="modal-overlay" onClick={() => setShowAddUserModal(false)}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>{editingUser ? "Edit User" : "Add New User"}</h2>
          <button className="modal-close" onClick={() => setShowAddUserModal(false)}>×</button>
        </div>
        <div className="modal-body">
          <div className="form-group">
            <label>Username *</label>
            <input
              type="text"
              value={newUser.username}
              onChange={(e) => setNewUser({ ...newUser, username: e.target.value })}
              className={errors.username ? "error" : ""}
            />
            {errors.username && <span className="error-message">{errors.username}</span>}
          </div>

          {/* <div className="form-group">
            <label>First Name *</label>
            <input
              type="text"
              value={newUser.first_name}
              onChange={(e) => setNewUser({ ...newUser, first_name: e.target.value })}
              className={errors.first_name ? "error" : ""}
            />
            {errors.first_name && <span className="error-message">{errors.first_name}</span>}
          </div> */}

          {/* <div className="form-group">
            <label>Last Name *</label>
            <input
              type="text"
              value={newUser.last_name}
              onChange={(e) => setNewUser({ ...newUser, last_name: e.target.value })}
              className={errors.last_name ? "error" : ""}
            />
            {errors.last_name && <span className="error-message">{errors.last_name}</span>}
          </div> */}

          <div className="form-group">
            <label>Email *</label>
            <input
              type="email"
              value={newUser.email}
              onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
              className={errors.email ? "error" : ""}
            />
            {errors.email && <span className="error-message">{errors.email}</span>}
          </div>

          {!editingUser && (
            <>
              <div className="form-group">
                <label>Password *</label>
                <input
                  type="password"
                  value={newUser.password}
                  onChange={(e) => {
                    setNewUser({ ...newUser, password: e.target.value });
                    setPasswordStrength(validatePassword(e.target.value).strength);
                  }}
                  className={errors.password ? "error" : ""}
                />
                {errors.password && <span className="error-message">{errors.password}</span>}
                <div className="password-strength">
                  <div className="strength-meter">
                    {[1, 2, 3, 4, 5].map((level) => (
                      <div
                        key={level}
                        className={`strength-bar ${passwordStrength >= level ? "active" : ""}`}
                        style={{ width: "20%" }}
                      />
                    ))}
                  </div>
                </div>
              </div>

              <div className="form-group">
                <label>Confirm Password *</label>
                <input
                  type="password"
                  value={newUser.confirmPassword}
                  onChange={(e) => setNewUser({ ...newUser, confirmPassword: e.target.value })}
                  className={errors.confirmPassword ? "error" : ""}
                />
                {errors.confirmPassword && (
                  <span className="error-message">{errors.confirmPassword}</span>
                )}
              </div>
            </>
          )}

          <div className="form-group">
            <label>Role *</label>
            <select
              value={newUser.role}
              onChange={(e) => setNewUser({ ...newUser, role: e.target.value })}
            >
              {rolesDef.map((r) => (
                <option key={r.value} value={r.value}>
                  {r.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="modal-actions">
          <button className="btn-primary" onClick={handleAddUser}>
            {editingUser ? "Update" : "Add"}
          </button>
          <button className="btn-secondary" onClick={() => setShowAddUserModal(false)}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  );

  const renderResetPasswordModal = () => (
    <div className="modal-overlay" onClick={() => setShowResetPasswordModal(false)}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>Reset Password for {resettingUser?.username}</h2>
          <button className="modal-close" onClick={() => setShowResetPasswordModal(false)}>×</button>
        </div>
        <div className="modal-body">
          <div className="form-group">
            <label>New Password</label>
            <input
              type="password"
              value={passwordReset.newPassword}
              onChange={(e) => {
                setPasswordReset({ ...passwordReset, newPassword: e.target.value });
                setPasswordStrength(validatePassword(e.target.value).strength);
              }}
            />
          </div>
          <div className="form-group">
            <label>Confirm Password</label>
            <input
              type="password"
              value={passwordReset.confirmPassword}
              onChange={(e) =>
                setPasswordReset({ ...passwordReset, confirmPassword: e.target.value })
              }
            />
          </div>
        </div>
        <div className="modal-actions">
          <button className="btn-primary" onClick={handleResetPassword}>
            Reset
          </button>
          <button className="btn-secondary" onClick={() => setShowResetPasswordModal(false)}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  );

  // ✅ Integrated Excel Bulk Upload modal (your requested format)
  const renderBulkUploadModal = () => (
    <div className="modal-overlay" onClick={() => setShowBulkUploadModal(false)}>
      <div className="modal-content" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h2>Excel Bulk Operations</h2>
          <button className="modal-close" onClick={() => setShowBulkUploadModal(false)}>×</button>
        </div>
        
        <div className="modal-body">
          <div className="upload-instructions">
            <h4>Instructions:</h4>
            <ul>
              <li>Upload an Excel file (.xlsx, .xls)</li>
              <li>File should contain columns: <code>username</code>, <code>email</code>, <code>role</code></li>
              <li>For <strong>Add Users</strong>, also include <code>password</code> column</li>
              <li>For other operations, only <code>username</code> column is required</li>
              <li>Roles must be one of: <code>trainee</code>, <code>teamlead</code>, <code>manager</code>, <code>hr</code>, <code>admin</code></li>
            </ul>
          </div>

          <div className="file-upload-area">
            <input
              type="file"
              id="file-upload"
              accept=".xlsx,.xls"
              onChange={handleFileChange}
              style={{ display: 'none' }}
            />
            <label htmlFor="file-upload" className="file-upload-label">
              {file ? ` ${file.name}` : 'Click to upload Excel'}
            </label>
            
            {file && (
              <div className="file-info">
                <p>Selected file: {file.name}</p>
                <p>Size: {(file.size / 1024).toFixed(2)} KB</p>
              </div>
            )}
          </div>

          <div className="excel-upload-grid">
            {[
              { endpoint: "/users/upload-excel/", label: "Upload & Add Users", btnClass: "super-btn-success", description: "Add new users from Excel file" },
              // { endpoint: "/users/bulk-delete-upload/", label: "Upload & Delete Users", btnClass: "super-btn-danger", description: "Delete users listed in Excel file" },
              { endpoint: "/users/bulk-activate-upload/", label: "Upload & Activate Users", btnClass: "btn-primary", description: "Activate users listed in Excel file" },
              { endpoint: "/users/bulk-deactivate-upload/", label: "Upload & Deactivate Users", btnClass: "btn-warning", description: "Deactivate users listed in Excel file" },
            ].map((item, idx) => (
              <div key={idx} className="excel-upload-card">
                <div className="excel-card-content">
                  <h4>{item.label}</h4>
                  <p>{item.description}</p>
                  <button
                    onClick={() => handleExcelUpload(item.endpoint)}
                    className={`btn ${item.btnClass}`}
                    disabled={!file || uploading}
                  >
                    {uploading ? 'Uploading...' : item.label}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="modal-actions">
          <button className="btn-secondary" onClick={() => setShowBulkUploadModal(false)}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  );

  const sidebarItems = [
    { id: "users", label: "User Management", icon: <Users size={18} /> },
    { id: "statistics", label: "Statistics", icon: <BarChart3 size={18} /> },
  ];

  return (
    <div className="dashboard">
      <ToastContainer position="top-right" autoClose={3000} />
      
      {/* Fixed Sidebar */}
      <div className="sidebar">
        <div className="sidebar-header">
          <h2>Admin Panel</h2>
          <p>System Administration</p>
        </div>
        <div className="sidebar-nav">
          {sidebarItems.map((item) => (
            <div
              key={item.id}
              className={`nav-item ${activeTab === item.id ? "active" : ""}`}
              onClick={() => setActiveTab(item.id)}
            >
              <span className="nav-icon">{item.icon}</span>
              <span className="nav-label">{item.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Scrollable Right Pane */}
      <div className="main-content">
        <div className="dashboard-header">
          <div className="header-title">
            <h1>Admin Dashboard</h1>
            {/* <div className="header-subtitle">
              Welcome, {userData?.first_name} {userData?.last_name}
            </div> */}
          </div>
          <div className="header-actions">
            <button className="btn-danger" onClick={onLogout}>
              Logout
            </button>
          </div>
        </div>

        {activeTab === "users" && renderUsersTab()}
        {activeTab === "statistics" && renderStatisticsTab()}
      </div>

      {/* Modals */}
      {showAddUserModal && renderAddUserModal()}
      {showResetPasswordModal && renderResetPasswordModal()}
      {showBulkUploadModal && renderBulkUploadModal()}
    </div>
  );
}

export default AdminDashboard;
