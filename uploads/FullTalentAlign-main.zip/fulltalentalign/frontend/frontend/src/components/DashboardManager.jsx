import React, { useState,useEffect } from 'react';
import Sidebar from './Sidebar';

import {
  LayoutDashboard,
  Briefcase,
  Users,
  CheckCircle,
  BarChart3,
  FileText,
  TrendingUp,
  MapPin,
  Target,
  Folder,
  ChevronRight,
  Search,
  Filter,
  Download,
  X,
  Star,
  Award,
  Calendar,
  PieChart,
  User,
  Mail,
  Building,
  GraduationCap,
  BookOpen,
  Sparkles,
  Zap,
  AlertCircle,
  Eye,
  Download as DownloadIcon,
  Plus,
  Settings,
  Bell,
  Clock,
  Check,
  Home,
  BriefcaseBusiness,
  ThumbsUp,
  ThumbsDown,
  Send,
  RefreshCw,
  MoreVertical,
  ExternalLink,
  Shield,
  Clock as ClockIcon,
  TrendingDown,
  Brain,
  Lightbulb,
  Heart,
  MessageSquare,
  BarChart2,
  Filter as FilterIcon,
  UserCheck,
  UserX,
  Target as TargetIcon,
  Hash,
  Percent,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';

function DashboardManager({ userData, onLogout }) {
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedJobProfile, setSelectedJobProfile] = useState(null);
  const [selectedTrainee, setSelectedTrainee] = useState(null);
  const [showTopN, setShowTopN] = useState(5);
  const [approvalFilter, setApprovalFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [recommendations, setRecommendations] = useState([
    {
      id: 1,
      traineeId: 101,
      traineeName: "John Smith",
      traineeEmail: "john.smith@example.com",
      projectId: 1,
      projectName: "E-commerce Platform",
      recommendedBy: "TA - Dr. James Wilson",
      recommendationDate: "2024-02-15",
      status: "pending", // pending, approved, rejected
      matchScore: 94,
      skillsMatch: ["React", "JavaScript", "CSS"],
      locationMatch: "pune",
      reason: "Exceptional performance in React projects and excellent team collaboration skills",
      taComments: "John consistently demonstrates strong problem-solving abilities and has shown great initiative in previous projects.",
      priority: "high"
    },
    {
      id: 2,
      traineeId: 102,
      traineeName: "Emma Wilson",
      traineeEmail: "emma.wilson@example.com",
      projectId: 2,
      projectName: "Data Analytics Dashboard",
      recommendedBy: "TA - Dr. Sarah Chen",
      recommendationDate: "2024-02-14",
      status: "pending",
      matchScore: 88,
      skillsMatch: ["React", "TypeScript", "UI/UX"],
      locationMatch: "hyderabad",
      reason: "Strong UI/UX skills and experience with data visualization libraries",
      taComments: "Emma has a keen eye for design and has previously worked on similar dashboard projects.",
      priority: "medium"
    },
    {
      id: 3,
      traineeId: 103,
      traineeName: "Mike Chen",
      traineeEmail: "mike.chen@example.com",
      projectId: 3,
      projectName: "Mobile Banking App",
      recommendedBy: "TA - Prof. Robert Brown",
      recommendationDate: "2024-02-13",
      status: "approved",
      matchScore: 92,
      skillsMatch: ["JavaScript", "CSS", "Security"],
      locationMatch: "pune",
      reason: "Strong background in security and financial applications",
      taComments: "Mike has completed advanced security courses and has relevant banking domain knowledge.",
      priority: "high"
    },
    {
      id: 4,
      traineeId: 104,
      traineeName: "Sarah Johnson",
      traineeEmail: "sarah.j@example.com",
      projectId: 1,
      projectName: "E-commerce Platform",
      recommendedBy: "TA - Dr. James Wilson",
      recommendationDate: "2024-02-12",
      status: "rejected",
      matchScore: 85,
      skillsMatch: ["React", "JavaScript"],
      locationMatch: "pune",
      reason: "Skills gap in backend technologies required for the project",
      taComments: "Sarah is strong in frontend but needs more experience with Node.js and databases.",
      priority: "low"
    }
  ]);

  // Mock data
  const jobProfiles = [
    {
      id: 1,
      title: "Frontend Developer",
      location: "pune",
      projects: 8,
      requiredSkills: ["React", "JavaScript", "CSS", "TypeScript"],
      totalTrainees: 45,
      matchingTrainees: 32,
      locationMatches: 28,
      skillMatches: 35,
      completeMatches: 25,
      matchPercentage: 71.1,
      topMatches: [
        { id: 101, name: "John Smith", matchScore: 94, location: "pune", skills: ["React", "JavaScript", "CSS"] },
        { id: 102, name: "Emma Wilson", matchScore: 92, location: "hyderabad", skills: ["React", "TypeScript"] },
        { id: 103, name: "Mike Chen", matchScore: 89, location: "pune", skills: ["JavaScript", "CSS"] },
        { id: 104, name: "Sarah Johnson", matchScore: 87, location: "pune", skills: ["React", "JavaScript"] },
        { id: 105, name: "David Lee", matchScore: 85, location: "Chicago", skills: ["React", "CSS"] },
        { id: 106, name: "Lisa Wang", matchScore: 84, location: "pune", skills: ["JavaScript", "TypeScript"] },
        { id: 107, name: "Tom Brown", matchScore: 82, location: "pune", skills: ["React"] },
        { id: 108, name: "Anna Davis", matchScore: 81, location: "hyderabad", skills: ["React", "CSS"] },
        { id: 109, name: "James Miller", matchScore: 79, location: "pune", skills: ["JavaScript"] },
        { id: 110, name: "Maria Garcia", matchScore: 77, location: "pune", skills: ["CSS"] }
      ]
    },
    {
      id: 2,
      title: "Data Scientist",
      location: "chennai",
      projects: 5,
      requiredSkills: ["Python", "Machine Learning", "SQL", "Statistics"],
      totalTrainees: 32,
      matchingTrainees: 24,
      locationMatches: 18,
      skillMatches: 26,
      completeMatches: 16,
      matchPercentage: 66.7,
      topMatches: [
        { id: 201, name: "Alex Johnson", matchScore: 91, location: "chennai", skills: ["Python", "Machine Learning"] },
        { id: 202, name: "Rachel Green", matchScore: 88, location: "chennai", skills: ["Python", "SQL"] },
        { id: 203, name: "Kevin Brown", matchScore: 85, location: "Remote", skills: ["Machine Learning", "Statistics"] },
        { id: 204, name: "Sophia Miller", matchScore: 83, location: "chennai", skills: ["Python"] },
        { id: 205, name: "Daniel Wilson", matchScore: 80, location: "chennai", skills: ["SQL", "Statistics"] }
      ]
    }
  ];

  const trainees = [
    {
      id: 101,
      name: "John Smith",
      email: "john.smith@example.com",
      location: "pune",
      skills: ["React", "JavaScript", "CSS", "Node.js"],
      projectsMatched: 8,
      totalProjects: 12,
      matchRate: 66.7,
      status: "Job Ready",
      joinedDate: "2024-01-15",
      currentProject: "E-commerce Platform",
      projectStatus: "approved", // approved, pending, open-pool
      certifications: ["React Advanced", "JavaScript Expert", "AWS Certified"],
      experience: "2 years",
      education: "B.Tech Computer Science",
      preferredLocation: "pune",
      evaluations: [
        { date: "2024-01-15", type: "Technical", score: 88 },
        { date: "2023-12-10", type: "Behavioral", score: 82 }
      ]
    },
    {
      id: 102,
      name: "Emma Wilson",
      email: "emma.wilson@example.com",
      location: "hyderabad",
      skills: ["React", "TypeScript", "UI/UX"],
      projectsMatched: 6,
      totalProjects: 10,
      matchRate: 60.0,
      status: "Needs Training",
      joinedDate: "2024-02-10",
      currentProject: null,
      projectStatus: "open-pool",
      certifications: ["UI/UX Design", "Figma Advanced"],
      experience: "1.5 years",
      education: "B.Des Graphic Design",
      preferredLocation: "hyderabad",
      evaluations: [
        { date: "2024-02-05", type: "Technical", score: 75 },
        { date: "2024-01-20", type: "Behavioral", score: 85 }
      ]
    }
  ];

  const projects = [
    { id: 1, name: "E-commerce Platform", skills: ["React", "Node.js", "MongoDB"], trainees: 15, status: "active" },
    { id: 2, name: "Data Analytics Dashboard", skills: ["Python", "React", "D3.js"], trainees: 12, status: "active" },
    { id: 3, name: "Mobile Banking App", skills: ["React Native", "Java", "Spring Boot"], trainees: 18, status: "active" },
    { id: 4, name: "Open Pool", skills: ["Various"], trainees: 8, status: "open-pool" }
  ];

  const renderOverview = () => (
    <div className="overview">
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon">
            <Users className="stat-icon-svg" />
          </div>
          <div className="stat-content">
            <h3>Total Trainees</h3>
            <div className="stat-value">156</div>
            {/* <div className="stat-trend">
              <TrendingUp size={14} />
              <span>12% from last month</span>
            </div> */}
            <div className="stat-detail">
              <span>Mapped: 124</span>
              <span>Unmapped: 32</span>
            </div>
          </div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon">
            <Folder className="stat-icon-svg" />
          </div>
          <div className="stat-content">
            <h3>Active Projects</h3>
            <div className="stat-value">24</div>
            {/* <div className="stat-trend">
              <TrendingUp size={14} />
              <span>3 new this month</span>
            </div> */}
            <div className="stat-detail">
              <span>Completed: 8</span>
              <span>In Progress: 16</span>
            </div>
          </div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon">
            <Target className="stat-icon-svg" />
          </div>
          <div className="stat-content">
            {/* <h3>Overall Match Rate</h3>
            <div className="stat-value">78.5%</div> */}
            {/* <div className="stat-trend">
              <TrendingUp size={14} />
              <span>5.2% from last quarter</span>
            </div> */}
            <div className="stat-detail">
              <span>High Match: 68</span>
              <span>Medium: 56</span>
            </div>
          </div>
        </div>
        
        
      </div>

      <div className="charts-grid">
        <div className="chart-card">
          <div className="card-header">
            <Briefcase size={20} />
            <h3>
             
              Projects by Skills Demand
            </h3>
          </div>
          <div className="skills-chart">
            {projects.map((project) => (
              <div key={project.id} className="project-skill-row">
                <div className="project-info">
                  <div className="project-name">{project.name}</div>
                  <div className="project-meta">
                    <div className="trainee-count">
                      <Users size={14} />
                      {project.trainees} trainees
                    </div>
                  </div>
                </div>
                <div className="skill-tags">
                  {project.skills.map((skill, idx) => (
                    <span key={idx} className="skill-tag">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="chart-card">
          <div className="card-header">
              <PieChart size={20} />
            <h3>
              Matching Distribution
            </h3>
          </div>
          <div className="matching-stats">
            {[
              { label: 'Location Match Only', count: 45, percentage: 65, color: '#3b82f6', icon: MapPin },
              { label: 'Skills Match Only', count: 38, percentage: 55, color: '#8b5cf6', icon: Award },
              { label: 'Complete Match', count: 68, percentage: 75, color: '#10b981', icon: CheckCircle },
              { label: 'No Match', count: 5, percentage: 10, color: '#ef4444', icon: AlertCircle }
            ].map((item, index) => {
              const Icon = item.icon;
              return (
                <div key={index} className="match-category">
                  <div className="category-header">
                    <div className="category-label">
                      <Icon size={16} />
                      {item.label}
                    </div>
                    <span className="count">{item.count}</span>
                  </div>
                  <div className="category-bar">
                    <div 
                      className="bar-fill" 
                      style={{ 
                        width: `${item.percentage}%`,
                        backgroundColor: item.color
                      }}
                    ></div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* <div className="quick-actions">
        <h3>Quick Actions</h3>
        <div className="action-buttons">
          <button className="action-btn" onClick={() => setActiveTab('job-profiles')}>
            <div className="action-icon">
              <Briefcase size={24} />
            </div>
            <span>View Job Profiles</span>
            <ChevronRight size={16} className="action-arrow" />
          </button>
          <button className="action-btn" onClick={() => setActiveTab('recommendations')}>
            <div className="action-icon">
              <ThumbsUp size={24} />
            </div>
            <span>Review Recommendations</span>
            <ChevronRight size={16} className="action-arrow" />
          </button>
          <button className="action-btn" onClick={() => setActiveTab('trainees')}>
            <div className="action-icon">
              <Users size={24} />
            </div>
            <span>Manage Trainees</span>
            <ChevronRight size={16} className="action-arrow" />
          </button>
        </div>
      </div> */}
    </div>
  );

  const renderRecommendations = () => {
    const filteredRecommendations = recommendations.filter(rec => {
      if (approvalFilter === 'all') return true;
      return rec.status === approvalFilter;
    });

    const pendingCount = recommendations.filter(r => r.status === 'pending').length;
    const approvedCount = recommendations.filter(r => r.status === 'approved').length;
    const rejectedCount = recommendations.filter(r => r.status === 'rejected').length;

    const handleApprove = (recommendationId) => {
      setRecommendations(recs => 
        recs.map(rec => 
          rec.id === recommendationId 
            ? { ...rec, status: 'approved' }
            : rec
        )
      );
      // In real app, would also update trainee's project assignment
      alert(`Trainee has been approved and mapped to the project!`);
    };

    const handleReject = (recommendationId) => {
      setRecommendations(recs => 
        recs.map(rec => 
          rec.id === recommendationId 
            ? { ...rec, status: 'rejected' }
            : rec
        )
      );
      // In real app, would move trainee to open pool
      alert(`Trainee has been rejected and moved to Open Pool for future assignments.`);
    };

    const handleViewTrainee = (traineeId) => {
      const trainee = trainees.find(t => t.id === traineeId);
      if (trainee) {
        setSelectedTrainee(trainee);
      }
    };

    return (
      <div className="recommendations">
        <div className="section-header">
          <div className="header-title">
            <h2>
              <ThumbsUp size={24} />
              TA Recommendations ({recommendations.length})
            </h2>
            <p className="subtitle">Review and approve trainee-project assignments</p>
          </div>
          <div className="filter-options">
            <div className="search-box">
              <Search size={18} />
              <input 
                type="text" 
                placeholder="Search recommendations..." 
                className="search-input"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="filter-group">
              <button className="btn-filter">
                <Filter size={18} />
                Filter
              </button>
              <select 
                className="filter-select"
                value={approvalFilter}
                onChange={(e) => setApprovalFilter(e.target.value)}
              >
                <option value="all">All Status</option>
                <option value="pending">Pending ({pendingCount})</option>
                <option value="approved">Approved ({approvedCount})</option>
                <option value="rejected">Rejected ({rejectedCount})</option>
              </select>
            </div>
          </div>
        </div>

        <div className="recommendations-stats">
          <div className="stat-card-small">
            <div className="stat-icon-small pending">
              <Clock size={20} />
            </div>
            <div className="stat-content-small">
              <div className="stat-value-small">{pendingCount}</div>
              <div className="stat-label-small">Pending Review</div>
            </div>
          </div>
          <div className="stat-card-small">
            <div className="stat-icon-small approved">
              <CheckCircle size={20} />
            </div>
            <div className="stat-content-small">
              <div className="stat-value-small">{approvedCount}</div>
              <div className="stat-label-small">Approved</div>
            </div>
          </div>
          <div className="stat-card-small">
            <div className="stat-icon-small rejected">
              <X size={20} />
            </div>
            <div className="stat-content-small">
              <div className="stat-value-small">{rejectedCount}</div>
              <div className="stat-label-small">Rejected</div>
            </div>
          </div>
          <div className="stat-card-small">
            <div className="stat-icon-small total">
              <Users size={20} />
            </div>
            <div className="stat-content-small">
              <div className="stat-value-small">{recommendations.length}</div>
              <div className="stat-label-small">Total</div>
            </div>
          </div>
        </div>

        <div className="table-container">
          <table className="data-table">
            <thead>
              <tr>
                <th>Trainee</th>
                <th>Project</th>
                <th>Recommended By</th>
                <th>Match Score</th>
                {/* <th>Priority</th> */}
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredRecommendations.map((rec) => (
                <tr key={rec.id} className={`recommendation-row status-${rec.status}`}>
                  <td>
                    <div className="trainee-info">
                      <div className="avatar">{rec.traineeName.charAt(0)}</div>
                      <div className="trainee-details">
                        <div className="name">{rec.traineeName}</div>
                        <div className="email">
                          <Mail size={12} />
                          {rec.traineeEmail}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td>
                    <div className="project-cell">
                      <div className="project-name">{rec.projectName}</div>
                      <div className="project-location">
                        <MapPin size={12} />
                        {rec.locationMatch}
                      </div>
                    </div>
                  </td>
                  <td>
                    <div className="ta-cell">
                      <div className="ta-name">{rec.recommendedBy}</div>
                      <div className="ta-date">
                        <Calendar size={12} />
                        {rec.recommendationDate}
                      </div>
                    </div>
                  </td>
                  <td>
                    <div className="score-cell">
                      <div className="score-badge">{rec.matchScore}%</div>
                      <div className="skills-match">
                        {rec.skillsMatch.slice(0, 2).map(skill => (
                          <span key={skill} className="skill-tag mini">{skill}</span>
                        ))}
                      </div>
                    </div>
                  </td>
                  {/* <td>
                    <div className={`priority-badge priority-${rec.priority}`}>
                      {rec.priority === 'high' ? 'High' : rec.priority === 'medium' ? 'Medium' : 'Low'}
                    </div>
                  </td> */}
                  <td>
                    <div className={`status-badge status-${rec.status}`}>
                      {rec.status === 'pending' ? (
                        <>
                          <Clock size={12} />
                          Pending
                        </>
                      ) : rec.status === 'approved' ? (
                        <>
                          <CheckCircle size={12} />
                          Approved
                        </>
                      ) : (
                        <>
                          <X size={12} />
                          Rejected
                        </>
                      )}
                    </div>
                  </td>
                  <td>
                    <div className="recommendation-actions">
                      <button 
                        className="btn-icon btn-icon-view"
                        onClick={() => handleViewTrainee(rec.traineeId)}
                      >
                        <Eye size={16} />
                      </button>
                      {rec.status === 'pending' && (
                        <>
                          <button 
                            className="btn-icon btn-icon-approve"
                            onClick={() => handleApprove(rec.id)}
                          >
                            <ThumbsUp size={16} />
                          </button>
                          <button 
                            className="btn-icon btn-icon-reject"
                            onClick={() => handleReject(rec.id)}
                          >
                            <ThumbsDown size={16} />
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredRecommendations.length === 0 && (
          <div className="empty-state">
            <ThumbsUp size={48} />
            <h3>No recommendations found</h3>
            <p>Try adjusting your filters or check back later for new recommendations.</p>
          </div>
        )}
      </div>
    );
  };

  const renderJobProfiles = () => (
    <div className="job-profiles">
      <div className="section-header">
        <div className="header-title">
          <h2>
            <Briefcase size={24} />
            Job Profiles ({jobProfiles.length})
          </h2>
          <p className="subtitle">Analyze job profile matching statistics</p>
        </div>
        <div className="filter-options">
          <div className="search-box">
            <Search size={18} />
            <input type="text" placeholder="Search job profiles..." className="search-input" />
          </div>
          <div className="filter-group">
            <button className="btn-filter">
              <Filter size={18} />
              Filter
            </button>
            <select className="filter-select">
              <option>All Locations</option>
              <option>pune</option>
              <option>chennai</option>
              <option>hyderabad</option>
            </select>
          </div>
        </div>
      </div>

      <div className="job-profiles-grid">
        {jobProfiles.map((profile) => (
          <div key={profile.id} className="job-profile-card" onClick={() => setSelectedJobProfile(profile)}>
            <div className="profile-header">
              <div className="profile-title">
                <div className="profile-icon">
                  <BriefcaseBusiness size={20} />
                </div>
                <h3>{profile.title}</h3>
              </div>
              <div className="location-tag">
                <MapPin size={14} />
                {profile.location}
              </div>
            </div>
            
            <div className="profile-stats">
              <div className="stat-row">
                <div className="stat-label">
                  <Folder size={14} />
                  Projects
                </div>
                <div className="stat-value">{profile.projects}</div>
              </div>
              <div className="stat-row">
                <div className="stat-label">
                  <Users size={14} />
                  Trainees Matched
                </div>
                <div className="stat-value">{profile.matchingTrainees}/{profile.totalTrainees}</div>
              </div>
              <div className="stat-row">
                <div className="stat-label">
                  <Target size={14} />
                  Match Rate
                </div>
                <div className="stat-value highlight">{profile.matchPercentage}%</div>
              </div>
            </div>
            
            <div className="skills-container">
              <h4>Required Skills</h4>
              <div className="skills-list">
                {profile.requiredSkills.map((skill, index) => (
                  <span key={index} className="skill-tag">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
            
            <div className="matching-breakdown">
              <div className="breakdown-item">
                <div className="breakdown-label">
                  <MapPin size={14} />
                  Location Match
                </div>
                <div className="breakdown-value">{profile.locationMatches}</div>
              </div>
              <div className="breakdown-item">
                <div className="breakdown-label">
                  <Award size={14} />
                  Skills Match
                </div>
                <div className="breakdown-value">{profile.skillMatches}</div>
              </div>
              <div className="breakdown-item">
                <div className="breakdown-label">
                  <CheckCircle size={14} />
                  Complete Match
                </div>
                <div className="breakdown-value">{profile.completeMatches}</div>
              </div>
            </div>
            
            <button className="view-details-btn">
              <Eye size={16} />
              View Details
            </button>
          </div>
        ))}
      </div>
    </div>
  );

  const renderTrainees = () => (
    <div className="trainees">
      <div className="section-header">
        <div className="header-title">
          <h2>
            <Users size={24} />
            All Trainees ({trainees.length})
          </h2>
          <p className="subtitle">Manage and analyze trainee performance</p>
        </div>
        <div className="filter-options">
          <div className="search-box">
            <Search size={18} />
            <input type="text" placeholder="Search trainees..." className="search-input" />
          </div>
          <div className="filter-group">
            <select className="filter-select">
              <option>All Status</option>
              <option>Job Ready</option>
              <option>Needs Training</option>
              <option>Not Ready</option>
            </select>
            <select className="filter-select">
              <option>All Locations</option>
              <option>pune</option>
              <option>chennai</option>
              <option>hyderabad</option>
            </select>
            <button className="btn-icon">
              <Download size={18} />
            </button>
          </div>
        </div>
      </div>

      <div className="table-container">
        <table className="data-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Location</th>
              <th>Skills</th>
              <th>Projects Matched</th>
              <th>Match Rate</th>
              {/* <th>Status</th> */}
              <th>Current Project</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {trainees.map((trainee) => (
              <tr key={trainee.id} onClick={() => setSelectedTrainee(trainee)}>
                <td>
                  <div className="trainee-info">
                    <div className="avatar">{trainee.name.charAt(0)}</div>
                    <div className="trainee-details">
                      <div className="name">{trainee.name}</div>
                      <div className="email">
                        <Mail size={12} />
                        {trainee.email}
                      </div>
                    </div>
                  </div>
                </td>
                <td>
                  <div className="location-cell">
                    <MapPin size={14} />
                    {trainee.location}
                  </div>
                </td>
                <td>
                  <div className="skills-preview">
                    {trainee.skills.slice(0, 2).map((skill, idx) => (
                      <span key={idx} className="skill-tag small">{skill}</span>
                    ))}
                    {trainee.skills.length > 2 && (
                      <span className="more-skills">+{trainee.skills.length - 2}</span>
                    )}
                  </div>
                </td>
                <td>
                  <div className="projects-cell">
                    {trainee.projectsMatched}/{trainee.totalProjects}
                  </div>
                </td>
                <td>
                  <div className="match-rate-cell">
                    <div className="match-rate-bar">
                      <div className="match-rate-fill" style={{ width: `${trainee.matchRate}%` }}></div>
                    </div>
                    <span className="match-rate-value">{trainee.matchRate}%</span>
                  </div>
                </td>
                {/* <td>
                  <div className={`status-badge status-${trainee.status.toLowerCase().replace(' ', '-')}`}>
                    {trainee.status === 'Job Ready' ? <CheckCircle size={12} /> : <Clock size={12} />}
                    {trainee.status}
                  </div>
                </td> */}
                <td>
                  {trainee.currentProject ? (
                    <div className={`project-status-badge status-${trainee.projectStatus}`}>
                      {trainee.projectStatus === 'approved' ? (
                        <>
                          <CheckCircle size={12} />
                          {trainee.currentProject}
                        </>
                      ) : trainee.projectStatus === 'open-pool' ? (
                        <>
                          <Users size={12} />
                          Open Pool
                        </>
                      ) : (
                        <>
                          <Clock size={12} />
                          {trainee.currentProject}
                        </>
                      )}
                    </div>
                  ) : (
                    <div className="project-status-badge status-unassigned">
                      <AlertCircle size={12} />
                      Unassigned
                    </div>
                  )}
                </td>
                <td>
                  <button 
                    className="btn-icon btn-icon-view"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedTrainee(trainee);
                    }}
                  >
                    <Eye size={16} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderReports = () => (
    <div className="reports">
      <div className="section-header">
        <div className="header-title">
          <h2>
            <FileText size={24} />
            Reports Generation
          </h2>
          <p className="subtitle">Generate detailed analytics reports</p>
        </div>
        {/* <div className="report-controls">
          <div className="filter-group">
            <select className="filter-select">
              <option>All Departments</option>
              <option>Technology</option>
              <option>Analytics</option>
              <option>Design</option>
            </select>
            <div className="date-range">
              <input type="date" className="date-input" />
              <span>to</span>
              <input type="date" className="date-input" />
            </div>
            <button className="btn-icon">
              <Download size={18} />
            </button>
          </div>
        </div> */}
      </div>

      <div className="report-types">
        <div className="report-card">
          <div className="report-icon">
            <Users size={24} />
          </div>
          <h3>Trainee Match Report</h3>
          <p>Detailed report of all trainees and their project matches</p>
          <button className="generate-btn">
            <FileText size={16} />
            Generate Report
          </button>
        </div>
        
        <div className="report-card">
          <div className="report-icon">
            <Award size={24} />
          </div>
          <h3>Skill Gap Analysis</h3>
          <p>Analysis of skill gaps across departments</p>
          <button className="generate-btn">
            <BarChart3 size={16} />
            Generate Report
          </button>
        </div>
        
        <div className="report-card">
          <div className="report-icon">
            <MapPin size={24} />
          </div>
          <h3>Location Distribution</h3>
          <p>Trainee distribution across locations</p>
          <button className="generate-btn">
            <PieChart size={16} />
            Generate Report
          </button>
        </div>
        
        <div className="report-card">
          <div className="report-icon">
            <ThumbsUp size={24} />
          </div>
          <h3>Recommendations Report</h3>
          <p>Approval status and TA recommendations</p>
          <button className="generate-btn">
            <CheckCircle size={16} />
            Generate Report
          </button>
        </div>
      </div>

      <div className="recent-reports">
        <h3>Recent Reports</h3>
        <div className="reports-list">
          <div className="report-item">
            <div className="report-info">
              <div className="report-title">
                <FileText size={18} />
                <h4>Q4 2024 Match Analysis</h4>
              </div>
              <p className="report-date">Generated on Dec 15, 2024</p>
            </div>
            <div className="report-actions">
              <button className="btn-icon">
                <Eye size={16} />
              </button>
              <button className="btn-icon">
                <Download size={16} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const JobProfileModal = ({ profile, onClose }) => (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <div className="modal-title">
            <BriefcaseBusiness size={24} />
            <h2>{profile.title}</h2>
          </div>
          <button className="modal-close" onClick={onClose}>
            <X size={24} />
          </button>
        </div>
        
        <div className="modal-body">
          <div className="modal-section">
            <h3>Project Details</h3>
            <div className="project-details-grid">
              <div className="detail-card">
                <div className="detail-icon">
                  <MapPin size={20} />
                </div>
                <div>
                  <div className="detail-label">Location</div>
                  <div className="detail-value">{profile.location}</div>
                </div>
              </div>
              <div className="detail-card">
                <div className="detail-icon">
                  <Folder size={20} />
                </div>
                <div>
                  <div className="detail-label">Active Projects</div>
                  <div className="detail-value">{profile.projects}</div>
                </div>
              </div>
              <div className="detail-card">
                <div className="detail-icon">
                  <Award size={20} />
                </div>
                <div>
                  <div className="detail-label">Required Skills</div>
                  <div className="detail-value skills-list">
                    {profile.requiredSkills.map((skill, idx) => (
                      <span key={idx} className="skill-tag">{skill}</span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="modal-section">
            <h3>Matching Statistics</h3>
            <div className="match-stats-grid">
              {[
                { label: "Total Trainees", value: profile.totalTrainees, icon: Users },
                { label: "Matching Trainees", value: profile.matchingTrainees, icon: CheckCircle },
                { label: "Location Matches", value: profile.locationMatches, icon: MapPin },
                { label: "Skill Matches", value: profile.skillMatches, icon: Award },
                { label: "Complete Matches", value: profile.completeMatches, icon: CheckCircle },
                // { label: "Overall Match Rate", value: `${profile.matchPercentage}%`, icon: Target, highlight: true }
              ].map((stat, index) => {
                const Icon = stat.icon;
                return (
                  <div key={index} className={`match-stat ${stat.highlight ? 'highlight' : ''}`}>
                    <div className="stat-icon">
                      <Icon size={20} />
                    </div>
                    <div className="stat-number">{stat.value}</div>
                    <div className="stat-label">{stat.label}</div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="modal-section">
            <div className="section-header">
              <h3>Top Matching Trainees</h3>
              <div className="toggle-buttons">
                <button 
                  className={`toggle-btn ${showTopN === 5 ? 'active' : ''}`}
                  onClick={() => setShowTopN(5)}
                >
                  Top 5
                </button>
                <button 
                  className={`toggle-btn ${showTopN === 10 ? 'active' : ''}`}
                  onClick={() => setShowTopN(10)}
                >
                  Top 10
                </button>
              </div>
            </div>
            
            <div className="table-container">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Rank</th>
                    <th>Name</th>
                    <th>Location</th>
                    <th>Skills</th>
                    <th>Match Score</th>
                    {/* <th>Status</th> */}
                  </tr>
                </thead>
                <tbody>
                  {profile.topMatches.slice(0, showTopN).map((match, index) => {
                    const trainee = trainees.find(t => t.id === match.id);
                    return (
                      <tr key={match.id}>
                        <td>
                          <div className={`rank-badge rank-${index + 1}`}>
                            {index + 1}
                          </div>
                        </td>
                        <td>
                          <div className="user-cell">
                            <div className="user-avatar-sm">
                              {match.name.charAt(0)}
                            </div>
                            <span>{match.name}</span>
                          </div>
                        </td>
                        <td>
                          <div className="location-cell">
                            <MapPin size={14} />
                            {match.location}
                          </div>
                        </td>
                        <td>
                          <div className="match-skills">
                            {match.skills.slice(0, 2).map((skill, idx) => (
                              <span key={idx} className="skill-tag small">{skill}</span>
                            ))}
                          </div>
                        </td>
                        <td>
                          <div className="score-cell">
                            <div className="score-bar">
                              <div className="score-fill" style={{ width: `${match.matchScore}%` }}></div>
                            </div>
                            <span className="score-value">{match.matchScore}%</span>
                          </div>
                        </td>
                        {/* <td>
                          {trainee ? (
                            <div className={`status-badge status-${trainee.status.toLowerCase().replace(' ', '-')}`}>
                              {trainee.status}
                            </div>
                          ) : (
                            <div className="status-badge status-unknown">
                              Unknown
                            </div>
                          )}
                        </td> */}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
        
        <div className="modal-actions">
          <button className="btn-secondary" onClick={onClose}>
            Close
          </button>
          <button className="btn-primary">
            <FileText size={18} />
            Generate Detailed Report
          </button>
        </div>
      </div>
    </div>
  );

const TraineeModal = ({ trainee, onClose }) => {
  const [traineeData, setTraineeData] = useState({
    id: trainee.id || 1,
    strengths: trainee.strengths || ["BizSkills", "Behavior Skill", "Projects"],
    weakness: trainee.weakness || ["Python", "Java", "WebTech"],
    upskillCourses: trainee.upskillCourses || [
      {
        id: 2,
        courseId: 5386,
        courseName: "Python E1 competency",
        url: "https://ievolveng.ultimatix.net/ievolve/competencydetails/5386",
        platform: "Ievolve"
      },
      {
        id: 11,
        courseId: 5835,
        courseName: "Python- Web Frameworks E1 competency",
        url: "https://ievolveng.ultimatix.net/ievolve/competencydetails/5835",
        platform: "Ievolve"
      },
      {
        id: 1,
        courseId: 3224,
        courseName: "Java E1 competency",
        url: "https://ievolveng.ultimatix.net/ievolve/competencydetails/3224",
        platform: "Ievolve"
      },
      {
        id: 15,
        courseId: 55957,
        courseName: "Node.js E1 competency",
        url: "https://ievolveng.ultimatix.net/ievolve/coursedetails/55957",
        platform: "Ievolve"
      },
      {
        id: 14,
        courseId: 5630,
        courseName: "React.js E1 competency",
        url: "https://ievolveng.ultimatix.net/ievolve/competencydetails/5630",
        platform: "Ievolve"
      }
    ],
    certificates: trainee.certificates || [
      {
        certificateId: 5,
        certificateName: "JAVA",
        provider: "UDEMY",
        acquiredDate: "2025-12-08",
        userId: 1
      },
      {
        certificateId: 6,
        certificateName: "AWS Certified Solutions Architect – Associate",
        provider: "Amazon Web Services",
        acquiredDate: "2024-03-15",
        userId: 1
      },
      {
        certificateId: 7,
        certificateName: "Google Professional Cloud Architect",
        provider: "Google Cloud",
        acquiredDate: "2023-11-05",
        userId: 1
      },
      {
        certificateId: 8,
        certificateName: "Certified Kubernetes Administrator (CKA)",
        provider: "Cloud Native Computing Foundation",
        acquiredDate: "2025-01-10",
        userId: 1
      },
      {
        certificateId: 9,
        certificateName: "Oracle Certified Professional, Java SE 11 Developer",
        provider: "Oracle",
        acquiredDate: "2022-09-30",
        userId: 1
      }
    ],
    userId: trainee.id || 2962,
    username: trainee.name || "Chandini Saketi",
    dpi: trainee.dpi || 1.95,
    location: trainee.location || "Pune",
    isu: trainee.isu || "NGM PS EBU & Delivery Governance ,Risk & Security.",
    batchRank: trainee.batchRank || "258/321",
    groupRank: trainee.groupRank || "20/23",
    average: trainee.average || 36,
    role: trainee.role || "IGNITE TRAINEE"
  });

  // Calculate matching projects based on trainee skills
  const [matchingProjects, setMatchingProjects] = useState([]);
  
  useEffect(() => {
    // In a real app, this would be calculated based on actual matching logic
    const calculatedProjects = [
      {
        id: 1,
        title: "Frontend Developer",
        location: "Pune",
        requiredSkills: ["React", "JavaScript", "CSS", "TypeScript"],
        matchScore: 92,
        matchStatus: "pending", // pending, mapped, open-pool
        matchedSkills: ["React", "JavaScript"],
        missingSkills: ["TypeScript", "CSS"],
        reason: "High match on core frontend skills, needs upskilling in TypeScript"
      },
      {
        id: 2,
        title: "Full Stack Developer",
        location: "Remote",
        requiredSkills: ["Node.js", "React", "MongoDB", "AWS"],
        matchScore: 78,
        matchStatus: "pending",
        matchedSkills: ["React"],
        missingSkills: ["Node.js", "MongoDB", "AWS"],
        reason: "Good frontend foundation, requires backend training"
      },
      {
        id: 3,
        title: "Java Developer",
        location: "Bangalore",
        requiredSkills: ["Java", "Spring Boot", "Microservices", "SQL"],
        matchScore: 45,
        matchStatus: "pending",
        matchedSkills: [],
        missingSkills: ["Java", "Spring Boot", "Microservices", "SQL"],
        reason: "Java identified as weakness area, requires intensive training"
      }
    ];
    setMatchingProjects(calculatedProjects);
  }, [traineeData]);

  const handleMapToProject = (projectId) => {
    setMatchingProjects(projects => 
      projects.map(proj => 
        proj.id === projectId 
          ? { ...proj, matchStatus: "mapped" }
          : proj
      )
    );
    
    // Update the main trainees list
    const updatedTrainees = trainees.map(t => 
      t.id === traineeData.userId 
        ? { 
            ...t, 
            currentProject: matchingProjects.find(p => p.id === projectId)?.title,
            projectStatus: "approved" 
          }
        : t
    );
    
    alert(`Trainee ${traineeData.username} has been mapped to the project successfully!`);
  };

  const handleOpenPool = (projectId) => {
    setMatchingProjects(projects => 
      projects.map(proj => 
        proj.id === projectId 
          ? { ...proj, matchStatus: "open-pool" }
          : proj
      )
    );
    
    // Update the main trainees list
    const updatedTrainees = trainees.map(t => 
      t.id === traineeData.userId 
        ? { 
            ...t, 
            currentProject: "Open Pool",
            projectStatus: "open-pool" 
          }
        : t
    );
    
    alert(`Trainee ${traineeData.username} has been moved to Open Pool for this project.`);
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <div className="trainee-header">
            <div className="avatar-large">{traineeData.username.charAt(0)}</div>
            <div className="trainee-info">
              <h2>{traineeData.username}</h2>
              <div className="trainee-meta">
                <span className="trainee-role">
                  <Briefcase size={16} />
                  {traineeData.role}
                </span>
                <span className="trainee-location">
                  <MapPin size={16} />
                  {traineeData.location}
                </span>
                <span className="trainee-dpi">
                  <Target size={16} />
                  DPI: {traineeData.dpi}
                </span>
              </div>
              <div className="rank-info">
                <span className="rank-item">
                  <Users size={14} />
                  Batch Rank: {traineeData.batchRank}
                </span>
                <span className="rank-item">
                  <Users size={14} />
                  Group Rank: {traineeData.groupRank}
                </span>
                <span className="rank-item">
                  <BarChart2 size={14} />
                  Average: {traineeData.average}%
                </span>
              </div>
            </div>
          </div>
          <button className="modal-close" onClick={onClose}>
            <X size={24} />
          </button>
        </div>
        
        <div className="modal-body">
          {/* Basic Info Section */}
          <div className="modal-section">
            <h3>
              <User size={20} />
              Basic Information
            </h3>
            <div className="info-grid">
              <div className="info-card">
                <div className="info-icon">
                  <Building size={20} />
                </div>
                <div>
                  <div className="info-label">ISU</div>
                  <div className="info-value">{traineeData.isu}</div>
                </div>
              </div>
              <div className="info-card">
                <div className="info-icon">
                  <GraduationCap size={20} />
                </div>
                <div>
                  <div className="info-label">User ID</div>
                  <div className="info-value">{traineeData.userId}</div>
                </div>
              </div>
            </div>
          </div>

          {/* Strengths Section */}
          <div className="modal-section">
            <h3>
              <ThumbsUp size={20} />
              Strengths
            </h3>
            <div className="skills-container">
              <div className="skills-list">
                {traineeData.strengths.map((strength, idx) => (
                  <span key={idx} className="skill-tag success">
                    <Check size={14} />
                    {strength}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Weaknesses Section */}
          <div className="modal-section">
            <h3>
              <AlertCircle size={20} />
              Weaknesses (Require Training)
            </h3>
            <div className="skills-container">
              <div className="skills-list">
                {traineeData.weakness.map((weakness, idx) => (
                  <span key={idx} className="skill-tag danger">
                    <AlertCircle size={14} />
                    {weakness}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Upskill Courses Section */}
          <div className="modal-section">
            <div className="section-header">
              <h3>
                <BookOpen size={20} />
                Recommended Upskill Courses
              </h3>
              <span className="section-count">{traineeData.upskillCourses.length} courses</span>
            </div>
            <div className="courses-list">
              {traineeData.upskillCourses.map((course) => (
                <div key={course.id} className="course-item">
                  <div className="course-info">
                    <div className="course-icon">
                      <BookOpen size={18} />
                    </div>
                    <div className="course-details">
                      <div className="course-name">{course.courseName}</div>
                      <div className="course-meta">
                        <span className="platform">{course.platform}</span>
                        <span className="course-id">ID: {course.courseId}</span>
                      </div>
                    </div>
                  </div>
                  <a 
                    href={course.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="btn-icon btn-icon-view"
                  >
                    <ExternalLink size={16} />
                  </a>
                </div>
              ))}
            </div>
          </div>

          {/* Certificates Section */}
          <div className="modal-section">
            <div className="section-header">
              <h3>
                <Award size={20} />
                Certificates
              </h3>
              <span className="section-count">{traineeData.certificates.length} certificates</span>
            </div>
            <div className="certificates-grid">
              {traineeData.certificates.map((cert) => (
                <div key={cert.certificateId} className="certificate-card">
                  <div className="certificate-icon">
                    <Award size={24} />
                  </div>
                  <div className="certificate-content">
                    <h4>{cert.certificateName}</h4>
                    <div className="certificate-meta">
                      <span className="provider">
                        <Building size={14} />
                        {cert.provider}
                      </span>
                      <span className="date">
                        <Calendar size={14} />
                        {cert.acquiredDate}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Matching Projects Section */}
          <div className="modal-section">
            <div className="section-header">
              <h3>
                <Briefcase size={20} />
                Matching Projects ({matchingProjects.length})
              </h3>
              <div className="filter-buttons">
                <button className="toggle-btn active">All</button>
                <button className="toggle-btn">High Match</button>
                <button className="toggle-btn">Medium Match</button>
              </div>
            </div>
            
            <div className="matching-projects">
              {matchingProjects.map((project) => (
                <div key={project.id} className="project-match-card">
                  <div className="project-match-info">
                    <div className="project-match-header">
                      <h4>{project.title}</h4>
                      <div className="match-score-badge">
                        <Target size={14} />
                        {project.matchScore}% Match
                      </div>
                    </div>
                    
                    <div className="project-match-details">
                      <div className="location-tag">
                        <MapPin size={14} />
                        {project.location}
                      </div>
                      
                      <div className="skills-match-section">
                        <div className="skills-match-row">
                          <div className="skills-label">Matched Skills:</div>
                          <div className="matched-skills">
                            {project.matchedSkills.length > 0 ? (
                              project.matchedSkills.map((skill, idx) => (
                                <span key={idx} className="skill-tag small success">
                                  <Check size={12} />
                                  {skill}
                                </span>
                              ))
                            ) : (
                              <span className="no-skills">No skills matched</span>
                            )}
                          </div>
                        </div>
                        
                        <div className="skills-match-row">
                          <div className="skills-label">Missing Skills:</div>
                          <div className="missing-skills">
                            {project.missingSkills.map((skill, idx) => (
                              <span key={idx} className="skill-tag small danger">
                                <AlertCircle size={12} />
                                {skill}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                      
                      <div className="match-reason">
                        <Lightbulb size={14} />
                        {project.reason}
                      </div>
                    </div>
                  </div>
                  
                  <div className="project-actions">
                    {project.matchStatus === "pending" ? (
                      <>
                        <button 
                          className="btn-secondary btn-sm"
                          onClick={() => handleOpenPool(project.id)}
                        >
                          <Users size={16} />
                          Open Pool
                        </button>
                        <button 
                          className="btn-primary btn-sm"
                          onClick={() => handleMapToProject(project.id)}
                        >
                          <CheckCircle size={16} />
                          Map to Project
                        </button>
                      </>
                    ) : project.matchStatus === "mapped" ? (
                      <div className="status-badge success">
                        <CheckCircle size={16} />
                        Mapped to Project
                      </div>
                    ) : (
                      <div className="status-badge info">
                        <Users size={16} />
                        In Open Pool
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        <div className="modal-actions">
          <button className="btn-secondary" onClick={onClose}>
            Close
          </button>
          <button className="btn-primary">
            <DownloadIcon size={18} />
            Download Profile Report
          </button>
          <button className="btn-secondary">
            <RefreshCw size={18} />
            Refresh Match Data
          </button>
        </div>
      </div>
    </div>
  );
};



  const sidebarItems = [
    { id: 'overview', label: 'Overview', icon: <LayoutDashboard size={20} /> },
    { id: 'job-profiles', label: 'Job Profiles', icon: <Briefcase size={20} /> },
    { id: 'trainees', label: 'Trainees', icon: <Users size={20} /> },
    { id: 'recommendations', label: 'Recommendations', icon: <ThumbsUp size={20} /> },
    // { id: 'analytics', label: 'Analytics', icon: <BarChart3 size={20} /> },
    // { id: 'reports', label: 'Reports', icon: <FileText size={20} /> },
  ];

  return (
    <div className="dashboard">
      <style>{`
        :root {
          --primary: #3b82f6;
          --primary-light: #eff6ff;
          --secondary: #6b7280;
          --success: #10b981;
          --warning: #f59e0b;
          --danger: #ef4444;
          --info: #0ea5e9;
          --background: #f9fafb;
          --card: #ffffff;
          --border: #e5e7eb;
          --text: #111827;
          --text-light: #6b7280;
        }

        /* Add new styles for recommendations */
        .recommendations-stats {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 1rem;
          margin-bottom: 1.5rem;
        }

        .stat-card-small {
          background: var(--card);
          padding: 1rem;
          border-radius: 0.75rem;
          border: 1px solid var(--border);
          display: flex;
          align-items: center;
          gap: 1rem;
        }

        .stat-icon-small {
          width: 2.5rem;
          height: 2.5rem;
          border-radius: 0.75rem;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .stat-icon-small.pending {
          background: #fef3c7;
          color: #92400e;
        }

        .stat-icon-small.approved {
          background: #d1fae5;
          color: #065f46;
        }

        .stat-icon-small.rejected {
          background: #fee2e2;
          color: #991b1b;
        }

        .stat-icon-small.total {
          background: #dbeafe;
          color: #1e40af;
        }

        .stat-content-small {
          flex: 1;
        }

        .stat-value-small {
          font-size: 1.5rem;
          font-weight: 700;
          color: var(--text);
          line-height: 1;
        }

        .stat-label-small {
          font-size: 0.75rem;
          color: var(--text-light);
          margin-top: 0.25rem;
        }

        /* Recommendation row styles */
        .recommendation-row:hover {
          background: var(--primary-light);
        }

        .recommendation-row.status-pending {
          border-left: 3px solid #f59e0b;
        }

        .recommendation-row.status-approved {
          border-left: 3px solid #10b981;
        }

        .recommendation-row.status-rejected {
          border-left: 3px solid #ef4444;
        }

        .project-cell {
          display: flex;
          flex-direction: column;
          gap: 0.25rem;
        }

        .project-name {
          font-weight: 600;
          color: var(--text);
        }

        .project-location {
          display: flex;
          align-items: center;
          gap: 0.375rem;
          font-size: 0.75rem;
          color: var(--text-light);
        }

        .ta-cell {
          display: flex;
          flex-direction: column;
          gap: 0.25rem;
        }

        .ta-name {
          font-weight: 500;
          color: var(--text);
          font-size: 0.875rem;
        }

        .ta-date {
          display: flex;
          align-items: center;
          gap: 0.375rem;
          font-size: 0.75rem;
          color: var(--text-light);
        }

        .score-cell {
          display: flex;
          flex-direction: column;
          gap: 0.5rem;
        }

        .score-badge {
          padding: 0.25rem 0.75rem;
          background: var(--primary-light);
          color: var(--primary);
          border-radius: 1rem;
          font-size: 0.75rem;
          font-weight: 600;
          width: fit-content;
        }

        .skills-match {
          display: flex;
          gap: 0.25rem;
          flex-wrap: wrap;
        }

        .skill-tag.mini {
          padding: 0.125rem 0.5rem;
          font-size: 0.625rem;
          background: #f3f4f6;
          color: var(--text);
        }

        .priority-badge {
          padding: 0.25rem 0.75rem;
          border-radius: 1rem;
          font-size: 0.75rem;
          font-weight: 600;
          width: fit-content;
        }

        .priority-high {
          background: #fee2e2;
          color: #991b1b;
        }

        .priority-medium {
          background: #fef3c7;
          color: #92400e;
        }

        .priority-low {
          background: #e5e7eb;
          color: #374151;
        }

        .recommendation-actions {
          display: flex;
          gap: 0.5rem;
        }

        .btn-icon-approve {
          background: #d1fae5;
          color: #065f46;
          border: 1px solid #a7f3d0;
        }

        .btn-icon-approve:hover {
          background: #a7f3d0;
          color: #064e3b;
          border-color: #065f46;
        }

        .btn-icon-reject {
          background: #fee2e2;
          color: #991b1b;
          border: 1px solid #fecaca;
        }

        .btn-icon-reject:hover {
          background: #fecaca;
          color: #7f1d1d;
          border-color: #991b1b;
        }

        .empty-state {
          text-align: center;
          padding: 3rem;
          background: var(--card);
          border-radius: 1rem;
          border: 2px dashed var(--border);
          margin-top: 1.5rem;
        }

        .empty-state h3 {
          font-size: 1.125rem;
          color: var(--text);
          margin: 1rem 0 0.5rem;
        }

        .empty-state p {
          color: var(--text-light);
          font-size: 0.875rem;
        }

        /* Project status badges in trainees table */
        .project-status-badge {
          padding: 0.375rem 0.75rem;
          border-radius: 9999px;
          font-size: 0.75rem;
          font-weight: 600;
          display: inline-flex;
          align-items: center;
          gap: 0.375rem;
          width: fit-content;
        }

        .status-approved {
          background: #d1fae5;
          color: #065f46;
        }

        .status-pending {
          background: #fef3c7;
          color: #92400e;
        }

        .status-open-pool {
          background: #dbeafe;
          color: #1e40af;
        }

        .status-unassigned {
          background: #e5e7eb;
          color: #374151;
        }

        /* Trainee modal enhancements */
        .current-status {
          margin-bottom: 1rem;
        }

        .status-card {
          display: flex;
          align-items: flex-start;
          gap: 1rem;
          padding: 1rem;
          background: var(--background);
          border-radius: 0.75rem;
        }

        .status-icon {
          width: 3rem;
          height: 3rem;
          border-radius: 0.75rem;
          background: var(--primary-light);
          display: flex;
          align-items: center;
          justify-content: center;
          color: var(--primary);
        }

        .status-content {
          flex: 1;
        }

        .status-content h4 {
          font-size: 0.875rem;
          color: var(--text-light);
          margin-bottom: 0.5rem;
          font-weight: 500;
        }

        .project-assignment {
          padding: 0.75rem;
          border-radius: 0.5rem;
          border-left: 4px solid;
        }

        .project-assignment.status-approved {
          background: #d1fae5;
          border-color: #10b981;
        }

        .project-assignment.status-pending {
          background: #fef3c7;
          border-color: #f59e0b;
        }

        .project-assignment.status-open-pool {
          background: #dbeafe;
          border-color: #3b82f6;
        }

        .project-assignment.status-unassigned {
          background: #e5e7eb;
          border-color: #6b7280;
        }

        .project-assignment strong {
          display: block;
          color: var(--text);
          margin-bottom: 0.25rem;
        }

        .assignment-status {
          display: flex;
          align-items: center;
          gap: 0.375rem;
          font-size: 0.75rem;
        }

        .assignment-status.approved {
          color: #065f46;
        }

        .assignment-status.pending {
          color: #92400e;
        }

        .assignment-status.open-pool {
          color: #1e40af;
        }

        .assignment-status.unassigned {
          color: #374151;
        }

        /* Skills and certifications grid */
        .skills-certifications {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 1.5rem;
        }

        .skills-certifications h4 {
          font-size: 0.875rem;
          color: var(--text-light);
          margin-bottom: 0.75rem;
          font-weight: 500;
        }

        .skills-grid {
          display: flex;
          flex-wrap: wrap;
          gap: 0.5rem;
        }

        .certifications-grid {
          display: flex;
          flex-direction: column;
          gap: 0.5rem;
        }

        .certification-item {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          padding: 0.5rem;
          background: var(--background);
          border-radius: 0.5rem;
          color: var(--text);
          font-size: 0.875rem;
        }

        /* Recommendations in trainee modal */
        .recommendations-list {
          display: flex;
          flex-direction: column;
          gap: 0.75rem;
        }

        .recommendation-item {
          padding: 1rem;
          border-radius: 0.75rem;
          border-left: 4px solid;
        }

        .recommendation-item.status-pending {
          background: #fef3c7;
          border-color: #f59e0b;
        }

        .recommendation-item.status-approved {
          background: #d1fae5;
          border-color: #10b981;
        }

        .recommendation-item.status-rejected {
          background: #fee2e2;
          border-color: #ef4444;
        }

        .recommendation-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          margin-bottom: 0.5rem;
        }

        .recommendation-title {
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }

        .recommendation-title h4 {
          font-size: 0.875rem;
          font-weight: 600;
          color: var(--text);
          margin: 0;
        }

        .recommendation-meta {
          display: flex;
          flex-direction: column;
          gap: 0.25rem;
          font-size: 0.75rem;
          color: var(--text-light);
        }

        .recommendation-reason {
          font-size: 0.875rem;
          color: var(--text);
          margin-bottom: 0.5rem;
          line-height: 1.5;
        }

        .no-recommendations {
          text-align: center;
          padding: 2rem;
          background: var(--background);
          border-radius: 0.75rem;
          color: var(--text-light);
        }

        .no-recommendations p {
          margin-top: 0.5rem;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
          .recommendations-stats {
            grid-template-columns: 1fr 1fr;
          }
          
          .skills-certifications {
            grid-template-columns: 1fr;
          }
          
          .recommendation-actions {
            flex-direction: column;
          }
          
          .btn-icon-approve, .btn-icon-reject {
            width: 100%;
          }
        }

        @media (max-width: 480px) {
          .recommendations-stats {
            grid-template-columns: 1fr;
          }
          
          .recommendation-header {
            flex-direction: column;
            gap: 0.5rem;
          }
        }

        /* Keep all existing styles from the previous version */
        /* All previous CSS styles remain here... */
        
        /* Add these to existing responsive design section */
        @media (max-width: 768px) {
          .trainee-stats {
            grid-template-columns: 1fr 1fr;
          }
          
          .modal-actions {
            flex-direction: column;
          }
          
          .btn-primary, .btn-secondary {
            width: 100%;
          }
        }

        @media (max-width: 480px) {
          .trainee-stats {
            grid-template-columns: 1fr;
          }
        }

      `}</style>

      {/* All existing styles from previous version remain here */}
      <style>{`
        :root {
          --primary: #3b82f6;
          --primary-light: #eff6ff;
          --secondary: #6b7280;
          --success: #10b981;
          --warning: #f59e0b;
          --danger: #ef4444;
          --background: #f9fafb;
          --card: #ffffff;
          --border: #e5e7eb;
          --text: #111827;
          --text-light: #6b7280;
        }

        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }

        body {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
          color: var(--text);
          background: var(--background);
        }

        .dashboard {
          display: flex;
          min-height: 100vh;
        }

        .main-content {
          flex: 1;
          padding: 2rem;
          overflow-y: auto;
          background: var(--background);
        }

        .dashboard-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 2rem;
          padding-bottom: 1.5rem;
          border-bottom: 1px solid var(--border);
        }

        .header-title h1 {
          font-size: 1.875rem;
          font-weight: 700;
          color: var(--text);
          margin-bottom: 0.5rem;
          display: flex;
          align-items: center;
          gap: 0.75rem;
        }

        .header-subtitle {
          color: var(--text-light);
          font-size: 0.875rem;
        }

        .header-actions {
          display: flex;
          gap: 1rem;
          align-items: center;
        }

        /* Stats Grid */
        .stats-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
          gap: 1.5rem;
          margin-bottom: 2rem;
        }

        .stat-card {
          background: var(--card);
          padding: 1.5rem;
          border-radius: 1rem;
          border: 1px solid var(--border);
          display: flex;
          align-items: center;
          gap: 1.25rem;
          transition: all 0.3s ease;
        }

        .stat-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1);
        }

        .stat-icon {
          width: 3.5rem;
          height: 3.5rem;
          border-radius: 0.75rem;
          background: var(--primary-light);
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .stat-icon-svg {
          width: 1.75rem;
          height: 1.75rem;
          color: var(--primary);
        }

        .stat-content {
          flex: 1;
        }

        .stat-content h3 {
          font-size: 0.875rem;
          color: var(--text-light);
          margin-bottom: 0.5rem;
          font-weight: 500;
        }

        .stat-value {
          font-size: 2rem;
          font-weight: 700;
          color: var(--text);
          margin-bottom: 0.25rem;
          line-height: 1;
        }

        .stat-trend {
          display: flex;
          align-items: center;
          gap: 0.375rem;
          font-size: 0.75rem;
          color: var(--success);
          font-weight: 500;
          margin-bottom: 0.5rem;
        }

        .stat-detail {
          display: flex;
          gap: 1rem;
          font-size: 0.75rem;
          color: var(--text-light);
        }

        .stat-detail span {
          padding-right: 1rem;
          border-right: 1px solid var(--border);
        }

        .stat-detail span:last-child {
          border-right: none;
        }

        /* Charts Grid */
        .charts-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
          gap: 1.5rem;
          margin-bottom: 2rem;
        }

        .chart-card {
          background: var(--card);
          padding: 1.5rem;
          border-radius: 1rem;
          border: 1px solid var(--border);
        }

        .card-header {
          display: flex;
          align-items: center;
          gap: 0.75rem;
          margin-bottom: 1.5rem;
        }

        .card-header h3 {
          font-size: 1.125rem;
          font-weight: 600;
          color: var(--text);
        }

        /* Skills Chart */
        .skills-chart {
          display: flex;
          flex-direction: column;
          gap: 1rem;
        }

        .project-skill-row {
          display: flex;
          flex-direction: column;
          gap: 0.75rem;
          padding: 1rem;
          background: var(--background);
          border-radius: 0.75rem;
        }

        .project-info {
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .project-name {
          font-weight: 500;
          color: var(--text);
        }

        .project-meta {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          color: var(--text-light);
          font-size: 0.875rem;
        }

        .trainee-count {
          display: flex;
          align-items: center;
          gap: 0.375rem;
        }

        .skill-tags {
          display: flex;
          flex-wrap: wrap;
          gap: 0.5rem;
        }

        .skill-tag {
          padding: 0.375rem 0.75rem;
          background: var(--primary-light);
          border-radius: 9999px;
          font-size: 0.75rem;
          color: var(--primary);
          font-weight: 500;
        }

        .skill-tag.small {
          padding: 0.25rem 0.5rem;
          font-size: 0.6875rem;
        }

        .skill-tag.large {
          padding: 0.5rem 1rem;
          font-size: 0.875rem;
        }

        /* Matching Stats */
        .matching-stats {
          display: flex;
          flex-direction: column;
          gap: 1rem;
        }

        .match-category {
          display: flex;
          flex-direction: column;
          gap: 0.5rem;
        }

        .category-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .category-label {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          font-size: 0.875rem;
          color: var(--text);
          font-weight: 500;
        }

        .count {
          font-size: 0.875rem;
          font-weight: 600;
          color: var(--text);
        }

        .category-bar {
          height: 0.5rem;
          background: var(--border);
          border-radius: 0.25rem;
          overflow: hidden;
        }

        .bar-fill {
          height: 100%;
          border-radius: 0.25rem;
        }

        /* Job Profiles */
        .job-profiles-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
          gap: 1.5rem;
          margin-top: 1.5rem;
        }

        .job-profile-card {
          background: var(--card);
          padding: 1.5rem;
          border-radius: 1rem;
          border: 1px solid var(--border);
          cursor: pointer;
          transition: all 0.3s ease;
        }

        .job-profile-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1);
        }

        .profile-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          margin-bottom: 1.25rem;
        }

        .profile-title {
          display: flex;
          align-items: center;
          gap: 0.75rem;
        }

        .profile-icon {
          width: 2.5rem;
          height: 2.5rem;
          border-radius: 0.75rem;
          background: var(--primary-light);
          display: flex;
          align-items: center;
          justify-content: center;
          color: var(--primary);
        }

        .profile-title h3 {
          font-size: 1.125rem;
          color: var(--text);
          margin: 0;
        }

        .location-tag {
          padding: 0.375rem 0.75rem;
          background: var(--background);
          border-radius: 9999px;
          font-size: 0.75rem;
          color: var(--text);
          font-weight: 500;
          display: flex;
          align-items: center;
          gap: 0.375rem;
        }

        .profile-stats {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 1rem;
          margin-bottom: 1.25rem;
          padding: 1rem;
          background: var(--background);
          border-radius: 0.75rem;
        }

        .stat-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .stat-label {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          font-size: 0.75rem;
          color: var(--text-light);
        }

        .stat-value {
          font-size: 0.875rem;
          color: var(--text);
          font-weight: 600;
        }

        .stat-value.highlight {
          color: var(--success);
        }

        .skills-container {
          margin-bottom: 1.25rem;
        }

        .skills-container h4 {
          font-size: 0.875rem;
          color: var(--text);
          margin-bottom: 0.75rem;
          font-weight: 500;
        }

        .skills-list {
          display: flex;
          flex-wrap: wrap;
          gap: 0.5rem;
        }

        .matching-breakdown {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 0.75rem;
          margin-bottom: 1.25rem;
        }

        .breakdown-item {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 0.5rem;
          padding: 0.75rem;
          background: var(--background);
          border-radius: 0.75rem;
          text-align: center;
        }

        .breakdown-label {
          display: flex;
          align-items: center;
          gap: 0.375rem;
          font-size: 0.6875rem;
          color: var(--text-light);
        }

        .breakdown-value {
          font-size: 1rem;
          font-weight: 700;
          color: var(--text);
        }

        .view-details-btn {
          width: 100%;
          padding: 0.75rem;
          background: var(--primary);
          color: white;
          border: none;
          border-radius: 0.75rem;
          font-weight: 600;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 0.5rem;
          transition: all 0.2s ease;
        }

        .view-details-btn:hover {
          background: #2563eb;
          transform: translateY(-1px);
          box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }

        /* Trainees Table */
        .table-container {
          overflow-x: auto;
          border-radius: 1rem;
          border: 1px solid var(--border);
          margin-top: 1.5rem;
        }

        .data-table {
          width: 100%;
          border-collapse: collapse;
          font-size: 0.875rem;
        }

        .data-table th {
          text-align: left;
          padding: 1rem;
          background: var(--primary-light);
          color: var(--text-light);
          font-weight: 600;
          font-size: 0.75rem;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          border-bottom: 1px solid var(--border);
        }

        .data-table td {
          padding: 1rem;
          border-bottom: 1px solid var(--border);
          color: var(--text);
        }

        .data-table tr:last-child td {
          border-bottom: none;
        }

        .data-table tr:hover {
          background: var(--primary-light);
        }

        .trainee-info {
          display: flex;
          align-items: center;
          gap: 0.75rem;
        }

        .avatar {
          width: 2.5rem;
          height: 2.5rem;
          border-radius: 50%;
          background: var(--primary);
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 600;
          font-size: 0.875rem;
        }

        .trainee-details {
          display: flex;
          flex-direction: column;
        }

        .name {
          font-weight: 600;
          color: var(--text);
        }

        .email {
          display: flex;
          align-items: center;
          gap: 0.375rem;
          font-size: 0.75rem;
          color: var(--text-light);
        }

        .location-cell {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          color: var(--text-light);
        }

        .skills-preview {
          display: flex;
          align-items: center;
          gap: 0.25rem;
        }

        .more-skills {
          font-size: 0.6875rem;
          color: var(--text-light);
        }

        .projects-cell {
          font-weight: 500;
          color: var(--text);
        }

        .match-rate-cell {
          display: flex;
          align-items: center;
          gap: 0.75rem;
        }

        .match-rate-bar {
          flex: 1;
          height: 0.375rem;
          background: var(--border);
          border-radius: 0.1875rem;
          overflow: hidden;
        }

        .match-rate-fill {
          height: 100%;
          background: linear-gradient(90deg, var(--success), #34d399);
          border-radius: 0.1875rem;
        }

        .match-rate-value {
          font-size: 0.875rem;
          font-weight: 600;
          color: var(--text);
          min-width: 3rem;
          text-align: right;
        }

        .status-badge {
          padding: 0.375rem 0.75rem;
          border-radius: 9999px;
          font-size: 0.75rem;
          font-weight: 600;
          display: inline-flex;
          align-items: center;
          gap: 0.375rem;
        }

        .status-job-ready {
          background: #d1fae5;
          color: #065f46;
        }

        .status-needs-training {
          background: #fef3c7;
          color: #92400e;
        }

        .status-not-ready {
          background: #fee2e2;
          color: #991b1b;
        }

        /* Reports */
        .report-types {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 1.5rem;
          margin-top: 1.5rem;
        }

        .report-card {
          background: var(--card);
          padding: 1.5rem;
          border-radius: 1rem;
          border: 1px solid var(--border);
          text-align: center;
          transition: all 0.3s ease;
        }

        .report-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1);
        }

        .report-icon {
          width: 3rem;
          height: 3rem;
          border-radius: 0.75rem;
          background: var(--primary-light);
          display: flex;
          align-items: center;
          justify-content: center;
          color: var(--primary);
          margin: 0 auto 1rem;
        }

        .report-card h3 {
          font-size: 1rem;
          color: var(--text);
          margin-bottom: 0.5rem;
          font-weight: 600;
        }

        .report-card p {
          color: var(--text-light);
          margin-bottom: 1.5rem;
          font-size: 0.875rem;
          line-height: 1.5;
        }

        .generate-btn {
          width: 100%;
          padding: 0.75rem;
          background: var(--primary);
          color: white;
          border: none;
          border-radius: 0.75rem;
          font-weight: 600;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 0.5rem;
          transition: all 0.2s ease;
        }

        .generate-btn:hover {
          background: #2563eb;
          transform: translateY(-1px);
          box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }

        .recent-reports {
          margin-top: 2rem;
          background: var(--card);
          padding: 1.5rem;
          border-radius: 1rem;
          border: 1px solid var(--border);
        }

        .recent-reports h3 {
          font-size: 1.125rem;
          color: var(--text);
          margin-bottom: 1rem;
          font-weight: 600;
        }

        .reports-list {
          display: flex;
          flex-direction: column;
          gap: 0.75rem;
        }

        .report-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 1rem;
          background: var(--background);
          border-radius: 0.75rem;
        }

        .report-info {
          flex: 1;
        }

        .report-title {
          display: flex;
          align-items: center;
          gap: 0.75rem;
          margin-bottom: 0.25rem;
        }

        .report-title h4 {
          font-size: 0.875rem;
          color: var(--text);
          font-weight: 600;
        }

        .report-date {
          font-size: 0.75rem;
          color: var(--text-light);
        }

        .report-actions {
          display: flex;
          gap: 0.5rem;
        }

        /* Modal */
        .modal-overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.5);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
          padding: 1rem;
          backdrop-filter: blur(4px);
        }

        .modal-content {
          background: var(--card);
          border-radius: 1rem;
          width: 90%;
          max-width: 1000px;
          max-height: 90vh;
          overflow-y: auto;
          box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
          animation: slideIn 0.3s ease;
        }

        @keyframes slideIn {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .modal-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 1.5rem;
          border-bottom: 1px solid var(--border);
        }

        .modal-title {
          display: flex;
          align-items: center;
          gap: 0.75rem;
        }

        .modal-title h2 {
          font-size: 1.5rem;
          font-weight: 700;
          color: var(--text);
        }

        .modal-close {
          background: none;
          border: none;
          color: var(--text-light);
          cursor: pointer;
          padding: 0.5rem;
          border-radius: 0.5rem;
          transition: all 0.2s ease;
        }

        .modal-close:hover {
          background: var(--border);
        }

        .modal-body {
          padding: 1.5rem;
        }

        .modal-section {
          margin-bottom: 2rem;
        }

        .modal-section h3 {
          font-size: 1.125rem;
          color: var(--text);
          margin-bottom: 1rem;
          font-weight: 600;
        }

        .project-details-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 1rem;
          margin-bottom: 1.5rem;
        }

        .detail-card {
          display: flex;
          align-items: center;
          gap: 0.75rem;
          padding: 1rem;
          background: var(--background);
          border-radius: 0.75rem;
        }

        .detail-icon {
          width: 2.5rem;
          height: 2.5rem;
          border-radius: 0.75rem;
          background: var(--primary-light);
          display: flex;
          align-items: center;
          justify-content: center;
          color: var(--primary);
        }

        .detail-label {
          font-size: 0.75rem;
          color: var(--text-light);
          margin-bottom: 0.25rem;
        }

        .detail-value {
          font-size: 0.875rem;
          color: var(--text);
          font-weight: 600;
        }

        .match-stats-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
          gap: 1rem;
          margin-bottom: 1.5rem;
        }

        .match-stat {
          text-align: center;
          padding: 1.5rem 1rem;
          background: var(--background);
          border-radius: 0.75rem;
          transition: all 0.3s ease;
        }

        .match-stat:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .match-stat.highlight {
          background: linear-gradient(135deg, var(--primary), #8b5cf6);
          color: white;
        }

        .match-stat.highlight .stat-icon {
          background: rgba(255, 255, 255, 0.2);
        }

        .match-stat.highlight .stat-icon svg {
          color: white;
        }

        .match-stat.highlight .stat-number,
        .match-stat.highlight .stat-label {
          color: white;
        }

        .match-stat .stat-icon {
          width: 2.5rem;
          height: 2.5rem;
          border-radius: 0.75rem;
          background: var(--primary-light);
          display: flex;
          align-items: center;
          justify-content: center;
          margin: 0 auto 0.75rem;
        }

        .match-stat .stat-icon svg {
          color: var(--primary);
        }

        .stat-number {
          font-size: 1.5rem;
          font-weight: 700;
          color: var(--text);
          margin-bottom: 0.25rem;
          line-height: 1;
        }

        .stat-label {
          font-size: 0.75rem;
          color: var(--text-light);
        }

        .rank-badge {
          width: 2rem;
          height: 2rem;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 600;
          font-size: 0.75rem;
        }

        .rank-1 { background: #fef3c7; color: #92400e; }
        .rank-2 { background: #e5e7eb; color: #374151; }
        .rank-3 { background: #fde68a; color: #92400e; }
        .rank-4, .rank-5, .rank-6, .rank-7, .rank-8, .rank-9, .rank-10 { 
          background: var(--background); 
          color: var(--text-light); 
        }

        .user-cell {
          display: flex;
          align-items: center;
          gap: 0.75rem;
        }

        .user-avatar-sm {
          width: 2rem;
          height: 2rem;
          border-radius: 50%;
          background: var(--primary);
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 600;
          font-size: 0.875rem;
        }

        .score-cell {
          display: flex;
          align-items: center;
          gap: 0.75rem;
        }

        .score-bar {
          flex: 1;
          height: 0.375rem;
          background: var(--border);
          border-radius: 0.1875rem;
          overflow: hidden;
        }

        .score-fill {
          height: 100%;
          background: linear-gradient(90deg, var(--success), #34d399);
          border-radius: 0.1875rem;
        }

        .score-value {
          font-size: 0.875rem;
          font-weight: 600;
          color: var(--text);
          min-width: 3rem;
          text-align: right;
        }

        .modal-actions {
          padding: 1.5rem;
          border-top: 1px solid var(--border);
          display: flex;
          gap: 0.75rem;
          justify-content: flex-end;
        }

        .btn-primary {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          background: var(--primary);
          color: white;
          padding: 0.75rem 1.5rem;
          border: none;
          border-radius: 0.75rem;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .btn-primary:hover {
          background: #2563eb;
          transform: translateY(-1px);
          box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }

        .btn-secondary {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          background: var(--card);
          color: var(--text);
          padding: 0.75rem 1.5rem;
          border: 1px solid var(--border);
          border-radius: 0.75rem;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .btn-secondary:hover {
          background: var(--primary-light);
          border-color: var(--primary);
        }

        /* Trainee Modal Specific */
        .trainee-header {
          display: flex;
          align-items: center;
          gap: 1.5rem;
        }

        .avatar-large {
          width: 4rem;
          height: 4rem;
          border-radius: 50%;
          background: linear-gradient(135deg, var(--primary), #8b5cf6);
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 1.5rem;
          font-weight: 600;
        }

        .trainee-info h2 {
          font-size: 1.5rem;
          color: var(--text);
          margin-bottom: 0.5rem;
          font-weight: 700;
        }

        .trainee-meta {
          display: flex;
          gap: 1.5rem;
          margin-bottom: 0.75rem;
        }

        .trainee-email, .trainee-location {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          color: var(--text-light);
          font-size: 0.875rem;
        }

        .trainee-stats {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
          gap: 1rem;
          margin-bottom: 2rem;
        }

        .trainee-stats .stat-card {
          text-align: center;
          padding: 1.5rem 1rem;
          flex-direction: column;
          gap: 0.75rem;
        }

        .trainee-stats .stat-icon {
          width: 3rem;
          height: 3rem;
        }

        .matching-projects {
          display: flex;
          flex-direction: column;
          gap: 0.75rem;
        }

        .project-match-card {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 1rem;
          background: var(--background);
          border-radius: 0.75rem;
        }

        .project-info h4 {
          margin: 0 0 0.5rem 0;
          color: var(--text);
          font-size: 0.875rem;
          font-weight: 600;
        }

        .project-skills {
          display: flex;
          gap: 0.5rem;
        }

        .match-info {
          display: flex;
          flex-direction: column;
          align-items: flex-end;
          gap: 0.5rem;
        }

        .match-score {
          text-align: right;
        }

        .score-label {
          font-size: 0.75rem;
          color: var(--text-light);
        }

        .score-value {
          font-size: 1rem;
          font-weight: 700;
          color: var(--success);
        }

        .btn-view-match {
          padding: 0.5rem 1rem;
          background: var(--card);
          color: var(--text);
          border: 1px solid var(--border);
          border-radius: 0.5rem;
          font-size: 0.75rem;
          cursor: pointer;
          display: flex;
          align-items: center;
          gap: 0.375rem;
          transition: all 0.2s ease;
        }

        .btn-view-match:hover {
          background: var(--primary-light);
          border-color: var(--primary);
          color: var(--primary);
        }

        /* Quick Actions */
        .quick-actions {
          background: var(--card);
          padding: 1.5rem;
          border-radius: 1rem;
          border: 1px solid var(--border);
        }

        .quick-actions h3 {
          font-size: 1.125rem;
          color: var(--text);
          margin-bottom: 1rem;
          font-weight: 600;
        }

        .action-buttons {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 1rem;
        }

        .action-btn {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 1.25rem;
          background: var(--background);
          border: 2px solid var(--border);
          border-radius: 0.75rem;
          cursor: pointer;
          transition: all 0.3s ease;
          text-align: left;
        }

        .action-btn:hover {
          background: var(--primary-light);
          border-color: var(--primary);
          transform: translateY(-2px);
        }

        .action-icon {
          width: 2.5rem;
          height: 2.5rem;
          border-radius: 0.75rem;
          background: var(--primary-light);
          display: flex;
          align-items: center;
          justify-content: center;
          color: var(--primary);
          margin-right: 1rem;
        }

        .action-btn span {
          flex: 1;
          font-weight: 500;
          color: var(--text);
        }

        .action-arrow {
          color: var(--text-light);
        }

        /* Common Components */
        .section-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 1.5rem;
        }

        .header-title h2 {
          display: flex;
          align-items: center;
          gap: 0.75rem;
          font-size: 1.5rem;
          font-weight: 700;
          color: var(--text);
        }

        .subtitle {
          color: var(--text-light);
          font-size: 0.875rem;
          margin-top: 0.25rem;
        }

        .filter-options {
          display: flex;
          gap: 1rem;
          align-items: center;
        }

        .search-box {
          position: relative;
        }

        .search-box svg {
          position: absolute;
          left: 1rem;
          top: 50%;
          transform: translateY(-50%);
          color: var(--text-light);
        }

        .search-input {
          padding: 0.75rem 1rem 0.75rem 3rem;
          border: 1px solid var(--border);
          border-radius: 0.75rem;
          font-size: 0.875rem;
          background: var(--card);
          min-width: 250px;
        }

        .search-input:focus {
          outline: none;
          border-color: var(--primary);
          box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        .filter-group {
          display: flex;
          gap: 0.5rem;
          align-items: center;
        }

        .btn-filter {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          padding: 0.75rem 1rem;
          background: var(--card);
          border: 1px solid var(--border);
          border-radius: 0.75rem;
          color: var(--text);
          font-size: 0.875rem;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .btn-filter:hover {
          background: var(--primary-light);
          border-color: var(--primary);
        }

        .filter-select {
          padding: 0.75rem;
          border: 1px solid var(--border);
          border-radius: 0.75rem;
          background: var(--card);
          color: var(--text);
          font-size: 0.875rem;
          min-width: 120px;
        }

        .date-range {
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }

        .date-input {
          padding: 0.75rem;
          border: 1px solid var(--border);
          border-radius: 0.75rem;
          font-size: 0.875rem;
          background: var(--card);
          color: var(--text);
        }

        .btn-icon {
          width: 2.5rem;
          height: 2.5rem;
          border-radius: 0.75rem;
          border: 1px solid var(--border);
          background: var(--card);
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          color: var(--text-light);
          transition: all 0.2s ease;
        }

        .btn-icon:hover {
          background: var(--primary-light);
          color: var(--primary);
          border-color: var(--primary);
        }

        .btn-icon-view:hover {
          background: #dbeafe;
          color: #1e40af;
          border-color: #1e40af;
        }

        .toggle-buttons {
          display: flex;
          gap: 0.5rem;
        }

        .toggle-btn {
          padding: 0.5rem 1rem;
          background: var(--background);
          border: 1px solid var(--border);
          border-radius: 0.5rem;
          font-size: 0.75rem;
          color: var(--text);
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .toggle-btn.active {
          background: var(--primary);
          color: white;
          border-color: var(--primary);
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
          .charts-grid {
            grid-template-columns: 1fr;
          }
          
          .job-profiles-grid {
            grid-template-columns: 1fr;
          }
          
          .modal-content {
            width: 95%;
          }
        }

        @media (max-width: 768px) {
          .stats-grid {
            grid-template-columns: 1fr;
          }
          
          .section-header {
            flex-direction: column;
            align-items: stretch;
            gap: 1rem;
          }
          
          .filter-options {
            flex-direction: column;
          }
          
          .search-input {
            min-width: 100%;
          }
          
          .main-content {
            padding: 1.5rem;
          }
          
          .action-buttons {
            grid-template-columns: 1fr;
          }
          
          .match-stats-grid {
            grid-template-columns: repeat(2, 1fr);
          }
          
          .matching-breakdown {
            grid-template-columns: 1fr;
          }
          
          .profile-stats {
            grid-template-columns: 1fr;
          }
        }

        @media (max-width: 480px) {
          .match-stats-grid {
            grid-template-columns: 1fr;
          }
          
          .modal-actions {
            flex-direction: column;
          }
          
          .trainee-meta {
            flex-direction: column;
            gap: 0.5rem;
          }
          
          .trainee-header {
            flex-direction: column;
            text-align: center;
            gap: 1rem;
          }
            /* Add these styles to your existing CSS */

/* Info Grid */
.info-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
  margin-top: 1rem;
}

.info-card {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 1rem;
  background: var(--background);
  border-radius: 0.75rem;
}

.info-icon {
  width: 2.5rem;
  height: 2.5rem;
  border-radius: 0.75rem;
  background: var(--primary-light);
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--primary);
}

.info-label {
  font-size: 0.75rem;
  color: var(--text-light);
  margin-bottom: 0.25rem;
}

.info-value {
  font-size: 0.875rem;
  color: var(--text);
  font-weight: 500;
}

/* Rank Info */
.rank-info {
  display: flex;
  gap: 1.5rem;
  margin-top: 0.75rem;
}

.rank-item {
  display: flex;
  align-items: center;
  gap: 0.375rem;
  font-size: 0.875rem;
  color: var(--text-light);
}

/* Skill Tags with Icons */
.skill-tag.success {
  background: #d1fae5;
  color: #065f46;
  border: 1px solid #a7f3d0;
}

.skill-tag.danger {
  background: #fee2e2;
  color: #991b1b;
  border: 1px solid #fecaca;
}

.skill-tag.small {
  padding: 0.25rem 0.5rem;
  font-size: 0.6875rem;
  display: inline-flex;
  align-items: center;
  gap: 0.25rem;
}

/* Courses List */
.courses-list {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.course-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem;
  background: var(--background);
  border-radius: 0.75rem;
}

.course-info {
  display: flex;
  align-items: center;
  gap: 0.75rem;
}

.course-icon {
  width: 2.5rem;
  height: 2.5rem;
  border-radius: 0.75rem;
  background: var(--primary-light);
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--primary);
}

.course-details {
  flex: 1;
}

.course-name {
  font-weight: 500;
  color: var(--text);
  margin-bottom: 0.25rem;
}

.course-meta {
  display: flex;
  gap: 1rem;
  font-size: 0.75rem;
  color: var(--text-light);
}

/* Certificates Grid */
.certificates-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: 1rem;
}

.certificate-card {
  padding: 1rem;
  background: var(--background);
  border-radius: 0.75rem;
  border: 1px solid var(--border);
  display: flex;
  align-items: center;
  gap: 0.75rem;
}

.certificate-icon {
  width: 2.5rem;
  height: 2.5rem;
  border-radius: 0.75rem;
  background: #fef3c7;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #92400e;
}

.certificate-content {
  flex: 1;
}

.certificate-content h4 {
  font-size: 0.875rem;
  font-weight: 600;
  color: var(--text);
  margin-bottom: 0.375rem;
}

.certificate-meta {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
  font-size: 0.75rem;
  color: var(--text-light);
}

.certificate-meta span {
  display: flex;
  align-items: center;
  gap: 0.375rem;
}

/* Matching Projects */
.matching-projects {
  display: flex;
  flex-direction: column;
  gap: 1rem;
  margin-top: 1rem;
}

.project-match-card {
  padding: 1.5rem;
  background: var(--card);
  border-radius: 1rem;
  border: 1px solid var(--border);
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 1.5rem;
}

.project-match-info {
  flex: 1;
}

.project-match-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
}

.project-match-header h4 {
  font-size: 1.125rem;
  color: var(--text);
  font-weight: 600;
  margin: 0;
}

.match-score-badge {
  padding: 0.375rem 0.75rem;
  background: var(--primary-light);
  color: var(--primary);
  border-radius: 9999px;
  font-size: 0.75rem;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 0.375rem;
}

.project-match-details {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.skills-match-section {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.skills-match-row {
  display: flex;
  gap: 0.75rem;
  align-items: flex-start;
}

.skills-label {
  font-size: 0.75rem;
  color: var(--text-light);
  font-weight: 500;
  min-width: 120px;
  padding-top: 0.25rem;
}

.matched-skills, .missing-skills {
  display: flex;
  flex-wrap: wrap;
  gap: 0.375rem;
}

.no-skills {
  font-size: 0.75rem;
  color: var(--text-light);
  font-style: italic;
}

.match-reason {
  padding: 0.75rem;
  background: #f0f9ff;
  border-radius: 0.5rem;
  font-size: 0.875rem;
  color: var(--text);
  display: flex;
  align-items: flex-start;
  gap: 0.5rem;
  line-height: 1.5;
}

.match-reason svg {
  color: #0ea5e9;
  flex-shrink: 0;
  margin-top: 0.125rem;
}

.project-actions {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  min-width: 150px;
}

.btn-sm {
  padding: 0.5rem 0.75rem;
  font-size: 0.75rem;
  white-space: nowrap;
}

.status-badge.success {
  background: #d1fae5;
  color: #065f46;
  border: 1px solid #a7f3d0;
  padding: 0.5rem 0.75rem;
  border-radius: 0.5rem;
  font-size: 0.75rem;
  font-weight: 600;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.375rem;
}

.status-badge.info {
  background: #dbeafe;
  color: #1e40af;
  border: 1px solid #bfdbfe;
  padding: 0.5rem 0.75rem;
  border-radius: 0.5rem;
  font-size: 0.75rem;
  font-weight: 600;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.375rem;
}

/* Section Header Enhancements */
.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
}

.section-count {
  font-size: 0.875rem;
  color: var(--text-light);
  background: var(--background);
  padding: 0.25rem 0.75rem;
  border-radius: 9999px;
}

.filter-buttons {
  display: flex;
  gap: 0.5rem;
}

/* Responsive adjustments */
@media (max-width: 768px) {
  .project-match-card {
    flex-direction: column;
    gap: 1rem;
  }
  
  .project-actions {
    width: 100%;
  }
  
  .skills-match-row {
    flex-direction: column;
    gap: 0.5rem;
  }
  
  .skills-label {
    min-width: auto;
  }
  
  .certificates-grid {
    grid-template-columns: 1fr;
  }
  
  .rank-info {
    flex-wrap: wrap;
    gap: 0.75rem;
  }
}
        }
      `}</style>

      <Sidebar 
        items={sidebarItems}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        userData={userData}
        onLogout={onLogout}
      />
      
      <div className="main-content">
        <div className="dashboard-header">
          <div className="header-title">
            <h1>
              <LayoutDashboard size={28} />
              Manager Dashboard
            </h1>
            <div className="header-subtitle">
              Welcome, {userData?.name || 'Manager'} | Comprehensive Talent Management Overview
            </div>
          </div>
          {/* <div className="header-actions">
            <button className="btn-primary">
              <DownloadIcon size={18} />
              Export Reports
            </button>
          </div> */}
        </div>
        
        {activeTab === 'overview' && renderOverview()}
        {activeTab === 'job-profiles' && renderJobProfiles()}
        {activeTab === 'trainees' && renderTrainees()}
        {activeTab === 'recommendations' && renderRecommendations()}
        {/* {activeTab === 'reports' && renderReports()} */}
      </div>

      {selectedJobProfile && (
        <JobProfileModal 
          profile={selectedJobProfile} 
          onClose={() => setSelectedJobProfile(null)} 
        />
      )}

      {selectedTrainee && (
        <TraineeModal 
          trainee={selectedTrainee} 
          onClose={() => setSelectedTrainee(null)} 
        />
      )}
    </div>
  );
}

export default DashboardManager;




