// import React, { useState } from 'react';
// import {
//   LayoutDashboard,
//   Briefcase,
//   Users,
//   BarChart2,
//   FileText,
//   ExternalLink,
//   Lightbulb,
//   BarChart3,
//   LogOut,
//   TrendingUp,
//   CheckCircle,
//   Clock,
//   MapPin,
//   DollarSign,
//   Calendar,
//   Edit,
//   Trash2,
//   Eye,
//   Search,
//   Filter,
//   X,
//   ChevronRight,
//   User,
//   Mail,
//   Star,
//   Award,
//   Target,
//   PieChart,
//   Download,
//   Bell,
//   Settings,
//   Plus,
//   ArrowLeft,
//   Check,
//   AlertCircle,
//   Link,
//   GraduationCap,
//   BriefcaseBusiness,
//   Building,
//   Map,
//   DollarSign as Dollar,
//   CalendarDays,
//   BookOpen,
//   Brain,
//   Sparkles,
//   Zap,
//   ThumbsUp,
//   TrendingDown
// } from 'lucide-react';
// import Navbar from './Navbar';
// import Sidebar from './Sidebar';

// function DashboardHR({ userData, onLogout }) {
//   const [activeTab, setActiveTab] = useState('dashboard');
//   const [selectedJob, setSelectedJob] = useState(null);
//   const [selectedTrainee, setSelectedTrainee] = useState(null);
//   const [isEditMode, setIsEditMode] = useState(false);
  
//   const [jobs, setJobs] = useState([
//     { 
//       id: 1, 
//       title: 'Frontend Developer', 
//       department: 'Technology', 
//       location: 'hyderabad', 
//       openings: 5, 
//       filled: 2, 
//       matches: 15, 
//       status: 'active',
//       description: 'Develop and maintain responsive web applications using React.js, TypeScript, and modern frontend technologies.',
//       requirements: '3+ years of React experience, strong JavaScript fundamentals, experience with state management (Redux/MobX)',
//       skills: ['React', 'JavaScript', 'TypeScript', 'CSS', 'HTML5', 'Redux'],
//       salary: '$85,000 - $110,000',
//       postedDate: '2024-01-15',
//       expiryDate: '2024-03-15'
//     },
//     { 
//       id: 2, 
//       title: 'Data Scientist', 
//       department: 'Analytics', 
//       location: 'Remote', 
//       openings: 3, 
//       filled: 1, 
//       matches: 8, 
//       status: 'active',
//       description: 'Build machine learning models and perform data analysis to drive business decisions.',
//       requirements: 'Master\'s in Data Science, experience with Python, ML libraries, and SQL',
//       skills: ['Python', 'Machine Learning', 'SQL', 'Pandas', 'TensorFlow'],
//       salary: '$95,000 - $130,000',
//       postedDate: '2024-01-20',
//       expiryDate: '2024-03-20'
//     },
//     { 
//       id: 3, 
//       title: 'DevOps Engineer', 
//       department: 'Operations', 
//       location: 'chennai', 
//       openings: 4, 
//       filled: 3, 
//       matches: 12, 
//       status: 'active',
//       description: 'Design and implement CI/CD pipelines and manage cloud infrastructure.',
//       requirements: 'Experience with AWS, Docker, Kubernetes, and Terraform',
//       skills: ['AWS', 'Docker', 'Kubernetes', 'Terraform', 'CI/CD'],
//       salary: '$100,000 - $140,000',
//       postedDate: '2024-01-10',
//       expiryDate: '2024-03-10'
//     },
//     { 
//       id: 4, 
//       title: 'UX Designer', 
//       department: 'Design', 
//       location: 'pune', 
//       openings: 2, 
//       filled: 0, 
//       matches: 6, 
//       status: 'inactive',
//       description: 'Create user-centered designs for web and mobile applications.',
//       requirements: 'Portfolio required, experience with Figma, Sketch, and user research',
//       skills: ['Figma', 'UI/UX', 'Prototyping', 'User Research'],
//       salary: '$75,000 - $100,000',
//       postedDate: '2024-01-05',
//       expiryDate: '2024-03-05'
//     },
//   ]);

 
//    // Update the trainee data structure to include the JSON format
// const [trainees, setTrainees] = useState([
//   { 
//     id: 1, 
//     name: 'John Smith', 
//     email: 'john.smith@example.com',
//     skills: ['React', 'JavaScript', 'CSS', 'TypeScript'],
//     score: 85, 
//     status: 'ready', 
//     location: 'hyderabad', 
//     matchedJobs: [
//       { id: 1, title: 'Frontend Developer', matchScore: 92 },
//       { id: 3, title: 'DevOps Engineer', matchScore: 65 }
//     ],
//     evaluations: [
//       { date: '2024-01-15', type: 'Technical', score: 88 },
//       { date: '2023-12-10', type: 'Behavioral', score: 82 }
//     ],
//     certifications: ['React Advanced', 'JavaScript Expert'],
//     preferredLocation: 'hyderabad',
//     experience: '2 years',
//     education: 'B.Tech Computer Science',
    
//     // New JSON format data
//     traineeData: {
//       id: 1,
//       strengths: ["BizSkills", "Behavior Skill", "Projects"],
//       weakness: ["Python", "Java", "WebTech"],
//       upskillCourses: [
//         {
//           id: 2,
//           courseId: 5386,
//           courseName: "Python E1 competency",
//           url: "https://ievolveng.ultimatix.net/ievolve/competencydetails/5386",
//           platform: "Ievolve"
//         },
//         {
//           id: 11,
//           courseId: 5835,
//           courseName: "Python- Web Frameworks E1 competency",
//           url: "https://ievolveng.ultimatix.net/ievolve/competencydetails/5835",
//           platform: "Ievolve"
//         },
//         {
//           id: 1,
//           courseId: 3224,
//           courseName: "Java E1 competency",
//           url: "https://ievolveng.ultimatix.net/ievolve/competencydetails/3224",
//           platform: "Ievolve"
//         }
//       ],
//       certificates: [
//         {
//           certificateId: 5,
//           certificateName: "JAVA",
//           provider: "UDEMY",
//           acquiredDate: "2025-12-08",
//           userId: 1
//         },
//         {
//           certificateId: 6,
//           certificateName: "AWS Certified Solutions Architect – Associate",
//           provider: "Amazon Web Services",
//           acquiredDate: "2024-03-15",
//           userId: 1
//         }
//       ],
//       userId: 2962,
//       username: "John Smith",
//       dpi: 1.95,
//       location: "hyderabad",
//       isu: "NGM PS EBU & Delivery Governance ,Risk & Security.",
//       batchRank: "258/321",
//       groupRank: "20/23",
//       average: 36,
//       role: "IGNITE TRAINEE",
//       isActive: true,
//       projectMatches: []
//     }
//   },
//   // ... other trainees with similar structure
// ]);

// // Add matching projects state
// const [matchingProjects, setMatchingProjects] = useState([]);


// const renderTraineeModal = () => {
//   if (!selectedTrainee) return null;

//   // Calculate matching projects
//   const calculateMatchingProjects = () => {
//     const traineeData = selectedTrainee.traineeData || selectedTrainee;
//     const traineeSkills = [
//       ...(traineeData.strengths || []),
//       ...(selectedTrainee.skills || [])
//     ];
    
//     return jobs.map(job => {
//       const requiredSkills = job.skills || [];
//       const matchedSkills = requiredSkills.filter(skill =>
//         traineeSkills.includes(skill)
//       );
//       const matchScore = Math.round((matchedSkills.length / Math.max(requiredSkills.length, 1)) * 100);
      
//       const isMapped = selectedTrainee.matchedJobs?.some(mj => mj.id === job.id);
//       const isInOpenPool = traineeData.projectMatches?.some(pm => 
//         pm.projectId === job.id && pm.status === 'open-pool'
//       );
      
//       return {
//         ...job,
//         matchScore: isNaN(matchScore) ? 0 : matchScore,
//         matchedSkills,
//         missingSkills: requiredSkills.filter(skill => !matchedSkills.includes(skill)),
//         status: isMapped ? 'mapped' : isInOpenPool ? 'open-pool' : 'pending',
//         reason: matchScore >= 80 ?
//           `Excellent match! ${matchedSkills.length} out of ${requiredSkills.length} skills match.` :
//           matchScore >= 50 ?
//           `Good potential match. Consider additional training for ${requiredSkills.length - matchedSkills.length} skills.` :
//           `Low match. Requires significant training in ${requiredSkills.length - matchedSkills.length} skills.`
//       };
//     }).filter(proj => proj.matchScore > 0)
//       .sort((a, b) => b.matchScore - a.matchScore);
//   };

//   // Action handlers
//   const handleActivateTrainee = () => {
//     setTrainees(trainees.map(t => 
//       t.id === selectedTrainee.id 
//         ? { 
//             ...t, 
//             traineeData: { 
//               ...t.traineeData, 
//               isActive: true,
//               userId: t.traineeData?.userId || t.id
//             },
//             status: 'ready'
//           }
//         : t
//     ));
//     alert(`${selectedTrainee.name} has been activated!`);
//   };

//   const handleDeactivateTrainee = () => {
//     if (window.confirm(`Deactivate ${selectedTrainee.name}?`)) {
//       setTrainees(trainees.map(t => 
//         t.id === selectedTrainee.id 
//           ? { 
//               ...t, 
//               traineeData: { 
//                 ...t.traineeData, 
//                 isActive: false 
//               },
//               status: 'inactive',
//               matchedJobs: []
//             }
//           : t
//       ));
//       alert(`${selectedTrainee.name} has been deactivated.`);
//     }
//   };

//   const handleOpenPool = (projectId) => {
//     const project = jobs.find(p => p.id === projectId);
//     if (!project) return;
    
//     setTrainees(trainees.map(t => 
//       t.id === selectedTrainee.id 
//         ? {
//             ...t,
//             traineeData: {
//               ...t.traineeData,
//               projectMatches: [
//                 ...(t.traineeData?.projectMatches || []),
//                 {
//                   projectId,
//                   projectTitle: project.title,
//                   status: 'open-pool',
//                   date: new Date().toISOString().split('T')[0]
//                 }
//               ]
//             }
//           }
//         : t
//     ));
//     alert(`${selectedTrainee.name} added to Open Pool for ${project.title}.`);
//   };

//   const handleMapToProject = (projectId) => {
//     const project = jobs.find(p => p.id === projectId);
//     if (!project) return;
    
//     if (project.filled >= project.openings) {
//       alert(`No openings available for ${project.title}.`);
//       return;
//     }
    
//     setTrainees(trainees.map(t => 
//       t.id === selectedTrainee.id 
//         ? {
//             ...t,
//             matchedJobs: [
//               ...(t.matchedJobs || []),
//               { 
//                 id: projectId, 
//                 title: project.title, 
//                 matchScore: calculateMatchingProjects().find(p => p.id === projectId)?.matchScore || 0
//               }
//             ],
//             traineeData: {
//               ...t.traineeData,
//               projectMatches: [
//                 ...(t.traineeData?.projectMatches || []),
//                 {
//                   projectId,
//                   projectTitle: project.title,
//                   status: 'mapped',
//                   date: new Date().toISOString().split('T')[0],
//                   mappedBy: userData?.name || 'HR Manager'
//                 }
//               ]
//             }
//           }
//         : t
//     ));
    
//     setJobs(jobs.map(j => 
//       j.id === projectId 
//         ? { ...j, filled: j.filled + 1 }
//         : j
//     ));
//     alert(`${selectedTrainee.name} mapped to ${project.title}!`);
//   };

//   const handleDownloadProfile = () => {
//     const traineeData = selectedTrainee.traineeData || selectedTrainee;
//     const profileData = {
//       basicInfo: {
//         id: selectedTrainee.id,
//         name: selectedTrainee.name,
//         email: selectedTrainee.email,
//         location: selectedTrainee.location,
//         status: selectedTrainee.status,
//         score: selectedTrainee.score
//       },
//       traineeData: traineeData,
//       skills: selectedTrainee.skills || [],
//       certifications: selectedTrainee.certifications || [],
//       evaluations: selectedTrainee.evaluations || [],
//       matchedJobs: selectedTrainee.matchedJobs || [],
//       generatedAt: new Date().toISOString(),
//       generatedBy: userData?.name || 'HR Dashboard'
//     };
    
//     const dataStr = JSON.stringify(profileData, null, 2);
//     const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);
//     const exportFileDefaultName = `${selectedTrainee.name.replace(/\s+/g, '_')}_profile_${new Date().toISOString().split('T')[0]}.json`;
    
//     const linkElement = document.createElement('a');
//     linkElement.setAttribute('href', dataUri);
//     linkElement.setAttribute('download', exportFileDefaultName);
//     document.body.appendChild(linkElement);
//     linkElement.click();
//     document.body.removeChild(linkElement);
//   };

//   const traineeData = selectedTrainee.traineeData || selectedTrainee;
//   const matchingProjects = calculateMatchingProjects();

//   return (
//     <div className="modal-overlay" onClick={() => setSelectedTrainee(null)}>
//       <div className="modal-content" onClick={e => e.stopPropagation()}>
//         {/* Modal Header */}
//         <div className="modal-header">
//           <div className="modal-title">
//             <User size={24} />
//             <h2>{traineeData.username || selectedTrainee.name}</h2>
//           </div>
//           <button className="modal-close" onClick={() => setSelectedTrainee(null)}>
//             <X size={24} />
//           </button>
//         </div>

//         {/* Modal Body */}
//         <div className="modal-body">
//           {/* Profile Header */}
//           <div className="profile-header">
//             <div className="profile-avatar">
//               {traineeData.username?.charAt(0) || selectedTrainee.name.charAt(0)}
//             </div>
//             <div className="profile-info">
//               <h3>{traineeData.username || selectedTrainee.name}</h3>
//               <div className="profile-role">{traineeData.role || 'TRAINEE'}</div>
//               <div className="profile-meta">
//                 <span className="profile-meta-item">
//                   <MapPin size={16} />
//                   {traineeData.location || selectedTrainee.location}
//                 </span>
//                 <span className="profile-meta-item">
//                   <Mail size={16} />
//                   {selectedTrainee.email}
//                 </span>
//                 <span className="profile-meta-item">
//                   <Target size={16} />
//                   DPI: {traineeData.dpi || 'N/A'}
//                 </span>
//                 <span className="profile-meta-item">
//                   <BarChart2 size={16} />
//                   Score: {selectedTrainee.score}%
//                 </span>
//               </div>
//             </div>
//             <div className="profile-actions">
//             </div>
//           </div>

//           {/* Basic Info Grid */}
//           <div className="info-grid">
//             <div className="info-card">
//               <h4>
//                 <User size={16} />
//                 Basic Information
//               </h4>
//               <div className="info-content">
//                 <div className="info-row">
//                   <span className="info-label">User ID</span>
//                   <span className="info-value">{traineeData.userId || 'N/A'}</span>
//                 </div>
//                 <div className="info-row">
//                   <span className="info-label">ISU</span>
//                   <span className="info-value">{traineeData.isu || 'N/A'}</span>
//                 </div>
//                 <div className="info-row">
//                   <span className="info-label">Batch Rank</span>
//                   <span className="info-value">{traineeData.batchRank || 'N/A'}</span>
//                 </div>
//                 <div className="info-row">
//                   <span className="info-label">Group Rank</span>
//                   <span className="info-value">{traineeData.groupRank || 'N/A'}</span>
//                 </div>
//                 <div className="info-row">
//                   <span className="info-label">Average</span>
//                   <span className="info-value">{traineeData.average || 0}%</span>
//                 </div>
//               </div>
//             </div>
//             <div className="info-card">
//               <h4>
//                 <Briefcase size={16} />
//                 Employment Details
//               </h4>
//               <div className="info-content">
//                 <div className="info-row">
//                   <span className="info-label">Experience</span>
//                   <span className="info-value">{selectedTrainee.experience || 'N/A'}</span>
//                 </div>
//                 <div className="info-row">
//                   <span className="info-label">Education</span>
//                   <span className="info-value">{selectedTrainee.education || 'N/A'}</span>
//                 </div>
//                 <div className="info-row">
//                   <span className="info-label">Preferred Location</span>
//                   <span className="info-value">{selectedTrainee.preferredLocation || 'N/A'}</span>
//                 </div>
//                 <div className="info-row">
//                   <span className="info-label">Status</span>
//                   <span className="info-value">{selectedTrainee.status === 'ready' ? 'Job Ready' : selectedTrainee.status === 'training' ? 'In Training' : 'Inactive'}</span>
//                 </div>
//                 <div className="info-row">
//                   <span className="info-label">Projects Matched</span>
//                   <span className="info-value">{selectedTrainee.matchedJobs?.length || 0}</span>
//                 </div>
//               </div>
//             </div>
//           </div>

//           {/* Skills Section */}
//           <div className="skills-section">
//             <h3 className="section-title">Skills Assessment</h3>
//             <div className="skills-container">
//               <div className="skills-column">
//                 <h4>
//                   <ThumbsUp size={16} />
//                   Strengths
//                 </h4>
//                 <div className="skills-list">
//                   {(traineeData.strengths || []).map((strength, idx) => (
//                     <span key={idx} className="skill-tag success">
//                       <Check size={14} />
//                       {strength}
//                     </span>
//                   ))}
//                 </div>
//               </div>
//               <div className="skills-column">
//                 <h4>
//                   <AlertCircle size={16} />
//                   Areas for Improvement
//                 </h4>
//                 <div className="skills-list">
//                   {(traineeData.weakness || []).map((weakness, idx) => (
//                     <span key={idx} className="skill-tag danger">
//                       <AlertCircle size={14} />
//                       {weakness}
//                     </span>
//                   ))}
//                 </div>
//               </div>
//             </div>
//           </div>

//           {/* Upskill Courses */}
//           <div className="courses-section">
//             <h3 className="section-title">
//               <BookOpen size={18} />
//               Recommended Upskill Courses
//               <span style={{ marginLeft: '8px', fontSize: '14px', color: 'var(--text-light)' }}>
//                 ({traineeData.upskillCourses?.length || 0})
//               </span>
//             </h3>
//             <div className="courses-grid">
//               {(traineeData.upskillCourses || []).map(course => (
//                 <div key={course.id} className="course-card">
//                   <div className="course-icon">
//                     <BookOpen size={20} />
//                   </div>
//                   <div className="course-content">
//                     <div className="course-title">{course.courseName}</div>
//                     <div className="course-meta">
//                       <span>{course.platform}</span>
//                       <a href={course.url} target="_blank" rel="noopener noreferrer" className="course-link">
//                         View Course <ExternalLink size={12} />
//                       </a>
//                     </div>
//                   </div>
//                 </div>
//               ))}
//             </div>
//           </div>

//           {/* Certificates */}
//           <div className="certificates-section">
//             <h3 className="section-title">
//               <Award size={18} />
//               Certifications
//               <span style={{ marginLeft: '8px', fontSize: '14px', color: 'var(--text-light)' }}>
//                 ({traineeData.certificates?.length || 0})
//               </span>
//             </h3>
//             <div className="certificates-grid">
//               {(traineeData.certificates || []).map(cert => (
//                 <div key={cert.certificateId} className="certificate-card">
//                   <div className="certificate-icon">
//                     <Award size={24} />
//                   </div>
//                   <div className="certificate-content">
//                     <div className="certificate-name">{cert.certificateName}</div>
//                     <div className="certificate-details">
//                       <span>
//                         <Building size={12} />
//                         {cert.provider}
//                       </span>
//                       <span>
//                         <Calendar size={12} />
//                         {cert.acquiredDate}
//                       </span>
//                     </div>
//                   </div>
//                 </div>
//               ))}
//             </div>
//           </div>

//           {/* Matching Projects */}
//           <div className="projects-section">
//             <div className="projects-header">
//               <h3 className="section-title">
//                 <Briefcase size={18} />
//                 Project Matching
//                 <span style={{ marginLeft: '8px', fontSize: '14px', color: 'var(--text-light)' }}>
//                   ({matchingProjects.length} projects)
//                 </span>
//               </h3>
//               <div className="projects-stats">
//                 <span className="stat-item">
//                   <Target size={16} />
//                   {matchingProjects.filter(p => p.matchScore >= 80).length} High
//                 </span>
//                 <span className="stat-item">
//                   <TrendingUp size={16} />
//                   {matchingProjects.filter(p => p.matchScore >= 50 && p.matchScore < 80).length} Medium
//                 </span>
//                 <span className="stat-item">
//                   <TrendingDown size={16} />
//                   {matchingProjects.filter(p => p.matchScore < 50).length} Low
//                 </span>
//               </div>
//             </div>

//             <div className="projects-grid">
//               {matchingProjects.map(project => {
//                 const isMapped = project.status === 'mapped';
//                 const isOpenPool = project.status === 'open-pool';
//                 const isAvailable = project.openings > project.filled;

//                 return (
//                   <div key={project.id} className={`project-card ${isMapped ? 'mapped' : isOpenPool ? 'open-pool' : ''}`}>
//                     <div className="project-header">
//                       <div className="project-title">
//                         <h4>{project.title}</h4>
//                         <div className="project-meta">
//                           <span>
//                             <Building size={14} />
//                             {project.department}
//                           </span>
//                           <span>
//                             <MapPin size={14} />
//                             {project.location}
//                           </span>
//                           <span>
//                             <DollarSign size={14} />
//                             {project.salary}
//                           </span>
//                         </div>
//                       </div>
//                       <div className={`match-badge ${project.matchScore >= 80 ? 'high' : project.matchScore >= 50 ? 'medium' : 'low'}`}>
//                         <Target size={14} />
//                         {project.matchScore}% Match
//                       </div>
//                     </div>

//                     <div className="skills-display">
//                       <div className="skill-group">
//                         <div className="skill-group-label">Matched Skills</div>
//                         <div className="skill-tags-container">
//                           {project.matchedSkills.map(skill => (
//                             <span key={skill} className="skill-tag success">
//                               <Check size={12} />
//                               {skill}
//                             </span>
//                           ))}
//                           {project.matchedSkills.length === 0 && (
//                             <span className="no-skills">No skills matched</span>
//                           )}
//                         </div>
//                       </div>
//                       <div className="skill-group">
//                         <div className="skill-group-label">Missing Skills</div>
//                         <div className="skill-tags-container">
//                           {project.missingSkills.map(skill => (
//                             <span key={skill} className="skill-tag danger">
//                               <AlertCircle size={12} />
//                               {skill}
//                             </span>
//                           ))}
//                         </div>
//                       </div>
//                     </div>

//                     <div className="project-details">
//                       <div className="reason">{project.reason}</div>
//                       <div className="openings-info">
//                         <span>
//                           <Users size={14} />
//                           Openings: {project.openings - project.filled} remaining
//                         </span>
//                         <span>
//                           <Calendar size={14} />
//                           Expires: {project.expiryDate}
//                         </span>
//                       </div>
//                     </div>

//                     <div className="project-actions">
//                       {isMapped ? (
//                         <div className="status-indicator success">
//                           <CheckCircle size={16} />
//                           Mapped to Project
//                         </div>
//                       ) : isOpenPool ? (
//                         <div className="status-indicator info">
//                           <Users size={16} />
//                           In Open Pool
//                         </div>
//                       ) : (
//                         <>
//                           <button className="btn-secondary" onClick={() => handleOpenPool(project.id)}>
//                             <Users size={16} />
//                             Open Pool
//                           </button>
//                           <button 
//                             className="btn-primary" 
//                             onClick={() => handleMapToProject(project.id)}
//                             disabled={!isAvailable}
//                           >
//                             <CheckCircle size={16} />
//                             {isAvailable ? 'Map to Project' : 'No Openings'}
//                           </button>
//                         </>
//                       )}
//                     </div>
//                   </div>
//                 );
//               })}
//             </div>

//             {matchingProjects.length === 0 && (
//               <div className="no-matches">
//                 <AlertCircle size={48} style={{ color: 'var(--text-light)', marginBottom: '16px' }} />
//                 <p style={{ color: 'var(--text-light)', marginBottom: '16px' }}>No matching projects found. Consider training in required skills.</p>
//                 <button className="btn-secondary">
//                   <Sparkles size={16} />
//                   Generate AI Recommendations
//                 </button>
//               </div>
//             )}
//           </div>
//         </div>

//         {/* Modal Footer */}
//         <div className="modal-footer">
//           <div>
//             <span style={{ fontSize: '14px', color: 'var(--text-light)' }}>
//               Last updated: {new Date().toLocaleDateString()}
//             </span>
//           </div>
//           <div className="footer-actions">
//             <button className="btn-outline" onClick={() => setSelectedTrainee(null)}>
//               <X size={16} />
//               Close
//             </button>
//             <button className="btn-outline" onClick={handleDownloadProfile}>
//               <Download size={16} />
//               Export Profile
//             </button>
//             <button className="btn-primary" onClick={() => {
//               alert('AI recommendations generated successfully!');
//             }}>
//               <Sparkles size={16} />
//               Generate AI Matches
//             </button>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

//   const [newJob, setNewJob] = useState({
//     title: '',
//     department: '',
//     location: '',
//     openings: 1,
//     requirements: '',
//     skills: [],
//     description: '',
//     salary: '',
//     expiryDate: ''
//   });

//   // Statistics Calculations
//   const calculateStatistics = () => {
//     const totalTrainees = trainees.length;
//     const totalJobs = jobs.length;
//     const mappedTrainees = trainees.filter(t => t.matchedJobs.length > 0).length;
//     const unmappedTrainees = totalTrainees - mappedTrainees;
//     const readyTrainees = trainees.filter(t => t.status === 'ready').length;
//     const trainingTrainees = trainees.filter(t => t.status === 'training').length;
//     const activeJobs = jobs.filter(j => j.status === 'active').length;
//     const filledPositions = jobs.reduce((sum, job) => sum + job.filled, 0);
//     const totalOpenings = jobs.reduce((sum, job) => sum + job.openings, 0);
//     const fillRate = totalOpenings > 0 ? Math.round((filledPositions / totalOpenings) * 100) : 0;

//     return {
//       totalTrainees,
//       totalJobs,
//       mappedTrainees,
//       unmappedTrainees,
//       readyTrainees,
//       trainingTrainees,
//       activeJobs,
//       filledPositions,
//       totalOpenings,
//       fillRate
//     };
//   };

//   const stats = calculateStatistics();

//   const renderDashboard = () => {
//     return (
//       <div className="dashboard-content">
//         <div className="stats-grid">
//           <div className="stat-card">
//             <div className="stat-icon">
//               <Users className="stat-icon-svg" />
//             </div>
//             <div className="stat-content">
//               <h3>Total Trainees</h3>
//               <div className="stat-value">{stats.totalTrainees}</div>
              
//             </div>
//           </div>
          
//           <div className="stat-card">
//             <div className="stat-icon">
//               <BriefcaseBusiness className="stat-icon-svg" />
//             </div>
//             <div className="stat-content">
//               <h3>Total Jobs</h3>
//               <div className="stat-value">{stats.totalJobs}</div>
             
//             </div>
//           </div>
          
//           <div className="stat-card">
//             <div className="stat-icon">
//               <CheckCircle className="stat-icon-svg" />
//             </div>
//             <div className="stat-content">
//               <h3>Mapped Trainees</h3>
//               <div className="stat-value">{stats.mappedTrainees}</div>
              
//             </div>
//           </div>
          
//           <div className="stat-card">
//             <div className="stat-icon">
//               <AlertCircle className="stat-icon-svg" />
//             </div>
//             <div className="stat-content">
//               <h3>Unmapped Trainees</h3>
//               <div className="stat-value">{stats.unmappedTrainees}</div>
              
//             </div>
//           </div>
          
//           <div className="stat-card">
//             <div className="stat-icon">
//               <Target className="stat-icon-svg" />
//             </div>
//             <div className="stat-content">
//               <h3>Job Ready</h3>
//               <div className="stat-value">{stats.readyTrainees}</div>
             
//             </div>
//           </div>
          
          
//         </div>

//         <div className="content-grid">
//           <div className="content-card">
//             <div className="card-header">
//               <h3>
//                 <Briefcase size={20} />
//                 Recent Job Matches
//               </h3>
//               <button className="btn-text">
//                 View All <ChevronRight size={16} />
//               </button>
//             </div>
//             <div className="table-container">
//               <table className="data-table">
//                 <thead>
//                   <tr>
//                     <th>Trainee</th>
//                     <th>Job Role</th>
//                     <th>Match Score</th>
//                     <th>Location</th>
//                     <th>Status</th>
//                   </tr>
//                 </thead>
//                 <tbody>
//                   {trainees.flatMap(trainee => 
//                     trainee.matchedJobs.map(job => ({
//                       trainee,
//                       job,
//                       jobDetails: jobs.find(j => j.id === job.id)
//                     }))
//                   ).slice(0, 5).map((match, index) => (
//                     <tr key={index}>
//                       <td>
//                         <div className="user-cell">
//                           <div className="user-avatar-sm">
//                             {match.trainee.name.charAt(0)}
//                           </div>
//                           <span>{match.trainee.name}</span>
//                         </div>
//                       </td>
//                       <td>{match.jobDetails?.title || match.job.title}</td>
//                       <td>
//                         <div className={`score-badge ${match.job.matchScore >= 90 ? 'score-high' : match.job.matchScore >= 75 ? 'score-medium' : 'score-low'}`}>
//                           {match.job.matchScore}%
//                         </div>
//                       </td>
//                       <td>
//                         <div className="location-cell">
//                           <MapPin size={14} />
//                           {match.trainee.location}
//                         </div>
//                       </td>
//                       <td>
//                         <div className={`status-badge ${match.job.matchScore >= 80 ? 'status-approved' : 'status-pending'}`}>
//                           {match.job.matchScore >= 80 ? (
//                             <>
//                               <ThumbsUp size={14} />
//                               High Match
//                             </>
//                           ) : (
//                             <>
//                               <Clock size={14} />
//                               Review
//                             </>
//                           )}
//                         </div>
//                       </td>
//                     </tr>
//                   ))}
//                 </tbody>
//               </table>
//             </div>
//           </div>

//           <div className="content-card">
//             <div className="card-header">
//               <h3>
//                 <Brain size={20} />
//                 Top Skills in Demand
//               </h3>
//               <button className="btn-text">
//                 View All <ChevronRight size={16} />
//               </button>
//             </div>
//             <div className="skills-list">
//               {[
//                 { name: 'React', demand: 95, jobs: 8 },
//                 { name: 'Python', demand: 92, jobs: 6 },
//                 { name: 'AWS', demand: 88, jobs: 5 },
//                 { name: 'Machine Learning', demand: 85, jobs: 4 },
//                 { name: 'UI/UX', demand: 82, jobs: 3 },
//                 { name: 'DevOps', demand: 78, jobs: 4 },
//               ].map(skill => (
//                 <div key={skill.name} className="skill-item">
//                   <div className="skill-header">
//                     <span className="skill-name">{skill.name}</span>
//                     <div className="skill-stats">
//                       <span className="skill-jobs">{skill.jobs} jobs</span>
//                       <span className="skill-demand">{skill.demand}%</span>
//                     </div>
//                   </div>
//                   <div className="skill-bar">
//                     <div 
//                       className="skill-fill" 
//                       style={{ width: `${skill.demand}%` }}
//                     ></div>
//                   </div>
//                 </div>
//               ))}
//             </div>
//           </div>
//         </div>
//       </div>
//     );
//   };

//   const renderJobManagement = () => (
//     <div className="job-management">
//       <div className="section-header">
//         <div className="header-title">
//           <h2>
//             <Briefcase size={24} />
//             Job Profiles Management
//           </h2>
//           <p className="subtitle">Manage and track all job positions</p>
//         </div>
//         <button 
//           className="btn-primary"
//           onClick={() => {
//             setSelectedJob(null);
//             setIsEditMode(false);
//             setActiveTab('createJob');
//           }}
//         >
//           <Plus size={18} />
//           Create New Job
//         </button>
//       </div>

//       <div className="table-container">
//         <table className="data-table">
//           <thead>
//             <tr>
//               <th>Job Title</th>
//               <th>Department</th>
//               <th>Location</th>
//               <th>Openings</th>
//               <th>Filled</th>
//               <th>Matches</th>
//               <th>Status</th>
//               <th>Actions</th>
//             </tr>
//           </thead>
//           <tbody>
//             {jobs.map(job => (
//               <tr key={job.id}>
//                 <td>
//                   <div className="job-title-cell">
//                     <div className="job-icon">
//                       <BriefcaseBusiness size={16} />
//                     </div>
//                     <span className="font-medium">{job.title}</span>
//                   </div>
//                 </td>
//                 <td>
//                   <div className="department-cell">
//                     <Building size={14} />
//                     {job.department}
//                   </div>
//                 </td>
//                 <td>
//                   <div className="location-cell">
//                     <MapPin size={14} />
//                     {job.location}
//                   </div>
//                 </td>
//                 <td>
//                   <div className="openings-cell">
//                     {job.openings}
//                   </div>
//                 </td>
//                 <td>
//                   <div className={`filled-cell ${job.filled === job.openings ? 'filled-complete' : ''}`}>
//                     {job.filled}/{job.openings}
//                   </div>
//                 </td>
//                 <td>
//                   <div className="matches-cell">
//                     {job.matches}
//                   </div>
//                 </td>
//                 <td>
//                   <div className={`status-badge status-${job.status}`}>
//                     {job.status === 'active' ? 'Active' : 'Inactive'}
//                   </div>
//                 </td>
//                 <td>
//                   <div className="action-buttons">
//                     <button 
//                       className="btn-icon btn-icon-view"
//                       onClick={() => {
//                         setSelectedJob(job);
//                         setIsEditMode(false);
//                       }}
//                     >
//                       <Eye size={16} />
//                     </button>
//                     <button 
//                       className="btn-icon btn-icon-edit"
//                       onClick={() => {
//                         setSelectedJob(job);
//                         setIsEditMode(true);
//                         setActiveTab('createJob');
//                       }}
//                     >
//                       <Edit size={16} />
//                     </button>
//                     <button 
//                       className="btn-icon btn-icon-delete"
//                       onClick={() => handleDeleteJob(job.id)}
//                     >
//                       <Trash2 size={16} />
//                     </button>
//                   </div>
//                 </td>
//               </tr>
//             ))}
//           </tbody>
//         </table>
//       </div>
//     </div>
//   );

//   const renderCreateJob = () => {
//     const jobToEdit = selectedJob || newJob;
//     const isEditing = !!selectedJob && isEditMode;

//     return (
//       <div className="create-job">
//         <div className="section-header">
//           <div className="header-title">
//             <h2>
//               {isEditing ? (
//                 <>
//                   <Edit size={24} />
//                   Edit Job Profile
//                 </>
//               ) : (
//                 <>
//                   <Plus size={24} />
//                   Create New Job Profile
//                 </>
//               )}
//             </h2>
//             <p className="subtitle">
//               {isEditing ? 'Update existing job details' : 'Fill in the details to create a new job position'}
//             </p>
//           </div>
//           <button 
//             className="btn-secondary"
//             onClick={() => {
//               setSelectedJob(null);
//               setIsEditMode(false);
//               setActiveTab('jobs');
//               setNewJob({
//                 title: '',
//                 department: '',
//                 location: '',
//                 openings: 1,
//                 requirements: '',
//                 skills: [],
//                 description: '',
//                 salary: '',
//                 expiryDate: ''
//               });
//             }}
//           >
//             <ArrowLeft size={18} />
//             Back to Jobs
//           </button>
//         </div>

//         <div className="form-card">
//           <form onSubmit={(e) => {
//             e.preventDefault();
//             if (isEditing) {
//               handleUpdateJob(jobToEdit);
//             } else {
//               handleCreateJob();
//             }
//           }}>
//             <div className="form-section">
//               <h3 className="form-section-title">
//                 <Briefcase size={20} />
//                 Basic Information
//               </h3>
//               <div className="form-row">
//                 <div className="form-group">
//                   <label>
//                     <span className="required">*</span>
//                     Job Title
//                   </label>
//                   <input
//                     type="text"
//                     className="form-control"
//                     value={jobToEdit.title}
//                     onChange={(e) => isEditing ? 
//                       setSelectedJob({...jobToEdit, title: e.target.value}) :
//                       setNewJob({...newJob, title: e.target.value})
//                     }
//                     required
//                     placeholder="e.g., Senior Frontend Developer"
//                   />
//                 </div>
//                 <div className="form-group">
//                   <label>
//                     <span className="required">*</span>
//                     Department
//                   </label>
//                   <select
//                     className="form-control"
//                     value={jobToEdit.department}
//                     onChange={(e) => isEditing ? 
//                       setSelectedJob({...jobToEdit, department: e.target.value}) :
//                       setNewJob({...newJob, department: e.target.value})
//                     }
//                     required
//                   >
//                     <option value="">Select Department</option>
//                     <option value="Technology">Technology</option>
//                     <option value="Analytics">Analytics</option>
//                     <option value="Design">Design</option>
//                     <option value="Operations">Operations</option>
//                     <option value="Marketing">Marketing</option>
//                     <option value="Sales">Sales</option>
//                   </select>
//                 </div>
//               </div>

//               <div className="form-row">
//                 <div className="form-group">
//                   <label>
//                     <span className="required">*</span>
//                     Location
//                   </label>
//                   <input
//                     type="text"
//                     className="form-control"
//                     value={jobToEdit.location}
//                     onChange={(e) => isEditing ? 
//                       setSelectedJob({...jobToEdit, location: e.target.value}) :
//                       setNewJob({...newJob, location: e.target.value})
//                     }
//                     required
//                     placeholder="e.g., Pune Chennai"
//                   />
//                 </div>
//                 <div className="form-group">
//                   <label>
//                     <span className="required">*</span>
//                     Number of Openings
//                   </label>
//                   <input
//                     type="number"
//                     className="form-control"
//                     value={jobToEdit.openings}
//                     onChange={(e) => isEditing ? 
//                       setSelectedJob({...jobToEdit, openings: parseInt(e.target.value) || 1}) :
//                       setNewJob({...newJob, openings: parseInt(e.target.value) || 1})
//                     }
//                     min="1"
//                     required
//                   />
//                 </div>
//               </div>

//               <div className="form-row">
                
//                 <div className="form-group">
//                   <label>
//                     <Calendar size={16} />
//                     Expiry Date
//                   </label>
//                   <input
//                     type="date"
//                     className="form-control"
//                     value={jobToEdit.expiryDate}
//                     onChange={(e) => isEditing ? 
//                       setSelectedJob({...jobToEdit, expiryDate: e.target.value}) :
//                       setNewJob({...newJob, expiryDate: e.target.value})
//                     }
//                   />
//                 </div>
//               </div>
//             </div>

//             <div className="form-section">
//               <h3 className="form-section-title">
//                 <BookOpen size={20} />
//                 Requirements & Skills
//               </h3>
//               <div className="form-group">
//                 <label>
//                   <span className="required">*</span>
//                   Required Skills
//                 </label>
//                 <div className="skills-input">
//                   <input
//                     type="text"
//                     className="form-control"
//                     placeholder="Type skill and press Enter or use comma separation"
//                     value={Array.isArray(jobToEdit.skills) ? jobToEdit.skills.join(', ') : jobToEdit.skills}
//                     onChange={(e) => {
//                       const skillsArray = e.target.value.split(',').map(s => s.trim()).filter(s => s);
//                       if (isEditing) {
//                         setSelectedJob({...jobToEdit, skills: skillsArray});
//                       } else {
//                         setNewJob({...newJob, skills: skillsArray});
//                       }
//                     }}
//                     required
//                   />
//                   <div className="skills-tags">
//                     {Array.isArray(jobToEdit.skills) && jobToEdit.skills.map((skill, index) => (
//                       <span key={index} className="skill-tag">
//                         {skill}
//                         <button 
//                           type="button"
//                           className="tag-remove"
//                           onClick={() => {
//                             const newSkills = jobToEdit.skills.filter((_, i) => i !== index);
//                             if (isEditing) {
//                               setSelectedJob({...jobToEdit, skills: newSkills});
//                             } else {
//                               setNewJob({...newJob, skills: newSkills});
//                             }
//                           }}
//                         >
//                           <X size={12} />
//                         </button>
//                       </span>
//                     ))}
//                   </div>
//                 </div>
//               </div>

//               <div className="form-group">
//                 <label>
//                   <span className="required">*</span>
//                   Job Description
//                 </label>
//                 <textarea
//                   className="form-control"
//                   rows="4"
//                   value={jobToEdit.description}
//                   onChange={(e) => isEditing ? 
//                     setSelectedJob({...jobToEdit, description: e.target.value}) :
//                     setNewJob({...newJob, description: e.target.value})
//                   }
//                   placeholder="Describe the job role, responsibilities, and expectations..."
//                   required
//                 ></textarea>
//               </div>

//               <div className="form-group">
//                 <label>
//                   <span className="required">*</span>
//                   Requirements & Qualifications
//                 </label>
//                 <textarea
//                   className="form-control"
//                   rows="4"
//                   value={jobToEdit.requirements}
//                   onChange={(e) => isEditing ? 
//                     setSelectedJob({...jobToEdit, requirements: e.target.value}) :
//                     setNewJob({...newJob, requirements: e.target.value})
//                   }
//                   placeholder="List the required experience, education, certifications, etc."
//                   required
//                 ></textarea>
//               </div>
//             </div>

//             <div className="form-actions">
//               <button 
//                 type="button" 
//                 className="btn-secondary"
//                 onClick={() => {
//                   setSelectedJob(null);
//                   setIsEditMode(false);
//                   setActiveTab('jobs');
//                   setNewJob({
//                     title: '',
//                     department: '',
//                     location: '',
//                     openings: 1,
//                     requirements: '',
//                     skills: [],
//                     description: '',
//                     salary: '',
//                     expiryDate: ''
//                   });
//                 }}
//               >
//                 Cancel
//               </button>
//               <button type="submit" className="btn-primary">
//                 {isEditing ? (
//                   <>
//                     <Check size={18} />
//                     Update Job Profile
//                   </>
//                 ) : (
//                   <>
//                     <Plus size={18} />
//                     Create Job Profile
//                   </>
//                 )}
//               </button>
//             </div>
//           </form>
//         </div>
//       </div>
//     );
//   };

//   const renderTraineesList = () => (
//     <div className="trainees-list">
//       <div className="section-header">
//         <div className="header-title">
//           <h2>
//             <Users size={24} />
//             Trainees Management
//           </h2>
//           <p className="subtitle">Manage and track all trainees in the system</p>
//         </div>
//         <div className="view-options">
//           <button 
//             className={`btn-view-option ${activeTab === 'trainees' ? 'active' : ''}`}
//             onClick={() => setActiveTab('trainees')}
//           >
//             All Trainees
//           </button>
//           <button 
//             className={`btn-view-option ${activeTab === 'mapped' ? 'active' : ''}`}
//             onClick={() => setActiveTab('mapped')}
//           >
//             <CheckCircle size={16} />
//             Mapped ({stats.mappedTrainees})
//           </button>
//           <button 
//             className={`btn-view-option ${activeTab === 'unmapped' ? 'active' : ''}`}
//             onClick={() => setActiveTab('unmapped')}
//           >
//             <AlertCircle size={16} />
//             Unmapped ({stats.unmappedTrainees})
//           </button>
//         </div>
//       </div>

//       <div className="search-filter">
//         <div className="search-box">
//           <Search size={18} />
//           <input 
//             type="text" 
//             className="search-input" 
//             placeholder="Search trainees by name, skills, or location..."
//           />
//         </div>
//         <div className="filter-group">
//           <button className="btn-filter">
//             <Filter size={18} />
//             Filter
//           </button>
//           <select className="filter-select">
//             <option value="">All Status</option>
//             <option value="ready">Job Ready</option>
//             <option value="training">In Training</option>
//           </select>
//           <button className="btn-icon">
//             <Download size={18} />
//           </button>
//         </div>
//       </div>

//       <div className="trainees-grid">
//         {trainees
//           .filter(trainee => {
//             if (activeTab === 'mapped') return trainee.matchedJobs.length > 0;
//             if (activeTab === 'unmapped') return trainee.matchedJobs.length === 0;
//             return true;
//           })
//           .map(trainee => (
//             <div key={trainee.id} className="trainee-card">
//               <div className="trainee-header">
//                 <div className="trainee-info-main">
//                   <div className="trainee-avatar">
//                     {trainee.name.charAt(0)}
//                   </div>
//                   <div className="trainee-info">
//                     <h4>{trainee.name}</h4>
//                     <div className="trainee-meta">
//                       <span className="trainee-email">
//                         <Mail size={14} />
//                         {trainee.email}
//                       </span>
//                       <span className="trainee-location">
//                         <MapPin size={14} />
//                         {trainee.location}
//                       </span>
//                     </div>
//                   </div>
//                 </div>
//                 <div className={`mapping-indicator ${trainee.matchedJobs.length > 0 ? 'mapped' : 'unmapped'}`}>
//                   {trainee.matchedJobs.length > 0 ? (
//                     <>
//                       <CheckCircle size={14} />
//                       Mapped
//                     </>
//                   ) : (
//                     <>
//                       <AlertCircle size={14} />
//                       Unmapped
//                     </>
//                   )}
//                 </div>
//               </div>
              
//               <div className="trainee-skills">
//                 {trainee.skills.slice(0, 4).map(skill => (
//                   <span key={skill} className="skill-tag">
//                     {skill}
//                   </span>
//                 ))}
//                 {trainee.skills.length > 4 && (
//                   <span className="skill-tag-more">
//                     +{trainee.skills.length - 4}
//                   </span>
//                 )}
//               </div>
              
//               <div className="trainee-stats">
//                 <div className="trainee-stat">
//                   <span className="stat-label">Readiness Score</span>
//                   <div className="score-progress">
//                     <div className="progress-bar">
//                       <div 
//                         className="progress-fill" 
//                         style={{ width: `${trainee.score}%` }}
//                       ></div>
//                     </div>
//                     <span className="score-value">{trainee.score}%</span>
//                   </div>
//                 </div>
//                 <div className="trainee-stat">
//                   <span className="stat-label">Matched Jobs</span>
//                   <div className="matched-jobs-count">
//                     <span className="match-count">{trainee.matchedJobs.length}</span>
//                     {trainee.matchedJobs.length > 0 && (
//                       <span className="best-match">
//                         <Star size={12} />
//                         Best: {Math.max(...trainee.matchedJobs.map(j => j.matchScore))}%
//                       </span>
//                     )}
//                   </div>
//                 </div>
//               </div>
              
//               <div className="trainee-actions">
//                 <button 
//                   className="btn-action btn-profile"
//                   onClick={() => setSelectedTrainee(trainee)}
//                 >
//                   <User size={16} />
//                   View Profile
//                 </button>
//                 {trainee.matchedJobs.length > 0 ? (
//                   <button className="btn-action btn-view-matches">
//                     <Briefcase size={16} />
//                     View Matches ({trainee.matchedJobs.length})
//                   </button>
//                 ) : (
//                   <button className="btn-action btn-find-matches">
//                     <Sparkles size={16} />
//                     Find Matches
//                   </button>
//                 )}
//               </div>
//             </div>
//           ))}
//       </div>
//     </div>
//   );

//   const handleCreateJob = () => {
//     const newJobObj = {
//       ...newJob,
//       id: jobs.length + 1,
//       matches: 0,
//       filled: 0,
//       status: 'active',
//       postedDate: new Date().toISOString().split('T')[0]
//     };
//     setJobs([...jobs, newJobObj]);
//     setActiveTab('jobs');
//     setNewJob({
//       title: '',
//       department: '',
//       location: '',
//       openings: 1,
//       requirements: '',
//       skills: [],
//       description: '',
//       salary: '',
//       expiryDate: ''
//     });
//   };

//   const handleUpdateJob = (updatedJob) => {
//     setJobs(jobs.map(job => job.id === updatedJob.id ? updatedJob : job));
//     setSelectedJob(null);
//     setIsEditMode(false);
//     setActiveTab('jobs');
//   };

//   const handleDeleteJob = (jobId) => {
//     if (window.confirm('Are you sure you want to delete this job? This action cannot be undone.')) {
//       setJobs(jobs.filter(job => job.id !== jobId));
//     }
//   };

//   const renderJobModal = () => {
//     if (!selectedJob || isEditMode) return null;

//     return (
//       <div className="modal-overlay" onClick={() => setSelectedJob(null)}>
//         <div className="modal-content" onClick={e => e.stopPropagation()}>
//           <div className="modal-header">
//             <div className="modal-title">
//               <Briefcase size={24} />
//               <h2>{selectedJob.title}</h2>
//             </div>
//             <button className="modal-close" onClick={() => setSelectedJob(null)}>
//               <X size={24} />
//             </button>
//           </div>
          
//           <div className="modal-body">
//             <div className="job-details-grid">
//               <div className="detail-item">
//                 <Building size={16} />
//                 <div>
//                   <span className="detail-label">Department</span>
//                   <span className="detail-value">{selectedJob.department}</span>
//                 </div>
//               </div>
//               <div className="detail-item">
//                 <MapPin size={16} />
//                 <div>
//                   <span className="detail-label">Location</span>
//                   <span className="detail-value">{selectedJob.location}</span>
//                 </div>
//               </div>
//               <div className="detail-item">
//                 <BriefcaseBusiness size={16} />
//                 <div>
//                   <span className="detail-label">Openings</span>
//                   <span className="detail-value">{selectedJob.openings} ({selectedJob.filled} filled)</span>
//                 </div>
//               </div>
//               <div className="detail-item">
//                 <Dollar size={16} />
//                 <div>
//                   <span className="detail-label">Salary</span>
//                   <span className="detail-value">{selectedJob.salary}</span>
//                 </div>
//               </div>
//               <div className="detail-item">
//                 <div className={`status-badge status-${selectedJob.status}`}>
//                   {selectedJob.status === 'active' ? 'Active' : 'Inactive'}
//                 </div>
//               </div>
//               <div className="detail-item">
//                 <CalendarDays size={16} />
//                 <div>
//                   <span className="detail-label">Posted</span>
//                   <span className="detail-value">{selectedJob.postedDate}</span>
//                 </div>
//               </div>
//               <div className="detail-item">
//                 <Calendar size={16} />
//                 <div>
//                   <span className="detail-label">Expires</span>
//                   <span className="detail-value">{selectedJob.expiryDate}</span>
//                 </div>
//               </div>
//             </div>

//             <div className="job-section">
//               <h3>Job Description</h3>
//               <p>{selectedJob.description}</p>
//             </div>

//             <div className="job-section">
//               <h3>Requirements</h3>
//               <p>{selectedJob.requirements}</p>
//             </div>

//             <div className="job-section">
//               <h3>Required Skills</h3>
//               <div className="skills-list">
//                 {selectedJob.skills.map(skill => (
//                   <span key={skill} className="skill-tag">
//                     {skill}
//                   </span>
//                 ))}
//               </div>
//             </div>

//             <div className="job-section">
//               <h3>Statistics</h3>
//               <div className="job-stats">
//                 <div className="job-stat">
//                   <span className="stat-label">Total Matches</span>
//                   <span className="stat-value">{selectedJob.matches}</span>
//                 </div>
//                 <div className="job-stat">
//                   <span className="stat-label">Fill Rate</span>
//                   <span className="stat-value">
//                     {Math.round((selectedJob.filled / selectedJob.openings) * 100)}%
//                   </span>
//                 </div>
//               </div>
//             </div>

//             <div className="modal-actions">
//               <button className="btn-secondary" onClick={() => setSelectedJob(null)}>
//                 Close
//               </button>
//               <button className="btn-primary" onClick={() => {
//                 setIsEditMode(true);
//                 setActiveTab('createJob');
//               }}>
//                 <Edit size={18} />
//                 Edit Job
//               </button>
//             </div>
//           </div>
//         </div>
//       </div>
//     );
//   };

//   const renderContent = () => {
//     switch (activeTab) {
//       case 'dashboard':
//         return renderDashboard();
//       case 'jobs':
//         return renderJobManagement();
//       case 'createJob':
//         return renderCreateJob();
//       case 'trainees':
//       case 'mapped':
//       case 'unmapped':
//         return renderTraineesList();
//       default:
//         return renderDashboard();
//     }
//   };

//   const sidebarItems = [
//     { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={20} /> },
//     { id: 'jobs', label: 'Job Management', icon: <Briefcase size={20} /> },
//     { id: 'trainees', label: 'Trainees List', icon: <Users size={20} /> },
  
//   ];

//   return (
//     <div className="dashboard">
//       <style>{`
//         :root {
//           --primary: #3b82f6;
//           --primary-light: #eff6ff;
//           --secondary: #6b7280;
//           --success: #10b981;
//           --warning: #f59e0b;
//           --danger: #ef4444;
//           --background: #f9fafb;
//           --card: #ffffff;
//           --border: #e5e7eb;
//           --text: #111827;
//           --text-light: #6b7280;
//         }

//         * {
//           margin: 0;
//           padding: 0;
//           box-sizing: border-box;
//         }

//         body {
//           font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
//           color: var(--text);
//           background: var(--background);
//         }





//   /* Modal Overlay */
//   .modal-overlay {
//     position: fixed;
//     top: 0;
//     left: 0;
//     right: 0;
//     bottom: 0;
//     background: rgba(15, 23, 42, 0.8);
//     display: flex;
//     align-items: center;
//     justify-content: center;
//     z-index: 1000;
//     padding: 20px;
//     backdrop-filter: blur(4px);
//   }

//   .modal-content {
//     background: white;
//     border-radius: 16px;
//     width: 100%;
//     max-width: 1000px;
//     max-height: 90vh;
//     overflow-y: auto;
//     box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
//     position: relative;
//   }

//   /* Header */
//   .modal-header {
//     padding: 24px 32px;
//     border-bottom: 1px solid #e5e7eb;
//     display: flex;
//     justify-content: space-between;
//     align-items: center;
//     background: #f8fafc;
//     border-radius: 16px 16px 0 0;
//   }

//   .modal-title {
//     display: flex;
//     align-items: center;
//     gap: 12px;
//   }

//   .modal-title h2 {
//     font-size: 24px;
//     font-weight: 600;
//     color: #1e293b;
//     margin: 0;
//   }

//   .modal-close {
//     width: 40px;
//     height: 40px;
//     border-radius: 10px;
//     border: none;
//     background: #f1f5f9;
//     color: #64748b;
//     cursor: pointer;
//     display: flex;
//     align-items: center;
//     justify-content: center;
//     transition: all 0.2s;
//   }

//   .modal-close:hover {
//     background: #e2e8f0;
//     color: #475569;
//   }

//   /* Body */
//   .modal-body {
//     padding: 32px;
//   }

//   /* Profile Header */
//   .profile-header {
//     display: flex;
//     gap: 24px;
//     align-items: center;
//     margin-bottom: 32px;
//     padding-bottom: 32px;
//     border-bottom: 2px solid #f1f5f9;
//   }

//   .profile-avatar {
//     width: 80px;
//     height: 80px;
//     background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
//     border-radius: 16px;
//     display: flex;
//     align-items: center;
//     justify-content: center;
//     font-size: 32px;
//     font-weight: 600;
//     color: white;
//     flex-shrink: 0;
//   }

//   .profile-info {
//     flex: 1;
//   }

//   .profile-info h3 {
//     font-size: 28px;
//     font-weight: 700;
//     color: #1e293b;
//     margin: 0 0 4px 0;
//   }

//   .profile-role {
//     display: inline-block;
//     background: #e0e7ff;
//     color: #4338ca;
//     padding: 4px 12px;
//     border-radius: 20px;
//     font-size: 12px;
//     font-weight: 600;
//     margin-bottom: 12px;
//   }

//   .profile-meta {
//     display: flex;
//     gap: 24px;
//     flex-wrap: wrap;
//   }

//   .profile-meta-item {
//     display: flex;
//     align-items: center;
//     gap: 8px;
//     font-size: 14px;
//     color: #64748b;
//   }

//   .profile-actions {
//     display: flex;
//     gap: 8px;
//   }

//   /* Buttons */
//   .btn-activate, .btn-deactivate {
//     padding: 8px 16px;
//     border-radius: 8px;
//     border: none;
//     font-weight: 500;
//     font-size: 14px;
//     cursor: pointer;
//     display: flex;
//     align-items: center;
//     gap: 6px;
//     transition: all 0.2s;
//   }

//   .btn-activate {
//     background: #10b981;
//     color: white;
//   }

//   .btn-activate:hover {
//     background: #059669;
//     transform: translateY(-1px);
//     box-shadow: 0 4px 12px rgba(16, 185, 129, 0.2);
//   }

//   .btn-deactivate {
//     background: #ef4444;
//     color: white;
//   }

//   .btn-deactivate:hover {
//     background: #dc2626;
//     transform: translateY(-1px);
//     box-shadow: 0 4px 12px rgba(239, 68, 68, 0.2);
//   }

//   /* Info Grid */
//   .info-grid {
//     display: grid;
//     grid-template-columns: 1fr 1fr;
//     gap: 24px;
//     margin-bottom: 32px;
//   }

//   .info-card {
//     background: #f8fafc;
//     border: 1px solid #e2e8f0;
//     border-radius: 12px;
//     padding: 20px;
//   }

//   .info-card h4 {
//     font-size: 16px;
//     font-weight: 600;
//     color: #334155;
//     margin: 0 0 16px 0;
//     display: flex;
//     align-items: center;
//     gap: 8px;
//   }

//   .info-content {
//     display: flex;
//     flex-direction: column;
//     gap: 12px;
//   }

//   .info-row {
//     display: flex;
//     justify-content: space-between;
//     align-items: center;
//   }

//   .info-label {
//     font-size: 14px;
//     color: #64748b;
//   }

//   .info-value {
//     font-size: 14px;
//     font-weight: 500;
//     color: #1e293b;
//   }

//   /* Skills Section */
//   .skills-section {
//     margin-bottom: 32px;
//   }

//   .section-title {
//     font-size: 18px;
//     font-weight: 600;
//     color: #1e293b;
//     margin: 0 0 16px 0;
//     display: flex;
//     align-items: center;
//     gap: 8px;
//   }

//   .skills-container {
//     display: grid;
//     grid-template-columns: 1fr 1fr;
//     gap: 16px;
//   }

//   .skills-column {
//     background: #f8fafc;
//     border: 1px solid #e2e8f0;
//     border-radius: 12px;
//     padding: 20px;
//   }

//   .skills-column h4 {
//     font-size: 14px;
//     font-weight: 600;
//     color: #334155;
//     margin: 0 0 12px 0;
//     display: flex;
//     align-items: center;
//     gap: 8px;
//   }

//   .skills-list {
//     display: flex;
//     flex-wrap: wrap;
//     gap: 8px;
//   }

//   .skill-tag {
//     padding: 4px 12px;
//     border-radius: 6px;
//     font-size: 13px;
//     font-weight: 500;
//     display: inline-flex;
//     align-items: center;
//     gap: 4px;
//   }

//   .skill-tag.success {
//     background: #dcfce7;
//     color: #166534;
//     border: 1px solid #bbf7d0;
//   }

//   .skill-tag.danger {
//     background: #fee2e2;
//     color: #991b1b;
//     border: 1px solid #fecaca;
//   }

//   /* Courses & Certificates */
//   .courses-section, .certificates-section {
//     margin-bottom: 32px;
//   }

//   .courses-grid, .certificates-grid {
//     display: grid;
//     grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
//     gap: 12px;
//   }

//   .course-card, .certificate-card {
//     background: #f8fafc;
//     border: 1px solid #e2e8f0;
//     border-radius: 12px;
//     padding: 16px;
//     display: flex;
//     gap: 12px;
//     align-items: flex-start;
//   }

//   .course-icon {
//     width: 36px;
//     height: 36px;
//     background: #dbeafe;
//     border-radius: 8px;
//     display: flex;
//     align-items: center;
//     justify-content: center;
//     color: #1d4ed8;
//     flex-shrink: 0;
//   }

//   .certificate-icon {
//     width: 36px;
//     height: 36px;
//     background: #fef3c7;
//     border-radius: 8px;
//     display: flex;
//     align-items: center;
//     justify-content: center;
//     color: #92400e;
//     flex-shrink: 0;
//   }

//   .course-content, .certificate-content {
//     flex: 1;
//   }

//   .course-title {
//     font-size: 14px;
//     font-weight: 500;
//     color: #1e293b;
//     margin: 0 0 4px 0;
//   }

//   .certificate-name {
//     font-size: 14px;
//     font-weight: 500;
//     color: #1e293b;
//     margin: 0 0 4px 0;
//   }

//   .course-meta, .certificate-details {
//     font-size: 12px;
//     color: #64748b;
//     display: flex;
//     gap: 12px;
//   }

//   .course-meta span, .certificate-details span {
//     display: flex;
//     align-items: center;
//     gap: 4px;
//   }

//   .course-link {
//     color: #2563eb;
//     text-decoration: none;
//     font-weight: 500;
//   }

//   /* Projects Section */
//   .projects-section {
//     margin-bottom: 32px;
//   }

//   .projects-header {
//     display: flex;
//     justify-content: space-between;
//     align-items: center;
//     margin-bottom: 20px;
//   }

//   .projects-stats {
//     display: flex;
//     gap: 16px;
//   }

//   .stat-item {
//     font-size: 14px;
//     color: #64748b;
//     display: flex;
//     align-items: center;
//     gap: 4px;
//   }

//   .projects-grid {
//     display: flex;
//     flex-direction: column;
//     gap: 12px;
//   }

//   .project-card {
//     background: #f8fafc;
//     border: 1px solid #e2e8f0;
//     border-radius: 12px;
//     padding: 20px;
//     position: relative;
//   }

//   .project-card.mapped {
//     border-left: 4px solid #10b981;
//   }

//   .project-card.open-pool {
//     border-left: 4px solid #3b82f6;
//   }

//   .project-header {
//     display: flex;
//     justify-content: space-between;
//     align-items: flex-start;
//     margin-bottom: 16px;
//   }

//   .project-title h4 {
//     font-size: 16px;
//     font-weight: 600;
//     color: #1e293b;
//     margin: 0 0 8px 0;
//   }

//   .project-meta {
//     display: flex;
//     gap: 16px;
//     font-size: 13px;
//     color: #64748b;
//   }

//   .project-meta span {
//     display: flex;
//     align-items: center;
//     gap: 4px;
//   }

//   .match-badge {
//     padding: 6px 12px;
//     background: #f1f5f9;
//     border-radius: 20px;
//     font-size: 13px;
//     font-weight: 500;
//     display: flex;
//     align-items: center;
//     gap: 4px;
//   }

//   .match-badge.high {
//     background: #dcfce7;
//     color: #166534;
//   }

//   .match-badge.medium {
//     background: #fef3c7;
//     color: #92400e;
//   }

//   .match-badge.low {
//     background: #fee2e2;
//     color: #991b1b;
//   }

//   .skills-display {
//     margin-bottom: 16px;
//   }

//   .skill-group {
//     display: flex;
//     gap: 8px;
//     margin-bottom: 12px;
//     align-items: flex-start;
//   }

//   .skill-group-label {
//     font-size: 13px;
//     color: #64748b;
//     min-width: 100px;
//     font-weight: 500;
//     padding-top: 2px;
//   }

//   .skill-tags-container {
//     display: flex;
//     flex-wrap: wrap;
//     gap: 6px;
//   }

//   .project-details {
//     background: #f1f5f9;
//     padding: 12px;
//     border-radius: 8px;
//     margin-bottom: 16px;
//   }

//   .reason {
//     font-size: 13px;
//     color: #475569;
//     line-height: 1.5;
//     margin-bottom: 12px;
//   }

//   .openings-info {
//     display: flex;
//     gap: 16px;
//     font-size: 13px;
//     color: #64748b;
//   }

//   .openings-info span {
//     display: flex;
//     align-items: center;
//     gap: 4px;
//   }

//   .project-actions {
//     display: flex;
//     gap: 8px;
//     justify-content: flex-end;
//   }

//   .btn {
//     padding: 8px 16px;
//     border-radius: 8px;
//     border: 1px solid #d1d5db;
//     font-size: 13px;
//     font-weight: 500;
//     cursor: pointer;
//     display: flex;
//     align-items: center;
//     gap: 6px;
//     transition: all 0.2s;
//     background: white;
//   }

//   .btn:hover {
//     transform: translateY(-1px);
//   }

//   .btn-secondary {
//     background: white;
//     color: #374151;
//     border-color: #d1d5db;
//   }

//   .btn-secondary:hover {
//     background: #f9fafb;
//     border-color: #9ca3af;
//   }

//   .btn-primary {
//     background: #3b82f6;
//     color: white;
//     border-color: #3b82f6;
//   }

//   .btn-primary:hover {
//     background: #2563eb;
//     border-color: #2563eb;
//   }

//   .status-indicator {
//     padding: 8px 16px;
//     border-radius: 8px;
//     font-size: 13px;
//     font-weight: 500;
//     display: flex;
//     align-items: center;
//     gap: 6px;
//   }

//   .status-indicator.success {
//     background: #dcfce7;
//     color: #166534;
//     border: 1px solid #bbf7d0;
//   }

//   .status-indicator.info {
//     background: #dbeafe;
//     color: #1e40af;
//     border: 1px solid #bfdbfe;
//   }

//   /* Modal Footer */
//   .modal-footer {
//     padding: 24px 32px;
//     border-top: 1px solid #e5e7eb;
//     display: flex;
//     justify-content: space-between;
//     align-items: center;
//     background: #f8fafc;
//     border-radius: 0 0 16px 16px;
//   }

//   .footer-actions {
//     display: flex;
//     gap: 12px;
//   }

//   .btn-outline {
//     padding: 8px 16px;
//     border: 1px solid #d1d5db;
//     border-radius: 8px;
//     background: white;
//     color: #374151;
//     font-size: 14px;
//     font-weight: 500;
//     cursor: pointer;
//     display: flex;
//     align-items: center;
//     gap: 6px;
//     transition: all 0.2s;
//   }

//   .btn-outline:hover {
//     background: #f9fafb;
//     border-color: #9ca3af;
//   }

//   /* Scrollbar */
//   .modal-content::-webkit-scrollbar {
//     width: 6px;
//   }

//   .modal-content::-webkit-scrollbar-track {
//     background: #f1f5f9;
//   }

//   .modal-content::-webkit-scrollbar-thumb {
//     background: #cbd5e1;
//     border-radius: 3px;
//   }

//   /* Responsive Design */
//   @media (max-width: 768px) {
//     .modal-content {
//       max-height: 95vh;
//     }
    
//     .modal-header {
//       padding: 20px;
//     }
    
//     .modal-body {
//       padding: 20px;
//     }
    
//     .info-grid {
//       grid-template-columns: 1fr;
//     }
    
//     .skills-container {
//       grid-template-columns: 1fr;
//     }
    
//     .courses-grid, .certificates-grid {
//       grid-template-columns: 1fr;
//     }
    
//     .project-header {
//       flex-direction: column;
//       gap: 12px;
//     }
    
//     .project-meta {
//       flex-wrap: wrap;
//     }
    
//     .skill-group {
//       flex-direction: column;
//       gap: 4px;
//     }
    
//     .skill-group-label {
//       min-width: auto;
//     }
    
//     .project-actions {
//       flex-direction: column;
//     }
    
//     .modal-footer {
//       flex-direction: column;
//       gap: 16px;
//     }
    
//     .footer-actions {
//       width: 100%;
//     }
    
//     .footer-actions button {
//       flex: 1;
//     }
//   }

//   @media (max-width: 640px) {
//     .profile-header {
//       flex-direction: column;
//       text-align: center;
//       gap: 16px;
//     }
    
//     .profile-meta {
//       justify-content: center;
//     }
    
//     .profile-actions {
//       width: 100%;
//       justify-content: center;
//     }
    
//     .projects-header {
//       flex-direction: column;
//       gap: 12px;
//     }
    
//     .projects-stats {
//       flex-wrap: wrap;
//     }
//   }





//         .dashboard {
//           display: flex;
//           min-height: 100vh;
//         }

//         .main-content {
//           flex: 1;
//           padding: 2rem;
//           overflow-y: auto;
//           background: var(--background);
//         }

//         .dashboard-header {
//           display: flex;
//           justify-content: space-between;
//           align-items: center;
//           margin-bottom: 2rem;
//           padding-bottom: 1.5rem;
//           border-bottom: 1px solid var(--border);
//         }

//         .header-title h1 {
//           font-size: 1.875rem;
//           font-weight: 700;
//           color: var(--text);
//           margin-bottom: 0.5rem;
//           display: flex;
//           align-items: center;
//           gap: 0.75rem;
//         }

//         .header-subtitle {
//           color: var(--text-light);
//           font-size: 0.875rem;
//         }

//         .header-actions {
//           display: flex;
//           gap: 1rem;
//           align-items: center;
//         }

//         /* Stats Grid */
//         .stats-grid {
//           display: grid;
//           grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
//           gap: 1.5rem;
//           margin-bottom: 2rem;
//         }

//         .stat-card {
//           background: var(--card);
//           padding: 1.5rem;
//           border-radius: 1rem;
//           border: 1px solid var(--border);
//           display: flex;
//           align-items: center;
//           gap: 1.25rem;
//           transition: all 0.3s ease;
//         }

//         .stat-card:hover {
//           transform: translateY(-2px);
//           box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1);
//         }

//         .stat-icon {
//           width: 3.5rem;
//           height: 3.5rem;
//           border-radius: 0.75rem;
//           background: var(--primary-light);
//           display: flex;
//           align-items: center;
//           justify-content: center;
//         }

//         .stat-icon-svg {
//           width: 1.75rem;
//           height: 1.75rem;
//           color: var(--primary);
//         }

//         .stat-content {
//           flex: 1;
//         }

//         .stat-content h3 {
//           font-size: 0.875rem;
//           color: var(--text-light);
//           margin-bottom: 0.5rem;
//           font-weight: 500;
//         }

//         .stat-value {
//           font-size: 2rem;
//           font-weight: 700;
//           color: var(--text);
//           margin-bottom: 0.25rem;
//           line-height: 1;
//         }

//         .stat-change {
//           display: flex;
//           align-items: center;
//           gap: 0.375rem;
//           font-size: 0.75rem;
//           color: var(--success);
//           font-weight: 500;
//         }

//         .stat-change svg {
//           width: 0.875rem;
//           height: 0.875rem;
//         }

//         /* Content Grid */
//         .content-grid {
//           display: grid;
//           grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
//           gap: 1.5rem;
//           margin-bottom: 1.5rem;
//         }

//         .content-card {
//           background: var(--card);
//           padding: 1.5rem;
//           border-radius: 1rem;
//           border: 1px solid var(--border);
//         }

//         .card-header {
//           display: flex;
//           justify-content: space-between;
//           align-items: center;
//           margin-bottom: 1.5rem;
//         }

//         .card-header h3 {
//           display: flex;
//           align-items: center;
//           gap: 0.75rem;
//           font-size: 1.125rem;
//           font-weight: 600;
//           color: var(--text);
//         }

//         .btn-text {
//           display: flex;
//           align-items: center;
//           gap: 0.375rem;
//           background: none;
//           border: none;
//           color: var(--primary);
//           font-size: 0.875rem;
//           font-weight: 500;
//           cursor: pointer;
//           padding: 0.5rem;
//           border-radius: 0.375rem;
//         }

//         .btn-text:hover {
//           background: var(--primary-light);
//         }

//         /* Tables */
//         .table-container {
//           overflow-x: auto;
//           border-radius: 0.75rem;
//           border: 1px solid var(--border);
//         }

//         .data-table {
//           width: 100%;
//           border-collapse: collapse;
//           font-size: 0.875rem;
//         }

//         .data-table th {
//           text-align: left;
//           padding: 1rem;
//           background: var(--primary-light);
//           color: var(--text-light);
//           font-weight: 600;
//           font-size: 0.75rem;
//           text-transform: uppercase;
//           letter-spacing: 0.05em;
//           border-bottom: 1px solid var(--border);
//         }

//         .data-table td {
//           padding: 1rem;
//           border-bottom: 1px solid var(--border);
//           color: var(--text);
//         }

//         .data-table tr:last-child td {
//           border-bottom: none;
//         }

//         .data-table tr:hover {
//           background: var(--primary-light);
//         }

//         /* Cell Styles */
//         .user-cell {
//           display: flex;
//           align-items: center;
//           gap: 0.75rem;
//         }

//         .user-avatar-sm {
//           width: 2rem;
//           height: 2rem;
//           border-radius: 50%;
//           background: var(--primary);
//           color: white;
//           display: flex;
//           align-items: center;
//           justify-content: center;
//           font-weight: 600;
//           font-size: 0.875rem;
//         }

//         .location-cell, .department-cell {
//           display: flex;
//           align-items: center;
//           gap: 0.5rem;
//           color: var(--text-light);
//         }

//         /* Score Badges */
//         .score-badge {
//           padding: 0.25rem 0.75rem;
//           border-radius: 9999px;
//           font-size: 0.75rem;
//           font-weight: 600;
//           display: inline-flex;
//           align-items: center;
//           gap: 0.25rem;
//         }

//         .score-high {
//           background: #d1fae5;
//           color: #065f46;
//         }

//         .score-medium {
//           background: #fef3c7;
//           color: #92400e;
//         }

//         .score-low {
//           background: #fee2e2;
//           color: #991b1b;
//         }

//         /* Status Badges */
//         .status-badge {
//           padding: 0.375rem 0.75rem;
//           border-radius: 9999px;
//           font-size: 0.75rem;
//           font-weight: 600;
//           display: inline-flex;
//           align-items: center;
//           gap: 0.375rem;
//         }

//         .status-approved {
//           background: #d1fae5;
//           color: #065f46;
//         }

//         .status-pending {
//           background: #fef3c7;
//           color: #92400e;
//         }

//         .status-active {
//           background: #dbeafe;
//           color: #1e40af;
//         }

//         .status-inactive {
//           background: #e5e7eb;
//           color: #6b7280;
//         }

//         .status-ready {
//           background: #d1fae5;
//           color: #065f46;
//         }

//         .status-training {
//           background: #fef3c7;
//           color: #92400e;
//         }

//         /* Action Buttons */
//         .action-buttons {
//           display: flex;
//           gap: 0.5rem;
//         }

//         .btn-icon {
//           width: 2rem;
//           height: 2rem;
//           border-radius: 0.5rem;
//           border: 1px solid var(--border);
//           background: var(--card);
//           display: flex;
//           align-items: center;
//           justify-content: center;
//           cursor: pointer;
//           color: var(--text-light);
//           transition: all 0.2s ease;
//         }

//         .btn-icon:hover {
//           background: var(--primary-light);
//           color: var(--primary);
//           border-color: var(--primary);
//         }

//         .btn-icon-view:hover {
//           background: #dbeafe;
//           color: #1e40af;
//           border-color: #1e40af;
//         }

//         .btn-icon-edit:hover {
//           background: #fef3c7;
//           color: #92400e;
//           border-color: #92400e;
//         }

//         .btn-icon-delete:hover {
//           background: #fee2e2;
//           color: #991b1b;
//           border-color: #991b1b;
//         }

//         /* Skills */
//         .skills-list {
//           display: flex;
//           flex-direction: column;
//           gap: 1rem;
//         }

//         .skill-item {
//           display: flex;
//           flex-direction: column;
//           gap: 0.5rem;
//         }

//         .skill-header {
//           display: flex;
//           justify-content: space-between;
//           align-items: center;
//         }

//         .skill-name {
//           font-size: 0.875rem;
//           font-weight: 500;
//           color: var(--text);
//         }

//         .skill-stats {
//           display: flex;
//           gap: 1rem;
//           font-size: 0.75rem;
//           color: var(--text-light);
//         }

//         .skill-bar {
//           height: 0.5rem;
//           background: var(--border);
//           border-radius: 0.25rem;
//           overflow: hidden;
//         }

//         .skill-fill {
//           height: 100%;
//           background: linear-gradient(90deg, var(--primary), #8b5cf6);
//           border-radius: 0.25rem;
//         }

//         /* Distribution */
//         .distribution-grid {
//           display: grid;
//           grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
//           gap: 1.5rem;
//         }

//         .distribution-item {
//           display: flex;
//           flex-direction: column;
//           gap: 0.75rem;
//         }

//         .distribution-header {
//           display: flex;
//           justify-content: space-between;
//           align-items: center;
//         }

//         .distribution-label {
//           display: flex;
//           align-items: center;
//           gap: 0.5rem;
//           font-size: 0.875rem;
//           font-weight: 500;
//           color: var(--text);
//         }

//         .distribution-value {
//           font-size: 1.25rem;
//           font-weight: 700;
//           color: var(--text);
//         }

//         .distribution-bar {
//           height: 0.5rem;
//           background: var(--border);
//           border-radius: 0.25rem;
//           overflow: hidden;
//         }

//         .distribution-fill {
//           height: 100%;
//           border-radius: 0.25rem;
//         }

//         .distribution-percentage {
//           font-size: 0.875rem;
//           color: var(--text-light);
//           text-align: right;
//         }

//         /* Section Header */
//         .section-header {
//           display: flex;
//           justify-content: space-between;
//           align-items: center;
//           margin-bottom: 2rem;
//         }

//         .section-header h2 {
//           display: flex;
//           align-items: center;
//           gap: 0.75rem;
//           font-size: 1.5rem;
//           font-weight: 700;
//           color: var(--text);
//         }

//         .subtitle {
//           color: var(--text-light);
//           font-size: 0.875rem;
//           margin-top: 0.25rem;
//         }

//         /* Buttons */
//         .btn-primary {
//           display: flex;
//           align-items: center;
//           gap: 0.5rem;
//           background: var(--primary);
//           color: white;
//           padding: 0.75rem 1.5rem;
//           border: none;
//           border-radius: 0.75rem;
//           font-weight: 600;
//           cursor: pointer;
//           transition: all 0.2s ease;
//         }

//         .btn-primary:hover {
//           background: #2563eb;
//           transform: translateY(-1px);
//           box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
//         }

//         .btn-secondary {
//           display: flex;
//           align-items: center;
//           gap: 0.5rem;
//           background: var(--card);
//           color: var(--text);
//           padding: 0.75rem 1.5rem;
//           border: 1px solid var(--border);
//           border-radius: 0.75rem;
//           font-weight: 600;
//           cursor: pointer;
//           transition: all 0.2s ease;
//         }

//         .btn-secondary:hover {
//           background: var(--primary-light);
//           border-color: var(--primary);
//         }

//         /* Trainees */
//         .search-filter {
//           display: flex;
//           gap: 1rem;
//           margin-bottom: 2rem;
//         }

//         .search-box {
//           flex: 1;
//           position: relative;
//         }

//         .search-box svg {
//           position: absolute;
//           left: 1rem;
//           top: 50%;
//           transform: translateY(-50%);
//           color: var(--text-light);
//         }

//         .search-input {
//           width: 100%;
//           padding: 0.75rem 1rem 0.75rem 3rem;
//           border: 1px solid var(--border);
//           border-radius: 0.75rem;
//           font-size: 0.875rem;
//           background: var(--card);
//         }

//         .search-input:focus {
//           outline: none;
//           border-color: var(--primary);
//           box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
//         }

//         .filter-group {
//           display: flex;
//           gap: 0.5rem;
//           align-items: center;
//         }

//         .btn-filter {
//           display: flex;
//           align-items: center;
//           gap: 0.5rem;
//           padding: 0.75rem 1rem;
//           background: var(--card);
//           border: 1px solid var(--border);
//           border-radius: 0.75rem;
//           color: var(--text);
//           font-size: 0.875rem;
//           cursor: pointer;
//         }

//         .filter-select {
//           padding: 0.75rem;
//           border: 1px solid var(--border);
//           border-radius: 0.75rem;
//           background: var(--card);
//           color: var(--text);
//           font-size: 0.875rem;
//           min-width: 120px;
//         }

//         /* View Options */
//         .view-options {
//           display: flex;
//           gap: 0.5rem;
//           background: var(--card);
//           padding: 0.25rem;
//           border-radius: 0.75rem;
//           border: 1px solid var(--border);
//         }

//         .btn-view-option {
//           display: flex;
//           align-items: center;
//           gap: 0.5rem;
//           padding: 0.5rem 1rem;
//           background: none;
//           border: none;
//           border-radius: 0.5rem;
//           color: var(--text-light);
//           font-size: 0.875rem;
//           font-weight: 500;
//           cursor: pointer;
//           transition: all 0.2s ease;
//         }

//         .btn-view-option.active {
//           background: var(--primary);
//           color: white;
//         }

//         /* Trainee Cards */
//         .trainees-grid {
//           display: grid;
//           grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
//           gap: 1.5rem;
//         }

//         .trainee-card {
//           background: var(--card);
//           padding: 1.5rem;
//           border-radius: 1rem;
//           border: 1px solid var(--border);
//           transition: all 0.3s ease;
//         }

//         .trainee-card:hover {
//           transform: translateY(-2px);
//           box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1);
//         }

//         .trainee-header {
//           display: flex;
//           justify-content: space-between;
//           align-items: flex-start;
//           margin-bottom: 1.5rem;
//         }

//         .trainee-info-main {
//           display: flex;
//           gap: 1rem;
//           align-items: center;
//         }

//         .trainee-avatar {
//           width: 3rem;
//           height: 3rem;
//           border-radius: 50%;
//           background: linear-gradient(135deg, var(--primary), #8b5cf6);
//           color: white;
//           display: flex;
//           align-items: center;
//           justify-content: center;
//           font-weight: 600;
//           font-size: 1rem;
//         }

//         .trainee-info h4 {
//           font-size: 1rem;
//           font-weight: 600;
//           color: var(--text);
//           margin-bottom: 0.25rem;
//         }

//         .trainee-meta {
//           display: flex;
//           flex-direction: column;
//           gap: 0.25rem;
//           font-size: 0.75rem;
//           color: var(--text-light);
//         }

//         .trainee-email, .trainee-location {
//           display: flex;
//           align-items: center;
//           gap: 0.375rem;
//         }

//         .mapping-indicator {
//           padding: 0.375rem 0.75rem;
//           border-radius: 9999px;
//           font-size: 0.75rem;
//           font-weight: 600;
//           display: flex;
//           align-items: center;
//           gap: 0.375rem;
//         }

//         .mapping-indicator.mapped {
//           background: #d1fae5;
//           color: #065f46;
//         }

//         .mapping-indicator.unmapped {
//           background: #fee2e2;
//           color: #991b1b;
//         }

//         .trainee-skills {
//           display: flex;
//           flex-wrap: wrap;
//           gap: 0.5rem;
//           margin-bottom: 1.5rem;
//         }

//         .skill-tag {
//           padding: 0.375rem 0.75rem;
//           background: var(--primary-light);
//           border-radius: 9999px;
//           font-size: 0.75rem;
//           color: var(--primary);
//           font-weight: 500;
//         }

//         .skill-tag-more {
//           padding: 0.375rem 0.75rem;
//           background: var(--border);
//           border-radius: 9999px;
//           font-size: 0.75rem;
//           color: var(--text-light);
//         }

//         .trainee-stats {
//           margin-bottom: 1.5rem;
//         }

//         .trainee-stat {
//           margin-bottom: 1rem;
//         }

//         .stat-label {
//           display: block;
//           font-size: 0.75rem;
//           color: var(--text-light);
//           margin-bottom: 0.5rem;
//           font-weight: 500;
//         }

//         .score-progress {
//           display: flex;
//           align-items: center;
//           gap: 1rem;
//         }

//         .progress-bar {
//           flex: 1;
//           height: 0.5rem;
//           background: var(--border);
//           border-radius: 0.25rem;
//           overflow: hidden;
//         }

//         .progress-fill {
//           height: 100%;
//           background: linear-gradient(90deg, var(--primary), #8b5cf6);
//           border-radius: 0.25rem;
//         }

//         .score-value {
//           font-size: 0.875rem;
//           font-weight: 600;
//           color: var(--text);
//           min-width: 2.5rem;
//           text-align: right;
//         }

//         .matched-jobs-count {
//           display: flex;
//           align-items: center;
//           gap: 1rem;
//         }

//         .match-count {
//           font-size: 1.25rem;
//           font-weight: 700;
//           color: var(--text);
//         }

//         .best-match {
//           display: flex;
//           align-items: center;
//           gap: 0.25rem;
//           font-size: 0.75rem;
//           color: var(--success);
//           font-weight: 600;
//         }

//         .trainee-actions {
//           display: flex;
//           gap: 0.75rem;
//         }

//         .btn-action {
//           flex: 1;
//           display: flex;
//           align-items: center;
//           justify-content: center;
//           gap: 0.5rem;
//           padding: 0.75rem;
//           border: 1px solid var(--border);
//           border-radius: 0.75rem;
//           background: var(--card);
//           color: var(--text);
//           font-size: 0.875rem;
//           font-weight: 500;
//           cursor: pointer;
//           transition: all 0.2s ease;
//         }

//         .btn-action:hover {
//           background: var(--primary-light);
//           color: var(--primary);
//           border-color: var(--primary);
//         }

//         .btn-profile:hover {
//           background: #e0e7ff;
//           color: #3730a3;
//           border-color: #3730a3;
//         }

//         .btn-find-matches:hover {
//           background: #dbeafe;
//           color: #1e40af;
//           border-color: #1e40af;
//         }

//         .btn-view-matches:hover {
//           background: #a7f3d0;
//           color: #065f46;
//           border-color: #065f46;
//         }

//         /* Form Styles */
//         .form-card {
//           background: var(--card);
//           padding: 2rem;
//           border-radius: 1rem;
//           border: 1px solid var(--border);
//         }

//         .form-section {
//           margin-bottom: 2rem;
//           padding-bottom: 2rem;
//           border-bottom: 1px solid var(--border);
//         }

//         .form-section:last-child {
//           margin-bottom: 0;
//           padding-bottom: 0;
//           border-bottom: none;
//         }

//         .form-section-title {
//           display: flex;
//           align-items: center;
//           gap: 0.75rem;
//           font-size: 1.125rem;
//           font-weight: 600;
//           color: var(--text);
//           margin-bottom: 1.5rem;
//         }

//         .form-row {
//           display: grid;
//           grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
//           gap: 1.5rem;
//           margin-bottom: 1.5rem;
//         }

//         .form-group {
//           margin-bottom: 1.5rem;
//         }

//         .form-group label {
//           display: flex;
//           align-items: center;
//           gap: 0.375rem;
//           margin-bottom: 0.5rem;
//           font-weight: 500;
//           color: var(--text);
//           font-size: 0.875rem;
//         }

//         .required {
//           color: var(--danger);
//         }

//         .form-control {
//           width: 100%;
//           padding: 0.75rem 1rem;
//           border: 1px solid var(--border);
//           border-radius: 0.75rem;
//           font-size: 0.875rem;
//           background: var(--card);
//           transition: all 0.2s ease;
//         }

//         .form-control:focus {
//           outline: none;
//           border-color: var(--primary);
//           box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
//         }

//         .form-actions {
//           display: flex;
//           gap: 1rem;
//           justify-content: flex-end;
//           margin-top: 2rem;
//           padding-top: 2rem;
//           border-top: 1px solid var(--border);
//         }

//         /* Modal */
//         .modal-overlay {
//           position: fixed;
//           top: 0;
//           left: 0;
//           right: 0;
//           bottom: 0;
//           background: rgba(0, 0, 0, 0.5);
//           display: flex;
//           justify-content: center;
//           align-items: center;
//           z-index: 1000;
//           backdrop-filter: blur(4px);
//         }

//         .modal-content {
//           background: var(--card);
//           border-radius: 1rem;
//           width: 90%;
//           max-width: 900px;
//           max-height: 90vh;
//           overflow-y: auto;
//           box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
//           animation: slideIn 0.3s ease;
//         }

//         @keyframes slideIn {
//           from {
//             opacity: 0;
//             transform: translateY(20px);
//           }
//           to {
//             opacity: 1;
//             transform: translateY(0);
//           }
//         }

//         .modal-header {
//           display: flex;
//           justify-content: space-between;
//           align-items: center;
//           padding: 1.5rem;
//           border-bottom: 1px solid var(--border);
//         }

//         .modal-title {
//           display: flex;
//           align-items: center;
//           gap: 0.75rem;
//         }

//         .modal-title h2 {
//           font-size: 1.5rem;
//           font-weight: 700;
//           color: var(--text);
//         }

//         .modal-close {
//           background: none;
//           border: none;
//           color: var(--text-light);
//           cursor: pointer;
//           padding: 0.5rem;
//           border-radius: 0.5rem;
//         }

//         .modal-close:hover {
//           background: var(--border);
//         }

//         .modal-body {
//           padding: 1.5rem;
//         }

//         /* Job Details */
//         .job-details-grid {
//           display: grid;
//           grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
//           gap: 1.5rem;
//           margin-bottom: 2rem;
//         }

//         .detail-item {
//           display: flex;
//           align-items: center;
//           gap: 0.75rem;
//         }

//         .detail-label {
//           display: block;
//           font-size: 0.75rem;
//           color: var(--text-light);
//           margin-bottom: 0.25rem;
//         }

//         .detail-value {
//           font-size: 0.875rem;
//           color: var(--text);
//           font-weight: 500;
//         }

//         .job-section {
//           margin-bottom: 2rem;
//         }

//         .job-section h3 {
//           font-size: 1.125rem;
//           font-weight: 600;
//           color: var(--text);
//           margin-bottom: 1rem;
//         }

//         .job-section p {
//           color: var(--text-light);
//           line-height: 1.6;
//           margin-bottom: 1rem;
//         }

//         .job-stats {
//           display: grid;
//           grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
//           gap: 2rem;
//         }

//         .job-stat {
//           display: flex;
//           flex-direction: column;
//           gap: 0.5rem;
//         }

//         .job-stat .stat-label {
//           font-size: 0.875rem;
//           color: var(--text-light);
//         }

//         .job-stat .stat-value {
//           font-size: 2rem;
//           font-weight: 700;
//           color: var(--text);
//         }

//         .modal-actions {
//           display: flex;
//           gap: 1rem;
//           justify-content: flex-end;
//           padding-top: 1.5rem;
//           border-top: 1px solid var(--border);
//         }

//         /* Profile */
//         .profile-header {
//           display: flex;
//           align-items: center;
//           gap: 2rem;
//           margin-bottom: 2rem;
//         }

//         .profile-avatar-large {
//           width: 5rem;
//           height: 5rem;
//           border-radius: 50%;
//           background: linear-gradient(135deg, var(--primary), #8b5cf6);
//           color: white;
//           display: flex;
//           align-items: center;
//           justify-content: center;
//           font-size: 2rem;
//           font-weight: 600;
//         }

//         .profile-info h3 {
//           font-size: 1.5rem;
//           color: var(--text);
//           margin-bottom: 0.5rem;
//           font-weight: 700;
//         }

//         .profile-meta {
//           display: flex;
//           flex-direction: column;
//           gap: 0.5rem;
//           margin-bottom: 1rem;
//         }

//         .profile-email, .profile-location {
//           display: flex;
//           align-items: center;
//           gap: 0.5rem;
//           color: var(--text-light);
//           font-size: 0.875rem;
//         }

//         .profile-details {
//           margin-bottom: 2rem;
//         }

//         .detail-row {
//           display: grid;
//           grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
//           gap: 2rem;
//         }

//         /* Skills Grid */
//         .skills-grid {
//           display: grid;
//           grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
//           gap: 1.5rem;
//         }

//         .skill-progress-item {
//           display: flex;
//           flex-direction: column;
//           gap: 0.5rem;
//         }

//         .skill-name {
//           font-size: 0.875rem;
//           font-weight: 500;
//           color: var(--text);
//         }

//         .skill-progress {
//           display: flex;
//           align-items: center;
//           gap: 1rem;
//         }

//         .progress-value {
//           font-size: 0.875rem;
//           color: var(--text-light);
//           min-width: 3rem;
//           text-align: right;
//         }

//         /* Certifications */
//         .certifications-list, .evaluations-list, .matched-jobs-list {
//           display: flex;
//           flex-direction: column;
//           gap: 0.75rem;
//         }

//         .certification-item {
//           display: flex;
//           align-items: center;
//           gap: 0.75rem;
//           padding: 1rem;
//           background: var(--primary-light);
//           border-radius: 0.75rem;
//           color: var(--primary);
//           font-weight: 500;
//         }

//         .evaluation-item {
//           padding: 1rem;
//           background: var(--background);
//           border-radius: 0.75rem;
//         }

//         .evaluation-header {
//           display: flex;
//           justify-content: space-between;
//           margin-bottom: 0.75rem;
//         }

//         .evaluation-type {
//           font-weight: 600;
//           color: var(--text);
//           font-size: 0.875rem;
//         }

//         .evaluation-date {
//           color: var(--text-light);
//           font-size: 0.75rem;
//         }

//         .evaluation-score {
//           display: flex;
//           align-items: center;
//           gap: 1rem;
//         }

//         .score-bar {
//           flex: 1;
//           height: 0.5rem;
//           background: var(--border);
//           border-radius: 0.25rem;
//           overflow: hidden;
//         }

//         .score-fill {
//           height: 100%;
//           background: linear-gradient(90deg, var(--success), #34d399);
//           border-radius: 0.25rem;
//         }

//         .score-value {
//           font-size: 0.875rem;
//           font-weight: 600;
//           color: var(--text);
//           min-width: 3rem;
//           text-align: right;
//         }

//         /* Matched Jobs */
//         .matched-job-item {
//           padding: 1rem;
//           background: var(--background);
//           border-radius: 0.75rem;
//           border-left: 4px solid var(--primary);
//         }

//         .job-title {
//           font-weight: 600;
//           color: var(--text);
//           margin-bottom: 0.5rem;
//           font-size: 0.875rem;
//         }

//         .job-match-details {
//           display: flex;
//           gap: 1rem;
//           font-size: 0.75rem;
//           color: var(--text-light);
//         }

//         .match-score {
//           display: flex;
//           align-items: center;
//           gap: 0.25rem;
//           color: var(--success);
//           font-weight: 600;
//         }

//         .no-matches {
//           display: flex;
//           flex-direction: column;
//           align-items: center;
//           gap: 1rem;
//           color: var(--text-light);
//           text-align: center;
//           padding: 3rem;
//         }

//         /* Recommendations */
//         .recommendations-list {
//           display: flex;
//           flex-direction: column;
//           gap: 1rem;
//         }

//         .recommendation-item {
//           display: flex;
//           align-items: center;
//           gap: 1rem;
//           padding: 1rem;
//           background: var(--background);
//           border-radius: 0.75rem;
//           transition: all 0.2s ease;
//         }

//         .recommendation-item:hover {
//           background: var(--primary-light);
//         }

//         .recommendation-icon {
//           width: 2.5rem;
//           height: 2.5rem;
//           border-radius: 0.75rem;
//           background: var(--primary-light);
//           display: flex;
//           align-items: center;
//           justify-content: center;
//           color: var(--primary);
//         }

//         .recommendation-content {
//           flex: 1;
//         }

//         .recommendation-content h4 {
//           font-size: 0.875rem;
//           font-weight: 600;
//           color: var(--text);
//           margin-bottom: 0.25rem;
//         }

//         .recommendation-content p {
//           font-size: 0.75rem;
//           color: var(--text-light);
//         }

//         /* Responsive */
//         @media (max-width: 1024px) {
//           .content-grid,
//           .form-row,
//           .job-details-grid,
//           .trainee-profile-grid {
//             grid-template-columns: 1fr;
//           }
//         }

//         @media (max-width: 768px) {
//           .main-content {
//             padding: 1rem;
//           }

//           .stats-grid {
//             grid-template-columns: 1fr;
//           }

//           .section-header {
//             flex-direction: column;
//             gap: 1rem;
//             align-items: stretch;
//           }

//           .search-filter {
//             flex-direction: column;
//           }

//           .trainees-grid {
//             grid-template-columns: 1fr;
//           }

//           .trainee-actions {
//             flex-direction: column;
//           }

//           .modal-content {
//             width: 95%;
//           }

//           .header-actions {
//             flex-direction: column;
//             align-items: stretch;
//           }
//         }

//         @media (max-width: 640px) {
//           .content-grid {
//             grid-template-columns: 1fr;
//           }

//           .action-buttons {
//             flex-wrap: wrap;
//           }

//           .btn-action {
//             min-height: 3rem;
//           }

//           .form-actions {
//             flex-direction: column;
//           }

//           .modal-actions {
//             flex-direction: column;
//           }

//         }
//       `}</style>

//       <Sidebar 
//         items={sidebarItems}
//         activeTab={activeTab}
//         onTabChange={setActiveTab}
//         userData={userData}
//         onLogout={onLogout}
//       />
      
//       <div className="main-content">
//         <div className="dashboard-header">
//           <div className="header-title">
//             <h1>
//               <LayoutDashboard size={28} />
//               HR Dashboard
//             </h1>
//             <div className="header-subtitle">
//               Welcome back, {userData?.name || 'HR Manager'} | Talent Management & Job Allocation
//             </div>
//           </div>
//           <div className="header-actions">
//             <button className="btn-primary" onClick={() => {
//               alert('Report generation started. Check reports section.');
//             }}>
//               <Download size={18} />
//               Generate Report
//             </button>
//           </div>
//         </div>
        
//         {renderContent()}
//       </div>
      
//       {renderJobModal()}
//       {renderTraineeModal()}
//     </div>
//   );
// }

// export default DashboardHR;

import React, { useState } from 'react';
import {
  LayoutDashboard,
  Briefcase,
  Users,
  BarChart2,
  FileText,
  ExternalLink,
  Lightbulb,
  BarChart3,
  LogOut,
  TrendingUp,
  CheckCircle,
  Clock,
  MapPin,
  DollarSign,
  Calendar,
  Edit,
  Trash2,
  Eye,
  Search,
  Filter,
  X,
  ChevronRight,
  User,
  Mail,
  Star,
  Award,
  Target,
  PieChart,
  Download,
  Bell,
  Settings,
  Plus,
  ArrowLeft,
  Check,
  AlertCircle,
  Link,
  GraduationCap,
  BriefcaseBusiness,
  Building,
  Map,
  DollarSign as Dollar,
  CalendarDays,
  BookOpen,
  Brain,
  Sparkles,
  Zap,
  ThumbsUp,
  TrendingDown,
  FileSpreadsheet,
  File,
  Upload
} from 'lucide-react';
import Navbar from './Navbar';
import Sidebar from './Sidebar';

function DashboardHR({ userData, onLogout }) {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [selectedJob, setSelectedJob] = useState(null);
  const [selectedTrainee, setSelectedTrainee] = useState(null);
  const [isEditMode, setIsEditMode] = useState(false);
  const [showExcelTemplate, setShowExcelTemplate] = useState(false);
  const [showWordTemplate, setShowWordTemplate] = useState(false);
  const [techSkills, setTechSkills] = useState([]);
  const [softSkills, setSoftSkills] = useState([]);
  
  const [jobs, setJobs] = useState([
    { 
      id: 1, 
      title: 'Frontend Developer', 
      department: 'Technology', 
      location: ['Hyderabad', 'Bangalore'], 
      openings: 5, 
      filled: 2, 
      matches: 15, 
      status: 'active',
      description: 'Develop and maintain responsive web applications using React.js, TypeScript, and modern frontend technologies.',
      requirements: '3+ years of React experience, strong JavaScript fundamentals, experience with state management (Redux/MobX)',
      techSkills: ['React', 'JavaScript', 'TypeScript', 'CSS', 'HTML5', 'Redux'],
      softSkills: ['Communication', 'Teamwork', 'Problem Solving'],
      salary: '$85,000 - $110,000',
      postedDate: '2024-01-15',
      expiryDate: '2024-03-15'
    },
    { 
      id: 2, 
      title: 'Data Scientist', 
      department: 'Analytics', 
      location: ['Remote'], 
      openings: 3, 
      filled: 1, 
      matches: 8, 
      status: 'active',
      description: 'Build machine learning models and perform data analysis to drive business decisions.',
      requirements: 'Master\'s in Data Science, experience with Python, ML libraries, and SQL',
      techSkills: ['Python', 'Machine Learning', 'SQL', 'Pandas', 'TensorFlow'],
      softSkills: ['Analytical Thinking', 'Communication', 'Research'],
      salary: '$95,000 - $130,000',
      postedDate: '2024-01-20',
      expiryDate: '2024-03-20'
    },
    { 
      id: 3, 
      title: 'DevOps Engineer', 
      department: 'Operations', 
      location: ['Chennai'], 
      openings: 4, 
      filled: 3, 
      matches: 12, 
      status: 'active',
      description: 'Design and implement CI/CD pipelines and manage cloud infrastructure.',
      requirements: 'Experience with AWS, Docker, Kubernetes, and Terraform',
      techSkills: ['AWS', 'Docker', 'Kubernetes', 'Terraform', 'CI/CD'],
      softSkills: ['Collaboration', 'Attention to Detail', 'Process Improvement'],
      salary: '$100,000 - $140,000',
      postedDate: '2024-01-10',
      expiryDate: '2024-03-10'
    },
  ]);

  // Update the trainee data structure to include the JSON format
  const [trainees, setTrainees] = useState([
    { 
      id: 1, 
      name: 'John Smith', 
      email: 'john.smith@example.com',
      skills: ['React', 'JavaScript', 'CSS', 'TypeScript'],
      score: 85, 
      status: 'ready', 
      location: 'hyderabad', 
      matchedJobs: [
        { id: 1, title: 'Frontend Developer', matchScore: 92 },
        { id: 3, title: 'DevOps Engineer', matchScore: 65 }
      ],
      evaluations: [
        { date: '2024-01-15', type: 'Technical', score: 88 },
        { date: '2023-12-10', type: 'Behavioral', score: 82 }
      ],
      certifications: ['React Advanced', 'JavaScript Expert'],
      preferredLocation: 'hyderabad',
      experience: '2 years',
      education: 'B.Tech Computer Science',
      
      // New JSON format data
      traineeData: {
        id: 1,
        strengths: ["BizSkills", "Behavior Skill", "Projects"],
        weakness: ["Python", "Java", "WebTech"],
        upskillCourses: [
          {
            id: 2,
            courseId: 5386,
            courseName: "Python E1 competency",
            url: "https://ievolveng.ultimatix.net/ievolve/competencydetails/5386",
            platform: "Ievolve"
          },
          {
            id: 11,
            courseId: 5835,
            courseName: "Python- Web Frameworks E1 competency",
            url: "https://ievolveng.ultimatix.net/ievolve/competencydetails/5835",
            platform: "Ievolve"
          },
          {
            id: 1,
            courseId: 3224,
            courseName: "Java E1 competency",
            url: "https://ievolveng.ultimatix.net/ievolve/competencydetails/3224",
            platform: "Ievolve"
          }
        ],
        certificates: [
          {
            certificateId: 5,
            certificateName: "JAVA",
            provider: "UDEMY",
            acquiredDate: "2025-12-08",
            userId: 1
          },
          {
            certificateId: 6,
            certificateName: "AWS Certified Solutions Architect – Associate",
            provider: "Amazon Web Services",
            acquiredDate: "2024-03-15",
            userId: 1
          }
        ],
        userId: 2962,
        username: "John Smith",
        dpi: 1.95,
        location: "hyderabad",
        isu: "NGM PS EBU & Delivery Governance ,Risk & Security.",
        batchRank: "258/321",
        groupRank: "20/23",
        average: 36,
        role: "IGNITE TRAINEE",
        isActive: true,
        projectMatches: []
      }
    },
  ]);

  // State for new job creation
  const [newJob, setNewJob] = useState({
    title: '',
    department: '',
    location: [''],
    openings: 1,
    requirements: '',
    techSkills: [],
    softSkills: [],
    description: '',
    salary: '',
    expiryDate: ''
  });

  // Toggle job status
  const toggleJobStatus = (jobId) => {
    setJobs(jobs.map(job => 
      job.id === jobId 
        ? { ...job, status: job.status === 'active' ? 'inactive' : 'active' }
        : job
    ));
  };

  // Handle Excel upload
  const handleExcelUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      alert(`Excel file "${file.name}" uploaded successfully! Processing data...`);
      event.target.value = null;
    }
  };

  // Handle Word upload
  const handleWordUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      alert(`Word document "${file.name}" uploaded successfully! Processing data...`);
      event.target.value = null;
    }
  };

  // Add new location field
  const addLocationField = () => {
    setNewJob({
      ...newJob,
      location: [...newJob.location, '']
    });
  };

  // Remove location field
  const removeLocationField = (index) => {
    const newLocations = newJob.location.filter((_, i) => i !== index);
    setNewJob({
      ...newJob,
      location: newLocations
    });
  };

  // Update location field
  const updateLocationField = (index, value) => {
    const newLocations = [...newJob.location];
    newLocations[index] = value;
    setNewJob({
      ...newJob,
      location: newLocations
    });
  };

  // Handle tech skills input
  const handleTechSkillAdd = (e) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      const skill = e.target.value.trim();
      if (skill && !techSkills.includes(skill)) {
        const updatedSkills = [...techSkills, skill];
        setTechSkills(updatedSkills);
        setNewJob({
          ...newJob,
          techSkills: updatedSkills
        });
        e.target.value = '';
      }
    }
  };

  // Handle soft skills input
  const handleSoftSkillAdd = (e) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      const skill = e.target.value.trim();
      if (skill && !softSkills.includes(skill)) {
        const updatedSkills = [...softSkills, skill];
        setSoftSkills(updatedSkills);
        setNewJob({
          ...newJob,
          softSkills: updatedSkills
        });
        e.target.value = '';
      }
    }
  };

  // Remove tech skill
  const removeTechSkill = (index) => {
    const updatedSkills = techSkills.filter((_, i) => i !== index);
    setTechSkills(updatedSkills);
    setNewJob({
      ...newJob,
      techSkills: updatedSkills
    });
  };

  // Remove soft skill
  const removeSoftSkill = (index) => {
    const updatedSkills = softSkills.filter((_, i) => i !== index);
    setSoftSkills(updatedSkills);
    setNewJob({
      ...newJob,
      softSkills: updatedSkills
    });
  };

  // Excel Template Modal
  const renderExcelTemplateModal = () => {
    if (!showExcelTemplate) return null;

    return (
      <div className="modal-overlay" onClick={() => setShowExcelTemplate(false)}>
        <div className="modal-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '600px' }}>
          <div className="modal-header">
            <div className="modal-title">
              <FileSpreadsheet size={24} />
              <h2>Excel Upload Template</h2>
            </div>
            <button className="modal-close" onClick={() => setShowExcelTemplate(false)}>
              <X size={24} />
            </button>
          </div>
          
          <div className="modal-body">
            <div className="template-instructions">
              <h3>How to format your Excel file:</h3>
              <ol style={{ marginLeft: '20px', marginTop: '16px' }}>
                <li>Use the following columns in order:</li>
                <ul style={{ marginLeft: '20px', marginTop: '8px' }}>
                  <li>Title (Job Title)</li>
                  <li>Department</li>
                  <li>Location (comma-separated for multiple locations)</li>
                  <li>Openings (Number)</li>
                  <li>Requirements</li>
                  <li>Tech Skills (comma-separated)</li>
                  <li>Soft Skills (comma-separated)</li>
                  <li>Description</li>
                  {/* <li>Salary Range</li> */}
                  <li>Expiry Date (YYYY-MM-DD)</li>
                </ul>
                <li style={{ marginTop: '16px' }}>Save as .xlsx or .csv format</li>
                <li>Maximum file size: 10MB</li>
                <li>Do not modify the column headers</li>
              </ol>
              
              <div className="sample-data" style={{ marginTop: '24px', padding: '16px', background: '#f8fafc', borderRadius: '8px' }}>
                <h4>Sample Row:</h4>
                <pre style={{ 
                  background: '#e2e8f0', 
                  padding: '12px', 
                  borderRadius: '6px',
                  marginTop: '8px',
                  fontSize: '12px',
                  overflowX: 'auto'
                }}>
                  Frontend Developer,Technology,Hyderabad,Bangalore,3,3+ years React experience...,React,JavaScript,TypeScript,Communication,Teamwork,Develop web applications...,$85,000 - $110,000,2024-03-15
                </pre>
              </div>
            </div>
          </div>
          
          <div className="modal-actions">
            <button className="btn-secondary" onClick={() => setShowExcelTemplate(false)}>
              Close
            </button>
            <button className="btn-primary" onClick={() => {
              document.getElementById('excelUpload').click();
              setShowExcelTemplate(false);
            }}>
              <Upload size={18} />
              Upload Excel
            </button>
          </div>
        </div>
      </div>
    );
  };

  // Word Template Modal
  const renderWordTemplateModal = () => {
    if (!showWordTemplate) return null;

    return (
      <div className="modal-overlay" onClick={() => setShowWordTemplate(false)}>
        <div className="modal-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '600px' }}>
          <div className="modal-header">
            <div className="modal-title">
              <File size={24} />
              <h2>Word Document Template</h2>
            </div>
            <button className="modal-close" onClick={() => setShowWordTemplate(false)}>
              <X size={24} />
            </button>
          </div>
          
          <div className="modal-body">
            <div className="template-instructions">
              <h3>Document Format Requirements:</h3>
              <div style={{ marginTop: '16px' }}>
                <h4>Required Sections:</h4>
                <ul style={{ marginLeft: '20px', marginTop: '8px' }}>
                  <li><strong>Job Title:</strong> Clear and descriptive</li>
                  <li><strong>Department:</strong> Specify the department</li>
                  <li><strong>Locations:</strong> List all locations (one per line)</li>
                  <li><strong>Number of Openings:</strong> Specify the count</li>
                  <li><strong>Technical Requirements:</strong> List technical skills and qualifications</li>
                  <li><strong>Soft Skills:</strong> List desired soft skills</li>
                  <li><strong>Job Description:</strong> Detailed responsibilities</li>
                  {/* <li><strong>Salary Information:</strong> Range or package details</li> */}
                  <li><strong>Application Deadline:</strong> Date in YYYY-MM-DD format</li>
                </ul>
              </div>
              
              <div className="format-example" style={{ marginTop: '24px', padding: '16px', background: '#f8fafc', borderRadius: '8px' }}>
                <h4>Format Example:</h4>
                <div style={{ 
                  background: 'white', 
                  padding: '16px', 
                  borderRadius: '6px',
                  marginTop: '8px',
                  border: '1px solid #e5e7eb'
                }}>
                  <p><strong>Job Title:</strong> Frontend Developer</p>
                  <p><strong>Department:</strong> Technology</p>
                  <p><strong>Locations:</strong><br />- Hyderabad<br />- Bangalore</p>
                  <p><strong>Openings:</strong> 3</p>
                  <p><strong>Technical Skills:</strong> React, JavaScript, TypeScript, CSS, HTML5</p>
                  <p><strong>Soft Skills:</strong> Communication, Teamwork, Problem Solving</p>
                  <p><strong>Description:</strong> [Detailed description here...]</p>
                  <p><strong>Salary:</strong> $85,000 - $110,000</p>
                  <p><strong>Deadline:</strong> 2024-03-15</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="modal-actions">
            <button className="btn-secondary" onClick={() => setShowWordTemplate(false)}>
              Close
            </button>
            <button className="btn-primary" onClick={() => {
              document.getElementById('wordUpload').click();
              setShowWordTemplate(false);
            }}>
              <Upload size={18} />
              Upload Word Doc
            </button>
          </div>
        </div>
      </div>
    );
  };

  // Hidden file inputs
  const renderHiddenFileInputs = () => (
    <>
      <input
        type="file"
        id="excelUpload"
        accept=".xlsx,.xls,.csv"
        style={{ display: 'none' }}
        onChange={handleExcelUpload}
      />
      <input
        type="file"
        id="wordUpload"
        accept=".doc,.docx"
        style={{ display: 'none' }}
        onChange={handleWordUpload}
      />
    </>
  );

  // Statistics Calculations
  const calculateStatistics = () => {
    const totalTrainees = trainees.length;
    const totalJobs = jobs.length;
    const mappedTrainees = trainees.filter(t => t.matchedJobs.length > 0).length;
    const unmappedTrainees = totalTrainees - mappedTrainees;
    const readyTrainees = trainees.filter(t => t.status === 'ready').length;
    const trainingTrainees = trainees.filter(t => t.status === 'training').length;
    const activeJobs = jobs.filter(j => j.status === 'active').length;
    const filledPositions = jobs.reduce((sum, job) => sum + job.filled, 0);
    const totalOpenings = jobs.reduce((sum, job) => sum + job.openings, 0);
    const fillRate = totalOpenings > 0 ? Math.round((filledPositions / totalOpenings) * 100) : 0;

    return {
      totalTrainees,
      totalJobs,
      mappedTrainees,
      unmappedTrainees,
      readyTrainees,
      trainingTrainees,
      activeJobs,
      filledPositions,
      totalOpenings,
      fillRate
    };
  };

  const stats = calculateStatistics();

  const renderDashboard = () => {
    return (
      <div className="dashboard-content">
        <div className="stats-grid">
          <div className="stat-card">
            <div className="stat-icon">
              <Users className="stat-icon-svg" />
            </div>
            <div className="stat-content">
              <h3>Total Trainees</h3>
              <div className="stat-value">{stats.totalTrainees}</div>
            </div>
          </div>
          
          <div className="stat-card">
            <div className="stat-icon">
              <BriefcaseBusiness className="stat-icon-svg" />
            </div>
            <div className="stat-content">
              <h3>Total Jobs</h3>
              <div className="stat-value">{stats.totalJobs}</div>
            </div>
          </div>
          
          <div className="stat-card">
            <div className="stat-icon">
              <CheckCircle className="stat-icon-svg" />
            </div>
            <div className="stat-content">
              <h3>Mapped Trainees</h3>
              <div className="stat-value">{stats.mappedTrainees}</div>
            </div>
          </div>
          
          <div className="stat-card">
            <div className="stat-icon">
              <AlertCircle className="stat-icon-svg" />
            </div>
            <div className="stat-content">
              <h3>Unmapped Trainees</h3>
              <div className="stat-value">{stats.unmappedTrainees}</div>
            </div>
          </div>
          
          <div className="stat-card">
            <div className="stat-icon">
              <Target className="stat-icon-svg" />
            </div>
            <div className="stat-content">
              <h3>Job Ready</h3>
              <div className="stat-value">{stats.readyTrainees}</div>
            </div>
          </div>
        </div>

        <div className="content-grid">
          <div className="content-card">
            <div className="card-header">
              <h3>
                <Briefcase size={20} />
                Recent Job Matches
              </h3>
              <button className="btn-text">
                View All <ChevronRight size={16} />
              </button>
            </div>
            <div className="table-container">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Trainee</th>
                    <th>Job Role</th>
                    <th>Match Score</th>
                    <th>Location</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {trainees.flatMap(trainee => 
                    trainee.matchedJobs.map(job => ({
                      trainee,
                      job,
                      jobDetails: jobs.find(j => j.id === job.id)
                    }))
                  ).slice(0, 5).map((match, index) => (
                    <tr key={index}>
                      <td>
                        <div className="user-cell">
                          <div className="user-avatar-sm">
                            {match.trainee.name.charAt(0)}
                          </div>
                          <span>{match.trainee.name}</span>
                        </div>
                      </td>
                      <td>{match.jobDetails?.title || match.job.title}</td>
                      <td>
                        <div className={`score-badge ${match.job.matchScore >= 90 ? 'score-high' : match.job.matchScore >= 75 ? 'score-medium' : 'score-low'}`}>
                          {match.job.matchScore}%
                        </div>
                      </td>
                      <td>
                        <div className="location-cell">
                          <MapPin size={14} />
                          {match.trainee.location}
                        </div>
                      </td>
                      <td>
                        <div className={`status-badge ${match.job.matchScore >= 80 ? 'status-approved' : 'status-pending'}`}>
                          {match.job.matchScore >= 80 ? (
                            <>
                              <ThumbsUp size={14} />
                              High Match
                            </>
                          ) : (
                            <>
                              <Clock size={14} />
                              Review
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="content-card">
            <div className="card-header">
              <h3>
                <Brain size={20} />
                Top Skills in Demand
              </h3>
              <button className="btn-text">
                View All <ChevronRight size={16} />
              </button>
            </div>
            <div className="skills-list">
              {[
                { name: 'React', demand: 95, jobs: 8 },
                { name: 'Python', demand: 92, jobs: 6 },
                { name: 'AWS', demand: 88, jobs: 5 },
                { name: 'Machine Learning', demand: 85, jobs: 4 },
                { name: 'UI/UX', demand: 82, jobs: 3 },
                { name: 'DevOps', demand: 78, jobs: 4 },
              ].map(skill => (
                <div key={skill.name} className="skill-item">
                  <div className="skill-header">
                    <span className="skill-name">{skill.name}</span>
                    <div className="skill-stats">
                      <span className="skill-jobs">{skill.jobs} jobs</span>
                      <span className="skill-demand">{skill.demand}%</span>
                    </div>
                  </div>
                  <div className="skill-bar">
                    <div 
                      className="skill-fill" 
                      style={{ width: `${skill.demand}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  };

  // Update renderJobManagement to include new buttons
  const renderJobManagement = () => (
    <div className="job-management">
      <div className="section-header">
        <div className="header-title">
          <h2>
            <Briefcase size={24} />
            Job Profiles Management
          </h2>
          <p className="subtitle">Manage and track all job positions</p>
        </div>
        <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
          <div className="upload-buttons" style={{ display: 'flex', gap: '8px' }}>
            <button 
              className="btn-secondary"
              onClick={() => setShowExcelTemplate(true)}
              style={{ display: 'flex', alignItems: 'center', gap: '8px' }}
            >
              <FileSpreadsheet size={18} />
              Upload Excel
            </button>
            <button 
              className="btn-secondary"
              onClick={() => setShowWordTemplate(true)}
              style={{ display: 'flex', alignItems: 'center', gap: '8px' }}
            >
              <File size={18} />
              Upload Word
            </button>
          </div>
          <button 
            className="btn-primary"
            onClick={() => {
              setSelectedJob(null);
              setIsEditMode(false);
              setActiveTab('createJob');
            }}
          >
            <Plus size={18} />
            Create New Job
          </button>
        </div>
      </div>

      <div className="table-container">
        <table className="data-table">
          <thead>
            <tr>
              <th>Job Title</th>
              <th>Department</th>
              <th>Location(s)</th>
              <th>Openings</th>
              <th>Filled</th>
              <th>Matches</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {jobs.map(job => (
              <tr key={job.id}>
                <td>
                  <div className="job-title-cell">
                    <div className="job-icon">
                      <BriefcaseBusiness size={16} />
                    </div>
                    <span className="font-medium">{job.title}</span>
                  </div>
                </td>
                <td>
                  <div className="department-cell">
                    <Building size={14} />
                    {job.department}
                  </div>
                </td>
                <td>
                  <div className="location-cell">
                    <MapPin size={14} />
                    {Array.isArray(job.location) ? job.location.join(', ') : job.location}
                  </div>
                </td>
                <td>
                  <div className="openings-cell">
                    {job.openings}
                  </div>
                </td>
                <td>
                  <div className={`filled-cell ${job.filled === job.openings ? 'filled-complete' : ''}`}>
                    {job.filled}/{job.openings}
                  </div>
                </td>
                <td>
                  <div className="matches-cell">
                    {job.matches}
                  </div>
                </td>
                <td>
                  <button 
                    className={`status-button ${job.status === 'active' ? 'status-active' : 'status-inactive'}`}
                    onClick={() => toggleJobStatus(job.id)}
                    style={{
                      padding: '4px 12px',
                      borderRadius: '9999px',
                      border: 'none',
                      fontSize: '12px',
                      fontWeight: '600',
                      cursor: 'pointer',
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: '4px'
                    }}
                  >
                    {job.status === 'active' ? (
                      <>
                        <CheckCircle size={12} />
                        Active
                      </>
                    ) : (
                      <>
                        <X size={12} />
                        Inactive
                      </>
                    )}
                  </button>
                </td>
                <td>
                  <div className="action-buttons">
                    <button 
                      className="btn-icon btn-icon-view"
                      onClick={() => {
                        setSelectedJob(job);
                        setIsEditMode(false);
                      }}
                    >
                      <Eye size={16} />
                    </button>
                    <button 
                      className="btn-icon btn-icon-edit"
                      onClick={() => {
                        setSelectedJob(job);
                        setIsEditMode(true);
                        setActiveTab('createJob');
                        setTechSkills(job.techSkills || []);
                        setSoftSkills(job.softSkills || []);
                      }}
                    >
                      <Edit size={16} />
                    </button>
                    <button 
                      className="btn-icon btn-icon-delete"
                      onClick={() => {
                        if (window.confirm('Are you sure you want to delete this job?')) {
                          setJobs(jobs.filter(j => j.id !== job.id));
                        }
                      }}
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  // Update renderCreateJob to include multiple locations and two skill fields
  const renderCreateJob = () => {
    const jobToEdit = selectedJob || newJob;
    const isEditing = !!selectedJob && isEditMode;

    return (
      <div className="create-job">
        <div className="section-header">
          <div className="header-title">
            <h2>
              {isEditing ? (
                <>
                  <Edit size={24} />
                  Edit Job Profile
                </>
              ) : (
                <>
                  <Plus size={24} />
                  Create New Job Profile
                </>
              )}
            </h2>
            <p className="subtitle">
              {isEditing ? 'Update existing job details' : 'Fill in the details to create a new job position'}
            </p>
          </div>
          <button 
            className="btn-secondary"
            onClick={() => {
              setSelectedJob(null);
              setIsEditMode(false);
              setActiveTab('jobs');
              setNewJob({
                title: '',
                department: '',
                location: [''],
                openings: 1,
                requirements: '',
                techSkills: [],
                softSkills: [],
                description: '',
                salary: '',
                expiryDate: ''
              });
              setTechSkills([]);
              setSoftSkills([]);
            }}
          >
            <ArrowLeft size={18} />
            Back to Jobs
          </button>
        </div>

        <div className="form-card">
          <form onSubmit={(e) => {
            e.preventDefault();
            if (isEditing) {
              handleUpdateJob(jobToEdit);
            } else {
              handleCreateJob();
            }
          }}>
            <div className="form-section">
              <h3 className="form-section-title">
                <Briefcase size={20} />
                Basic Information
              </h3>
              <div className="form-row">
                <div className="form-group">
                  <label>
                    <span className="required">*</span>
                    Job Title
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    value={jobToEdit.title}
                    onChange={(e) => isEditing ? 
                      setSelectedJob({...jobToEdit, title: e.target.value}) :
                      setNewJob({...newJob, title: e.target.value})
                    }
                    required
                    placeholder="e.g., Senior Frontend Developer"
                  />
                </div>
                <div className="form-group">
                  <label>
                    <span className="required">*</span>
                    Department
                  </label>
                  <select
                    className="form-control"
                    value={jobToEdit.department}
                    onChange={(e) => isEditing ? 
                      setSelectedJob({...jobToEdit, department: e.target.value}) :
                      setNewJob({...newJob, department: e.target.value})
                    }
                    required
                  >
                    <option value="">Select Department</option>
                    <option value="Technology">Technology</option>
                    <option value="Analytics">Analytics</option>
                    <option value="Design">Design</option>
                    <option value="Operations">Operations</option>
                    <option value="Marketing">Marketing</option>
                    <option value="Sales">Sales</option>
                  </select>
                </div>
              </div>

              {/* Multiple Locations */}
              <div className="form-group">
                <label>
                  <span className="required">*</span>
                  Locations
                  <span style={{ fontSize: '12px', color: '#6b7280', marginLeft: '8px' }}>
                    (Add multiple locations if needed)
                  </span>
                </label>
                {jobToEdit.location.map((loc, index) => (
                  <div key={index} style={{ display: 'flex', gap: '8px', marginBottom: '8px' }}>
                    <input
                      type="text"
                      className="form-control"
                      value={loc}
                      onChange={(e) => {
                        if (isEditing) {
                          const newLocs = [...jobToEdit.location];
                          newLocs[index] = e.target.value;
                          setSelectedJob({...jobToEdit, location: newLocs});
                        } else {
                          updateLocationField(index, e.target.value);
                        }
                      }}
                      required={index === 0}
                      placeholder="e.g., Hyderabad"
                    />
                    {jobToEdit.location.length > 1 && (
                      <button
                        type="button"
                        className="btn-icon"
                        onClick={() => {
                          if (isEditing) {
                            const newLocs = jobToEdit.location.filter((_, i) => i !== index);
                            setSelectedJob({...jobToEdit, location: newLocs});
                          } else {
                            removeLocationField(index);
                          }
                        }}
                        style={{ 
                          width: '40px', 
                          height: '40px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center'
                        }}
                      >
                        <X size={16} />
                      </button>
                    )}
                  </div>
                ))}
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={addLocationField}
                  style={{ 
                    marginTop: '8px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    padding: '8px 16px'
                  }}
                >
                  <Plus size={16} />
                  Add Another Location
                </button>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>
                    <span className="required">*</span>
                    Number of Openings
                  </label>
                  <input
                    type="number"
                    className="form-control"
                    value={jobToEdit.openings}
                    onChange={(e) => isEditing ? 
                      setSelectedJob({...jobToEdit, openings: parseInt(e.target.value) || 1}) :
                      setNewJob({...newJob, openings: parseInt(e.target.value) || 1})
                    }
                    min="1"
                    required
                  />
                </div>
                <div className="form-group">
                  <label>
                    <Calendar size={16} />
                    Expiry Date
                  </label>
                  <input
                    type="date"
                    className="form-control"
                    value={jobToEdit.expiryDate}
                    onChange={(e) => isEditing ? 
                      setSelectedJob({...jobToEdit, expiryDate: e.target.value}) :
                      setNewJob({...newJob, expiryDate: e.target.value})
                    }
                  />
                </div>
              </div>

              {/* <div className="form-row">
                <div className="form-group">
                  <label>
                    <DollarSign size={16} />
                    Salary Range
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    value={jobToEdit.salary}
                    onChange={(e) => isEditing ? 
                      setSelectedJob({...jobToEdit, salary: e.target.value}) :
                      setNewJob({...newJob, salary: e.target.value})
                    }
                    placeholder="e.g., $85,000 - $110,000"
                  />
                </div>
              </div> */}
            </div>

            <div className="form-section">
              <h3 className="form-section-title">
                <BookOpen size={20} />
                Requirements & Skills
              </h3>
              
              {/* Tech Skills */}
              <div className="form-group">
                <label>
                  <span className="required">*</span>
                  Technical Skills
                </label>
                <div className="skills-input">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Type technical skill and press Enter or comma"
                    onKeyDown={handleTechSkillAdd}
                  />
                  <div className="skills-tags" style={{ marginTop: '8px' }}>
                    {(isEditing ? jobToEdit.techSkills : techSkills).map((skill, index) => (
                      <span key={index} className="skill-tag" style={{ background: '#dbeafe', color: '#1e40af' }}>
                        {skill}
                        <button 
                          type="button"
                          className="tag-remove"
                          onClick={() => {
                            if (isEditing) {
                              const newSkills = jobToEdit.techSkills.filter((_, i) => i !== index);
                              setSelectedJob({...jobToEdit, techSkills: newSkills});
                            } else {
                              removeTechSkill(index);
                            }
                          }}
                        >
                          <X size={12} />
                        </button>
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Soft Skills */}
              <div className="form-group">
                <label>
                  Soft Skills
                </label>
                <div className="skills-input">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Type soft skill and press Enter or comma"
                    onKeyDown={handleSoftSkillAdd}
                  />
                  <div className="skills-tags" style={{ marginTop: '8px' }}>
                    {(isEditing ? jobToEdit.softSkills : softSkills).map((skill, index) => (
                      <span key={index} className="skill-tag" style={{ background: '#dcfce7', color: '#166534' }}>
                        {skill}
                        <button 
                          type="button"
                          className="tag-remove"
                          onClick={() => {
                            if (isEditing) {
                              const newSkills = jobToEdit.softSkills.filter((_, i) => i !== index);
                              setSelectedJob({...jobToEdit, softSkills: newSkills});
                            } else {
                              removeSoftSkill(index);
                            }
                          }}
                        >
                          <X size={12} />
                        </button>
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="form-group">
                <label>
                  <span className="required">*</span>
                  Job Description
                </label>
                <textarea
                  className="form-control"
                  rows="4"
                  value={jobToEdit.description}
                  onChange={(e) => isEditing ? 
                    setSelectedJob({...jobToEdit, description: e.target.value}) :
                    setNewJob({...newJob, description: e.target.value})
                  }
                  placeholder="Describe the job role, responsibilities, and expectations..."
                  required
                ></textarea>
              </div>

              <div className="form-group">
                <label>
                  <span className="required">*</span>
                  Requirements & Qualifications
                </label>
                <textarea
                  className="form-control"
                  rows="4"
                  value={jobToEdit.requirements}
                  onChange={(e) => isEditing ? 
                    setSelectedJob({...jobToEdit, requirements: e.target.value}) :
                    setNewJob({...newJob, requirements: e.target.value})
                  }
                  placeholder="List the required experience, education, certifications, etc."
                  required
                ></textarea>
              </div>
            </div>

            <div className="form-actions">
              <button 
                type="button" 
                className="btn-secondary"
                onClick={() => {
                  setSelectedJob(null);
                  setIsEditMode(false);
                  setActiveTab('jobs');
                  setNewJob({
                    title: '',
                    department: '',
                    location: [''],
                    openings: 1,
                    requirements: '',
                    techSkills: [],
                    softSkills: [],
                    description: '',
                    salary: '',
                    expiryDate: ''
                  });
                  setTechSkills([]);
                  setSoftSkills([]);
                }}
              >
                Cancel
              </button>
              <button type="submit" className="btn-primary">
                {isEditing ? (
                  <>
                    <Check size={18} />
                    Update Job Profile
                  </>
                ) : (
                  <>
                    <Plus size={18} />
                    Create Job Profile
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  };

  const renderTraineesList = () => (
    <div className="trainees-list">
      <div className="section-header">
        <div className="header-title">
          <h2>
            <Users size={24} />
            Trainees Management
          </h2>
          <p className="subtitle">Manage and track all trainees in the system</p>
        </div>
        <div className="view-options">
          <button 
            className={`btn-view-option ${activeTab === 'trainees' ? 'active' : ''}`}
            onClick={() => setActiveTab('trainees')}
          >
            All Trainees
          </button>
          <button 
            className={`btn-view-option ${activeTab === 'mapped' ? 'active' : ''}`}
            onClick={() => setActiveTab('mapped')}
          >
            <CheckCircle size={16} />
            Mapped ({stats.mappedTrainees})
          </button>
          <button 
            className={`btn-view-option ${activeTab === 'unmapped' ? 'active' : ''}`}
            onClick={() => setActiveTab('unmapped')}
          >
            <AlertCircle size={16} />
            Unmapped ({stats.unmappedTrainees})
          </button>
        </div>
      </div>

      <div className="search-filter">
        <div className="search-box">
          <Search size={18} />
          <input 
            type="text" 
            className="search-input" 
            placeholder="Search trainees by name, skills, or location..."
          />
        </div>
        <div className="filter-group">
          <button className="btn-filter">
            <Filter size={18} />
            Filter
          </button>
          <select className="filter-select">
            <option value="">All Status</option>
            <option value="ready">Job Ready</option>
            <option value="training">In Training</option>
          </select>
          <button className="btn-icon">
            <Download size={18} />
          </button>
        </div>
      </div>

      <div className="trainees-grid">
        {trainees
          .filter(trainee => {
            if (activeTab === 'mapped') return trainee.matchedJobs.length > 0;
            if (activeTab === 'unmapped') return trainee.matchedJobs.length === 0;
            return true;
          })
          .map(trainee => (
            <div key={trainee.id} className="trainee-card">
              <div className="trainee-header">
                <div className="trainee-info-main">
                  <div className="trainee-avatar">
                    {trainee.name.charAt(0)}
                  </div>
                  <div className="trainee-info">
                    <h4>{trainee.name}</h4>
                    <div className="trainee-meta">
                      <span className="trainee-email">
                        <Mail size={14} />
                        {trainee.email}
                      </span>
                      <span className="trainee-location">
                        <MapPin size={14} />
                        {trainee.location}
                      </span>
                    </div>
                  </div>
                </div>
                <div className={`mapping-indicator ${trainee.matchedJobs.length > 0 ? 'mapped' : 'unmapped'}`}>
                  {trainee.matchedJobs.length > 0 ? (
                    <>
                      <CheckCircle size={14} />
                      Mapped
                    </>
                  ) : (
                    <>
                      <AlertCircle size={14} />
                      Unmapped
                    </>
                  )}
                </div>
              </div>
              
              <div className="trainee-skills">
                {trainee.skills.slice(0, 4).map(skill => (
                  <span key={skill} className="skill-tag">
                    {skill}
                  </span>
                ))}
                {trainee.skills.length > 4 && (
                  <span className="skill-tag-more">
                    +{trainee.skills.length - 4}
                  </span>
                )}
              </div>
              
              <div className="trainee-stats">
                <div className="trainee-stat">
                  <span className="stat-label">Readiness Score</span>
                  <div className="score-progress">
                    <div className="progress-bar">
                      <div 
                        className="progress-fill" 
                        style={{ width: `${trainee.score}%` }}
                      ></div>
                    </div>
                    <span className="score-value">{trainee.score}%</span>
                  </div>
                </div>
                <div className="trainee-stat">
                  <span className="stat-label">Matched Jobs</span>
                  <div className="matched-jobs-count">
                    <span className="match-count">{trainee.matchedJobs.length}</span>
                    {trainee.matchedJobs.length > 0 && (
                      <span className="best-match">
                        <Star size={12} />
                        Best: {Math.max(...trainee.matchedJobs.map(j => j.matchScore))}%
                      </span>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="trainee-actions">
                <button 
                  className="btn-action btn-profile"
                  onClick={() => setSelectedTrainee(trainee)}
                >
                  <User size={16} />
                  View Profile
                </button>
                {trainee.matchedJobs.length > 0 ? (
                  <button className="btn-action btn-view-matches">
                    <Briefcase size={16} />
                    View Matches ({trainee.matchedJobs.length})
                  </button>
                ) : (
                  <button className="btn-action btn-find-matches">
                    <Sparkles size={16} />
                    Find Matches
                  </button>
                )}
              </div>
            </div>
          ))}
      </div>
    </div>
  );

  const handleCreateJob = () => {
    const newJobObj = {
      ...newJob,
      id: jobs.length + 1,
      matches: 0,
      filled: 0,
      status: 'active',
      postedDate: new Date().toISOString().split('T')[0]
    };
    setJobs([...jobs, newJobObj]);
    setActiveTab('jobs');
    setNewJob({
      title: '',
      department: '',
      location: [''],
      openings: 1,
      requirements: '',
      techSkills: [],
      softSkills: [],
      description: '',
      salary: '',
      expiryDate: ''
    });
    setTechSkills([]);
    setSoftSkills([]);
  };

  const handleUpdateJob = (updatedJob) => {
    setJobs(jobs.map(job => job.id === updatedJob.id ? updatedJob : job));
    setSelectedJob(null);
    setIsEditMode(false);
    setActiveTab('jobs');
    setTechSkills([]);
    setSoftSkills([]);
  };

  const renderTraineeModal = () => {
    if (!selectedTrainee) return null;

    // Calculate matching projects
    const calculateMatchingProjects = () => {
      const traineeData = selectedTrainee.traineeData || selectedTrainee;
      const traineeSkills = [
        ...(traineeData.strengths || []),
        ...(selectedTrainee.skills || [])
      ];
      
      return jobs.map(job => {
        const requiredSkills = [...(job.techSkills || []), ...(job.softSkills || [])];
        const matchedSkills = requiredSkills.filter(skill =>
          traineeSkills.includes(skill)
        );
        const matchScore = Math.round((matchedSkills.length / Math.max(requiredSkills.length, 1)) * 100);
        
        const isMapped = selectedTrainee.matchedJobs?.some(mj => mj.id === job.id);
        const isInOpenPool = traineeData.projectMatches?.some(pm => 
          pm.projectId === job.id && pm.status === 'open-pool'
        );
        
        return {
          ...job,
          matchScore: isNaN(matchScore) ? 0 : matchScore,
          matchedSkills,
          missingSkills: requiredSkills.filter(skill => !matchedSkills.includes(skill)),
          status: isMapped ? 'mapped' : isInOpenPool ? 'open-pool' : 'pending',
          reason: matchScore >= 80 ?
            `Excellent match! ${matchedSkills.length} out of ${requiredSkills.length} skills match.` :
            matchScore >= 50 ?
            `Good potential match. Consider additional training for ${requiredSkills.length - matchedSkills.length} skills.` :
            `Low match. Requires significant training in ${requiredSkills.length - matchedSkills.length} skills.`
        };
      }).filter(proj => proj.matchScore > 0)
        .sort((a, b) => b.matchScore - a.matchScore);
    };

    const handleMapToProject = (projectId) => {
      const project = jobs.find(p => p.id === projectId);
      if (!project) return;
      
      if (project.filled >= project.openings) {
        alert(`No openings available for ${project.title}.`);
        return;
      }
      
      setTrainees(trainees.map(t => 
        t.id === selectedTrainee.id 
          ? {
              ...t,
              matchedJobs: [
                ...(t.matchedJobs || []),
                { 
                  id: projectId, 
                  title: project.title, 
                  matchScore: calculateMatchingProjects().find(p => p.id === projectId)?.matchScore || 0
                }
              ],
              traineeData: {
                ...t.traineeData,
                projectMatches: [
                  ...(t.traineeData?.projectMatches || []),
                  {
                    projectId,
                    projectTitle: project.title,
                    status: 'mapped',
                    date: new Date().toISOString().split('T')[0],
                    mappedBy: userData?.name || 'HR Manager'
                  }
                ]
              }
            }
          : t
      ));
      
      setJobs(jobs.map(j => 
        j.id === projectId 
          ? { ...j, filled: j.filled + 1 }
          : j
      ));
      alert(`${selectedTrainee.name} mapped to ${project.title}!`);
    };

    const traineeData = selectedTrainee.traineeData || selectedTrainee;
    const matchingProjects = calculateMatchingProjects();

    return (
      <div className="modal-overlay" onClick={() => setSelectedTrainee(null)}>
        <div className="modal-content" onClick={e => e.stopPropagation()}>
          <div className="modal-header">
            <div className="modal-title">
              <User size={24} />
              <h2>{traineeData.username || selectedTrainee.name}</h2>
            </div>
            <button className="modal-close" onClick={() => setSelectedTrainee(null)}>
              <X size={24} />
            </button>
          </div>

          <div className="modal-body">
            <div className="profile-header">
              <div className="profile-avatar">
                {traineeData.username?.charAt(0) || selectedTrainee.name.charAt(0)}
              </div>
              <div className="profile-info">
                <h3>{traineeData.username || selectedTrainee.name}</h3>
                <div className="profile-role">{traineeData.role || 'TRAINEE'}</div>
                <div className="profile-meta">
                  <span className="profile-meta-item">
                    <MapPin size={16} />
                    {traineeData.location || selectedTrainee.location}
                  </span>
                  <span className="profile-meta-item">
                    <Mail size={16} />
                    {selectedTrainee.email}
                  </span>
                  <span className="profile-meta-item">
                    <Target size={16} />
                    DPI: {traineeData.dpi || 'N/A'}
                  </span>
                  <span className="profile-meta-item">
                    <BarChart2 size={16} />
                    Score: {selectedTrainee.score}%
                  </span>
                </div>
              </div>
            </div>

            <div className="info-grid">
              <div className="info-card">
                <h4>
                  <User size={16} />
                  Basic Information
                </h4>
                <div className="info-content">
                  <div className="info-row">
                    <span className="info-label">User ID</span>
                    <span className="info-value">{traineeData.userId || 'N/A'}</span>
                  </div>
                  <div className="info-row">
                    <span className="info-label">ISU</span>
                    <span className="info-value">{traineeData.isu || 'N/A'}</span>
                  </div>
                  <div className="info-row">
                    <span className="info-label">Batch Rank</span>
                    <span className="info-value">{traineeData.batchRank || 'N/A'}</span>
                  </div>
                  <div className="info-row">
                    <span className="info-label">Group Rank</span>
                    <span className="info-value">{traineeData.groupRank || 'N/A'}</span>
                  </div>
                  <div className="info-row">
                    <span className="info-label">Average</span>
                    <span className="info-value">{traineeData.average || 0}%</span>
                  </div>
                </div>
              </div>
              <div className="info-card">
                <h4>
                  <Briefcase size={16} />
                  Employment Details
                </h4>
                <div className="info-content">
                  <div className="info-row">
                    <span className="info-label">Experience</span>
                    <span className="info-value">{selectedTrainee.experience || 'N/A'}</span>
                  </div>
                  <div className="info-row">
                    <span className="info-label">Education</span>
                    <span className="info-value">{selectedTrainee.education || 'N/A'}</span>
                  </div>
                  <div className="info-row">
                    <span className="info-label">Preferred Location</span>
                    <span className="info-value">{selectedTrainee.preferredLocation || 'N/A'}</span>
                  </div>
                  <div className="info-row">
                    <span className="info-label">Status</span>
                    <span className="info-value">{selectedTrainee.status === 'ready' ? 'Job Ready' : selectedTrainee.status === 'training' ? 'In Training' : 'Inactive'}</span>
                  </div>
                  <div className="info-row">
                    <span className="info-label">Projects Matched</span>
                    <span className="info-value">{selectedTrainee.matchedJobs?.length || 0}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="projects-section">
              <div className="projects-header">
                <h3 className="section-title">
                  <Briefcase size={18} />
                  Project Matching
                  <span style={{ marginLeft: '8px', fontSize: '14px', color: 'var(--text-light)' }}>
                    ({matchingProjects.length} projects)
                  </span>
                </h3>
              </div>

              <div className="projects-grid">
                {matchingProjects.map(project => {
                  const isMapped = project.status === 'mapped';
                  const isAvailable = project.openings > project.filled;

                  return (
                    <div key={project.id} className={`project-card ${isMapped ? 'mapped' : ''}`}>
                      <div className="project-header">
                        <div className="project-title">
                          <h4>{project.title}</h4>
                          <div className="project-meta">
                            <span>
                              <Building size={14} />
                              {project.department}
                            </span>
                            <span>
                              <MapPin size={14} />
                              {Array.isArray(project.location) ? project.location.join(', ') : project.location}
                            </span>
                          </div>
                        </div>
                        <div className={`match-badge ${project.matchScore >= 80 ? 'high' : project.matchScore >= 50 ? 'medium' : 'low'}`}>
                          <Target size={14} />
                          {project.matchScore}% Match
                        </div>
                      </div>

                      <div className="project-details">
                        <div className="reason">{project.reason}</div>
                        <div className="openings-info">
                          <span>
                            <Users size={14} />
                            Openings: {project.openings - project.filled} remaining
                          </span>
                          <span>
                            <Calendar size={14} />
                            Expires: {project.expiryDate}
                          </span>
                        </div>
                      </div>

                      <div className="project-actions">
                        {isMapped ? (
                          <div className="status-indicator success">
                            <CheckCircle size={16} />
                            Mapped to Project
                          </div>
                        ) : (
                          <button 
                            className="btn-primary" 
                            onClick={() => handleMapToProject(project.id)}
                            disabled={!isAvailable}
                          >
                            <CheckCircle size={16} />
                            {isAvailable ? 'Map to Project' : 'No Openings'}
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {matchingProjects.length === 0 && (
                <div className="no-matches">
                  <AlertCircle size={48} style={{ color: 'var(--text-light)', marginBottom: '16px' }} />
                  <p style={{ color: 'var(--text-light)', marginBottom: '16px' }}>No matching projects found. Consider training in required skills.</p>
                </div>
              )}
            </div>
          </div>

          <div className="modal-footer">
            <div>
              <span style={{ fontSize: '14px', color: 'var(--text-light)' }}>
                Last updated: {new Date().toLocaleDateString()}
              </span>
            </div>
            <div className="footer-actions">
              <button className="btn-outline" onClick={() => setSelectedTrainee(null)}>
                <X size={16} />
                Close
              </button>
              <button className="btn-primary" onClick={() => {
                alert('AI recommendations generated successfully!');
              }}>
                <Sparkles size={16} />
                Generate AI Matches
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderJobModal = () => {
    if (!selectedJob || isEditMode) return null;

    return (
      <div className="modal-overlay" onClick={() => setSelectedJob(null)}>
        <div className="modal-content" onClick={e => e.stopPropagation()}>
          <div className="modal-header">
            <div className="modal-title">
              <Briefcase size={24} />
              <h2>{selectedJob.title}</h2>
            </div>
            <button className="modal-close" onClick={() => setSelectedJob(null)}>
              <X size={24} />
            </button>
          </div>
          
          <div className="modal-body">
            <div className="job-details-grid">
              <div className="detail-item">
                <Building size={16} />
                <div>
                  <span className="detail-label">Department</span>
                  <span className="detail-value">{selectedJob.department}</span>
                </div>
              </div>
              <div className="detail-item">
                <MapPin size={16} />
                <div>
                  <span className="detail-label">Location</span>
                  <span className="detail-value">{Array.isArray(selectedJob.location) ? selectedJob.location.join(', ') : selectedJob.location}</span>
                </div>
              </div>
              <div className="detail-item">
                <BriefcaseBusiness size={16} />
                <div>
                  <span className="detail-label">Openings</span>
                  <span className="detail-value">{selectedJob.openings} ({selectedJob.filled} filled)</span>
                </div>
              </div>
              <div className="detail-item">
                <Dollar size={16} />
                <div>
                  <span className="detail-label">Salary</span>
                  <span className="detail-value">{selectedJob.salary}</span>
                </div>
              </div>
              <div className="detail-item">
                <div className={`status-badge status-${selectedJob.status}`}>
                  {selectedJob.status === 'active' ? 'Active' : 'Inactive'}
                </div>
              </div>
              <div className="detail-item">
                <CalendarDays size={16} />
                <div>
                  <span className="detail-label">Posted</span>
                  <span className="detail-value">{selectedJob.postedDate}</span>
                </div>
              </div>
              <div className="detail-item">
                <Calendar size={16} />
                <div>
                  <span className="detail-label">Expires</span>
                  <span className="detail-value">{selectedJob.expiryDate}</span>
                </div>
              </div>
            </div>

            <div className="job-section">
              <h3>Job Description</h3>
              <p>{selectedJob.description}</p>
            </div>

            <div className="job-section">
              <h3>Requirements</h3>
              <p>{selectedJob.requirements}</p>
            </div>

            <div className="job-section">
              <h3>Technical Skills</h3>
              <div className="skills-list">
                {selectedJob.techSkills.map(skill => (
                  <span key={skill} className="skill-tag" style={{ background: '#dbeafe', color: '#1e40af' }}>
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            <div className="job-section">
              <h3>Soft Skills</h3>
              <div className="skills-list">
                {selectedJob.softSkills.map(skill => (
                  <span key={skill} className="skill-tag" style={{ background: '#dcfce7', color: '#166534' }}>
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            <div className="modal-actions">
              <button className="btn-secondary" onClick={() => setSelectedJob(null)}>
                Close
              </button>
              <button className="btn-primary" onClick={() => {
                setIsEditMode(true);
                setActiveTab('createJob');
                setTechSkills(selectedJob.techSkills || []);
                setSoftSkills(selectedJob.softSkills || []);
              }}>
                <Edit size={18} />
                Edit Job
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return renderDashboard();
      case 'jobs':
        return renderJobManagement();
      case 'createJob':
        return renderCreateJob();
      case 'trainees':
      case 'mapped':
      case 'unmapped':
        return renderTraineesList();
      default:
        return renderDashboard();
    }
  };

  const sidebarItems = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={20} /> },
    { id: 'jobs', label: 'Job Management', icon: <Briefcase size={20} /> },
    { id: 'trainees', label: 'Trainees List', icon: <Users size={20} /> },
  ];

  return (
    <div className="dashboard">
      <style>{`
        :root {
          --primary: #3b82f6;
          --primary-light: #eff6ff;
          --secondary: #6b7280;
          --success: #10b981;
          --warning: #f59e0b;
          --danger: #ef4444;
          --background: #f9fafb;
          --card: #ffffff;
          --border: #e5e7eb;
          --text: #111827;
          --text-light: #6b7280;
        }

        /* Add status button styles */
        .status-button.status-active {
          background: #d1fae5;
          color: #065f46;
        }
        
        .status-button.status-inactive {
          background: #fee2e2;
          color: #991b1b;
        }
        
        .status-button:hover {
          opacity: 0.9;
          transform: scale(1.05);
        }
        
        .upload-buttons .btn-secondary {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 8px 16px;
        }
        
        .upload-buttons .btn-secondary:hover {
          background: #f3f4f6;
        }
        
        .skills-input .form-control {
          margin-bottom: 8px;
        }
        
        .skills-tags {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
          margin-top: 8px;
        }
        
        .skill-tag {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          padding: 4px 12px;
          border-radius: 9999px;
          font-size: 12px;
          font-weight: 500;
        }
        
        .tag-remove {
          background: none;
          border: none;
          padding: 0;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          color: inherit;
          opacity: 0.7;
        }
        
        .tag-remove:hover {
          opacity: 1;
        }

        /* All your existing CSS remains here */
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }

        body {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
          color: var(--text);
          background: var(--background);
        }

        /* Modal Overlay */
        .modal-overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(15, 23, 42, 0.8);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
          padding: 20px;
          backdrop-filter: blur(4px);
        }

        .modal-content {
          background: white;
          border-radius: 16px;
          width: 100%;
          max-width: 1000px;
          max-height: 90vh;
          overflow-y: auto;
          box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
          position: relative;
        }

        /* Header */
        .modal-header {
          padding: 24px 32px;
          border-bottom: 1px solid #e5e7eb;
          display: flex;
          justify-content: space-between;
          align-items: center;
          background: #f8fafc;
          border-radius: 16px 16px 0 0;
        }

        .modal-title {
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .modal-title h2 {
          font-size: 24px;
          font-weight: 600;
          color: #1e293b;
          margin: 0;
        }

        .modal-close {
          width: 40px;
          height: 40px;
          border-radius: 10px;
          border: none;
          background: #f1f5f9;
          color: #64748b;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s;
        }

        .modal-close:hover {
          background: #e2e8f0;
          color: #475569;
        }

        /* Body */
        .modal-body {
          padding: 32px;
        }

        /* Profile Header */
        .profile-header {
          display: flex;
          gap: 24px;
          align-items: center;
          margin-bottom: 32px;
          padding-bottom: 32px;
          border-bottom: 2px solid #f1f5f9;
        }

        .profile-avatar {
          width: 80px;
          height: 80px;
          background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
          border-radius: 16px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 32px;
          font-weight: 600;
          color: white;
          flex-shrink: 0;
        }

        .profile-info {
          flex: 1;
        }

        .profile-info h3 {
          font-size: 28px;
          font-weight: 700;
          color: #1e293b;
          margin: 0 0 4px 0;
        }

        .profile-role {
          display: inline-block;
          background: #e0e7ff;
          color: #4338ca;
          padding: 4px 12px;
          border-radius: 20px;
          font-size: 12px;
          font-weight: 600;
          margin-bottom: 12px;
        }

        .profile-meta {
          display: flex;
          gap: 24px;
          flex-wrap: wrap;
        }

        .profile-meta-item {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 14px;
          color: #64748b;
        }

        .profile-actions {
          display: flex;
          gap: 8px;
        }

        /* Info Grid */
        .info-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 24px;
          margin-bottom: 32px;
        }

        .info-card {
          background: #f8fafc;
          border: 1px solid #e2e8f0;
          border-radius: 12px;
          padding: 20px;
        }

        .info-card h4 {
          font-size: 16px;
          font-weight: 600;
          color: #334155;
          margin: 0 0 16px 0;
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .info-content {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .info-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .info-label {
          font-size: 14px;
          color: #64748b;
        }

        .info-value {
          font-size: 14px;
          font-weight: 500;
          color: #1e293b;
        }

        /* Projects Section */
        .projects-section {
          margin-bottom: 32px;
        }

        .section-title {
          font-size: 18px;
          font-weight: 600;
          color: #1e293b;
          margin: 0 0 16px 0;
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .projects-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 20px;
        }

        .projects-grid {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .project-card {
          background: #f8fafc;
          border: 1px solid #e2e8f0;
          border-radius: 12px;
          padding: 20px;
          position: relative;
        }

        .project-card.mapped {
          border-left: 4px solid #10b981;
        }

        .project-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          margin-bottom: 16px;
        }

        .project-title h4 {
          font-size: 16px;
          font-weight: 600;
          color: #1e293b;
          margin: 0 0 8px 0;
        }

        .project-meta {
          display: flex;
          gap: 16px;
          font-size: 13px;
          color: #64748b;
        }

        .project-meta span {
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .match-badge {
          padding: 6px 12px;
          background: #f1f5f9;
          border-radius: 20px;
          font-size: 13px;
          font-weight: 500;
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .match-badge.high {
          background: #dcfce7;
          color: #166534;
        }

        .match-badge.medium {
          background: #fef3c7;
          color: #92400e;
        }

        .match-badge.low {
          background: #fee2e2;
          color: #991b1b;
        }

        .project-details {
          background: #f1f5f9;
          padding: 12px;
          border-radius: 8px;
          margin-bottom: 16px;
        }

        .reason {
          font-size: 13px;
          color: #475569;
          line-height: 1.5;
          margin-bottom: 12px;
        }

        .openings-info {
          display: flex;
          gap: 16px;
          font-size: 13px;
          color: #64748b;
        }

        .openings-info span {
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .project-actions {
          display: flex;
          gap: 8px;
          justify-content: flex-end;
        }

        .btn {
          padding: 8px 16px;
          border-radius: 8px;
          border: 1px solid #d1d5db;
          font-size: 13px;
          font-weight: 500;
          cursor: pointer;
          display: flex;
          align-items: center;
          gap: 6px;
          transition: all 0.2s;
          background: white;
        }

        .btn:hover {
          transform: translateY(-1px);
        }

        .btn-secondary {
          background: white;
          color: #374151;
          border-color: #d1d5db;
        }

        .btn-secondary:hover {
          background: #f9fafb;
          border-color: #9ca3af;
        }

        .btn-primary {
          background: #3b82f6;
          color: white;
          border-color: #3b82f6;
        }

        .btn-primary:hover {
          background: #2563eb;
          border-color: #2563eb;
        }

        .status-indicator {
          padding: 8px 16px;
          border-radius: 8px;
          font-size: 13px;
          font-weight: 500;
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .status-indicator.success {
          background: #dcfce7;
          color: #166534;
          border: 1px solid #bbf7d0;
        }

        /* Modal Footer */
        .modal-footer {
          padding: 24px 32px;
          border-top: 1px solid #e5e7eb;
          display: flex;
          justify-content: space-between;
          align-items: center;
          background: #f8fafc;
          border-radius: 0 0 16px 16px;
        }

        .footer-actions {
          display: flex;
          gap: 12px;
        }

        .btn-outline {
          padding: 8px 16px;
          border: 1px solid #d1d5db;
          border-radius: 8px;
          background: white;
          color: #374151;
          font-size: 14px;
          font-weight: 500;
          cursor: pointer;
          display: flex;
          align-items: center;
          gap: 6px;
          transition: all 0.2s;
        }

        .btn-outline:hover {
          background: #f9fafb;
          border-color: #9ca3af;
        }

        /* Rest of your existing CSS... */
        .dashboard {
          display: flex;
          min-height: 100vh;
        }

        .main-content {
          flex: 1;
          padding: 2rem;
          overflow-y: auto;
          background: var(--background);
        }

        .dashboard-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 2rem;
          padding-bottom: 1.5rem;
          border-bottom: 1px solid var(--border);
        }

        .header-title h1 {
          font-size: 1.875rem;
          font-weight: 700;
          color: var(--text);
          margin-bottom: 0.5rem;
          display: flex;
          align-items: center;
          gap: 0.75rem;
        }

        .header-subtitle {
          color: var(--text-light);
          font-size: 0.875rem;
        }

        .header-actions {
          display: flex;
          gap: 1rem;
          align-items: center;
        }

        /* Stats Grid */
        .stats-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 1.5rem;
          margin-bottom: 2rem;
        }

        .stat-card {
          background: var(--card);
          padding: 1.5rem;
          border-radius: 1rem;
          border: 1px solid var(--border);
          display: flex;
          align-items: center;
          gap: 1.25rem;
          transition: all 0.3s ease;
        }

        .stat-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1);
        }

        .stat-icon {
          width: 3.5rem;
          height: 3.5rem;
          border-radius: 0.75rem;
          background: var(--primary-light);
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .stat-icon-svg {
          width: 1.75rem;
          height: 1.75rem;
          color: var(--primary);
        }

        .stat-content {
          flex: 1;
        }

        .stat-content h3 {
          font-size: 0.875rem;
          color: var(--text-light);
          margin-bottom: 0.5rem;
          font-weight: 500;
        }

        .stat-value {
          font-size: 2rem;
          font-weight: 700;
          color: var(--text);
          margin-bottom: 0.25rem;
          line-height: 1;
        }

        /* Content Grid */
        .content-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
          gap: 1.5rem;
          margin-bottom: 1.5rem;
        }

        .content-card {
          background: var(--card);
          padding: 1.5rem;
          border-radius: 1rem;
          border: 1px solid var(--border);
        }

        .card-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 1.5rem;
        }

        .card-header h3 {
          display: flex;
          align-items: center;
          gap: 0.75rem;
          font-size: 1.125rem;
          font-weight: 600;
          color: var(--text);
        }

        .btn-text {
          display: flex;
          align-items: center;
          gap: 0.375rem;
          background: none;
          border: none;
          color: var(--primary);
          font-size: 0.875rem;
          font-weight: 500;
          cursor: pointer;
          padding: 0.5rem;
          border-radius: 0.375rem;
        }

        .btn-text:hover {
          background: var(--primary-light);
        }

        /* Tables */
        .table-container {
          overflow-x: auto;
          border-radius: 0.75rem;
          border: 1px solid var(--border);
        }

        .data-table {
          width: 100%;
          border-collapse: collapse;
          font-size: 0.875rem;
        }

        .data-table th {
          text-align: left;
          padding: 1rem;
          background: var(--primary-light);
          color: var(--text-light);
          font-weight: 600;
          font-size: 0.75rem;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          border-bottom: 1px solid var(--border);
        }

        .data-table td {
          padding: 1rem;
          border-bottom: 1px solid var(--border);
          color: var(--text);
        }

        .data-table tr:last-child td {
          border-bottom: none;
        }

        .data-table tr:hover {
          background: var(--primary-light);
        }

        /* Cell Styles */
        .user-cell {
          display: flex;
          align-items: center;
          gap: 0.75rem;
        }

        .user-avatar-sm {
          width: 2rem;
          height: 2rem;
          border-radius: 50%;
          background: var(--primary);
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 600;
          font-size: 0.875rem;
        }

        .location-cell, .department-cell {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          color: var(--text-light);
        }

        /* Score Badges */
        .score-badge {
          padding: 0.25rem 0.75rem;
          border-radius: 9999px;
          font-size: 0.75rem;
          font-weight: 600;
          display: inline-flex;
          align-items: center;
          gap: 0.25rem;
        }

        .score-high {
          background: #d1fae5;
          color: #065f46;
        }

        .score-medium {
          background: #fef3c7;
          color: #92400e;
        }

        .score-low {
          background: #fee2e2;
          color: #991b1b;
        }

        /* Status Badges */
        .status-badge {
          padding: 0.375rem 0.75rem;
          border-radius: 9999px;
          font-size: 0.75rem;
          font-weight: 600;
          display: inline-flex;
          align-items: center;
          gap: 0.375rem;
        }

        .status-approved {
          background: #d1fae5;
          color: #065f46;
        }

        .status-pending {
          background: #fef3c7;
          color: #92400e;
        }

        .status-active {
          background: #dbeafe;
          color: #1e40af;
        }

        .status-inactive {
          background: #e5e7eb;
          color: #6b7280;
        }

        .status-ready {
          background: #d1fae5;
          color: #065f46;
        }

        .status-training {
          background: #fef3c7;
          color: #92400e;
        }

        /* Action Buttons */
        .action-buttons {
          display: flex;
          gap: 0.5rem;
        }

        .btn-icon {
          width: 2rem;
          height: 2rem;
          border-radius: 0.5rem;
          border: 1px solid var(--border);
          background: var(--card);
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          color: var(--text-light);
          transition: all 0.2s ease;
        }

        .btn-icon:hover {
          background: var(--primary-light);
          color: var(--primary);
          border-color: var(--primary);
        }

        .btn-icon-view:hover {
          background: #dbeafe;
          color: #1e40af;
          border-color: #1e40af;
        }

        .btn-icon-edit:hover {
          background: #fef3c7;
          color: #92400e;
          border-color: #92400e;
        }

        .btn-icon-delete:hover {
          background: #fee2e2;
          color: #991b1b;
          border-color: #991b1b;
        }

        /* Skills */
        .skills-list {
          display: flex;
          flex-direction: column;
          gap: 1rem;
        }

        .skill-item {
          display: flex;
          flex-direction: column;
          gap: 0.5rem;
        }

        .skill-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .skill-name {
          font-size: 0.875rem;
          font-weight: 500;
          color: var(--text);
        }

        .skill-stats {
          display: flex;
          gap: 1rem;
          font-size: 0.75rem;
          color: var(--text-light);
        }

        .skill-bar {
          height: 0.5rem;
          background: var(--border);
          border-radius: 0.25rem;
          overflow: hidden;
        }

        .skill-fill {
          height: 100%;
          background: linear-gradient(90deg, var(--primary), #8b5cf6);
          border-radius: 0.25rem;
        }

        /* Section Header */
        .section-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 2rem;
        }

        .section-header h2 {
          display: flex;
          align-items: center;
          gap: 0.75rem;
          font-size: 1.5rem;
          font-weight: 700;
          color: var(--text);
        }

        .subtitle {
          color: var(--text-light);
          font-size: 0.875rem;
          margin-top: 0.25rem;
        }

        /* Buttons */
        .btn-primary {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          background: var(--primary);
          color: white;
          padding: 0.75rem 1.5rem;
          border: none;
          border-radius: 0.75rem;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .btn-primary:hover {
          background: #2563eb;
          transform: translateY(-1px);
          box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }

        .btn-secondary {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          background: var(--card);
          color: var(--text);
          padding: 0.75rem 1.5rem;
          border: 1px solid var(--border);
          border-radius: 0.75rem;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .btn-secondary:hover {
          background: var(--primary-light);
          border-color: var(--primary);
        }

        /* Trainees */
        .search-filter {
          display: flex;
          gap: 1rem;
          margin-bottom: 2rem;
        }

        .search-box {
          flex: 1;
          position: relative;
        }

        .search-box svg {
          position: absolute;
          left: 1rem;
          top: 50%;
          transform: translateY(-50%);
          color: var(--text-light);
        }

        .search-input {
          width: 100%;
          padding: 0.75rem 1rem 0.75rem 3rem;
          border: 1px solid var(--border);
          border-radius: 0.75rem;
          font-size: 0.875rem;
          background: var(--card);
        }

        .search-input:focus {
          outline: none;
          border-color: var(--primary);
          box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        .filter-group {
          display: flex;
          gap: 0.5rem;
          align-items: center;
        }

        .btn-filter {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          padding: 0.75rem 1rem;
          background: var(--card);
          border: 1px solid var(--border);
          border-radius: 0.75rem;
          color: var(--text);
          font-size: 0.875rem;
          cursor: pointer;
        }

        .filter-select {
          padding: 0.75rem;
          border: 1px solid var(--border);
          border-radius: 0.75rem;
          background: var(--card);
          color: var(--text);
          font-size: 0.875rem;
          min-width: 120px;
        }

        /* View Options */
        .view-options {
          display: flex;
          gap: 0.5rem;
          background: var(--card);
          padding: 0.25rem;
          border-radius: 0.75rem;
          border: 1px solid var(--border);
        }

        .btn-view-option {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          padding: 0.5rem 1rem;
          background: none;
          border: none;
          border-radius: 0.5rem;
          color: var(--text-light);
          font-size: 0.875rem;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .btn-view-option.active {
          background: var(--primary);
          color: white;
        }

        /* Trainee Cards */
        .trainees-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
          gap: 1.5rem;
        }

        .trainee-card {
          background: var(--card);
          padding: 1.5rem;
          border-radius: 1rem;
          border: 1px solid var(--border);
          transition: all 0.3s ease;
        }

        .trainee-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1);
        }

        .trainee-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          margin-bottom: 1.5rem;
        }

        .trainee-info-main {
          display: flex;
          gap: 1rem;
          align-items: center;
        }

        .trainee-avatar {
          width: 3rem;
          height: 3rem;
          border-radius: 50%;
          background: linear-gradient(135deg, var(--primary), #8b5cf6);
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 600;
          font-size: 1rem;
        }

        .trainee-info h4 {
          font-size: 1rem;
          font-weight: 600;
          color: var(--text);
          margin-bottom: 0.25rem;
        }

        .trainee-meta {
          display: flex;
          flex-direction: column;
          gap: 0.25rem;
          font-size: 0.75rem;
          color: var(--text-light);
        }

        .trainee-email, .trainee-location {
          display: flex;
          align-items: center;
          gap: 0.375rem;
        }

        .mapping-indicator {
          padding: 0.375rem 0.75rem;
          border-radius: 9999px;
          font-size: 0.75rem;
          font-weight: 600;
          display: flex;
          align-items: center;
          gap: 0.375rem;
        }

        .mapping-indicator.mapped {
          background: #d1fae5;
          color: #065f46;
        }

        .mapping-indicator.unmapped {
          background: #fee2e2;
          color: #991b1b;
        }

        .trainee-skills {
          display: flex;
          flex-wrap: wrap;
          gap: 0.5rem;
          margin-bottom: 1.5rem;
        }

        .skill-tag {
          padding: 0.375rem 0.75rem;
          background: var(--primary-light);
          border-radius: 9999px;
          font-size: 0.75rem;
          color: var(--primary);
          font-weight: 500;
        }

        .skill-tag-more {
          padding: 0.375rem 0.75rem;
          background: var(--border);
          border-radius: 9999px;
          font-size: 0.75rem;
          color: var(--text-light);
        }

        .trainee-stats {
          margin-bottom: 1.5rem;
        }

        .trainee-stat {
          margin-bottom: 1rem;
        }

        .stat-label {
          display: block;
          font-size: 0.75rem;
          color: var(--text-light);
          margin-bottom: 0.5rem;
          font-weight: 500;
        }

        .score-progress {
          display: flex;
          align-items: center;
          gap: 1rem;
        }

        .progress-bar {
          flex: 1;
          height: 0.5rem;
          background: var(--border);
          border-radius: 0.25rem;
          overflow: hidden;
        }

        .progress-fill {
          height: 100%;
          background: linear-gradient(90deg, var(--primary), #8b5cf6);
          border-radius: 0.25rem;
        }

        .score-value {
          font-size: 0.875rem;
          font-weight: 600;
          color: var(--text);
          min-width: 2.5rem;
          text-align: right;
        }

        .matched-jobs-count {
          display: flex;
          align-items: center;
          gap: 1rem;
        }

        .match-count {
          font-size: 1.25rem;
          font-weight: 700;
          color: var(--text);
        }

        .best-match {
          display: flex;
          align-items: center;
          gap: 0.25rem;
          font-size: 0.75rem;
          color: var(--success);
          font-weight: 600;
        }

        .trainee-actions {
          display: flex;
          gap: 0.75rem;
        }

        .btn-action {
          flex: 1;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 0.5rem;
          padding: 0.75rem;
          border: 1px solid var(--border);
          border-radius: 0.75rem;
          background: var(--card);
          color: var(--text);
          font-size: 0.875rem;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .btn-action:hover {
          background: var(--primary-light);
          color: var(--primary);
          border-color: var(--primary);
        }

        .btn-profile:hover {
          background: #e0e7ff;
          color: #3730a3;
          border-color: #3730a3;
        }

        .btn-find-matches:hover {
          background: #dbeafe;
          color: #1e40af;
          border-color: #1e40af;
        }

        .btn-view-matches:hover {
          background: #a7f3d0;
          color: #065f46;
          border-color: #065f46;
        }

        /* Form Styles */
        .form-card {
          background: var(--card);
          padding: 2rem;
          border-radius: 1rem;
          border: 1px solid var(--border);
        }

        .form-section {
          margin-bottom: 2rem;
          padding-bottom: 2rem;
          border-bottom: 1px solid var(--border);
        }

        .form-section:last-child {
          margin-bottom: 0;
          padding-bottom: 0;
          border-bottom: none;
        }

        .form-section-title {
          display: flex;
          align-items: center;
          gap: 0.75rem;
          font-size: 1.125rem;
          font-weight: 600;
          color: var(--text);
          margin-bottom: 1.5rem;
        }

        .form-row {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 1.5rem;
          margin-bottom: 1.5rem;
        }

        .form-group {
          margin-bottom: 1.5rem;
        }

        .form-group label {
          display: flex;
          align-items: center;
          gap: 0.375rem;
          margin-bottom: 0.5rem;
          font-weight: 500;
          color: var(--text);
          font-size: 0.875rem;
        }

        .required {
          color: var(--danger);
        }

        .form-control {
          width: 100%;
          padding: 0.75rem 1rem;
          border: 1px solid var(--border);
          border-radius: 0.75rem;
          font-size: 0.875rem;
          background: var(--card);
          transition: all 0.2s ease;
        }

        .form-control:focus {
          outline: none;
          border-color: var(--primary);
          box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        .form-actions {
          display: flex;
          gap: 1rem;
          justify-content: flex-end;
          margin-top: 2rem;
          padding-top: 2rem;
          border-top: 1px solid var(--border);
        }

        /* Job Details */
        .job-details-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 1.5rem;
          margin-bottom: 2rem;
        }

        .detail-item {
          display: flex;
          align-items: center;
          gap: 0.75rem;
        }

        .detail-label {
          display: block;
          font-size: 0.75rem;
          color: var(--text-light);
          margin-bottom: 0.25rem;
        }

        .detail-value {
          font-size: 0.875rem;
          color: var(--text);
          font-weight: 500;
        }

        .job-section {
          margin-bottom: 2rem;
        }

        .job-section h3 {
          font-size: 1.125rem;
          font-weight: 600;
          color: var(--text);
          margin-bottom: 1rem;
        }

        .job-section p {
          color: var(--text-light);
          line-height: 1.6;
          margin-bottom: 1rem;
        }

        .job-stats {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
          gap: 2rem;
        }

        .job-stat {
          display: flex;
          flex-direction: column;
          gap: 0.5rem;
        }

        .job-stat .stat-label {
          font-size: 0.875rem;
          color: var(--text-light);
        }

        .job-stat .stat-value {
          font-size: 2rem;
          font-weight: 700;
          color: var(--text);
        }

        .modal-actions {
          display: flex;
          gap: 1rem;
          justify-content: flex-end;
          padding-top: 1.5rem;
          border-top: 1px solid var(--border);
        }

        /* Responsive */
        @media (max-width: 768px) {
          .main-content {
            padding: 1rem;
          }

          .stats-grid {
            grid-template-columns: 1fr;
          }

          .section-header {
            flex-direction: column;
            gap: 1rem;
            align-items: stretch;
          }

          .search-filter {
            flex-direction: column;
          }

          .trainees-grid {
            grid-template-columns: 1fr;
          }

          .trainee-actions {
            flex-direction: column;
          }

          .modal-content {
            width: 95%;
          }

          .header-actions {
            flex-direction: column;
            align-items: stretch;
          }

          .info-grid {
            grid-template-columns: 1fr;
          }
        }

        @media (max-width: 640px) {
          .content-grid {
            grid-template-columns: 1fr;
          }

          .action-buttons {
            flex-wrap: wrap;
          }

          .btn-action {
            min-height: 3rem;
          }

          .form-actions {
            flex-direction: column;
          }

          .modal-actions {
            flex-direction: column;
          }
        }
      `}</style>

      <Sidebar 
        items={sidebarItems}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        userData={userData}
        onLogout={onLogout}
      />
      
      <div className="main-content">
        <div className="dashboard-header">
          <div className="header-title">
            <h1>
              <LayoutDashboard size={28} />
              HR Dashboard
            </h1>
            <div className="header-subtitle">
              Welcome back, {userData?.name || 'HR Manager'} | Talent Management & Job Allocation
            </div>
          </div>
          <div className="header-actions">
            {/* <button className="btn-primary" onClick={() => {
              alert('Report generation started. Check reports section.');
            }}>
              <Download size={18} />
              Generate Report
            </button> */}
          </div>
        </div>
        
        {renderContent()}
      </div>
      
      {renderHiddenFileInputs()}
      {renderExcelTemplateModal()}
      {renderWordTemplateModal()}
      {renderJobModal()}
      {renderTraineeModal()}
    </div>
  );
}

export default DashboardHR;