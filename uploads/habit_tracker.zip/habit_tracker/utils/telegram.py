import requests
from config import TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID

BASE_URL = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}"


# ✅ Send message with buttons
def send_reminder(task_id, task_name):

    text = f"🧴 {task_name}\n\nDue Today before 9 PM"

    keyboard = {
        "inline_keyboard": [
            [
                {"text": "✅ Completed", "callback_data": f"done:{task_id}"},
                {"text": "⏰ Remind 2hrs", "callback_data": f"later:{task_id}"}
            ]
        ]
    }

    requests.post(f"{BASE_URL}/sendMessage", json={
        "chat_id": TELEGRAM_CHAT_ID,
        "text": text,
        "reply_markup": keyboard
    })