from flask import Flask, request
from datetime import datetime, timedelta
from bson import ObjectId
import threading
import time

from db import db
from scheduler import check_and_send   # ✅ Import scheduler


def create_app():
    app = Flask(__name__)

    # ✅ Register Blueprints
    from routes.interval_routes import interval_bp
    from routes.note_routes import note_bp
    from routes.dashboard_routes import dashboard_bp

    app.register_blueprint(interval_bp)
    app.register_blueprint(note_bp)
    app.register_blueprint(dashboard_bp)

    # ✅ TELEGRAM WEBHOOK
    @app.route('/telegram/webhook', methods=['POST'])
    def telegram_webhook():
        data = request.json

        query = data.get("callback_query")

        if not query:
            return "ok"

        action = query.get("data")

        if not action:
            return "ok"

        parts = action.split(":")
        if len(parts) < 2:
            return "ok"

        task_id = parts[1]

        # ✅ COMPLETED
        if action.startswith("done"):
            task = db.intervals.find_one({"_id": ObjectId(task_id)})

            if task:
                days = task.get("interval_days", 0)

                db.intervals.update_one(
                    {"_id": ObjectId(task_id)},
                    {
                        "$set": {
                            "last_done": datetime.now(),
                            "next_due": datetime.now() + timedelta(days=days)
                        }
                    }
                )

        # ✅ REMIND AFTER 2 HOURS
        elif action.startswith("later"):
            db.intervals.update_one(
                {"_id": ObjectId(task_id)},
                {
                    "$set": {
                        "next_due": datetime.now() + timedelta(hours=2)
                    }
                }
            )

        return "ok"

    return app


# ✅ BACKGROUND SCHEDULER THREAD
def start_scheduler():
    while True:
        try:
            check_and_send()
        except Exception as e:
            print("Scheduler error:", e)

        time.sleep(3600)  # run every 1 hour


# ✅ RUN APP
if __name__ == '__main__':
    app = create_app()

    # ✅ Start background job
    t = threading.Thread(target=start_scheduler, daemon=True)
    t.start()

    app.run(debug=True)
