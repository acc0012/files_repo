from flask import Blueprint, render_template
from datetime import datetime
from db import db

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/')
def dashboard():
    now = datetime.now()
    today = now.date()

    # ✅ Get latest intervals first
    intervals = list(db.intervals.find().sort('_id', -1))

    processed_intervals = []

    for i in intervals:
        next_due = i.get('next_due')
        last_done = i.get('last_done')

        if not next_due:
            continue

        # ✅ Deadline = 9 PM on due day (safe)
        due_datetime = next_due.replace(
            hour=21, minute=0, second=0, microsecond=0
        )

        # ✅ Remaining time
        remaining = due_datetime - now

        # ✅ Status logic
        if remaining.total_seconds() < 0:
            status = "Overdue"
        elif next_due.date() == today:
            status = "Due Today"
        else:
            status = "Upcoming"

        processed_intervals.append({
            "id": str(i["_id"]),
            "name": i.get("name"),
            "interval_days": i.get("interval_days"),
            "last_done": last_done,
            "next_due": next_due,
            "remaining": str(remaining).split('.')[0],
            "status": status
        })

    # ✅ Show only top 5 intervals
    processed_intervals = processed_intervals[:5]

    # ✅ Show only latest 5 notes
    notes = list(
        db.notes.find().sort('_id', -1).limit(5)
    )

    return render_template(
        'dashboard.html',
        intervals=processed_intervals,
        notes=notes
    )