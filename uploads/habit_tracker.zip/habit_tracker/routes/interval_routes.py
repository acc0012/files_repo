from flask import Blueprint, render_template, request, redirect
from datetime import datetime, timedelta
from db import db
from bson import ObjectId

interval_bp = Blueprint('interval', __name__)


# ✅ LIST WITH PAGINATION (25 per page)
@interval_bp.route('/intervals')
def list_intervals():
    page = int(request.args.get('page', 1))
    per_page = 25

    total = db.intervals.count_documents({})

    intervals = list(
        db.intervals.find()
        .sort('_id', -1)
        .skip((page - 1) * per_page)
        .limit(per_page)
    )

    return render_template(
        'interval/list.html',
        intervals=intervals,
        page=page,
        per_page=per_page,
        total=total
    )


# ✅ ADD
@interval_bp.route('/intervals/add', methods=['GET', 'POST'])
def add_interval():
    if request.method == 'POST':
        name = request.form.get('name')
        days = int(request.form.get('days', 0))

        last_done = datetime.now()
        next_due = last_done + timedelta(days=days)

        db.intervals.insert_one({
            "name": name,
            "interval_days": days,
            "last_done": last_done,
            "next_due": next_due
        })

        return redirect('/intervals')

    return render_template('interval/add.html')


# ✅ MARK DONE (FIXED ROUTE)
@interval_bp.route('/intervals/mark_done/<id>')
def mark_done(id):
    task = db.intervals.find_one({"_id": ObjectId(id)})

    if not task:
        return redirect('/intervals')

    next_due = datetime.now() + timedelta(days=task.get('interval_days', 0))

    db.intervals.update_one(
        {"_id": ObjectId(id)},
        {"$set": {
            "last_done": datetime.now(),
            "next_due": next_due
        }}
    )

    return redirect('/intervals')


# ✅ EDIT
@interval_bp.route('/intervals/edit/<id>', methods=['GET', 'POST'])
def edit_interval(id):
    task = db.intervals.find_one({"_id": ObjectId(id)})

    if not task:
        return redirect('/intervals')

    if request.method == 'POST':
        name = request.form.get('name')
        days = int(request.form.get('days', 0))

        last_done = task.get('last_done', datetime.now())
        next_due = last_done + timedelta(days=days)

        db.intervals.update_one(
            {"_id": ObjectId(id)},
            {
                "$set": {
                    "name": name,
                    "interval_days": days,
                    "next_due": next_due
                }
            }
        )

        return redirect('/intervals')

    return render_template('interval/edit.html', task=task)


# ✅ DELETE
@interval_bp.route('/intervals/delete/<id>')
def delete_interval(id):
    db.intervals.delete_one({"_id": ObjectId(id)})
    return redirect('/intervals')