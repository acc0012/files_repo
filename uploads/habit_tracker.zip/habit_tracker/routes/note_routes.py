from flask import Blueprint, render_template, request, redirect
from db import db
from collections import defaultdict
from bson import ObjectId

note_bp = Blueprint('notes', __name__)


# ✅ NOTES DASHBOARD (WITH PAGINATION - 25 CARDS)
@note_bp.route('/notes')
def list_notes():
    page = int(request.args.get('page', 1))
    per_page = 25

    raw_notes = list(db.notes.find())

    grouped = defaultdict(list)

    # ✅ Group notes by type + title
    for n in raw_notes:
        note_type = n.get('type') or 'General'
        title = n.get('title') or 'General'
        key = f"{note_type}||{title}"
        grouped[key].append(n)

    summary = []

    for key, items in grouped.items():
        items = sorted(items, key=lambda x: x["_id"], reverse=True)
        latest = items[0]

        note_type, title = key.split("||")

        summary.append({
            "type": note_type,
            "title": title,
            "last_note": latest.get("notes", ""),
            "last_date": latest.get("end_date") or latest.get("start_date"),
            "count": len(items),
            "id": f"{note_type}|{title}"
        })

    # ✅ SORT safely
    summary = sorted(
        summary,
        key=lambda x: x["last_date"] or "",
        reverse=True
    )

    total = len(summary)

    # ✅ PAGINATION (25 cards)
    summary = summary[(page - 1) * per_page: page * per_page]

    return render_template(
        'notes/list.html',
        summaries=summary,
        page=page,
        total=total,
        per_page=per_page
    )


# ✅ VIEW NOTE (WITH PAGINATION - 10 ENTRIES)
@note_bp.route('/notes/view/<key>')
def view_note(key):
    page = int(request.args.get('page', 1))
    per_page = 10

    note_type, title = key.split("|")

    total = db.notes.count_documents({
        "type": note_type,
        "title": title
    })

    notes = list(
        db.notes.find({
            "type": note_type,
            "title": title
        })
        .sort('_id', -1)
        .skip((page - 1) * per_page)
        .limit(per_page)
    )

    return render_template(
        'notes/view.html',
        notes=notes,
        type=note_type,
        title=title,
        page=page,
        total=total,
        per_page=per_page
    )


# ✅ ADD NOTE (WITH DROPDOWN SUPPORT)
@note_bp.route('/notes/add', methods=['GET', 'POST'])
def add_note():

    existing = list(db.notes.find({}, {"type": 1, "title": 1}))
    options = list(set([
        f"{x.get('type')}||{x.get('title')}"
        for x in existing
        if x.get('type') and x.get('title')
    ]))

    if request.method == 'POST':

        selected = request.form.get("existing")

        if selected and selected != "other":
            note_type, title = selected.split("||")
        else:
            note_type = request.form.get("type") or "General"
            title = request.form.get("title") or "General"

        data = {
            "title": title,
            "type": note_type,
            "start_date": request.form.get("start_date"),
            "end_date": request.form.get("end_date"),
            "notes": request.form.get("notes")
        }

        db.notes.insert_one(data)
        return redirect('/notes')

    return render_template('notes/add.html', options=options)


# ✅ EDIT NOTE
@note_bp.route('/notes/edit/<id>', methods=['GET', 'POST'])
def edit_note(id):
    note = db.notes.find_one({"_id": ObjectId(id)})

    if not note:
        return redirect('/notes')

    if request.method == 'POST':
        db.notes.update_one(
            {"_id": ObjectId(id)},
            {
                "$set": {
                    "notes": request.form.get('notes'),
                    "end_date": request.form.get('end_date')
                }
            }
        )
        return redirect('/notes')

    return render_template('notes/edit.html', note=note)


# ✅ DELETE SINGLE NOTE ENTRY (optional, good feature)
@note_bp.route('/notes/delete/<id>')
def delete_note(id):
    db.notes.delete_one({"_id": ObjectId(id)})
    return redirect('/notes')


# ✅ DELETE ENTIRE GROUP (CARD DELETE)
@note_bp.route('/notes/delete_group/<key>')
def delete_group(key):
    note_type, title = key.split("|")

    db.notes.delete_many({
        "type": note_type,
        "title": title
    })

    return redirect('/notes')
