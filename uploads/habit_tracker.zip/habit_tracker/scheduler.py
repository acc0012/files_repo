from datetime import datetime
from db import db
from utils.telegram import send_reminder

def check_and_send():
    now = datetime.now()

    tasks = db.intervals.find()

    for t in tasks:
        next_due = t.get('next_due')

        if not next_due:
            continue

        # ✅ If due today
        if next_due.date() == now.date():

            # ✅ If before 9 PM
            if now.hour >= 18 and now.hour < 21:
                send_reminder(str(t["_id"]), t["name"])
