cls


python app.py