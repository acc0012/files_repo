import json
from datetime import datetime
from pathlib import Path

from core import config
from services.token_service import token_service
from services.option_service import (
    get_options_contracts,
    options_cache,
    get_options_cache_summary,
)

# ============================================================
# Backtest One-Time Option Instrument Fetch
# ============================================================
# Run this from project root:
#
#   python fetch_backtest_options_once.py
#
# This script:
#   1. Loads Upstox token from MongoDB.
#   2. Fetches nearest/current week NIFTY option instruments.
#   3. Filters strikes from 23500 to 25000.
#   4. Saves instruments to data/backtest/current_week_options_23500_25000.json
#
# This does NOT start FastAPI.
# This does NOT start WebSocket.
# This does NOT start Telegram bot.
# This does NOT run scheduler.
# ============================================================

BACKTEST_STRIKE_FROM = 23500.0
BACKTEST_STRIKE_TO = 25000.0

OUTPUT_FILE = Path("data/backtest/current_week_options_23500_25000.json")


def main():
    print("============================================================")
    print("BACKTEST OPTION INSTRUMENT FETCH STARTED")
    print("============================================================")

    # --------------------------------------------------------
    # 1. Override strike range only for this standalone run
    # --------------------------------------------------------
    config.STRIKE_FROM = BACKTEST_STRIKE_FROM
    config.STRIKE_TO = BACKTEST_STRIKE_TO

    print(f"Backtest strike range: {config.STRIKE_FROM} to {config.STRIKE_TO}")

    # --------------------------------------------------------
    # 2. Refresh token from MongoDB into token_service memory
    # --------------------------------------------------------
    print("Refreshing Upstox token from MongoDB...")

    token_loaded = token_service.refresh_tokens()

    if not token_loaded:
        raise RuntimeError(
            "No usable Upstox access token found in MongoDB. "
            "Please save/refresh token first."
        )

    access_token = token_service.get_access_token()

    if not access_token:
        raise RuntimeError("Token loaded but access_token is empty.")

    print("Token loaded successfully.")

    # --------------------------------------------------------
    # 3. Fetch nearest/current week NIFTY option contracts
    # --------------------------------------------------------
    print("Fetching nearest/current week NIFTY option instruments...")

    result = get_options_contracts(
        instrument_key=getattr(config, "MAIN_NIFTY_SECURITY", "NSE_INDEX|Nifty 50"),
        expiry_date=None,
        filter_nearest=True,
        save_data=False,
    )

    if not result:
        raise RuntimeError("Option contract fetch failed or returned no result.")

    option_instruments = result.get("data", []) or []
    option_keys = [
        item.get("instrument_key")
        for item in option_instruments
        if item.get("instrument_key")
    ]

    subscribed_keys = options_cache.get("subscribed_keys", [])

    # --------------------------------------------------------
    # 4. Build backtest output payload
    # --------------------------------------------------------
    output_payload = {
        "status": "success",
        "purpose": "backtest_current_week_option_instruments",
        "generated_at": datetime.now().isoformat(),
        "main_index_key": getattr(config, "MAIN_NIFTY_SECURITY", "NSE_INDEX|Nifty 50"),
        "strike_from": BACKTEST_STRIKE_FROM,
        "strike_to": BACKTEST_STRIKE_TO,
        "nearest_expiry": result.get("nearest_expiry"),
        "total_contracts": result.get("total_contracts", 0),
        "option_instrument_keys_count": len(option_keys),
        "option_instrument_keys": option_keys,
        "all_subscribed_keys_count": len(subscribed_keys),
        "all_subscribed_keys": subscribed_keys,
        "cache_summary": get_options_cache_summary(),
        "data": option_instruments,
    }

    # --------------------------------------------------------
    # 5. Save output file
    # --------------------------------------------------------
    OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)

    with open(OUTPUT_FILE, "w", encoding="utf-8") as file:
        json.dump(output_payload, file, indent=4, ensure_ascii=False, default=str)

    print("============================================================")
    print("BACKTEST OPTION INSTRUMENT FETCH COMPLETED")
    print("============================================================")
    print(f"Nearest Expiry       : {output_payload.get('nearest_expiry')}")
    print(f"Total Contracts      : {output_payload.get('total_contracts')}")
    print(f"Option Keys Count    : {len(option_keys)}")
    print(f"All Subscribe Count  : {len(subscribed_keys)}")
    print(f"Output File          : {OUTPUT_FILE.resolve()}")
    print("============================================================")


if __name__ == "__main__":
    main()