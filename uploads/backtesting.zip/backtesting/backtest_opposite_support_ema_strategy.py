import csv
import json
from datetime import datetime
from pathlib import Path
from statistics import mean


# ============================================================
# Opposite Support EMA Strategy Backtest
# ============================================================
#
# Strategy:
#
# 1. Use NIFTY Opening Range average to build eligible strike window:
#       NIFTY_OR_AVG - 500 to NIFTY_OR_AVG + 500
#
# 2. For every option instrument inside that window:
#       calculate option Opening Range levels.
#
# 3. Resistance trigger:
#       If CE or PE instrument touches/crosses R2/R3.
#
# 4. Opposite support candidate:
#       If resistance side is PE, watch CE instruments.
#       If resistance side is CE, watch PE instruments.
#
# 5. Candidate must touch S2/S3.
#
# 6. Entry allowed only when candidate candle close <= S2.
#
# 7. Entry confirmation:
#       bullish EMA 9/21 crossover.
#
# 8. Entry price:
#       EMA bullish cross candle close.
#
# 9. Targets:
#       Target 1 = candidate Opening Range average
#       Target 2 = candidate R2
#       Target 3 = candidate R3
#
# Run:
#       python backtest_opposite_support_ema_strategy.py
#
# ============================================================


# ============================================================
# Config
# ============================================================

HISTORICAL_ROOT = Path("data/backtest/historical_candles")
NIFTY_FILE = HISTORICAL_ROOT / "nifty_index_30_non_empty_market_days.json"
OPTION_CANDLES_DIR = HISTORICAL_ROOT / "option_candles"

OUTPUT_ROOT = Path("data/backtest/strategy_results")
TRADE_REPORT_CSV = OUTPUT_ROOT / "trade_report.csv"
DAILY_REPORT_CSV = OUTPUT_ROOT / "daily_report.csv"
SUMMARY_JSON = OUTPUT_ROOT / "backtest_summary.json"
TRADE_REPORT_JSON = OUTPUT_ROOT / "trade_report.json"
DAILY_REPORT_JSON = OUTPUT_ROOT / "daily_report.json"

OPENING_RANGE_CANDLE_COUNT = 1

AVERAGE_WINDOW_POINTS = 500.0
STRIKE_FROM = 23500.0
STRIKE_TO = 25000.0

EMA_FAST_PERIOD = 9
EMA_SLOW_PERIOD = 21

RESISTANCE_TRIGGER_LEVELS = ["R2", "R3"]
SUPPORT_CANDIDATE_LEVELS = ["S2", "S3"]
SUPPORT_PRIORITY_LEVELS = ["S3", "S2"]

ENTRY_CROSS_TYPE = "bullish_cross"

# Entry only when candidate candle close is <= S2.
ALERT_ONLY_WHEN_PRICE_BELOW_OR_EQUAL_S2 = True

# If True, one trade per option instrument per day.
ONE_TRADE_PER_INSTRUMENT_PER_DAY = True

# If True, one trade per day total after first valid entry.
ONE_TRADE_PER_DAY = False


# ============================================================
# Basic Helpers
# ============================================================

def load_json(path: Path):
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")

    with open(path, "r", encoding="utf-8") as file:
        return json.load(file)


def save_json(path: Path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)

    with open(path, "w", encoding="utf-8") as file:
        json.dump(payload, file, indent=4, ensure_ascii=False, default=str)


def safe_float(value, default=0.0):
    try:
        if value is None:
            return default
        return float(value)
    except Exception:
        return default


def safe_int(value, default=0):
    try:
        if value is None:
            return default
        return int(value)
    except Exception:
        return default


def safe_str(value, default=""):
    if value is None:
        return default
    return str(value)


def normalize_option_type(value):
    text = str(value or "").strip().upper()

    if text in ["CE", "CALL"]:
        return "CE"

    if text in ["PE", "PUT"]:
        return "PE"

    return None


def opposite_option_type(value):
    option_type = normalize_option_type(value)

    if option_type == "CE":
        return "PE"

    if option_type == "PE":
        return "CE"

    return None


def candle_timestamp(candle):
    try:
        return str(candle[0])
    except Exception:
        return ""


def candle_open(candle):
    return safe_float(candle[1])


def candle_high(candle):
    return safe_float(candle[2])


def candle_low(candle):
    return safe_float(candle[3])


def candle_close(candle):
    return safe_float(candle[4])


def candle_volume(candle):
    try:
        return safe_int(candle[5])
    except Exception:
        return 0


def sort_candles(candles):
    try:
        return sorted(candles, key=lambda item: str(item[0]))
    except Exception:
        return candles or []


def deduplicate_candles(candles):
    seen = set()
    output = []

    for candle in candles or []:
        key = candle_timestamp(candle)

        if key and key not in seen:
            seen.add(key)
            output.append(candle)

    return output


def prepare_candles(candles):
    return sort_candles(deduplicate_candles(candles or []))


def get_date_from_timestamp(timestamp):
    return str(timestamp or "")[:10]


def is_strike_inside_filter_range(strike):
    strike_value = safe_float(strike)
    return STRIKE_FROM <= strike_value <= STRIKE_TO


def is_strike_inside_window(strike, lower, upper):
    strike_value = safe_float(strike)
    return safe_float(lower) <= strike_value <= safe_float(upper)


def build_average_window(average):
    average = safe_float(average)

    raw_lower = average - AVERAGE_WINDOW_POINTS
    raw_upper = average + AVERAGE_WINDOW_POINTS

    final_lower = max(STRIKE_FROM, raw_lower)
    final_upper = min(STRIKE_TO, raw_upper)

    return {
        "average": average,
        "window_points": AVERAGE_WINDOW_POINTS,
        "configured_from": STRIKE_FROM,
        "configured_to": STRIKE_TO,
        "raw_lower": raw_lower,
        "raw_upper": raw_upper,
        "final_lower": final_lower,
        "final_upper": final_upper,
    }


# ============================================================
# Opening Range Calculation
# ============================================================

def calculate_opening_range(candles, candle_count=OPENING_RANGE_CANDLE_COUNT):
    candles = prepare_candles(candles)

    if not candles:
        return {
            "status": "empty",
            "message": "No candles available.",
        }

    selected = candles[:candle_count]

    if len(selected) < candle_count:
        return {
            "status": "insufficient_data",
            "message": "Not enough candles for Opening Range.",
            "candles_count": len(candles),
            "selected_candles_count": len(selected),
        }

    range_open = candle_open(selected[0])
    range_high = max(candle_high(candle) for candle in selected)
    range_low = min(candle_low(candle) for candle in selected)
    range_close = candle_close(selected[-1])
    range_average = (range_high + range_low) / 2

    high_avg_diff = abs(range_high - range_average)
    low_avg_diff = abs(range_average - range_low)

    r1 = range_average + (high_avg_diff / 2)
    s1 = range_average - (low_avg_diff / 2)

    r2 = range_high + high_avg_diff
    s2 = range_low - low_avg_diff

    r3 = r2 + high_avg_diff
    s3 = s2 - low_avg_diff

    return {
        "status": "success",
        "candles_count": len(candles),
        "selected_candles_count": len(selected),
        "range": {
            "open": round(range_open, 4),
            "high": round(range_high, 4),
            "low": round(range_low, 4),
            "close": round(range_close, 4),
            "average": round(range_average, 4),
            "first_candle_time": candle_timestamp(selected[0]),
            "last_candle_time": candle_timestamp(selected[-1]),
        },
        "levels": {
            "r1": round(r1, 4),
            "s1": round(s1, 4),
            "r2": round(r2, 4),
            "s2": round(s2, 4),
            "r3": round(r3, 4),
            "s3": round(s3, 4),
            "sub_resistance": round(r1, 4),
            "sub_support": round(s1, 4),
            "resistance2": round(r2, 4),
            "support2": round(s2, 4),
            "resistance3": round(r3, 4),
            "support3": round(s3, 4),
            "r3_threshold": round((r2 + r3) / 2, 4),
            "s3_threshold": round((s2 + s3) / 2, 4),
        },
        "selected_candles": selected,
    }


# ============================================================
# Touch Detection
# ============================================================

def detect_resistance_touches(
    date_text,
    instrument,
    candles,
    opening_range,
):
    touches = []

    levels = opening_range.get("levels", {})

    r2 = safe_float(levels.get("r2"))
    r3 = safe_float(levels.get("r3"))

    for candle in candles:
        ts = candle_timestamp(candle)
        high = candle_high(candle)

        if high >= r3:
            touches.append(
                {
                    "type": "resistance_touch",
                    "date": date_text,
                    "instrument_key": instrument.get("instrument_key"),
                    "trading_symbol": instrument.get("trading_symbol"),
                    "instrument_type": instrument.get("instrument_type"),
                    "strike_price": instrument.get("strike_price"),
                    "level": "R3",
                    "level_value": r3,
                    "trigger_field": "high",
                    "trigger_price": high,
                    "touch_time": ts,
                    "priority": 1,
                }
            )
            continue

        if high >= r2:
            touches.append(
                {
                    "type": "resistance_touch",
                    "date": date_text,
                    "instrument_key": instrument.get("instrument_key"),
                    "trading_symbol": instrument.get("trading_symbol"),
                    "instrument_type": instrument.get("instrument_type"),
                    "strike_price": instrument.get("strike_price"),
                    "level": "R2",
                    "level_value": r2,
                    "trigger_field": "high",
                    "trigger_price": high,
                    "touch_time": ts,
                    "priority": 2,
                }
            )

    return touches


def detect_support_touches(
    date_text,
    instrument,
    candles,
    opening_range,
):
    touches = []

    levels = opening_range.get("levels", {})

    s2 = safe_float(levels.get("s2"))
    s3 = safe_float(levels.get("s3"))

    for candle in candles:
        ts = candle_timestamp(candle)
        low = candle_low(candle)

        if low <= s3:
            touches.append(
                {
                    "type": "support_touch",
                    "date": date_text,
                    "instrument_key": instrument.get("instrument_key"),
                    "trading_symbol": instrument.get("trading_symbol"),
                    "instrument_type": instrument.get("instrument_type"),
                    "strike_price": instrument.get("strike_price"),
                    "level": "S3",
                    "level_value": s3,
                    "trigger_field": "low",
                    "trigger_price": low,
                    "touch_time": ts,
                    "priority": 1,
                }
            )
            continue

        if low <= s2:
            touches.append(
                {
                    "type": "support_touch",
                    "date": date_text,
                    "instrument_key": instrument.get("instrument_key"),
                    "trading_symbol": instrument.get("trading_symbol"),
                    "instrument_type": instrument.get("instrument_type"),
                    "strike_price": instrument.get("strike_price"),
                    "level": "S2",
                    "level_value": s2,
                    "trigger_field": "low",
                    "trigger_price": low,
                    "touch_time": ts,
                    "priority": 2,
                }
            )

    return touches


def first_touch_per_instrument_level(touches):
    """
    Keeps first touch per instrument + level.
    """

    output = {}
    sorted_touches = sorted(touches, key=lambda item: item.get("touch_time") or "")

    for touch in sorted_touches:
        key = f"{touch.get('instrument_key')}_{touch.get('level')}"

        if key not in output:
            output[key] = touch

    return list(output.values())


# ============================================================
# EMA Calculation
# ============================================================

def calculate_ema(values, period):
    if not values or period <= 0:
        return []

    multiplier = 2 / (period + 1)
    output = []

    previous_ema = None

    for value in values:
        price = safe_float(value)

        if previous_ema is None:
            previous_ema = price
        else:
            previous_ema = (price * multiplier) + (previous_ema * (1 - multiplier))

        output.append(round(previous_ema, 4))

    return output


def calculate_ema_cross_events(candles):
    candles = prepare_candles(candles)

    if len(candles) < max(EMA_FAST_PERIOD, EMA_SLOW_PERIOD):
        return []

    closes = [candle_close(candle) for candle in candles]

    ema_fast = calculate_ema(closes, EMA_FAST_PERIOD)
    ema_slow = calculate_ema(closes, EMA_SLOW_PERIOD)

    events = []

    for idx in range(1, len(candles)):
        previous_fast = ema_fast[idx - 1]
        previous_slow = ema_slow[idx - 1]
        current_fast = ema_fast[idx]
        current_slow = ema_slow[idx]

        cross_type = None

        if previous_fast <= previous_slow and current_fast > current_slow:
            cross_type = "bullish_cross"

        elif previous_fast >= previous_slow and current_fast < current_slow:
            cross_type = "bearish_cross"

        if cross_type:
            candle = candles[idx]

            events.append(
                {
                    "timestamp": candle_timestamp(candle),
                    "timestamp_index": idx,
                    "cross_type": cross_type,
                    "close": candle_close(candle),
                    "candle_open": candle_open(candle),
                    "candle_high": candle_high(candle),
                    "candle_low": candle_low(candle),
                    "ema_fast": current_fast,
                    "ema_slow": current_slow,
                    "previous_ema_fast": previous_fast,
                    "previous_ema_slow": previous_slow,
                    "ema_fast_period": EMA_FAST_PERIOD,
                    "ema_slow_period": EMA_SLOW_PERIOD,
                }
            )

    return events


# ============================================================
# Target Simulation
# ============================================================

def find_target_hit_after_entry(candles, entry_index, target_value):
    target = safe_float(target_value)

    for idx in range(entry_index + 1, len(candles)):
        candle = candles[idx]

        if candle_high(candle) >= target:
            return {
                "hit": True,
                "hit_time": candle_timestamp(candle),
                "hit_price": target,
                "hit_candle_high": candle_high(candle),
                "bars_after_entry": idx - entry_index,
            }

    return {
        "hit": False,
        "hit_time": None,
        "hit_price": target,
        "hit_candle_high": None,
        "bars_after_entry": None,
    }


def calculate_mfe_mae(candles, entry_index, entry_price):
    future_candles = candles[entry_index + 1:]

    if not future_candles:
        return {
            "max_favorable_move": 0.0,
            "max_adverse_move": 0.0,
            "max_high_after_entry": None,
            "min_low_after_entry": None,
        }

    max_high = max(candle_high(candle) for candle in future_candles)
    min_low = min(candle_low(candle) for candle in future_candles)

    entry = safe_float(entry_price)

    return {
        "max_favorable_move": round(max_high - entry, 4),
        "max_adverse_move": round(entry - min_low, 4),
        "max_high_after_entry": round(max_high, 4),
        "min_low_after_entry": round(min_low, 4),
    }


# ============================================================
# Data Loading
# ============================================================

def load_nifty_data():
    payload = load_json(NIFTY_FILE)

    return {
        "valid_market_days": payload.get("valid_market_days", []),
        "candles_by_day": payload.get("candles_by_day", {}),
        "raw": payload,
    }


def load_option_instruments():
    instruments = []

    if not OPTION_CANDLES_DIR.exists():
        raise FileNotFoundError(f"Option candles folder not found: {OPTION_CANDLES_DIR}")

    files = sorted(OPTION_CANDLES_DIR.glob("*.json"))

    for file_path in files:
        payload = load_json(file_path)
        contract_info = payload.get("contract_info", {})

        instrument = {
            "instrument_key": payload.get("instrument_key"),
            "contract_info": contract_info,
            "trading_symbol": contract_info.get("trading_symbol"),
            "instrument_type": normalize_option_type(contract_info.get("instrument_type")),
            "strike_price": safe_float(contract_info.get("strike_price")),
            "expiry": contract_info.get("expiry"),
            "candles_by_day": payload.get("candles_by_day", {}),
            "source_file": str(file_path),
        }

        if instrument.get("instrument_key") and instrument.get("instrument_type"):
            instruments.append(instrument)

    return instruments


# ============================================================
# Daily Strategy Backtest
# ============================================================

def build_daily_context(date_text, nifty_candles, option_instruments):
    nifty_or = calculate_opening_range(nifty_candles)

    if nifty_or.get("status") != "success":
        return {
            "status": "skipped",
            "date": date_text,
            "reason": "nifty_opening_range_failed",
            "nifty_opening_range": nifty_or,
        }

    nifty_average = safe_float(nifty_or.get("range", {}).get("average"))
    average_window = build_average_window(nifty_average)

    eligible = []

    for instrument in option_instruments:
        strike = instrument.get("strike_price")
        option_type = instrument.get("instrument_type")

        if not is_strike_inside_filter_range(strike):
            continue

        if not is_strike_inside_window(
            strike,
            average_window.get("final_lower"),
            average_window.get("final_upper"),
        ):
            continue

        candles = prepare_candles(instrument.get("candles_by_day", {}).get(date_text, []))

        if not candles:
            continue

        option_or = calculate_opening_range(candles)

        if option_or.get("status") != "success":
            continue

        eligible.append(
            {
                "instrument": instrument,
                "instrument_key": instrument.get("instrument_key"),
                "instrument_type": option_type,
                "strike_price": strike,
                "trading_symbol": instrument.get("trading_symbol"),
                "candles": candles,
                "opening_range": option_or,
            }
        )

    return {
        "status": "success",
        "date": date_text,
        "nifty_opening_range": nifty_or,
        "nifty_average": nifty_average,
        "average_window": average_window,
        "eligible_instruments": eligible,
    }


def collect_daily_touches(date_text, eligible_instruments):
    resistance_touches = []
    support_touches = []

    for item in eligible_instruments:
        instrument = item["instrument"]
        candles = item["candles"]
        opening_range = item["opening_range"]

        resistance_touches.extend(
            detect_resistance_touches(
                date_text=date_text,
                instrument=instrument,
                candles=candles,
                opening_range=opening_range,
            )
        )

        support_touches.extend(
            detect_support_touches(
                date_text=date_text,
                instrument=instrument,
                candles=candles,
                opening_range=opening_range,
            )
        )

    resistance_touches = first_touch_per_instrument_level(resistance_touches)
    support_touches = first_touch_per_instrument_level(support_touches)

    return resistance_touches, support_touches


def support_touch_before_or_at_entry(support_touch, entry_time):
    touch_time = support_touch.get("touch_time")
    return bool(touch_time and entry_time and touch_time <= entry_time)


def resistance_touch_before_or_at_entry(resistance_touch, entry_time):
    touch_time = resistance_touch.get("touch_time")
    return bool(touch_time and entry_time and touch_time <= entry_time)


def select_best_reference_resistance(
    resistance_touches,
    candidate_type,
    entry_time,
):
    """
    Candidate type is support-side option type.
    Resistance trigger must be opposite type.
    """

    expected_resistance_type = opposite_option_type(candidate_type)

    valid = [
        item
        for item in resistance_touches
        if normalize_option_type(item.get("instrument_type")) == expected_resistance_type
        and resistance_touch_before_or_at_entry(item, entry_time)
    ]

    if not valid:
        return None

    # Priority:
    # R3 first, then R2.
    # Earlier touch first.
    # Nearest strike relation is not needed here because this is only reference trigger.
    valid = sorted(
        valid,
        key=lambda item: (
            item.get("priority", 99),
            item.get("touch_time") or "",
            abs(safe_float(item.get("strike_price"))),
        ),
    )

    return valid[0]


def select_support_touch_for_candidate(
    support_touches,
    candidate_key,
    entry_time,
):
    valid = [
        item
        for item in support_touches
        if item.get("instrument_key") == candidate_key
        and support_touch_before_or_at_entry(item, entry_time)
    ]

    if not valid:
        return None

    # Priority:
    # S3 first, then S2.
    valid = sorted(
        valid,
        key=lambda item: (
            item.get("priority", 99),
            item.get("touch_time") or "",
        ),
    )

    return valid[0]


def build_trade_from_ema_event(
    date_text,
    day_context,
    candidate_item,
    ema_event,
    resistance_touch,
    support_touch,
):
    instrument = candidate_item["instrument"]
    candles = candidate_item["candles"]
    opening_range = candidate_item["opening_range"]

    levels = opening_range.get("levels", {})
    option_range = opening_range.get("range", {})

    entry_index = ema_event.get("timestamp_index")
    entry_price = safe_float(ema_event.get("close"))
    entry_time = ema_event.get("timestamp")

    target_avg = safe_float(option_range.get("average"))
    target_r2 = safe_float(levels.get("r2"))
    target_r3 = safe_float(levels.get("r3"))

    avg_hit = find_target_hit_after_entry(candles, entry_index, target_avg)
    r2_hit = find_target_hit_after_entry(candles, entry_index, target_r2)
    r3_hit = find_target_hit_after_entry(candles, entry_index, target_r3)

    mfe_mae = calculate_mfe_mae(candles, entry_index, entry_price)

    if r3_hit.get("hit"):
        result_status = "target_r3_hit"
    elif r2_hit.get("hit"):
        result_status = "target_r2_hit"
    elif avg_hit.get("hit"):
        result_status = "target_average_hit"
    else:
        result_status = "no_target_hit"

    return {
        "date": date_text,
        "entry_time": entry_time,
        "instrument_key": instrument.get("instrument_key"),
        "trading_symbol": instrument.get("trading_symbol"),
        "strike_price": instrument.get("strike_price"),
        "option_type": instrument.get("instrument_type"),
        "entry_price": round(entry_price, 4),
        "entry_reason": "opposite_support_bullish_ema_cross",
        "ema_cross_type": ema_event.get("cross_type"),
        "ema_fast": ema_event.get("ema_fast"),
        "ema_slow": ema_event.get("ema_slow"),
        "previous_ema_fast": ema_event.get("previous_ema_fast"),
        "previous_ema_slow": ema_event.get("previous_ema_slow"),
        "support_level_touched": support_touch.get("level"),
        "support_level_value": support_touch.get("level_value"),
        "support_touch_time": support_touch.get("touch_time"),
        "support_trigger_price": support_touch.get("trigger_price"),
        "support_candidate_s2": levels.get("s2"),
        "support_candidate_s3": levels.get("s3"),
        "support_candidate_average": option_range.get("average"),
        "resistance_reference_instrument": resistance_touch.get("instrument_key"),
        "resistance_reference_symbol": resistance_touch.get("trading_symbol"),
        "resistance_reference_type": resistance_touch.get("instrument_type"),
        "resistance_reference_strike": resistance_touch.get("strike_price"),
        "resistance_reference_level": resistance_touch.get("level"),
        "resistance_reference_level_value": resistance_touch.get("level_value"),
        "resistance_touch_time": resistance_touch.get("touch_time"),
        "resistance_trigger_price": resistance_touch.get("trigger_price"),
        "nifty_or_average": day_context.get("nifty_average"),
        "nifty_window_lower": day_context.get("average_window", {}).get("final_lower"),
        "nifty_window_upper": day_context.get("average_window", {}).get("final_upper"),
        "target_average": round(target_avg, 4),
        "target_r2": round(target_r2, 4),
        "target_r3": round(target_r3, 4),
        "target_avg_hit": avg_hit.get("hit"),
        "target_avg_hit_time": avg_hit.get("hit_time"),
        "target_avg_bars": avg_hit.get("bars_after_entry"),
        "target_r2_hit": r2_hit.get("hit"),
        "target_r2_hit_time": r2_hit.get("hit_time"),
        "target_r2_bars": r2_hit.get("bars_after_entry"),
        "target_r3_hit": r3_hit.get("hit"),
        "target_r3_hit_time": r3_hit.get("hit_time"),
        "target_r3_bars": r3_hit.get("bars_after_entry"),
        "max_favorable_move": mfe_mae.get("max_favorable_move"),
        "max_adverse_move": mfe_mae.get("max_adverse_move"),
        "max_high_after_entry": mfe_mae.get("max_high_after_entry"),
        "min_low_after_entry": mfe_mae.get("min_low_after_entry"),
        "result_status": result_status,
    }


def run_backtest_for_day(date_text, nifty_candles, option_instruments):
    day_context = build_daily_context(date_text, nifty_candles, option_instruments)

    if day_context.get("status") != "success":
        return {
            "date": date_text,
            "status": "skipped",
            "reason": day_context.get("reason"),
            "trades": [],
            "daily_report": {
                "date": date_text,
                "status": "skipped",
                "reason": day_context.get("reason"),
            },
        }

    eligible = day_context.get("eligible_instruments", [])
    resistance_touches, support_touches = collect_daily_touches(date_text, eligible)

    trades = []
    traded_instruments = set()

    for candidate_item in eligible:
        instrument = candidate_item["instrument"]
        instrument_key = instrument.get("instrument_key")
        option_type = instrument.get("instrument_type")
        candles = candidate_item["candles"]
        levels = candidate_item["opening_range"].get("levels", {})

        if ONE_TRADE_PER_DAY and trades:
            break

        if ONE_TRADE_PER_INSTRUMENT_PER_DAY and instrument_key in traded_instruments:
            continue

        ema_events = calculate_ema_cross_events(candles)

        bullish_events = [
            event
            for event in ema_events
            if event.get("cross_type") == ENTRY_CROSS_TYPE
        ]

        for ema_event in bullish_events:
            entry_time = ema_event.get("timestamp")
            entry_close = safe_float(ema_event.get("close"))
            s2_value = safe_float(levels.get("s2"))

            if ALERT_ONLY_WHEN_PRICE_BELOW_OR_EQUAL_S2 and entry_close > s2_value:
                continue

            support_touch = select_support_touch_for_candidate(
                support_touches=support_touches,
                candidate_key=instrument_key,
                entry_time=entry_time,
            )

            if not support_touch:
                continue

            resistance_touch = select_best_reference_resistance(
                resistance_touches=resistance_touches,
                candidate_type=option_type,
                entry_time=entry_time,
            )

            if not resistance_touch:
                continue

            trade = build_trade_from_ema_event(
                date_text=date_text,
                day_context=day_context,
                candidate_item=candidate_item,
                ema_event=ema_event,
                resistance_touch=resistance_touch,
                support_touch=support_touch,
            )

            trades.append(trade)
            traded_instruments.add(instrument_key)

            if ONE_TRADE_PER_INSTRUMENT_PER_DAY:
                break

        if ONE_TRADE_PER_DAY and trades:
            break

    daily_report = {
        "date": date_text,
        "status": "success",
        "nifty_or_average": day_context.get("nifty_average"),
        "nifty_window_lower": day_context.get("average_window", {}).get("final_lower"),
        "nifty_window_upper": day_context.get("average_window", {}).get("final_upper"),
        "eligible_instruments_count": len(eligible),
        "resistance_touches_count": len(resistance_touches),
        "support_touches_count": len(support_touches),
        "ema_entries_count": len(trades),
        "avg_target_hits": sum(1 for trade in trades if trade.get("target_avg_hit")),
        "r2_target_hits": sum(1 for trade in trades if trade.get("target_r2_hit")),
        "r3_target_hits": sum(1 for trade in trades if trade.get("target_r3_hit")),
        "failed_entries": sum(1 for trade in trades if trade.get("result_status") == "no_target_hit"),
    }

    return {
        "date": date_text,
        "status": "success",
        "trades": trades,
        "daily_report": daily_report,
        "resistance_touches": resistance_touches,
        "support_touches": support_touches,
    }


# ============================================================
# Report Writers
# ============================================================

def write_csv(path: Path, rows: list):
    path.parent.mkdir(parents=True, exist_ok=True)

    if not rows:
        with open(path, "w", encoding="utf-8", newline="") as file:
            file.write("")
        return

    fieldnames = sorted({key for row in rows for key in row.keys()})

    with open(path, "w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()

        for row in rows:
            writer.writerow(row)


def build_summary(valid_days, trades, daily_reports):
    total_entries = len(trades)

    avg_hits = sum(1 for trade in trades if trade.get("target_avg_hit"))
    r2_hits = sum(1 for trade in trades if trade.get("target_r2_hit"))
    r3_hits = sum(1 for trade in trades if trade.get("target_r3_hit"))

    failed_entries = sum(1 for trade in trades if trade.get("result_status") == "no_target_hit")

    def hit_rate(count):
        if total_entries <= 0:
            return 0.0
        return round((count / total_entries) * 100, 2)

    def average_bars(field):
        values = [
            safe_float(trade.get(field))
            for trade in trades
            if trade.get(field) is not None
        ]
        return round(mean(values), 2) if values else None

    total_by_day = {
        report.get("date"): report.get("ema_entries_count", 0)
        for report in daily_reports
    }

    best_day = None
    worst_day = None

    if total_by_day:
        best_day = max(total_by_day.items(), key=lambda item: item[1])
        worst_day = min(total_by_day.items(), key=lambda item: item[1])

    return {
        "status": "success",
        "generated_at": datetime.now().isoformat(),
        "strategy_name": "Opposite Support EMA Alert Flow",
        "config": {
            "opening_range_candle_count": OPENING_RANGE_CANDLE_COUNT,
            "average_window_points": AVERAGE_WINDOW_POINTS,
            "strike_from": STRIKE_FROM,
            "strike_to": STRIKE_TO,
            "ema_fast_period": EMA_FAST_PERIOD,
            "ema_slow_period": EMA_SLOW_PERIOD,
            "resistance_trigger_levels": RESISTANCE_TRIGGER_LEVELS,
            "support_candidate_levels": SUPPORT_CANDIDATE_LEVELS,
            "entry_cross_type": ENTRY_CROSS_TYPE,
            "alert_only_when_price_below_or_equal_s2": ALERT_ONLY_WHEN_PRICE_BELOW_OR_EQUAL_S2,
            "one_trade_per_instrument_per_day": ONE_TRADE_PER_INSTRUMENT_PER_DAY,
            "one_trade_per_day": ONE_TRADE_PER_DAY,
        },
        "total_market_days": len(valid_days),
        "total_entries": total_entries,
        "avg_target_hit_count": avg_hits,
        "r2_target_hit_count": r2_hits,
        "r3_target_hit_count": r3_hits,
        "failed_entries": failed_entries,
        "avg_target_hit_rate_pct": hit_rate(avg_hits),
        "r2_target_hit_rate_pct": hit_rate(r2_hits),
        "r3_target_hit_rate_pct": hit_rate(r3_hits),
        "failed_entry_rate_pct": hit_rate(failed_entries),
        "average_bars_to_avg": average_bars("target_avg_bars"),
        "average_bars_to_r2": average_bars("target_r2_bars"),
        "average_bars_to_r3": average_bars("target_r3_bars"),
        "best_day_by_entries": {
            "date": best_day[0],
            "entries": best_day[1],
        }
        if best_day
        else None,
        "worst_day_by_entries": {
            "date": worst_day[0],
            "entries": worst_day[1],
        }
        if worst_day
        else None,
        "output_files": {
            "trade_report_csv": str(TRADE_REPORT_CSV),
            "daily_report_csv": str(DAILY_REPORT_CSV),
            "trade_report_json": str(TRADE_REPORT_JSON),
            "daily_report_json": str(DAILY_REPORT_JSON),
            "summary_json": str(SUMMARY_JSON),
        },
    }


# ============================================================
# Main
# ============================================================

def main():
    started_at = datetime.now().isoformat()

    print("============================================================")
    print("OPPOSITE SUPPORT EMA STRATEGY BACKTEST STARTED")
    print("============================================================")
    print(f"Started At       : {started_at}")
    print(f"NIFTY File       : {NIFTY_FILE}")
    print(f"Option Folder    : {OPTION_CANDLES_DIR}")
    print(f"Output Folder    : {OUTPUT_ROOT}")
    print("============================================================")

    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    nifty_data = load_nifty_data()
    valid_days = nifty_data.get("valid_market_days", [])
    nifty_candles_by_day = nifty_data.get("candles_by_day", {})

    option_instruments = load_option_instruments()

    print(f"Valid NIFTY Days        : {len(valid_days)}")
    print(f"Option Instruments      : {len(option_instruments)}")
    print("============================================================")

    all_trades = []
    daily_reports = []
    all_day_debug = []

    for idx, date_text in enumerate(valid_days, start=1):
        print(f"[DAY {idx}/{len(valid_days)}] Backtesting {date_text} ...")

        nifty_candles = prepare_candles(nifty_candles_by_day.get(date_text, []))

        result = run_backtest_for_day(
            date_text=date_text,
            nifty_candles=nifty_candles,
            option_instruments=option_instruments,
        )

        trades = result.get("trades", [])
        daily_report = result.get("daily_report", {})

        all_trades.extend(trades)
        daily_reports.append(daily_report)

        all_day_debug.append(
            {
                "date": date_text,
                "status": result.get("status"),
                "trades_count": len(trades),
                "daily_report": daily_report,
                "resistance_touches_count": len(result.get("resistance_touches", [])),
                "support_touches_count": len(result.get("support_touches", [])),
            }
        )

        print(
            f"  Entries={len(trades)} | "
            f"ResistanceTouches={daily_report.get('resistance_touches_count')} | "
            f"SupportTouches={daily_report.get('support_touches_count')} | "
            f"AVG Hits={daily_report.get('avg_target_hits')} | "
            f"R2 Hits={daily_report.get('r2_target_hits')} | "
            f"R3 Hits={daily_report.get('r3_target_hits')}"
        )

    summary = build_summary(
        valid_days=valid_days,
        trades=all_trades,
        daily_reports=daily_reports,
    )

    summary["started_at"] = started_at
    summary["completed_at"] = datetime.now().isoformat()
    summary["day_debug"] = all_day_debug

    save_json(TRADE_REPORT_JSON, all_trades)
    save_json(DAILY_REPORT_JSON, daily_reports)
    save_json(SUMMARY_JSON, summary)

    write_csv(TRADE_REPORT_CSV, all_trades)
    write_csv(DAILY_REPORT_CSV, daily_reports)

    print("============================================================")
    print("OPPOSITE SUPPORT EMA STRATEGY BACKTEST COMPLETED")
    print("============================================================")
    print(f"Total Market Days     : {summary.get('total_market_days')}")
    print(f"Total Entries         : {summary.get('total_entries')}")
    print(f"AVG Target Hits       : {summary.get('avg_target_hit_count')} ({summary.get('avg_target_hit_rate_pct')}%)")
    print(f"R2 Target Hits        : {summary.get('r2_target_hit_count')} ({summary.get('r2_target_hit_rate_pct')}%)")
    print(f"R3 Target Hits        : {summary.get('r3_target_hit_count')} ({summary.get('r3_target_hit_rate_pct')}%)")
    print(f"Failed Entries        : {summary.get('failed_entries')} ({summary.get('failed_entry_rate_pct')}%)")
    print(f"Trade CSV             : {TRADE_REPORT_CSV.resolve()}")
    print(f"Daily CSV             : {DAILY_REPORT_CSV.resolve()}")
    print(f"Summary JSON          : {SUMMARY_JSON.resolve()}")
    print("============================================================")


if __name__ == "__main__":
    main()