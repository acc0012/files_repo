import json
from datetime import datetime
from pathlib import Path


# ============================================================
# Paths
# ============================================================

DATA_ROOT = Path("data")

BACKTEST_ROOT = DATA_ROOT / "backtest"

OPTION_CANDLES_DIR = DATA_ROOT / "option_candles"

NIFTY_FILE = DATA_ROOT / "nifty_index_30_non_empty_market_days.json"

STRATEGY_RESULTS = BACKTEST_ROOT / "strategy_results"

TRADE_REPORT_JSON = STRATEGY_RESULTS / "trade_report.json"

DAILY_OR_LEVELS_OUTPUT_FILE = STRATEGY_RESULTS / "daily_or_levels_report.json"

NIFTY_DAILY_OR_LEVELS_OUTPUT_FILE = (
    STRATEGY_RESULTS / "nifty_daily_or_levels_report.json"
)


# ============================================================
# Helpers
# ============================================================

def load_json(path):
    with open(path, "r", encoding="utf-8") as file:
        return json.load(file)


def save_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)

    with open(path, "w", encoding="utf-8") as file:
        json.dump(
            payload,
            file,
            indent=4,
            ensure_ascii=False,
            default=str,
        )


def safe_float(value, default=0.0):
    try:
        return float(value)
    except Exception:
        return default


# ============================================================
# Opening Range
# ============================================================

def candle_high(candle):
    return safe_float(candle[2])


def candle_low(candle):
    return safe_float(candle[3])


def candle_open(candle):
    return safe_float(candle[1])


def candle_close(candle):
    return safe_float(candle[4])


def calculate_opening_range(candles):
    if not candles:
        return None

    first = candles[0]

    range_open = candle_open(first)
    range_high = candle_high(first)
    range_low = candle_low(first)
    range_close = candle_close(first)

    average = (range_high + range_low) / 2

    high_avg_diff = abs(range_high - average)
    low_avg_diff = abs(average - range_low)

    r1 = average + (high_avg_diff / 2)
    s1 = average - (low_avg_diff / 2)

    r2 = range_high + high_avg_diff
    s2 = range_low - low_avg_diff

    r3 = r2 + high_avg_diff
    s3 = s2 - low_avg_diff

    return {
        "open": round(range_open, 4),
        "high": round(range_high, 4),
        "low": round(range_low, 4),
        "close": round(range_close, 4),

        "average": round(average, 4),

        "r1": round(r1, 4),
        "s1": round(s1, 4),

        "r2": round(r2, 4),
        "s2": round(s2, 4),

        "r3": round(r3, 4),
        "s3": round(s3, 4),
    }


# ============================================================
# Data Load
# ============================================================

print("Loading trade report...")
trades = load_json(TRADE_REPORT_JSON)

print("Loading NIFTY candles...")
nifty_payload = load_json(NIFTY_FILE)

nifty_day_candles = nifty_payload.get(
    "candles_by_day",
    {},
)

print("Loading option candle files...")

option_files = {}

for file_path in OPTION_CANDLES_DIR.glob("*.json"):
    payload = load_json(file_path)

    instrument_key = payload.get("instrument_key")

    if instrument_key:
        option_files[instrument_key] = payload

print(
    f"Loaded option instruments: {len(option_files)}"
)


# ============================================================
# Generate Separate NIFTY Daily OR Levels Report
# ============================================================

nifty_daily_or_levels = []

for date_text in sorted(nifty_day_candles.keys()):

    nifty_candles = nifty_day_candles.get(
        date_text,
        [],
    )

    nifty_or = calculate_opening_range(
        nifty_candles
    )

    nifty_daily_or_levels.append(
        {
            "date": date_text,
            "opening_range": nifty_or,
        }
    )

nifty_daily_payload = {
    "generated_at": datetime.now().isoformat(),
    "days_count": len(nifty_daily_or_levels),
    "days": nifty_daily_or_levels,
}

save_json(
    NIFTY_DAILY_OR_LEVELS_OUTPUT_FILE,
    nifty_daily_payload,
)


# ============================================================
# Group Trades By Day
# ============================================================

trades_by_day = {}

for trade in trades:
    date_text = trade.get("date")

    trades_by_day.setdefault(
        date_text,
        []
    ).append(trade)


# ============================================================
# Build Daily Trade OR Levels Report
# ============================================================

daily_report = []

for date_text in sorted(trades_by_day.keys()):

    day_trades = trades_by_day[date_text]

    day_entry = {
        "date": date_text,
        "trade_count": len(day_trades),
        "generated_at": datetime.now().isoformat(),
        "nifty": None,
        "selected_trades": [],
    }

    # --------------------------------------------------------
    # NIFTY OR
    # --------------------------------------------------------

    nifty_candles = nifty_day_candles.get(
        date_text,
        [],
    )

    nifty_or = calculate_opening_range(
        nifty_candles
    )

    day_entry["nifty"] = nifty_or

    # --------------------------------------------------------
    # Trades
    # --------------------------------------------------------

    for trade in day_trades:

        support_key = trade.get(
            "instrument_key"
        )

        resistance_key = trade.get(
            "resistance_reference_instrument"
        )

        support_payload = option_files.get(
            support_key,
            {},
        )

        resistance_payload = option_files.get(
            resistance_key,
            {},
        )

        support_candles = (
            support_payload
            .get("candles_by_day", {})
            .get(date_text, [])
        )

        resistance_candles = (
            resistance_payload
            .get("candles_by_day", {})
            .get(date_text, [])
        )

        support_or = calculate_opening_range(
            support_candles
        )

        resistance_or = calculate_opening_range(
            resistance_candles
        )

        selected_trade = {
            "support_candidate": {
                "instrument_key": support_key,
                "trading_symbol": trade.get(
                    "trading_symbol"
                ),
                "strike_price": trade.get(
                    "strike_price"
                ),
                "option_type": trade.get(
                    "option_type"
                ),
                "support_level_touched": trade.get(
                    "support_level_touched"
                ),
                "support_level_value": trade.get(
                    "support_level_value"
                ),
                "support_touch_time": trade.get(
                    "support_touch_time"
                ),
                "opening_range": support_or,
            },

            "resistance_reference": {
                "instrument_key": resistance_key,
                "trading_symbol": trade.get(
                    "resistance_reference_symbol"
                ),
                "strike_price": trade.get(
                    "resistance_reference_strike"
                ),
                "option_type": trade.get(
                    "resistance_reference_type"
                ),
                "resistance_level": trade.get(
                    "resistance_reference_level"
                ),
                "resistance_level_value": trade.get(
                    "resistance_reference_level_value"
                ),
                "resistance_touch_time": trade.get(
                    "resistance_touch_time"
                ),
                "opening_range": resistance_or,
            },

            "entry": {
                "entry_time": trade.get(
                    "entry_time"
                ),
                "entry_price": trade.get(
                    "entry_price"
                ),
                "ema_fast": trade.get(
                    "ema_fast"
                ),
                "ema_slow": trade.get(
                    "ema_slow"
                ),
            },

            "targets": {
                "average": {
                    "price": trade.get(
                        "target_average"
                    ),
                    "hit": trade.get(
                        "target_avg_hit"
                    ),
                },

                "r2": {
                    "price": trade.get(
                        "target_r2"
                    ),
                    "hit": trade.get(
                        "target_r2_hit"
                    ),
                },

                "r3": {
                    "price": trade.get(
                        "target_r3"
                    ),
                    "hit": trade.get(
                        "target_r3_hit"
                    ),
                },
            },

            "result_status": trade.get(
                "result_status"
            ),
        }

        day_entry["selected_trades"].append(
            selected_trade
        )

    daily_report.append(
        day_entry
    )


# ============================================================
# Save Daily Trade OR Levels Report
# ============================================================

daily_payload = {
    "generated_at": datetime.now().isoformat(),
    "days_count": len(daily_report),
    "days": daily_report,
}

save_json(
    DAILY_OR_LEVELS_OUTPUT_FILE,
    daily_payload,
)


# ============================================================
# Summary
# ============================================================

print()
print("====================================================")
print("DAILY OR LEVEL REPORT GENERATED")
print("====================================================")
print(f"Trade Days Processed : {len(daily_report)}")
print(f"NIFTY Days Processed : {len(nifty_daily_or_levels)}")
print(f"Trade OR Output File : {DAILY_OR_LEVELS_OUTPUT_FILE.resolve()}")
print(f"NIFTY OR Output File : {NIFTY_DAILY_OR_LEVELS_OUTPUT_FILE.resolve()}")
print("====================================================")