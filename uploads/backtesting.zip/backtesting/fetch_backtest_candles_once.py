import json
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, date
from pathlib import Path
from threading import Lock

import upstox_client
from upstox_client.rest import ApiException


# ============================================================
# Backtest Historical Candle Fetch Configuration
# ============================================================

API_VERSION = "2.0"
INTERVAL = "1minute"

MAIN_INDEX_KEY = "NSE_INDEX|Nifty 50"

MARKET_DAYS_REQUIRED = 30

# Safety limit to search backward for 30 non-empty market days.
# Weekends/holidays/empty days will be skipped.
MAX_LOOKBACK_CALENDAR_DAYS = 80

# Upstox historical v2 1minute max request window.
MAX_DAYS_PER_REQUEST = 7

# Parallel thread count for option instruments.
MAX_WORKERS = 10

# Small delay inside each worker between batch requests.
REQUEST_SLEEP_SECONDS = 0.20

OPTION_FILE = Path("data/backtest/current_week_options_23500_25000.json")

OUTPUT_ROOT = Path("data/backtest/historical_candles")
NIFTY_OUTPUT_FILE = OUTPUT_ROOT / "nifty_index_30_non_empty_market_days.json"
OPTION_OUTPUT_DIR = OUTPUT_ROOT / "option_candles"
SUMMARY_OUTPUT_FILE = OUTPUT_ROOT / "historical_fetch_summary.json"


# ============================================================
# Thread-Safe Print
# ============================================================

_print_lock = Lock()


def safe_print(*args, **kwargs):
    with _print_lock:
        print(*args, **kwargs)


# ============================================================
# Helpers
# ============================================================

def safe_instrument_filename(instrument_key: str) -> str:
    return (
        str(instrument_key)
        .replace("|", "_")
        .replace(" ", "_")
        .replace("/", "_")
        .replace("\\", "_")
    )


def response_to_dict(api_response) -> dict:
    if api_response is None:
        return {}

    if hasattr(api_response, "to_dict"):
        try:
            return api_response.to_dict()
        except Exception:
            pass

    if isinstance(api_response, dict):
        return api_response

    try:
        return dict(api_response)
    except Exception:
        return {}


def extract_candles(api_response) -> list:
    response_dict = response_to_dict(api_response)
    data = response_dict.get("data", {})

    if isinstance(data, dict):
        candles = data.get("candles", [])
        return candles if isinstance(candles, list) else []

    return []


def save_json(path: Path, payload: dict):
    path.parent.mkdir(parents=True, exist_ok=True)

    with open(path, "w", encoding="utf-8") as file:
        json.dump(payload, file, indent=4, ensure_ascii=False, default=str)


def load_option_file() -> dict:
    if not OPTION_FILE.exists():
        raise FileNotFoundError(
            f"Option instrument file not found: {OPTION_FILE}. "
            "Run fetch_backtest_options_once.py first."
        )

    with open(OPTION_FILE, "r", encoding="utf-8") as file:
        return json.load(file)


def get_yesterday() -> date:
    return datetime.now().date() - timedelta(days=1)


def format_date(value: date) -> str:
    return value.strftime("%Y-%m-%d")


def parse_candle_date(candle) -> str | None:
    """
    Extracts YYYY-MM-DD from Upstox candle timestamp.

    Expected candle:
        [
            "2026-08-14T09:15:00+05:30",
            open,
            high,
            low,
            close,
            volume,
            oi
        ]
    """

    try:
        ts = str(candle[0])
        return ts[:10]
    except Exception:
        return None


def sort_candles(candles: list) -> list:
    try:
        return sorted(candles, key=lambda item: str(item[0]) if item else "")
    except Exception:
        return candles


def deduplicate_candles(candles: list) -> list:
    seen = set()
    unique = []

    for candle in candles:
        if isinstance(candle, list) and candle:
            key = candle[0]
        else:
            key = json.dumps(candle, default=str)

        if key not in seen:
            seen.add(key)
            unique.append(candle)

    return unique


def split_date_range_into_batches(
    from_date_obj: date,
    to_date_obj: date,
    max_days_per_request: int = MAX_DAYS_PER_REQUEST,
) -> list:
    """
    Splits date range into max 7 calendar day batches.

    Example:
        from 2026-07-01 to 2026-07-20
        returns:
            2026-07-01 to 2026-07-07
            2026-07-08 to 2026-07-14
            2026-07-15 to 2026-07-20
    """

    if from_date_obj > to_date_obj:
        return []

    batches = []
    current_from = from_date_obj

    while current_from <= to_date_obj:
        current_to = min(
            current_from + timedelta(days=max_days_per_request - 1),
            to_date_obj,
        )

        batches.append(
            {
                "from_date": format_date(current_from),
                "to_date": format_date(current_to),
            }
        )

        current_from = current_to + timedelta(days=1)

    return batches


def get_lookup_range_for_market_days() -> tuple[date, date]:
    """
    Returns broad calendar range to find 30 non-empty NIFTY market days.
    """

    to_date_obj = get_yesterday()
    from_date_obj = to_date_obj - timedelta(days=MAX_LOOKBACK_CALENDAR_DAYS - 1)

    return from_date_obj, to_date_obj


def get_range_from_valid_days(valid_market_days: list) -> tuple[date, date]:
    """
    Valid market days are stored latest to oldest.
    This returns proper oldest to latest range.
    """

    if not valid_market_days:
        raise ValueError("valid_market_days is empty.")

    date_objs = [
        datetime.strptime(day_text, "%Y-%m-%d").date()
        for day_text in valid_market_days
    ]

    return min(date_objs), max(date_objs)


# ============================================================
# Upstox Historical Fetch
# ============================================================

def fetch_candles_for_range(
    instrument_key: str,
    from_date_text: str,
    to_date_text: str,
) -> dict:
    """
    Fetches 1-minute candles for one instrument for one date range.

    Uses:
        HistoryApi().get_historical_candle_data1(
            instrument_key,
            interval,
            to_date,
            from_date,
            api_version
        )
    """

    api_instance = upstox_client.HistoryApi()

    try:
        api_response = api_instance.get_historical_candle_data1(
            instrument_key,
            INTERVAL,
            to_date_text,
            from_date_text,
            API_VERSION,
        )

        candles = extract_candles(api_response)

        return {
            "status": "success" if candles else "empty",
            "instrument_key": instrument_key,
            "from_date": from_date_text,
            "to_date": to_date_text,
            "candles_count": len(candles),
            "candles": candles,
            "error": None,
        }

    except ApiException as ex:
        error_body = getattr(ex, "body", str(ex))

        return {
            "status": "failed",
            "instrument_key": instrument_key,
            "from_date": from_date_text,
            "to_date": to_date_text,
            "candles_count": 0,
            "candles": [],
            "error": error_body,
        }

    except Exception as ex:
        return {
            "status": "failed",
            "instrument_key": instrument_key,
            "from_date": from_date_text,
            "to_date": to_date_text,
            "candles_count": 0,
            "candles": [],
            "error": f"{type(ex).__name__}: {ex}",
        }


def fetch_candles_for_batches(
    instrument_key: str,
    batches: list,
    valid_market_days_filter: set | None = None,
) -> dict:
    """
    Fetches candles for an instrument using max 7-day batches.

    If valid_market_days_filter is provided:
        candles are grouped and retained only for those dates.
    """

    all_candles = []
    batch_results = []
    errors = []

    for batch in batches:
        from_date_text = batch["from_date"]
        to_date_text = batch["to_date"]

        result = fetch_candles_for_range(
            instrument_key=instrument_key,
            from_date_text=from_date_text,
            to_date_text=to_date_text,
        )

        batch_results.append(
            {
                "from_date": from_date_text,
                "to_date": to_date_text,
                "status": result.get("status"),
                "candles_count": result.get("candles_count", 0),
                "error": result.get("error"),
            }
        )

        if result.get("error"):
            errors.append(
                {
                    "from_date": from_date_text,
                    "to_date": to_date_text,
                    "error": result.get("error"),
                }
            )

        candles = result.get("candles", []) or []
        all_candles.extend(candles)

        if REQUEST_SLEEP_SECONDS > 0:
            time.sleep(REQUEST_SLEEP_SECONDS)

    all_candles = deduplicate_candles(all_candles)
    all_candles = sort_candles(all_candles)

    candles_by_day = {}

    for candle in all_candles:
        day_text = parse_candle_date(candle)

        if not day_text:
            continue

        if valid_market_days_filter is not None and day_text not in valid_market_days_filter:
            continue

        candles_by_day.setdefault(day_text, []).append(candle)

    for day_text in list(candles_by_day.keys()):
        candles_by_day[day_text] = sort_candles(
            deduplicate_candles(candles_by_day[day_text])
        )

    return {
        "instrument_key": instrument_key,
        "batches": batch_results,
        "errors": errors,
        "all_candles_count": len(all_candles),
        "candles_by_day": candles_by_day,
        "non_empty_days": sorted(candles_by_day.keys(), reverse=True),
        "non_empty_days_count": len(candles_by_day),
        "total_filtered_candles": sum(len(items) for items in candles_by_day.values()),
    }


# ============================================================
# Step 1: Fetch NIFTY 30 Non-Empty Market Days
# ============================================================

def fetch_nifty_30_non_empty_days() -> dict:
    safe_print("============================================================")
    safe_print("FETCHING NIFTY INDEX 30 NON-EMPTY MARKET DAYS")
    safe_print("============================================================")

    from_date_obj, to_date_obj = get_lookup_range_for_market_days()

    batches = split_date_range_into_batches(
        from_date_obj=from_date_obj,
        to_date_obj=to_date_obj,
        max_days_per_request=MAX_DAYS_PER_REQUEST,
    )

    safe_print(f"NIFTY lookup range : {format_date(from_date_obj)} to {format_date(to_date_obj)}")
    safe_print(f"NIFTY batches      : {len(batches)}")
    safe_print(f"Batch size         : {MAX_DAYS_PER_REQUEST} calendar days max")

    result = fetch_candles_for_batches(
        instrument_key=MAIN_INDEX_KEY,
        batches=batches,
        valid_market_days_filter=None,
    )

    all_non_empty_days = sorted(
        result.get("candles_by_day", {}).keys(),
        reverse=True,
    )

    valid_market_days = all_non_empty_days[:MARKET_DAYS_REQUIRED]

    candles_by_day = {
        day_text: result["candles_by_day"][day_text]
        for day_text in valid_market_days
        if day_text in result.get("candles_by_day", {})
    }

    extra_non_empty_days = all_non_empty_days[MARKET_DAYS_REQUIRED:]

    payload = {
        "status": (
            "success"
            if len(valid_market_days) == MARKET_DAYS_REQUIRED
            else "partial_success"
        ),
        "instrument_key": MAIN_INDEX_KEY,
        "interval": INTERVAL,
        "api_version": API_VERSION,
        "generated_at": datetime.now().isoformat(),
        "required_market_days": MARKET_DAYS_REQUIRED,
        "valid_market_days_count": len(valid_market_days),
        "valid_market_days": valid_market_days,
        "lookup_from_date": format_date(from_date_obj),
        "lookup_to_date": format_date(to_date_obj),
        "checked_calendar_days": MAX_LOOKBACK_CALENDAR_DAYS,
        "batches_count": len(batches),
        "batches": result.get("batches", []),
        "errors": result.get("errors", []),
        "extra_non_empty_days_count": len(extra_non_empty_days),
        "extra_non_empty_days": extra_non_empty_days,
        "candles_by_day": candles_by_day,
    }

    save_json(NIFTY_OUTPUT_FILE, payload)

    safe_print("============================================================")
    safe_print("NIFTY FETCH COMPLETED")
    safe_print(f"Valid Market Days : {len(valid_market_days)}")
    safe_print(f"Output File       : {NIFTY_OUTPUT_FILE.resolve()}")
    safe_print("============================================================")

    return payload


# ============================================================
# Step 2: Fetch One Option Instrument
# ============================================================

def fetch_single_option_instrument(
    contract: dict,
    valid_market_days: list,
    batches: list,
    index: int,
    total_instruments: int,
) -> dict:
    instrument_key = contract.get("instrument_key")

    if not instrument_key:
        return {
            "status": "skipped",
            "reason": "missing_instrument_key",
            "contract_info": contract,
        }

    trading_symbol = contract.get("trading_symbol")

    safe_print(
        f"[START] OPTION {index}/{total_instruments}: "
        f"{trading_symbol} | {instrument_key}"
    )

    valid_filter = set(valid_market_days)

    result = fetch_candles_for_batches(
        instrument_key=instrument_key,
        batches=batches,
        valid_market_days_filter=valid_filter,
    )

    candles_by_day = result.get("candles_by_day", {}) or {}
    non_empty_days = [
        day_text
        for day_text in valid_market_days
        if day_text in candles_by_day and len(candles_by_day[day_text]) > 0
    ]

    empty_days = [
        day_text
        for day_text in valid_market_days
        if day_text not in candles_by_day or len(candles_by_day.get(day_text, [])) == 0
    ]

    instrument_total_candles = sum(
        len(candles_by_day.get(day_text, []))
        for day_text in non_empty_days
    )

    instrument_payload = {
        "status": "success" if non_empty_days else "empty",
        "generated_at": datetime.now().isoformat(),
        "interval": INTERVAL,
        "api_version": API_VERSION,
        "instrument_key": instrument_key,
        "contract_info": contract,
        "requested_days_count": len(valid_market_days),
        "requested_days": valid_market_days,
        "non_empty_days_count": len(non_empty_days),
        "non_empty_days": non_empty_days,
        "empty_days_count": len(empty_days),
        "empty_days": empty_days,
        "failed_batches_count": len(result.get("errors", [])),
        "failed_batches": result.get("errors", []),
        "batches_count": len(batches),
        "batches": result.get("batches", []),
        "total_candles": instrument_total_candles,
        "candles_by_day": {
            day_text: candles_by_day.get(day_text, [])
            for day_text in valid_market_days
            if day_text in candles_by_day
        },
    }

    output_file = OPTION_OUTPUT_DIR / f"{safe_instrument_filename(instrument_key)}.json"
    save_json(output_file, instrument_payload)

    summary = {
        "status": instrument_payload["status"],
        "instrument_key": instrument_key,
        "trading_symbol": trading_symbol,
        "instrument_type": contract.get("instrument_type"),
        "strike_price": contract.get("strike_price"),
        "expiry": contract.get("expiry"),
        "requested_days_count": len(valid_market_days),
        "non_empty_days_count": len(non_empty_days),
        "empty_days_count": len(empty_days),
        "failed_batches_count": len(result.get("errors", [])),
        "total_candles": instrument_total_candles,
        "output_file": str(output_file),
    }

    safe_print(
        f"[DONE] OPTION {index}/{total_instruments}: "
        f"{trading_symbol} | "
        f"non_empty_days={len(non_empty_days)}, "
        f"total_candles={instrument_total_candles}, "
        f"file={output_file}"
    )

    return summary


# ============================================================
# Step 3: Fetch Options In Parallel
# ============================================================

def fetch_option_candles_for_valid_days_parallel(
    option_contracts: list,
    valid_market_days: list,
) -> dict:
    safe_print("============================================================")
    safe_print("FETCHING OPTION CANDLES IN PARALLEL")
    safe_print("============================================================")

    OPTION_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    total_instruments = len(option_contracts)

    from_date_obj, to_date_obj = get_range_from_valid_days(valid_market_days)

    batches = split_date_range_into_batches(
        from_date_obj=from_date_obj,
        to_date_obj=to_date_obj,
        max_days_per_request=MAX_DAYS_PER_REQUEST,
    )

    safe_print(f"Option date range : {format_date(from_date_obj)} to {format_date(to_date_obj)}")
    safe_print(f"Valid days count  : {len(valid_market_days)}")
    safe_print(f"Option batches    : {len(batches)}")
    safe_print(f"Max workers       : {MAX_WORKERS}")

    instruments_summary = []

    total_success_instruments = 0
    total_empty_instruments = 0
    total_skipped_instruments = 0
    total_failed_instruments = 0
    total_candles = 0

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_to_contract = {}

        for index, contract in enumerate(option_contracts, start=1):
            future = executor.submit(
                fetch_single_option_instrument,
                contract,
                valid_market_days,
                batches,
                index,
                total_instruments,
            )

            future_to_contract[future] = contract

        completed_count = 0

        for future in as_completed(future_to_contract):
            completed_count += 1
            contract = future_to_contract[future]

            try:
                summary = future.result()

                instruments_summary.append(summary)

                status = summary.get("status")

                if status == "success":
                    total_success_instruments += 1
                elif status == "empty":
                    total_empty_instruments += 1
                elif status == "skipped":
                    total_skipped_instruments += 1
                else:
                    total_failed_instruments += 1

                total_candles += int(summary.get("total_candles", 0) or 0)

                safe_print(
                    f"[PROGRESS] {completed_count}/{total_instruments} completed | "
                    f"latest={summary.get('trading_symbol')} | "
                    f"status={status}"
                )

            except Exception as ex:
                total_failed_instruments += 1

                error_summary = {
                    "status": "failed",
                    "instrument_key": contract.get("instrument_key"),
                    "trading_symbol": contract.get("trading_symbol"),
                    "instrument_type": contract.get("instrument_type"),
                    "strike_price": contract.get("strike_price"),
                    "expiry": contract.get("expiry"),
                    "error": f"{type(ex).__name__}: {ex}",
                }

                instruments_summary.append(error_summary)

                safe_print(
                    f"[FAILED] {completed_count}/{total_instruments}: "
                    f"{contract.get('trading_symbol')} | "
                    f"error={type(ex).__name__}: {ex}"
                )

    instruments_summary = sorted(
        instruments_summary,
        key=lambda item: (
            str(item.get("instrument_type")),
            float(item.get("strike_price") or 0),
            str(item.get("instrument_key")),
        ),
    )

    summary = {
        "status": "success",
        "generated_at": datetime.now().isoformat(),
        "interval": INTERVAL,
        "api_version": API_VERSION,
        "max_workers": MAX_WORKERS,
        "max_days_per_request": MAX_DAYS_PER_REQUEST,
        "total_option_instruments": total_instruments,
        "success_instruments": total_success_instruments,
        "empty_instruments": total_empty_instruments,
        "skipped_instruments": total_skipped_instruments,
        "failed_instruments": total_failed_instruments,
        "valid_market_days_count": len(valid_market_days),
        "valid_market_days": valid_market_days,
        "from_date": format_date(from_date_obj),
        "to_date": format_date(to_date_obj),
        "batches_count": len(batches),
        "batches": batches,
        "total_candles": total_candles,
        "option_output_dir": str(OPTION_OUTPUT_DIR),
        "instruments": instruments_summary,
    }

    safe_print("============================================================")
    safe_print("OPTION PARALLEL FETCH COMPLETED")
    safe_print(f"Total instruments : {total_instruments}")
    safe_print(f"Success           : {total_success_instruments}")
    safe_print(f"Empty             : {total_empty_instruments}")
    safe_print(f"Failed            : {total_failed_instruments}")
    safe_print(f"Total candles     : {total_candles}")
    safe_print("============================================================")

    return summary


# ============================================================
# Main
# ============================================================

def main():
    started_at = datetime.now().isoformat()

    safe_print("============================================================")
    safe_print("BACKTEST HISTORICAL CANDLE FETCH STARTED")
    safe_print("============================================================")
    safe_print(f"Started At         : {started_at}")
    safe_print(f"Interval           : {INTERVAL}")
    safe_print(f"API Version        : {API_VERSION}")
    safe_print(f"Market Days Needed : {MARKET_DAYS_REQUIRED}")
    safe_print(f"Max Days/Request   : {MAX_DAYS_PER_REQUEST}")
    safe_print(f"Max Workers        : {MAX_WORKERS}")
    safe_print("============================================================")

    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    OPTION_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    option_file_payload = load_option_file()

    option_contracts = option_file_payload.get("data", []) or []

    if not option_contracts:
        raise RuntimeError(
            "No option contracts found in option file. "
            "Expected data[] in current_week_options_23500_25000.json"
        )

    safe_print(f"Loaded option contracts: {len(option_contracts)}")
    safe_print(f"Nearest expiry: {option_file_payload.get('nearest_expiry')}")
    safe_print(
        f"Strike range: "
        f"{option_file_payload.get('strike_from')} to "
        f"{option_file_payload.get('strike_to')}"
    )

    # --------------------------------------------------------
    # 1. Fetch NIFTY valid market days first
    # --------------------------------------------------------
    nifty_payload = fetch_nifty_30_non_empty_days()

    valid_market_days = nifty_payload.get("valid_market_days", [])

    if not valid_market_days:
        raise RuntimeError("No valid NIFTY market days found. Cannot continue.")

    # --------------------------------------------------------
    # 2. Fetch option candles for same dates in parallel
    # --------------------------------------------------------
    options_summary = fetch_option_candles_for_valid_days_parallel(
        option_contracts=option_contracts,
        valid_market_days=valid_market_days,
    )

    completed_at = datetime.now().isoformat()

    # --------------------------------------------------------
    # 3. Save master summary
    # --------------------------------------------------------
    final_summary = {
        "status": "success",
        "started_at": started_at,
        "completed_at": completed_at,
        "generated_at": completed_at,
        "option_source_file": str(OPTION_FILE),
        "nifty_output_file": str(NIFTY_OUTPUT_FILE),
        "option_output_dir": str(OPTION_OUTPUT_DIR),
        "summary_output_file": str(SUMMARY_OUTPUT_FILE),
        "main_index_key": MAIN_INDEX_KEY,
        "interval": INTERVAL,
        "api_version": API_VERSION,
        "market_days_required": MARKET_DAYS_REQUIRED,
        "max_lookback_calendar_days": MAX_LOOKBACK_CALENDAR_DAYS,
        "max_days_per_request": MAX_DAYS_PER_REQUEST,
        "max_workers": MAX_WORKERS,
        "nifty": {
            "valid_market_days_count": nifty_payload.get("valid_market_days_count"),
            "valid_market_days": nifty_payload.get("valid_market_days"),
            "lookup_from_date": nifty_payload.get("lookup_from_date"),
            "lookup_to_date": nifty_payload.get("lookup_to_date"),
            "batches_count": nifty_payload.get("batches_count"),
            "errors_count": len(nifty_payload.get("errors", [])),
        },
        "options": options_summary,
    }

    save_json(SUMMARY_OUTPUT_FILE, final_summary)

    safe_print("============================================================")
    safe_print("BACKTEST HISTORICAL CANDLE FETCH COMPLETED")
    safe_print("============================================================")
    safe_print(f"Started At           : {started_at}")
    safe_print(f"Completed At         : {completed_at}")
    safe_print(f"NIFTY valid days     : {nifty_payload.get('valid_market_days_count')}")
    safe_print(f"Option instruments   : {options_summary.get('total_option_instruments')}")
    safe_print(f"Success instruments  : {options_summary.get('success_instruments')}")
    safe_print(f"Empty instruments    : {options_summary.get('empty_instruments')}")
    safe_print(f"Failed instruments   : {options_summary.get('failed_instruments')}")
    safe_print(f"Total option candles : {options_summary.get('total_candles')}")
    safe_print(f"NIFTY output file    : {NIFTY_OUTPUT_FILE.resolve()}")
    safe_print(f"Option output folder : {OPTION_OUTPUT_DIR.resolve()}")
    safe_print(f"Summary output file  : {SUMMARY_OUTPUT_FILE.resolve()}")
    safe_print("============================================================")


if __name__ == "__main__":
    main()