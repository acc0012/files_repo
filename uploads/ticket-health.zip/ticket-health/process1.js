const processAllTickets = async (
  live_mode = true,
  test_mode = false
) => {
  "use strict";

  const CONFIG = {
    baseUrl:
      "https://nextgenghd.ultimatix.net/NextGenGHDIncidentService/rest",
    localApiBaseUrl: "http://localhost:8000",
    localApiSaveEndpoint: "/api/files/save-json",
    localApiFilename: "all_tickets.json",
    levels: [
      { levelId: 489, levelName: "L 1.5 - GHD" },
      { levelId: 405, levelName: "Level 405" },
      { levelId: 399, levelName: "Level 399" }
    ],
    ticketsPerLevelBatch: 3,
    testTicketsPerLevel: 3,
    batchDelayMs: 2000,
    requestTimeoutMs: 30000,
    localApiTimeoutMs: 30000,
    retryCount: 2,
    retryDelayMs: 3000,
    includeResolutionDetails: true,
    includeAllTicketDetails: true,
    includeDetailedTrace: true,
    persistToLocalStorage: true,
    localStorageKey: "nextGenGhdTicketDetails"
  };

  const liveModeEnabled = live_mode === true;
  const testModeEnabled = test_mode === true;

  const state = {
    ticketList: [],
    errors: [],
    persistenceErrors: [],
    totalAvailableTickets: 0,
    totalTickets: 0,
    processedTickets: 0,
    persistedTickets: 0,
    levelProgress: {},
    startedAt: null
  };

  const sleep = (milliseconds) =>
    new Promise((resolve) =>
      setTimeout(resolve, milliseconds)
    );

  const getCookie = (name) => {
    const cookies = document.cookie
      ? document.cookie.split(";")
      : [];

    for (const cookie of cookies) {
      const separatorIndex = cookie.indexOf("=");

      const cookieName = cookie
        .slice(
          0,
          separatorIndex === -1
            ? cookie.length
            : separatorIndex
        )
        .trim();

      if (cookieName === name) {
        return decodeURIComponent(
          separatorIndex === -1
            ? ""
            : cookie.slice(separatorIndex + 1)
        );
      }
    }

    return null;
  };

  const getXsrfToken = () =>
    getCookie("XSRF-TOKEN") ||
    getCookie("XSRF_TOKEN") ||
    getCookie("xsrf-token") ||
    getCookie("CSRF-TOKEN");

  const createHeaders = ({
    includeXsrf = true
  } = {}) => {
    const headers = {
      accept: "application/json, text/plain, */*",
      "content-type": "application/json"
    };

    if (includeXsrf) {
      const xsrfToken = getXsrfToken();

      if (xsrfToken) {
        headers["x-xsrf-token"] = xsrfToken;
      }
    }

    return headers;
  };

  const fetchWithTimeout = async (
    url,
    options = {},
    timeoutMs = CONFIG.requestTimeoutMs
  ) => {
    const controller = new AbortController();

    const timeoutId = setTimeout(
      () => controller.abort(),
      timeoutMs
    );

    try {
      return await fetch(url, {
        ...options,
        signal: controller.signal
      });
    } finally {
      clearTimeout(timeoutId);
    }
  };

  const parseResponse = async (response) => {
    const responseText = await response.text();

    if (!responseText) {
      return null;
    }

    try {
      return JSON.parse(responseText);
    } catch {
      return responseText;
    }
  };

  const requestJson = async (
    endpoint,
    body,
    {
      retries = CONFIG.retryCount,
      includeXsrf = true,
      timeoutMs = CONFIG.requestTimeoutMs
    } = {}
  ) => {
    const url = `${CONFIG.baseUrl}/${endpoint}`;
    let lastError = null;

    for (
      let attempt = 0;
      attempt <= retries;
      attempt += 1
    ) {
      try {
        const response = await fetchWithTimeout(
          url,
          {
            method: "POST",
            headers: createHeaders({
              includeXsrf
            }),
            body: JSON.stringify(body),
            mode: "cors",
            credentials: "include",
            referrer:
              "https://nextgenghd.ultimatix.net/NextGenGHDUI/"
          },
          timeoutMs
        );

        const responseData =
          await parseResponse(response);

        if (!response.ok) {
          const error = new Error(
            `${endpoint} failed with HTTP ${response.status}`
          );

          error.status = response.status;
          error.response = responseData;

          throw error;
        }

        return responseData;
      } catch (error) {
        lastError = error;

        if (error?.name === "AbortError") {
          lastError = new Error(
            `${endpoint} timed out after ${timeoutMs} milliseconds`
          );

          lastError.status = null;
        }

        const requestStatus =
          lastError?.status ??
          error?.status ??
          null;

        const shouldRetry =
          attempt < retries &&
          requestStatus !== 400 &&
          requestStatus !== 401 &&
          requestStatus !== 403;

        if (!shouldRetry) {
          break;
        }

        console.warn(
          `${endpoint} attempt ${attempt + 1} failed. Retrying...`
        );

        await sleep(
          CONFIG.retryDelayMs * (attempt + 1)
        );
      }
    }

    throw lastError;
  };

  const requestLocalApi = async (
    endpoint,
    body,
    {
      retries = CONFIG.retryCount,
      timeoutMs = CONFIG.localApiTimeoutMs
    } = {}
  ) => {
    const url =
      `${CONFIG.localApiBaseUrl}${endpoint}`;

    let lastError = null;

    for (
      let attempt = 0;
      attempt <= retries;
      attempt += 1
    ) {
      try {
        const response = await fetchWithTimeout(
          url,
          {
            method: "POST",
            headers: {
              accept: "application/json",
              "content-type": "application/json"
            },
            body: JSON.stringify(body),
            mode: "cors",
            credentials: "omit"
          },
          timeoutMs
        );

        const responseData =
          await parseResponse(response);

        if (!response.ok) {
          const error = new Error(
            `Local API request failed with HTTP ${response.status}`
          );

          error.status = response.status;
          error.response = responseData;

          throw error;
        }

        return responseData;
      } catch (error) {
        lastError = error;

        if (error?.name === "AbortError") {
          lastError = new Error(
            `Local API request timed out after ${timeoutMs} milliseconds`
          );

          lastError.status = null;
        }

        const requestStatus =
          lastError?.status ??
          error?.status ??
          null;

        const shouldRetry =
          attempt < retries &&
          requestStatus !== 400 &&
          requestStatus !== 401 &&
          requestStatus !== 403;

        if (!shouldRetry) {
          break;
        }

        console.warn(
          `Local API attempt ${attempt + 1} failed. Retrying...`
        );

        await sleep(
          CONFIG.retryDelayMs * (attempt + 1)
        );
      }
    }

    throw lastError;
  };

  const normalizeTicketId = (value) => {
    if (
      value === null ||
      value === undefined ||
      value === ""
    ) {
      return null;
    }

    const normalized = String(value).trim();

    return /^\d+$/.test(normalized)
      ? normalized
      : null;
  };

  const findTicketId = (ticket) => {
    if (
      ticket === null ||
      ticket === undefined
    ) {
      return null;
    }

    if (
      typeof ticket === "number" ||
      typeof ticket === "string"
    ) {
      return normalizeTicketId(ticket);
    }

    if (typeof ticket !== "object") {
      return null;
    }

    const possibleKeys = [
      "ticketNo",
      "ticketId",
      "ticketID",
      "ticketNumber",
      "callId",
      "callID",
      "incidentId",
      "incidentID",
      "id"
    ];

    for (const key of possibleKeys) {
      const ticketId = normalizeTicketId(
        ticket[key]
      );

      if (ticketId) {
        return ticketId;
      }
    }

    return null;
  };

  const extractTicketObjects = (response) => {
    const results = [];
    const visited = new WeakSet();

    const walk = (value) => {
      if (
        value === null ||
        value === undefined
      ) {
        return;
      }

      if (Array.isArray(value)) {
        for (const item of value) {
          walk(item);
        }

        return;
      }

      if (typeof value !== "object") {
        return;
      }

      if (visited.has(value)) {
        return;
      }

      visited.add(value);

      const ticketId = findTicketId(value);

      if (ticketId) {
        results.push({
          ticketId,
          summary: value
        });

        return;
      }

      for (
        const childValue of Object.values(value)
      ) {
        if (
          childValue &&
          (
            Array.isArray(childValue) ||
            typeof childValue === "object"
          )
        ) {
          walk(childValue);
        }
      }
    };

    walk(response);

    const uniqueTickets = new Map();

    for (const ticket of results) {
      if (!uniqueTickets.has(ticket.ticketId)) {
        uniqueTickets.set(
          ticket.ticketId,
          ticket
        );
      }
    }

    return [...uniqueTickets.values()];
  };

  const fetchTicketsForLevel = async (level) => {
    try {
      const response = await requestJson(
        "getTicketsByLevel",
        [false, Number(level.levelId)],
        {
          includeXsrf: false
        }
      );

      const tickets =
        extractTicketObjects(response);

      return {
        level,
        response,
        tickets,
        availableCount: tickets.length
      };
    } catch (error) {
      state.errors.push({
        levelId: level.levelId,
        levelName: level.levelName,
        endpoint: "getTicketsByLevel",
        error: error.message
      });

      return {
        level,
        response: null,
        tickets: [],
        availableCount: 0
      };
    }
  };

  const safeTicketRequest = async (
    endpoint,
    ticketId
  ) => {
    try {
      const data = await requestJson(
        endpoint,
        Number(ticketId),
        {
          includeXsrf: true
        }
      );

      return {
        success: true,
        data,
        error: null
      };
    } catch (error) {
      return {
        success: false,
        data: null,
        error: error.message
      };
    }
  };

  const persistTicketToLocalApi = async (
    ticketRecord
  ) => {
    if (!liveModeEnabled) {
      return {
        success: false,
        skipped: true,
        filename: null,
        error: null,
        message: "Live mode is disabled."
      };
    }

    const filename =
      CONFIG.localApiFilename;

    try {
      const result = await requestLocalApi(
        CONFIG.localApiSaveEndpoint,
        {
          filename,
          content: ticketRecord
        }
      );

      state.persistedTickets += 1;

      return {
        success: true,
        skipped: false,
        filename,
        error: null,
        result
      };
    } catch (error) {
      const persistenceError = {
        levelId:
          ticketRecord.level?.levelId ?? null,
        levelName:
          ticketRecord.level?.levelName ?? null,
        ticketId: ticketRecord.ticketId,
        endpoint:
          CONFIG.localApiSaveEndpoint,
        filename,
        error: error.message,
        occurredAt: new Date().toISOString()
      };

      state.persistenceErrors.push(
        persistenceError
      );

      console.error(
        `Unable to persist ticket ${ticketRecord.ticketId}:`,
        error
      );

      return {
        success: false,
        skipped: false,
        filename,
        error: error.message
      };
    }
  };

  const fetchTicketDetails = async (
    queueItem
  ) => {
    const requests = [];

    if (CONFIG.includeAllTicketDetails) {
      requests.push({
        key: "allTicketDetails",
        endpoint: "getAllTicketDetails"
      });
    }

    if (CONFIG.includeResolutionDetails) {
      requests.push({
        key: "resolutionDetails",
        endpoint:
          "getTicketDetailsForResolution"
      });
    }

    if (CONFIG.includeDetailedTrace) {
      requests.push({
        key: "detailedTrace",
        endpoint: "getCallDetailedTrace"
      });
    }

    const results = await Promise.all(
      requests.map(
        async ({ key, endpoint }) => ({
          key,
          endpoint,
          result: await safeTicketRequest(
            endpoint,
            queueItem.ticketId
          )
        })
      )
    );

    const data = {};
    const failedEndpoints = [];

    for (
      const {
        key,
        endpoint,
        result
      } of results
    ) {
      data[key] = result.data;

      if (!result.success) {
        failedEndpoints.push(endpoint);

        state.errors.push({
          levelId: queueItem.level.levelId,
          levelName:
            queueItem.level.levelName,
          ticketId: queueItem.ticketId,
          endpoint,
          error: result.error
        });
      }
    }

    const ticketRecord = {
      level: {
        levelId: queueItem.level.levelId,
        levelName:
          queueItem.level.levelName
      },
      ticketId: queueItem.ticketId,
      data: {
        summary: queueItem.summary,
        ...data
      },
      metadata: {
        fetchedAt: new Date().toISOString(),
        completed:
          failedEndpoints.length === 0,
        failedEndpoints,
        liveMode: liveModeEnabled,
        testMode: testModeEnabled
      }
    };

    const persistenceResult =
      await persistTicketToLocalApi(
        ticketRecord
      );

    ticketRecord.metadata.persistence = {
      attempted: liveModeEnabled,
      success: persistenceResult.success,
      skipped: persistenceResult.skipped,
      filename:
        persistenceResult.filename ?? null,
      savedAt:
        persistenceResult.success
          ? new Date().toISOString()
          : null,
      error:
        persistenceResult.error ?? null
    };

    return ticketRecord;
  };

  const upsertTicket = (ticketRecord) => {
    const existingIndex =
      state.ticketList.findIndex(
        (item) =>
          String(item.ticketId) ===
            String(ticketRecord.ticketId) &&
          String(item.level?.levelId) ===
            String(
              ticketRecord.level.levelId
            )
      );

    if (existingIndex === -1) {
      state.ticketList.push(ticketRecord);
    } else {
      state.ticketList[existingIndex] =
        ticketRecord;
    }
  };

  const saveToLocalStorage = () => {
    if (!CONFIG.persistToLocalStorage) {
      return;
    }

    try {
      localStorage.setItem(
        CONFIG.localStorageKey,
        JSON.stringify({
          savedAt: new Date().toISOString(),
          liveMode: liveModeEnabled,
          testMode: testModeEnabled,
          totalAvailableTickets:
            state.totalAvailableTickets,
          tickets: state.ticketList,
          errors: state.errors,
          persistenceErrors:
            state.persistenceErrors
        })
      );
    } catch (error) {
      console.error(
        "Unable to save to localStorage:",
        error
      );
    }
  };

  const loadFromLocalStorage = () => {
    if (!CONFIG.persistToLocalStorage) {
      return;
    }

    try {
      const saved = localStorage.getItem(
        CONFIG.localStorageKey
      );

      if (!saved) {
        return;
      }

      const data = JSON.parse(saved);

      if (Array.isArray(data.tickets)) {
        state.ticketList = data.tickets;
      }

      if (Array.isArray(data.errors)) {
        state.errors = data.errors;
      }

      if (
        Array.isArray(
          data.persistenceErrors
        )
      ) {
        state.persistenceErrors =
          data.persistenceErrors;
      }
    } catch (error) {
      console.error(
        "Unable to load from localStorage:",
        error
      );
    }
  };

  const getElapsedTime = () => {
    if (!state.startedAt) {
      return "00:00:00";
    }

    const elapsedMilliseconds =
      Date.now() - state.startedAt;

    const totalSeconds = Math.floor(
      elapsedMilliseconds / 1000
    );

    const hours = String(
      Math.floor(totalSeconds / 3600)
    ).padStart(2, "0");

    const minutes = String(
      Math.floor(
        (totalSeconds % 3600) / 60
      )
    ).padStart(2, "0");

    const seconds = String(
      totalSeconds % 60
    ).padStart(2, "0");

    return `${hours}:${minutes}:${seconds}`;
  };

  const printStatus = ({
    completed = false
  } = {}) => {
    console.clear();

    console.log(
      completed
        ? "GHD Ticket Processing Complete"
        : "GHD Ticket Processing"
    );

    console.log(
      `Live mode: ${
        liveModeEnabled ? "Enabled" : "Disabled"
      }`
    );

    console.log(
      `Test mode: ${
        testModeEnabled ? "Enabled" : "Disabled"
      }`
    );

    if (testModeEnabled) {
      console.log(
        `Test limit: First ${CONFIG.testTicketsPerLevel} tickets per level`
      );
    }

    console.log(
      `Available tickets: ${state.totalAvailableTickets}`
    );

    console.log(
      `Selected for processing: ${state.totalTickets}`
    );

    console.log(
      `Overall: ${state.processedTickets} / ${state.totalTickets}`
    );

    if (liveModeEnabled) {
      console.log(
        `Saved through API: ${state.persistedTickets} / ${state.processedTickets}`
      );

      console.log(
        `Output file: ${CONFIG.localApiFilename}`
      );
    }

    console.log(
      `Elapsed: ${getElapsedTime()}`
    );

    console.log("");

    for (const level of CONFIG.levels) {
      const progress =
        state.levelProgress[
          String(level.levelId)
        ];

      if (!progress) {
        console.log(
          `${level.levelName}: Preparing`
        );

        continue;
      }

      let statusText = "Waiting";

      if (
        progress.completed &&
        progress.total === 0
      ) {
        statusText = "No tickets";
      } else if (progress.completed) {
        statusText = "Complete";
      } else if (progress.active) {
        statusText =
          `Batch ${progress.currentBatch} / ` +
          `${progress.totalBatches}`;
      }

      console.log(
        `${level.levelName}: ` +
        `${progress.processed} / ` +
        `${progress.total} selected | ` +
        `${progress.available} available | ` +
        `${statusText}`
      );

      if (
        progress.active &&
        progress.currentTicketIds.length
      ) {
        console.log(
          "  Processing: " +
          progress.currentTicketIds.join(", ")
        );
      }
    }

    console.log("");

    console.log(
      `Stored tickets: ${state.ticketList.length}`
    );

    if (state.errors.length) {
      console.log(
        `Ticket API errors: ${state.errors.length}`
      );
    }

    if (state.persistenceErrors.length) {
      console.log(
        `Local persistence errors: ${state.persistenceErrors.length}`
      );
    }
  };

  const createLevelQueue = (
    levelResult
  ) => {
    const uniqueTicketIds = new Set();
    const completeQueue = [];

    for (const ticket of levelResult.tickets) {
      const ticketId = String(
        ticket.ticketId
      );

      if (uniqueTicketIds.has(ticketId)) {
        continue;
      }

      uniqueTicketIds.add(ticketId);

      completeQueue.push({
        level: {
          levelId:
            levelResult.level.levelId,
          levelName:
            levelResult.level.levelName
        },
        ticketId,
        summary: ticket.summary
      });
    }

    if (testModeEnabled) {
      return completeQueue.slice(
        0,
        CONFIG.testTicketsPerLevel
      );
    }

    return completeQueue;
  };

  const processLevelQueue = async (
    level,
    queue
  ) => {
    const progress =
      state.levelProgress[
        String(level.levelId)
      ];

    if (!queue.length) {
      progress.active = false;
      progress.completed = true;
      progress.currentBatch = 0;
      progress.currentTicketIds = [];

      printStatus();

      return {
        levelId: level.levelId,
        levelName: level.levelName,
        available: progress.available,
        selected: 0,
        processed: 0,
        persisted: 0
      };
    }

    progress.active = true;
    printStatus();

    for (
      let batchStart = 0;
      batchStart < queue.length;
      batchStart +=
        CONFIG.ticketsPerLevelBatch
    ) {
      const batch = queue.slice(
        batchStart,
        batchStart +
          CONFIG.ticketsPerLevelBatch
      );

      const batchNumber =
        Math.floor(
          batchStart /
            CONFIG.ticketsPerLevelBatch
        ) + 1;

      progress.currentBatch = batchNumber;
      progress.currentTicketIds =
        batch.map(
          (item) => item.ticketId
        );

      printStatus();

      const batchResults =
        await Promise.all(
          batch.map((queueItem) =>
            fetchTicketDetails(queueItem)
          )
        );

      for (
        const ticketRecord of batchResults
      ) {
        upsertTicket(ticketRecord);

        progress.processed += 1;
        state.processedTickets += 1;

        if (
          ticketRecord.metadata
            ?.persistence?.success
        ) {
          progress.persisted += 1;
        }
      }

      progress.currentTicketIds = [];

      saveToLocalStorage();
      printStatus();

      const hasMoreTickets =
        batchStart +
          CONFIG.ticketsPerLevelBatch <
        queue.length;

      if (hasMoreTickets) {
        await sleep(
          CONFIG.batchDelayMs
        );
      }
    }

    progress.active = false;
    progress.completed = true;
    progress.currentTicketIds = [];

    printStatus();

    return {
      levelId: level.levelId,
      levelName: level.levelName,
      available: progress.available,
      selected: progress.total,
      processed: progress.processed,
      persisted: progress.persisted
    };
  };

  loadFromLocalStorage();

  state.startedAt = Date.now();

  console.log(
    `Starting ticket processing with live mode ${
      liveModeEnabled
        ? "enabled"
        : "disabled"
    } and test mode ${
      testModeEnabled
        ? "enabled"
        : "disabled"
    }.`
  );

  if (testModeEnabled) {
    console.log(
      `Only the first ${CONFIG.testTicketsPerLevel} unique tickets from each level will be processed.`
    );
  }

  if (liveModeEnabled) {
    console.log(
      `Processed tickets will be sent to ${CONFIG.localApiBaseUrl}${CONFIG.localApiSaveEndpoint}.`
    );

    console.log(
      `Tickets will be appended to ${CONFIG.localApiFilename}.`
    );
  }

  const levelResults = await Promise.all(
    CONFIG.levels.map((level) =>
      fetchTicketsForLevel(level)
    )
  );

  const levelQueues = new Map();

  state.totalAvailableTickets = 0;
  state.totalTickets = 0;
  state.processedTickets = 0;
  state.persistedTickets = 0;
  state.levelProgress = {};

  for (
    const levelResult of levelResults
  ) {
    const availableTickets =
      levelResult.tickets.length;

    const queue = createLevelQueue(
      levelResult
    );

    levelQueues.set(
      String(levelResult.level.levelId),
      queue
    );

    const totalBatches = Math.ceil(
      queue.length /
        CONFIG.ticketsPerLevelBatch
    );

    state.levelProgress[
      String(levelResult.level.levelId)
    ] = {
      levelId:
        levelResult.level.levelId,
      levelName:
        levelResult.level.levelName,
      available: availableTickets,
      total: queue.length,
      processed: 0,
      persisted: 0,
      currentBatch: 0,
      totalBatches,
      currentTicketIds: [],
      active: false,
      completed: queue.length === 0
    };

    state.totalAvailableTickets +=
      availableTickets;

    state.totalTickets += queue.length;
  }

  printStatus();

  if (state.totalTickets === 0) {
    printStatus({
      completed: true
    });

    console.log("No tickets available.");

    return {
      liveMode: liveModeEnabled,
      testMode: testModeEnabled,
      testTicketsPerLevel:
        testModeEnabled
          ? CONFIG.testTicketsPerLevel
          : null,
      tickets: state.ticketList,
      errors: state.errors,
      persistenceErrors:
        state.persistenceErrors,
      totalAvailable: 0,
      total: 0,
      processed: 0,
      persisted: 0,
      levelResults: []
    };
  }

  const processingResults =
    await Promise.all(
      CONFIG.levels.map((level) => {
        const queue =
          levelQueues.get(
            String(level.levelId)
          ) || [];

        return processLevelQueue(
          level,
          queue
        );
      })
    );

  saveToLocalStorage();

  printStatus({
    completed: true
  });

  console.log(
    `Fetched ${state.totalAvailableTickets} available tickets.`
  );

  console.log(
    `Selected ${state.totalTickets} tickets for processing.`
  );

  console.log(
    `Processed ${state.processedTickets} / ${state.totalTickets} selected tickets.`
  );

  console.log(
    `Stored ${state.ticketList.length} tickets in local storage.`
  );

  if (liveModeEnabled) {
    console.log(
      `Saved ${state.persistedTickets} / ${state.processedTickets} tickets through the local API.`
    );

    console.log(
      `Tickets were appended to ${CONFIG.localApiFilename}.`
    );
  }

  if (state.errors.length) {
    console.warn(
      `Completed with ${state.errors.length} ticket API errors.`
    );

    console.table(state.errors);
  }

  if (state.persistenceErrors.length) {
    console.warn(
      `Completed with ${state.persistenceErrors.length} local persistence errors.`
    );

    console.table(
      state.persistenceErrors
    );
  }

  return {
    liveMode: liveModeEnabled,
    testMode: testModeEnabled,
    testTicketsPerLevel:
      testModeEnabled
        ? CONFIG.testTicketsPerLevel
        : null,
    outputFilename:
      liveModeEnabled
        ? CONFIG.localApiFilename
        : null,
    tickets: state.ticketList,
    errors: state.errors,
    persistenceErrors:
      state.persistenceErrors,
    totalAvailable:
      state.totalAvailableTickets,
    total: state.totalTickets,
    processed: state.processedTickets,
    persisted: state.persistedTickets,
    levelResults: processingResults
  };
};

window.processAllTickets =
  processAllTickets;

if (
  typeof module !== "undefined" &&
  module.exports
) {
  module.exports = processAllTickets;
}



// processAllTickets(true, false);