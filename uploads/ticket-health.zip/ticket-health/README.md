# Ticket Health Command Center - FastAPI Prototype

Enterprise ticket quality, lifecycle governance, and SLA health monitoring layer.

## Technology
- Python FastAPI
- Jinja2 server-rendered HTML
- Vanilla JavaScript and CSS
- Local Python mock data
- In-memory monitoring simulation
- No database, authentication backend, or external API

## Run
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
Open http://127.0.0.1:8000

## Live-mode simulation
Use **Run Health Scan Now**. The browser polls FastAPI endpoints while the server advances through scan stages and adds a monitoring run. State resets when the server restarts.


## Mock data and future database migration

Prototype records are stored in `app/data/mock_data.json`. Routes access them through
`app/services/repository.py`, rather than importing mock constants directly.

To migrate to a database later, create a database-backed repository implementing:

- `list_tickets(status=None, health=None, query=None)`
- `list_pending()`
- `list_resolved()`
- `get_ticket(ticket_no)`
- `list_runs()`

Then replace the exported `repository` object. The API routes and UI can remain unchanged.
