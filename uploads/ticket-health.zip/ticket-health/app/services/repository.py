from copy import deepcopy
from datetime import datetime

from app.data.mock_data import load_mock_data


class JsonTicketRepository:
    def __init__(self):
        self.reload()

    def reload(self):
        data = load_mock_data()

        self._tickets = data.get("tickets", [])
        self._lifecycle = data.get("lifecycle", {})
        self._runs = data.get("monitoringRuns", [])
        self._ai_recommendations = data.get("aiRecommendations", {})
        self._ai_action_history = data.get("aiActionHistory", {})

        self._original_tickets = deepcopy(self._tickets)
        self._original_lifecycle = deepcopy(self._lifecycle)
        self._original_ai_recommendations = deepcopy(
            self._ai_recommendations
        )
        self._original_ai_action_history = deepcopy(
            self._ai_action_history
        )

    def list_tickets(
        self,
        status=None,
        health=None,
        query=None,
    ):
        rows = self._tickets

        if status:
            rows = [
                row
                for row in rows
                if row.get("status", "").lower()
                == status.lower()
            ]

        if health:
            rows = [
                row
                for row in rows
                if row.get("healthStatus", "").lower()
                == health.lower()
            ]

        if query:
            needle = query.strip().lower()

            rows = [
                row
                for row in rows
                if needle
                in " ".join(
                    [
                        str(row.get("ticketNo", "")),
                        str(row.get("description", "")),
                        str(row.get("assignedTo", "")),
                        str(row.get("assignmentGroup", "")),
                        str(row.get("item", "")),
                        str(row.get("catalog", "")),
                        str(row.get("issueType", "")),
                        str(row.get("location", "")),
                    ]
                ).lower()
            ]

        return deepcopy(rows)

    def list_pending(self):
        return [
            row
            for row in self.list_tickets()
            if row.get("status", "").lower() != "closed"
        ]

    def list_resolved(self):
        return [
            row
            for row in self.list_tickets()
            if row.get("status", "").lower() == "closed"
        ]

    def list_runs(self):
        return self._runs

    def get_ticket(self, ticket_no):
        ticket = self._find_ticket(ticket_no)

        if ticket is None:
            return None

        result = deepcopy(ticket)
        result["events"] = deepcopy(
            self._lifecycle.get(ticket_no, [])
        )
        result["aiRecommendation"] = (
            self.get_ai_recommendation(ticket_no)
        )
        result["aiActionHistory"] = (
            self.list_ai_action_history(ticket_no)
        )

        return result

    def update_ticket(self, ticket_no, changes):
        ticket = self._find_ticket(ticket_no)

        if ticket is None:
            return None

        protected_fields = {
            "ticketNo",
            "events",
            "aiRecommendation",
            "aiActionHistory",
        }

        for field, value in changes.items():
            if field not in protected_fields:
                ticket[field] = deepcopy(value)

        return self.get_ticket(ticket_no)

    def get_ai_recommendation(self, ticket_no):
        recommendation = self._ai_recommendations.get(
            ticket_no
        )

        if recommendation is None:
            return None

        return deepcopy(recommendation)

    def save_ai_recommendation(
        self,
        ticket_no,
        recommendation,
    ):
        if self._find_ticket(ticket_no) is None:
            return None

        saved_recommendation = deepcopy(recommendation)

        saved_recommendation["ticketNo"] = ticket_no
        saved_recommendation.setdefault(
            "status",
            "PENDING",
        )
        saved_recommendation.setdefault(
            "generatedAt",
            self._current_time(),
        )
        saved_recommendation["updatedAt"] = (
            self._current_time()
        )

        self._ai_recommendations[ticket_no] = (
            saved_recommendation
        )

        return deepcopy(saved_recommendation)

    def update_ai_recommendation(
        self,
        ticket_no,
        changes,
    ):
        recommendation = self._ai_recommendations.get(
            ticket_no
        )

        if recommendation is None:
            return None

        recommendation.update(deepcopy(changes))
        recommendation["updatedAt"] = self._current_time()

        return deepcopy(recommendation)

    def list_ai_action_history(self, ticket_no):
        return deepcopy(
            self._ai_action_history.get(ticket_no, [])
        )

    def add_ai_action_history(
        self,
        ticket_no,
        entry,
    ):
        if self._find_ticket(ticket_no) is None:
            return None

        history = self._ai_action_history.setdefault(
            ticket_no,
            [],
        )

        saved_entry = deepcopy(entry)

        saved_entry.setdefault(
            "id",
            self._next_history_id(ticket_no),
        )
        saved_entry.setdefault(
            "ticketNo",
            ticket_no,
        )
        saved_entry.setdefault(
            "createdAt",
            self._current_time(),
        )

        history.insert(0, saved_entry)

        return deepcopy(saved_entry)

    def add_lifecycle_event(
        self,
        ticket_no,
        event,
    ):
        if self._find_ticket(ticket_no) is None:
            return None

        events = self._lifecycle.setdefault(
            ticket_no,
            [],
        )

        saved_event = deepcopy(event)

        saved_event.setdefault(
            "time",
            self._current_time(),
        )
        saved_event.setdefault(
            "actor",
            "AI Ticket Health Agent",
        )
        saved_event.setdefault(
            "level",
            "Automation",
        )
        saved_event.setdefault(
            "impact",
            "Info",
        )

        events.append(saved_event)

        return deepcopy(saved_event)

    def apply_ai_actions(
        self,
        ticket_no,
        action_ids=None,
        approved_by="User",
    ):
        ticket = self._find_ticket(ticket_no)
        recommendation = self._ai_recommendations.get(
            ticket_no
        )

        if ticket is None:
            return None

        if recommendation is None:
            return {
                "success": False,
                "ticketNo": ticket_no,
                "status": "FAILED",
                "message": (
                    "No AI recommendation is available "
                    "for this ticket."
                ),
                "results": [],
            }

        actions = deepcopy(
            recommendation.get("actions", [])
        )

        if action_ids is not None:
            selected_ids = set(action_ids)

            actions = [
                action
                for action in actions
                if action.get("id") in selected_ids
            ]

        if not actions:
            return {
                "success": False,
                "ticketNo": ticket_no,
                "status": "FAILED",
                "message": (
                    "No recommended actions were selected."
                ),
                "results": [],
            }

        results = []

        for action in actions:
            result = self._execute_action(
                ticket_no,
                action,
            )
            results.append(result)

        successful_actions = [
            result
            for result in results
            if result.get("success")
        ]

        failed_actions = [
            result
            for result in results
            if not result.get("success")
        ]

        if successful_actions and not failed_actions:
            recommendation_status = "APPLIED"
        elif successful_actions and failed_actions:
            recommendation_status = "PARTIALLY_APPLIED"
        else:
            recommendation_status = "FAILED"

        recommendation["status"] = recommendation_status
        recommendation["approvedBy"] = approved_by
        recommendation["approvedAt"] = (
            self._current_time()
        )
        recommendation["updatedAt"] = (
            self._current_time()
        )

        history_entry = self.add_ai_action_history(
            ticket_no,
            {
                "type": "AI_ACTION_EXECUTION",
                "status": recommendation_status,
                "approvedBy": approved_by,
                "message": (
                    f"{len(successful_actions)} action(s) "
                    f"completed and {len(failed_actions)} "
                    "action(s) failed."
                ),
                "results": results,
            },
        )

        self.add_lifecycle_event(
            ticket_no,
            {
                "action": (
                    "AI Recommended Actions Applied"
                ),
                "actor": approved_by,
                "level": "AI Agent",
                "impact": (
                    "Positive"
                    if recommendation_status == "APPLIED"
                    else "Warning"
                ),
                "remarks": (
                    f"{len(successful_actions)} recommended "
                    "action(s) were applied to the ticket."
                ),
            },
        )

        return {
            "success": (
                bool(successful_actions)
                and not failed_actions
            ),
            "ticketNo": ticket_no,
            "status": recommendation_status,
            "message": (
                f"{len(successful_actions)} action(s) "
                f"completed and {len(failed_actions)} "
                "action(s) failed."
            ),
            "results": results,
            "history": history_entry,
            "ticket": self.get_ticket(ticket_no),
        }

    def reject_ai_recommendation(
        self,
        ticket_no,
        reason=None,
        rejected_by="User",
    ):
        if self._find_ticket(ticket_no) is None:
            return None

        recommendation = self._ai_recommendations.get(
            ticket_no
        )

        if recommendation is None:
            return {
                "success": False,
                "ticketNo": ticket_no,
                "status": "FAILED",
                "message": (
                    "No AI recommendation is available "
                    "for this ticket."
                ),
            }

        rejection_reason = (
            reason or "No reason provided."
        )

        recommendation["status"] = "REJECTED"
        recommendation["rejectedBy"] = rejected_by
        recommendation["rejectedAt"] = (
            self._current_time()
        )
        recommendation["rejectionReason"] = (
            rejection_reason
        )
        recommendation["updatedAt"] = (
            self._current_time()
        )

        history_entry = self.add_ai_action_history(
            ticket_no,
            {
                "type": (
                    "AI_RECOMMENDATION_REJECTED"
                ),
                "status": "REJECTED",
                "rejectedBy": rejected_by,
                "message": rejection_reason,
            },
        )

        self.add_lifecycle_event(
            ticket_no,
            {
                "action": (
                    "AI Recommendation Rejected"
                ),
                "actor": rejected_by,
                "level": "AI Agent",
                "impact": "Warning",
                "remarks": rejection_reason,
            },
        )

        return {
            "success": True,
            "ticketNo": ticket_no,
            "status": "REJECTED",
            "message": (
                "AI recommendation was rejected."
            ),
            "history": history_entry,
            "recommendation": deepcopy(
                recommendation
            ),
        }

    def reset_ticket_demo(self, ticket_no):
        original_ticket = self._find_original_ticket(
            ticket_no
        )

        if original_ticket is None:
            return None

        current_index = self._find_ticket_index(
            ticket_no
        )

        if current_index is None:
            self._tickets.append(
                deepcopy(original_ticket)
            )
        else:
            self._tickets[current_index] = deepcopy(
                original_ticket
            )

        self._lifecycle[ticket_no] = deepcopy(
            self._original_lifecycle.get(
                ticket_no,
                [],
            )
        )

        if ticket_no in self._original_ai_recommendations:
            self._ai_recommendations[ticket_no] = (
                deepcopy(
                    self._original_ai_recommendations[
                        ticket_no
                    ]
                )
            )
        else:
            self._ai_recommendations.pop(
                ticket_no,
                None,
            )

        if ticket_no in self._original_ai_action_history:
            self._ai_action_history[ticket_no] = (
                deepcopy(
                    self._original_ai_action_history[
                        ticket_no
                    ]
                )
            )
        else:
            self._ai_action_history.pop(
                ticket_no,
                None,
            )

        return self.get_ticket(ticket_no)

    def _execute_action(
        self,
        ticket_no,
        action,
    ):
        action_id = action.get("id")
        action_type = str(
            action.get("type", "")
        ).upper()
        title = action.get(
            "title",
            "Recommended action",
        )

        result = {
            "actionId": action_id,
            "type": action_type,
            "title": title,
            "success": False,
            "message": "",
            "executedAt": self._current_time(),
        }

        if action_type == "RECATEGORIZE":
            return self._execute_recategorize(
                ticket_no,
                action,
                result,
            )

        if action_type == "REASSIGN":
            return self._execute_reassign(
                ticket_no,
                action,
                result,
            )

        if action_type == "ADD_WORK_NOTE":
            return self._execute_add_work_note(
                ticket_no,
                action,
                result,
            )

        if action_type == "UPDATE_PENDING":
            return self._execute_update_pending(
                ticket_no,
                action,
                result,
            )

        if action_type == "NOTIFY":
            return self._execute_notify(
                ticket_no,
                action,
                result,
            )

        if action_type == "UPDATE_SLA":
            return self._execute_update_sla(
                ticket_no,
                action,
                result,
            )

        result["message"] = (
            f"Unsupported action type: {action_type}"
        )

        return result

    def _execute_recategorize(
        self,
        ticket_no,
        action,
        result,
    ):
        new_category = (
            action.get("targetCategory")
            or action.get("value")
            or action.get("target")
        )

        if not new_category:
            result["message"] = (
                "Target category was not provided."
            )
            return result

        ticket = self._find_ticket(ticket_no)
        old_category = ticket.get("item", "Not set")

        ticket["item"] = new_category

        self.add_lifecycle_event(
            ticket_no,
            {
                "action": "Ticket Recategorized",
                "impact": "Positive",
                "remarks": (
                    f"Category changed from "
                    f"{old_category} to {new_category}."
                ),
            },
        )

        result["success"] = True
        result["message"] = (
            f"Ticket category changed from "
            f"{old_category} to {new_category}."
        )

        return result

    def _execute_reassign(
        self,
        ticket_no,
        action,
        result,
    ):
        target_group = (
            action.get("targetGroup")
            or action.get("assignmentGroup")
        )
        target_assignee = (
            action.get("targetAssignee")
            or action.get("assignedTo")
        )
        target_level = action.get("targetLevel")

        assignment_changes = {}

        if target_group:
            assignment_changes["assignmentGroup"] = (
                target_group
            )

        if target_assignee:
            assignment_changes["assignedTo"] = (
                target_assignee
            )

        if target_level:
            assignment_changes["level"] = target_level

        if not assignment_changes:
            result["message"] = (
                "Target assignment information "
                "was not provided."
            )
            return result

        ticket = self._find_ticket(ticket_no)

        for field, value in assignment_changes.items():
            ticket[field] = value

        destination = (
            target_group
            or target_assignee
            or target_level
        )

        self.add_lifecycle_event(
            ticket_no,
            {
                "action": "Ticket Reassigned",
                "impact": "Positive",
                "remarks": (
                    f"Ticket reassigned to {destination}."
                ),
            },
        )

        result["success"] = True
        result["message"] = (
            f"Ticket reassigned to {destination}."
        )

        return result

    def _execute_add_work_note(
        self,
        ticket_no,
        action,
        result,
    ):
        note = (
            action.get("note")
            or action.get("value")
            or action.get("description")
        )

        if not note:
            result["message"] = (
                "Work note content was not provided."
            )
            return result

        ticket = self._find_ticket(ticket_no)
        work_notes = ticket.setdefault(
            "workNotes",
            [],
        )

        work_notes.append(
            {
                "note": note,
                "addedBy": (
                    "AI Ticket Health Agent"
                ),
                "addedAt": self._current_time(),
            }
        )

        self.add_lifecycle_event(
            ticket_no,
            {
                "action": "AI Work Note Added",
                "impact": "Positive",
                "remarks": note,
            },
        )

        result["success"] = True
        result["message"] = (
            "Work note added successfully."
        )

        return result

    def _execute_update_pending(
        self,
        ticket_no,
        action,
        result,
    ):
        changes = {}

        if "pendingReason" in action:
            changes["pendingReason"] = action.get(
                "pendingReason"
            )

        if "pendingTillDate" in action:
            changes["pendingTillDate"] = action.get(
                "pendingTillDate"
            )

        if action.get("status"):
            changes["status"] = action.get("status")

        if not changes:
            changes = {
                "pendingReason": None,
                "pendingTillDate": None,
            }

        ticket = self._find_ticket(ticket_no)

        for field, value in changes.items():
            ticket[field] = value

        self.add_lifecycle_event(
            ticket_no,
            {
                "action": "Pending Status Updated",
                "impact": "Positive",
                "remarks": (
                    action.get("description")
                    or (
                        "Pending details were updated "
                        "by the AI agent."
                    )
                ),
            },
        )

        result["success"] = True
        result["message"] = (
            "Pending status updated successfully."
        )

        return result

    def _execute_notify(
        self,
        ticket_no,
        action,
        result,
    ):
        recipients = (
            action.get("recipients")
            or action.get("notify")
            or []
        )

        if isinstance(recipients, str):
            recipients = [recipients]

        recipients = [
            str(recipient).strip()
            for recipient in recipients
            if str(recipient).strip()
        ]

        if not recipients:
            result["message"] = (
                "Notification recipients "
                "were not provided."
            )
            return result

        notification = {
            "recipients": recipients,
            "subject": action.get(
                "subject",
                f"Ticket {ticket_no} was updated",
            ),
            "message": action.get(
                "message",
                (
                    "The AI Ticket Health Agent "
                    "applied corrective actions."
                ),
            ),
            "sentAt": self._current_time(),
            "status": "SIMULATED",
        }

        ticket = self._find_ticket(ticket_no)

        ticket.setdefault(
            "notifications",
            [],
        ).append(notification)

        recipients_text = ", ".join(recipients)

        self.add_lifecycle_event(
            ticket_no,
            {
                "action": "Team Notification Sent",
                "impact": "Info",
                "remarks": (
                    "Dummy notification sent to "
                    f"{recipients_text}."
                ),
            },
        )

        result["success"] = True
        result["message"] = (
            "Dummy notification sent to "
            f"{recipients_text}."
        )
        result["notification"] = notification

        return result

    def _execute_update_sla(
        self,
        ticket_no,
        action,
        result,
    ):
        changes = {}

        if "slaPercent" in action:
            changes["slaPercent"] = action.get(
                "slaPercent"
            )

        if "slaDate" in action:
            changes["slaDate"] = action.get(
                "slaDate"
            )

        if "healthStatus" in action:
            changes["healthStatus"] = action.get(
                "healthStatus"
            )

        if not changes:
            result["message"] = (
                "SLA update values were not provided."
            )
            return result

        ticket = self._find_ticket(ticket_no)

        for field, value in changes.items():
            ticket[field] = value

        self.add_lifecycle_event(
            ticket_no,
            {
                "action": "SLA Monitoring Updated",
                "impact": "Info",
                "remarks": (
                    action.get("description")
                    or (
                        "SLA monitoring details "
                        "were updated."
                    )
                ),
            },
        )

        result["success"] = True
        result["message"] = (
            "SLA monitoring details updated."
        )

        return result

    def _find_ticket(self, ticket_no):
        return next(
            (
                row
                for row in self._tickets
                if str(row.get("ticketNo"))
                == str(ticket_no)
            ),
            None,
        )

    def _find_original_ticket(self, ticket_no):
        return next(
            (
                row
                for row in self._original_tickets
                if str(row.get("ticketNo"))
                == str(ticket_no)
            ),
            None,
        )

    def _find_ticket_index(self, ticket_no):
        return next(
            (
                index
                for index, row in enumerate(
                    self._tickets
                )
                if str(row.get("ticketNo"))
                == str(ticket_no)
            ),
            None,
        )

    def _next_history_id(self, ticket_no):
        history = self._ai_action_history.get(
            ticket_no,
            [],
        )

        numeric_ids = [
            entry.get("id")
            for entry in history
            if isinstance(entry.get("id"), int)
        ]

        return max(numeric_ids, default=0) + 1

    @staticmethod
    def _current_time():
        return datetime.now().astimezone().isoformat(
            timespec="seconds"
        )


repository = JsonTicketRepository()