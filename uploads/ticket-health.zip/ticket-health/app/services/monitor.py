from datetime import datetime, timedelta
import threading
import time
from app.services.repository import repository

state = {
    "isRunning": False, "intervalHours": 6,
    "lastRun": "31 Aug 2026 10:00 PM", "nextRun": "01 Sep 2026 04:00 AM",
    "ticketsScanned": 12486, "issuesDetected": 1842,
    "progress": 100, "stage": "Completed"
}

stages = [
    "Fetching tickets", "Evaluating SLA", "Evaluating lifecycle",
    "Evaluating categorization", "Evaluating pending health",
    "Evaluating resolution", "Evaluating closure"
]


def _scan():
    state.update(isRunning=True, progress=2, stage="Starting monitoring cycle")
    for number, stage in enumerate(stages, 1):
        state.update(stage=stage, progress=int(number / len(stages) * 92))
        time.sleep(0.8)

    now = datetime.now()
    state.update(
        isRunning=False,
        progress=100,
        stage="Monitoring cycle completed",
        lastRun=now.strftime("%d %b %Y %I:%M %p"),
        nextRun=(now + timedelta(hours=state["intervalHours"])).strftime("%d %b %Y %I:%M %p"),
        ticketsScanned=state["ticketsScanned"] + 17,
        issuesDetected=state["issuesDetected"] + 3,
    )
    runs = repository.list_runs()
    runs.insert(0, {
        "id": runs[0]["id"] + 1 if runs else 1,
        "started": state["lastRun"], "duration": "4m 11s",
        "tickets": state["ticketsScanned"], "issues": state["issuesDetected"],
        "critical": 114, "status": "Completed"
    })


def start_scan():
    if not state["isRunning"]:
        threading.Thread(target=_scan, daemon=True).start()
    return state
