from copy import deepcopy


def generate_recommendation(ticket):
    ticket_no = str(ticket.get("ticketNo", ""))
    description = str(ticket.get("description", "")).strip()
    description_lower = description.lower()
    current_category = str(ticket.get("item", "")).strip()
    current_assignee = str(ticket.get("assignedTo", "")).strip()
    current_level = str(ticket.get("level", "")).strip()
    current_status = str(ticket.get("status", "")).strip()
    health_status = str(ticket.get("healthStatus", "WATCH")).upper()
    sla_percent = ticket.get("slaPercent", 0)
    findings = ticket.get("findings") or []
    health_checks = ticket.get("healthChecks") or {}
    events = ticket.get("events") or []

    route = determine_route(
        description_lower,
        current_category,
    )

    category_mismatch = (
        route["category"].lower()
        != current_category.lower()
    )

    actions = []
    analysis = []

    analysis.append(
        "Ticket description and issue context were reviewed."
    )

    analysis.append(
        "Current category and assignment path were evaluated."
    )

    analysis.append(
        "SLA exposure and ticket lifecycle evidence were checked."
    )

    if category_mismatch:
        actions.extend(
            create_routing_actions(
                ticket_no=ticket_no,
                current_category=current_category,
                current_assignee=current_assignee,
                route=route,
            )
        )

    troubleshooting_failed = check_failed(
        health_checks,
        "Troubleshooting",
    )

    has_troubleshooting_finding = any(
        str(finding.get("category", "")).lower()
        == "troubleshooting"
        for finding in findings
    )

    if troubleshooting_failed or has_troubleshooting_finding:
        actions.append(
            {
                "id": next_action_id(actions),
                "type": "ADD_WORK_NOTE",
                "title": "Add Troubleshooting Work Note",
                "description": (
                    "Add a detailed work note describing the checks "
                    "completed before routing the ticket."
                ),
                "note": (
                    "AI review identified insufficient troubleshooting "
                    "evidence. Validate the reported issue, document the "
                    "checks completed, capture the outcome and record the "
                    "reason for any further assignment."
                ),
            }
        )

    pending_failed = check_failed(
        health_checks,
        "Pending Discipline",
    )

    has_pending_finding = any(
        str(finding.get("category", "")).lower()
        == "pending"
        for finding in findings
    )

    if pending_failed or has_pending_finding:
        actions.append(
            {
                "id": next_action_id(actions),
                "type": "UPDATE_PENDING",
                "title": "Correct Pending Status",
                "description": (
                    "Remove unsupported pending information and return "
                    "the ticket to active investigation."
                ),
                "pendingReason": None,
                "pendingTillDate": None,
                "status": "Assigned To",
            }
        )

    sla_failed = check_failed(
        health_checks,
        "SLA",
    )

    if sla_failed or numeric_value(sla_percent) >= 90:
        actions.append(
            {
                "id": next_action_id(actions),
                "type": "ADD_WORK_NOTE",
                "title": "Add SLA Recovery Note",
                "description": (
                    "Record the immediate recovery plan for the SLA risk."
                ),
                "note": (
                    f"AI review identified SLA exposure at "
                    f"{sla_percent}%. Prioritize investigation, update "
                    "the next action and maintain regular work notes "
                    "until the ticket is stabilized."
                ),
            }
        )

        actions.append(
            {
                "id": next_action_id(actions),
                "type": "NOTIFY",
                "title": "Notify Current Team Lead",
                "description": (
                    "Notify the current support lead about the SLA risk."
                ),
                "recipients": [
                    create_current_team_lead_name(
                        current_category
                    )
                ],
                "subject": (
                    f"SLA attention required for ticket "
                    f"{ticket_no}"
                ),
                "message": (
                    f"Ticket {ticket_no} is at "
                    f"{sla_percent}% SLA consumption and requires "
                    "an immediate operational review."
                ),
            }
        )

    if not actions:
        actions.append(
            {
                "id": next_action_id(actions),
                "type": "ADD_WORK_NOTE",
                "title": "Add AI Review Note",
                "description": (
                    "Document that the ticket was reviewed and no "
                    "routing correction was required."
                ),
                "note": (
                    "AI ticket health review completed. The current "
                    "category and assignment appear appropriate. "
                    "Continue investigation and maintain complete "
                    "technical work notes."
                ),
            }
        )

    high_risk_findings = [
        finding
        for finding in findings
        if str(
            finding.get("severity", "")
        ).upper() in {"HIGH", "CRITICAL"}
    ]

    confidence = calculate_confidence(
        route_score=route["score"],
        category_mismatch=category_mismatch,
        high_risk_count=len(high_risk_findings),
        description=description,
    )

    summary = build_summary(
        category_mismatch=category_mismatch,
        current_category=current_category,
        route=route,
        health_status=health_status,
        sla_percent=sla_percent,
    )

    reasoning = build_reasoning(
        description=description,
        current_category=current_category,
        route=route,
        category_mismatch=category_mismatch,
        sla_percent=sla_percent,
        findings=findings,
        events=events,
        current_level=current_level,
        current_status=current_status,
    )

    return deepcopy(
        {
            "ticketNo": ticket_no,
            "status": "PENDING",
            "confidence": confidence,
            "riskScore": calculate_risk_score(
                health_status=health_status,
                sla_percent=sla_percent,
                findings=findings,
                health_checks=health_checks,
            ),
            "summary": summary,
            "reasoning": reasoning,
            "recommendedCategory": route["category"],
            "recommendedAssignmentGroup": route["group"],
            "recommendedAssignee": route["queue"],
            "currentCategory": current_category,
            "currentAssignee": current_assignee,
            "analysis": analysis,
            "actions": actions,
        }
    )


def determine_route(description, current_category):
    route_rules = [
        {
            "keywords": [
                "format",
                "reformat",
                "rebuild",
                "reimage",
                "image laptop",
                "asset handover",
                "asset preparation",
                "laptop",
                "desktop",
                "endpoint",
                "device health",
                "slow device",
                "slow laptop",
                "operating system",
                "os install",
                "os installation",
                "software installation",
                "application installation",
            ],
            "category": "Endpoint Support",
            "group": "Desktop Support Team",
            "queue": "Desktop Support Queue",
            "score": 95,
        },
        {
            "keywords": [
                "office application",
                "office applications",
                "office 365",
                "microsoft 365",
                "m365",
                "o365",
                "word installation",
                "excel installation",
                "powerpoint installation",
            ],
            "category": "Office 365",
            "group": "Microsoft 365 Support Team",
            "queue": "Microsoft 365 Support Queue",
            "score": 94,
        },
        {
            "keywords": [
                "shared mailbox",
                "mailbox",
                "email",
                "outlook",
                "distribution list",
                "mail delivery",
            ],
            "category": "Email",
            "group": "Messaging Support Team",
            "queue": "Messaging Support Queue",
            "score": 93,
        },
        {
            "keywords": [
                "vpn",
                "network",
                "connectivity",
                "wifi",
                "wi-fi",
                "internet",
                "dns",
                "proxy",
                "disconnect",
            ],
            "category": "Networking",
            "group": "Network Operations Team",
            "queue": "Network Operations Queue",
            "score": 93,
        },
        {
            "keywords": [
                "password reset",
                "unable to access",
                "access denied",
                "login",
                "sign in",
                "authentication",
                "authorization",
                "project application access",
            ],
            "category": "Access",
            "group": "Identity and Access Team",
            "queue": "Identity and Access Queue",
            "score": 92,
        },
        {
            "keywords": [
                "hard disk",
                "ssd",
                "keyboard",
                "mouse",
                "monitor",
                "battery",
                "motherboard",
                "physical damage",
                "hardware failure",
            ],
            "category": "Hardware",
            "group": "Hardware Support Team",
            "queue": "Hardware Support Queue",
            "score": 91,
        },
    ]

    for rule in route_rules:
        if any(
            keyword in description
            for keyword in rule["keywords"]
        ):
            return deepcopy(rule)

    return {
        "category": current_category or "General Support",
        "group": "Current Assignment Group",
        "queue": "Current Support Queue",
        "score": 80,
    }


def create_routing_actions(
    ticket_no,
    current_category,
    current_assignee,
    route,
):
    source_lead = create_current_team_lead_name(
        current_category
    )
    destination_lead = (
        f"{route['group']} Lead"
    )

    return [
        {
            "id": "ACT001",
            "type": "RECATEGORIZE",
            "title": "Recategorize Ticket",
            "description": (
                f"Change the category from "
                f"{current_category or 'Not Set'} to "
                f"{route['category']}."
            ),
            "targetCategory": route["category"],
        },
        {
            "id": "ACT002",
            "type": "REASSIGN",
            "title": "Reassign Ticket",
            "description": (
                f"Route the ticket to {route['group']}."
            ),
            "targetGroup": route["group"],
            "targetAssignee": route["queue"],
        },
        {
            "id": "ACT003",
            "type": "ADD_WORK_NOTE",
            "title": "Add Routing Correction Work Note",
            "description": (
                "Document why the ticket was recategorized "
                "and reassigned."
            ),
            "note": (
                f"AI review detected a category mismatch. "
                f"The ticket description aligns with "
                f"{route['category']} rather than "
                f"{current_category or 'the current category'}. "
                f"The ticket was routed from "
                f"{current_assignee or 'the current assignee'} "
                f"to {route['group']}."
            ),
        },
        {
            "id": "ACT004",
            "type": "NOTIFY",
            "title": "Notify Source and Receiving Team Leads",
            "description": (
                "Notify both team leads about the routing correction."
            ),
            "recipients": [
                source_lead,
                destination_lead,
            ],
            "subject": (
                f"Ticket {ticket_no} recategorization notification"
            ),
            "message": (
                f"Ticket {ticket_no} was identified as a category "
                f"mismatch. The recommended category is "
                f"{route['category']} and the receiving group is "
                f"{route['group']}."
            ),
        },
    ]


def build_summary(
    category_mismatch,
    current_category,
    route,
    health_status,
    sla_percent,
):
    if category_mismatch:
        return (
            f"The ticket appears to be incorrectly categorized "
            f"under {current_category or 'the current category'}. "
            f"The recommended ownership is {route['category']} "
            f"with {route['group']}."
        )

    if numeric_value(sla_percent) >= 90:
        return (
            f"The current routing appears suitable, but the ticket "
            f"requires immediate SLA attention at {sla_percent}% "
            f"consumption."
        )

    if health_status in {"AT_RISK", "CRITICAL"}:
        return (
            "The current routing appears suitable, but the ticket "
            "requires operational attention based on its health "
            "findings and lifecycle evidence."
        )

    return (
        "The ticket category and assignment appear suitable. "
        "Continue investigation and maintain complete work notes."
    )


def build_reasoning(
    description,
    current_category,
    route,
    category_mismatch,
    sla_percent,
    findings,
    events,
    current_level,
    current_status,
):
    reasons = []

    if category_mismatch:
        reasons.append(
            f"The description indicates a "
            f"{route['category']} request, while the current "
            f"category is {current_category or 'not set'}."
        )
    else:
        reasons.append(
            "The description is reasonably aligned with the "
            "current ticket category."
        )

    if findings:
        reasons.append(
            f"The health scan identified {len(findings)} "
            f"finding(s) requiring review."
        )

    if numeric_value(sla_percent) >= 100:
        reasons.append(
            f"The ticket has exceeded its SLA at "
            f"{sla_percent}% consumption."
        )
    elif numeric_value(sla_percent) >= 90:
        reasons.append(
            f"The ticket is approaching its SLA limit at "
            f"{sla_percent}% consumption."
        )
    else:
        reasons.append(
            f"The ticket is currently at {sla_percent}% "
            f"SLA consumption."
        )

    if events:
        reasons.append(
            f"{len(events)} lifecycle event(s) were reviewed "
            "to understand the actions completed so far."
        )

    if current_level or current_status:
        reasons.append(
            f"The current state is "
            f"{current_status or 'unknown'} at "
            f"{current_level or 'an unspecified support level'}."
        )

    if description:
        reasons.append(
            "The recommendation was generated from the ticket "
            "description, current routing, SLA position, findings "
            "and available lifecycle evidence."
        )

    return " ".join(reasons)


def calculate_confidence(
    route_score,
    category_mismatch,
    high_risk_count,
    description,
):
    confidence = numeric_value(route_score)

    if not description.strip():
        confidence -= 15

    if category_mismatch:
        confidence += 1

    if high_risk_count:
        confidence += min(high_risk_count, 3)

    return max(
        70,
        min(int(confidence), 98),
    )


def calculate_risk_score(
    health_status,
    sla_percent,
    findings,
    health_checks,
):
    score = 1

    if health_status == "WATCH":
        score += 1
    elif health_status == "AT_RISK":
        score += 3
    elif health_status == "CRITICAL":
        score += 5

    sla_value = numeric_value(sla_percent)

    if sla_value >= 100:
        score += 4
    elif sla_value >= 90:
        score += 3
    elif sla_value >= 75:
        score += 1

    for finding in findings:
        severity = str(
            finding.get("severity", "")
        ).upper()

        if severity == "CRITICAL":
            score += 3
        elif severity == "HIGH":
            score += 2
        elif severity == "MEDIUM":
            score += 1

    for value in health_checks.values():
        normalized_value = str(value).upper()

        if normalized_value == "FAIL":
            score += 2
        elif normalized_value == "WARNING":
            score += 1

    return min(score, 10)


def check_failed(health_checks, check_name):
    value = str(
        health_checks.get(check_name, "")
    ).upper()

    return value in {
        "FAIL",
        "WARNING",
    }


def create_current_team_lead_name(category):
    category_name = str(category).strip()

    if not category_name:
        return "Current Team Lead"

    return f"{category_name} Team Lead"


def next_action_id(actions):
    return f"ACT{len(actions) + 1:03d}"


def numeric_value(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0