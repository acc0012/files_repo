from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field

from app.services.ai_agent import generate_recommendation
from app.services.monitor import start_scan, state
from app.services.repository import repository


app = FastAPI(title="Ticket Health Command Center")

app.mount(
    "/static",
    StaticFiles(directory="app/static"),
    name="static",
)

templates = Jinja2Templates(directory="app/templates")


class Interval(BaseModel):
    intervalHours: int


class ApplyActionsRequest(BaseModel):
    actionIds: list[str] | None = None
    approvedBy: str = Field(
        default="User",
        min_length=1,
        max_length=100,
    )


class RejectRecommendationRequest(BaseModel):
    reason: str | None = Field(
        default=None,
        max_length=500,
    )
    rejectedBy: str = Field(
        default="User",
        min_length=1,
        max_length=100,
    )


def get_ticket_or_404(ticket_no: str):
    result = repository.get_ticket(ticket_no)

    if result is None:
        raise HTTPException(
            status_code=404,
            detail="Ticket not found",
        )

    return result


def context(request: Request, page: str = "dashboard"):
    tickets = repository.list_tickets()

    return {
        "request": request,
        "page": page,
        "tickets": tickets,
        "pending": repository.list_pending(),
        "resolved": repository.list_resolved(),
        "runs": repository.list_runs(),
        "monitor": state,
        "stats": {
            "monitored": 12486,
            "healthy": 9842,
            "attention": 1937,
            "critical": 707,
            "pending": 2384,
            "resolved": 8916,
            "risk": 428,
            "violated": 183,
        },
    }


@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request):
    return templates.TemplateResponse(
        "index.html",
        context(request),
    )


@app.get("/page/{page}", response_class=HTMLResponse)
def page(request: Request, page: str):
    return templates.TemplateResponse(
        "index.html",
        context(request, page),
    )


@app.get("/api/tickets")
def tickets(
    status: str | None = None,
    health: str | None = None,
    q: str | None = None,
):
    return repository.list_tickets(
        status=status,
        health=health,
        query=q,
    )


@app.get("/api/tickets/{ticket_no}")
def ticket(ticket_no: str):
    return get_ticket_or_404(ticket_no)


@app.get("/api/tickets/{ticket_no}/ai-recommendation")
def get_ai_recommendation(ticket_no: str):
    ticket_data = get_ticket_or_404(ticket_no)

    existing_recommendation = repository.get_ai_recommendation(
        ticket_no
    )

    if existing_recommendation is not None:
        return existing_recommendation

    generated_recommendation = generate_recommendation(
        ticket_data
    )

    saved_recommendation = repository.save_ai_recommendation(
        ticket_no,
        generated_recommendation,
    )

    if saved_recommendation is None:
        raise HTTPException(
            status_code=500,
            detail="Unable to save AI recommendation",
        )

    return saved_recommendation


@app.post("/api/tickets/{ticket_no}/ai-recommendation/generate")
def regenerate_ai_recommendation(ticket_no: str):
    ticket_data = get_ticket_or_404(ticket_no)

    generated_recommendation = generate_recommendation(
        ticket_data
    )

    saved_recommendation = repository.save_ai_recommendation(
        ticket_no,
        generated_recommendation,
    )

    if saved_recommendation is None:
        raise HTTPException(
            status_code=500,
            detail="Unable to save AI recommendation",
        )

    return {
        "success": True,
        "message": "AI recommendation generated.",
        "recommendation": saved_recommendation,
    }


@app.get("/api/tickets/{ticket_no}/ai-actions/history")
def ai_action_history(ticket_no: str):
    get_ticket_or_404(ticket_no)

    return {
        "ticketNo": ticket_no,
        "history": repository.list_ai_action_history(
            ticket_no
        ),
    }


@app.post("/api/tickets/{ticket_no}/ai-actions/apply")
def apply_ai_actions(
    ticket_no: str,
    payload: ApplyActionsRequest,
):
    get_ticket_or_404(ticket_no)

    if payload.actionIds is not None and not payload.actionIds:
        raise HTTPException(
            status_code=400,
            detail="Select at least one recommended action",
        )

    recommendation = repository.get_ai_recommendation(
        ticket_no
    )

    if recommendation is None:
        ticket_data = repository.get_ticket(ticket_no)

        generated_recommendation = generate_recommendation(
            ticket_data
        )

        repository.save_ai_recommendation(
            ticket_no,
            generated_recommendation,
        )

    result = repository.apply_ai_actions(
        ticket_no=ticket_no,
        action_ids=payload.actionIds,
        approved_by=payload.approvedBy.strip(),
    )

    if result is None:
        raise HTTPException(
            status_code=500,
            detail="Unable to apply AI actions",
        )

    if not result.get("success") and not result.get("results"):
        raise HTTPException(
            status_code=400,
            detail=result.get(
                "message",
                "No AI actions were applied",
            ),
        )

    return result


@app.post("/api/tickets/{ticket_no}/ai-actions/reject")
def reject_ai_recommendation(
    ticket_no: str,
    payload: RejectRecommendationRequest,
):
    get_ticket_or_404(ticket_no)

    recommendation = repository.get_ai_recommendation(
        ticket_no
    )

    if recommendation is None:
        raise HTTPException(
            status_code=404,
            detail="AI recommendation not found",
        )

    reason = payload.reason.strip() if payload.reason else None

    result = repository.reject_ai_recommendation(
        ticket_no=ticket_no,
        reason=reason,
        rejected_by=payload.rejectedBy.strip(),
    )

    if result is None:
        raise HTTPException(
            status_code=500,
            detail="Unable to reject AI recommendation",
        )

    return result


@app.post("/api/tickets/{ticket_no}/reset-demo")
def reset_demo(ticket_no: str):
    get_ticket_or_404(ticket_no)

    restored_ticket = repository.reset_ticket_demo(
        ticket_no
    )

    if restored_ticket is None:
        raise HTTPException(
            status_code=500,
            detail="Unable to restore ticket demo state",
        )

    return {
        "success": True,
        "message": "Ticket demo state restored.",
        "ticket": restored_ticket,
    }


@app.get("/api/monitor")
def monitor():
    return state


@app.post("/api/monitor/run")
def run():
    return start_scan()


@app.post("/api/monitor/interval")
def interval(payload: Interval):
    supported_intervals = [1, 3, 6, 12, 24]

    if payload.intervalHours not in supported_intervals:
        raise HTTPException(
            status_code=400,
            detail="Unsupported interval",
        )

    state["intervalHours"] = payload.intervalHours

    return state