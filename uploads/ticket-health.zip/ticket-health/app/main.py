import json
import re
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field

from app.services.ai_agent import generate_recommendation
from app.services.monitor import start_scan, state
from app.services.repository import repository


app = FastAPI(title="Ticket Health Command Center")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost",
        "http://127.0.0.1",
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "https://nextgenghd.ultimatix.net",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount(
    "/static",
    StaticFiles(directory="app/static"),
    name="static",
)

templates = Jinja2Templates(directory="app/templates")

DATA_DIRECTORY = Path(
    r"C:\Users\2854348\Documents\GHD-AUTOMATION"
    r"\ticket-health\app\data"
)

SAFE_FILENAME_PATTERN = re.compile(
    r"^[A-Za-z0-9][A-Za-z0-9._-]{0,199}$"
)

WINDOWS_RESERVED_FILENAMES = {
    "CON",
    "PRN",
    "AUX",
    "NUL",
    "COM1",
    "COM2",
    "COM3",
    "COM4",
    "COM5",
    "COM6",
    "COM7",
    "COM8",
    "COM9",
    "LPT1",
    "LPT2",
    "LPT3",
    "LPT4",
    "LPT5",
    "LPT6",
    "LPT7",
    "LPT8",
    "LPT9",
}

json_file_lock = threading.Lock()


class Interval(BaseModel):
    intervalHours: int


class ApplyActionsRequest(BaseModel):
    actionIds: list[str] | None = None
    approvedBy: str = Field(
        default="User",
        min_length=1,
        max_length=100,
    )


class RejectRecommendationRequest(BaseModel):
    reason: str | None = Field(
        default=None,
        max_length=500,
    )
    rejectedBy: str = Field(
        default="User",
        min_length=1,
        max_length=100,
    )


class SaveJsonRequest(BaseModel):
    filename: str = Field(
        min_length=1,
        max_length=200,
    )
    content: Any


def get_ticket_or_404(ticket_no: str):
    result = repository.get_ticket(ticket_no)

    if result is None:
        raise HTTPException(
            status_code=404,
            detail="Ticket not found",
        )

    return result


def validate_json_filename(filename: str) -> str:
    cleaned_filename = filename.strip()

    if not cleaned_filename:
        raise HTTPException(
            status_code=400,
            detail="Filename is required",
        )

    if not SAFE_FILENAME_PATTERN.fullmatch(cleaned_filename):
        raise HTTPException(
            status_code=400,
            detail=(
                "Filename may contain only letters, numbers, "
                "dots, hyphens, and underscores"
            ),
        )

    if Path(cleaned_filename).name != cleaned_filename:
        raise HTTPException(
            status_code=400,
            detail="Directory paths are not allowed",
        )

    if not cleaned_filename.lower().endswith(".json"):
        cleaned_filename = f"{cleaned_filename}.json"

    if Path(cleaned_filename).stem.upper() in WINDOWS_RESERVED_FILENAMES:
        raise HTTPException(
            status_code=400,
            detail="Reserved Windows filename is not allowed",
        )

    return cleaned_filename


def get_safe_target_path(filename: str) -> Path:
    DATA_DIRECTORY.mkdir(
        parents=True,
        exist_ok=True,
    )

    data_directory = DATA_DIRECTORY.resolve()
    target_path = (data_directory / filename).resolve()

    try:
        target_path.relative_to(data_directory)
    except ValueError as error:
        raise HTTPException(
            status_code=400,
            detail="Invalid destination path",
        ) from error

    return target_path


def read_existing_json_items(target_path: Path) -> list:
    if not target_path.exists():
        return []

    try:
        with target_path.open(
            mode="r",
            encoding="utf-8",
        ) as file:
            existing_content = json.load(file)
    except json.JSONDecodeError as error:
        raise HTTPException(
            status_code=409,
            detail=(
                "The existing JSON file contains invalid JSON "
                "and cannot be appended"
            ),
        ) from error
    except OSError as error:
        raise HTTPException(
            status_code=500,
            detail=f"Unable to read existing JSON file: {error}",
        ) from error

    if isinstance(existing_content, list):
        return existing_content

    return [existing_content]


def append_json_content(
    target_path: Path,
    content: Any,
) -> int:
    temporary_path = target_path.with_name(
        f"{target_path.name}.{uuid.uuid4().hex}.tmp"
    )

    with json_file_lock:
        existing_items = read_existing_json_items(
            target_path
        )

        if isinstance(content, list):
            existing_items.extend(content)
        else:
            existing_items.append(content)

        try:
            with temporary_path.open(
                mode="w",
                encoding="utf-8",
            ) as file:
                json.dump(
                    existing_items,
                    file,
                    ensure_ascii=False,
                    indent=2,
                )
                file.write("\n")

            temporary_path.replace(target_path)
        except (OSError, TypeError, ValueError) as error:
            try:
                temporary_path.unlink(missing_ok=True)
            except OSError:
                pass

            raise HTTPException(
                status_code=500,
                detail=f"Unable to append JSON content: {error}",
            ) from error

    return len(existing_items)


def context(request: Request, page: str = "dashboard"):
    tickets = repository.list_tickets()

    return {
        "request": request,
        "page": page,
        "tickets": tickets,
        "pending": repository.list_pending(),
        "resolved": repository.list_resolved(),
        "runs": repository.list_runs(),
        "monitor": state,
        "stats": {
            "monitored": 12486,
            "healthy": 9842,
            "attention": 1937,
            "critical": 707,
            "pending": 2384,
            "resolved": 8916,
            "risk": 428,
            "violated": 183,
        },
    }


@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request):
    return templates.TemplateResponse(
        "index.html",
        context(request),
    )


@app.get("/page/{page}", response_class=HTMLResponse)
def page(request: Request, page: str):
    return templates.TemplateResponse(
        "index.html",
        context(request, page),
    )


@app.get("/api/health")
def health():
    return {
        "status": "running",
        "application": app.title,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


@app.get("/api/tickets")
def tickets(
    status: str | None = None,
    health: str | None = None,
    q: str | None = None,
):
    return repository.list_tickets(
        status=status,
        health=health,
        query=q,
    )


@app.get("/api/tickets/{ticket_no}")
def ticket(ticket_no: str):
    return get_ticket_or_404(ticket_no)


@app.get("/api/tickets/{ticket_no}/ai-recommendation")
def get_ai_recommendation(ticket_no: str):
    ticket_data = get_ticket_or_404(ticket_no)

    existing_recommendation = repository.get_ai_recommendation(
        ticket_no
    )

    if existing_recommendation is not None:
        return existing_recommendation

    generated_recommendation = generate_recommendation(
        ticket_data
    )

    saved_recommendation = repository.save_ai_recommendation(
        ticket_no,
        generated_recommendation,
    )

    if saved_recommendation is None:
        raise HTTPException(
            status_code=500,
            detail="Unable to save AI recommendation",
        )

    return saved_recommendation


@app.post("/api/tickets/{ticket_no}/ai-recommendation/generate")
def regenerate_ai_recommendation(ticket_no: str):
    ticket_data = get_ticket_or_404(ticket_no)

    generated_recommendation = generate_recommendation(
        ticket_data
    )

    saved_recommendation = repository.save_ai_recommendation(
        ticket_no,
        generated_recommendation,
    )

    if saved_recommendation is None:
        raise HTTPException(
            status_code=500,
            detail="Unable to save AI recommendation",
        )

    return {
        "success": True,
        "message": "AI recommendation generated.",
        "recommendation": saved_recommendation,
    }


@app.get("/api/tickets/{ticket_no}/ai-actions/history")
def ai_action_history(ticket_no: str):
    get_ticket_or_404(ticket_no)

    return {
        "ticketNo": ticket_no,
        "history": repository.list_ai_action_history(
            ticket_no
        ),
    }


@app.post("/api/tickets/{ticket_no}/ai-actions/apply")
def apply_ai_actions(
    ticket_no: str,
    payload: ApplyActionsRequest,
):
    get_ticket_or_404(ticket_no)

    if payload.actionIds is not None and not payload.actionIds:
        raise HTTPException(
            status_code=400,
            detail="Select at least one recommended action",
        )

    recommendation = repository.get_ai_recommendation(
        ticket_no
    )

    if recommendation is None:
        ticket_data = repository.get_ticket(ticket_no)

        generated_recommendation = generate_recommendation(
            ticket_data
        )

        repository.save_ai_recommendation(
            ticket_no,
            generated_recommendation,
        )

    result = repository.apply_ai_actions(
        ticket_no=ticket_no,
        action_ids=payload.actionIds,
        approved_by=payload.approvedBy.strip(),
    )

    if result is None:
        raise HTTPException(
            status_code=500,
            detail="Unable to apply AI actions",
        )

    if not result.get("success") and not result.get("results"):
        raise HTTPException(
            status_code=400,
            detail=result.get(
                "message",
                "No AI actions were applied",
            ),
        )

    return result


@app.post("/api/tickets/{ticket_no}/ai-actions/reject")
def reject_ai_recommendation(
    ticket_no: str,
    payload: RejectRecommendationRequest,
):
    get_ticket_or_404(ticket_no)

    recommendation = repository.get_ai_recommendation(
        ticket_no
    )

    if recommendation is None:
        raise HTTPException(
            status_code=404,
            detail="AI recommendation not found",
        )

    reason = payload.reason.strip() if payload.reason else None

    result = repository.reject_ai_recommendation(
        ticket_no=ticket_no,
        reason=reason,
        rejected_by=payload.rejectedBy.strip(),
    )

    if result is None:
        raise HTTPException(
            status_code=500,
            detail="Unable to reject AI recommendation",
        )

    return result


@app.post("/api/tickets/{ticket_no}/reset-demo")
def reset_demo(ticket_no: str):
    get_ticket_or_404(ticket_no)

    restored_ticket = repository.reset_ticket_demo(
        ticket_no
    )

    if restored_ticket is None:
        raise HTTPException(
            status_code=500,
            detail="Unable to restore ticket demo state",
        )

    return {
        "success": True,
        "message": "Ticket demo state restored.",
        "ticket": restored_ticket,
    }


@app.post(
    "/api/files/save-json",
    status_code=status.HTTP_201_CREATED,
)
def save_json(payload: SaveJsonRequest):
    filename = validate_json_filename(
        payload.filename
    )

    target_path = get_safe_target_path(
        filename
    )

    total_items = append_json_content(
        target_path=target_path,
        content=payload.content,
    )

    return {
        "success": True,
        "message": "JSON content appended successfully.",
        "filename": target_path.name,
        "path": str(target_path),
        "totalItems": total_items,
        "savedAt": datetime.now(timezone.utc).isoformat(),
    }


@app.get("/api/monitor")
def monitor():
    return state


@app.post("/api/monitor/run")
def run():
    return start_scan()


@app.post("/api/monitor/interval")
def interval(payload: Interval):
    supported_intervals = [1, 3, 6, 12, 24]

    if payload.intervalHours not in supported_intervals:
        raise HTTPException(
            status_code=400,
            detail="Unsupported interval",
        )

    state["intervalHours"] = payload.intervalHours

    return state