const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => document.querySelectorAll(selector);

let poll;
let activeTicketNo = null;
let aiActionInProgress = false;

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function formatHealthStatus(value) {
  return String(value || "N/A").replaceAll("_", " ");
}

function badgeClass(value) {
  return String(value || "n/a")
    .toLowerCase()
    .replaceAll(" ", "_");
}

function formatDateTime(value) {
  if (!value) {
    return "";
  }

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return escapeHtml(value);
  }

  return date.toLocaleString();
}

async function requestJson(url, options = {}) {
  const response = await fetch(url, options);
  let data = null;

  try {
    data = await response.json();
  } catch {
    data = null;
  }

  if (!response.ok) {
    const message =
      data?.detail ||
      data?.message ||
      `Request failed with status ${response.status}`;

    throw new Error(message);
  }

  return data;
}

function initializeCharts() {
  const healthChart = $("#healthChart");
  const slaChart = $("#slaChart");

  if (healthChart && typeof Chart !== "undefined") {
    new Chart(healthChart, {
      type: "doughnut",
      data: {
        labels: ["Healthy", "Watch", "At Risk", "Critical"],
        datasets: [
          {
            data: [9842, 1937, 420, 287],
            backgroundColor: ["#16875b", "#e9a820", "#d95812", "#c73535"],
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: "bottom",
          },
        },
      },
    });
  }

  if (slaChart && typeof Chart !== "undefined") {
    new Chart(slaChart, {
      type: "bar",
      data: {
        labels: ["<50%", "50-75%", "75-90%", "90-100%", ">100%"],
        datasets: [
          {
            label: "Tickets",
            data: [4820, 3910, 3145, 428, 183],
            backgroundColor: [
              "#4a8de4",
              "#6fa6ec",
              "#e9a820",
              "#d95812",
              "#c73535",
            ],
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,
          },
        },
      },
    });
  }
}

function renderHealthChecks(healthChecks = {}) {
  const entries = Object.entries(healthChecks);

  if (!entries.length) {
    return "<p>No health checklist information available.</p>";
  }

  return entries
    .map(
      ([name, value]) => `
            <div class="check">
                <span>${escapeHtml(name)}</span>
                <span class="badge ${badgeClass(value)}">
                    ${escapeHtml(value)}
                </span>
            </div>
        `,
    )
    .join("");
}

function renderFindings(findings = []) {
  if (!findings.length) {
    return `
            <div class="finding">
                <b>No material exceptions detected</b>
                <p>
                    Ticket handling evidence is consistent with
                    the expected process.
                </p>
            </div>
        `;
  }

  return findings
    .map(
      (finding) => `
            <div class="finding ${escapeHtml(finding.severity || "")}">
                <b>${escapeHtml(finding.title || "Finding")}</b>
                <small>
                    ${escapeHtml(finding.category || "General")}
                    ·
                    ${escapeHtml(finding.severity || "INFO")}
                </small>
                <p>${escapeHtml(finding.description || "")}</p>
            </div>
        `,
    )
    .join("");
}

function renderLifecycleEvents(events = []) {
  if (!events.length) {
    return "<p>No detailed lifecycle trace loaded.</p>";
  }

  return events
    .map(
      (event) => `
            <div class="event">
                <b>${escapeHtml(event.action || "Activity")}</b>
                <small>
                    ${escapeHtml(event.time || "")}
                    ·
                    ${escapeHtml(event.actor || "Unknown")}
                    ·
                    ${escapeHtml(event.level || "")}
                </small>
                <p>${escapeHtml(event.remarks || "")}</p>
            </div>
        `,
    )
    .join("");
}

function renderResolution(ticket) {
  if (!ticket.resolution) {
    return "";
  }

  const quality =
    ticket.resolutionQuality === null || ticket.resolutionQuality === undefined
      ? "N/A"
      : `${ticket.resolutionQuality}%`;

  return `
        <h3>Resolution Analysis</h3>
        <div class="finding">
            <b>${escapeHtml(quality)} quality</b>
            <p>${escapeHtml(ticket.resolution)}</p>
        </div>
    `;
}

function renderTicketReport(ticket) {
  const healthChecks = renderHealthChecks(ticket.healthChecks || {});
  const findings = renderFindings(ticket.findings || []);
  const events = renderLifecycleEvents(ticket.events || []);
  const resolution = renderResolution(ticket);
  const healthStatus = formatHealthStatus(ticket.healthStatus);

  return `
        <div class="detail-head">
            <small>TICKET HEALTH REPORT</small>
            <h2>Ticket #${escapeHtml(ticket.ticketNo)}</h2>
            <span class="badge ${badgeClass(ticket.healthStatus)}">
                ${escapeHtml(healthStatus)}
                ·
                ${escapeHtml(ticket.healthScore)}/100
            </span>
            <p>${escapeHtml(ticket.description)}</p>
        </div>

        <div class="detail-grid">
            <div class="detail-card">
                <small>Status</small>
                <b>${escapeHtml(ticket.status || "-")}</b>
            </div>

            <div class="detail-card">
                <small>Priority</small>
                <b>${escapeHtml(ticket.priority || "-")}</b>
            </div>

            <div class="detail-card">
                <small>Category</small>
                <b>${escapeHtml(ticket.item || "-")}</b>
            </div>

            <div class="detail-card">
                <small>SLA</small>
                <b>${escapeHtml(ticket.slaPercent)}%</b>
            </div>

            <div class="detail-card">
                <small>Age</small>
                <b>${escapeHtml(ticket.agingDays)} days</b>
            </div>
        </div>

        <h3>
            Why is this ticket
            ${escapeHtml(healthStatus.toLowerCase())}?
        </h3>

        ${findings}

        <h3>Health Checklist</h3>
        <div class="check-grid">
            ${healthChecks}
        </div>

        <h3>Lifecycle Timeline</h3>
        <div class="timeline">
            ${events}
        </div>

        ${resolution}

        <div id="aiAgentSection">
            <div class="ai-panel">
                <div class="ai-processing">
                    <span class="ai-spinner"></span>
                    <span>Analyzing ticket and preparing recommendation...</span>
                </div>
            </div>
        </div>

        <button type="button">
            View Full Health Report
        </button>
    `;
}

async function openTicket(ticketNo) {
  activeTicketNo = String(ticketNo);

  try {
    const ticket = await requestJson(
      `/api/tickets/${encodeURIComponent(ticketNo)}`,
    );

    const drawerContent = $("#drawerContent");

    if (!drawerContent) {
      return;
    }

    drawerContent.innerHTML = renderTicketReport(ticket);

    $("#overlay")?.classList.remove("hidden");
    $("#drawer")?.classList.add("open");

    await loadAIRecommendation(ticket.ticketNo);
  } catch (error) {
    showToast(error.message || "Unable to load ticket details.", "error");
  }
}

function closeDrawer() {
  $("#overlay")?.classList.add("hidden");
  $("#drawer")?.classList.remove("open");
  activeTicketNo = null;
}

function filterTickets() {
  const query = ($("#tableSearch")?.value || "").trim().toLowerCase();

  const health = $("#healthFilter")?.value || "";

  $$("#ticketTable tbody tr").forEach((row) => {
    const matchesQuery = !query || row.innerText.toLowerCase().includes(query);

    const matchesHealth = !health || row.dataset.health === health;

    row.style.display = matchesQuery && matchesHealth ? "" : "none";
  });
}

function showToast(message, type = "success") {
  let container = $("#toastContainer");

  if (!container) {
    container = document.createElement("div");
    container.id = "toastContainer";
    container.className = "toast-container";
    document.body.appendChild(container);
  }

  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.textContent = message;

  container.appendChild(toast);

  window.setTimeout(() => {
    toast.classList.add("show");
  }, 50);

  window.setTimeout(() => {
    toast.classList.remove("show");

    window.setTimeout(() => {
      toast.remove();
    }, 400);
  }, 4000);
}

async function loadAIRecommendation(ticketNo) {
  const container = $("#aiAgentSection");

  if (!container) {
    return;
  }

  container.innerHTML = `
        <div class="ai-panel">
            <div class="ai-processing">
                <span class="ai-spinner"></span>
                <span>Analyzing ticket and preparing recommendation...</span>
            </div>
        </div>
    `;

  try {
    const recommendation = await requestJson(
      `/api/tickets/${encodeURIComponent(ticketNo)}/ai-recommendation`,
    );

    if (activeTicketNo !== String(ticketNo)) {
      return;
    }

    renderAIRecommendation(recommendation);
  } catch (error) {
    container.innerHTML = `
            <div class="ai-panel">
                <div class="ai-status rejected">
                    ${escapeHtml(
                      error.message || "Failed to load AI recommendation.",
                    )}
                </div>
            </div>
        `;

    showToast(error.message || "Failed to load AI recommendation.", "error");
  }
}

function renderRecommendationStatus(status) {
  if (!status) {
    return "";
  }

  const normalizedStatus = String(status).toLowerCase();
  let statusClass = "pending";

  if (
    normalizedStatus === "applied" ||
    normalizedStatus === "partially_applied"
  ) {
    statusClass = "applied";
  } else if (normalizedStatus === "rejected" || normalizedStatus === "failed") {
    statusClass = "rejected";
  }

  return `
        <div class="ai-status ${statusClass}">
            Recommendation status:
            ${escapeHtml(formatHealthStatus(status))}
        </div>
    `;
}

function renderRecommendationActions(actions = [], disabled = false) {
  if (!actions.length) {
    return `
            <div class="ai-status pending">
                No automated corrective actions are required.
            </div>
        `;
  }

  return actions
    .map(
      (action) => `
            <label class="ai-action">
                <input
                    type="checkbox"
                    class="ai-action-checkbox"
                    value="${escapeHtml(action.id)}"
                    ${disabled ? "disabled" : "checked"}
                >
                <div>
                    <b>${escapeHtml(action.title || "Recommended action")}</b>
                    <p>${escapeHtml(action.description || "")}</p>
                </div>
            </label>
        `,
    )
    .join("");
}

function renderAIRecommendation(ai) {
  const container = $("#aiAgentSection");

  if (!container || !ai) {
    return;
  }

  const status = String(ai.status || "PENDING").toUpperCase();
  const actionsDisabled = ["APPLIED", "PARTIALLY_APPLIED", "REJECTED"].includes(
    status,
  );

  const actions = renderRecommendationActions(
    ai.actions || [],
    actionsDisabled,
  );

  const applyDisabled = actionsDisabled || !(ai.actions || []).length;

  container.innerHTML = `
  <details class="ai-advisor-dropdown">
    <summary class="ai-advisor-summary">
      <div class="ai-advisor-title">
        <span class="ai-advisor-icon">✦</span>

        <div>
          <h3>AI Resolution Advisor</h3>
          <small>
            ${escapeHtml(
              ai.summary || "AI recommendation is available for this ticket.",
            )}
          </small>
        </div>
      </div>

      <div class="ai-advisor-meta">
        <span class="ai-confidence">
          Confidence ${escapeHtml(ai.confidence ?? 90)}%
        </span>

        <span class="ai-chevron" aria-hidden="true"></span>
      </div>
    </summary>

    <div class="ai-advisor-content">
      ${renderRecommendationStatus(status)}

      <div class="ai-summary">
        ${escapeHtml(ai.summary || "Ticket analysis completed.")}
      </div>

      <div class="ai-reasoning">
        <h4>Reasoning</h4>
        <p>
          ${escapeHtml(
            ai.reasoning || "Recommendation generated from the ticket details.",
          )}
        </p>
      </div>

      <div class="ai-target">
        <h4>Recommended Routing</h4>

        <div class="ai-routing-grid">
          <div class="ai-routing-item">
            <small>Category</small>
            <b>${escapeHtml(ai.recommendedCategory || "-")}</b>
          </div>

          <div class="ai-routing-item">
            <small>Assignment Group</small>
            <b>
              ${escapeHtml(ai.recommendedAssignmentGroup || "-")}
            </b>
          </div>
        </div>
      </div>

      <details class="ai-section-dropdown" open>
        <summary>
          <span>Recommended Actions</span>
          <span class="section-count">
            ${(ai.actions || []).length}
          </span>
        </summary>

        <div class="ai-section-content ai-actions">
          ${actions}
        </div>
      </details>

      <details class="ai-section-dropdown">
        <summary>
          <span>AI Action History</span>
          <span class="ai-chevron" aria-hidden="true"></span>
        </summary>

        <div class="ai-section-content">
          <div id="aiHistory">
            <div class="ai-processing">
              <span class="ai-spinner"></span>
              <span>Loading AI action history...</span>
            </div>
          </div>
        </div>
      </details>

      <div id="aiProcessingState"></div>

      <div class="ai-buttons">
        <button
          type="button"
          class="apply-btn"
          data-ai-action="apply"
          ${applyDisabled ? "disabled" : ""}
        >
          Apply Recommended Actions
        </button>

        <button
          type="button"
          class="secondary-btn"
          data-ai-action="regenerate"
        >
          Regenerate
        </button>

        <button
          type="button"
          class="secondary-btn"
          data-ai-action="reject"
          ${actionsDisabled ? "disabled" : ""}
        >
          Reject
        </button>

        <button
          type="button"
          class="secondary-btn"
          data-ai-action="reset"
        >
          Reset Demo
        </button>
      </div>
    </div>
  </details>
`;

  container
    .querySelector('[data-ai-action="apply"]')
    ?.addEventListener("click", () => {
      applyAIActions(ai.ticketNo);
    });

  container
    .querySelector('[data-ai-action="regenerate"]')
    ?.addEventListener("click", () => {
      regenerateAIRecommendation(ai.ticketNo);
    });

  container
    .querySelector('[data-ai-action="reject"]')
    ?.addEventListener("click", () => {
      rejectAIRecommendation(ai.ticketNo);
    });

  container
    .querySelector('[data-ai-action="reset"]')
    ?.addEventListener("click", () => {
      resetDemo(ai.ticketNo);
    });

  loadAIHistory(ai.ticketNo);
}

function setAIProcessing(message) {
  const target = $("#aiProcessingState");

  if (!target) {
    return;
  }

  if (!message) {
    target.innerHTML = "";
    return;
  }

  target.innerHTML = `
        <div class="ai-processing">
            <span class="ai-spinner"></span>
            <span>${escapeHtml(message)}</span>
        </div>
    `;
}

function setAIButtonsDisabled(disabled) {
  $$("#aiAgentSection button").forEach((button) => {
    button.disabled = disabled;
  });

  $$(".ai-action-checkbox").forEach((checkbox) => {
    checkbox.disabled = disabled;
  });
}

async function applyAIActions(ticketNo) {
  if (aiActionInProgress) {
    return;
  }

  const actionIds = [...$$(".ai-action-checkbox:checked")].map(
    (checkbox) => checkbox.value,
  );

  if (!actionIds.length) {
    showToast("Select at least one recommended action.", "warning");
    return;
  }

  aiActionInProgress = true;
  setAIButtonsDisabled(true);
  setAIProcessing("Applying selected corrective actions...");

  try {
    const result = await requestJson(
      `/api/tickets/${encodeURIComponent(ticketNo)}/ai-actions/apply`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          approvedBy: "Demo User",
          actionIds,
        }),
      },
    );

    if (!result.success && result.status !== "PARTIALLY_APPLIED") {
      throw new Error(result.message || "No AI actions were applied.");
    }

    const toastType =
      result.status === "PARTIALLY_APPLIED" ? "warning" : "success";

    showToast(result.message || "AI actions executed successfully.", toastType);

    await openTicket(ticketNo);
  } catch (error) {
    setAIProcessing("");
    setAIButtonsDisabled(false);

    showToast(error.message || "Failed to execute AI actions.", "error");
  } finally {
    aiActionInProgress = false;
  }
}

async function rejectAIRecommendation(ticketNo) {
  if (aiActionInProgress) {
    return;
  }

  aiActionInProgress = true;
  setAIButtonsDisabled(true);
  setAIProcessing("Rejecting AI recommendation...");

  try {
    const result = await requestJson(
      `/api/tickets/${encodeURIComponent(ticketNo)}/ai-actions/reject`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          rejectedBy: "Demo User",
          reason: "Rejected by user",
        }),
      },
    );

    showToast(result.message || "Recommendation rejected.", "warning");

    await loadAIRecommendation(ticketNo);
  } catch (error) {
    setAIProcessing("");
    setAIButtonsDisabled(false);

    showToast(error.message || "Unable to reject recommendation.", "error");
  } finally {
    aiActionInProgress = false;
  }
}

async function regenerateAIRecommendation(ticketNo) {
  if (aiActionInProgress) {
    return;
  }

  aiActionInProgress = true;
  setAIButtonsDisabled(true);
  setAIProcessing("Regenerating AI recommendation...");

  try {
    const result = await requestJson(
      `/api/tickets/${encodeURIComponent(ticketNo)}/ai-recommendation/generate`,
      {
        method: "POST",
      },
    );

    showToast(result.message || "AI recommendation regenerated.", "success");

    renderAIRecommendation(result.recommendation);
  } catch (error) {
    setAIProcessing("");
    setAIButtonsDisabled(false);

    showToast(error.message || "Regeneration failed.", "error");
  } finally {
    aiActionInProgress = false;
  }
}

async function resetDemo(ticketNo) {
  if (aiActionInProgress) {
    return;
  }

  aiActionInProgress = true;
  setAIButtonsDisabled(true);
  setAIProcessing("Restoring original demo data...");

  try {
    const result = await requestJson(
      `/api/tickets/${encodeURIComponent(ticketNo)}/reset-demo`,
      {
        method: "POST",
      },
    );

    showToast(result.message || "Demo reset completed.", "success");

    await openTicket(ticketNo);
  } catch (error) {
    setAIProcessing("");
    setAIButtonsDisabled(false);

    showToast(error.message || "Reset failed.", "error");
  } finally {
    aiActionInProgress = false;
  }
}

async function loadAIHistory(ticketNo) {
  try {
    const data = await requestJson(
      `/api/tickets/${encodeURIComponent(ticketNo)}/ai-actions/history`,
    );

    const target = $("#aiHistory");

    if (!target) {
      return;
    }

    const history = data.history || [];

    if (!history.length) {
      target.innerHTML = `
                <h4>AI Action History</h4>
                <p>No AI actions have been recorded.</p>
            `;
      return;
    }

    target.innerHTML = `
            <h4>AI Action History</h4>
            ${history
              .map(
                (item) => `
                    <div class="ai-history-item">
                        <b>
                            ${escapeHtml(
                              formatHealthStatus(item.status || "RECORDED"),
                            )}
                        </b>
                        <p>${escapeHtml(item.message || "")}</p>
                        <small>
                            ${formatDateTime(item.createdAt)}
                        </small>
                    </div>
                `,
              )
              .join("")}
        `;
  } catch (error) {
    const target = $("#aiHistory");

    if (target) {
      target.innerHTML = `
                <h4>AI Action History</h4>
                <p>Unable to load AI action history.</p>
            `;
    }
  }
}

function initializeTicketRows() {
  $$("[data-ticket]").forEach((row) => {
    row.addEventListener("click", () => {
      openTicket(row.dataset.ticket);
    });
  });
}

function initializeDrawer() {
  $("#closeDrawer")?.addEventListener("click", closeDrawer);

  $("#overlay")?.addEventListener("click", closeDrawer);

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      closeDrawer();
    }
  });
}

function initializeFilters() {
  $("#tableSearch")?.addEventListener("input", filterTickets);

  $("#healthFilter")?.addEventListener("change", filterTickets);

  $("#globalSearch")?.addEventListener("keydown", (event) => {
    if (event.key !== "Enter") {
      return;
    }

    const query = event.target.value.trim();

    if (!query) {
      return;
    }

    const row = [...$$("[data-ticket]")].find((item) =>
      item.innerText.toLowerCase().includes(query.toLowerCase()),
    );

    if (row) {
      openTicket(row.dataset.ticket);
      return;
    }

    window.location.href = `/page/ticket-health?q=${encodeURIComponent(query)}`;
  });
}

function initializeMonitoring() {
  const interval = $("#interval");
  const scanButton = $("#scanBtn");

  if (interval) {
    interval.value = "6";

    interval.addEventListener("change", async (event) => {
      try {
        await requestJson("/api/monitor/interval", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            intervalHours: Number(event.target.value),
          }),
        });

        showToast(
          `Monitoring interval updated to ${event.target.value} hours.`,
          "info",
        );
      } catch (error) {
        showToast(error.message || "Unable to update interval.", "error");
      }
    });
  }

  if (!scanButton) {
    return;
  }

  scanButton.addEventListener("click", async () => {
    try {
      await requestJson("/api/monitor/run", {
        method: "POST",
      });

      $("#scanBanner")?.classList.remove("hidden");

      if (poll) {
        window.clearInterval(poll);
      }

      poll = window.setInterval(async () => {
        try {
          const scanState = await requestJson("/api/monitor");

          if ($("#scanStage")) {
            $("#scanStage").textContent = scanState.stage;
          }

          if ($("#scanProgress")) {
            $("#scanProgress").style.width = `${scanState.progress}%`;
          }

          if ($("#scanPct")) {
            $("#scanPct").textContent = `${scanState.progress}%`;
          }

          if (!scanState.isRunning && scanState.progress === 100) {
            window.clearInterval(poll);
            poll = null;

            window.setTimeout(() => {
              $("#scanBanner")?.classList.add("hidden");
            }, 1800);

            showToast("Ticket health scan completed.", "success");
          }
        } catch (error) {
          window.clearInterval(poll);
          poll = null;

          $("#scanBanner")?.classList.add("hidden");

          showToast(error.message || "Unable to read scan progress.", "error");
        }
      }, 350);
    } catch (error) {
      showToast(error.message || "Unable to start health scan.", "error");
    }
  });
}

function initializeApplication() {
  initializeCharts();
  initializeTicketRows();
  initializeDrawer();
  initializeFilters();
  initializeMonitoring();
}

initializeApplication();
