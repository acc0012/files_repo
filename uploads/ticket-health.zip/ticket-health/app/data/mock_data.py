from pathlib import Path
import json

DATA_FILE = Path(__file__).with_name("mock_data.json")


def load_mock_data():
    """Load prototype ticket data from JSON.

    This function intentionally returns ordinary Python dictionaries and lists.
    A future database repository can expose the same public methods without
    requiring changes to routes, templates, or monitoring logic.
    """
    with DATA_FILE.open("r", encoding="utf-8") as file:
        return json.load(file)
