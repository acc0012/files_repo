const processAllTickets = async () => {
  "use strict";

  const CONFIG = {
    baseUrl:
      "https://nextgenghd.ultimatix.net/NextGenGHDIncidentService/rest",
    levels: [
      { levelId: 489, levelName: "L 1.5 - GHD" },
      { levelId: 405, levelName: "Level 405" },
      { levelId: 399, levelName: "Level 399" }
    ],
    ticketsPerLevelBatch: 3,
    batchDelayMs: 2000,
    requestTimeoutMs: 30000,
    retryCount: 2,
    retryDelayMs: 3000,
    includeResolutionDetails: true,
    includeAllTicketDetails: true,
    includeDetailedTrace: true,
    persistToLocalStorage: true,
    localStorageKey: "nextGenGhdTicketDetails"
  };

  const state = {
    ticketList: [],
    errors: [],
    totalTickets: 0,
    processedTickets: 0,
    levelProgress: {},
    startedAt: null
  };

  const sleep = (milliseconds) =>
    new Promise((resolve) => setTimeout(resolve, milliseconds));

  const getCookie = (name) => {
    const cookies = document.cookie
      ? document.cookie.split(";")
      : [];

    for (const cookie of cookies) {
      const separatorIndex = cookie.indexOf("=");

      const cookieName = cookie
        .slice(
          0,
          separatorIndex === -1
            ? cookie.length
            : separatorIndex
        )
        .trim();

      if (cookieName === name) {
        return decodeURIComponent(
          separatorIndex === -1
            ? ""
            : cookie.slice(separatorIndex + 1)
        );
      }
    }

    return null;
  };

  const getXsrfToken = () =>
    getCookie("XSRF-TOKEN") ||
    getCookie("XSRF_TOKEN") ||
    getCookie("xsrf-token") ||
    getCookie("CSRF-TOKEN");

  const createHeaders = ({
    includeXsrf = true
  } = {}) => {
    const headers = {
      accept: "application/json, text/plain, */*",
      "content-type": "application/json"
    };

    if (includeXsrf) {
      const xsrfToken = getXsrfToken();

      if (xsrfToken) {
        headers["x-xsrf-token"] = xsrfToken;
      }
    }

    return headers;
  };

  const fetchWithTimeout = async (
    url,
    options = {},
    timeoutMs = CONFIG.requestTimeoutMs
  ) => {
    const controller = new AbortController();

    const timeoutId = setTimeout(
      () => controller.abort(),
      timeoutMs
    );

    try {
      return await fetch(url, {
        ...options,
        signal: controller.signal
      });
    } finally {
      clearTimeout(timeoutId);
    }
  };

  const requestJson = async (
    endpoint,
    body,
    {
      retries = CONFIG.retryCount,
      includeXsrf = true,
      timeoutMs = CONFIG.requestTimeoutMs
    } = {}
  ) => {
    const url = `${CONFIG.baseUrl}/${endpoint}`;
    let lastError = null;

    for (
      let attempt = 0;
      attempt <= retries;
      attempt += 1
    ) {
      try {
        const response = await fetchWithTimeout(
          url,
          {
            method: "POST",
            headers: createHeaders({
              includeXsrf
            }),
            body: JSON.stringify(body),
            mode: "cors",
            credentials: "include",
            referrer:
              "https://nextgenghd.ultimatix.net/NextGenGHDUI/"
          },
          timeoutMs
        );

        const responseText = await response.text();
        let responseData = null;

        if (responseText) {
          try {
            responseData = JSON.parse(responseText);
          } catch {
            responseData = responseText;
          }
        }

        if (!response.ok) {
          const error = new Error(
            `${endpoint} failed with HTTP ${response.status}`
          );

          error.status = response.status;
          error.response = responseData;

          throw error;
        }

        return responseData;
      } catch (error) {
        lastError = error;

        if (error?.name === "AbortError") {
          lastError = new Error(
            `${endpoint} timed out after ${timeoutMs} milliseconds`
          );

          lastError.status = null;
        }

        const status =
          lastError?.status ??
          error?.status ??
          null;

        const shouldRetry =
          attempt < retries &&
          status !== 400 &&
          status !== 401 &&
          status !== 403;

        if (!shouldRetry) {
          break;
        }

        console.warn(
          `${endpoint} attempt ${attempt + 1} failed. Retrying...`
        );

        await sleep(
          CONFIG.retryDelayMs * (attempt + 1)
        );
      }
    }

    throw lastError;
  };

  const normalizeTicketId = (value) => {
    if (
      value === null ||
      value === undefined ||
      value === ""
    ) {
      return null;
    }

    const normalized = String(value).trim();

    return /^\d+$/.test(normalized)
      ? normalized
      : null;
  };

  const findTicketId = (ticket) => {
    if (
      ticket === null ||
      ticket === undefined
    ) {
      return null;
    }

    if (
      typeof ticket === "number" ||
      typeof ticket === "string"
    ) {
      return normalizeTicketId(ticket);
    }

    if (typeof ticket !== "object") {
      return null;
    }

    const possibleKeys = [
      "ticketNo",
      "ticketId",
      "ticketID",
      "ticketNumber",
      "callId",
      "callID",
      "incidentId",
      "incidentID",
      "id"
    ];

    for (const key of possibleKeys) {
      const ticketId = normalizeTicketId(
        ticket[key]
      );

      if (ticketId) {
        return ticketId;
      }
    }

    return null;
  };

  const extractTicketObjects = (response) => {
    const results = [];
    const visited = new WeakSet();

    const walk = (value) => {
      if (
        value === null ||
        value === undefined
      ) {
        return;
      }

      if (Array.isArray(value)) {
        for (const item of value) {
          walk(item);
        }

        return;
      }

      if (typeof value !== "object") {
        return;
      }

      if (visited.has(value)) {
        return;
      }

      visited.add(value);

      const ticketId = findTicketId(value);

      if (ticketId) {
        results.push({
          ticketId,
          summary: value
        });

        return;
      }

      for (const childValue of Object.values(value)) {
        if (
          childValue &&
          (
            Array.isArray(childValue) ||
            typeof childValue === "object"
          )
        ) {
          walk(childValue);
        }
      }
    };

    walk(response);

    const uniqueTickets = new Map();

    for (const ticket of results) {
      if (!uniqueTickets.has(ticket.ticketId)) {
        uniqueTickets.set(
          ticket.ticketId,
          ticket
        );
      }
    }

    return [...uniqueTickets.values()];
  };

  const fetchTicketsForLevel = async (level) => {
    try {
      const response = await requestJson(
        "getTicketsByLevel",
        [false, Number(level.levelId)],
        {
          includeXsrf: false
        }
      );

      return {
        level,
        response,
        tickets: extractTicketObjects(response)
      };
    } catch (error) {
      state.errors.push({
        levelId: level.levelId,
        levelName: level.levelName,
        endpoint: "getTicketsByLevel",
        error: error.message
      });

      return {
        level,
        response: null,
        tickets: []
      };
    }
  };

  const safeTicketRequest = async (
    endpoint,
    ticketId
  ) => {
    try {
      const data = await requestJson(
        endpoint,
        Number(ticketId),
        {
          includeXsrf: true
        }
      );

      return {
        success: true,
        data,
        error: null
      };
    } catch (error) {
      return {
        success: false,
        data: null,
        error: error.message
      };
    }
  };

  const fetchTicketDetails = async (queueItem) => {
    const requests = [];

    if (CONFIG.includeAllTicketDetails) {
      requests.push({
        key: "allTicketDetails",
        endpoint: "getAllTicketDetails"
      });
    }

    if (CONFIG.includeResolutionDetails) {
      requests.push({
        key: "resolutionDetails",
        endpoint:
          "getTicketDetailsForResolution"
      });
    }

    if (CONFIG.includeDetailedTrace) {
      requests.push({
        key: "detailedTrace",
        endpoint: "getCallDetailedTrace"
      });
    }

    const results = await Promise.all(
      requests.map(
        async ({ key, endpoint }) => ({
          key,
          endpoint,
          result: await safeTicketRequest(
            endpoint,
            queueItem.ticketId
          )
        })
      )
    );

    const data = {};
    const failedEndpoints = [];

    for (
      const {
        key,
        endpoint,
        result
      } of results
    ) {
      data[key] = result.data;

      if (!result.success) {
        failedEndpoints.push(endpoint);

        state.errors.push({
          levelId: queueItem.level.levelId,
          levelName:
            queueItem.level.levelName,
          ticketId: queueItem.ticketId,
          endpoint,
          error: result.error
        });
      }
    }

    return {
      level: {
        levelId: queueItem.level.levelId,
        levelName:
          queueItem.level.levelName
      },
      ticketId: queueItem.ticketId,
      data: {
        summary: queueItem.summary,
        ...data
      },
      metadata: {
        fetchedAt: new Date().toISOString(),
        completed:
          failedEndpoints.length === 0,
        failedEndpoints
      }
    };
  };

  const upsertTicket = (ticketRecord) => {
    const existingIndex =
      state.ticketList.findIndex(
        (item) =>
          String(item.ticketId) ===
            String(ticketRecord.ticketId) &&
          String(item.level?.levelId) ===
            String(
              ticketRecord.level.levelId
            )
      );

    if (existingIndex === -1) {
      state.ticketList.push(ticketRecord);
    } else {
      state.ticketList[existingIndex] =
        ticketRecord;
    }
  };

  const saveToLocalStorage = () => {
    if (!CONFIG.persistToLocalStorage) {
      return;
    }

    try {
      localStorage.setItem(
        CONFIG.localStorageKey,
        JSON.stringify({
          savedAt: new Date().toISOString(),
          tickets: state.ticketList,
          errors: state.errors
        })
      );
    } catch (error) {
      console.error(
        "Unable to save to localStorage:",
        error
      );
    }
  };

  const loadFromLocalStorage = () => {
    if (!CONFIG.persistToLocalStorage) {
      return;
    }

    try {
      const saved = localStorage.getItem(
        CONFIG.localStorageKey
      );

      if (!saved) {
        return;
      }

      const data = JSON.parse(saved);

      if (Array.isArray(data.tickets)) {
        state.ticketList = data.tickets;
      }

      if (Array.isArray(data.errors)) {
        state.errors = data.errors;
      }
    } catch (error) {
      console.error(
        "Unable to load from localStorage:",
        error
      );
    }
  };

  const getElapsedTime = () => {
    if (!state.startedAt) {
      return "00:00:00";
    }

    const elapsedMilliseconds =
      Date.now() - state.startedAt;

    const totalSeconds = Math.floor(
      elapsedMilliseconds / 1000
    );

    const hours = String(
      Math.floor(totalSeconds / 3600)
    ).padStart(2, "0");

    const minutes = String(
      Math.floor(
        (totalSeconds % 3600) / 60
      )
    ).padStart(2, "0");

    const seconds = String(
      totalSeconds % 60
    ).padStart(2, "0");

    return `${hours}:${minutes}:${seconds}`;
  };

  const printStatus = ({
    completed = false
  } = {}) => {
    console.clear();

    console.log(
      completed
        ? "GHD Ticket Processing Complete"
        : "GHD Ticket Processing"
    );

    console.log(
      `Overall: ${state.processedTickets} / ${state.totalTickets}`
    );

    console.log(
      `Elapsed: ${getElapsedTime()}`
    );

    console.log("");

    for (const level of CONFIG.levels) {
      const progress =
        state.levelProgress[
          String(level.levelId)
        ];

      if (!progress) {
        console.log(
          `${level.levelName}: Preparing`
        );

        continue;
      }

      let statusText = "Waiting";

      if (progress.completed) {
        statusText = "Complete";
      } else if (progress.active) {
        statusText =
          `Batch ${progress.currentBatch} / ` +
          `${progress.totalBatches}`;
      } else if (progress.total === 0) {
        statusText = "No tickets";
      }

      console.log(
        `${level.levelName}: ` +
        `${progress.processed} / ` +
        `${progress.total} | ` +
        `${statusText}`
      );

      if (
        progress.active &&
        progress.currentTicketIds.length
      ) {
        console.log(
          `  Processing: ` +
          progress.currentTicketIds.join(", ")
        );
      }
    }

    console.log("");

    console.log(
      `Stored tickets: ${state.ticketList.length}`
    );

    if (state.errors.length) {
      console.log(
        `Errors: ${state.errors.length}`
      );
    }
  };

  const createLevelQueue = (
    levelResult
  ) => {
    const uniqueTicketIds = new Set();
    const queue = [];

    for (const ticket of levelResult.tickets) {
      const ticketId = String(
        ticket.ticketId
      );

      if (uniqueTicketIds.has(ticketId)) {
        continue;
      }

      uniqueTicketIds.add(ticketId);

      queue.push({
        level: {
          levelId:
            levelResult.level.levelId,
          levelName:
            levelResult.level.levelName
        },
        ticketId,
        summary: ticket.summary
      });
    }

    return queue;
  };

  const processLevelQueue = async (
    level,
    queue
  ) => {
    const progress =
      state.levelProgress[
        String(level.levelId)
      ];

    if (!queue.length) {
      progress.active = false;
      progress.completed = true;
      progress.currentBatch = 0;
      progress.currentTicketIds = [];

      printStatus();

      return {
        levelId: level.levelId,
        levelName: level.levelName,
        total: 0,
        processed: 0
      };
    }

    progress.active = true;
    printStatus();

    for (
      let batchStart = 0;
      batchStart < queue.length;
      batchStart +=
        CONFIG.ticketsPerLevelBatch
    ) {
      const batch = queue.slice(
        batchStart,
        batchStart +
          CONFIG.ticketsPerLevelBatch
      );

      const batchNumber =
        Math.floor(
          batchStart /
            CONFIG.ticketsPerLevelBatch
        ) + 1;

      progress.currentBatch = batchNumber;
      progress.currentTicketIds =
        batch.map(
          (item) => item.ticketId
        );

      printStatus();

      const batchResults =
        await Promise.all(
          batch.map((queueItem) =>
            fetchTicketDetails(queueItem)
          )
        );

      for (
        const ticketRecord of batchResults
      ) {
        upsertTicket(ticketRecord);

        progress.processed += 1;
        state.processedTickets += 1;
      }

      progress.currentTicketIds = [];

      saveToLocalStorage();
      printStatus();

      const hasMoreTickets =
        batchStart +
          CONFIG.ticketsPerLevelBatch <
        queue.length;

      if (hasMoreTickets) {
        await sleep(
          CONFIG.batchDelayMs
        );
      }
    }

    progress.active = false;
    progress.completed = true;
    progress.currentTicketIds = [];

    printStatus();

    return {
      levelId: level.levelId,
      levelName: level.levelName,
      total: progress.total,
      processed: progress.processed
    };
  };

  loadFromLocalStorage();

  state.startedAt = Date.now();

  const levelResults = await Promise.all(
    CONFIG.levels.map((level) =>
      fetchTicketsForLevel(level)
    )
  );

  const levelQueues = new Map();

  state.totalTickets = 0;
  state.processedTickets = 0;
  state.levelProgress = {};

  for (
    const levelResult of levelResults
  ) {
    const queue = createLevelQueue(
      levelResult
    );

    levelQueues.set(
      String(levelResult.level.levelId),
      queue
    );

    const totalBatches = Math.ceil(
      queue.length /
        CONFIG.ticketsPerLevelBatch
    );

    state.levelProgress[
      String(levelResult.level.levelId)
    ] = {
      levelId:
        levelResult.level.levelId,
      levelName:
        levelResult.level.levelName,
      total: queue.length,
      processed: 0,
      currentBatch: 0,
      totalBatches,
      currentTicketIds: [],
      active: false,
      completed: queue.length === 0
    };

    state.totalTickets += queue.length;
  }

  printStatus();

  if (state.totalTickets === 0) {
    printStatus({
      completed: true
    });

    console.log("No tickets available.");

    return {
      tickets: state.ticketList,
      errors: state.errors,
      total: 0,
      processed: 0,
      levelResults: []
    };
  }

  const processingResults =
    await Promise.all(
      CONFIG.levels.map((level) => {
        const queue =
          levelQueues.get(
            String(level.levelId)
          ) || [];

        return processLevelQueue(
          level,
          queue
        );
      })
    );

  saveToLocalStorage();

  printStatus({
    completed: true
  });

  console.log(
    `Processed ${state.processedTickets} / ${state.totalTickets} tickets.`
  );

  console.log(
    `Stored ${state.ticketList.length} tickets in local storage.`
  );

  if (state.errors.length) {
    console.warn(
      `Completed with ${state.errors.length} errors.`
    );

    console.table(state.errors);
  }

  return {
    tickets: state.ticketList,
    errors: state.errors,
    total: state.totalTickets,
    processed: state.processedTickets,
    levelResults: processingResults
  };
};

window.processAllTickets =
  processAllTickets;

if (
  typeof module !== "undefined" &&
  module.exports
) {
  module.exports = processAllTickets;
}

// // Auto-execute or call manually
//  processAllTickets();