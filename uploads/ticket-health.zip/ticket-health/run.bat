@echo off
cls
call myenv\Scripts\activate.bat
uvicorn app.main:app --reload