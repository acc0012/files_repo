import os
from channels.routing import ProtocolTypeRouter, URLRouter
from django.core.asgi import get_asgi_application
from django.urls import path
from orders.consumers import OrderConsumer

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'trading_project.settings')

django_app = get_asgi_application()

application = ProtocolTypeRouter({
    "http": django_app,
    "websocket": URLRouter([
        path("ws/orders/", OrderConsumer.as_asgi()),
    ]),
})