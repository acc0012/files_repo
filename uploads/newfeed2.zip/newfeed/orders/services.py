from core.utils import parse_message, generate_order_id, current_ist_time, should_ignore
from core.db import get_orders_collection
from core.telegram import send_telegram_alert
from core.logger import get_logger
from core.db import get_option_data_from_symbol   # 🔥 CHANGED (only import)
from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer



logger = get_logger("order_processor")


def notify_new_order(order_doc):
    channel_layer = get_channel_layer()

    async_to_sync(channel_layer.group_send)(
        "orders_live",
        {
            "type": "new_order",
            "data": {
                "order_id": order_doc["order_id"],
                "security_id": order_doc.get("option_data", {}).get("security_id"),
            }
        }
    )
# ✅ initialize collection once
orders_collection = get_orders_collection()


def process_order(raw_message):
    order_id = generate_order_id("ORD")

    metadata = {}
    failed_step = "init"

    try:
        logger.info(f"Received alert: {raw_message}")

        # STEP 1: Parse message
        failed_step = "parse_message"
        metadata = parse_message(raw_message)

        trade_type = metadata.get("Type")
        if not trade_type:
            raise ValueError("Missing Type in alert")

        # 🔥 Detect CE / PE (UNCHANGED)
        option_type = "pe" if "PE" in trade_type.upper() else "ce"

        # 🔥 Fetch option data (ENHANCED ONLY THIS BLOCK)
        option_data = None
        try:
            strike = metadata.get("Strike")
            symbol = metadata.get("Symbol")

            if strike and symbol:
                raw_data = get_option_data_from_symbol(
                    symbol=symbol,
                    strike=strike,
                    option_type=option_type
                )

                if raw_data:
                    # ✅ Extract only needed fields (NO LOGIC CHANGE, just cleaner storage)
                    option_data = {
                        "security_id": raw_data.get("security_id"),
                        "last_price": raw_data.get("last_price"),
                        "oi": raw_data.get("oi"),
                        "implied_volatility": raw_data.get("implied_volatility"),
                        "delta": raw_data.get("greeks", {}).get("delta"),
                        "theta": raw_data.get("greeks", {}).get("theta"),
                        "gamma": raw_data.get("greeks", {}).get("gamma"),
                        "vega": raw_data.get("greeks", {}).get("vega"),
                    }

        except Exception as oc_err:
            logger.error(f"Option data fetch failed: {oc_err}")

        # STEP 2: Fetch last placed order
        failed_step = "fetch_last_order"
        last_order = orders_collection.find_one(
            {"status": "PLACED"},
            sort=[("created_at", -1)]
        )

        # STEP 3: Ignore logic
        failed_step = "should_ignore"
        ignored = should_ignore(last_order, trade_type)

        order_id = generate_order_id("IG" if ignored else "ORD")

        # STEP 4: Prepare document (UNCHANGED)
        failed_step = "prepare_doc"
        order_doc = {
            "order_id": order_id,
            "status": "IGNORED" if ignored else "PLACED",
            "source": "ALERT",

            "trade_type": trade_type,
            "strike": metadata.get("Strike"),
            "strike_price": metadata.get("StrikeLivePrice"),
            "symbol": metadata.get("Symbol"),
            "alert_price": metadata.get("Price"),

            # 🔥 SAME FIELD (just cleaner now)
            "option_data": option_data,

            "created_at": current_ist_time(),
            "metadata": metadata
        }

        # STEP 5: Save to DB
        failed_step = "db_insert"
        orders_collection.insert_one(order_doc)

        if order_doc["status"] == "PLACED":
            notify_new_order(order_doc)
            
        logger.info(f"Order stored: {order_id} | Status: {order_doc['status']}")

        # STEP 6: Telegram (UNCHANGED)
        try:
            send_telegram_alert({
                "order_id": order_doc["order_id"],
                "status": order_doc["status"],
                "trade_type": order_doc["trade_type"],
                "symbol": order_doc["symbol"],
                "strike": order_doc["strike"],
                "strike_price": order_doc["strike_price"],
                "alert_price": order_doc["alert_price"],
                "created_at": order_doc["created_at"]
            })

            logger.info(f"Telegram sent for {order_id} ({order_doc['status']})")

        except Exception as tg_err:
            logger.error(f"Telegram error: {tg_err}")

    except Exception as e:
        logger.error(f"Error at step [{failed_step}] → {str(e)}", exc_info=True)

        failed_order = {
            "order_id": generate_order_id("FAIL"),
            "status": "FAILED",
            "source": "ALERT",
            "error_reason": str(e),
            "error_type": type(e).__name__,
            "failed_step": failed_step,
            "raw_message": raw_message,
            "metadata": metadata,
            "created_at": current_ist_time()
        }

        try:
            orders_collection.insert_one(failed_order)
            logger.warning(f"FAILED order stored: {failed_order['order_id']}")

            # Telegram for FAILED
            try:
                send_telegram_alert({
                    "order_id": failed_order["order_id"],
                    "status": "FAILED",
                    "trade_type": metadata.get("Type", "NA"),
                    "symbol": metadata.get("Symbol", "NA"),
                    "strike": metadata.get("Strike", "NA"),
                    "strike_price": "NA",
                    "alert_price": metadata.get("Price", "NA"),
                    "created_at": failed_order["created_at"],
                    "error": failed_order["error_reason"],
                    "failed_step": failed_order["failed_step"]
                })

                logger.info(f"Telegram sent for FAILED {failed_order['order_id']}")

            except Exception as tg_err:
                logger.error(f"Telegram FAIL alert error: {tg_err}")

        except Exception as db_err:
            logger.critical(f"DB ERROR while saving failed order: {db_err}", exc_info=True)