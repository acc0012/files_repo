from pymongo import MongoClient
from django.conf import settings
from core.logger import get_logger
import sys

logger = get_logger("db_layer")

# -----------------------------------
# 🔧 FORCE UTF-8 LOGGING (SAFE)
# -----------------------------------
try:
    sys.stdout.reconfigure(encoding='utf-8')
except Exception:
    pass


# -----------------------------------
# 🔗 SINGLETON CLIENT
# -----------------------------------
_client = None


def get_mongo_client():
    global _client

    if _client is None:
        if not settings.MONGO_URI:
            raise ValueError("MONGO_URI missing")

        _client = MongoClient(settings.MONGO_URI)
        logger.info("Mongo Connected")

    return _client


# -----------------------------------
# 📦 DATABASE (FIXED)
# -----------------------------------
def get_db(db_name=None):
    client = get_mongo_client()

    # Use passed DB or fallback
    db_to_use = db_name if db_name else settings.MONGO_DB

    if not db_to_use:
        raise ValueError("MONGO_DB missing")

    db = client[db_to_use]

    logger.info(f"Using DB: {db_to_use}")

    return db


# -----------------------------------
# 📊 COLLECTIONS
# -----------------------------------
def get_orders_collection():
    if not settings.MONGO_COLLECTION:
        raise ValueError("MONGO_COLLECTION missing")

    col = get_db()[settings.MONGO_COLLECTION]
    logger.info(f"Orders collection: {col.name}")

    return col


def get_auth_collection():
    return get_db(settings.AUTH_MONGO_DB)[settings.AUTH_MONGO_COLLECTION]


def get_option_chain_collection():
    # ✅ Use separate DB if provided
    db_name = getattr(settings, "MONGO_OPTION_CHAIN_DB", None)
    collection_name = getattr(settings, "MONGO_OPTION_COLLECTION", "index_option_chain")

    db = get_db(db_name)

    col = db[collection_name]

    logger.info(f"DB Name: {db.name}")
    logger.info(f"Collection: {col.name}")

    try:
        count = col.count_documents({})
        logger.info(f"option_chain collection count: {count}")

        if count == 0:
            logger.error("CRITICAL: option_chain collection is EMPTY")

    except Exception as e:
        logger.error(f"Error checking collection count: {e}")

    return col


# -----------------------------------
# 🔥 BACKWARD COMPATIBILITY
# -----------------------------------
orders_collection = get_orders_collection()


# -----------------------------------
# 🔥 SYMBOL → INDEX MAPPING
# -----------------------------------
def get_index_security_id_from_symbol(symbol: str):
    if not symbol:
        logger.error("Symbol is empty")
        return None

    symbol = symbol.upper()

    if "BANKNIFTY" in symbol:
        return 51
    elif "FINNIFTY" in symbol:
        return 25
    elif "NIFTY" in symbol:
        return 13

    logger.error(f"Unknown symbol mapping: {symbol}")
    return None


# -----------------------------------
# 🎯 OPTION CHAIN FETCH LOGIC
# -----------------------------------
def get_option_data(index_security_id, expiry, strike, option_type="pe"):
    collection = get_option_chain_collection()

    try:
        strike = float(strike)
    except Exception:
        logger.error(f"Invalid strike value: {strike}")
        return None

    strike_key = f"{strike:.6f}"

    logger.info(
        f"Fetching option data -> index={index_security_id}, strike={strike_key}, type={option_type}"
    )

    doc = collection.find_one(
        {"index_security_id": index_security_id},
        sort=[("fetched_at", -1)]
    )

    if not doc:
        logger.error(f"No option chain document found for index {index_security_id}")
        return None

    logger.info(f"Fetched doc timestamp: {doc.get('fetched_at')}")

    oc = doc.get("option_chain", {}).get("oc", {})

    if not oc:
        logger.error("option_chain.oc is empty")
        return None

    logger.info(f"Available strikes count: {len(oc)}")

    # ✅ Exact match
    if strike_key in oc:
        logger.info(f"Exact strike found: {strike_key}")
        return oc[strike_key].get(option_type.lower())

    # ✅ Nearest match
    try:
        closest = min(
            oc.keys(),
            key=lambda x: abs(float(x) - strike)
        )

        logger.warning(f"Strike {strike_key} not found, using nearest {closest}")

        return oc[closest].get(option_type.lower())

    except Exception as e:
        logger.error(f"Error finding nearest strike: {e}", exc_info=True)
        return None


# -----------------------------------
# 🔥 SYMBOL BASED FETCH
# -----------------------------------
def get_option_data_from_symbol(symbol, strike, option_type="pe"):
    logger.info(f"Symbol fetch -> {symbol}, strike={strike}")

    index_security_id = get_index_security_id_from_symbol(symbol)

    if not index_security_id:
        logger.error("Could not determine index from symbol")
        return None

    return get_option_data(
        index_security_id=index_security_id,
        expiry=None,
        strike=strike,
        option_type=option_type
    )


# -----------------------------------
# 🚀 OPTIONAL: GET BOTH CE & PE
# -----------------------------------
def get_option_both(index_security_id, expiry, strike):
    collection = get_option_chain_collection()

    try:
        strike = float(strike)
    except Exception:
        logger.error(f"Invalid strike value: {strike}")
        return None

    strike_key = f"{strike:.6f}"

    doc = collection.find_one(
        {"index_security_id": index_security_id},
        sort=[("fetched_at", -1)]
    )

    if not doc:
        logger.error("No option chain document found")
        return None

    oc = doc.get("option_chain", {}).get("oc", {})

    if strike_key in oc:
        return oc[strike_key]

    try:
        closest = min(
            oc.keys(),
            key=lambda x: abs(float(x) - strike)
        )

        logger.warning(f"Using nearest strike {closest}")

        return oc[closest]

    except Exception as e:
        logger.error(f"Error finding nearest strike: {e}", exc_info=True)
        return None


# -----------------------------------
# 🔥 OPTIONAL: AUTO ATM STRIKE
# -----------------------------------
def get_atm_strike(index_security_id, expiry):
    collection = get_option_chain_collection()

    doc = collection.find_one(
        {"index_security_id": index_security_id},
        sort=[("fetched_at", -1)]
    )

    if not doc:
        logger.error("No option chain document found for ATM")
        return None

    last_price = doc.get("option_chain", {}).get("last_price")

    if not last_price:
        logger.error("last_price missing in option chain")
        return None

    atm = round(last_price / 50) * 50

    logger.info(f"Calculated ATM strike: {atm}")

    return int(atm)