package com.ignite.innoverse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InnoverseApplicationTests {

	@Test
	void contextLoads() {
	}

}
