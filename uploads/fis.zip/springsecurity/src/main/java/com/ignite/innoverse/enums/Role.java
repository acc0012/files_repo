package com.ignite.innoverse.enums;

public enum Role {
    ROLE_ADMIN,
    ROLE_TA,
    ROLE_ASSOCIATES
}
