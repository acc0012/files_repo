package com.ignite.innoverse.controller;

import com.ignite.innoverse.dtos.request.IdeaReq;
import com.ignite.innoverse.dtos.response.GeneralResponse;
import com.ignite.innoverse.projections.IdeasProjection;
import com.ignite.innoverse.service.IdeaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@RestController
@RequestMapping("/api/v1/idea")
public class IdeasController {

    @Autowired
    IdeaService ideaService;

    @PostMapping("/create")
    @PreAuthorize("hasAuthority('ADD_IDEAS')")
    public ResponseEntity<GeneralResponse> createIdea(@Validated @RequestBody IdeaReq ideaReq, Principal principal){
        return ResponseEntity.status(HttpStatus.CREATED).body(ideaService.addIdea(principal, ideaReq));
    }

    @GetMapping("/view")
    @PreAuthorize("hasAuthority('IDEA_MANAGEMENT')")
    public ResponseEntity<List<IdeasProjection>> viewAll(){
        return ResponseEntity.ok(ideaService.viewAllIdeas());
    }


}
