package com.ignite.innoverse.dtos.request;

import com.ignite.innoverse.models.project.Tech;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class IdeaReq {

    @NotNull(message = "problemStatement cannot be empty")
    private String problemStatement;

    @NotNull(message = "solution cannot be empty")
    private String solution;

    private String presentationLink;

    @NotNull(message = "tech list cannot be empty")
    private List<Integer> techListId;

}
