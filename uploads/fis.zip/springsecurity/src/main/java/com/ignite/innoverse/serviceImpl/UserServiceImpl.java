package com.ignite.innoverse.serviceImpl;

import com.ignite.innoverse.dtos.request.UserReq;
import com.ignite.innoverse.dtos.request.UserUpdate;
import com.ignite.innoverse.dtos.response.GeneralResponse;
import com.ignite.innoverse.dtos.response.UserRes;
import com.ignite.innoverse.models.auth.User;
import com.ignite.innoverse.models.batch.Batch;
import com.ignite.innoverse.models.batch.BatchSubBatchId;
import com.ignite.innoverse.models.batch.BatchSubBatchMapping;
import com.ignite.innoverse.models.batch.SubBatch;
import com.ignite.innoverse.projections.UserProjection;
import com.ignite.innoverse.repo.BatchRepo;
import com.ignite.innoverse.repo.BatchSubBatchMapRepo;
import com.ignite.innoverse.repo.SubBatchRepo;
import com.ignite.innoverse.repo.UserRepo;
import com.ignite.innoverse.service.UserService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    UserRepo userRepo;

    @Autowired
    BatchRepo batchRepo;

    @Autowired
    SubBatchRepo subBatchRepo;

    @Autowired
    BatchSubBatchMapRepo subBatchMapRepo;

    @Autowired
    PasswordEncoder passwordEncoder;

    @Override
    public UserRes addUser(UserReq userReq) {

        Batch batch=batchRepo.findById(userReq.getBatchId())
                .orElseThrow(()->new EntityNotFoundException("Invalid BatchId"));

        SubBatch subBatch= subBatchRepo.findById(userReq.getSubBatchId())
                .orElseThrow(()->new EntityNotFoundException("Invalid SubBatchId"));

        User user=userRepo.save(
                User.builder()
                        .name(userReq.getName())
                        .email(userReq.getEmail())
                        .isEnabled(userReq.getIsEnabled())
                        .empId(userReq.getEmpId())
                        .role(userReq.getRole())
                        .batchSubBatchMapping(
                                BatchSubBatchMapping.builder()
                                        .id(
                                                BatchSubBatchId.builder()
                                                        .batchId(batch.getId())
                                                        .subBatchId(subBatch.getId())
                                                        .build()
                                        )
                                        .batch(batch)
                                        .subBatch(subBatch)
                                        .build()
                        )
                        .password(passwordEncoder.encode(userReq.getPassword()))
                        .createdAt(LocalDateTime.now())
                        .lastLogin(LocalDateTime.now())
                        .build()
        );
        return formatter(user);
    }

    @Override
    public GeneralResponse updateUser(UserUpdate update) {

        User user=userRepo.findByEmail(update.getEmail())
                .orElseThrow(
                        ()-> new UsernameNotFoundException("Invalid User")
                );

        if(update.getEmpId()!=null){
            user.setEmpId(update.getEmpId());
        }

        if(update.getRole()!=null){
            user.setRole(update.getRole());
        }

        if(update.getPassword()!=null){
            user.setPassword(update.getPassword());
        }

        if(update.getName()!=null){
            user.setName(update.getName());
        }

        if(update.getBatchId()!=null  && update.getSubBatchId()!=null){
            BatchSubBatchMapping batchSubBatchMapping=subBatchMapRepo.findById(
                    BatchSubBatchId.builder()
                            .subBatchId(update.getSubBatchId())
                            .batchId(update.getBatchId())
                            .build()
            ).orElseThrow(()-> new EntityNotFoundException("Invalid BatchId && SubBatchId Mapping"));

            user.setBatchSubBatchMapping(batchSubBatchMapping);
        }
        else if(update.getBatchId()!=null){
            BatchSubBatchMapping batchSubBatchMapping=subBatchMapRepo.findById(
                    BatchSubBatchId.builder()
                            .subBatchId(user.getBatchSubBatchMapping().getId().getSubBatchId())
                            .batchId(update.getBatchId())
                            .build()
            ).orElseThrow(()-> new EntityNotFoundException("Invalid BatchId"));

            user.setBatchSubBatchMapping(batchSubBatchMapping);


        }else if(update.getSubBatchId()!=null){
            BatchSubBatchMapping batchSubBatchMapping=subBatchMapRepo.findById(
                    BatchSubBatchId.builder()
                            .subBatchId(update.getSubBatchId())
                            .batchId(user.getBatchSubBatchMapping().getId().getBatchId())
                            .build()
            ).orElseThrow(()-> new EntityNotFoundException("Invalid SubBatchId"));

            user.setBatchSubBatchMapping(batchSubBatchMapping);
        }

        userRepo.save(user);

        return GeneralResponse.builder()
                .message(user.getEmail()+" details are updated")
                .status(200)
                .build();
    }

    @Override
    public List<UserProjection> viewAll() {

        return userRepo.findAllProjectionBy();
    }

    private UserRes formatter(User user){
        return UserRes.builder()
                .email(user.getEmail())
                .name(user.getName())
                .role(user.getRole())
                .isEnabled(user.getIsEnabled())
                .build();
    }
}
