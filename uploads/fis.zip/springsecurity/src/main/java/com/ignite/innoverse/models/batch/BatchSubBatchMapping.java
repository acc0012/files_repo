package com.ignite.innoverse.models.batch;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import com.ignite.innoverse.models.auth.User;
import jakarta.persistence.*;
import lombok.*;

import java.util.List;
import java.util.Objects;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@Builder
@Entity
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class ,property = "id")
public class BatchSubBatchMapping {

    @EmbeddedId
    private BatchSubBatchId id;

    @ManyToOne
    @MapsId("batchId")              /*MapsId refers to the batch's primary key field in BatchSubBatchId*/
    private Batch batch;

    @ManyToOne
    @MapsId("subBatchId")           /*MapsId refers to the subBatch's primary key field in BatchSubBatchId*/
    private SubBatch subBatch;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            joinColumns = {
                    @JoinColumn(name = "batch_id"),
                    @JoinColumn(name = "sub_batch_id")
            },
            inverseJoinColumns = @JoinColumn(name = "user_id")
    )
    private List<User> mentor;     /*This field can be used to store TA user objects for a specific sub batch*/

    @Override
    public boolean equals(Object ob){
        if(this==ob) return true;
        if(ob==null || this.getClass() != ob.getClass()) return false;
        BatchSubBatchMapping batch=(BatchSubBatchMapping) ob;
        return batch.getId() == this.getId();
    }

    @Override
    public int hashCode(){
        return Objects.hash(id);
    }
}
