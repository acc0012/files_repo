package com.ignite.innoverse.serviceImpl;

import com.ignite.innoverse.config.jwt.JwtUtilService;
import com.ignite.innoverse.config.user.UserInfoDetails;
import com.ignite.innoverse.dtos.request.AuthReq;
import com.ignite.innoverse.dtos.response.AuthRes;
import com.ignite.innoverse.repo.UserRepo;
import com.ignite.innoverse.service.AuthService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class AuthServiceImp implements AuthService {

    @Autowired
    UserRepo userRepo;

    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    JwtUtilService jwtUtilService;

    Logger logger= LoggerFactory.getLogger(AuthService.class);

    @Override
    public AuthRes login(AuthReq authReq) {

        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        authReq.getUserName(),
                        authReq.getPassword()));
        var user = userRepo.findByEmail(authReq.getUserName())
                .orElseThrow(() -> new UsernameNotFoundException("User Not Found"));
        var jwtToken = jwtUtilService.generateToken(new UserInfoDetails(user));
        logger.info("User authenticated: {}", user);
//      for saving login time
        user.setLastLogin(LocalDateTime.now());
//      saved in db
        userRepo.save(user);
        return AuthRes.builder()
                .accessToken(jwtToken)
                .message("Login Successful : " + user.getName())
                .build();
    }
}
