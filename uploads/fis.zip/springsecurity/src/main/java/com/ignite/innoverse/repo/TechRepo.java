package com.ignite.innoverse.repo;

import com.ignite.innoverse.models.project.Tech;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TechRepo extends JpaRepository<Tech,Integer> {
}
