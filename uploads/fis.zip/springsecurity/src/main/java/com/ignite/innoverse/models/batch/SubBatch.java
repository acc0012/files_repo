package com.ignite.innoverse.models.batch;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jakarta.persistence.*;
import lombok.*;

import java.util.Objects;
import java.util.Set;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "sub_batch")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class ,property = "id")
public class SubBatch {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String subBatch;

    @OneToMany(mappedBy = "subBatch")
    private Set<BatchSubBatchMapping> batchSubBatchMappings;

    @Override
    public boolean equals(Object ob){
        if(this==ob) return true;
        if(ob==null || this.getClass() != ob.getClass()) return false;
        SubBatch subBatch=(SubBatch) ob;
        return subBatch.getId().equals(this.id);
    }

    @Override
    public int hashCode(){
        return Objects.hash(id);
    }

}
