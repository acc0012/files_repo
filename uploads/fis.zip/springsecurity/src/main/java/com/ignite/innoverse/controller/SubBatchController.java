package com.ignite.innoverse.controller;

import com.ignite.innoverse.dtos.request.SubBatchReq;
import com.ignite.innoverse.dtos.response.SubBatchRes;
import com.ignite.innoverse.projections.SubBatchProjection;
import com.ignite.innoverse.service.SubBatchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/subBatch")
@PreAuthorize("hasAuthority('SUB_BATCH_MANAGEMENT')")
public class SubBatchController {

    @Autowired
    SubBatchService subBatchService;

    @PostMapping("/create")
    public ResponseEntity<SubBatchRes> create(@RequestBody SubBatchReq subBatchReq){
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(subBatchService.create(subBatchReq));
    }

    @GetMapping("/view")
    public ResponseEntity<List<SubBatchProjection>> viewAll(){
        return ResponseEntity.ok(subBatchService.viewAll());
    }

}
