package com.ignite.innoverse.dtos.response;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AuthRes {
    private String accessToken;
    private String message;
}
