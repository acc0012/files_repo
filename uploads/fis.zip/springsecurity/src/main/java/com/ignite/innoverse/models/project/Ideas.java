package com.ignite.innoverse.models.project;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import com.ignite.innoverse.models.auth.User;
import jakarta.persistence.*;
import lombok.*;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@Builder
@Entity
@Table(name = "ideas")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class ,property = "id")
public class Ideas {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(length = 5000)
    private String problemStatement;

    @Column(length = 5000)
    private String solution;

    private String presentationLink;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "idea_tech",
            joinColumns = @JoinColumn(name = "idea_id"),
            inverseJoinColumns = @JoinColumn(name = "tech_id")
    )
    private List<Tech> techList;

    @ManyToOne(fetch = FetchType.EAGER)
    private User postedBy;                        /*Many Ideas can be posted by one user*/
}
