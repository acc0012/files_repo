package com.ignite.innoverse.controller;

import com.ignite.innoverse.dtos.request.BatchSubBatchReq;
import com.ignite.innoverse.dtos.response.GeneralResponse;
import com.ignite.innoverse.service.BatchSubBatchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/batchSubBatch")
@PreAuthorize("hasAuthority('SUB_BATCH_MANAGEMENT')")
public class BatchSubBatchController {

    @Autowired
    BatchSubBatchService batchSubBatchService;

    @PostMapping("/create")
    public ResponseEntity<GeneralResponse> addBatchSubBatch(@RequestBody BatchSubBatchReq batchReq){
        return ResponseEntity.status(HttpStatus.CREATED).body(batchSubBatchService.create(batchReq));
    }

}
