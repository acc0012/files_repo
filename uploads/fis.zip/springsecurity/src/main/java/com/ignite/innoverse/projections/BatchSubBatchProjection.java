package com.ignite.innoverse.projections;

import java.util.List;

public interface BatchSubBatchProjection {
    BatchProjection getBatch();
    SubBatchProjection getSubBatch();
    List<UserProjection> getMentor();
}
