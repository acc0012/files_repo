package com.ignite.innoverse.models.auth;

import com.ignite.innoverse.enums.Role;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Authorities {

    public static List<Authority> getAuthorities(Role role) {
        return switch (role.name()) {
            case "ROLE_ADMIN" ->
                    Arrays.asList(
                            Authority.USER_MANAGEMENT,
                            Authority.BATCH_MANAGEMENT,
                            Authority.SUB_BATCH_MANAGEMENT,
                            Authority.GET_MY_INFO,
                            Authority.IDEA_MANAGEMENT,
                            Authority.TECH_MANAGEMENT
                    );
            case "ROLE_TA" ->
                    Arrays.asList(
                            Authority.ADD_INCUBATORS,
                            Authority.ADD_IDEAS,
                            Authority.VIEW_ALL_IDEAS,
                            Authority.ADD_PROJECT_SUGGESTIONS,
                            Authority.GET_MY_INFO
                    );
            case "ROLE_ASSOCIATES" ->
                    Arrays.asList(
                            Authority.ADD_IDEAS,
                            Authority.ADD_PROJECT_SUGGESTIONS,
                            Authority.GET_MY_INFO
                    );
            default -> new ArrayList<>();
        };
    }
}
