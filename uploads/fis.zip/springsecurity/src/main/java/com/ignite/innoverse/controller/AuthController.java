package com.ignite.innoverse.controller;

import com.ignite.innoverse.dtos.request.AuthReq;
import com.ignite.innoverse.dtos.response.AuthRes;
import com.ignite.innoverse.models.auth.User;
import com.ignite.innoverse.projections.UserProjection;
import com.ignite.innoverse.repo.UserRepo;
import com.ignite.innoverse.service.AuthService;
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;

@RestController
@RequestMapping("/api/v1/auth")
public class AuthController {

    @Autowired
    AuthService authService;

    @Autowired
    UserRepo userRepo;

    @PostMapping("/login")
    public ResponseEntity<AuthRes> login(@Valid @RequestBody AuthReq authReq){
        return ResponseEntity.ok(authService.login(authReq));
    }

    @PreAuthorize("hasAuthority('GET_MY_INFO')")
    @GetMapping("/me")
    public ResponseEntity<UserProjection> userInfo(Principal principal){
        UserProjection user=userRepo.findProjectionByEmail(principal.getName());
        return ResponseEntity.ok(user);
    }

}
