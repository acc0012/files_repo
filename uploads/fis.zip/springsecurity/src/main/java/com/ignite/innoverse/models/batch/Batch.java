package com.ignite.innoverse.models.batch;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.util.Objects;
import java.util.Set;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "batch")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class ,property = "id")
public class Batch {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String batchName;
    private LocalDate startDate;
    private LocalDate endDate;

    @OneToMany(mappedBy = "batch")
    private Set<BatchSubBatchMapping> subBatches;

    @Override
    public boolean equals(Object ob){
        if(this==ob) return true;
        if(ob==null || this.getClass() != ob.getClass()) return false;
        Batch batch=(Batch) ob;
        return batch.getId().equals(this.id);
    }

    @Override
    public int hashCode(){
        return Objects.hash(id);
    }

}
