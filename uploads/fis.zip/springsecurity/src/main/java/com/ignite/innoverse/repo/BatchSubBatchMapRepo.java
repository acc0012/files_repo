package com.ignite.innoverse.repo;

import com.ignite.innoverse.models.batch.BatchSubBatchId;
import com.ignite.innoverse.models.batch.BatchSubBatchMapping;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BatchSubBatchMapRepo extends JpaRepository<BatchSubBatchMapping, BatchSubBatchId> {

}
