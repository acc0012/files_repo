package com.ignite.innoverse.repo;

import com.ignite.innoverse.models.batch.SubBatch;
import com.ignite.innoverse.projections.SubBatchProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SubBatchRepo extends JpaRepository<SubBatch,Integer> {
    List<SubBatchProjection> findAllProjectionBy();
}
