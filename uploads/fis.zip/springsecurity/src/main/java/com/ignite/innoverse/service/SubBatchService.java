package com.ignite.innoverse.service;

import com.ignite.innoverse.dtos.request.SubBatchReq;
import com.ignite.innoverse.dtos.response.SubBatchRes;
import com.ignite.innoverse.projections.SubBatchProjection;

import java.util.List;

public interface SubBatchService {
    SubBatchRes create(SubBatchReq subBatchReq);

    List<SubBatchProjection> viewAll();
}
