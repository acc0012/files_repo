package com.ignite.innoverse.service;

import com.ignite.innoverse.dtos.request.IdeaReq;
import com.ignite.innoverse.dtos.response.GeneralResponse;
import com.ignite.innoverse.projections.IdeasProjection;

import java.security.Principal;
import java.util.List;

public interface IdeaService {

    GeneralResponse addIdea(Principal principal, IdeaReq ideaReq);

    List<IdeasProjection> viewAllIdeas();
}
