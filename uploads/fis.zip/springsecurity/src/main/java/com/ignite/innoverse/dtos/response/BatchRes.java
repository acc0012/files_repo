package com.ignite.innoverse.dtos.response;

import jakarta.persistence.Column;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.LocalDate;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class BatchRes {

    @Column(nullable = false)
    @NotNull(message = "batchName cannot be null")
    private String batchName;
    private LocalDate startDate;
    private LocalDate endDate;

}
