package com.ignite.innoverse.projections;

public interface BatchProjection {
    Integer getId();
    String getBatchName();
}
