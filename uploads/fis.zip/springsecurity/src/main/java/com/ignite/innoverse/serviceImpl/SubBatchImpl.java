package com.ignite.innoverse.serviceImpl;

import com.ignite.innoverse.dtos.request.SubBatchReq;
import com.ignite.innoverse.dtos.response.SubBatchRes;
import com.ignite.innoverse.models.batch.SubBatch;
import com.ignite.innoverse.projections.SubBatchProjection;
import com.ignite.innoverse.repo.SubBatchRepo;
import com.ignite.innoverse.service.SubBatchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SubBatchImpl implements SubBatchService {

    @Autowired
    SubBatchRepo subBatchRepo;

    @Override
    public SubBatchRes create(SubBatchReq subBatchReq) {
        return formatter(
                subBatchRepo.save(
                        SubBatch.builder()
                                .subBatch(subBatchReq.getSubBatch())
                                .build()
                )
        );
    }

    @Override
    public List<SubBatchProjection> viewAll() {
        return subBatchRepo.findAllProjectionBy();
    }


    private SubBatchRes formatter(SubBatch subBatch){
        return SubBatchRes.builder()
                .subBatch(subBatch.getSubBatch())
                .id(subBatch.getId())
                .build();
    }
}
