package com.ignite.innoverse.service;

import com.ignite.innoverse.dtos.request.UserReq;
import com.ignite.innoverse.dtos.request.UserUpdate;
import com.ignite.innoverse.dtos.response.GeneralResponse;
import com.ignite.innoverse.dtos.response.UserRes;
import com.ignite.innoverse.projections.UserProjection;

import java.util.List;

public interface UserService {

    UserRes addUser(UserReq userReq);

    GeneralResponse updateUser(UserUpdate update);

    List<UserProjection> viewAll();
}
