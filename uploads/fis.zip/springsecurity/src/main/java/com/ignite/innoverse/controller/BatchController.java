package com.ignite.innoverse.controller;

import com.ignite.innoverse.dtos.request.BatchReq;
import com.ignite.innoverse.dtos.response.BatchRes;
import com.ignite.innoverse.projections.BatchProjection;
import com.ignite.innoverse.service.BatchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/batch")
@PreAuthorize("hasAuthority('BATCH_MANAGEMENT')")
public class BatchController {

    @Autowired
    BatchService batchService;

    @PostMapping("/create")
    public ResponseEntity<BatchRes> addBatch(@RequestBody BatchReq batchReq){
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(batchService.addBatch(batchReq)
                );
    }

    @GetMapping("/view")
    public ResponseEntity<List<BatchProjection>> viewAll(){
        return ResponseEntity.ok(batchService.viewAll());
    }
}
