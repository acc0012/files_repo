package com.ignite.innoverse.serviceImpl;

import com.ignite.innoverse.dtos.response.GeneralResponse;
import com.ignite.innoverse.models.project.Tech;
import com.ignite.innoverse.repo.TechRepo;
import com.ignite.innoverse.service.TechService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
public class TechServiceImpl implements TechService {

    @Autowired
    TechRepo techRepo;

    @Override
    public GeneralResponse addTech(String tech) {
        techRepo.save(
                Tech.builder()
                        .name(tech)
                        .build()
        );

        return GeneralResponse.builder()
                .message("tech added successfully")
                .status(HttpStatus.CREATED.value())
                .build();
    }
}
