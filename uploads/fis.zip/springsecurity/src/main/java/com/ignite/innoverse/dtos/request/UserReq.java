package com.ignite.innoverse.dtos.request;

import com.ignite.innoverse.enums.Role;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.*;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserReq {

    private String email;//login

    private String name;

    private Integer empId;

    private Boolean isEnabled;

    private String password;

    private Integer batchId;

    private Integer subBatchId;

    @Enumerated(EnumType.STRING)
    private Role role;
}
