package com.ignite.innoverse.dtos.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuthReq {

    @Email(message = "email should be valid")
    @NotBlank(message = "userName cannot be blank")
    private String userName;

    @NotBlank(message = "password cannot be blank")
    private String password;
}
