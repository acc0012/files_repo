package com.ignite.innoverse.controller;

import com.ignite.innoverse.dtos.request.UserReq;
import com.ignite.innoverse.dtos.request.UserUpdate;
import com.ignite.innoverse.dtos.response.GeneralResponse;
import com.ignite.innoverse.dtos.response.UserRes;
import com.ignite.innoverse.projections.UserProjection;
import com.ignite.innoverse.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/user")
@PreAuthorize("hasAuthority('USER_MANAGEMENT')")
public class UserController {

    @Autowired
    UserService userService;

    @PostMapping("/create")
    public ResponseEntity<UserRes> createUser(@RequestBody UserReq userReq){
        return ResponseEntity.status(HttpStatus.CREATED).body(userService.addUser(userReq));
    }

    @PatchMapping("/update")
    public ResponseEntity<GeneralResponse> updateUser(@RequestBody UserUpdate update){
        return ResponseEntity.ok(userService.updateUser(update));
    }

    @GetMapping("/view")
    public ResponseEntity<List<UserProjection>> viewAllUsers(){
        return ResponseEntity.ok(userService.viewAll());
    }

}
