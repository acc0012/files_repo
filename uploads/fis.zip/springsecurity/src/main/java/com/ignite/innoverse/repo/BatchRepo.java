package com.ignite.innoverse.repo;

import com.ignite.innoverse.models.batch.Batch;
import com.ignite.innoverse.models.batch.SubBatch;
import com.ignite.innoverse.projections.BatchProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BatchRepo extends JpaRepository<Batch, Integer> {
    List<BatchProjection> findAllProjectionBy();
}
