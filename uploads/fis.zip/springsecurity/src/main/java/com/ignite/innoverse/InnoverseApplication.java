package com.ignite.innoverse;

import com.ignite.innoverse.dtos.request.UserReq;
import com.ignite.innoverse.enums.Role;
import com.ignite.innoverse.repo.UserRepo;
import com.ignite.innoverse.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InnoverseApplication implements CommandLineRunner {

	@Autowired
	UserService userService;

	public static void main(String[] args) {
		SpringApplication.run(InnoverseApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
//		userService.addUser(
//				UserReq.builder()
//						.email("admin@tcs.com")
//						.name("stranger")
//						.empId(2718141)
//						.role(Role.ROLE_ADMIN)
//						.isEnabled(true)
//						.password("Tcs#12345")
//						.build()
//		);
	}
}
