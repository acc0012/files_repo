package com.ignite.innoverse.dtos.response;

import com.ignite.innoverse.enums.Role;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.*;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class UserRes {
    private String email;//login

    private String name;

    private Boolean isEnabled;

    @Enumerated(EnumType.STRING)
    private Role role;
}
