package com.ignite.innoverse.projections;

public interface TechProjection {
    String getName();
    Integer getId();
}
