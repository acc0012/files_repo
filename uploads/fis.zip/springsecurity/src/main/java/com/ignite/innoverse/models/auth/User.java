package com.ignite.innoverse.models.auth;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import com.ignite.innoverse.enums.Role;
import com.ignite.innoverse.models.batch.BatchSubBatchMapping;
import com.ignite.innoverse.models.project.Ideas;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.beans.factory.annotation.Value;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "user_data")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class ,property = "userId")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer userId;

    @Column(unique=true)
    private String email;//login

    private String name;

    private Boolean isEnabled;

    private Integer empId;

    @Value("${default.password:defaultPassword}")
    private String password;

    @Enumerated(EnumType.STRING)
    private Role role;

    private LocalDateTime createdAt;

    private LocalDateTime lastLogin;

    @ManyToOne
    @JoinColumns(
                {
                    @JoinColumn(name = "batch_id",referencedColumnName = "batch_id"),
                    @JoinColumn(name = "sub_batch_id",referencedColumnName = "sub_batch_id")
                }
            )
    private BatchSubBatchMapping batchSubBatchMapping;

    @ManyToMany(mappedBy = "mentor",fetch = FetchType.LAZY)
    private List<BatchSubBatchMapping> owner;


    @OneToMany(mappedBy = "postedBy",fetch = FetchType.EAGER)
    private List<Ideas> ideasList;

    @Override
    public boolean equals(Object ob){
        if(this==ob) return true;
        if(ob==null || this.getClass() != ob.getClass()) return false;
        User user=(User) ob;
        return user.getUserId().equals(this.userId) && user.getEmail().equals(this.getEmail());
    }

    @Override
    public int hashCode(){
        return Objects.hash(userId,email);
    }
}
