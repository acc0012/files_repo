package com.ignite.innoverse.dtos.request;

import com.ignite.innoverse.enums.Role;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
public class UserUpdate {

    @NotNull(message = "userName cannot be null")
    private String email;
    private String password;
    private Integer empId;
    private String name;
    private Integer batchId;
    private Integer subBatchId;
    @Enumerated(EnumType.STRING)
    private Role role;

}
