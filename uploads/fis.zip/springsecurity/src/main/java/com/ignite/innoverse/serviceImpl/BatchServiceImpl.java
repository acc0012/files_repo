package com.ignite.innoverse.serviceImpl;

import com.ignite.innoverse.dtos.request.BatchReq;
import com.ignite.innoverse.dtos.response.BatchRes;
import com.ignite.innoverse.models.batch.Batch;
import com.ignite.innoverse.projections.BatchProjection;
import com.ignite.innoverse.repo.BatchRepo;
import com.ignite.innoverse.service.BatchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BatchServiceImpl implements BatchService {

    @Autowired
    BatchRepo batchRepo;

    @Override
    public BatchRes addBatch(BatchReq batchReq) {

        Batch batch=batchRepo.save(
                Batch.builder()
                        .batchName(batchReq.getBatchName())
                        .startDate(batchReq.getStartDate())
                        .endDate(batchReq.getEndDate())
                        .build()
        );
        return formatter(batch);
    }

    @Override
    public List<BatchProjection> viewAll() {
        return batchRepo.findAllProjectionBy();
    }

    private BatchRes formatter(Batch batch){
        return BatchRes.builder()
                .batchName(batch.getBatchName())
                .startDate(batch.getStartDate())
                .endDate(batch.getEndDate())
                .build();
    }
}
