package com.ignite.innoverse.service;

import com.ignite.innoverse.dtos.request.BatchReq;
import com.ignite.innoverse.dtos.response.BatchRes;
import com.ignite.innoverse.projections.BatchProjection;

import java.util.List;

public interface BatchService {
    BatchRes addBatch(BatchReq batchReq);

    List<BatchProjection> viewAll();
}
