package com.ignite.innoverse.serviceImpl;

import com.ignite.innoverse.dtos.request.IdeaReq;
import com.ignite.innoverse.dtos.response.GeneralResponse;
import com.ignite.innoverse.models.project.Ideas;
import com.ignite.innoverse.projections.IdeasProjection;
import com.ignite.innoverse.repo.IdeaRepo;
import com.ignite.innoverse.repo.TechRepo;
import com.ignite.innoverse.repo.UserRepo;
import com.ignite.innoverse.service.IdeaService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import java.security.Principal;
import java.util.List;

@Service
public class IdeaServiceImpl implements IdeaService {

    Logger logger= LoggerFactory.getLogger(IdeaServiceImpl.class);

    UserRepo userRepo;
    IdeaRepo ideaRepo;
    TechRepo techRepo;

    public IdeaServiceImpl(UserRepo userRepo, IdeaRepo ideaRepo, TechRepo techRepo) {
        this.userRepo = userRepo;
        this.ideaRepo = ideaRepo;
        this.techRepo = techRepo;
    }

    @Override
    public GeneralResponse addIdea(Principal principal, IdeaReq ideaReq) {

        Ideas idea=Ideas.builder()
                .postedBy(userRepo.findByEmail(principal.getName())
                        .orElseThrow(()->new UsernameNotFoundException("Invalid User"))
                )
                .presentationLink(ideaReq.getPresentationLink())
                .problemStatement(ideaReq.getProblemStatement())
                .solution(ideaReq.getSolution())
                .techList(techRepo.findAllById(ideaReq.getTechListId()))
                .build();

        ideaRepo.save(idea);

        logger.info("user_id :{}\n posted idea_id :{}", idea.getPostedBy().getUserId(), idea.getId());

        return GeneralResponse.builder()
                .status(HttpStatus.CREATED.value())
                .message("Idea posted successfully")
                .build();
    }

    @Override
    public List<IdeasProjection> viewAllIdeas() {
        return ideaRepo.findAllProjectionBy();
    }

}
