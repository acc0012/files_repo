package com.ignite.innoverse.config.jwt;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
public class JwtAuthFilter extends OncePerRequestFilter {

    public JwtAuthFilter(JwtUtilService jwtUtilService,UserDetailsService userDetailsService) {
        this.jwtUtilService = jwtUtilService;
        this.userDetailsService=userDetailsService;
    }

    private JwtUtilService jwtUtilService;
    private UserDetailsService userDetailsService;

    @Override
    protected void doFilterInternal(
            @NonNull HttpServletRequest request,
            @NonNull HttpServletResponse response,
            @NonNull FilterChain filterChain) throws ServletException, IOException {


        final String authHeader = request.getHeader("Authorization");

        logger.debug("Incoming Authorization Header: " + request.getHeader("Authorization"));
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            logger.debug(String.format("Public API access remote Ip %s || URL (%s)%s", request.getRemoteAddr(), request.getMethod(), request.getRequestURI()));
            filterChain.doFilter(request, response);
            return;
        }
        final String jwt = authHeader.substring(7);
        String email = "";
        try {
            email = jwtUtilService.getEmail(jwt);
            if (email != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                UserDetails userDetails = this.userDetailsService.loadUserByUsername(email);
                if (jwtUtilService.isValidToken(jwt, userDetails)) {
                    UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(
                            userDetails,
                            null,
                            userDetails.getAuthorities());
                    authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                    logger.debug(String.format("Authorized API access remote Ip %s || URL (%s) %s || user (%s)", request.getRemoteAddr(), request.getMethod(), request.getRequestURI(), userDetails.getAuthorities().iterator().next().toString()));
                    SecurityContextHolder.getContext().setAuthentication(authToken);
                }
            }
        } catch (Exception e) {
            logger.debug(String.format("Unauthorized API access remote Ip %s || URL (%s) %s || Error %s", request.getRemoteAddr(), request.getMethod(), request.getRequestURI(), e.toString()));
        }

        filterChain.doFilter(request, response);

    }


}
