package com.ignite.innoverse.dtos.response;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GeneralResponse {
    private String message;
    private int status;
}
