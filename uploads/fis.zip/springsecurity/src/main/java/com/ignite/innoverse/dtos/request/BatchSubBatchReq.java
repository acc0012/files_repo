package com.ignite.innoverse.dtos.request;

import lombok.*;

import java.util.List;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BatchSubBatchReq {

    private Integer batchId;
    private List<Integer> subBatchId;

}
