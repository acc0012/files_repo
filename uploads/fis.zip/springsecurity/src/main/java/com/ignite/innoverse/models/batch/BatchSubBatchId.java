package com.ignite.innoverse.models.batch;


import jakarta.persistence.Embeddable;
import lombok.*;

import java.io.Serializable;
import java.util.Objects;

/**
 * Composite key with Batch id and SubBatch id
 */
@Embeddable
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BatchSubBatchId implements Serializable {

    private Integer batchId;
    private Integer subBatchId;

    @Override
    public boolean equals(Object ob){
        if(this==ob) return true;
        if(ob==null || this.getClass() != ob.getClass()) return false;

        BatchSubBatchId batchSubBatchId=(BatchSubBatchId) ob;
        return batchId.equals(batchSubBatchId.getBatchId()) &&
                subBatchId.equals(batchSubBatchId.getSubBatchId());
    }

    @Override
    public int hashCode(){
        return Objects.hash(batchId,subBatchId);
    }
}
