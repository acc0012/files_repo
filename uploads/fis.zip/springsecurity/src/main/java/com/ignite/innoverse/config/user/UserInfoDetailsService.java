package com.ignite.innoverse.config.user;

import com.ignite.innoverse.repo.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

/**
 * We have to create a UserDetailsService bean , So We have implemented that interface in this class
 * Implemented logic for retrieval of user object from DB
 */
@Service
public class UserInfoDetailsService implements UserDetailsService {

    @Autowired
    UserRepo userRepo;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        return new UserInfoDetails(
                userRepo.findByEmail(username)
                        .orElseThrow(()-> new UsernameNotFoundException("userName not found: "+username))
        );
    }

}
