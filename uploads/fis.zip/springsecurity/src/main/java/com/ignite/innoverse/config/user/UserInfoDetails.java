package com.ignite.innoverse.config.user;

import com.ignite.innoverse.models.auth.Authorities;
import com.ignite.innoverse.models.auth.User;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;

/**
 * This class implements UserDetails to represent our DB stored entity object
 * as a Spring Security understandable UserDetails object
 */
public class UserInfoDetails implements UserDetails {

    private final User user;

    public UserInfoDetails(User user){
        this.user=user;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        List<SimpleGrantedAuthority> authorities=new ArrayList<>();

        authorities.add(new SimpleGrantedAuthority(user.getRole().name()));

        Authorities.getAuthorities(
                user.getRole()
        ).stream().map(Enum::name).forEach((e)->authorities.add(new SimpleGrantedAuthority(e)));

        return authorities;
    }

    @Override
    public String getPassword() {
        return user.getPassword();
    }

    @Override
    public String getUsername() {
        return user.getEmail();
    }

    @Override
    public boolean isEnabled() { return user.getIsEnabled(); }

    @Override
    public boolean isAccountNonLocked() {
        return user.getIsEnabled();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof User user1)) return false;
        return Objects.equals(user1.getUserId(), user.getUserId()); // Compare based on unique identifier (i.e) db auto generated ID
    }

    @Override
    public int hashCode() {
        return Objects.hash(user.getUserId()); // Use the same unique identifier for hash code
    }
}
