package com.ignite.innoverse.projections;
import com.ignite.innoverse.models.project.Tech;

import java.util.List;

public interface IdeasProjection {
    Integer getId();
    String getProblemStatement();
    String getSolution();
    String getPresentationLink();
    List<TechProjection> getTechList();
    UserProjection getPostedBy();
}
