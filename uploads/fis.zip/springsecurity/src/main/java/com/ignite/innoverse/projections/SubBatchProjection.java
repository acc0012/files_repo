package com.ignite.innoverse.projections;

public interface SubBatchProjection {
    Integer getId();
    String getSubBatch();
}
