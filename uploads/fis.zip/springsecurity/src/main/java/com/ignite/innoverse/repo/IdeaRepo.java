package com.ignite.innoverse.repo;

import com.ignite.innoverse.models.project.Ideas;
import com.ignite.innoverse.projections.IdeasProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IdeaRepo extends JpaRepository<Ideas,Integer> {
    List<IdeasProjection> findAllProjectionBy();
}
