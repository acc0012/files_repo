package com.ignite.innoverse.dtos.request;

import jakarta.persistence.Column;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.LocalDate;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BatchReq {

    @Column(nullable = false)
    @NotNull(message = "batchName cannot be null")
    private String batchName;
    private LocalDate startDate;
    private LocalDate endDate;
}
