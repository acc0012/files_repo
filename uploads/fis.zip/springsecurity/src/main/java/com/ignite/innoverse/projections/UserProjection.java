package com.ignite.innoverse.projections;

import com.ignite.innoverse.enums.Role;

public interface UserProjection {
    Integer getUserId();
    String getEmail();
    String getName();
    Boolean getIsEnabled();
    Integer getEmpId();
    Role getRole();
    BatchSubBatchProjection getBatchSubBatchMapping();

}
