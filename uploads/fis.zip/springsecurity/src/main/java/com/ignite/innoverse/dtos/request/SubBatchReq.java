package com.ignite.innoverse.dtos.request;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SubBatchReq {
    private String subBatch;
}
