package com.ignite.innoverse.service;

import com.ignite.innoverse.dtos.request.BatchSubBatchReq;
import com.ignite.innoverse.dtos.response.GeneralResponse;

public interface BatchSubBatchService {
    GeneralResponse create(BatchSubBatchReq batchReq);
}
