package com.ignite.innoverse.serviceImpl;

import com.ignite.innoverse.dtos.request.BatchSubBatchReq;
import com.ignite.innoverse.dtos.response.GeneralResponse;
import com.ignite.innoverse.models.batch.Batch;
import com.ignite.innoverse.models.batch.BatchSubBatchId;
import com.ignite.innoverse.models.batch.BatchSubBatchMapping;
import com.ignite.innoverse.models.batch.SubBatch;
import com.ignite.innoverse.repo.BatchRepo;
import com.ignite.innoverse.repo.BatchSubBatchMapRepo;
import com.ignite.innoverse.repo.SubBatchRepo;
import com.ignite.innoverse.service.BatchSubBatchService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BatchSubBatchServiceImpl implements BatchSubBatchService {

    @Autowired
    BatchSubBatchMapRepo batchSubBatchMapRepo;

    @Autowired
    BatchRepo batchRepo;

    @Autowired
    SubBatchRepo subBatchRepo;

    @Override
    public GeneralResponse create(BatchSubBatchReq batchReq) {

        List<SubBatch> subBatchList=subBatchRepo.findAllById(batchReq.getSubBatchId());
        Batch batch= batchRepo.findById(batchReq.getBatchId())
                .orElseThrow(()->new EntityNotFoundException("Invalid batchId"));

        List<BatchSubBatchMapping> subBatchMappingList=subBatchList.stream().map(
                (e)-> BatchSubBatchMapping.builder()
                        .id(
                                BatchSubBatchId.builder()
                                        .batchId(batch.getId())
                                        .subBatchId(e.getId())
                                        .build()
                        )
                        .batch(batch)
                        .subBatch(e)
                        .build()
                ).toList();

        batchSubBatchMapRepo.saveAll(subBatchMappingList);

        return GeneralResponse.builder()
                .status(HttpStatus.CREATED.value())
                .message("Batches mapped successfully")
                .build();
    }
}
