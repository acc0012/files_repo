package com.ignite.innoverse.dtos.response;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
public class SubBatchRes {

    private Integer id;
    private String subBatch;

}
