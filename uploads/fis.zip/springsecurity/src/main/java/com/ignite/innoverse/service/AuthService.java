package com.ignite.innoverse.service;

import com.ignite.innoverse.dtos.request.AuthReq;
import com.ignite.innoverse.dtos.response.AuthRes;

public interface AuthService {
    AuthRes login(AuthReq authReq);
}
