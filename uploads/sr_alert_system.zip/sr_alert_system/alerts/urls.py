from django.urls import path
from .views import tradingview_webhook


urlpatterns = [
path("webhook/<int:index_security_id>/", tradingview_webhook),


]