import threading
from datetime import datetime

from core.utils import get_mongo_collection, get_option_chain_collection
from core.logging import get_logger

logger = get_logger("alerts-bg")


# ✅ OPTION LOOKUP FUNCTION
def get_option_security_id(index_security_id: int, strike: float, trade_type: str):
    """
    Fetch option security_id from option chain collection
    """

    try:
        collection = get_option_chain_collection()

        doc = collection.find_one(
            {"index_security_id": index_security_id},
            sort=[("fetched_at", -1)]
        )

        if not doc:
            raise Exception("Option chain not found")

        oc = doc.get("option_chain", {}).get("oc", {})

        strike_key = f"{float(strike):.6f}"

        strike_data = oc.get(strike_key)

        if not strike_data:
            raise Exception(f"Strike {strike_key} not found")

        if trade_type.lower() == "buyce":
            return strike_data.get("ce", {}).get("security_id")

        elif trade_type.lower() == "buype":
            return strike_data.get("pe", {}).get("security_id")

        else:
            raise Exception("Invalid trade type")

    except Exception as e:
        raise Exception(f"Option lookup failed: {str(e)}")


# ✅ BUILD TRADE FUNCTION
def build_trade(parsed: dict, raw_message: str, index_security_id: int):
    try:
        trade_type = parsed.get("Type", "").strip()
        entry = float(parsed.get("Price", 0) or 0)

        dl_avg = float(parsed.get("DL_Avg", 0) or 0)
        dh_avg = float(parsed.get("DH_Avg", 0) or 0)

        strike = float(parsed.get("Strike", 0) or 0)
        status = parsed.get("Status", "Unknown")
        
        # ✅ VALIDATION
        if entry <= 0:
            raise ValueError("Invalid entry price")

        option_security_id = get_option_security_id(
            index_security_id,
            strike,
            trade_type
        )

        if not option_security_id:
            raise ValueError("Option security_id not found")

        result = {
            "raw_message": raw_message,
            "index_security_id": index_security_id,
            "option_security_id": option_security_id,
            "type": trade_type,
            "direction": "CALL" if trade_type.lower() == "buyce" else "PUT",
            "entry": entry,
            "strike": strike,
            "status": status,
            "created_at": datetime.utcnow(),
            "display_id": None,
            # ✅ ✅ DEFAULT SYSTEM STATUS (WILL BE OVERRIDDEN IN VIEW)
            "system_status": "pending"
        }

        # ✅ STRATEGY LOGIC
        if trade_type.lower() == "buyce":
            result.update({
                "stop_loss": dl_avg,
                "target1": entry + 5,
                "target2": entry + 10
            })

        elif trade_type.lower() == "buype":
            result.update({
                "stop_loss": dh_avg,
                "target1": entry + 5,
                "target2": entry + 10
            })

        else:
            raise ValueError(f"Unknown trade type: {trade_type}")

        # ✅ METRICS
        result["risk"] = abs(entry - result["stop_loss"])
        result["reward"] = result["target2"] - entry

        return result

    except Exception as e:
        raise Exception(f"Trade build failed: {str(e)}")


# ✅ BACKGROUND SAVE FUNCTION
def save_trade_async(trade_data, tmp_id):
    try:
        collection = get_mongo_collection()

        # ✅ DUPLICATE CHECK
        existing = collection.find_one({
            "raw_message": trade_data.get("raw_message")
        })

        if existing:
            logger.info(f"[DUPLICATE] Skipping save for tmp_id={tmp_id}")
            return

        # ✅ Attach metadata
        trade_data["tmp_id"] = tmp_id
        trade_data["saved_at"] = datetime.utcnow()

        # ✅ Ensure system_status always present
        if not trade_data.get("system_status"):
            trade_data["system_status"] = f"placed_{tmp_id}"

        collection.insert_one(trade_data)

        logger.info(
            f"[ASYNC SAVED] tmp_id={tmp_id} | "
            f"status={trade_data.get('system_status')} | "
            f"opt_id={trade_data.get('option_security_id')}"
        )

    except Exception as e:
        logger.error(f"[ASYNC ERROR] {str(e)}")


# ✅ THREAD WRAPPER
def process_in_background(trade_data, tmp_id):
    try:
        thread = threading.Thread(
            target=save_trade_async,
            args=(trade_data, tmp_id),
            daemon=True
        )
        thread.start()

    except Exception as e:
        logger.error(f"[THREAD ERROR] {str(e)}")