import json
import uuid

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

from core.logging import get_logger
from .parser import parse_message
from .services import build_trade, process_in_background

from market_feed.manager import start_tracking
from market_feed.state import has_active_trade_same_type

logger = get_logger("alerts")


@csrf_exempt
def tradingview_webhook(request, index_security_id: int):
    """
    Webhook endpoint for TradingView alerts

    Flow:
    alert -> parse -> option lookup -> filter -> start tracking -> async save
    """

    # ✅ ALWAYS CREATE TMP ID FIRST
    tmp_id = f"tmp_{uuid.uuid4().hex[:10]}"

    if request.method != "POST":
        return JsonResponse(
            {
                "status": f"fail_{tmp_id}",
                "error": "Invalid method"
            },
            status=405
        )

    try:
        # ✅ Parse request body
        try:
            body = json.loads(request.body)
        except json.JSONDecodeError:
            return JsonResponse(
                {
                    "status": f"fail_{tmp_id}",
                    "error": "Invalid JSON"
                },
                status=400
            )

        message = body.get("message")

        if not message:
            return JsonResponse(
                {
                    "status": f"fail_{tmp_id}",
                    "error": "Message missing"
                },
                status=400
            )

        # ✅ Parse TradingView message
        parsed = parse_message(message)

        # ✅ Build trade
        trade_data = build_trade(parsed, message, index_security_id)
        trade_data["display_id"] = tmp_id.split("_")[1][:6]
        # ✅ Extract values
        option_security_id = trade_data.get("option_security_id")
        stop_loss = trade_data.get("stop_loss")
        direction = trade_data.get("direction")
        trade_type = trade_data.get("type")
        tv_status = trade_data.get("status")   # Allowed / Ignored

        # ✅ Validate required fields
        if not option_security_id:
            return JsonResponse(
                {
                    "status": f"fail_{tmp_id}",
                    "error": "Invalid option_security_id"
                },
                status=400
            )

        if not stop_loss:
            return JsonResponse(
                {
                    "status": f"fail_{tmp_id}",
                    "error": "Invalid stop_loss"
                },
                status=400
            )

        if not direction:
            return JsonResponse(
                {
                    "status": f"fail_{tmp_id}",
                    "error": "Invalid direction"
                },
                status=400
            )

        # ✅ ✅ FILTER LOGIC (CORE)
        if has_active_trade_same_type(direction):
            logger.info(
                f"[IGNORED] Active {direction} exists | tmp_id={tmp_id}"
            )

            return JsonResponse({
                "status": f"ign_{tmp_id}",
                "reason": f"Active {direction} trade exists",
                "option_security_id": option_security_id
            })

        # ✅ Override TradingView ignored signals
        if tv_status == "Ignored":
            logger.info(
                f"[OVERRIDE] TV Ignored → Accepting trade | tmp_id={tmp_id}"
            )

        # ✅ Attach system status
        trade_data["tmp_id"] = tmp_id
        trade_data["system_status"] = f"placed_{tmp_id}"

        # ✅ Start tracking
        start_tracking(
            index_id=index_security_id,
            option_security_id=option_security_id,
            tmp_id=tmp_id,
            stop_loss=stop_loss,
            direction=direction
        )

        # ✅ Async DB save
        process_in_background(trade_data, tmp_id)

        logger.info(
            f"[PLACED] tmp_id={tmp_id} | "
            f"type={trade_type} | direction={direction} | "
            f"tv_status={tv_status} | opt={option_security_id}"
        )

        # ✅ Success response
        return JsonResponse({
            "status": f"placed_{tmp_id}",
            "tmp_id": tmp_id,
            "option_security_id": option_security_id
        })

    except ValueError as ve:
        logger.error(f"[FAIL VALIDATION] {str(ve)} | tmp_id={tmp_id}")

        return JsonResponse(
            {
                "status": f"fail_{tmp_id}",
                "error": str(ve)
            },
            status=400
        )

    except Exception as e:
        logger.error(f"[FAIL ERROR] {str(e)} | tmp_id={tmp_id}")

        return JsonResponse(
            {
                "status": f"fail_{tmp_id}",
                "error": str(e)
            },
            status=500
        )