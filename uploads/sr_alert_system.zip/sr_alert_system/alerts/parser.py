 

def parse_message(message: str):
    """
    Parse TradingView alert message string into structured dict
    """

    data = {}

    try:
        parts = message.split(" ")

        for part in parts:
            if "=" in part:
                k, v = part.split("=", 1)
                data[k] = v

        return data

    except Exception as e:
        raise ValueError(f"Parsing failed: {str(e)}")