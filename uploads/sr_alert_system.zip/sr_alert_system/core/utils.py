from pymongo import MongoClient
from django.conf import settings

# ✅ Global client (singleton)
_client = None


def get_mongo_client():
    """
    Reuse single MongoDB connection
    """
    global _client

    if _client is None:
        _client = MongoClient(settings.MONGO_URI)

    return _client


# ✅ MAIN ALERT COLLECTION
def get_mongo_collection():
    client = get_mongo_client()
    db = client[settings.MONGO_DB]
    return db[settings.MONGO_COLLECTION]


# ✅ OPTION CHAIN COLLECTION
def get_option_chain_collection():
    client = get_mongo_client()
    db = client[settings.MONGO_OPTION_CHAIN_DB]
    return db[settings.MONGO_OPTION_CHAIN_COLLECTION]