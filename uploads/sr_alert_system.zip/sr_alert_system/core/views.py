from django.shortcuts import render
from django.http import JsonResponse, StreamingHttpResponse

import os
import time

# ✅ LOG FILE PATH (centralized)
LOG_FILE = os.path.join(os.getcwd(), "logs", "app.log")


# =====================================================
# ✅ FETCH LAST LOGS (REST API)
# =====================================================
def fetch_logs(request):
    """
    Return last N lines from log file
    """

    try:
        if not os.path.exists(LOG_FILE):
            return JsonResponse({
                "logs": [],
                "message": "Log file not found"
            })

        with open(LOG_FILE, "r", encoding="utf-8") as f:
            lines = f.readlines()[-200:]  # ✅ last 200 lines

        return JsonResponse({
            "logs": lines
        })

    except Exception as e:
        return JsonResponse({
            "error": str(e)
        }, status=500)


# =====================================================
# ✅ STREAM LOGS (SSE - REAL TIME)
# =====================================================
def stream_logs(request):
    """
    Stream logs in real-time using Server-Sent Events (SSE)
    """

    def event_stream():

        try:
            if not os.path.exists(LOG_FILE):
                yield "data: Log file not found\n\n"
                return

            with open(LOG_FILE, "r", encoding="utf-8") as f:
                # ✅ Move to end (only new logs)
                f.seek(0, os.SEEK_END)

                while True:
                    line = f.readline()

                    if not line:
                        time.sleep(1)
                        continue

                    # ✅ Send new log line
                    yield f"data: {line.strip()}\n\n"

        except Exception as e:
            yield f"data: ERROR: {str(e)}\n\n"

    response = StreamingHttpResponse(
        event_stream(),
        content_type="text/event-stream"
    )

    # ✅ Recommended headers (prevent buffering issues)
    response["Cache-Control"] = "no-cache"
    response["X-Accel-Buffering"] = "no"

    return response


# =====================================================
# ✅ DASHBOARD PAGE
# =====================================================
def dashboard(request):
    return render(request, "index.html")


# =====================================================
# ✅ LOGS PAGE
# =====================================================
def logs_page(request):
    return render(request, "logs.html")