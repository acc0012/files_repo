import logging
import os
from django.conf import settings


def get_logger(name=__name__):
    logger = logging.getLogger(name)

    # ✅ Prevent duplicate handlers
    if logger.handlers:
        return logger

    logger.setLevel(logging.INFO)  # always capture logs internally

    # ✅ Ensure logs directory exists
    log_dir = os.path.join(os.getcwd(), "logs")
    os.makedirs(log_dir, exist_ok=True)

    log_file_path = os.path.join(log_dir, "app.log")

    # ✅ Common formatter
    formatter = logging.Formatter(
        "\n" + 30 * "-" + "\n"
        "%(asctime)s | %(levelname)s\n"
        "File: %(filename)s | Line: %(lineno)d\n"
        "%(name)s\n"
        "%(message)s\n"
        + 30 * "-" + "\n"
    )

    # ✅ FILE HANDLER (ALWAYS ENABLED ✅)
    file_handler = logging.FileHandler(log_file_path)
    file_handler.setFormatter(formatter)
    file_handler.setLevel(logging.INFO)

    logger.addHandler(file_handler)

    # ✅ CONSOLE HANDLER (ONLY IF TEST_LOGS = TRUE)
    if getattr(settings, "TEST_LOGS", False):
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        console_handler.setLevel(logging.INFO)

        logger.addHandler(console_handler)

    return logger