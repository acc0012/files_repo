from django.apps import AppConfig


class MarketFeedConfig(AppConfig):
    name = "market_feed"
