import threading
from core.logging import get_logger

from .state import (
    LOCK,
    ENTRY_TRACKER,
    get_all_subscriptions,
    get_subscription_exchange,
    add_subscription,
    remove_subscription,
    reset_all_state
)

from .subscriber import (
    subscribe_instrument,
    unsubscribe_instrument
)

from .ws_client import (
    start_ws_listener,
    stop_ws_listener
)

logger = get_logger("feed-manager")


# =====================================================
# ✅ STOP ALL EXISTING TRACKING
# =====================================================
def stop_all_tracking():
    """
    Stop all active subscriptions + WS connections
    Fully reset system before new trade
    """

    try:
        # ✅ Get safe copy
        subscriptions = get_all_subscriptions()

        for sec_id, exchange in subscriptions.items():

            # ✅ UNSUBSCRIBE
            try:
                unsubscribe_instrument(exchange, sec_id)
                logger.info(f"[UNSUBSCRIBED] {sec_id} | exch={exchange}")
            except Exception as e:
                logger.error(f"[UNSUB ERROR] {sec_id} | {str(e)}")

            # ✅ STOP WS
            try:
                stop_ws_listener(sec_id)
            except Exception as e:
                logger.error(f"[WS STOP ERROR] {sec_id} | {str(e)}")

            # ✅ REMOVE SUB
            remove_subscription(sec_id)

        # ✅ Final cleanup (ensures zero leftover state)
        reset_all_state()

        logger.info("[RESET] All subscriptions & tracking cleared")

    except Exception as e:
        logger.error(f"[RESET ERROR] {str(e)}")


# =====================================================
# ✅ START TRACKING (MAIN ENGINE)
# =====================================================
def start_tracking(index_id, option_security_id, tmp_id, stop_loss, direction):
    """
    Flow:
    - STOP old feeds ✅
    - Subscribe new instruments ✅
    - Start WS ✅
    - Track trade ✅
    """

    try:
        # =====================================================
        # ✅ VALIDATION
        # =====================================================
        if not option_security_id:
            raise ValueError("Invalid option_security_id")

        if not stop_loss:
            raise ValueError("Invalid stop_loss")

        if not direction:
            raise ValueError("Invalid direction")

        # =====================================================
        # ✅ EXCHANGE MAPPING
        # =====================================================
        if index_id == 13:
            exchange = 2  # NSE_FNO
        elif index_id == 51:
            exchange = 8  # BSE_FNO
        else:
            raise Exception(f"Unknown index_id: {index_id}")

        # =====================================================
        # ✅ STEP 1: RESET SYSTEM
        # =====================================================
        stop_all_tracking()

        # =====================================================
        # ✅ STEP 2: SUBSCRIBE + START WS
        # =====================================================
        with LOCK:

            # ================================
            # ✅ INDEX SUBSCRIPTION
            # ================================
            if subscribe_instrument(exchange, index_id):

                add_subscription(index_id, exchange)

                threading.Thread(
                    target=start_ws_listener,
                    args=(index_id,),
                    daemon=True
                ).start()

                logger.info(f"[INDEX ACTIVE] {index_id} | exch={exchange}")

            else:
                logger.error(f"[INDEX SUB FAILED] {index_id}")

            # ================================
            # ✅ OPTION SUBSCRIPTION
            # ================================
            if subscribe_instrument(exchange, option_security_id):

                add_subscription(option_security_id, exchange)

                threading.Thread(
                    target=start_ws_listener,
                    args=(option_security_id,),
                    daemon=True
                ).start()

                logger.info(f"[OPTION ACTIVE] {option_security_id} | exch={exchange}")

            else:
                logger.error(f"[OPTION SUB FAILED] {option_security_id}")

            # =====================================================
            # ✅ STORE TRADE STATE
            # =====================================================
            ENTRY_TRACKER[option_security_id] = {
                "tmp_id": tmp_id,
                "index_id": index_id,
                "stop_loss": stop_loss,
                "direction": direction,

                "entry": None,
                "target1": None,
                "target2": None,

                "t1_hit": False,
                "t2_hit": False,
                "sl_hit": False,

                "closed": False,
                "sl_moved": False
            }

        logger.info(
            f"[TRACK STARTED] opt={option_security_id} | "
            f"index={index_id} | tmp_id={tmp_id} | dir={direction}"
        )

    except Exception as e:
        logger.error(f"[TRACKING ERROR] {str(e)}")