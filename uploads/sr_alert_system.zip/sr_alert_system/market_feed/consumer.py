from datetime import datetime
from core.logging import get_logger
from core.utils import get_mongo_collection

from .state import ENTRY_TRACKER, LOCK

logger = get_logger("feed-consumer")


def on_quote_feed(data):
    """
    Handle incoming market feed

    Logic:
    - Option security_id → ENTRY + TARGET tracking
    - Index security_id → STOPLOSS tracking (direction-aware)
    """

    try:
        security_id = data.get("security_id")
        ltp = float(data.get("LTP", 0))

        # ✅ Ignore invalid LTP
        if ltp <= 0:
            return

        collection = get_mongo_collection()

        # ✅ THREAD SAFE
        with LOCK:
            items = list(ENTRY_TRACKER.items())

        for option_sec_id, trade in items:

            # ✅ Skip closed trades
            if trade.get("closed"):
                continue

            tmp_id = trade.get("tmp_id")

            # =====================================================
            # ✅ OPTION LOGIC (ENTRY + TARGETS)
            # =====================================================
            if security_id == option_sec_id:

                # ✅ ENTRY FIX
                if not trade.get("entry"):
                    trade["entry"] = ltp
                    trade["target1"] = ltp + 5
                    trade["target2"] = ltp + 10

                    logger.info(f"ENTRY FIXED {security_id} @ {ltp}")

                    collection.update_one(
                        {"tmp_id": tmp_id},
                        {
                            "$set": {
                                "entry": ltp,
                                "target1": trade["target1"],
                                "target2": trade["target2"],
                                "entry_time": datetime.utcnow(),
                                "system_status": f"active_{tmp_id}"
                            }
                        }
                    )

                # ✅ TARGET 1 HIT
                if (
                    trade.get("target1") is not None and
                    ltp >= trade["target1"] and
                    not trade.get("t1_hit")
                ):
                    trade["t1_hit"] = True

                    logger.info(f"T1 HIT {security_id}")

                    collection.update_one(
                        {"tmp_id": tmp_id},
                        {
                            "$set": {
                                "t1_hit": True,
                                "t1_price": ltp,
                                "t1_time": datetime.utcnow()
                            }
                        }
                    )

                    # ✅ MOVE SL TO COST
                    if not trade.get("sl_moved"):
                        trade["stop_loss"] = trade["entry"]
                        trade["sl_moved"] = True

                        logger.info(f"SL MOVED TO COST for {security_id}")

                        collection.update_one(
                            {"tmp_id": tmp_id},
                            {
                                "$set": {
                                    "stop_loss": trade["entry"],
                                    "sl_moved": True
                                }
                            }
                        )

                # ✅ TARGET 2 HIT (EXIT)
                if (
                    trade.get("target2") is not None and
                    ltp >= trade["target2"] and
                    not trade.get("t2_hit")
                ):
                    trade["t2_hit"] = True
                    trade["closed"] = True

                    pnl = ltp - trade["entry"]

                    logger.info(f"T2 HIT {security_id} → CLOSED | PnL={pnl}")

                    collection.update_one(
                        {"tmp_id": tmp_id},
                        {
                            "$set": {
                                "t2_hit": True,
                                "t2_price": ltp,
                                "t2_time": datetime.utcnow(),
                                "exit_price": ltp,
                                "exit_type": "T2",
                                "exit_time": datetime.utcnow(),
                                "closed": True,
                                "pnl": pnl,
                                "system_status": f"closed_t2_{tmp_id}"
                            }
                        }
                    )

            # =====================================================
            # ✅ INDEX LOGIC (STOPLOSS)
            # =====================================================
            if security_id == trade.get("index_id"):

                index_ltp = ltp
                direction = trade.get("direction")

                # ✅ CALL
                if direction == "CALL":
                    if (
                        index_ltp <= trade.get("stop_loss", 0)
                        and not trade.get("sl_hit")
                    ):
                        trade["sl_hit"] = True
                        trade["closed"] = True

                        # Approx PnL
                        pnl = trade.get("stop_loss") - trade.get("entry", trade.get("stop_loss"))

                        logger.info(f"SL HIT CALL → CLOSED | PnL={pnl}")

                        collection.update_one(
                            {"tmp_id": tmp_id},
                            {
                                "$set": {
                                    "sl_hit": True,
                                    "exit_price": index_ltp,
                                    "exit_type": "SL",
                                    "exit_time": datetime.utcnow(),
                                    "closed": True,
                                    "pnl": pnl,
                                    "system_status": f"closed_sl_{tmp_id}"
                                }
                            }
                        )

                # ✅ PUT
                elif direction == "PUT":
                    if (
                        index_ltp >= trade.get("stop_loss", 0)
                        and not trade.get("sl_hit")
                    ):
                        trade["sl_hit"] = True
                        trade["closed"] = True

                        pnl = trade.get("entry", index_ltp) - trade.get("stop_loss")

                        logger.info(f"SL HIT PUT → CLOSED | PnL={pnl}")

                        collection.update_one(
                            {"tmp_id": tmp_id},
                            {
                                "$set": {
                                    "sl_hit": True,
                                    "exit_price": index_ltp,
                                    "exit_type": "SL",
                                    "exit_time": datetime.utcnow(),
                                    "closed": True,
                                    "pnl": pnl,
                                    "system_status": f"closed_sl_{tmp_id}"
                                }
                            }
                        )

    except Exception as e:
        logger.error(f"Feed error: {str(e)}")
