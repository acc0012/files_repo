"""
Global in-memory state for market feed tracking

NOTE:
- Thread-safe using LOCK
- Handles subscriptions, websocket lifecycle, and trade tracking
"""

import threading

# =====================================================
# ✅ GLOBAL LOCK
# =====================================================
LOCK = threading.Lock()


# =====================================================
# ✅ ACTIVE SUBSCRIPTIONS
# =====================================================
# format:
# {
#   security_id: exchange_segment
# }
ACTIVE_SUBSCRIPTIONS = {}


# =====================================================
# ✅ WEBSOCKET CONNECTIONS
# =====================================================
# format:
# {
#   security_id: websocket_object
# }
WS_CONNECTIONS = {}


# =====================================================
# ✅ TRADE TRACKER
# =====================================================
# format:
# {
#   option_security_id: { trade_data }
# }
ENTRY_TRACKER = {}


# =====================================================
# ✅ CHECK ACTIVE TRADE BY TYPE
# =====================================================
def has_active_trade_same_type(direction: str):
    with LOCK:
        return any(
            not trade.get("closed", False)
            and trade.get("direction") == direction
            for trade in ENTRY_TRACKER.values()
        )


# =====================================================
# ✅ GET ACTIVE TRADES
# =====================================================
def get_active_trades():
    with LOCK:
        return [
            trade.copy()
            for trade in ENTRY_TRACKER.values()
            if not trade.get("closed", False)
        ]


# =====================================================
# ✅ GET CLOSED TRADES
# =====================================================
def get_closed_trades():
    with LOCK:
        return [
            trade.copy()
            for trade in ENTRY_TRACKER.values()
            if trade.get("closed", False)
        ]


# =====================================================
# ✅ CHECK OPTION ACTIVE
# =====================================================
def is_option_active(option_security_id: int):
    with LOCK:
        trade = ENTRY_TRACKER.get(option_security_id)
        return trade is not None and not trade.get("closed", False)


# =====================================================
# ✅ GET TRADE BY TMP ID
# =====================================================
def get_trade_by_tmp_id(tmp_id: str):
    with LOCK:
        for trade in ENTRY_TRACKER.values():
            if trade.get("tmp_id") == tmp_id:
                return trade.copy()
    return None


# =====================================================
# ✅ CLEANUP CLOSED TRADES
# =====================================================
def cleanup_closed_trades():
    with LOCK:
        keys = [
            key for key, trade in ENTRY_TRACKER.items()
            if trade.get("closed", False)
        ]
        for key in keys:
            del ENTRY_TRACKER[key]


# =====================================================
# ✅ COUNT ACTIVE BY TYPE
# =====================================================
def count_active_trades(direction: str):
    with LOCK:
        return sum(
            1
            for trade in ENTRY_TRACKER.values()
            if not trade.get("closed", False)
            and trade.get("direction") == direction
        )


# =====================================================
# ✅ SUBSCRIPTION MANAGEMENT
# =====================================================
def add_subscription(security_id: int, exchange: int):
    with LOCK:
        ACTIVE_SUBSCRIPTIONS[security_id] = exchange


def get_subscription_exchange(security_id: int):
    with LOCK:
        return ACTIVE_SUBSCRIPTIONS.get(security_id)


def remove_subscription(security_id: int):
    with LOCK:
        ACTIVE_SUBSCRIPTIONS.pop(security_id, None)


def get_all_subscriptions():
    """
    Return copy of all subscriptions (safe iteration)
    """
    with LOCK:
        return ACTIVE_SUBSCRIPTIONS.copy()


# =====================================================
# ✅ WEBSOCKET MANAGEMENT
# =====================================================
def register_ws(security_id: int, ws):
    with LOCK:
        WS_CONNECTIONS[security_id] = ws


def get_ws(security_id: int):
    with LOCK:
        return WS_CONNECTIONS.get(security_id)


def remove_ws(security_id: int):
    with LOCK:
        WS_CONNECTIONS.pop(security_id, None)


def is_ws_active(security_id: int):
    with LOCK:
        return security_id in WS_CONNECTIONS


# =====================================================
# ✅ TRACKER MANAGEMENT
# =====================================================
def add_trade(option_security_id: int, trade_data: dict):
    with LOCK:
        ENTRY_TRACKER[option_security_id] = trade_data


def get_all_trades():
    with LOCK:
        return ENTRY_TRACKER.copy()


# =====================================================
# ✅ RESET STATE (CRITICAL)
# =====================================================
def reset_all_state():
    """
    Clears all runtime memory:
    - subscriptions
    - websocket connections
    - trade tracker
    """

    with LOCK:
        ACTIVE_SUBSCRIPTIONS.clear()
        WS_CONNECTIONS.clear()
        ENTRY_TRACKER.clear()