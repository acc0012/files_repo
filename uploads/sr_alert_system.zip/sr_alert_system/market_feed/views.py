from django.http import JsonResponse
from market_feed.state import get_active_trades
from core.utils import get_mongo_collection


# ✅ Helper: safe JSON conversion
def serialize_trade(trade):
    """
    Clean trade object for JSON response
    """
    return {
        "tmp_id": trade.get("tmp_id"),
        "display_id": trade.get("display_id"),
        "direction": trade.get("direction"),
        "entry": trade.get("entry"),
        "target1": trade.get("target1"),
        "target2": trade.get("target2"),
        "stop_loss": trade.get("stop_loss"),
        "t1_hit": trade.get("t1_hit"),
        "t2_hit": trade.get("t2_hit"),
        "sl_hit": trade.get("sl_hit"),
        "closed": trade.get("closed", False),
    }


# ✅ ACTIVE TRADES API
def active_trades(request):
    """
    Return all active trades (in-memory)
    """

    data = get_active_trades()

    # ✅ Clean + format data
    trades = [serialize_trade(t) for t in data]

    return JsonResponse({
        "count": len(trades),
        "trades": trades
    })


# ✅ CLOSED TRADES API
def closed_trades(request):
    """
    Fetch closed trades from MongoDB
    """

    collection = get_mongo_collection()

    docs = list(
        collection.find(
            {"closed": True},
            {"_id": 0}
        )
        .sort("exit_time", -1)
        .limit(50)
    )

    # ✅ Normalize fields (important for UI stability)
    result = []
    for d in docs:
        result.append({
            "tmp_id": d.get("tmp_id"),
            "display_id": d.get("display_id"),
            "direction": d.get("direction"),
            "entry": d.get("entry"),
            "exit_price": d.get("exit_price"),
            "pnl": d.get("pnl", 0),
            "system_status": d.get("system_status"),
            "exit_time": d.get("exit_time"),
        })

    return JsonResponse({
        "count": len(result),
        "trades": result
    })