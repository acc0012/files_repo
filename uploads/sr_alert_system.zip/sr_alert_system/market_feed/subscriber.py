import requests
from core.logging import get_logger

logger = get_logger("market-feed")

# ✅ Railway base URL
BASE_HTTP = "https://temp101.up.railway.app"


def subscribe_instrument(exchange_segment, security_id):
    """
    Subscribe instrument using Railway API
    """

    try:
        payload = {
            "symbols": [[exchange_segment, str(security_id), 17]]
        }

        response = requests.post(
            f"{BASE_HTTP}/subscribe",
            json=payload,
            timeout=5
        )

        if response.status_code != 200:
            logger.error(
                f"[SUBSCRIBE FAIL] HTTP {response.status_code} | sec={security_id}"
            )
            return False

        data = response.json()

        if data.get("status") == "success":
            logger.info(
                f"[SUBSCRIBED] sec={security_id} | exchange={exchange_segment}"
            )
            return True

        logger.error(f"[SUBSCRIBE FAIL] {data}")
        return False

    except Exception as e:
        logger.error(f"[SUBSCRIBE ERROR] sec={security_id} | {str(e)}")
        return False


def unsubscribe_instrument(exchange_segment, security_id):
    """
    Unsubscribe instrument using Railway API
    """

    try:
        payload = {
            "symbols": [[exchange_segment, str(security_id), 17]]
        }

        response = requests.post(
            f"{BASE_HTTP}/unsubscribe",
            json=payload,
            timeout=5
        )

        if response.status_code != 200:
            logger.error(
                f"[UNSUB FAIL] HTTP {response.status_code} | sec={security_id}"
            )
            return False

        data = response.json()

        if data.get("status") == "success":
            logger.info(
                f"[UNSUBSCRIBED] sec={security_id} | exchange={exchange_segment}"
            )
            return True

        logger.error(f"[UNSUB FAIL] {data}")
        return False

    except Exception as e:
        logger.error(f"[UNSUB ERROR] sec={security_id} | {str(e)}")
        return False