import json
import time
import threading
import websocket

from core.logging import get_logger
from market_feed.consumer import on_quote_feed
from django.conf import settings

from market_feed.state import (
    register_ws,
    get_ws,
    remove_ws,
    is_ws_active,   # ✅ new helper
)

logger = get_logger("ws-client")

# ✅ WebSocket base URL
BASE_WS = settings.BASE_WS


# =====================================================
# ✅ START WS LISTENER
# =====================================================
def start_ws_listener(security_id):
    """
    Start WebSocket listener for a given security_id

    Flow:
    WS → receive tick → parse → send to trading engine
    """

    url = f"{BASE_WS}/{security_id}/quote"

    # ✅ CONTROL FLAG
    should_reconnect = True

    def on_message(ws, message):
        try:
            data = json.loads(message)

            # ✅ Send to trading engine
            on_quote_feed(data)

        except Exception as e:
            logger.error(f"[WS PARSE ERROR] sec={security_id} | {str(e)}")

    def on_error(ws, error):
        logger.error(f"[WS ERROR] sec={security_id} | {str(error)}")

    def on_close(ws, close_status_code, close_msg):
        logger.warning(f"[WS CLOSED] sec={security_id}")

        # ✅ Check if we should reconnect
        if should_reconnect:
            if is_ws_active(security_id):
                time.sleep(2)
                reconnect()
            else:
                logger.info(f"[WS CLEAN STOP] sec={security_id}")

    def on_open(ws):
        logger.info(f"[WS CONNECTED] sec={security_id}")

    def reconnect():
        try:
            logger.info(f"[WS RECONNECTING] sec={security_id}")

            threading.Thread(
                target=start_ws_listener,
                args=(security_id,),
                daemon=True
            ).start()

        except Exception as e:
            logger.error(f"[WS RECONNECT ERROR] sec={security_id} | {str(e)}")

    # ✅ Create WebSocket client
    ws = websocket.WebSocketApp(
        url,
        on_message=on_message,
        on_error=on_error,
        on_close=on_close,
        on_open=on_open
    )

    # ✅ Register WS (thread-safe via state)
    register_ws(security_id, ws)

    try:
        logger.info(f"[WS START] sec={security_id}")

        # ✅ Stable connection settings
        ws.run_forever(
            ping_interval=30,
            ping_timeout=10
        )

    except Exception as e:
        logger.error(f"[WS RUN ERROR] sec={security_id} | {str(e)}")


# =====================================================
# ✅ STOP WS LISTENER
# =====================================================
def stop_ws_listener(security_id):
    """
    Stop WebSocket cleanly and prevent reconnect
    """

    try:
        ws = get_ws(security_id)

        if not ws:
            return

        logger.info(f"[WS STOP] sec={security_id}")

        # ✅ Remove BEFORE closing → prevents reconnect
        remove_ws(security_id)

        # ✅ Close connection
        ws.close()

    except Exception as e:
        logger.error(f"[WS STOP ERROR] sec={security_id} | {str(e)}")