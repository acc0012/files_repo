"""
URL configuration for sr_alert_system project.
"""

from django.contrib import admin
from django.urls import path, include

# ✅ Core Views
from core.views import (
    dashboard,
    logs_page,
    fetch_logs,
    stream_logs
)

# ✅ Trade APIs
from market_feed.views import (
    active_trades,
    closed_trades
)


urlpatterns = [

    # =========================================
    # ✅ ADMIN
    # =========================================
    path("admin/", admin.site.urls),

    # =========================================
    # ✅ TRADINGVIEW WEBHOOK
    # =========================================
    path("alerts/", include("alerts.urls")),

    # =========================================
    # ✅ DASHBOARD UI
    # =========================================
    path("", dashboard, name="dashboard"),

    # =========================================
    # ✅ TRADE APIs
    # =========================================
    path("api/active-trades/", active_trades, name="active-trades"),
    path("api/closed-trades/", closed_trades, name="closed-trades"),

    # =========================================
    # ✅ LOGS UI
    # =========================================
    path("logs/", logs_page, name="logs-page"),

    # =========================================
    # ✅ LOGS APIs
    # =========================================
    path("api/logs/", fetch_logs, name="fetch-logs"),
    path("api/logs/stream/", stream_logs, name="stream-logs"),
]
